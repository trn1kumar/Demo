import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MatSnackBar, MatDialogRef, MatDialogConfig, MatDialog } from '@angular/material';
import { FirstStepComponent } from '../sign-up/first-step/first-step.component';
import { SecondStepComponent } from '../sign-up/second-step/second-step.component';
import { ForgotPasswordComponent } from '../forgot-password/forgot-password.component';
import { SocialUser, AuthService, GoogleLoginProvider, FacebookLoginProvider } from 'angular-6-social-login';
import { SnackBarConfig } from 'src/app/core/services/extra/snackbar.config';
import { TokenStorageService } from 'src/app/core/services/token/token-storage.service';
import { LoginService } from 'src/app/core/services/auth/login.service';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { SmeInfoService } from 'src/app/core/services/sme-page/sme-info.service';
import { BusinessCircleService } from 'src/app/core/services/circle/business-circle.service';
import { GoogleOauthToken } from 'src/app/core/models/googelOauthToken';
import { SocialLoginCredentials } from 'src/app/core/models/socialLoginCredentials';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  hide = true;
  user: SocialUser
  loginForm: FormGroup;
  signupDialogRef: MatDialogRef<FirstStepComponent>;
  otpDialogRef: MatDialogRef<SecondStepComponent>;
  forgotPasswordDialogRef: MatDialogRef<ForgotPasswordComponent>

  constructor(private snackBar: MatSnackBar, private snackBarConfig: SnackBarConfig,
    private token: TokenStorageService, private loginService: LoginService,
    private formBuilder: FormBuilder, private dialogRef: MatDialogRef<LoginComponent>,
    private jwtToken: JwtTokenService, private smeInfoService: SmeInfoService,
    private matDialog: MatDialog, private businessCircle: BusinessCircleService,
    private auth: AuthService) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: new FormControl(null, [Validators.required]),
      password: new FormControl(null, [Validators.required])
    })
  }

  login(loginCredentials) {

    if (this.loginForm.controls['username'].valid && this.loginForm.controls['password'].valid) {

      this.loginService.login(loginCredentials).subscribe(
        res => {
          this.dialogRef.close()
          this.token.saveToken(res.body.token)

          if (!this.jwtToken.getUserType()) {
            
            let uuid = this.jwtToken.getUserId();
            this.smeUuid(uuid)
          }
          else{
          
          }
          // 
        },
        err => {
         
          if(err.error.errorCode==600){
            let errorMessage:string =err.error.errorMessage;
            let uuid=errorMessage.split('.')[1];
            
            sessionStorage.setItem('uuid', btoa(uuid))
            this.openOtpDialog()
          }


          if (err.status == 0) {
            return false
          } else {
            if (err.error.message == "Unauthorized:Bad credentials") {
              this.loginForm.controls['password'].setErrors({
                "passwordNotFound": true
              });
            }
            else {
              this.loginForm.controls['username'].setErrors({
                "usernameNotFound": true
              });
            }
          }
        }
      )

    } else {
      return false
    }

  }

  loginWithOTP() {

    if (this.loginForm.controls['username'].status == "INVALID") {
      this.loginForm.controls['username'].markAsTouched()
      this.loginForm.controls['password'].markAsUntouched()
    }

    if (this.loginForm.controls['username'].valid) {
      this.loginService.loginWithOTP(this.loginForm.controls['username'].value).subscribe(
        res => {
          this.snackBar.open('OTP sent successfully !!', '', this.snackBarConfig.getSnackBarConfig())
          sessionStorage.setItem('uuid', btoa(res.uuid))
          sessionStorage.setItem('m', btoa(res.username))
          this.openOtpDialog()
        },
        err => {
          if (err.error.httpStatus == 403) {
            this.loginForm.controls['username'].setErrors({
              'usernameNotFound': true
            })
          }
        }
      )
    }

  }

  signUp() {
    this.dialogRef.close()
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false
    dialogConfig.width = '400px'

    this.signupDialogRef = this.matDialog.open(FirstStepComponent, dialogConfig)
  }

  openOtpDialog() {
    this.dialogRef.close()
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false
    dialogConfig.width = '400px'

    this.otpDialogRef = this.matDialog.open(SecondStepComponent, dialogConfig)
  }

  openForgotPasswordDialog() {
    this.dialogRef.close()
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false
    dialogConfig.width = '400px'

    this.forgotPasswordDialogRef = this.matDialog.open(ForgotPasswordComponent, dialogConfig)
  }

  signInWithGoogle(): void {
    this.auth.signIn(GoogleLoginProvider.PROVIDER_ID).then(userData => {
      // console.log('userData:   ', userData)
      let googleUser = new GoogleOauthToken();
      googleUser.authToken = userData.idToken;
      googleUser.clientId = SocialLoginCredentials.googleClientId;
      console.log('googleuser', googleUser)
      this.getLogin(googleUser, 'google');
    },
    err=>
    {
      console.log('Error',err)
    });
  }

  signInWithFacebook(): void {
    this.auth.signIn(FacebookLoginProvider.PROVIDER_ID).then(fbdata => {
      console.log('fbdata: ', fbdata)
      this.getLogin(fbdata, 'facebook')
    });
  }

  getLogin(userData, provider: string) {
    if (provider == 'google') {

      this.loginService.googleSocialLogin(userData).subscribe(
        res => {
          this.token.saveToken(res.token)
          if (!this.jwtToken.getUserType()) {
            let uuid = this.jwtToken.getUserId();
            this.smeUuid(uuid)
          }
          // this.reloadWindow();
        },
        err => {
          console.log(err)
        }
      )

    } else if (provider == 'facebook') {

      this.loginService.facebookSocialLogin(userData).subscribe(
        res => {
          this.token.saveToken(res.token)
          if (!this.jwtToken.getUserType()) {
            let uuid = this.jwtToken.getUserId();
            this.smeUuid(uuid)
           
          }
         
          // 
        },
        err => {
          console.log(err)
        }
      )
    }
    else {
      console.log('Invalid Provider')
    }
  }

  smeUuid(uuid) {

    this.smeInfoService.smeUuid(uuid).subscribe(
      res => {

        if (res.sUuid != null || res.sUuid != undefined) {
          localStorage.setItem('sUuid', btoa(res.sUuid))
          // this.businessCircle.smeLoginCircle(res.sUuid)
        }
      },
    )
  }

  close() {
    this.dialogRef.close()
  }

}
