/* Modules */
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { AuthRoutingModule } from './auth-routing.module';
/* Components */
import { FirstStepComponent } from './sign-up/first-step/first-step.component';
import { SecondStepComponent } from './sign-up/second-step/second-step.component';
import { LoginComponent } from './login/login.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import {
  SocialLoginModule,
  AuthServiceConfig,
  GoogleLoginProvider,
  FacebookLoginProvider

} from 'angular-6-social-login';
import { SocialLoginCredentials } from 'src/app/core/models/socialLoginCredentials';

export function getAuthServiceConfigs() {
  const config = new AuthServiceConfig(
      [
        {
          id: FacebookLoginProvider.PROVIDER_ID,
          provider: new FacebookLoginProvider(SocialLoginCredentials.facebookClientId)
        },
        {
          id: GoogleLoginProvider.PROVIDER_ID,
          provider: new GoogleLoginProvider(SocialLoginCredentials.googleClientId)
        }
      ]
  );
  return config;
}

@NgModule({
  imports: [
    CommonModule,
    AuthRoutingModule,
    SharedModule,
    SocialLoginModule,

  ],
  declarations: [
    FirstStepComponent, 
    SecondStepComponent, 
    LoginComponent, 
    ForgotPasswordComponent
  ],
  entryComponents : [
    LoginComponent,
    FirstStepComponent,
    SecondStepComponent,
    ForgotPasswordComponent
  ],
  providers: [  {
    provide: AuthServiceConfig,
    useFactory: getAuthServiceConfigs
  }],
  bootstrap: []
})
export class AuthModule { }
