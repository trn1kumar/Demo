import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import * as $ from 'jquery';
import { MatSnackBar, MatDialogRef, MatDialog, MatDialogConfig } from '@angular/material';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { LoginComponent } from '../login/login.component';
import { SignUpService } from 'src/app/core/services/auth/sign-up.service';
import { SnackBarConfig } from 'src/app/core/services/extra/snackbar.config';
import { LoginService } from 'src/app/core/services/auth/login.service';
import { TokenStorageService } from 'src/app/core/services/token/token-storage.service';


@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  @ViewChild('idotp')
  otpField: ElementRef

  @ViewChild('password')
  passwordField: ElementRef

  constructor(private signupService: SignUpService, private snackBar: MatSnackBar,
    private snackBarConfig: SnackBarConfig , private formBuilder : FormBuilder , private loginService : LoginService,
    private dialogRef : MatDialogRef<ForgotPasswordComponent> , public token : TokenStorageService,
    private matDialog:MatDialog) { }

  hide = true;
  forgotPasswordForm: FormGroup;
  setNewPassword: FormGroup;
  emailormobile: string;
  count: number = 0;
  waitingMsg: string = "You can Resend OTP after 5 seconds";
  button1 = true
  resetPassword = false
  loginDialogRef:MatDialogRef<LoginComponent>

  ngOnInit() {
    $('#waitingmsg').hide();

    this.forgotPasswordForm = this.formBuilder.group({
      username : new FormControl(null,[Validators.required])
    })

    this.setNewPassword = this.formBuilder.group({
      otp : new FormControl(null,[Validators.required,Validators.pattern('[0-9]+')]),
      newPassword : new FormControl(null,[Validators.required,Validators.minLength(5)])
    })
  }

  sendOTP(username){
    if(this.forgotPasswordForm.valid){
      this.loginService.forgotPassword(username).subscribe(
        res =>{
          sessionStorage.setItem('u',btoa(username.username))
          sessionStorage.setItem('uuid',btoa(res.uuid))
          this.forgotPasswordForm.controls['username'].disable();
          this.emailormobile = atob(sessionStorage.getItem("u"))
          this.button1 = false
          this.resetPassword = true
        },
        err => {
          if(err.error.httpStatus == 403){
            this.snackBar.open(username.username + " Not Exist !!","Ok",this.snackBarConfig.getSnackBarConfig())
            this.forgotPasswordForm.controls['username'].setErrors({
              'required' : true
            })
          }
        }
      )
    }else{
      return false
    }
  }

  savePassword(){
    if(this.setNewPassword.valid){

        if(sessionStorage.getItem('uuid') != null){
          let enteredOTP = JSON.stringify({ otp : this.setNewPassword.controls['otp'].value , 
                                            uuid : atob(sessionStorage.getItem('uuid'))         })

          this.signupService.verifyOTP(enteredOTP,null).subscribe(
            res => {
              let newPassword = JSON.stringify({newPassword : this.setNewPassword.controls['newPassword'].value ,
              uuid : atob(sessionStorage.getItem('uuid'))})
              this.loginService.resetPassword(newPassword,res.body.token).subscribe(
                res =>{
                  this.snackBar.open('Password has been changed successfully !!','',this.snackBarConfig.getSnackBarConfig())
                  this.dialogRef.close()
                  sessionStorage.clear()
                  
                    this.dialogRef.close()
                    const dialogConfig = new MatDialogConfig();
                    dialogConfig.autoFocus = false
                    dialogConfig.width = '400px'
                
                    this.loginDialogRef = this.matDialog.open(LoginComponent , dialogConfig)
                  
                
                }
              )
            },
            err => {
              this.snackBar.open("Please enter valid OTP","Ok",this.snackBarConfig.getSnackBarConfig())
              this.setNewPassword.controls['otp'].setErrors({
                'wrongOTP' : true
              })
            }
          )
        } 
    }
    else{
      this.passwordField.nativeElement.focus()
    }
  }

  resendOTP(){

    if(sessionStorage.getItem('uuid') != null){

      ++this.count

      if(this.count >= 5){
        $('#resendLink').hide().delay(5000).show(0)
        this.count = 0
        $('#waitingmsg').show().delay(5000).hide(0)
      }

      this.signupService.resendOTP(atob(sessionStorage.getItem('uuid'))).subscribe(
        res => {
          this.snackBar.open('OTP resend successfully !!','',this.snackBarConfig.getSnackBarConfig())
        }
     )
    }
  }

  close() {
    this.dialogRef.close()
  }
}
