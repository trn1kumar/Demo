import { Component, OnInit } from '@angular/core';
import { ErrorStateMatcher, MatSnackBar, MatDialogRef, MatDialogConfig, MatDialog } from '@angular/material';
import { FormControl, FormGroupDirective, NgForm, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SecondStepComponent } from '../second-step/second-step.component';
import { LoginComponent } from '../../login/login.component';
import { SignUpService } from 'src/app/core/services/auth/sign-up.service';
import { SnackBarConfig } from 'src/app/core/services/extra/snackbar.config';

export class EmailStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl, form: FormGroupDirective | NgForm | null): boolean {
    return !!(control && control.invalid);
  }
}

@Component({
  selector: 'app-first-step',
  templateUrl: './first-step.component.html',
  styleUrls: ['./first-step.component.css']
})
export class FirstStepComponent implements OnInit {

  constructor(private formBuilder: FormBuilder , private signupService : SignUpService ,
    private snackBar : MatSnackBar , private snackBarConfig : SnackBarConfig ,
    private dialogRef : MatDialogRef<FirstStepComponent> , private matDialog : MatDialog) { }

hide = true;
signupForm: FormGroup;
emailPattern = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
emailMatcher = new EmailStateMatcher();
otpDialogRef : MatDialogRef<SecondStepComponent>;
loginDialogRef : MatDialogRef<LoginComponent>;
ngOnInit() {

this.signupForm = this.formBuilder.group({

userFullName: new FormControl(null, [Validators.required, Validators.pattern('[a-zA-Z ]*$')]),
userMobile: new FormControl(null, [Validators.required, Validators.pattern('[0-9]+'), Validators.minLength(10)]),
userEmail: new FormControl(null, [Validators.pattern(this.emailPattern)]),
userPassword: new FormControl(null, [Validators.required, Validators.minLength(5), Validators.maxLength(20)]),

})
}

generateOTP(userData) {

if(this.signupForm.valid){

this.signupService.generateOTP(userData).subscribe(
res => {
sessionStorage.clear()
sessionStorage.setItem('uuid',btoa(res.body.uuid))
sessionStorage.setItem('m',btoa(res.body.userMobile))
if(res.body.userEmail != null || res.body.userEmail != undefined ){
  sessionStorage.setItem('e',btoa(res.body.userEmail))
}
this.openOtpDialog()
},
err => {
let msg: string = err.error.errorMessage
if (msg.indexOf('@') != -1) {
  this.snackBar.open(err.error.errorMessage,'', this.snackBarConfig.getSnackBarConfig())
  this.signupForm.controls['userEmail'].setErrors({
    'emailExist': true
  })
}
else {
  this.snackBar.open(err.error.errorMessage,'',this.snackBarConfig.getSnackBarConfig())
  this.signupForm.controls['userMobile'].setErrors({
    'mobileExist': true
  })
}
}
)
}else{
return false
}

}


signIn() {
this.dialogRef.close()
const dialogConfig = new MatDialogConfig();
dialogConfig.autoFocus = false
dialogConfig.width = '400px'

this.loginDialogRef = this.matDialog.open(LoginComponent , dialogConfig)
}

openOtpDialog(){
this.dialogRef.close()
const dialogConfig = new MatDialogConfig();
dialogConfig.autoFocus = false
dialogConfig.width = '400px'

this.otpDialogRef = this.matDialog.open(SecondStepComponent ,dialogConfig)
}

close(){
this.dialogRef.close()
sessionStorage.clear()
}
}
