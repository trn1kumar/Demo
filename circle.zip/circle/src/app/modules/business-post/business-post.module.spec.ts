import { BusinessPostModule } from './business-post.module';

describe('BusinessPostModule', () => {
  let businessPostModule: BusinessPostModule;

  beforeEach(() => {
    businessPostModule = new BusinessPostModule();
  });

  it('should create an instance', () => {
    expect(businessPostModule).toBeTruthy();
  });
});
