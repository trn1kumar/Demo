import { Component, OnInit, Input } from '@angular/core';
import { BusinessCircle } from 'src/app/core/models/business-circle';
import { SME } from 'src/app/core/models/sme';
import { BusinessCircleService } from 'src/app/core/services/circle/business-circle.service';
import { RestURL } from 'src/app/core/models/rest-api-url';


@Component({
  selector: 'app-business-profile',
  templateUrl: './business-profile.component.html',
  styleUrls: ['./business-profile.component.css']
})
export class BusinessProfileComponent implements OnInit {

  @Input()
  sme: any
  count:number=0;
  circle: BusinessCircle;
  receviedReq: SME[];
  sentReq:SME[];
  pendingRequestsNotFound:boolean=false
  seeAll:boolean=true
  seeAllConnection:boolean=false
  constructor(private businessCircle: BusinessCircleService) { }

  ngOnInit() {
     /*For Count */
     let sUuid=atob(localStorage.getItem('sUuid'));
     this.businessCircle.getBusinessCircle(sUuid).subscribe(
      res => {
        this.circle = res;
        this.receviedReq = this.circle.receiveRequests
        if(this.receviedReq == null || this.receviedReq == undefined)
        {
          this.pendingRequestsNotFound=true;
          this.seeAll=false
        }
        /*My Conenctions START*/
       
        if(this.circle.myConnetions != undefined)
        {
          this.count = this.circle.myConnetions.length
        }
      
        
        /*My Conenctions END*/
      },);
  }
  getImage(imageName) {

    if (imageName != null) {
      return RestURL.contentServerUrl + (imageName);
    } else
      return "/assets/logo/Male-Avatar.png"
  }
  smeNameClick(sUuid) {
    let url = 'sme/' + sUuid
    window.open(url, '_blank')
  }
  onMyConnection()
  {
    let url = 'circle/my-connections'
    window.open(url, '_blank')
  }
}
