import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BusinessRightSideComponent } from './business-right-side.component';

describe('BusinessRightSideComponent', () => {
  let component: BusinessRightSideComponent;
  let fixture: ComponentFixture<BusinessRightSideComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BusinessRightSideComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BusinessRightSideComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
