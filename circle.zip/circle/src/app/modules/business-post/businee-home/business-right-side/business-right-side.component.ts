import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { SME } from 'src/app/core/models/sme';
import { BusinessCircleService } from 'src/app/core/services/circle/business-circle.service';
import { SnackBarConfig } from 'src/app/core/services/extra/snackbar.config';
import { BusinessCircle, SendRequest } from 'src/app/core/models/business-circle';
import { RestURL } from 'src/app/core/models/rest-api-url';


@Component({
  selector: 'app-business-right-side',
  templateUrl: './business-right-side.component.html',
  styleUrls: ['./business-right-side.component.css']
})
export class BusinessRightSideComponent implements OnInit {

  suggestions: SME[]
  smeNotFound : boolean = false
  constructor(private businessCircle: BusinessCircleService,private snackbarConfig : SnackBarConfig,private snackBar: MatSnackBar) { }

  ngOnInit() {
    let sUuid=atob(localStorage.getItem('sUuid'));
    this.businessCircle.getPeopleYouMayKnow(sUuid).subscribe(
      res=>
      {  /*PeopleYouMayKnow START*/ 
          this.suggestions=res;
          // console.log(res)
          /*PeopleYouMayKnow END*/ 
      },
      err=>
    {
      this.smeNotFound=true
    }
    );
  }
  onaddConnection(suggestion,index)
  {
    let circle = new BusinessCircle()
    let sendRequest = new SendRequest()
    let sendReq=[];
    circle.sUuid = atob(localStorage.getItem("sUuid"))
    // console.log("platformSMEs",platformSMEs.smeId);
    // console.log("smeId",circle.sUuid);
    sendRequest.toSmeId=suggestion.sUuid;
    // console.log("sendRequestId",sendRequest.toSmeId);
    sendReq.push(sendRequest);
    circle.sendRequests=sendReq;
    // console.log(circle);
  
    this.businessCircle.addBusinessRequest(circle).subscribe(
      response=>
      {
        // console.log("response",response);
        this.snackBar.open('Invitation Sent to '  +suggestion.smeName,'Ok',this.snackbarConfig.getSnackBarConfig());
        this.suggestions.splice(index,1);
      },
    )
  }
  getImage(imageName) {

    if (imageName != null) {
      return RestURL.contentServerUrl + (imageName);
    } else
      return "/assets/logo/Male-Avatar.png"
  }
  smeNameClick(sUuid) {
    let url = 'sme/' + sUuid
    window.open(url, '_blank')
  }
  refresh()
  {
    window.location.reload();
  }
}
