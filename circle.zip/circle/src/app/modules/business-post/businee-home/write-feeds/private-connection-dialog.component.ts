import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";
import { Inject, Component } from "@angular/core";
import { SMECircleDto } from "src/app/core/models/business-circle";
import { BusinessCircleService } from "src/app/core/services/circle/business-circle.service";
import { RestURL } from "src/app/core/models/rest-api-url";

@Component({
    template: `
    <a href matTooltip="Close" onclick="return false" (click)="close()" style="float:right ; color : rgb(43, 43, 192)">
        <mat-icon>close</mat-icon>
    </a>
        <div class="fluid-container ">
        <h5>Share with Only Specific Person</h5>
            <div class="row" *ngFor="let connection of connections">
                  <mat-checkbox class="example-margin" (click)="oncl(connection.sUuid)"> </mat-checkbox>
                 <br>
                 <img [src]="getImage(connection.logoImage)" alt="Avatar" class="avatar">
                 <a href="/sme/{{connection.sUuid}}" onclick="return false" (click)="smeNameClick(connection.sUuid)">
                 <h6 style="margin-left:10px">{{connection.smeName}}</h6>
                 </a>
            </div>
            <br>
            <mat-chip-list>
               <mat-chip style="margin-left:300px; width:50px" color="primary" selected *ngIf="connectionIds?.length > 0" (click)="onclick()">Done</mat-chip>
            </mat-chip-list>
        </div>
      
    `,
    styles: [
        `
        a { color: inherit; } 
        a:hover {
            color: rgb(76, 197, 245);
        }
        .avatar {
            vertical-align: middle;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border;
        }
        `,
    ],
})
export class PrivateConnectionDialog {

    connectionIds:string[]=[]
    connections:Array<SMECircleDto>
    constructor(private dialogRef: MatDialogRef<PrivateConnectionDialog>,
        @Inject(MAT_DIALOG_DATA) public data: any,private businessCircle:BusinessCircleService ) {
    }

    ngOnInit() {
        let sUuid=atob(localStorage.getItem('sUuid'));

        this.businessCircle.getMyCircleConnection(sUuid).subscribe(
            res=>
            {
                this.connections=res
                console.log('data',res)
            }
        )
    }
    onclick()
    {
        this.dialogRef.close(this.connectionIds)
    }
    oncl(id:string)
    {
        let index=this.connectionIds.indexOf(id)
        if(index === -1)
        {
            this.connectionIds.push(id)
            console.log('connectionIds',this.connectionIds)
        }
        else{
            this.connectionIds.splice(index,1)
            console.log('connectionIds Remove',this.connectionIds)
        }
   
    }
    getImage(imageName) {

        if (imageName != null) {
          return RestURL.contentServerUrl + (imageName);
        } else
          return "/assets/logo/Male-Avatar.png"
      }
    smeNameClick(sUuid) {
        let url = 'sme/' + sUuid
        window.open(url, '_blank')
      }
    close() {
        this.dialogRef.close()
    }
}