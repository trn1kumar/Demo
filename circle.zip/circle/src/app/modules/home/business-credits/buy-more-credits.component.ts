import { Inject, Component, OnInit } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { JwtTokenService } from "src/app/core/services/token/jwt-token.service";
import { PricingService } from "src/app/core/services/pricing/pricing.service";
import { AddCredits } from "src/app/core/models/pricing";
import { FormControl, Validators } from "@angular/forms";

@Component({
    template: `
    <div *ngIf="closeButton">
    <a href matTooltip="Close" onclick="return false" (click)="close()" 
    style="float:right ; color : rgb(43, 43, 192)">
      <mat-icon>close</mat-icon>
    </a>
    </div>

    <div *ngIf="buyCredits" class="text-center" style="margin-bottom:20px">
        <span style="font-size:15px">Credits </span> 
        <input style="width:25%" [formControl]="creditsControl" type="number">
    </div>

    <div class="text-center" *ngIf="buyNowButton">
    <button mat-stroked-button (click)="buy()" color="primary">BUY NOW</button>
    <span style="margin-right:20px"></span>
    <button mat-stroked-button (click)="close()" color="primary">Cancel</button>
    </div>

    <div class="text-center" *ngIf="okButton">
        <img src="../../../assets/smeface/check.gif" height="200" weight="00">
        <div>
        <button mat-stroked-button (click)="ok()" color="primary">Ok</button>
        </div>
    </div>

    `,
    
})
export class BuyMoreCreditsComponent implements OnInit{

    buyNowButton: boolean = true
    okButton: boolean
    closeButton: boolean = true
    buyCredits:boolean = true
    creditsControl = new FormControl(1,[Validators.min(1)]);

    constructor(private dialogRef: MatDialogRef<BuyMoreCreditsComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any, private pricingService: PricingService,
        public jwtToken: JwtTokenService) {
    }

    ngOnInit(): void {
        this.creditsControl.valueChanges.subscribe(
          value => {
            if (value < 0) {
              this.creditsControl.setValue(1)
            }
          }
        )
    }

    buy(){

        let object = new AddCredits()
        object.sUuid = atob(localStorage.getItem('sUuid'))
        object.userUUID = this.jwtToken.getUserId()
        object.type = this.data.type
        object.action = 'CREDIT'
        object.credits = this.creditsControl.value
        this.pricingService.updateCredits(object).subscribe(res =>{
            if(res.status == 201){
                this.buyNowButton = false
                this.okButton = true
                this.closeButton = false
                this.buyCredits = false
            }
        })

    }

    ok() {
        let status:boolean = true
        this.dialogRef.close({status:status})
    }

    close() {
        this.dialogRef.close()
    }

}