import { Component, OnInit } from '@angular/core';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { TokenStorageService } from 'src/app/core/services/token/token-storage.service';
import { PricingService } from 'src/app/core/services/pricing/pricing.service';
import { Observable } from 'rxjs';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';
import { FileSizeFormatService } from 'src/app/core/services/extra/file-size-format.service';
import { BuyMoreCreditsComponent } from './buy-more-credits.component';

@Component({
  selector: 'app-business-credits',
  templateUrl: './business-credits.component.html',
  styleUrls: ['./business-credits.component.css']
})
export class BusinessCreditsComponent implements OnInit {
  userPricing:Observable<any>
  buyNowDialogRef: MatDialogRef<BuyMoreCreditsComponent>;

  constructor(private pricingService:PricingService, private dialog: MatDialog,
    public format:FileSizeFormatService) { }

  ngOnInit() {
    this.getUserPricingDetails()
  }

  getUserPricingDetails(){
   this.userPricing = this.pricingService.getUserPricingDetailsWithInitial(atob(localStorage.getItem('sUuid')))
  }
  buyMoreCredits(type: string){
    this.openDialog(type)
  }

  openDialog(type:string){
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true
    dialogConfig.autoFocus = false;
    dialogConfig.width = '500px';
    dialogConfig.data = {type:type}

    this.buyNowDialogRef = this.dialog.open(BuyMoreCreditsComponent, dialogConfig);
    this.buyNowDialogRef.afterClosed().subscribe(
      res => {
        if(res){
          if(res.status){
            this.getUserPricingDetails()
          }
        }
      })
  }


}
