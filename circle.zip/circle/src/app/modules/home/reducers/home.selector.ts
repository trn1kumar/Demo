import { createSelector } from "@ngrx/store";
import { HomeState, CheckCartState } from "./home.state";
import { AppState } from "../../../app.reducers";

export function getHomeState(state: AppState): HomeState {
    return state.homestate
}
export function fetchTotalCartCount(state: HomeState) {
    return state.totalCartCount
}

export function getCheckCartState(state: AppState): CheckCartState {
    return state.checkCartState
}
export function checkCartState(state:CheckCartState){
   return state.status
}

export const getCartState = createSelector(getCheckCartState,checkCartState)
export const getTotalCartCount = createSelector(getHomeState, fetchTotalCartCount)
