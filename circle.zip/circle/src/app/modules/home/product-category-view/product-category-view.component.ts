import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { HomePageService } from 'src/app/core/services/home-page/home-page.service';

@Component({
  selector: 'app-product-category-view',
  templateUrl: './product-category-view.component.html',
  styleUrls: ['./product-category-view.component.css']
})
export class ProductCategoryViewComponent implements OnInit {

  productCategories:Observable<any>
  constructor(private homePageService:HomePageService) { }

  ngOnInit() {
    this.productCategories = this.homePageService.getProductAllCategories();
  }

}
