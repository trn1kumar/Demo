import { Component, OnInit, Input } from '@angular/core';
import { NguCarousel } from '@ngu/carousel';
import { Observable } from 'rxjs';
import { SME } from 'src/app/core/models/sme';
import { HomePageService } from 'src/app/core/services/home-page/home-page.service';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { TokenStorageService } from 'src/app/core/services/token/token-storage.service';
import { BusinessCircleService } from 'src/app/core/services/circle/business-circle.service';
import { SnackBarConfig } from 'src/app/core/services/extra/snackbar.config';
import { MatSnackBar } from '@angular/material';
import { RestURL } from 'src/app/core/models/rest-api-url';
import { BusinessCircle, SendRequest } from 'src/app/core/models/business-circle';
@Component({
  selector: 'app-home-sme-list',
  templateUrl: './home-sme-list.component.html',
  styleUrls: ['./home-sme-list.component.css']
})
export class HomeSmeListComponent implements OnInit {

  carousel: NguCarousel
  @Input()
  smes: Observable<SME[]>
  smeNames: string[] = []
  isSme=false;
  isDisableId:string;

  constructor(private homePageService: HomePageService, private jwtTokenService: JwtTokenService,
    private tokenStorageService:TokenStorageService,
    private businessCircle:BusinessCircleService,
    private snackbarConfig : SnackBarConfig,private snackBar: MatSnackBar) { }

  ngOnInit() {
    this.carousel = {
      grid: { xs: 1, sm: 3, md: 4, lg: 6, all: 180 },
      speed: 600,
      interval: 3000,
      point: {
        visible: false
      },
      load: 2,
      easing: 'ease',
      animation: 'lazy',
      touch: true
    }
    this.isSme=!this.isSme;

  }






  getImage(imageName) {
    if (imageName != null) {
      return RestURL.contentServerUrl + (imageName);
    } else
      return "/assets/not-found/not-available.jpeg"
  }

  smeNameClick(sUuid) {
    let url = 'sme/' + sUuid
    window.open(url, '_blank')
  }

  onaddConnection(smeConnection,index)
  {
    let circle = new BusinessCircle()
    let sendRequest = new SendRequest()
    let sendReq=[];
    circle.sUuid = atob(localStorage.getItem("sUuid"))
    // console.log("platformSMEs",platformSMEs.smeId);
    // console.log("smeId",circle.sUuid);
    sendRequest.toSmeId=smeConnection.sUuid;
    // console.log("sendRequestId",sendRequest.toSmeId);
    sendReq.push(sendRequest);
    circle.sendRequests=sendReq;
    // console.log(circle);
    
    this.businessCircle.addBusinessRequest(circle).subscribe(
      response=>
      {
        this.isDisableId=smeConnection.sUuid;
        this.snackBar.open('Invitation Sent to '  +smeConnection.smeName,'Ok',this.snackbarConfig.getSnackBarConfig());
        setTimeout(function(){
        window.location.reload();
     }, 50);
        
      },
    )
  }
}
