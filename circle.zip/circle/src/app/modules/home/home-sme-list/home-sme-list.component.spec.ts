import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeSmeListComponent } from './home-sme-list.component';

describe('HomeSmeListComponent', () => {
  let component: HomeSmeListComponent;
  let fixture: ComponentFixture<HomeSmeListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HomeSmeListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeSmeListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
