
/* Modules */
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeRoutingModule } from './home-routing.module';


import { NguCarouselModule } from '@ngu/carousel'

/* Components */
import { HomeComponent } from './home/home.component';
import { HomeSliderComponent } from './home-slider/home-slider.component';
import { HomeProductListComponent } from './home-product-list/home-product-list.component';
import { HomeSmeListComponent } from './home-sme-list/home-sme-list.component';
import { HomeRoutesComponent } from './home-routes.component';
import { SearchResultComponent } from './search-result/search-result.component';
import { SearchResultProductsComponent } from './search-result/search-result-products/search-result-products.component';
import { SearchResultCategoryComponent } from './search-result/search-result-category/search-result-category.component';
import { SearchResultFilterComponent } from './search-result/search-result-filter/search-result-filter.component';
import { HomeActions } from './actions/home.actions';
import { HomeServicesListComponent } from './home-services-list/home-services-list.component';
import { SmefacePricingComponent } from './smeface-pricing/smeface-pricing.component';
import { BuyNowDialogComponent } from './smeface-pricing/buy-now-dialog.component';
import { LayoutModule } from 'src/app/layout/users/smeface/layout.module';
import { SharedModule } from '../shared/shared.module';
import { BusinessCreditsComponent } from './business-credits/business-credits.component';
import { ProductCategoryViewComponent } from './product-category-view/product-category-view.component';
import { ServiceCategoryViewComponent } from './service-category-view/service-category-view.component';
import { BuyMoreCreditsComponent } from './business-credits/buy-more-credits.component';


@NgModule({
  imports: [
    CommonModule,
    HomeRoutingModule,
    LayoutModule,
    SharedModule,
    NguCarouselModule
  ],
  declarations: [
    HomeComponent, 
    HomeSliderComponent, 
    HomeProductListComponent, 
    HomeSmeListComponent, 
    HomeRoutesComponent, 
    SearchResultComponent, 
    SearchResultProductsComponent, 
    SearchResultCategoryComponent, 
    SearchResultFilterComponent, 
    HomeServicesListComponent, 
    SmefacePricingComponent,
    BuyNowDialogComponent,
    BusinessCreditsComponent ,
    ProductCategoryViewComponent,
    ServiceCategoryViewComponent,
    BuyMoreCreditsComponent
  ],
  providers:[
    HomeActions
  ],
  entryComponents:[
    BuyNowDialogComponent,
    BuyMoreCreditsComponent
  ]
})
export class HomeModule { }
