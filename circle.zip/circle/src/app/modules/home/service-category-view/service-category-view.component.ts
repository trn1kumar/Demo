import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { HomePageService } from 'src/app/core/services/home-page/home-page.service';

@Component({
  selector: 'app-service-category-view',
  templateUrl: './service-category-view.component.html',
  styleUrls: ['./service-category-view.component.css']
})
export class ServiceCategoryViewComponent implements OnInit {

  serviceCategories: Observable<any>

  constructor(private homePageService:HomePageService) { }

  ngOnInit() {
    this.serviceCategories = this.homePageService.getServiceAllCategories()
  }

}
