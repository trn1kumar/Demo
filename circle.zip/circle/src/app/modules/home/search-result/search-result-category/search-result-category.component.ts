import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-result-category',
  templateUrl: './search-result-category.component.html',
  styleUrls: ['./search-result-category.component.css']
})
export class SearchResultCategoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
