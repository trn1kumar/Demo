import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription, Observable } from 'rxjs';

import { SearchRequest } from 'src/app/core/models/search';
import { Product } from 'src/app/core/models/product';
import { ProductService } from 'src/app/core/services/product/product.service';

@Component({
  selector: 'app-search-result',
  templateUrl: './search-result.component.html',
  styleUrls: ['./search-result.component.css']
})
export class SearchResultComponent implements OnInit {

  products : Array<Product>

  showSpinner : boolean = true
  productsNotFound : boolean = false
  constructor(private route : ActivatedRoute , private productService : ProductService) { }

  ngOnInit() {
    
    if(this.route.snapshot.queryParams['q'] == undefined || this.route.snapshot.queryParams['q'] == ''){
      this.productService.products().subscribe(
        res => {
          this.showSpinner = false
          this.products = res
        },
        err =>{
          this.showSpinner = false
          this.productsNotFound = true
        }
      )
    }
    else{
      let search  = new SearchRequest()
      search.searchEntity = this.route.snapshot.queryParams['entity']
      search.searchText = this.route.snapshot.queryParams['q']

      this.productService.searchText(search).subscribe(
        res => {
          this.showSpinner = false
          this.products = res.body
        },
        err => {
          this.showSpinner = false
          this.productsNotFound = true
        }
      )
    }
    
  }
  

}
