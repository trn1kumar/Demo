import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-result-filter',
  templateUrl: './search-result-filter.component.html',
  styleUrls: ['./search-result-filter.component.css']
})
export class SearchResultFilterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
