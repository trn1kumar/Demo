import { Component, OnInit } from '@angular/core';
import { PricingService } from 'src/app/core/services/pricing/pricing.service';
import { Observable } from 'rxjs';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { TokenStorageService } from 'src/app/core/services/token/token-storage.service';
import { MatDailogService } from 'src/app/core/services/extra/matdialog.config';
import { PricingRequest } from 'src/app/core/models/pricing';
import { MatDialog, MatDialogRef, MatDialogConfig } from '@angular/material';
import { BuyNowDialogComponent } from './buy-now-dialog.component';
import { FileSizeFormatService } from 'src/app/core/services/extra/file-size-format.service';

@Component({
  selector: 'app-smeface-pricing',
  templateUrl: './smeface-pricing.component.html',
  styleUrls: ['./smeface-pricing.component.css']
})
export class SmefacePricingComponent implements OnInit {

  pricingDetails: Observable<any>
  planName: Observable<string>
  userPricingDetails: any
  buyNowDialogRef: MatDialogRef<BuyNowDialogComponent>;

  constructor(private pricingService: PricingService, public jwtToken: JwtTokenService,
    public token: TokenStorageService, private matDialogService: MatDailogService, private dialog: MatDialog,
    public format:FileSizeFormatService) { }

  ngOnInit() {
    this.pricingDetails = this.pricingService.getPricingDetails()
    if (this.token.isLoggedIn() && !this.jwtToken.getUserType()) {
      this.getUserPricingDetails()
    }
  }

  getUserPricingDetails(){
    this.pricingService.getUserPricingDetails(atob(localStorage.getItem('sUuid'))).subscribe(
      res => {
        this.userPricingDetails = res
        this.planName = res.planName
      }
    )
  }

  withoutLogin() {
    this.matDialogService.openLoginDialog();
  }

  openBuyNowDialog(plan: string) {
    let pricingData: any
    this.pricingDetails.subscribe(res => {
      if (plan === 'SMALL') {
        pricingData = res.small
      } else if (plan === 'MEDIUM') {
        pricingData = res.medium
      } else {
        pricingData = res.big
      }
    })

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true
    dialogConfig.autoFocus = false;
    dialogConfig.width = '800px';

    dialogConfig.data = {
      userData: this.userPricingDetails,
      pricingData: pricingData,
      plan: plan
    }

    this.buyNowDialogRef = this.dialog.open(BuyNowDialogComponent, dialogConfig);
    this.buyNowDialogRef.afterClosed().subscribe(
      res => {
        if (res != undefined) {
          this.getUserPricingDetails()
        }
      })
  }

}
