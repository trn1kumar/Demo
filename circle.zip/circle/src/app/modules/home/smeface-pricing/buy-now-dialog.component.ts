import { Component, Inject } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { PricingService } from "src/app/core/services/pricing/pricing.service";
import { JwtTokenService } from "src/app/core/services/token/jwt-token.service";
import { PricingRequest } from "src/app/core/models/pricing";
import { FileSizeFormatService } from "src/app/core/services/extra/file-size-format.service";

@Component({
    template: `

    <div *ngIf="closeButton">
    <a href matTooltip="Close" onclick="return false" (click)="close()" style="float:right ; color : rgb(43, 43, 192)">
      <mat-icon>close</mat-icon>
    </a>
    </div>

    <div class="table-responsive table-borderless text-center" *ngIf="buyNowButton">
<table class="table">
<thead>
  <tr>
    <th></th>
    <th>Remaining Credits</th>
    <th></th>
    <th>{{data.pricingData.planName}} credits</th>
    <th></th>
    <th>Total</th>
  </tr>
</thead>
<tbody>
    <tr>
        <td><b>Product/Services Listings</b></td>
        <td>{{data.userData.listings}}</td>
        <td>+</td>
        <td>{{data.pricingData.listings}}</td>
        <td></td>
        <td>{{data.userData.listings + data.pricingData.listings}}</td>
    </tr>
    <tr>
        <td><b>No. of Connections</b></td>
        <td>{{data.userData.connections}}</td>
        <td>+</td>
        <td>{{data.pricingData.connections}}</td>
        <td></td>
        <td>{{data.userData.connections + data.pricingData.connections}}</td>
    </tr>
    <tr>
        <td><b>No. of Business Post</b></td>
        <td>{{data.userData.businessPosts}}</td>
        <td>+</td>
        <td>{{data.pricingData.businessPosts}}</td>
        <td></td>
        <td>{{data.userData.businessPosts + data.pricingData.businessPosts}}</td>
    </tr>
    <tr>
        <td><b>No. of Job Postings</b></td>
        <td>{{data.userData.jobPostings}}</td>
        <td>+</td>
        <td>{{data.pricingData.jobPostings}}</td>
        <td></td>
        <td>{{data.userData.jobPostings + data.pricingData.jobPostings}}</td>
    </tr>
    <tr>
        <td><b>No. of Business Interest Read</b></td>
        <td>{{data.userData.biReadCredits}}</td>
        <td>+</td>
        <td>{{data.pricingData.biReadCredits}}</td>
        <td></td>
        <td>{{data.userData.biReadCredits + data.pricingData.biReadCredits}}</td>
    </tr>
    <tr>
        <td><b>Image Storage Size</b></td>
        <td>{{format.formatSizeUnits(data.userData.imageStorageSize)}}</td>
        <td>+</td>
        <td>{{format.formatSizeUnits(data.pricingData.imageStorageSize)}}</td>
        <td></td>
        <td>{{format.formatSizeUnits(data.userData.imageStorageSize + data.pricingData.imageStorageSize)}}</td>
    </tr>
</tbody>
</table>
</div>

    <div class="text-center" *ngIf="buyNowButton">
    <button mat-stroked-button (click)="buyNow()" color="primary">BUY NOW</button>
    <span style="margin-right:20px"></span>
    <button mat-stroked-button (click)="close()" color="primary">Cancel</button>
    </div>

    <div class="text-center" *ngIf="okButton">
        <img src="../../../assets/smeface/check.gif" height="300" weight="300">
        <div>
        <button mat-stroked-button (click)="ok()" color="primary">Ok</button>
        </div>
    </div>

    `
})
export class BuyNowDialogComponent {

    buyNowButton: boolean = true
    okButton: boolean
    planName: string
    closeButton: boolean = true

    constructor(private dialogRef: MatDialogRef<BuyNowDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any, private pricingService: PricingService,
        public jwtToken: JwtTokenService,public format:FileSizeFormatService) {
            // console.log(data)
    }

    buyNow() {
        this.buyNowButton = false
        this.okButton = true
        this.closeButton = false
        let request = new PricingRequest()
        request.sUuid = atob(localStorage.getItem('sUuid'))
        request.userUUID = this.jwtToken.getUserId()
        request.plan = this.data.plan
        this.pricingService.upgradePlan(request).subscribe(
            res => {
                this.planName = res.planName
            }
        )
    }

    doSum(num1: number, num2: number) {
        return num1 + num2
    }

    ok() {
        this.dialogRef.close(this.planName)
    }

    close() {
        this.dialogRef.close()
    }
}

