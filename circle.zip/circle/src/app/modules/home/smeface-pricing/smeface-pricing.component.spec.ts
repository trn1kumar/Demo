import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SmefacePricingComponent } from './smeface-pricing.component';

describe('SmefacePricingComponent', () => {
  let component: SmefacePricingComponent;
  let fixture: ComponentFixture<SmefacePricingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SmefacePricingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SmefacePricingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
