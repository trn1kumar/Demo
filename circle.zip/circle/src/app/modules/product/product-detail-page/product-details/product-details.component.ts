import { Component, OnInit, Input } from '@angular/core';
import { Product } from 'src/app/core/models/product';
import { Image } from 'src/app/core/models/image';


@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  @Input()
  product : Product

  images : Image[]
  selectedImage : Image

  constructor() { }

  ngOnInit() {
    this.images = this.product.images
    this.selectedImage = this.product.images[0]
  }

}
