import { Component, OnInit, Input } from '@angular/core';

import { FormControl } from '@angular/forms';
import { Store } from '@ngrx/store';
import * as fromRoot from '../../../../app.reducers'
import { Product } from 'src/app/core/models/product';
import { TokenStorageService } from 'src/app/core/services/token/token-storage.service';
import { MatDailogService } from 'src/app/core/services/extra/matdialog.config';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { BusinessCartService } from 'src/app/core/services/cart/business-cart.service';
import { MatSnackBar } from '@angular/material';
import { SnackBarConfig } from 'src/app/core/services/extra/snackbar.config';
import { CartItem } from 'src/app/core/models/cart-item';
import { BusinessInterest } from 'src/app/core/models/business-interest';

const provider = 'PRODUCT'
@Component({
  selector: 'app-product-business-interest',
  templateUrl: './product-business-interest.component.html',
  styleUrls: ['./product-business-interest.component.css']
})
export class ProductBusinessInterestComponent implements OnInit {

  @Input()
  product: Product
  event: any
  quantityControl = new FormControl(1);
  disabled = false;
  constructor(private token: TokenStorageService, private dialogService: MatDailogService, private jwtToken: JwtTokenService, private cartService: BusinessCartService, private snackBar: MatSnackBar,
    private snackBarConfig: SnackBarConfig, private store: Store<fromRoot.AppState>) { }

  ngOnInit() {
    this.quantityControl.setValue(this.product.minOrderQty)
    this.quantityControl.valueChanges.subscribe(
      value => {
        if (value > 1) {
          this.disabled = false
        }
        if (value < this.product.minOrderQty) {
          this.quantityControl.setValue(this.product.minOrderQty)
          this.disabled = true
        }
      }
    )
  }


  businessInterest(uuid) {
    if (!this.token.isLoggedIn()) {
      const dialogRef = this.dialogService.openLoginDialog()
      dialogRef.afterClosed().subscribe(
        res => {
          if (this.token.isLoggedIn()) {
            this.generateBusinessInterest(uuid)
          }
        }
      )
    } else {
      this.generateBusinessInterest(uuid)
    }
  }

  generateBusinessInterest(uuid) {

    let cartItem = new CartItem()
    cartItem.businessInterestQuantity = this.quantityControl.value
    cartItem.businessInterestUUID = uuid
    cartItem.provider = provider

    let businessInterest = new BusinessInterest()
    businessInterest.cartItem.push(cartItem)
    businessInterest.userUuid = this.jwtToken.getUserId()

    console.log("BI : ", businessInterest)

    this.cartService.generateBI(businessInterest).subscribe(
      res => {
        this.snackBar.open('Buisness Interest Generated', '', this.snackBarConfig.getSnackBarConfig())
        this.store.dispatch({ type: 'Increment_Total_Cart_Count' })
      },
      err => {
        if (err.error.errorCode == 208) {
          this.snackBar.open('Product already in cart', '', this.snackBarConfig.getSnackBarConfig())
        }
      }
    )
  }

  addQuantity() {
    let quantity = this.quantityControl.value
    if (quantity == 10000) {
      return false
    }
    this.quantityControl.setValue(++quantity)
  }

  minusQuantity() {
    let quantity = this.quantityControl.value
    this.quantityControl.setValue(--quantity)
  }

  onlyNumber(evt) {

    evt = (evt) ? evt : window.event;
    this.event = evt
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
}
