import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductBusinessInterestComponent } from './product-business-interest.component';

describe('ProductBusinessInterestComponent', () => {
  let component: ProductBusinessInterestComponent;
  let fixture: ComponentFixture<ProductBusinessInterestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductBusinessInterestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductBusinessInterestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
