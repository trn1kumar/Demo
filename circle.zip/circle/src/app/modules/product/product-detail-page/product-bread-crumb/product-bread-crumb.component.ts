import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-product-bread-crumb',
  templateUrl: './product-bread-crumb.component.html',
  styleUrls: ['./product-bread-crumb.component.css']
})
export class ProductBreadCrumbComponent implements OnInit {

  @Input()
  breadcrumb: any

  constructor() { }

  ngOnInit() {
  }

}
