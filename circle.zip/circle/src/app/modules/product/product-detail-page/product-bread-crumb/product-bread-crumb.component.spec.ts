import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductBreadCrumbComponent } from './product-bread-crumb.component';

describe('ProductBreadCrumbComponent', () => {
  let component: ProductBreadCrumbComponent;
  let fixture: ComponentFixture<ProductBreadCrumbComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductBreadCrumbComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductBreadCrumbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
