import { Component, OnInit, Input } from '@angular/core';
import { Product } from 'src/app/core/models/product';

@Component({
  selector: 'app-product-description',
  templateUrl: './product-description.component.html',
  styleUrls: ['./product-description.component.css']
})
export class ProductDescriptionComponent implements OnInit {

  @Input()
  product : Product
  specifications: Map<string,string>

  constructor() { }

  ngOnInit() {
    if(this.product.specifications != null){
      this.specifications = this.product.specifications
    }
  }

  smeNameClick(sUuid){
    let url =  'sme/' + sUuid
    window.open(url,'_blank')
  }

  getMapValue(map) {
    return Array.from(Object.entries(map))
  }
}
