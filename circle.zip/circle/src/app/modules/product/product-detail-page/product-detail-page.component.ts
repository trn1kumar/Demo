import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { ProductService } from 'src/app/core/services/product/product.service';
import { Product } from 'src/app/core/models/product';


@Component({
  selector: 'app-product-detail-page',
  templateUrl: './product-detail-page.component.html',
  styleUrls: ['./product-detail-page.component.css']
})
export class ProductDetailPageComponent implements OnInit, OnDestroy {
  similarProduct : Array<Product>;
  product: Product = null;
  subcription$: Subscription

  proudctUuid : any;
  showSpinner : boolean = true
  constructor(private route : ActivatedRoute , private productService : ProductService) { 
   
    this.subcription$ = this.route.params.subscribe(
     params =>{
      this.proudctUuid =  params['uuid']
      this.productService.productByUuid(this.proudctUuid).subscribe(
        res => {
          this.showSpinner = false  
          this.product = res
        }
      )
     }
   )
  }

  ngOnInit() {
  }

  ngOnDestroy(): void {
    this.subcription$.unsubscribe()
  }
  
}
