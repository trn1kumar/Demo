import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductRoutingModule } from './product-routing.module';
import { ProductDetailPageComponent } from './product-detail-page/product-detail-page.component';
import { SharedModule } from '../shared/shared.module';
import { ProductDetailsComponent } from './product-detail-page/product-details/product-details.component';
import { ProductImagesComponent } from './product-detail-page/product-images/product-images.component';
import { ProductDescriptionComponent } from './product-detail-page/product-description/product-description.component';
import { ProductReviewComponent } from './product-detail-page/product-review/product-review.component';
import { ProductBusinessInterestComponent } from './product-detail-page/product-business-interest/product-business-interest.component';

import { ProductBreadCrumbComponent } from './product-detail-page/product-bread-crumb/product-bread-crumb.component';
import { NguCarouselModule } from '@ngu/carousel';
import { ProductCategoryComponent } from './product-category/product-category.component';
import { ProductsFilterComponent } from './product-category/products-filter/products-filter.component';
import { ProductsDisplayComponent } from './product-category/products-display/products-display.component';
import { ProductsCategorySliderComponent } from './product-category/products-display/products-category-slider/products-category-slider.component';
import { ProductsBreadcrumbComponent } from './product-category/products-display/products-breadcrumb/products-breadcrumb.component';
import { ProductsComponent } from './product-category/products-display/products/products.component';
import { SimilarProductComponent } from './product-detail-page/similar-product/similar-product.component';
import { Ng5SliderModule } from 'ng5-slider';
import { LayoutModule } from 'src/app/layout/users/smeface/layout.module';
@NgModule({
  imports: [
    CommonModule,
    ProductRoutingModule,
    SharedModule,
    LayoutModule,
    NguCarouselModule,
    Ng5SliderModule
  ],
  declarations: [
    ProductDetailPageComponent, 
    ProductDetailsComponent, 
    ProductImagesComponent, 
    ProductDescriptionComponent, 
    ProductReviewComponent,  
    ProductBusinessInterestComponent, 
    ProductBreadCrumbComponent, ProductCategoryComponent, ProductsFilterComponent, ProductsDisplayComponent, ProductsCategorySliderComponent, ProductsBreadcrumbComponent, ProductsComponent, SimilarProductComponent, 
  ]
})
export class ProductModule { }
