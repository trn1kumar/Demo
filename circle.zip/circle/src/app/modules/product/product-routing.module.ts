import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductDetailPageComponent } from './product-detail-page/product-detail-page.component';
import { ProductCategoryComponent } from './product-category/product-category.component';

const routes: Routes = [
  { path:':productName/p/:uuid' , component:ProductDetailPageComponent},
  { path:':category' , component:ProductCategoryComponent},
  { path:':category/:subcategory' , component:ProductCategoryComponent},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductRoutingModule { }
