import { Component, OnInit, Input } from '@angular/core';
import { NguCarousel } from '@ngu/carousel';
import { RestURL } from 'src/app/core/models/rest-api-url';

@Component({
  selector: 'app-products-category-slider',
  templateUrl: './products-category-slider.component.html',
  styleUrls: ['./products-category-slider.component.css']
})
export class ProductsCategorySliderComponent implements OnInit {

  @Input()
  productCategory: any
  
  carousel: NguCarousel
  constructor() { }

  ngOnInit() {
    this.carousel = {
      grid: { xs: 1, sm: 3, md: 4, lg: 6, all: 150 },
      speed: 600,
      interval: 3000,
      point: {
        visible: false
      },
      load: 2,
      easing: 'ease',
      animation: 'lazy',
      touch: true
    }
  }
  getImage(result){
    if(result != null){
      return RestURL.contentServerUrl+(result.fileLocation);
    }else
    return "/assets/not-found/not-available.jpeg"
  }

}
