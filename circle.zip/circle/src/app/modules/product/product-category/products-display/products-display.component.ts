import { Component, OnInit, Input } from '@angular/core';
import { ProductCategoryResponse } from 'src/app/core/models/product';

@Component({
  selector: 'app-products-display',
  templateUrl: './products-display.component.html',
  styleUrls: ['./products-display.component.css']
})
export class ProductsDisplayComponent implements OnInit {

  @Input()
  products: ProductCategoryResponse

  constructor() { }

  ngOnInit() {
  }

}
