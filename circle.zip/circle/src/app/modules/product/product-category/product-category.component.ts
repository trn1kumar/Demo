import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { ProductCategoryResponse } from 'src/app/core/models/product';
import { ProductService } from 'src/app/core/services/product/product.service';

@Component({
  selector: 'app-product-category',
  templateUrl: './product-category.component.html',
  styleUrls: ['./product-category.component.css']
})
export class ProductCategoryComponent implements OnInit {

  products$: ProductCategoryResponse
  subscription$: Subscription

  constructor(private productService: ProductService, private router: Router) {
    this.subscription$ = router.events
      .pipe(filter(e => e instanceof NavigationEnd))
      .subscribe((e: NavigationEnd) => {
        this.products(e.url)
      });
  }

  ngOnInit() {
  }

  products(url: string) {
    this.productService.productByURL(url).subscribe(
      res => {
        this.products$ = res
      }
    )
  }
  ngOnDestroy(): void {
    this.subscription$.unsubscribe()
  }
}
