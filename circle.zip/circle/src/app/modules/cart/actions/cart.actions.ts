import { Injectable } from "@angular/core";

@Injectable()
export class CartActions {
    static Store_Sent_Count = 'Store_Sent_Count'
    static Store_Received_Count = 'Store_Received_Count'
    static Decrement_Sent_Count = 'Decrement_Sent_Count'
    static Decrement_Received_Count = 'Decrement_Received_Count'

    storeSentCount(sentCount: number) {
        return { type: CartActions.Store_Sent_Count, payload: sentCount }
    }
    storeReceived(receivedCount: number) {
        return { type: CartActions.Store_Received_Count, payload: receivedCount }
    }
    decrementSentCount() {
        return { type: CartActions.Decrement_Sent_Count }
    }
    decrementReceivedCount() {
        return { type: CartActions.Decrement_Received_Count }
    }
}