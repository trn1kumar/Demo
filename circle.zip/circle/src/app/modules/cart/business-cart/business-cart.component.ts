import { Component, OnInit } from '@angular/core';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { Router } from '@angular/router';
import * as fromCart from '../reducers'
import { Store, select } from '@ngrx/store';
@Component({
  selector: 'app-business-cart',
  templateUrl: './business-cart.component.html',
  styleUrls: ['./business-cart.component.css'],
})
export class BusinessCartComponent implements OnInit {

  sentCount : number
  receiveCount : number

  constructor(public jwtToken : JwtTokenService,private router:Router,
    private store: Store<fromCart.BusinessCartState>) { }

  ngOnInit() {
    this.store.pipe(select(fromCart.getSentCount)).subscribe(
      res => {
        this.sentCount=+res
      }
    )
    this.store.pipe(select(fromCart.getReceivedCount)).subscribe(
      res => {
        this.receiveCount=+res
      }
    )
    this.router.navigate(['cart','received'])
  }

}
