import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SmeCartDisplayComponent } from './sme-cart-display.component';

describe('SmeCartDisplayComponent', () => {
  let component: SmeCartDisplayComponent;
  let fixture: ComponentFixture<SmeCartDisplayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SmeCartDisplayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SmeCartDisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
