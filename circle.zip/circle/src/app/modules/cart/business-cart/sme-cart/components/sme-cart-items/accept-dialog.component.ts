import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { FormControl } from '@angular/forms';
import { BusinessCartService } from 'src/app/core/services/cart/business-cart.service';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { SnackBarConfig } from 'src/app/core/services/extra/snackbar.config';

@Component({
  template: `

    <div class="text-center">

    <mat-icon  style="font-size:80px;color:rgb(166, 166, 166);margin-right:60px;">attach_file</mat-icon>

    <p></p>

    <mat-dialog-content>
      <input type="file" #fileInput (change)="getFileDetails($event)" required style="margin-left:55px;">
      <br>
      <br>
      <span>
      <b>OR</b>
      </span>
      <mat-form-field class="example-full-width">
        <input matInput placeholder="Write a message" [formControl]="quotationMessage" length=1000 required>
      </mat-form-field>
      <div *ngIf="showError">
        <span style="color:red">please select any</span>
      </div>
    </mat-dialog-content>

    <br>

    <button mat-stroked-button (click)="send()" color="primary" style="margin-right:30px">Send Quotation</button>
    <button mat-stroked-button (click)="onClickCancle()" color="primary">Cancel</button>

    </div>
  `,
  styles:[
    `.example-full-width {
      width: 100%;
    }`
  ]
})
export class AcceptDialogComponent {

  myFiles: string[] = [];
  showError: boolean = false
  quotationMessage= new FormControl(null)

  
  constructor(private dialogRef: MatDialogRef<AcceptDialogComponent>, private cartService: BusinessCartService,
    private jwtToken: JwtTokenService, @Inject(MAT_DIALOG_DATA) public data: any,
    private snackBar: MatSnackBar, private snackBarConfig: SnackBarConfig) {
  }

  send(){
    this.showError = false
    if(this.getFormData().getAll('files').length > 0){
      this.sendQuotation();
    }else if(this.quotationMessage.value != null){
      this.sendQuotation()
    }else{
      this.showError = true
    }
  }

  sendQuotation(){
  
    let formData = this.getFormData()
    let quotation = new Quotation()
    quotation.uuid = this.data.receiveCartItemUuid
    quotation.messageCenter = {message :this.quotationMessage.value}

    formData.append('smeActionData', JSON.stringify(quotation))
    console.log(formData.get('smeActionData'))
    this.cartService.sendQuotation(formData).subscribe(
      res => {
        this.snackBar.open("Quotation sent successfully", '', this.snackBarConfig.getSnackBarConfig())
        this.dialogRef.close(true)
        window.location.reload()
      },
    )
  }

  onClickCancle() {
    this.dialogRef.close()
  }

  getFileDetails(e) {
    this.showError = false
    var count = this.myFiles.length

    for (let i = 0; i < count; i++) {
      this.myFiles.pop()
    }

    for (let i = 0; i < e.target.files.length; i++) {
      this.myFiles.push(e.target.files[i]);
    }
  }

  getFormData() {

    let formData: FormData = new FormData()

    for (let i = 0; i < this.myFiles.length; i++) {
      formData.append("files", this.myFiles[i]);
    }

    return formData
  }

}

export class Quotation {
  uuid: string;
  messageCenter:{
    message:string
  }
}