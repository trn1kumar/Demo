import { Component, OnInit, Input } from '@angular/core';
import * as $ from 'jquery';

const SENT = 'QUOTATION SENT'
const RECEIVED = 'RECEIVED'
const ORDERED = 'ORDERED'
const DELIVERED = 'DELIVERED'

@Component({
  selector: 'app-sme-cart-item-status',
  templateUrl: './sme-cart-item-status.component.html',
  styleUrls: ['./sme-cart-item-status.component.css']
})
export class SmeCartItemStatusComponent implements OnInit {

  @Input()
  status: string

  sent : boolean = false
  received : boolean = false
  ordered : boolean = false
  delivered : boolean = false

  constructor() { }

  ngOnInit() {
    this.checkStatus(this.status)
  }

  checkStatus(status: string) {
    if (status == SENT) {
      this.statusSent()
    }
    if (status == RECEIVED) {
      this.statusQuotation()
    }
    if (status == ORDERED) {
      this.statusOrdered()
    }
    if (status == DELIVERED) {
      this.statusDelivered()
    }
  }

  statusSent() {
    this.sent = true
  }

  statusQuotation() {
    this.received = true
  }

  statusOrdered() {
    this.ordered = true
  }

  statusDelivered() {
    this.delivered = true
  }
}
