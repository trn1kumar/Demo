import { Component, OnInit, Input } from '@angular/core';
import { PricingService } from 'src/app/core/services/pricing/pricing.service';
import { Received_BI } from 'src/app/core/models/receive-bi';

@Component({
  selector: 'app-sme-cart-display',
  templateUrl: './sme-cart-display.component.html',
  styleUrls: ['./sme-cart-display.component.css']
})
export class SmeCartDisplayComponent implements OnInit {

  @Input() receivedBI : Received_BI
  
  biReadCredits:number

  constructor(private pricingService:PricingService) { }

  ngOnInit() {
    this.pricingService.checkCredits(atob(localStorage.getItem('sUuid')),'BI_READ').subscribe(
      res=>{
        this.biReadCredits = res.credits
      }
    )
      
  }

  manageCredit(data){
    if(data == true){
      this.biReadCredits = this.biReadCredits + 1;
    }else if(data == false){
      this.biReadCredits = this.biReadCredits - 1;
    }
  }

}
