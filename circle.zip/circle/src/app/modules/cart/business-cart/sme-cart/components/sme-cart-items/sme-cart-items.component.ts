import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MatDialogConfig, MatDialogRef, MatDialog } from '@angular/material';
import { AcceptDialogComponent } from './accept-dialog.component';
import { DeleteDialogComponent } from './delete-dialog.component';
import { BusinessCartService } from 'src/app/core/services/cart/business-cart.service';
import { BuyReadCreditComponent } from './buy-read-credit.component';
import { Received_BI } from 'src/app/core/models/receive-bi';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { RestURL } from 'src/app/core/models/rest-api-url';

@Component({
  selector: 'app-sme-cart-items',
  templateUrl: './sme-cart-items.component.html',
  styleUrls: ['./sme-cart-items.component.css']
})
export class SmeCartItemsComponent implements OnInit {

  @Input()
  receivedBI: Array<Received_BI>

  @Input()
  biReadCredits: number

  @Output()
  manageCredit = new EventEmitter()

  acceptDialogRef: MatDialogRef<AcceptDialogComponent>;
  deleteDialogRef: MatDialogRef<DeleteDialogComponent>;
  buyCreditDialogRef: MatDialogRef<BuyReadCreditComponent>;

  constructor(private dialog: MatDialog, private jwtToken: JwtTokenService,
    private cartService: BusinessCartService) { }

  ngOnInit() {

  }

  onRejectDialog(receiveCartItemUuid: string) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';
    dialogConfig.data = receiveCartItemUuid

    this.deleteDialogRef = this.dialog.open(DeleteDialogComponent, dialogConfig);
  }

  onAcceptDialog(receiveCartItemUuid: string, index) {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';
    dialogConfig.data = { receiveCartItemUuid }

    this.acceptDialogRef = this.dialog.open(AcceptDialogComponent, dialogConfig);
    this.acceptDialogRef.afterClosed().subscribe(
      res => {
        if (res == true) {
          this.receivedBI[index]
        }
      }
    )
  }


  openBuyCreditDialog(uuid: string,index) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true
    dialogConfig.autoFocus = false;
    dialogConfig.width = '500px';

    this.buyCreditDialogRef = this.dialog.open(BuyReadCreditComponent, dialogConfig);
    this.buyCreditDialogRef.afterClosed().subscribe(
      res => {
        if (res == true) {
          this.manageCredit.emit(true)
          this.receivedBI[index].viewStatus = true
          this.getUserDetails(uuid,index)
        }
      }
    )
  }

  onViewStatus(uuid: string,index:number) {
    if (this.biReadCredits > 0) {
      this.receivedBI[index].spinner = true
      this.getUserDetails(uuid,index)
    } else {
      this.openBuyCreditDialog(uuid,index)
    }

  }

  getUserDetails(uuid: string,index:number) {
    let data:any={
      uuid:uuid,
      sUuid:atob(localStorage.getItem('sUuid')),
      userUUID:this.jwtToken.getUserId()
    }
    this.cartService.getUserDetails(data).subscribe(
      res => {
        this.receivedBI[index].userDetails = res;
        this.manageCredit.emit(false)
        this.receivedBI[index].spinner = false
      },
      err => {
        if(err.error.errorCode == 402){
          this.receivedBI[index].spinner = false
          this.openBuyCreditDialog(uuid,index)
          this.receivedBI[index].viewStatus = false
          this.manageCredit.emit(true)
        }
      }
    )
  }

  getImage(result) {
    if (result != null) {
      return RestURL.contentServerUrl + (result.fileLocation);
    } else
      return "/assets/not-found/not-available.jpeg"
  }

  productNameClick(productName, uuid) {
    let url = productName + '/p/' + uuid
    window.open(url, '_blank')
  }
  serviceNameClick(serviceName, uuid) {
    let url = 'services/' + serviceName + '/' + uuid
    window.open(url, '_blank')
  }
}
