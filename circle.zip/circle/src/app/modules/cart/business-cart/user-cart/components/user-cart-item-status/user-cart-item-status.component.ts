import { Component, OnInit, Input } from '@angular/core';

const SENT = 'SENT'
const RECEIVED = 'QUOTATION RECEIVED'
const ORDERED = 'ORDERED'
const DELIVERED = 'DELIVERED'

@Component({
  selector: 'app-user-cart-item-status',
  templateUrl: './user-cart-item-status.component.html',
  styleUrls: ['./user-cart-item-status.component.css']
})
export class UserCartItemStatusComponent implements OnInit {

  @Input()
  status: string;

  sent : boolean = false
  quotation : boolean = false
  ordered : boolean = false
  delivered : boolean = false

  constructor() { }

  ngOnInit() {
    this.checkStatus(this.status)
  }

  checkStatus(status : string){
    if(status == SENT){
      this.statusSent()
    }
    if(status == RECEIVED){
      this.statusQuotation()
    }
    if(status == ORDERED){
      this.statusOrdered()
    }
    if(status == DELIVERED){
      this.statusDelivered()
    }
  }

  statusSent(){
    this.sent = true
  }

  statusQuotation(){
    this.quotation = true
  }

  statusOrdered(){
    this.ordered = true
  }

  statusDelivered(){
    this.delivered= true
  }

}
