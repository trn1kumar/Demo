import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BusinessCartComponent } from './business-cart/business-cart.component';
import { UserCartComponent } from './business-cart/user-cart/user-cart.component';
import { SmeCartComponent } from './business-cart/sme-cart/sme-cart.component';
import { CartGuardService } from 'src/app/core/guards/cart-guard.service';

const routes: Routes = [
  { path: '' , component: BusinessCartComponent,
    children: [
      { path: 'sent' , component: UserCartComponent,canActivate:[CartGuardService]},
      { path: 'received' , component: SmeCartComponent,canActivate:[CartGuardService]},
    ]},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CartRoutingModule { }
