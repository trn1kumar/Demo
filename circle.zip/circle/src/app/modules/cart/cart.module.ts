
/* Modules */
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CartRoutingModule } from './cart-routing.module';
import { SharedModule } from '../shared/shared.module';

/* Components */
import { BusinessCartComponent } from './business-cart/business-cart.component';
import { UserCartComponent } from './business-cart/user-cart/user-cart.component';
import { SmeCartComponent } from './business-cart/sme-cart/sme-cart.component';
import { SmeCartItemsComponent } from './business-cart/sme-cart/components/sme-cart-items/sme-cart-items.component';
import { SmeCartItemStatusComponent } from './business-cart/sme-cart/components/sme-cart-item-status/sme-cart-item-status.component';
import { UserCartItemsComponent } from './business-cart/user-cart/components/user-cart-items/user-cart-items.component';
import { UserCartItemStatusComponent } from './business-cart/user-cart/components/user-cart-item-status/user-cart-item-status.component';
import { DeleteCartDialogComponent } from './business-cart/user-cart/components/user-cart-items/delete-cart-dialog.component';
import { AcceptDialogComponent } from './business-cart/sme-cart/components/sme-cart-items/accept-dialog.component';
import { DeleteDialogComponent } from './business-cart/sme-cart/components/sme-cart-items/delete-dialog.component';
import { SmeCartDisplayComponent } from './business-cart/sme-cart/components/sme-cart-display/sme-cart-display.component';
import { CartActions } from './actions/cart.actions';
import { StoreModule } from '@ngrx/store';
import { reducers } from './reducers';
import { UserCartDisplayComponent } from './business-cart/user-cart/components/user-cart-display/user-cart-display.component';
import { BuyReadCreditComponent } from './business-cart/sme-cart/components/sme-cart-items/buy-read-credit.component';
import { LayoutModule } from 'src/app/layout/users/smeface/layout.module';


@NgModule({
  imports: [
    CommonModule,
    CartRoutingModule,
    LayoutModule,
    SharedModule,
    StoreModule.forFeature('cart',reducers)
  ],
  declarations: [
    BusinessCartComponent,
    UserCartComponent,
    SmeCartComponent,
    SmeCartItemsComponent,
    SmeCartItemStatusComponent,
    UserCartItemsComponent,
    UserCartItemStatusComponent,
    DeleteCartDialogComponent,
    AcceptDialogComponent,
    DeleteDialogComponent,
    SmeCartDisplayComponent,
    UserCartDisplayComponent,
    BuyReadCreditComponent
  ],
  entryComponents :[
    DeleteCartDialogComponent,
    AcceptDialogComponent,
    DeleteDialogComponent,
    BuyReadCreditComponent
  ],
  providers:[
    CartActions
  ]
})
export class CartModule { 

}
