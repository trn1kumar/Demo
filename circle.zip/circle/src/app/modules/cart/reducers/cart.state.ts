export interface CartState {
    sentCount: number
    receivedCount: number
}