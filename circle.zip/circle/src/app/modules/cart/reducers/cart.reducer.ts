import { CartState } from "./cart.state";
import { CartActions } from "../actions/cart.actions";

export const Initial_State: CartState = {
    sentCount: 0,
    receivedCount: 0
}

export function cartReducer(lastState = Initial_State, { type, payload }: any): CartState {

    switch (type) {
        case CartActions.Decrement_Sent_Count:
            return { sentCount: lastState.sentCount - 1 , receivedCount:lastState.receivedCount}

        case CartActions.Decrement_Received_Count:
            return { sentCount: lastState.sentCount , receivedCount:lastState.receivedCount - 1}

        case CartActions.Store_Sent_Count:
            return { sentCount: lastState.sentCount = payload , receivedCount:lastState.receivedCount}

        case CartActions.Store_Received_Count:
            return { sentCount: lastState.sentCount , receivedCount:lastState.receivedCount = payload}

        default:
            return lastState
    }
}
