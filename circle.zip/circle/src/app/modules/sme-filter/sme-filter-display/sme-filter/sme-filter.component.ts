import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sme-filter',
  templateUrl: './sme-filter.component.html',
  styleUrls: ['./sme-filter.component.css']
})
export class SmeFilterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
