import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SmeFilterComponent } from './sme-filter.component';

describe('SmeFilterComponent', () => {
  let component: SmeFilterComponent;
  let fixture: ComponentFixture<SmeFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SmeFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SmeFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
