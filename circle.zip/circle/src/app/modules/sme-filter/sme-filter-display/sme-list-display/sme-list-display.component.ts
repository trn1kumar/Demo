import { Component, OnInit, Input } from '@angular/core';
import { SMECategoryDto } from 'src/app/core/models/sme-information';
import { RestURL } from 'src/app/core/models/rest-api-url';

@Component({
  selector: 'app-sme-list-display',
  templateUrl: './sme-list-display.component.html',
  styleUrls: ['./sme-list-display.component.css']
})
export class SmeListDisplayComponent implements OnInit {

  @Input()
  smeCategoryData:SMECategoryDto;

  constructor() { }

  ngOnInit() {
  }
  getImage(imageName) {
    if (imageName != null) {
      return RestURL.contentServerUrl + (imageName);
    } else
      return "/assets/not-found/not-available.jpeg"
  }

  smeNameClick(sUuid) {
    let url = 'sme/' + sUuid
    window.open(url, '_blank')
  }
}
