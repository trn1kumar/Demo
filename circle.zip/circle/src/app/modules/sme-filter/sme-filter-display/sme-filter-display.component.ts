import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { SmeInfoService } from 'src/app/core/services/sme-page/sme-info.service';
import { SMECategoryDto } from 'src/app/core/models/sme-information';

@Component({
  selector: 'app-sme-filter-display',
  templateUrl: './sme-filter-display.component.html',
  styleUrls: ['./sme-filter-display.component.css']
})
export class SmeFilterDisplayComponent implements OnInit {

  smeCategoryData:SMECategoryDto;
  
  subscription$ : Subscription

  constructor(private router:Router,private smeService:SmeInfoService) { 
    this.subscription$ = router.events
    .pipe(filter(e => e instanceof NavigationEnd))
    .subscribe((e: NavigationEnd) => {
      this.getData(e.url);
    });
  }

  ngOnInit() {
  }

  getData(url){
    console.log(url)
    this.smeService.smeByCategory(url).subscribe(res=>{
      this.smeCategoryData=res
    },err=>{
      console.log(err)
    })
  }

}
