import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GalleryPublishComponent } from './gallery-publish.component';

describe('GalleryPublishComponent', () => {
  let component: GalleryPublishComponent;
  let fixture: ComponentFixture<GalleryPublishComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GalleryPublishComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GalleryPublishComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
