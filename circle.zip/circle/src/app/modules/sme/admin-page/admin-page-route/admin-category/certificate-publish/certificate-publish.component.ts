import { Component, OnInit } from '@angular/core';
import { SMECertificate } from 'src/app/core/models/sme-certificates';
import { MatDialogRef, MatDialog, MatSnackBar, MatDialogConfig } from '@angular/material';
import { DeleteCertificateComponent } from './delete-certificate.component';
import { PublishData } from 'src/app/core/models/publish-data';
import { SmeHomePageService } from 'src/app/core/services/sme-page/sme-home-page.service';
import { PublishDataService } from 'src/app/core/services/publish-data/publish-data.service';
import { SnackBarConfig } from 'src/app/core/services/extra/snackbar.config';
import { RestURL } from 'src/app/core/models/rest-api-url';


@Component({
  selector: 'app-certificate-publish',
  templateUrl: './certificate-publish.component.html',
  styleUrls: ['./certificate-publish.component.css']
})
export class CertificatePublishComponent implements OnInit {

  smeCertificates: Array<SMECertificate>
  disablePublishButton:boolean=true;
  disableDeactiveButton:boolean=true;
  map = new Map<string, boolean>();
  sUuid: string
  selectedSize:any =0;
  status: string = 'active'
  status1: string = 'deactive'
  source:string ='certificates'
  publishCertificateButton:boolean=true
  deleteDialogRef : MatDialogRef<DeleteCertificateComponent>
  publishData = new Array<PublishData>();
  certificatesIds:string[]=[]
  constructor(private smeService: SmeHomePageService,private matDialog : MatDialog,private publishDataService:PublishDataService,private snackBar: MatSnackBar,private snackBarConfig: SnackBarConfig) { }

  ngOnInit() {
    this.sUuid = atob(localStorage.getItem('sUuid'))
    this.smeService.smeCertificates(this.sUuid, this.status).subscribe(
      res => {
        this.smeCertificates = res
        console.log(res)
      }
    )
  }
  getImage(result){
    if(result != null && result.length > 0){
      return RestURL.contentServerUrl+(result[0].imageLocation);
    }else
    return "/assets/not-found/not-available.jpeg"
  }
  addNewCertificateClick()
  {
    let url = '/sme/my-home/addcertificate'
    window.open(url,'_blank')
   
  }
  viewAllCertificataeClick()
  {
    let url = '/sme/my-home/certificate'
    window.open(url,'_blank')
  }
  onActive()
  {
    this.selectedSize=0
    this.publishCertificateButton=true
    this.disableDeactiveButton=true
    this.map.clear()
    this.sUuid = atob(localStorage.getItem('sUuid'))
    this.smeService.smeCertificates(this.sUuid, this.status).subscribe(
      res => {
        this.smeCertificates = res
        console.log(res)
      },
      err=>
      {
        this.smeCertificates=null
      }
    )
  }

  
  onDelete(crtiUuid,index) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose=true
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';
    dialogConfig.data = crtiUuid

    this.deleteDialogRef = this.matDialog.open(DeleteCertificateComponent, dialogConfig);
    this.deleteDialogRef.afterClosed().subscribe(
      res => {
        if(res == true){
          this.smeCertificates.splice(index,1)
        }
      }
    )
  }

  onInActive()
  {
    this.selectedSize=0;
    this.publishCertificateButton=false
    this.disablePublishButton=true
    this.map.clear()
    this.sUuid = atob(localStorage.getItem('sUuid'))
    this.smeService.smeCertificates(this.sUuid, this.status1).subscribe(
      res => {
        this.smeCertificates = res
        console.log(res)
      },
      err=>
      {
        this.smeCertificates=null
      }
    )
  }

  onclickCheckbox(crtiUuid: string, active: boolean) 
  {
    console.log(!this.map.has(crtiUuid))
    if (!this.map.has(crtiUuid)) {
      console.log("added")
      this.map.set(crtiUuid, active);
    } else {
      console.log("delete")
      this.map.delete(crtiUuid)
    }
    console.log(this.map)
    this.selectedSize=this.map.size
    if(this.map.size>0){
    this.disablePublishButton=false
    this.disableDeactiveButton=false
    }else{
      this.disablePublishButton=true
      this.disableDeactiveButton=true
    }
  }

  onClickDeactive()
  {
    let publishDataArr=new Array<PublishData>();

    this.map.forEach((status: boolean, crtiUuid: string) => {
      let publishData=new PublishData();
      publishData.id=crtiUuid;
      publishData.status=status;
      publishDataArr.push(publishData);
      
  });
  this.publishDataService.publishSmeInfo(this.sUuid,publishDataArr,this.source).subscribe(
    res=>
    {
      this.snackBar.open('Deactivate Successfully', '', this.snackBarConfig.getSnackBarConfig())
      this.map.clear()
      this.disableDeactiveButton=true
      this.onActive()
    },
    err=>
    {
      console.log(err)
    }
  )
  }

  onClickPublish()
  {
  let publishDataArr=new Array<PublishData>();

    this.map.forEach((status: boolean, crtiUuid: string) => {
      let publishData=new PublishData();
      publishData.id=crtiUuid;
      publishData.status=status;
      publishDataArr.push(publishData);
      
  });
  this.publishDataService.publishSmeInfo(this.sUuid,publishDataArr,this.source).subscribe(
    res=>
    {
      this.snackBar.open('Publish Data Successfully', '', this.snackBarConfig.getSnackBarConfig())
      this.map.clear()
      this.disablePublishButton=true
      this.onInActive()
    },
    err=>
    {
      console.log(err)
    }
  )
  }

}
