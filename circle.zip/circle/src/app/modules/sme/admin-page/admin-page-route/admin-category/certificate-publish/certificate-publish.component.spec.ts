import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CertificatePublishComponent } from './certificate-publish.component';

describe('CertificatePublishComponent', () => {
  let component: CertificatePublishComponent;
  let fixture: ComponentFixture<CertificatePublishComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CertificatePublishComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CertificatePublishComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
