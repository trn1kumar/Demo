import { Component, Inject } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from "@angular/material";
import { SmeInfoService } from "src/app/core/services/sme-page/sme-info.service";
import { SnackBarConfig } from "src/app/core/services/extra/snackbar.config";


@Component({
    template: `
  
      <div class="text-center">
      <mat-icon  style="font-size:100px;color:rgb(247, 173, 62);margin-right:70px;">error_outline</mat-icon>
      
      <mat-dialog-content>
        <h2>Are You Sure ? </h2>
      </mat-dialog-content>
  
      <p></p>
  
      <button mat-stroked-button (click)="onDelete()" color="warn">Yes</button>
      <button mat-stroked-button (click)="onClickNo()" style="color:green;margin-left:30px">No</button>
  
      </div>
    `
})
export class GalleryDialogComponent
{
    constructor(private dialogRef: MatDialogRef<GalleryDialogComponent>,
        private smeInfoService: SmeInfoService,
       @Inject(MAT_DIALOG_DATA) public data: any, private snackBar: MatSnackBar,
       private snackBarConfig: SnackBarConfig) { }

   onDelete() {
       this.smeInfoService.deleteGallery(this.data).subscribe(
           res => {
               this.snackBar.open('remove successfully', 'Ok', this.snackBarConfig.getSnackBarConfig())
               this.dialogRef.close(true)
           },
       )  
   }

   onClickNo() {
       this.dialogRef.close()
   }
}