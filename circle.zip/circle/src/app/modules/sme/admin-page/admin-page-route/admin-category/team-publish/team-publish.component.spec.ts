import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TeamPublishComponent } from './team-publish.component';

describe('TeamPublishComponent', () => {
  let component: TeamPublishComponent;
  let fixture: ComponentFixture<TeamPublishComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TeamPublishComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TeamPublishComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
