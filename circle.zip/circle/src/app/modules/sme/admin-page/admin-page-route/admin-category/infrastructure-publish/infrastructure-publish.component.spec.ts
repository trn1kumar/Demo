import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InfrastructurePublishComponent } from './infrastructure-publish.component';

describe('InfrastructurePublishComponent', () => {
  let component: InfrastructurePublishComponent;
  let fixture: ComponentFixture<InfrastructurePublishComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InfrastructurePublishComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InfrastructurePublishComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
