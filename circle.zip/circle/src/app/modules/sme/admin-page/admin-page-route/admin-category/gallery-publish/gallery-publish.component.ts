import { Component, OnInit } from '@angular/core';

import { GalleryDialogComponent } from './gallery-dialog.component';
import { SMEGallery } from 'src/app/core/models/sme-gallery';
import { PublishData } from 'src/app/core/models/publish-data';
import { MatDialogRef, MatDialog, MatSnackBar, MatDialogConfig } from '@angular/material';
import { SmeHomePageService } from 'src/app/core/services/sme-page/sme-home-page.service';
import { PublishDataService } from 'src/app/core/services/publish-data/publish-data.service';
import { SnackBarConfig } from 'src/app/core/services/extra/snackbar.config';
import { RestURL } from 'src/app/core/models/rest-api-url';

@Component({
  selector: 'app-gallery-publish',
  templateUrl: './gallery-publish.component.html',
  styleUrls: ['./gallery-publish.component.css']
})
export class GalleryPublishComponent implements OnInit {
  smeGallery: Array<SMEGallery>
  disablePublishButton:boolean=true;
  disableDeactiveButton:boolean=true;
  map = new Map<string, boolean>();
  sUuid: string
  status: string = 'active'
  selectedSize:any=0;
  status1: string = 'deactive'
  source:string ='galleries'
  publishGalleryButton:boolean=true
  publishData = new Array<PublishData>();
  galleryIds:string[]=[]
  deleteDialogRef : MatDialogRef<GalleryDialogComponent>
  constructor(private smeService: SmeHomePageService,private matDialog : MatDialog,private publishDataService:PublishDataService,private snackBar: MatSnackBar,private snackBarConfig: SnackBarConfig) { }

  ngOnInit() {
    this.sUuid = atob(localStorage.getItem('sUuid'))
    this.smeService.smeGallery(this.sUuid, this.status).subscribe(
      res => {
        this.smeGallery = res
        console.log(res)
      }
    )
  }
  onDelete(galleryUuid,index) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose=true
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';
    dialogConfig.data = galleryUuid

    this.deleteDialogRef = this.matDialog.open(GalleryDialogComponent, dialogConfig);
    this.deleteDialogRef.afterClosed().subscribe(
      res => {
        if(res == true){
          this.smeGallery.splice(index,1)
        }
      }
    )
  }
  addGallery()
  {
    let url = '/sme/my-home/addgallery'
    window.open(url,'_blank')
  }
  viewAllGallery()
  {
    let url = '/sme/my-home/gallery'
    window.open(url,'_blank')
  }
  getImage(result){
    if(result != null && result.length > 0){
      return RestURL.contentServerUrl+(result[0].imageLocation);
    }else
    return "/assets/not-found/not-available.jpeg"
  }
  onActive()
  {
    this.selectedSize=0
    this.publishGalleryButton=true
    this.disableDeactiveButton=true
    this.map.clear()
    this.sUuid = atob(localStorage.getItem('sUuid'))
    this.smeService.smeGallery(this.sUuid, this.status).subscribe(
      res => {
        this.smeGallery = res
        console.log(res)
      },
      err=>
      {
        this.smeGallery=null
      }
    )
  }


  onInActive()
  {
    this.selectedSize=0
    this.publishGalleryButton=false
    this.disablePublishButton=true
    this.map.clear()
    this.sUuid = atob(localStorage.getItem('sUuid'))
    this.smeService.smeGallery(this.sUuid, this.status1).subscribe(
      res => {
        this.smeGallery = res
        console.log(res)
      
      },
      err=>
      {
        this.smeGallery=null
      }
    )
  }

  onclickCheckbox(galleryUuid: string, active: boolean) 
  {
    console.log(!this.map.has(galleryUuid))
    if (!this.map.has(galleryUuid)) {
      console.log("added")
      this.map.set(galleryUuid, active);
    } else {
      console.log("delete")
      this.map.delete(galleryUuid)
    }
    console.log(this.map)
    this.selectedSize=this.map.size
    if(this.map.size>0){
    this.disablePublishButton=false
    this.disableDeactiveButton=false
    }else{
      this.disablePublishButton=true
      this.disableDeactiveButton=true
    }
  }

  onClickDeactive()
  {
    let publishDataArr=new Array<PublishData>();

    this.map.forEach((status: boolean, galleryUuid: string) => {
      let publishData=new PublishData();
      publishData.id=galleryUuid;
      publishData.status=status;
      publishDataArr.push(publishData);
      
  });
  this.publishDataService.publishSmeInfo(this.sUuid,publishDataArr,this.source).subscribe(
    res=>
    {
      this.snackBar.open('Deactivate Successfully', '', this.snackBarConfig.getSnackBarConfig())
      this.map.clear()
      this.disableDeactiveButton=true
      this.onActive()
    }
  )
  }

  onClickPublish()
  {
  let publishDataArr=new Array<PublishData>();

    this.map.forEach((status: boolean, galleryUuid: string) => {
      let publishData=new PublishData();
      publishData.id=galleryUuid;
      publishData.status=status;
      publishDataArr.push(publishData);
      
  });
  this.publishDataService.publishSmeInfo(this.sUuid,publishDataArr,this.source).subscribe(
    res=>
    {
      this.snackBar.open('Publish Data Successfully', '', this.snackBarConfig.getSnackBarConfig())
      this.map.clear()
      this.disablePublishButton=true
      this.onInActive()
    }
  )
  }
}
