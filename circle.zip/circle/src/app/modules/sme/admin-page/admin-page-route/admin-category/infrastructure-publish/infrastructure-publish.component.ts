import { Component, OnInit } from '@angular/core';
import { DeleteInfrastructureComponent } from './delete-infrastructure.component';
import { SMEInfrastructure } from 'src/app/core/models/sme-infrastructure';
import { PublishData } from 'src/app/core/models/publish-data';
import { MatDialogRef, MatDialog, MatSnackBar, MatDialogConfig } from '@angular/material';
import { SmeHomePageService } from 'src/app/core/services/sme-page/sme-home-page.service';
import { PublishDataService } from 'src/app/core/services/publish-data/publish-data.service';
import { SnackBarConfig } from 'src/app/core/services/extra/snackbar.config';
import { RestURL } from 'src/app/core/models/rest-api-url';

@Component({
  selector: 'app-infrastructure-publish',
  templateUrl: './infrastructure-publish.component.html',
  styleUrls: ['./infrastructure-publish.component.css']
})
export class InfrastructurePublishComponent implements OnInit {
  smeInfra: Array<SMEInfrastructure>
  disablePublishButton: boolean = true;
  disableDeactiveButton: boolean = true;
  map = new Map<string, Array<boolean>>();
  sUuid: string
  selectedSize:any=0
  status: string = 'active'
  status1: string = 'deactive'
  source: string = 'infrastructures'
  publishInfraButton: boolean = true
  publishData = new Array<PublishData>();
  deleteDialogRef: MatDialogRef<DeleteInfrastructureComponent>
  galleryIds: string[] = []

  constructor(private smeService: SmeHomePageService, private publishDataService: PublishDataService, private matDialog: MatDialog, private snackBar: MatSnackBar, private snackBarConfig: SnackBarConfig) { }

  ngOnInit() {
    this.sUuid = atob(localStorage.getItem('sUuid'))
    this.smeService.smeInfrastructure(this.sUuid, this.status).subscribe(
      res => {
        this.smeInfra = res
        console.log(res)
      }
    )
  }
  addInfrastructure() {
    let url = '/sme/my-home/addinfrastructure'
    window.open(url, '_blank')
  }
  viewAllInfrastructure() {
    let url = '/sme/my-home/infrastructure'
    window.open(url, '_blank')
  }
  onDelete(infraUuid, index) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose=true
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';
    dialogConfig.data = infraUuid

    this.deleteDialogRef = this.matDialog.open(DeleteInfrastructureComponent, dialogConfig);
    this.deleteDialogRef.afterClosed().subscribe(
      res => {
        if (res == true) {
          this.smeInfra.splice(index, 1)
        }
      }
    )
  }
  getImage(result) {
    if (result != null && result.length > 0) {
      return RestURL.contentServerUrl + (result[0].imageLocation);
    } else
      return "/assets/not-found/not-available.jpeg"
  }

  onActive() {
    this.selectedSize=0
    this.publishInfraButton = true
    this.disableDeactiveButton = true
    this.map.clear()
    this.sUuid = atob(localStorage.getItem('sUuid'))
    this.smeService.smeInfrastructure(this.sUuid, this.status).subscribe(
      res => {
        this.smeInfra = res
        console.log(res)
      },
      err => {
        this.smeInfra = null
      }
    )
  }

  onInActive() {
    this.selectedSize=0
    this.publishInfraButton = false
    this.disablePublishButton = true
    this.map.clear()
    this.sUuid = atob(localStorage.getItem('sUuid'))
    this.smeService.smeInfrastructure(this.sUuid, this.status1).subscribe(
      res => {
        this.smeInfra = res
        console.log(res)

      },
      err => {
        this.smeInfra = null
      }
    )
  }

  onclickCheckbox(infraUuid: string, active: boolean, businessPost: boolean) {
    console.log(!this.map.has(infraUuid))
    if (!this.map.has(infraUuid)) {
      console.log("added")
      let arr = new Array<boolean>();
      arr.push(active)
      arr.push(businessPost)
      console.log(arr)
      this.map.set(infraUuid, arr);
    } else {
      console.log("delete")
      this.map.delete(infraUuid)
    }
    console.log(this.map)
    this.selectedSize=this.map.size
    if (this.map.size > 0) {
      this.disablePublishButton = false
      this.disableDeactiveButton = false
    } else {
      this.disablePublishButton = true
      this.disableDeactiveButton = true
    }
  }
  onClickDeactive() {
    let publishDataArr = new Array<PublishData>();

    this.map.forEach((arr: Array<boolean>, infraUuid: string) => {
      let publishData = new PublishData();
      publishData.id = infraUuid;
      publishData.status = arr[0];
      publishData.businessPost = arr[1];
      console.log(publishData)
      publishDataArr.push(publishData);

    });
    this.publishDataService.publishSmeInfo(this.sUuid, publishDataArr, this.source).subscribe(
      res => {
        this.snackBar.open('Deactivate Successfully', '', this.snackBarConfig.getSnackBarConfig())
        this.map.clear()
        this.disableDeactiveButton = true
        this.onActive()
      },
      err=>
      {

      }
    )
  }


  onClickPublish() {
    let publishDataArr = new Array<PublishData>();

    this.map.forEach((arr: Array<boolean>, infraUuid: string) => {
      let publishData = new PublishData();
      publishData.id = infraUuid;
      publishData.status = arr[0];
      publishData.businessPost = arr[1];
      publishDataArr.push(publishData);

    });
    this.publishDataService.publishSmeInfo(this.sUuid, publishDataArr, this.source).subscribe(
      res => {
        this.snackBar.open('Publish Data Successfully', '', this.snackBarConfig.getSnackBarConfig())
        this.map.clear()
        this.disablePublishButton = true
        this.onInActive()
      },
      err=>
      {
        
      }
    )
  }
}
