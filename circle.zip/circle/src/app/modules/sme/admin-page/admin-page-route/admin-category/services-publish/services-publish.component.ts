import { Component, OnInit } from '@angular/core';
import { DeleteServiceComponent } from './delete-service.component';
import { BuyNowDialog } from 'src/app/core/services/extra/buyNowDialog.config';
import { SMEService } from 'src/app/core/models/sme-service';
import { MatDialogRef, MatDialog, MatSnackBar, MatDialogConfig } from '@angular/material';
import { PublishData } from 'src/app/core/models/publish-data';
import { SmeService } from 'src/app/core/services/sme-service/sme.service';
import { PublishDataService } from 'src/app/core/services/publish-data/publish-data.service';
import { SnackBarConfig } from 'src/app/core/services/extra/snackbar.config';
import { RestURL } from 'src/app/core/models/rest-api-url';


@Component({
  selector: 'app-services-publish',
  templateUrl: './services-publish.component.html',
  styleUrls: ['./services-publish.component.css']
})
export class ServicesPublishComponent implements OnInit {
  smeServices: Array<SMEService>
  disablePublishButton: boolean = true;
  disableDeactiveButton: boolean = true;
  selectedServiceSize:any=0;
  map = new Map<string, Array<boolean>>();
  sUuid: string
  status: string = 'active'
  status1: string = 'deactive'
  deleteDialogRef: MatDialogRef<DeleteServiceComponent>
  publishServiceButton: boolean = true
  publishData = new Array<PublishData>();

  constructor(private smeService: SmeService, private publishDataService: PublishDataService, private matDialog: MatDialog, private snackBar: MatSnackBar, private snackBarConfig: SnackBarConfig) { }

  ngOnInit() {
    this.selectedServiceSize=0
    this.smeService.serviceBySuuid(atob(localStorage.getItem('sUuid')), this.status).subscribe(
      res => {
        this.smeServices = res
        console.log(res)
      }

    )
  }
  getImage(result) {
    if (result != null && result.length > 0) {
      return RestURL.contentServerUrl + (result[0].imageLocation);
    } else
      return "/assets/not-found/not-available.jpeg"
  }

  onDelete(serviceUUID, index) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose=true
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';
    dialogConfig.data = { serviceUUID, sUuid: atob(localStorage.getItem('sUuid')) }

    this.deleteDialogRef = this.matDialog.open(DeleteServiceComponent, dialogConfig);
    this.deleteDialogRef.afterClosed().subscribe(
      res => {
        if (res == true) {
          this.smeServices.splice(index, 1)
        }
      }
    )
  }
  onActive() {
    this.selectedServiceSize=0
    this.publishServiceButton = true
    this.disableDeactiveButton = true
    this.map.clear()
    this.smeService.serviceBySuuid(atob(localStorage.getItem('sUuid')), this.status).subscribe(
      res => {
        this.smeServices = res
        console.log(res)
      }, err => {
        this.smeServices = null
      }

    )
  }

  onInActive() {
    this.selectedServiceSize=0
    this.publishServiceButton = false
    this.disablePublishButton = true
    this.map.clear()
    this.smeService.serviceBySuuid(atob(localStorage.getItem('sUuid')), this.status1).subscribe(
      res => {
        this.smeServices = res
        console.log(res)
      },
      err => {
        this.smeServices = null
      }

    )
  }

  onclickCheckbox(serviceUuid: string, active: boolean, businessPost: boolean) {
    console.log(!this.map.has(serviceUuid))
    if (!this.map.has(serviceUuid)) {
      console.log("added")
      let arr = new Array<boolean>();
      arr.push(active)
      arr.push(businessPost)
      console.log(arr)
      this.map.set(serviceUuid, arr);
    } else {
      console.log("delete")
      this.map.delete(serviceUuid)
    }
    console.log(this.map)
    this.selectedServiceSize=this.map.size
    if (this.map.size > 0) {
      this.disablePublishButton = false
      this.disableDeactiveButton = false
    } else {
      this.disablePublishButton = true
      this.disableDeactiveButton = true
    }
  }

  onClickDeactive() {
    let publishDataArr = new Array<PublishData>();

    this.map.forEach((arr: Array<boolean>, serviceUuid: string) => {
      let publishData = new PublishData();
      publishData.id = serviceUuid;
      publishData.status = arr[0];
      publishData.businessPost = arr[1];
      console.log(publishData)
      publishDataArr.push(publishData);

    });
    this.publishDataService.publishService(atob(localStorage.getItem('sUuid')), publishDataArr).subscribe(
      res => {
        this.snackBar.open('Deactivate Successfully', '', this.snackBarConfig.getSnackBarConfig())
        this.map.clear()
        this.disableDeactiveButton = true
        this.onActive()

        console.log(res)
      }
    )
  }


  onClickPublish() {
    let publishDataArr = new Array<PublishData>();

    this.map.forEach((arr: Array<boolean>, serviceUuid: string) => {
      let publishData = new PublishData();
      publishData.id = serviceUuid;
      publishData.status = arr[0];
      publishData.businessPost = arr[1];
      console.log(publishData)
      publishDataArr.push(publishData);

    });
    this.publishDataService.publishService(atob(localStorage.getItem('sUuid')), publishDataArr).subscribe(
      res => {
        this.snackBar.open('Publish Data Successfully', '', this.snackBarConfig.getSnackBarConfig())
        this.map.clear()
        this.disablePublishButton = true
        this.onInActive()
      },
      // err => {
      //   console.log(err)
      //   if (err.status == 402) {
      //     const dialogRef = this.buyNowDialog.openbuyNowDialog()
      //     dialogRef.afterClosed().subscribe(
      //       res => {

      //       }
      //     )
      //   }
      // }
    )
  }
  productNameClick(serviceUrlName, serviceUUID) {
    let url = '/services/' + serviceUrlName + '/' + serviceUUID
    window.open(url, '_blank')
  }
}
