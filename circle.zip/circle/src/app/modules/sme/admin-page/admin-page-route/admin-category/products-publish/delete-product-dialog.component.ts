import { Component, Inject } from "@angular/core";
import { MatDialogRef, MatSnackBar, MAT_DIALOG_DATA } from "@angular/material";
import { ProductService } from "src/app/core/services/product/product.service";
import { SnackBarConfig } from "src/app/core/services/extra/snackbar.config";


@Component({
    template: `
  
      <div class="text-center">
      <mat-icon  style="font-size:100px;color:rgb(247, 173, 62);margin-right:70px;">error_outline</mat-icon>
      
      <mat-dialog-content>
        <h2>Are You Sure ? </h2>
      </mat-dialog-content>
  
      <p></p>
  
      <button mat-stroked-button (click)="onDelete()" color="warn">Yes</button>
      <button mat-stroked-button (click)="onClickNo()" style="color:green;margin-left:30px">No</button>
  
      </div>
    `
})
export class DeleteProductComponent
{
    constructor(private dialogRef: MatDialogRef<DeleteProductComponent>,
        private productService: ProductService,
       @Inject(MAT_DIALOG_DATA) public data: any, private snackBar: MatSnackBar,
       private snackBarConfig: SnackBarConfig) { }

   onDelete() {
       this.productService.removeProduct(this.data).subscribe(
           res => {
               this.snackBar.open('remove successfully', 'Ok', this.snackBarConfig.getSnackBarConfig())
               this.dialogRef.close(true)
           },
       )  
   }

   onClickNo() {
       this.dialogRef.close()
   }
}