import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductsPublishComponent } from './products-publish.component';

describe('ProductsPublishComponent', () => {
  let component: ProductsPublishComponent;
  let fixture: ComponentFixture<ProductsPublishComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductsPublishComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductsPublishComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
