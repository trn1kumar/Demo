import { Component, OnInit } from '@angular/core';
import { BuyNowDialog } from 'src/app/core/services/extra/buyNowDialog.config';
import { JobPost } from 'src/app/core/models/jobPost';
import { PublishData } from 'src/app/core/models/publish-data';
import { MatDialog, MatSnackBar, MatDialogRef, MatDialogConfig } from '@angular/material';
import { JobPostingService } from 'src/app/core/services/job-posting/job-posting.service';
import { PublishDataService } from 'src/app/core/services/publish-data/publish-data.service';
import { SnackBarConfig } from 'src/app/core/services/extra/snackbar.config';
import { RestURL } from 'src/app/core/models/rest-api-url';
import { DeleteVacancyDialog } from './delete-vacancy-dialog-component';

@Component({
  selector: 'app-vacancy-publish',
  templateUrl: './vacancy-publish.component.html',
  styleUrls: ['./vacancy-publish.component.css']
})
export class VacancyPublishComponent implements OnInit {

  smeJobs: Array<JobPost>
  disablePublishButton:boolean=true;
  disableDeactiveButton:boolean=true;
  map = new Map<string, boolean>();
  sUuid: string
  selectedSize:any=0
  status: string = 'active'
  status1: string = 'deactive'
  publishVacancyButton: boolean = true
  publishData = new Array<PublishData>();
  noAvailableImage:boolean=false
  deleteDialogRef: MatDialogRef<DeleteVacancyDialog>
  vacancyIds: string[] = []
  constructor(private matDialog: MatDialog,private jobPostService: JobPostingService, private publishDataService: PublishDataService, private snackBar: MatSnackBar, private snackBarConfig: SnackBarConfig) { }


  ngOnInit() {
    this.jobPostService.getJobsBySmeId(atob(localStorage.getItem('sUuid')),this.status).subscribe(
      res => {
        this.smeJobs = res
        console.log(this.smeJobs)
      }
    )
  }
  getImage(result) {
    if (result != null && result.length > 0) {
      return RestURL.contentServerUrl + (result[0].imageLocation);
    } else
      return "/assets/not-found/not-available.jpeg"
  }
  onDelete(vacancyUuid, index) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose=true
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';
    dialogConfig.data = vacancyUuid

    this.deleteDialogRef = this.matDialog.open(DeleteVacancyDialog, dialogConfig);
    this.deleteDialogRef.afterClosed().subscribe(
      res => {
        if (res == true) {
          this.smeJobs.splice(index, 1)
        }
      }
    )
  }
  onActive() {
    this.selectedSize=0
    this.publishVacancyButton = true
    this.disableDeactiveButton=true
    this.map.clear()
    this.jobPostService.getJobsBySmeId(atob(localStorage.getItem('sUuid')),this.status).subscribe(
      res => {
        this.smeJobs = res
        console.log(res)
      },err=>
      {
        this.smeJobs=null
      }
    )
  }
  onInActive() 
  {
    this.selectedSize=0
    this.publishVacancyButton = false
    this.disablePublishButton=true
    this.map.clear()
    this.jobPostService.getJobsBySmeId(atob(localStorage.getItem('sUuid')),this.status1).subscribe(
      res => {
        this.smeJobs = res
        
        console.log(this.smeJobs)
      },
      err=>
      {
        this.noAvailableImage=true
        this.smeJobs=null
      }
    )
  }
  onclickCheckbox(vacancyUuid: string, vacancyActive: boolean) 
  {
    console.log(!this.map.has(vacancyUuid))
    if (!this.map.has(vacancyUuid)) {
      this.map.set(vacancyUuid, vacancyActive);
    } else {
      this.map.delete(vacancyUuid)
    }
    console.log(this.map)
    this.selectedSize=this.map.size
    if(this.map.size > 0){
    this.disablePublishButton=false
    this.disableDeactiveButton=false
    }else{
      this.disablePublishButton=true
      this.disableDeactiveButton=true
    } 
  }
  
  addNewVacancyClick()
  {
    let url = '/sme/my-home/vacancy-post'
    window.open(url, '_blank')
  }
  viewAllVacancy()
  {
    let url = '/sme/my-home/vacancy'
    window.open(url, '_blank')
  }
  onClickDeactive()
  {
    let publishDataArr=new Array<PublishData>();

    this.map.forEach((status: boolean, vacancyUuid: string) => {
      let publishData=new PublishData();
      publishData.id=vacancyUuid;
      publishData.status=status;
      publishDataArr.push(publishData);
      
  });
  this.publishDataService.publishVacancy(atob(localStorage.getItem('sUuid')),publishDataArr).subscribe(
    res=>
    {
      this.snackBar.open('Deactivate Successfully', '', this.snackBarConfig.getSnackBarConfig())
      this.map.clear()
      this.disableDeactiveButton=true
      this.onActive()
    },
    err => {
      console.log(err)
      // if (err.status == 402) {
      //   const dialogRef = this.buyNowDialog.openbuyNowDialog()
      //   dialogRef.afterClosed().subscribe(
      //     res => {

      //     }
      //   )
      // }
    }
  )
  }

  onClickPublish()
  {
  let publishDataArr=new Array<PublishData>();

    this.map.forEach((status: boolean, vacancyUuid: string) => {
      let publishData=new PublishData();
      publishData.id=vacancyUuid;
      publishData.status=status;
      publishDataArr.push(publishData);
      
  });
  this.publishDataService.publishVacancy(atob(localStorage.getItem('sUuid')),publishDataArr).subscribe(
    res=>
    {
      this.snackBar.open('Publish Data Successfully', '', this.snackBarConfig.getSnackBarConfig())
      this.map.clear()
      this.disablePublishButton=true
      this.onInActive()
    },
    err=>
    {
      publishDataArr=null
    }
  )
  }
}

