import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VacancyPublishComponent } from './vacancy-publish.component';

describe('VacancyPublishComponent', () => {
  let component: VacancyPublishComponent;
  let fixture: ComponentFixture<VacancyPublishComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VacancyPublishComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VacancyPublishComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
