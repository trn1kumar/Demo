import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CircleRoutingModule } from './circle-routing.module';
import { CircleHomeComponent } from './circle-home/circle-home.component';
import { MyConnectionComponent } from './circle-home/my-connection/my-connection.component';
import { PendingRequestComponent } from './circle-home/pending-request/pending-request.component';
import { SentRequestComponent } from './circle-home/sent-request/sent-request.component';
import { SuggestionComponent } from './circle-home/suggestion/suggestion.component';
import { SharedModule } from '../shared/shared.module';
import { CircleComponent } from './circle.component';
import { DeleteConnectionDialogComponent } from './circle-home/my-connection/delete-connection-dialog.component';
import { DeletePendingDialogComponent } from './circle-home/pending-request/remove-pending-dialog.component';
import { DeleteSentDialogComponent } from './circle-home/sent-request/cancel-sent-dialog.component';
import { MutualConnectionDialogComponents } from './circle-home/suggestion/mutual-connection-dialog.component';
import { MutualMyConnectionDialogComponents } from './circle-home/my-connection/Mutual-MyConnection-dialog.component';
import { MutualSConnectionDialogComponents } from './circle-home/sent-request/mutual-SConnection-dialog.component';
import { MutualPConnectionDialogComponents } from './circle-home/pending-request/mutual-pconnection-dialog.component';
import { LayoutModule } from 'src/app/layout/users/smeface/layout.module';

@NgModule({
  imports: [
    CommonModule,
    CircleRoutingModule,
    LayoutModule,
    SharedModule
  ],
  declarations: [
    CircleHomeComponent, 
    MyConnectionComponent, 
    PendingRequestComponent, 
    SentRequestComponent, 
    SuggestionComponent, 
    CircleComponent,
    DeleteConnectionDialogComponent,
    DeletePendingDialogComponent,
    DeleteSentDialogComponent,
    MutualConnectionDialogComponents,
    MutualPConnectionDialogComponents,
    MutualSConnectionDialogComponents,
    MutualMyConnectionDialogComponents
  ],
  entryComponents:[DeleteConnectionDialogComponent,DeletePendingDialogComponent,DeleteSentDialogComponent,MutualConnectionDialogComponents,MutualPConnectionDialogComponents,MutualSConnectionDialogComponents,MutualMyConnectionDialogComponents]
})
export class CircleModule { }
