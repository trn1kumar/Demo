import { Component, OnInit } from "@angular/core";
import { SMECircleDto, ConnectionVo } from "src/app/core/models/business-circle";
import { MatDialogRef, MatDialog, MatSnackBar, MatDialogConfig } from "@angular/material";
import { DeleteSentDialogComponent } from "./cancel-sent-dialog.component";
import { MutualSConnectionDialogComponents } from "./mutual-SConnection-dialog.component";
import { BusinessCircleService } from "src/app/core/services/circle/business-circle.service";
import { SnackBarConfig } from "src/app/core/services/extra/snackbar.config";
import { Router } from "@angular/router";
import { RestURL } from "src/app/core/models/rest-api-url";


@Component({
  selector: 'app-sent-request',
  templateUrl: './sent-request.component.html',
  styleUrls: ['./sent-request.component.css']
})
export class SentRequestComponent implements OnInit {

  sUuid:string;
  sendReqs:SMECircleDto[];
  sentRequestNotFound:boolean=false
  deleteDialogRef: MatDialogRef<DeleteSentDialogComponent>
  mutualsConnectionView:MatDialogRef<MutualSConnectionDialogComponents>
  constructor(public businessCircle:BusinessCircleService,private matDialog: MatDialog,private snackbarConfig : SnackBarConfig,private snackBar: MatSnackBar,private router:Router) { }

  ngOnInit() {
    this.sUuid=atob(localStorage.getItem('sUuid'));
    this.businessCircle.getAllSentRequest(this.sUuid).subscribe(response=>
      {
        this.sendReqs=response;
        console.log(response)
      },
      err=>
      {
        this.sentRequestNotFound=true
        
      }
  );
  }
  onOpenDialog(mutualConnections:SMECircleDto[],smeName:string)
  {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';
    dialogConfig.data ={mutualConnections,smeName}
  
    this.mutualsConnectionView = this.matDialog.open(MutualSConnectionDialogComponents, dialogConfig);
    this.mutualsConnectionView.afterClosed().subscribe(
      res => {
        if(res == true)
        {
         
        }
      }
    )
  }
  cancelSentrequest(sendRequestId: string, index) {
    let cancelCon=new ConnectionVo();
      cancelCon.sUuid=this.sUuid;
      cancelCon.sendReqUuid=sendRequestId

    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';
    dialogConfig.data = cancelCon

    this.deleteDialogRef = this.matDialog.open(DeleteSentDialogComponent, dialogConfig);
    this.deleteDialogRef.afterClosed().subscribe(
      res => {
        if (res == true) {
          this.sendReqs.splice(index, 1)
        }
      }
    )
  }


  getImage(imageName){
    if(imageName != null){
      return RestURL.contentServerUrl + (imageName);
    }else
    return "/assets/not-found/404.jpg"
  }
  smeNameClick(sUuid){
    let url =  'sme/' + sUuid
    window.open(url,'_blank')
  }
}
