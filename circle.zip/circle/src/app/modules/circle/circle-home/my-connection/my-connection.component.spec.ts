import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyConnectionComponent } from './my-connection.component';

describe('MyConnectionComponent', () => {
  let component: MyConnectionComponent;
  let fixture: ComponentFixture<MyConnectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyConnectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyConnectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
