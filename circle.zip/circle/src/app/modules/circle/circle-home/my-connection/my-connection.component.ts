import { Component, OnInit } from "@angular/core";
import { SMECircleDto, ConnectionVo } from "src/app/core/models/business-circle";
import { MatDialogRef, MatDialog, MatSnackBar, MatDialogConfig } from "@angular/material";
import { DeleteConnectionDialogComponent } from "./delete-connection-dialog.component";
import { MutualMyConnectionDialogComponents } from "./Mutual-MyConnection-dialog.component";
import { SnackBarConfig } from "src/app/core/services/extra/snackbar.config";
import { Router } from "@angular/router";
import { BusinessCircleService } from "src/app/core/services/circle/business-circle.service";
import { RestURL } from "src/app/core/models/rest-api-url";


@Component({
  selector: 'app-my-connection',
  templateUrl: './my-connection.component.html',
  styleUrls: ['./my-connection.component.css']
})
export class MyConnectionComponent implements OnInit {

  sUuid: string;
  circleConnection: SMECircleDto[];
  connection: SMECircleDto[];
  deleteDialogRef : MatDialogRef<DeleteConnectionDialogComponent>
  mutualMyConnectionView:MatDialogRef<MutualMyConnectionDialogComponents>
  myConnection:boolean=false
  constructor(private snackbarConfig: SnackBarConfig, private matDialog : MatDialog,private snackBar: MatSnackBar, private router: Router, private businessCircle: BusinessCircleService) { }

  ngOnInit() {
    this.sUuid = atob(localStorage.getItem('sUuid'));
    this.businessCircle.getMyCircleConnection(this.sUuid).subscribe(
      res => {
      this.circleConnection = res;
       console.log('MY CONNECTION', res)
    },
    err=>
    {
      this.myConnection=true
    }
    );
  }
  onOpenDialog(mutualConnections:SMECircleDto[],smeName:string)
  {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';
    dialogConfig.data ={mutualConnections,smeName}
  
    this.mutualMyConnectionView = this.matDialog.open(MutualMyConnectionDialogComponents, dialogConfig);
    this.mutualMyConnectionView.afterClosed().subscribe(
      res => {
        if(res == true)
        {
         
        }
      }
    )
  }
  onRemoveConnection(connectionUuid: string,index) {
     let removeCon = new ConnectionVo();
     removeCon.sUuid = this.sUuid;
     removeCon.connectionUuid = connectionUuid;

    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';
    dialogConfig.data = removeCon

    this.deleteDialogRef = this.matDialog.open(DeleteConnectionDialogComponent, dialogConfig);
    this.deleteDialogRef.afterClosed().subscribe(
      res => {
        if(res == true){
          this.circleConnection.splice(index,1)
        }
      }
    )
  }
  getImage(imageName){
    if(imageName != null){
      return RestURL.contentServerUrl + (imageName);
    }else
    return "/assets/not-found/404.jpg"
  }
  smeNameClick(sUuid){
    let url =  'sme/' + sUuid
    window.open(url,'_blank')
  }
}
