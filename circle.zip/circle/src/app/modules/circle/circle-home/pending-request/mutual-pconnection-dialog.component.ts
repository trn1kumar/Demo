import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { Inject, Component } from "@angular/core";
import { RestURL } from "src/app/core/models/rest-api-url";


@Component({
    template: `
    <a href matTooltip="Close" onclick="return false" (click)="close()" style="float:right ; color : rgb(43, 43, 192)">
        <mat-icon>close</mat-icon>
    </a>
        <div class="fluid-container ">
        
        <h6>Mutual Connections: {{data.smeName}}</h6> 
        <hr>
         <div *ngFor="let mutualConnection of data.mutualConnections">
                    <div class="row">

                             <div class="space border"> 
        
                                <img [src]="getImage(mutualConnection.logoImage)" class="avatar">
 
                             </div>
 
                             <div class="middle">

                             <a href="/sme/{{mutualConnection.sUuid}}" onclick="return false" class="smeName" matTooltip="{{mutualConnection.smeName}}" (click)="smeNameClick(mutualConnection.sUuid)">
                                 {{mutualConnection.smeName}}
                                 <p></p>
                                 <span>
                                 {{mutualConnection.smeAddress.locality}}, {{mutualConnection.smeAddress.city}}
                                 </span>
                             </a>
                                
                               <font size="2">Contact Person: {{mutualConnection.contactPerson}}</font>
                             </div>
                        
                        
                    </div>
                    <hr>
                </div>
        </div>
      
    `,
    styles:[
        `
        .avatar {
            vertical-align: middle;
            width: 50px;
            height: 50px;
            border-radius: 60%;
        }
        .space{
            margin-right:20px;
        }
        .middle{
            margin-bottom:20px;
        }
        .smeName{
            color: black;
        }
        `,
    ],
})

export class MutualPConnectionDialogComponents
{
    constructor(private dialogRef: MatDialogRef<MutualPConnectionDialogComponents>,
        @Inject(MAT_DIALOG_DATA) public data: any,) { 
           console.log('data',data)
        }
 
    onClickNo() {
        this.dialogRef.close()
    }
    close() {
     this.dialogRef.close()
   }
   getImage(imageName){
     if(imageName != null){
       return RestURL.contentServerUrl + (imageName);
     }else
     return "/assets/not-found/404.jpg"
   }
   smeNameClick(sUuid)
   {
     let url =  'sme/' + sUuid
     window.open(url,'_blank')
   }
}