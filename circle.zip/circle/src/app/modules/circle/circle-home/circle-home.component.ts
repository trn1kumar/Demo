import { Component, OnInit } from "@angular/core";
import { BusinessCircle } from "src/app/core/models/business-circle";
import { SME } from "src/app/core/models/sme";
import { Observable } from "rxjs";
import { Image } from "src/app/core/models/image";
import { JwtTokenService } from "src/app/core/services/token/jwt-token.service";
import { SnackBarConfig } from "src/app/core/services/extra/snackbar.config";
import { MatSnackBar } from "@angular/material";
import { ActivatedRoute, Router } from "@angular/router";
import { DomSanitizer } from "@angular/platform-browser";
import { BusinessCircleService } from "src/app/core/services/circle/business-circle.service";
import { RestURL } from "src/app/core/models/rest-api-url";



@Component({
  selector: 'app-circle-home',
  templateUrl: './circle-home.component.html',
  styleUrls: ['./circle-home.component.css']
})
export class CircleHomeComponent implements OnInit {

  sUuid: string;
  isDifferentSme: boolean;
  circle: BusinessCircle;
  receviedReq: SME[];
  sentReq:SME[];
  suggestion: Observable<SME[]>
  images : Image[] = null
  count:number=0;
  peopleYouMayKnowNotFound:boolean=false
  seeAllSent:boolean=true
  seeAll:boolean=true
  seeAllConnection:boolean=false
  sentRequestsNotFound:boolean=false
  mutualConnection:boolean=false
  pendingRequestsNotFound:boolean=false
  constructor(private jwtToken: JwtTokenService,
    private snackbarConfig : SnackBarConfig,private snackBar: MatSnackBar,
    private route: ActivatedRoute, private router: Router, private sanitizer : DomSanitizer,
    private businessCircle: BusinessCircleService) { }

  ngOnInit() {

    this.sUuid = atob(localStorage.getItem('sUuid'));

    if (!this.jwtToken.getUserType() && this.route.snapshot.params['id'] == this.sUuid
      || this.route.snapshot.params['id'] == null) {
      this.isDifferentSme = false;
    }
    else if (!this.jwtToken.getUserType() && this.route.snapshot.params['id'] != this.sUuid) {
      this.isDifferentSme = true;
      this.sUuid = this.route.snapshot.params['id'];
    }
    else {
      this.sUuid = this.route.snapshot.params['id'];
    }
    
    /*For Count */
    this.businessCircle.getBusinessCircle(this.sUuid).subscribe(
      res => {
        this.circle = res;
        this.receviedReq = this.circle.receiveRequests
        if(this.receviedReq == null || this.receviedReq == undefined)
        {
          this.pendingRequestsNotFound=true;
          this.seeAll=false
        }
        /*My Conenctions START*/
          this.count = this.circle.myConnetions.length;
        
          if(this.count > 0)
          {
            this.seeAllConnection=true
          }
        /*My Conenctions END*/
      },
      err=>
      {
        
      }

    );

    this.businessCircle.getPeopleYouMayKnow(this.sUuid).subscribe(
      res=>
      {  /*PeopleYouMayKnow START*/ 
          this.suggestion=res;
          console.log(res)
          /*PeopleYouMayKnow END*/ 
      },
      err=>
      {
        this.peopleYouMayKnowNotFound=true
      }
    );
  }
 
  getImage(imageName){
    if(imageName != null){
      return RestURL.contentServerUrl + (imageName);
    }else
    return "/assets/not-found/404.jpg"
  }
  smeNameClickP(){
    let url =  'circle/pending-requests/'
    window.open(url,'_blank')
  }
  smeNameClickM(){
    let url =  'circle/my-connections/'
    window.open(url,'_blank')
  }
  smeNameClickSent()
  {
    let url =  'circle/sent-requests/'
    window.open(url,'_blank')
  }
}
