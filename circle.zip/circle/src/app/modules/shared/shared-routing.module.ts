import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SmeTermsConditionComponent } from './components/sme-terms-condition/sme-terms-condition.component';




const routes: Routes = [
  {path:'SmeTermsCondition',component:SmeTermsConditionComponent}
 
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SharedRoutingModule { }
