import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sme-terms-condition',
  templateUrl: './sme-terms-condition.component.html',
  styleUrls: ['./sme-terms-condition.component.css']
})
export class SmeTermsConditionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
