import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SmeTermsConditionComponent } from './sme-terms-condition.component';

describe('SmeTermsConditionComponent', () => {
  let component: SmeTermsConditionComponent;
  let fixture: ComponentFixture<SmeTermsConditionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SmeTermsConditionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SmeTermsConditionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
