/* Modules */
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedRoutingModule } from './shared-routing.module';
import { MaterialModule } from './modules/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { ProductNamePipe } from './pipes/productname.pipe';
import { SMENamePipe } from './pipes/smename.pipe';
import { SMECircle1Pipe } from './pipes/smecircle1.pipe';
import { IndianCurrencyPipe } from './pipes/currency.pipe';
import { BusinessPoDescription } from './pipes/businessPodescription.pipe';
import { SmeTermsConditionComponent } from './components/sme-terms-condition/sme-terms-condition.component';
import { SMENameForPost } from './pipes/smeNameForPost.pipe';
import { SearchResultPipe } from './pipes/search-result.pipe';
import { ReadMore } from './pipes/read-more.pipe';
import { BuyNowComponent } from './components/buy-now/buy-now.component';



export const PIPES = [
  ProductNamePipe,
  SMENamePipe,
  SMECircle1Pipe,
  IndianCurrencyPipe,
  BusinessPoDescription,
  SMENameForPost,
  SearchResultPipe,
  ReadMore
];

@NgModule({
  imports: [
    CommonModule,
    SharedRoutingModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  exports: [
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    NotFoundComponent,
    PIPES,
    BuyNowComponent
  ],
  declarations: [
    NotFoundComponent,
    PIPES,
    SmeTermsConditionComponent,
    BuyNowComponent,
  ],
  entryComponents: [BuyNowComponent]
})
export class SharedModule { }
