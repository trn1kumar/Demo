import { Pipe, PipeTransform } from "@angular/core";

@Pipe({ name: 'readMorePipe' })
export class ReadMore implements PipeTransform {

    transform(value: string, ...args: any[]) {

        if(value != null && value.length >= 170){
            return value.slice(0,170) + ''
        }
        return value
    }

}