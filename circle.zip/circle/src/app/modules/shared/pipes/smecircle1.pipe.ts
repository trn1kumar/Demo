import { Pipe, PipeTransform } from "@angular/core";

@Pipe({ name: 'circleSmePipe' })
export class SMECircle1Pipe implements PipeTransform {

    transform(value: string, ...args: any[]) {

        if(value != null && value.length >= 10){
            return value.slice(0,10) + '...'
        }
        return value
    }
}