import { Pipe, PipeTransform } from "@angular/core";

@Pipe({ name: 'smeNameForPostPipe' })
export class SMENameForPost implements PipeTransform {

    transform(value: string, ...args: any[]) {

        if(value != null && value.length >= 12){
            return value.slice(0,12) + '...'
        }
        return value
    }

}