import { SmeServiceModule } from './sme-service.module';

describe('SmeServiceModule', () => {
  let smeServiceModule: SmeServiceModule;

  beforeEach(() => {
    smeServiceModule = new SmeServiceModule();
  });

  it('should create an instance', () => {
    expect(smeServiceModule).toBeTruthy();
  });
});
