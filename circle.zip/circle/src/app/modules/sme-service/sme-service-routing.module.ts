import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ServiceRoutePageComponent } from './service-route-page/service-route-page.component';
import { ServiceCategoryComponent } from './service-category/service-category.component';
import { ServiceNotFoundComponent } from './service-not-found/service-not-found.component';

const routes: Routes = [
  { path:'c/:serviceCategoryURLName' , component:ServiceCategoryComponent},
  { path:'c/:serviceCategoryURLName/:masterSubCategoryURLName' , component:ServiceCategoryComponent},
  { path:':serviceUrlName/:serviceUUID' , component:ServiceRoutePageComponent},
  { path:'' , component:ServiceNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SmeServiceRoutingModule { }
