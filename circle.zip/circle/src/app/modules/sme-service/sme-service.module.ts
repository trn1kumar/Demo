import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SmeServiceRoutingModule } from './sme-service-routing.module';
import { ServiceRoutePageComponent } from './service-route-page/service-route-page.component';
import { ServiceCategoryComponent } from './service-category/service-category.component';
import { ServiceDetailsComponent } from './service-route-page/service-details/service-details.component';
import { ServiceImagesComponent } from './service-route-page/service-images/service-images.component';
import { ServiceDescriptionComponent } from './service-route-page/service-description/service-description.component';
import { ServiceBreadCrumbComponent } from './service-route-page/service-bread-crumb/service-bread-crumb.component';
import { SharedModule } from '../shared/shared.module';
import { ServicesFilterComponent } from './service-category/services-filter/services-filter.component';
import { ServiceBusinessInterestComponent } from './service-route-page/service-business-interest/service-business-interest.component';
import { ServicesDisplayComponent } from './service-category/services-display/services-display.component';
import { ServicesCategorySliderComponent } from './service-category/services-display/services-category-slider/services-category-slider.component';
import { ServicesBreadcrumbComponent } from './service-category/services-display/services-breadcrumb/services-breadcrumb.component';
import { ServicesComponent } from './service-category/services-display/services/services.component';
import { NguCarouselModule } from '@ngu/carousel';
import { Ng5SliderModule } from 'ng5-slider';
import { ServiceNotFoundComponent } from './service-not-found/service-not-found.component';
import { LayoutModule } from 'src/app/layout/users/smeface/layout.module';

@NgModule({
  imports: [
    CommonModule,
    SmeServiceRoutingModule,
    SharedModule,
    LayoutModule,
    NguCarouselModule,
    Ng5SliderModule
  ],
  declarations: [
    ServiceRoutePageComponent, 
    ServiceCategoryComponent, 
    ServiceDetailsComponent, 
    ServiceImagesComponent, 
    ServiceDescriptionComponent, 
    ServiceBreadCrumbComponent, 
    ServicesComponent, 
    ServicesFilterComponent, 
    ServicesCategorySliderComponent, 
    ServiceBusinessInterestComponent, ServicesDisplayComponent, ServicesBreadcrumbComponent, ServiceNotFoundComponent
  ]
})
export class SmeServiceModule { }
