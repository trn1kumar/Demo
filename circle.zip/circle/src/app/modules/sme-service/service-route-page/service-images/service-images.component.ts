import { Component, OnInit, Input, ChangeDetectionStrategy } from '@angular/core';
import { ServiceImage } from 'src/app/core/models/sme-service';
import { RestURL } from 'src/app/core/models/rest-api-url';


@Component({
  selector: 'app-service-images',
  templateUrl: './service-images.component.html',
  styleUrls: ['./service-images.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ServiceImagesComponent implements OnInit {

  @Input()
  serviceImages: Array<ServiceImage>
  @Input()
  selectedImage: ServiceImage

  showBottomImages = true

  constructor() { }

  ngOnInit() {
    if(this.serviceImages.length != null || this.serviceImages.length != undefined){
      this.checkLength(this.serviceImages)
    }
  }

  onMouseOver(image : ServiceImage){
    this.selectedImage = image
  }

  checkLength(images){
    if(images.length == 1){
      this.showBottomImages = false
    }
  }

  getImage(result){
    if(result != null){
      return RestURL.contentServerUrl+(result.fileLocation);
    }else
    return "/assets/not-found/not-available.jpeg"
  }

}
