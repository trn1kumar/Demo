import { Component, OnInit, Input, ChangeDetectionStrategy } from '@angular/core';
import { ServiceImage } from 'src/app/core/models/sme-service';

@Component({
  selector: 'app-service-details',
  templateUrl: './service-details.component.html',
  styleUrls: ['./service-details.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ServiceDetailsComponent implements OnInit {

  @Input()
  service : any

  serviceImages : Array<ServiceImage>
  selectedImage : ServiceImage

  constructor() { }

  ngOnInit() {
    this.serviceImages = this.service.serviceImages
    this.selectedImage = this.service.serviceImages[0]
  }
}
