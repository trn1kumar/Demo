import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-service-bread-crumb',
  templateUrl: './service-bread-crumb.component.html',
  styleUrls: ['./service-bread-crumb.component.css']
})
export class ServiceBreadCrumbComponent implements OnInit {

  @Input()
  breadcrumb : any;

  constructor() { }

  ngOnInit() {
  }

}
