import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceBreadCrumbComponent } from './service-bread-crumb.component';

describe('ServiceBreadCrumbComponent', () => {
  let component: ServiceBreadCrumbComponent;
  let fixture: ComponentFixture<ServiceBreadCrumbComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServiceBreadCrumbComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceBreadCrumbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
