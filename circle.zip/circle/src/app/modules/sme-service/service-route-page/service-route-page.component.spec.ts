import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceRoutePageComponent } from './service-route-page.component';

describe('ServiceRoutePageComponent', () => {
  let component: ServiceRoutePageComponent;
  let fixture: ComponentFixture<ServiceRoutePageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServiceRoutePageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceRoutePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
