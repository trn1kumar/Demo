import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceBusinessInterestComponent } from './service-business-interest.component';

describe('ServiceBusinessInterestComponent', () => {
  let component: ServiceBusinessInterestComponent;
  let fixture: ComponentFixture<ServiceBusinessInterestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServiceBusinessInterestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceBusinessInterestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
