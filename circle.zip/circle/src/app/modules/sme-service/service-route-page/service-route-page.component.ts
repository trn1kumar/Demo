import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { TokenStorageService } from 'src/app/core/services/token/token-storage.service';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { SMEService } from 'src/app/core/models/sme-service';
import { SmeService } from 'src/app/core/services/sme-service/sme.service';

@Component({
  selector: 'app-service-route-page',
  templateUrl: './service-route-page.component.html',
  styleUrls: ['./service-route-page.component.css']
})
export class ServiceRoutePageComponent implements OnInit,OnDestroy {

  service : Observable<SMEService>
  subcription$: Subscription

  showSpinner : boolean = true
  notFound : boolean = false
  constructor(private route : ActivatedRoute,private smeService: SmeService,
    private token: TokenStorageService, private jwtToken: JwtTokenService) { 

    this.subcription$ = this.route.params.subscribe(
      params =>{
       this.serviceBYUuid(params['serviceUUID'])
      }
    )
  }

  ngOnInit() {
    
  }

  serviceBYUuid(serviceUUID:string){
    if(this.token.isLoggedIn() && this.jwtToken.getUserType()){
      this.forUser(serviceUUID);
    }else if(this.token.isLoggedIn() && !this.jwtToken.getUserType()){
      this.forSME(serviceUUID)
    }else{
      this.forAll(serviceUUID)
    }
  }

  forAll(serviceUUID:string){
    this.smeService.serviceByUuid(serviceUUID).subscribe(
      res => {
        this.showSpinner = false
        this.service = res
      },
      err => {
        this.showSpinner = false
        this.notFound = true
      }
    )
  }

  forUser(serviceUUID:string){
    let userUUID = this.jwtToken.getUserId()
    this.smeService.serviceByUuidTypeUSER(serviceUUID,userUUID).subscribe(
      res => {
        this.showSpinner = false
        this.service = res
      },
      err => {
        this.showSpinner = false
        this.notFound = true
      }
    )
  }

  forSME(serviceUUID:string){
    let userUUID = this.jwtToken.getUserId()
    let sUuid = atob(localStorage.getItem('sUuid'))
    this.smeService.serviceByUuidTypeSME(serviceUUID,userUUID,sUuid).subscribe(
      res => {
        this.showSpinner = false
        this.service = res
      },
      err => {
        this.showSpinner = false
        this.notFound = true
      }
    )
  }

  ngOnDestroy(): void {
    this.subcription$.unsubscribe()
  }
  
}
