import { Component, OnInit, Input } from '@angular/core';
import { SMEService } from 'src/app/core/models/sme-service';

@Component({
  selector: 'app-service-description',
  templateUrl: './service-description.component.html',
  styleUrls: ['./service-description.component.css'],
})
export class ServiceDescriptionComponent implements OnInit {

  @Input()
  service: SMEService
  specifications:Map<string,string>

  constructor() { }

  ngOnInit() {
    if(this.service.specifications != null){
      this.specifications = this.service.specifications
    }
  }
  
  smeNameClick(sUuid){
    let url =  'sme/' + sUuid
    window.open(url,'_blank')
  }

  getMapValue(map) {
    return Array.from(Object.entries(map))
  }

}
