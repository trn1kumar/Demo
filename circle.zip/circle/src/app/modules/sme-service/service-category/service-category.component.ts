import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { CategoryResponse } from 'src/app/core/models/sme-service';
import { SmeService } from 'src/app/core/services/sme-service/sme.service';

@Component({
  selector: 'app-service-category',
  templateUrl: './service-category.component.html',
  styleUrls: ['./service-category.component.css']
})
export class ServiceCategoryComponent implements OnInit,OnDestroy {

  services$ : CategoryResponse
  subscription$ : Subscription

  constructor(private smeService: SmeService ,private router:Router) { 
    this.subscription$ = router.events
    .pipe(filter(e => e instanceof NavigationEnd))
    .subscribe((e: NavigationEnd) => {
      this.services(e.url)
    });
  }

  ngOnInit() {
  }

  services(url:string){
    this.smeService.categoryByName(url).subscribe(
      res =>{
        this.services$ = res
        console.log(res)
      },
      err =>{
        this.router.navigateByUrl("/services")
      }
    )

  }

  ngOnDestroy(): void {
    this.subscription$.unsubscribe()
  }
}