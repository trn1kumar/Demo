import { Component, OnInit, Input } from '@angular/core';
import { Options } from 'ng5-slider';
import { Filter, SmeFilter } from 'src/app/core/models/filter';
import { ActivatedRoute, Router, Params } from '@angular/router';

@Component({
  selector: 'app-services-filter',
  templateUrl: './services-filter.component.html',
  styleUrls: ['./services-filter.component.css']
})
export class ServicesFilterComponent implements OnInit {

  @Input()
  filter: Filter
  str: string = ""
  priceFilter: string
  minPrice: number
  resetPriceButton: boolean = false
  resetSmeButton: boolean = false
  filters: Array<string>

  maxPrice: number
  smefilter: Array<SmeFilter>
  constructor(private router: ActivatedRoute, private route: Router) {

  }
  onClick(name, isSelected) {

    if (isSelected == false) {
      this.str = (this.str + " " + name).trim()
    } else {

      this.str = this.str.replace(name, "").trim()

    }

  }
  onSubmit() {
    const queryparams: Params = Object.assign({}, this.router.snapshot.queryParams);

    queryparams['sme'] = this.str;
    if (this.str == undefined || this.str == "") {
      if (this.priceFilter != null) {
        this.onPriceSubmit()
      } else {
        this.route.navigate([]);
      }
      this.resetSmeButton = false
    } else {
      this.route.navigate([], { queryParams: queryparams });
      this.resetSmeButton = true
    }

  }
  onPriceSubmit() {
    const queryparams: Params = Object.assign({}, this.router.snapshot.queryParams);
    this.priceFilter = this.minPrice + "-" + this.maxPrice
    if (this.priceFilter == null || this.priceFilter == "") {
      this.route.navigate([]);
      this.resetPriceButton = false
    } else {
      queryparams['price'] = this.priceFilter
      this.route.navigate([], { queryParams: queryparams });
      this.resetPriceButton = true
    }

  }

  ngOnInit() {
    this.minPrice = this.filter.price.minPrice
    this.maxPrice = this.filter.price.maxPrice
    this.smefilter = this.filter.smeFilter
  }
  clearPriceFilters() {

    this.minPrice = this.filter.price.minPrice
    this.maxPrice = this.filter.price.maxPrice
    this.priceFilter = null;
    this.resetPriceButton = false
    if (this.str != null) {
      this.onSubmit()
    } else {
      this.route.navigate([]);
    }

  }
  clearSmeFilters() {
    this.smefilter.forEach(res => res.isSelected = false)
    this.resetSmeButton = false
    this.str = null;
    if (this.priceFilter != null) {
      this.onPriceSubmit()
    } else {
      this.route.navigate([]);
    }

  }
  clearFilters() {
    this.clearPriceFilters()
    this.clearSmeFilters()
  }

}
