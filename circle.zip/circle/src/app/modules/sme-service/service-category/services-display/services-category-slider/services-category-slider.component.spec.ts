import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServicesCategorySliderComponent } from './services-category-slider.component';

describe('ServicesCategorySliderComponent', () => {
  let component: ServicesCategorySliderComponent;
  let fixture: ComponentFixture<ServicesCategorySliderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServicesCategorySliderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServicesCategorySliderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
