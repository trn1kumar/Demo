import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-services-breadcrumb',
  templateUrl: './services-breadcrumb.component.html',
  styleUrls: ['./services-breadcrumb.component.css']
})
export class ServicesBreadcrumbComponent implements OnInit {

  @Input()
  breadcrumbs: Array<string>

  constructor() { }

  ngOnInit() {
  }

}
