import { Component, OnInit, Input } from '@angular/core';
import { Store } from '@ngrx/store';
import * as fromRoot from '../../../../../app.reducers'
import { TokenStorageService } from 'src/app/core/services/token/token-storage.service';
import { MatDailogService } from 'src/app/core/services/extra/matdialog.config';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { BusinessCartService } from 'src/app/core/services/cart/business-cart.service';
import { MatSnackBar } from '@angular/material';
import { SnackBarConfig } from 'src/app/core/services/extra/snackbar.config';
import { CartItem } from 'src/app/core/models/cart-item';
import { BusinessInterest } from 'src/app/core/models/business-interest';
import { RestURL } from 'src/app/core/models/rest-api-url';


const provider = 'SERVICE'

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css']
})
export class ServicesComponent implements OnInit {

  @Input()
  services: any

  @Input()
  categoryName: Array<string>

  constructor(private token: TokenStorageService,
    private dialogService: MatDailogService, private jwtToken: JwtTokenService,
    private cartService: BusinessCartService, private snackBar: MatSnackBar,
    private snackBarConfig: SnackBarConfig,
    private store: Store<fromRoot.AppState>) { }

  ngOnInit() {
    
  }
  businessInterest(uuid, index) {

    if (!this.token.isLoggedIn()) {
      const dialogRef = this.dialogService.openLoginDialog()
      dialogRef.afterClosed().subscribe(
        res => {
          if (this.token.isLoggedIn()) {
            this.genrateBusinessInterest(uuid, index)
          }
        }
      )
    } else {
      this.genrateBusinessInterest(uuid, index)
    }

  }

  genrateBusinessInterest(uuid, index) {

    let cartItem = new CartItem()
    cartItem.businessInterestQuantity = 1
    cartItem.businessInterestUUID = uuid
    cartItem.provider = provider

    let businessInterest = new BusinessInterest()
    businessInterest.cartItem.push(cartItem)
    businessInterest.userUuid = this.jwtToken.getUserId()

    console.log("BI : ", businessInterest)

    this.cartService.generateBI(businessInterest).subscribe(
      res => {
        this.snackBar.open('Buisness Interest Generated', '', this.snackBarConfig.getSnackBarConfig())
        this.store.dispatch({ type: 'Increment_Total_Cart_Count' })
        this.services.splice(index,1)
      },
      err => {
        if (err.error.errorCode == 208) {
          this.snackBar.open('Service already in cart', '', this.snackBarConfig.getSnackBarConfig())
        }
      }
    )
  }
  productNameClick(serviceUrlName,serviceUUID){
    let url = '/services/' + serviceUrlName + '/' + serviceUUID
    window.open(url,'_blank')
  }

  smeNameClick(sUuid){
    let url =  'sme/' + sUuid
    window.open(url,'_blank')
  }

  getImage(result){
    if(result != null){
      return RestURL.contentServerUrl+(result.fileLocation);
    }else
    return "/assets/not-found/not-available.jpeg"
  }
}
