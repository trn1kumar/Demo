import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-services-display',
  templateUrl: './services-display.component.html',
  styleUrls: ['./services-display.component.css']
})
export class ServicesDisplayComponent implements OnInit {

  @Input()
  services: any;

  constructor() { }

  ngOnInit() {
  }

}
