import { TestBed, inject } from '@angular/core/testing';

import { CartGuardService } from './cart-guard.service';

describe('CartGuardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CartGuardService]
    });
  });

  it('should be created', inject([CartGuardService], (service: CartGuardService) => {
    expect(service).toBeTruthy();
  }));
});
