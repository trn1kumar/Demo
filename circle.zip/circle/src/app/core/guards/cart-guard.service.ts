import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { JwtTokenService } from '../services/token/jwt-token.service';

@Injectable({
  providedIn: 'root'
})
export class CartGuardService implements CanActivate{

  constructor(private jwtToken: JwtTokenService, private router: Router) { }

  canActivate(): boolean {
    if(this.jwtToken.getUserType()){
      this.router.navigateByUrl('/cart');
      return false;
    }else{
      return true;
    }
  }
  
}
