import { Image } from "./image";
import { Auditable } from "./auditable";

export class SMEManagementTeam extends Auditable
{
    fullName : string
    designation : string
    experience : number
    fbLink : string
    linkedinLink : string
    images : Image[]
    teamUuid : string
    twitterLink : string
    mail:string
    active:boolean
}