export class Filter {

     price:PriceFilter;
	 smeFilter:Array<SmeFilter>;
   
}

export class SmeFilter {
     smeNames:string
	 sUUID:string
	 isSelected:Boolean
}

export class PriceFilter{
    maxPrice:number
	minPrice:number

}