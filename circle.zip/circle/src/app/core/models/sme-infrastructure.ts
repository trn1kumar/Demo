import { Image } from "./image";
import { Auditable } from "./auditable";

export class SMEInfrastructure extends Auditable{

    images : Image[]
    infraUuid : string
    machineName : string
    capacity : string
    description : string
    manufacturer : string
    modelName : string
    quantity : string
    active:boolean
    businessPost:boolean
}