import { Auditable } from "./auditable";

export class SMEGallery extends Auditable{
    
    galleryUuid:string
    description:string
    active:boolean
    galleryTitle:string
}