export class SearchRequest {
    searchText: string
    searchEntity: string
}