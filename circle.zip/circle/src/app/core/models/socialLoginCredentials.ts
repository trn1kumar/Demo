export class SocialLoginCredentials{
    public static readonly facebookClientId:string='308542979751669';
    public static readonly googleClientId:string='735327285764-d7tb2je02ujnvq9j75fvqvefup1nkc5d.apps.googleusercontent.com'
}