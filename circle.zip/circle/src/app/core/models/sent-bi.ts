import { Product } from "./product";

export class Sent_BI{
    smeCartId : number
    businessInterestQuantity : number
    products : Product
    
}