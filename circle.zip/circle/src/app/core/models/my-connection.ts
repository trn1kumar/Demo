import { Image } from "./image";

export class MyConnection {
    connectionUuid : string
    images : Image[]
    sUuid : string
    smeName : string
}