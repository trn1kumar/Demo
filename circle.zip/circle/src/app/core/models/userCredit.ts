export class UserCredit {
    planName: string;
    productListing: number;
    connectionCredits: number;
    biReadCredits: number;
    imageStorageSize: DoubleRange;
    jobPostings:number;
    businessPostCredits:number;
}