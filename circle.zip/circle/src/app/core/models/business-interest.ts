import { CartItem } from "./cart-item";

export class BusinessInterest {
    userUuid : string
    cartItem : CartItem[] = []
}