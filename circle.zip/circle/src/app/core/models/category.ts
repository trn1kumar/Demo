import { SubCategory } from "./subcategory";

export class Category {
    title: string
    url: string
    subCategoryVos : SubCategory[]
}