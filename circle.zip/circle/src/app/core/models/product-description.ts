export class ProductDescription{
    
    sUuid : string
    uuid : string
    productDisplayName : string
    stock : number
    weight : number
    smeName : string
    location : string
    longDesc : string
    shortDesc : string
    price : number

}