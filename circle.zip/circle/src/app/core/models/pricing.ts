export class PricingRequest{
    sUuid:string
    plan:string
    type:string
    userUUID:string
}

export class AddCredits{
    sUuid:string
    type:string
    userUUID:string
    credits:number
    action:string = "CREDIT"
}
