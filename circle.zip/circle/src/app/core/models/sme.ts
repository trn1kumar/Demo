import { Image } from "./image";

export class SME {
    smeName : string
    sUuid : string
    images : Image[]
    
}