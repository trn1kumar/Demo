export class Auditable
{
    creationDate:Date
}