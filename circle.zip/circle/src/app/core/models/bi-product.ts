export class BI_Product{
    uuid : string
    sUuid : string
}