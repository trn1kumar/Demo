import { BI_Product } from "./bi-product";

export class CartItem {
    businessInterestUUID : string
    businessInterestQuantity : number
    provider: string
}