import { Image } from "./image";

export class SMEInformation {

    smeName: string;
    smeType: string;
    uuid: string;
    registeredAS: string;
    address: string;
    companyDescription: string;
    contactEmail: string;
    contactPerson: string;
    contactPhone: string;
    gstin: number;
    smeAddress: SMEAddress
    numberOfEmployees: number;
    oneLineStatement: string;
    yearOfEstablishment: string;
    turnOver: string;
    logoImage: string;
    googlemapLink: string;
   
    

}
export class SMECategoryDto{
    categoryUuid:string
    categoryUrl:string
    categoryName:string
    smes:Array<SMEInformation>
    totalSmesCount:number;
}
export class SMEAddress {
    address_uuid: string;

    street: string;

    city: string;

    country: string;

    state: string;

    pincode: string;

    locality: string;
}

export class SearchRequest {
    searchText: string
}

export class City {
    state: State
    cityCode: string
    cityName: string
    formattedCityName: string
}
export class State {
    country: Country
    formattedStateName: string
    stateCode: string
    stateName: string

}
export class Country {
    countryCode:string
    countryName:string
}