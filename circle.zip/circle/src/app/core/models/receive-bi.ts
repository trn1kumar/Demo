import { User } from "./user";

export class Received_BI {
    viewStatus : boolean
    userDetails : User
    status : string
    spinner:boolean
    recievdBusinessInterests:Array<any>
    sentCount:number
    receiveCount:number
}
