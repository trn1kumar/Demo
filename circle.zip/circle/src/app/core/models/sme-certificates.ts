import { Image } from "./image";
import { Auditable } from "./auditable";

export class SMECertificate extends Auditable{
    crtiUuid : string
    certificateType : string
    certificateDesc : string
    images : Image[]
    active:boolean
}