export class Image {
    fileLocation:string
    mainImage: boolean
}