export class JobPost
{
    smeUuid:string

    vacancyUuid:string
    
    vacancyTitle:string
    
    shortDescription:string
    
    minExp:number
    
    maxExp:number
    
    minSalary:number
    
    maxSalary:number
    
    jobLocation:string
    
    noOfVacancy:number
    
    jobRole:string
    
    minQualification:string
    
    maxAge:number
    
    lastApplyDate:Date
    
    keySkills:string


    totalAppliedBy:number

    vacancyDetail:VacancyDetail

    smeInfo:SMEDto

    vacancyActive:boolean

    businessPost:boolean
}
export class ApplyActivity{

    applyActivityUuid:string

    userUuid:string

    userResume:string
    
    applyDate:Date

    userFullName:string

    userMobileNumber:string

    userEmail:string

    about:string
}
export class VacancyDetail
{
    vdUuid:string
    
    longDescription:string
    
    contactMobileNumber:string

    contactEmail:string
}

export class SMEDto
{
    smeName:string
    sUuid:string
}

export class UserDto
{
    uuid:string
    userFullName:string

}
 export class VacancyFilter{
    
}

 export module VacancyFilter{
    
    let filterByJobRoles:Map<string,Set<FilterByJobRole>>
    let filterByLocations:Map<string,Set<FilterByLocation>>
   let filterBySmes:Map<string,Set<FilterBySme>>;
   let filterBySalary:Map<string,Set<FilterBySalary>>

   let filterByExperience:Map<string,Set<FilterByExperience>>;
   let filterByQualifications:Map<string,Set<FilterByQualification>>
  
  
   let filterByRevelance:Map<string,Set<FilterByRevelance>>
   
    export class FilterBySme{
        sUuid:string;
       smeName:string;
       selected:string;
    }
    export class FilterByExperience{
         minExp:DoubleRange;
         maxExp:DoubleRange;
         formattedExperience:string
		 selected:boolean;
    }
    export class FilterByLocation {
         location:string;
		 selected:boolean;
    }
    export class FilterByQualification {
         qualification:string;
		 selected:boolean;
    }
    export class FilterByJobRole {
         jobRole:string;
		 selected:boolean;
    }
    export class FilterBySalary {
         minSalary:LongRange;
         maxSalary:LongRange;
         formattedSalary:string
		 selected:boolean
    }
    export class FilterByRevelance {
         minCreationDate:Date;
		 maxCreationDate:Date;
		 selected:boolean;
    }
}

