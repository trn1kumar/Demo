export class BusinessPost
{
    smeUuid:string
    
    businessPostId:string
    
    title:string
    
    description:string
    
    privacy:string

    files:Array<BusinessPostImages>

    image:string
    
    public tags:Array<string>
    
    publishFeedDto:PublishFeedDto
}

export class BusinessPostDto extends BusinessPost
{
    smeInfo:SMEDto
    taggedWith:Array<SMEDto>
}

export class SMEDto
{
    sUuid:string
    smeName:string;
    logoImage:string;
}
export class BusinessPostImages
{
    fileId:string
    fileName:string
    fileLocation:string
    imageLocation:string
    active:boolean
}
export class PublishFeedDto{
    id:string
    active:boolean
    machineName:string
    description:string
    images:Array<BusinessPostImages>
}