
import { Image } from "./image";
import { Address } from "./address";

export class User {
    uuid: string
    
    userEmail: string;

    userMobile: string;

    userFullName: string;

    userDetail: UserDetail;
}

export class UserDetail {
    udUuid: string;

    address: Address[];

    profileImage: string;

    provider:string;
}

export class UserUpdate {
    uuid: string
    
    newEmail: string;

    newMobileNumber: string;

    userFullName: string;

    password: string;
	
}
