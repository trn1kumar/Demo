
/* Modules */
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { JwtModule } from '@auth0/angular-jwt';
import { CoreRoutingModule } from './core-routing.module';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

/* Services */
import { SnackBarConfig } from './services/extra/snackbar.config';
import { BusinessCartService } from './services/cart/business-cart.service';
import { BusinessCircleService } from './services/circle/business-circle.service';
import { Interceptor } from './interceptor/request.interceptor';
import { ProductService } from './services/product/product.service';
import { JwtTokenService } from './services/token/jwt-token.service';
import { TokenStorageService } from './services/token/token-storage.service';
import { HomePageService } from './services/home-page/home-page.service';
import { MatDailogService } from './services/extra/matdialog.config';
import { SmeInfoService } from './services/sme-page/sme-info.service';
import { SmeHomePageService } from './services/sme-page/sme-home-page.service';
import { UserService } from './services/user/user.service';

export function tokenGetter() {
  return localStorage.getItem('AuthToken');
}

@NgModule({
  imports: [
    CommonModule,
    CoreRoutingModule,
    JwtModule.forRoot({config :{tokenGetter : tokenGetter}}),
  ],
  declarations: [

  ],
  providers :[
    {
      provide: HTTP_INTERCEPTORS,
      useClass: Interceptor,
      multi: true
    },
    SnackBarConfig,
    BusinessCartService,
    BusinessCircleService,
    ProductService,
    JwtTokenService,
    TokenStorageService,
    HomePageService,
    MatDailogService,
    SmeInfoService,
    SmeHomePageService,
    UserService,
  ],
})
export class CoreModule { }
