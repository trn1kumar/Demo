import { TestBed, inject } from '@angular/core/testing';

import { FileSizeFormatService } from './file-size-format.service';

describe('FileSizeFormatService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FileSizeFormatService]
    });
  });

  it('should be created', inject([FileSizeFormatService], (service: FileSizeFormatService) => {
    expect(service).toBeTruthy();
  }));
});
