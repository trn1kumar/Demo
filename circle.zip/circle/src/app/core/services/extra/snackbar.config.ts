import {
    MatSnackBar,
    MatSnackBarConfig,
    MatSnackBarHorizontalPosition,
    MatSnackBarVerticalPosition,
} from '@angular/material';
import { Injectable } from '@angular/core';

@Injectable()
export class SnackBarConfig {

    constructor() { }

    horizontalPosition: MatSnackBarHorizontalPosition = 'center';
    verticalPosition: MatSnackBarVerticalPosition = 'top';
    duration: number = 2000;

    // customized snackbar
    getSnackBarConfig() {
        let config = new MatSnackBarConfig();

        config.duration = this.duration;
        config.verticalPosition = this.verticalPosition;
        config.horizontalPosition = this.horizontalPosition;
        config.panelClass = ['snackbar-class']

        return config;
    }

}