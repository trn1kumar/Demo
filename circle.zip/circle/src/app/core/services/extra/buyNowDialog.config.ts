import { MatDialogRef, MatDialogConfig, MatDialog } from "@angular/material";
import { Injectable } from "@angular/core";
import { BuyNowComponent } from "src/app/modules/shared/components/buy-now/buy-now.component";

@Injectable()
export class BuyNowDialog {
    buyNowDialogRef: MatDialogRef<BuyNowComponent>;

    private dialogConfig = new MatDialogConfig();


    constructor(private matDialog: MatDialog) {
        this.dialogConfig.autoFocus = false;
        this.dialogConfig.disableClose = true
        this.dialogConfig.width = '400px';
    }


    openbuyNowDialog() {
        this.buyNowDialogRef = this.matDialog.open(BuyNowComponent, this.dialogConfig)

        return this.buyNowDialogRef
    }
}