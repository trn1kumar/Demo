import { Injectable } from '@angular/core';
import { MatDialogRef, MatDialogConfig, MatDialog } from '@angular/material';
import { Observable } from 'rxjs';
import { LoginComponent } from 'src/app/modules/auth/login/login.component';

@Injectable()
export class MatDailogService {

    loginDialogRef : MatDialogRef<LoginComponent>;

    private dialogConfig = new MatDialogConfig();

    constructor(private matDialog : MatDialog){
        this.dialogConfig.autoFocus = false
        this.dialogConfig.width = '400px'
        this.dialogConfig.height= '560px'
       
    }

    openLoginDialog() {
        
        this.loginDialogRef = this.matDialog.open(LoginComponent , this.dialogConfig)
      
        return this.loginDialogRef
    }
    
}