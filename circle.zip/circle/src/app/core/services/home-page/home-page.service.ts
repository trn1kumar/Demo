import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from '../../models/product';
import { RestURL } from '../../models/rest-api-url';
import { SMECircleDto } from '../../models/business-circle';
import { shareReplay } from 'rxjs/operators';
import { VacancyFilter } from '../../models/jobPost';
import { SMECategoryDto } from '../../models/sme-information';

const CACHE_SIZE = 1;

@Injectable({
  providedIn: 'root'
})
export class HomePageService {

  private homePageProduct$: Observable<Array<Product>>
  private homePageSMEs$: Observable<Array<SMECircleDto>>
  private categories$: Observable<any>
  private serviceCategories$: Observable<any>
  private vacacncyCategories$: Observable<VacancyFilter>
  private smeCategories$:Observable<Array<SMECategoryDto>>
    
  
  private sliderImages$: Observable<any>
  private smefacelogo$: Observable<any>
  private productAllCategories: Observable<any>
  private serviceAllCategories: Observable<any>
  private vacancyAllCategories: Observable<any>
  
  constructor(private http: HttpClient) { }

  public products(): Observable<any> {
    if (!this.homePageProduct$) {
      this.homePageProduct$ = this.http.get<Array<Product>>(RestURL.productURL + 'active').pipe(
        shareReplay(CACHE_SIZE)
      )
    }
    return this.homePageProduct$
  }
  public productsForUserType(userUUID): Observable<any> {
    if (!this.homePageProduct$) {
      this.homePageProduct$ = this.http.get<Array<Product>>(RestURL.productURL + 'active', { params: { u: userUUID } }).pipe(
        shareReplay(CACHE_SIZE)
      )
    }
    return this.homePageProduct$
  }
  public productsForSMEType(userUUID, sUuid): Observable<any> {
    if (!this.homePageProduct$) {
      this.homePageProduct$ = this.http.get<Array<Product>>(RestURL.productURL + 'active', { params: { u: userUUID, s: sUuid } }).pipe(
        shareReplay(CACHE_SIZE)
      )
    }
    return this.homePageProduct$
  }

  public smeForUserType(userUUID:string):Observable<any>
  {
    if (!this.homePageSMEs$) {
      this.homePageSMEs$ = this.http.get<Array<SMECircleDto>>(RestURL.circleURL + userUUID + "/smes").pipe(
        shareReplay(CACHE_SIZE)
      )
    }
    return this.homePageSMEs$
  }

  public smesForSmeType(sUuid: string): Observable<any> {
    if (!this.homePageSMEs$) {
      this.homePageSMEs$ = this.http.get<Array<SMECircleDto>>(RestURL.circleURL + sUuid + "/smes").pipe(
        shareReplay(CACHE_SIZE)
      )
    }
    return this.homePageSMEs$
  }

  public sme(): Observable<any> {
    if (!this.homePageSMEs$) {
      this.homePageSMEs$ = this.http.get<Array<SMECircleDto>>(RestURL.smeInformartionURL).pipe(
        shareReplay(CACHE_SIZE)
      )
    }
    return this.homePageSMEs$
  }

  public categories(): Observable<any> {
    if (!this.categories$) {
      this.categories$ = this.http.get(RestURL.categoryURL + '/' + 'categories-and-sub').pipe(
        shareReplay(CACHE_SIZE)
      )
    }
    return this.categories$
  }

  public serviceCategories(): Observable<any> {
    if (!this.serviceCategories$) {
      this.serviceCategories$ = this.http.get(RestURL.serviceURL + 'categories').pipe(
        shareReplay(CACHE_SIZE)
      )
    }
    return this.serviceCategories$
  }

  public vacancyCategories(): Observable<any> {
    if (!this.vacacncyCategories$) {
      this.vacacncyCategories$ = this.http.get(RestURL.jobPostUrl + 'filter').pipe(
        shareReplay(CACHE_SIZE)
      )
    }
    return this.vacacncyCategories$
  }

  public smeCategories():Observable<any>{
    if(!this.smeCategories$)
    {
      this.smeCategories$ = this.http.get<Array<SMECategoryDto>>(RestURL.smeInformartionURL+'categories').pipe(
        shareReplay(CACHE_SIZE)
      )
    }
    return this.smeCategories$
  }

  public getHomeSliderImage(): Observable<any> {
    if (!this.sliderImages$) {
      this.sliderImages$ = this.http.get(RestURL.adminURL + 'image').pipe(
        shareReplay(CACHE_SIZE)
      )
    }
    return this.sliderImages$;
  }
  public getSmefaceLogo(): Observable<any> {
    if (!this.smefacelogo$) {
      this.smefacelogo$ = this.http.get(RestURL.adminURL + 'logo-image').pipe(
        shareReplay(CACHE_SIZE)
      )
    }
    return this.smefacelogo$;
  }

  public getProductAllCategories(): Observable<any> {
    if (!this.productAllCategories) {
      this.productAllCategories = this.http.get(RestURL.categoryURL + '/' + 'categories-and-sub').pipe(
        shareReplay(CACHE_SIZE))
    }
    return this.productAllCategories;
  }

  public getServiceAllCategories(): Observable<any> {
    if (!this.serviceAllCategories) {
      this.serviceAllCategories = this.http.get(RestURL.serviceURL + 'categories').pipe(
        shareReplay(CACHE_SIZE))
    }
    return this.serviceAllCategories;
  }
}
