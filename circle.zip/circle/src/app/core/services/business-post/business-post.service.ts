import { Injectable } from '@angular/core';
import { RestURL } from '../../models/rest-api-url';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BusinessPost } from '../../models/business-post';


@Injectable({
  providedIn: 'root'
})
export class BusinessPostService {

  private url=RestURL.businessPostURL
  constructor(private http:HttpClient) { }

  public businessPost(formData):Observable<any>
  {
    console.log('form data',formData)
    return this.http.post(this.url+'feed',formData,{observe:'response'})
  }

  public getAllFeeds(sUuid:string):Observable<any>
  {
    return this.http.get(this.url+sUuid+'/feeds',{observe:'response'})
  }

  public getAllFeedsforView(viewerSmeId:string,loggedInSmeId:string):Observable<any>
  {
    return this.http.get(this.url+viewerSmeId+'/feeds',{ params:{id:loggedInSmeId},observe:'response'})
  }

  public deleteFeed(feedId):Observable<any>
  {
    return this.http.delete(this.url+feedId+'/feed')
  }

  public deleteImage(fileLocation:string):Observable<any>
  {
    return this.http.delete(this.url+fileLocation)
  }

}
