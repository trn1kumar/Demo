import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RestURL } from '../../models/rest-api-url';
import { Observable } from 'rxjs';
import { retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class JobPostingService {

  private url = RestURL.jobPostUrl
  private url2 = RestURL.BASE_URL;
  constructor(private http:HttpClient) { }

  public postJob(formData):Observable<any>
  {
    return this.http.post(this.url,formData,{observe:'response'})
  }

  public getJobsBySmeId(sUuid:string,status:string):Observable<any>
  {
    if(status == null)
    {
      return  this.http.get(this.url+sUuid+'/sme')

    }
    return  this.http.get(this.url+sUuid+'/sme',{params:{status:status}})
  }

  public getJobsByJobUuid(jobUuid:string):Observable<any>
  {
    return  this.http.get(this.url+''+'/sme/'+jobUuid+'/vacancy')
  }

  public getAllJobs(url:string):Observable<any>
  {
    return this.http.get(this.url2+url)
  }
  // public getAllJobs(jobRoleMap: string[],jobLocationMap: string[], jobExperienceMap:string[],jobSmeMap: string[]):Observable<any>
  // {
  //   return this.http.get(this.url,{params:{jobRoleMap:jobRoleMap,jobLocationMap:jobLocationMap,jobExperienceMap:jobExperienceMap,jobSmeMap:jobSmeMap}})
  // }
  
  public uploadApplicantForm(sUuid:string,vacancyUuid:string,uploadFormData):Observable<any>
  {

    return this.http.post(this.url +' '+'/apply/'+sUuid+'/sme/'+vacancyUuid+'/vacancy',uploadFormData)
  }

  public getAppliedPeople(vacancyUuid:string):Observable<any>
  {
    return this.http.get(this.url+'loginsmeid'+'/sme/'+vacancyUuid+'/vacancy/job-applicant')
  }

  public getJobFilter():Observable<any>
  {
    return this.http.get(this.url+'filter')
  }
}
