import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { RestURL } from '../../models/rest-api-url';
import { Product } from '../../models/product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private url = RestURL.productURL
  private headers = new HttpHeaders({
    'Content-Type': 'application/json',
  })

  constructor(private http: HttpClient) { }

  public productByUuid(uuid): Observable<Product> {
    return this.http.get<Product>(this.url + uuid + '/product')
  }

  public getProduct(uuid,sUuid): Observable<Product> {
    return this.http.get<Product>(this.url + sUuid + '/' + uuid )
  }


  public addProduct(productData): Observable<any> {
    return this.http.post(this.url + 'product', productData, { observe: 'response' })
  }

  public updateProduct(products): Observable<any> {
    return this.http.put(this.url + 'update', products)
  }

  public productByURL(url: string): Observable<any> {
    return this.http.get<Array<Product>>(RestURL.categoryURL + url)
  }

  public removeProduct(productUuid): Observable<any> {
    return this.http.delete(this.url + productUuid)
  }

  public products(): Observable<any> {
    return this.http.get<Array<Product>>(this.url + 'active')
  }

  public searchText(searchRequest: any): Observable<any> {
    return this.http.post<Array<Product>>(RestURL.searchURL,
      searchRequest,
      { observe: 'response', headers: this.headers })
  }

  public getSimillarProducts(productName, subCategoryName): Observable<any> {
    return this.http.get<Array<Product>>(RestURL.categoryURL + '/similar', { params: { s: subCategoryName, p: productName } })
  }

  public getSubCategorySpecifications(uuid: string): Observable<any> {
    return this.http.get(RestURL.categoryURL + '/getMaster/' + uuid)
  }

  public getPriceUnitNames(): Observable<any>{
    return this.http.get(this.url + 'price')
  }
}
