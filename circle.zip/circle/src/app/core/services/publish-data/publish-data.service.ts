import { Injectable } from '@angular/core';
import { RestURL } from '../../models/rest-api-url';
import { HttpClient } from '../../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../../node_modules/rxjs';
import { PublishData } from '../../models/publish-data';

@Injectable({
  providedIn: 'root'
})
export class PublishDataService {

  private smeUrl = RestURL.smeInformartionURL
  private productUrl=RestURL.productURL
  private serviceURL=RestURL.serviceURL
  private jobPostUrl=RestURL.jobPostUrl
  constructor(private http:HttpClient) { }

  public publishSmeInfo(sUuid:string,publishData :Array<PublishData>,source:string):Observable<any>
  {
    return this.http.put(this.smeUrl+sUuid+'/'+source,publishData)
  }

  public publishProduct(sUuid:string,publishData :Array<PublishData>):Observable<any>
  {
    return this.http.put(this.productUrl+sUuid+'/change/status',publishData)
  }

  public publishService(sUuid:string,publishData :Array<PublishData>):Observable<any>
  {
    return this.http.put(this.serviceURL+sUuid+'/service',publishData)
  }

  public publishVacancy(sUuid:string,publishData :Array<PublishData>):Observable<any>
  {
    return this.http.put(this.jobPostUrl+sUuid+'/sme/'+' '+'/vacancy',publishData)
  }
}
