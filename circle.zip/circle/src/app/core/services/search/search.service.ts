import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { RestURL } from '../../models/rest-api-url';

@Injectable({
  providedIn: 'root'
})
export class SearchService {

  private url = RestURL.searchURL

  private headers = new HttpHeaders ({
    'Content-Type' : 'application/json',
  })

  constructor(private http : HttpClient) { }

  public searchSuggest(request) : Observable<any> {
    return this.http.post<string[]>(this.url + 'auto-suggest' , 
      request , 
      { observe : 'response' , headers : this.headers })
  }

}
