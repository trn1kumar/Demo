import { TestBed, inject } from '@angular/core/testing';

import { SmeHomePageService } from './sme-home-page.service';

describe('SmeHomePageService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SmeHomePageService]
    });
  });

  it('should be created', inject([SmeHomePageService], (service: SmeHomePageService) => {
    expect(service).toBeTruthy();
  }));
});
