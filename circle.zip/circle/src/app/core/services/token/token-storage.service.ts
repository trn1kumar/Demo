import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

const TOKEN_KEY = 'AuthToken';
const ADMIN_TOKEN_KEY = 'AdminToken';
@Injectable({
  providedIn: 'root'
})
export class TokenStorageService {

  constructor(private router : Router) { }

  public saveToken(token: string) {
    localStorage.removeItem(TOKEN_KEY)
    localStorage.setItem(TOKEN_KEY, token)
  }

  public getToken(): string {
    return localStorage.getItem(TOKEN_KEY);
  }

  public saveAdminToken(adminToken: string) {
    localStorage.removeItem(ADMIN_TOKEN_KEY)
    localStorage.setItem(ADMIN_TOKEN_KEY, adminToken)
  }

  public getAdminToken(): string {
    return localStorage.getItem(ADMIN_TOKEN_KEY);
  }



  public isLoggedIn(){
    return this.getToken() !==null
  }

  public isAdminLoggedIn()
  {
    return this.getAdminToken() !==null
  }
  
  public logout() {
    localStorage.clear()
  }
}
