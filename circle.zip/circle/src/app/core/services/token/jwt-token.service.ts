 import { Injectable } from '@angular/core';
import * as jwt_decode from 'jwt-decode';

@Injectable({
  providedIn: 'root'
})
export class JwtTokenService {

  constructor() { }

  // Decode jwt token and return object 
  getDecodedAccessToken(token: string): any {
    try {
      return jwt_decode(token);
    }
    catch (Error) {
      return false;
    }
  }

  // get user name
  getUserName(): string {
    let tokenInfo = this.getDecodedAccessToken(localStorage.getItem("AuthToken"));
    return tokenInfo.name
  }

  // get role
  getUserRole(): string {
    let tokenInfo = this.getDecodedAccessToken(localStorage.getItem("AuthToken"));
    return tokenInfo.smeface
  }

  // get uuid
  getUserId() {
    let tokenInfo = this.getDecodedAccessToken(localStorage.getItem("AuthToken"));
    return tokenInfo.uuid
  }

  // get user type SME or Normal user
  // if NORMAL user then return True
  getUserType() {
    let tokenInfo = this.getDecodedAccessToken(localStorage.getItem("AuthToken"));

    if (tokenInfo.usertype == 'NORMAL') {
      return true
    }
    else {
      return false
    }
  }
  
}
