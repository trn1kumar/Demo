import { Injectable } from '@angular/core';
import { RestURL } from '../../models/rest-api-url';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User, UserUpdate } from '../../models/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private url = RestURL.authURL;

  constructor(private http:HttpClient) { }

  public getUserProfile(uid):Observable<any>
  {
    return this.http.get(this.url + uid)
  }

  public uploadProfileImage(userId:string,uploadFormData):Observable<any>
  {
    return this.http.post(this.url + userId + '/user/upload/profile-image',uploadFormData)
  }

  public updateFullName(userUpdateObj:UserUpdate):Observable<any>
  {
    return this.http.put(this.url + ' '+'/full-name',userUpdateObj)
  }

  public sendOtp(userUpdateObj:UserUpdate):Observable<any>
  {
    return this.http.post(this.url + 'send/otp',userUpdateObj,{observe:'response'})
  }

  public updateEmail(userUpdateObj:UserUpdate):Observable<any>
  {
    console.log(userUpdateObj)
    return this.http.put(this.url + ' '+'/email',userUpdateObj,{observe:'response'})
  }

  public removeProfileImage(uuid:string):Observable<any>
  {
    return this.http.delete(this.url+uuid+'/user/remove/profile-image') 
  }

  
  public getUserProfileCompletionStatus(uuid:string):Observable<any>
  {
    return this.http.get(this.url+uuid+'/profile/percentage') 
  }

}
