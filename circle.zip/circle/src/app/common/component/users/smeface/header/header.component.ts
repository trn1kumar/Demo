import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import * as fromRoot from '../../../../../app.reducers'
import { User, UserUpdate } from 'src/app/core/models/user';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { TokenStorageService } from 'src/app/core/services/token/token-storage.service';
import { MatDailogService } from 'src/app/core/services/extra/matdialog.config';
import { BusinessCartService } from 'src/app/core/services/cart/business-cart.service';
import { UserService } from 'src/app/core/services/user/user.service';
import { getTotalCartCount } from 'src/app/modules/home/reducers/home.selector';
import { RestURL } from 'src/app/core/models/rest-api-url';
import { MatDialogConfig } from '@angular/material';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  selected = "All";
  uuid:string
  user$ : Observable<User>
  totalCartCount : number
  searchCatagory:any;
  searchCatagoryArr = ["product", "services", "sme"];
  constructor(public jwtToken : JwtTokenService, public token : TokenStorageService ,
    private matDialogService : MatDailogService ,private dialogService: MatDailogService, private router : Router,
    private cartService : BusinessCartService,private userService:UserService,
    private store: Store<fromRoot.AppState> ) { }

  ngOnInit() {
    this.searchCatagory= "All";
    if(this.token.isLoggedIn()){
      this.uuid = this.jwtToken.getUserId();
      this.user$ = this.userService.getUserProfile(this.uuid)
    }
    this.cartService.cartCount(this.jwtToken.getUserId())
    this.store.select(getTotalCartCount).subscribe(
      res => {
        this.totalCartCount = res
        }
      )
    
     
  }

  selectCatagory(val){
    this.searchCatagory = val;
    console.log(val)
  }
  


  openLoginDialog(){
    this.matDialogService.openLoginDialog()
  }
  
  logout(){
    window.location.reload()
    this.token.logout()
    this.router.navigate([''])
  }

  editProfile(){
    this.router.navigate([''])
  }
  getImage(imageName) {
    return RestURL.contentServerUrl + (imageName);
  }
  onListSmeface()
  {
    if (!this.token.isLoggedIn()) {
      const dialogRef = this.dialogService.openLoginDialog()
      dialogRef.afterClosed().subscribe(
        res => {
          if (this.token.isLoggedIn()) {
            this.router.navigateByUrl('/sme/list-sme')
          }
        }
      )
    }

}

scrolltoTop(){
  window.scrollTo(0,0)
}
}
