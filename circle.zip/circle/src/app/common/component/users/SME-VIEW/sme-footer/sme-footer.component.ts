import { Component, OnInit, Input } from '@angular/core';
import { SMEInformation } from 'src/app/core/models/sme-information';
import { RestURL } from 'src/app/core/models/rest-api-url';


@Component({
  selector: 'app-sme-footer',
  templateUrl: './sme-footer.component.html',
  styleUrls: ['./sme-footer.component.css']
})
export class SmeFooterComponent implements OnInit {
  
  @Input()
  smeInfo : SMEInformation

  constructor() { }

  ngOnInit() {
  }

  getImage(imageName){
    if(imageName != null){
      return RestURL.contentServerUrl+(imageName);
    }else
    return "/assets/not-found/not-available.jpeg"
  }

}
