import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SmeHeaderComponent } from './sme-header.component';

describe('SmeHeaderComponent', () => {
  let component: SmeHeaderComponent;
  let fixture: ComponentFixture<SmeHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SmeHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SmeHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
