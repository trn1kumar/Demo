import * as $ from 'jquery';
import { Component, Inject } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MatSnackBar, MAT_DIALOG_DATA } from '@angular/material';
import { SignUpService } from 'src/app/core/services/auth/sign-up.service';
import { Router } from '@angular/router';
import { TokenStorageService } from 'src/app/core/services/token/token-storage.service';
import { SnackBarConfig } from 'src/app/core/services/extra/snackbar.config';
@Component({
    template: `
    <h2>
     <a href matTooltip="Close" onclick="return false" (click)="close()" style="float:right ; color : rgb(43, 43, 192)">
        <mat-icon>close</mat-icon>
     </a>
    </h2>
    <mat-dialog-content *ngIf="data">
        <div>
            <span id="subtitle">
                OTP sent on 
                <strong *ngIf="data.newMobileNumber"><font>{{data.newMobileNumber}}</font></strong>
                <strong *ngIf="data.newEmail"> and <font>{{data.newEmail}}</font></strong>
            </span>
        </div>
        <form id="myform" [formGroup]="verifyOtpForm" (ngSubmit)="verifyOTP(verifyOtpForm.value)" class="example-form">
        
                <div class="form-group" style="padding-top: 30px">
                <table class="example-full-width" cellspacing="0">
                <tr>
                    <td>
                    <mat-form-field class="example-full-width">
                        <input #idotp matInput placeholder="Enter OTP (3 Digits only)" formControlName="otp" minlength="3"
                        maxlength="3" required>
                    </mat-form-field>
                    </td>
                    <td>
                    <a id="resendLink" href onclick="return false;" (click)="resendOTP()">Resend?</a>
                    </td>
                </tr>
                <tr></tr>
                <tr>
                    <td>
                    <p id="waitingmsg">
                        <font style="color:3F52B1">{{waitingMsg}}</font>
                    </p>
                    </td>
                </tr>
                </table>
            </div>
                <div style="padding-top: 15px">
                    <button type="submit" mat-raised-button color="primary" style="width: 30%">Verify</button>
                </div>
        </form>
    </mat-dialog-content>
    `,
    styles: [`
    #subtitle{
        font-family: serif;
        font-size: 17px;
    },
    #myform{
        text-align: center;
    },
    a {  
        color : #3F52B1;
    },
    font{
        color: rgb(235, 85, 85)
    },
    #title{
        font-family: serif;
        font-size: 25px;
    },
    #subtitle{
        font-family: serif;
        font-size: 17px;
    },
    .example-form {
        min-width: 150px;
        max-width: 500px;
        width: 100%;
    },
    .example-full-width {
        width: 100%;
    },
    `]
})

export class OtpVerifyAdminPage {

    showUserEmail = false
    verifyOtpForm: FormGroup;
    count: number = 0;
    waitingMsg: string = "You can Resend OTP after 5 seconds";
    constructor(private dialogRef: MatDialogRef<OtpVerifyAdminPage>,
        private formBuilder:FormBuilder,private snackBar: MatSnackBar,
         private signupService: SignUpService,private router:Router,private token: TokenStorageService,private snackBarConfig : SnackBarConfig,@Inject(MAT_DIALOG_DATA) public data: any) { 
             console.log('dialog data',data)
         }

    ngOnInit() {

        $('#waitingmsg').hide();
    
        this.verifyOtpForm = this.formBuilder.group({
          uuid: new FormControl(this.data.uuid),
          otp: new FormControl('', [Validators.required, Validators.pattern('[0-9]+')])
        })
    }
    close() {
        this.dialogRef.close()
    }
    resendOTP(){

        if(this.data.uuid != null){
    
          ++this.count
    
          if(this.count >= 5){
            $('#resendLink').hide().delay(5000).show(0)
            this.count = 0
            $('#waitingmsg').show().delay(5000).hide(0)
          }
    
          this.signupService.resendOTP(this.data.uuid).subscribe(
            res => {
              this.snackBar.open('OTP resend successfully !!','',this.snackBarConfig.getSnackBarConfig())
            }
         )
        }
      }
      verifyOTP(enteredOTP){

        if(this.verifyOtpForm.valid && this.data.uuid != null){
    
          this.signupService.verifyOTP(enteredOTP,null).subscribe(
            res => {
                console.log('verify')
              this.snackBar.open('OTP verified successfully !!','',this.snackBarConfig.getSnackBarConfig())
              this.token.saveAdminToken(res.body.token)
              this.dialogRef.close()
              this.router.navigateByUrl('/sme/admin')
            },
            err => {
              this.snackBar.open("Please enter valid OTP","Ok",this.snackBarConfig.getSnackBarConfig())
              this.verifyOtpForm.controls['otp'].setErrors({
                'wrongOTP' : true
              })
            }
          )
        }
      }
}