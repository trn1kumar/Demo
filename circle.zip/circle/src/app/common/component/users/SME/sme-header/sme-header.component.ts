import { Component, OnInit, Input } from '@angular/core';
import {MatDialogRef, MatDialogConfig, MatDialog } from '@angular/material';
import { OtpVerifyAdminPage } from './otp-verify-dialog.component';
import { SMEInformation } from 'src/app/core/models/sme-information';
import { UserUpdate } from 'src/app/core/models/user';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { UserService } from 'src/app/core/services/user/user.service';
import { TokenStorageService } from 'src/app/core/services/token/token-storage.service';
import { RestURL } from 'src/app/core/models/rest-api-url';


@Component({
  selector: 'app-sme-header',
  templateUrl: './sme-header.component.html',
  styleUrls: ['./sme-header.component.css']
})
export class SmeHeaderComponent implements OnInit {

  @Input()
  smeInfo : SMEInformation

  @Input()
  totalCartCount: number
  userUpdate:UserUpdate
  otpDialogRef : MatDialogRef<OtpVerifyAdminPage>
  constructor(public jwtToken : JwtTokenService,public userService:UserService, public token : TokenStorageService,private matDialog : MatDialog) { }

  ngOnInit() {
    if(this.smeInfo){
      localStorage.setItem('smeName' ,this.smeInfo.smeName)
    }
  }
  scrolltoTop(){
    window.scrollTo(0,0)
  }
  getImage(imageName){
    if(imageName != null){
      return RestURL.contentServerUrl+(imageName);
    }else
    return "/assets/not-found/not-available.jpeg"
  }

  onAdminClick()
  {
    let uuid=this.jwtToken.getUserId();

    let userUuid=new UserUpdate();
    userUuid.uuid=uuid
    
   
   this.userService.sendOtp(userUuid).subscribe(
     res=>
     {
       sessionStorage.clear();
      //  sessionStorage.setItem('uuid',btoa(uuid))
        this.userUpdate=res.body
        console.log('userUpdate',this.userUpdate)
        console.log('otp',res)
        this.openOtpDialog(this.userUpdate)
     }
   )
     
  }
  openOtpDialog(userUpdate:UserUpdate){
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false
    dialogConfig.width = '400px'
    dialogConfig.data=userUpdate
    this.otpDialogRef = this.matDialog.open(OtpVerifyAdminPage ,dialogConfig)
  }

  logout(){
    window.location.reload()
    this.token.logout()
  }
}
