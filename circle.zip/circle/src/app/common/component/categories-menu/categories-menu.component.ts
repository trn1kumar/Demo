import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { HomePageService } from 'src/app/core/services/home-page/home-page.service';
import { VacancyFilter } from 'src/app/core/models/jobPost';
import { SMECategoryDto } from 'src/app/core/models/sme-information';

@Component({
  selector: 'app-categories-menu',
  templateUrl: './categories-menu.component.html',
  styleUrls: ['./categories-menu.component.css']
})
export class CategoriesMenuComponent implements OnInit {

  homepageSME$ : Observable<Array<SMECategoryDto>>
  homepageCategory$ : Observable<Array<any>>
  homePageServiceCategories$: Observable<Array<any>>
  homePageVacancyCategories$:Observable<VacancyFilter>
  private serviceURL : string = 'services/c/'
  private smeURL : string = 'sme/'
  
  constructor(private homePageService : HomePageService,private  router:Router) { }

  ngOnInit() {
    this.homepageSME$ = this.homePageService.smeCategories()
    this.homepageCategory$ = this.homePageService.categories()
    this.homePageServiceCategories$ = this.homePageService.serviceCategories()
    this.homePageVacancyCategories$ = this.homePageService.vacancyCategories();
  }

  smeNameClick(sUuid){
    let url =  'sme/' + sUuid
    window.open(url,'_blank')
  }

  productClick(name){
    this.router.navigateByUrl(name)
  }

  serviceClick(name){
    this.router.navigateByUrl(this.serviceURL+name)
  }


}
