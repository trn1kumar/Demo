import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/modules/shared/shared.module';
import { SmeHeaderComponent } from 'src/app/common/component/users/SME-VIEW/sme-header/sme-header.component';
import { SmeFooterComponent } from 'src/app/common/component/users/SME-VIEW/sme-footer/sme-footer.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    SharedModule
  ],
  declarations: [
    SmeHeaderComponent,
    SmeFooterComponent
  ],
  exports:[
    SmeHeaderComponent,
    SmeFooterComponent
  ]
})
export class SmeViewLayoutModule { }
