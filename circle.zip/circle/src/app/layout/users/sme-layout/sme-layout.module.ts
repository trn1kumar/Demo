/* Modules */
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/modules/shared/shared.module';
import { SmeHeaderComponent } from 'src/app/common/component/users/SME/sme-header/sme-header.component';
import { SmeFooterComponent } from 'src/app/common/component/users/SME/sme-footer/sme-footer.component';
import { OtpVerifyAdminPage } from 'src/app/common/component/users/SME/sme-header/otp-verify-dialog.component';


@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    SharedModule
  ],
  declarations: [
    SmeHeaderComponent,
    SmeFooterComponent,
    OtpVerifyAdminPage
  ],
  exports:[
    SmeHeaderComponent,
    SmeFooterComponent,
    OtpVerifyAdminPage
  ],
  entryComponents:[OtpVerifyAdminPage]

})
export class SMELayoutModule { }
