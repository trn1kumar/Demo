
/* Modules */
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

/* Components */
import { HeaderComponent } from '../../../common/component/users/smeface/header/header.component';
import { FooterComponent } from '../../../common/component/users/smeface/footer/footer.component';
import { CategoriesMenuComponent } from '../../../common/component/categories-menu/categories-menu.component';

import { AuthModule } from 'src/app/modules/auth/auth.module';
import { SharedModule } from 'src/app/modules/shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    AuthModule,
    SharedModule
  ],
  declarations: [
    HeaderComponent,
    FooterComponent,
    CategoriesMenuComponent,
  ],
  exports: [
    HeaderComponent,
    FooterComponent,
    CategoriesMenuComponent
  ],
  providers: [
  ]
})
export class LayoutModule { }
