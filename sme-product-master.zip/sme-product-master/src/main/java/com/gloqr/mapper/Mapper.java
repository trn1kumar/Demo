package com.gloqr.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.gloqr.constants.ProductState;
import com.gloqr.dto.ProductDTO;
import com.gloqr.entity.Product;
import com.gloqr.exception.CustomException;
import com.gloqr.util.CustomGenerator;

@Component
public class Mapper {

	@Autowired
	private CustomGenerator generator;

	public <T> T convertToEntity(Object srcObj, Class<T> targetClass) {
		T entity = null;

		try {
			entity = new ModelMapper().map(srcObj, targetClass);
		} catch (Exception e) {
			throw new CustomException("Error while converting DTO to Entity", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return entity;
	}

	public <T> T convertToDto(Object srcObj, Class<T> targetClass) {
		T dto = null;

		try {
			dto = new ModelMapper().map(srcObj, targetClass);
		} catch (Exception e) {
			throw new CustomException("Error while converting Entity to DTO", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return dto;
	}

	public void modifyExistingProduct(Product existingproduct, ProductDTO productDTO) {
		existingproduct.setProductName(productDTO.getProductName());
		existingproduct.setProductUrlName(generator.filterName(productDTO.getProductName()));

		existingproduct.setPrice(productDTO.getPrice());
		existingproduct.setPriceUnit(productDTO.getPriceUnit());
		if (productDTO.getDiscount() != 0) {
			existingproduct.setDiscountedPrice(
					productDTO.getPrice() - ((productDTO.getPrice() * productDTO.getDiscount()) / 100));
		} else {
			existingproduct.setDiscountedPrice(productDTO.getPrice());
		}
		existingproduct.setStock(productDTO.getStock());
		existingproduct.setMinOrderQty(productDTO.getMinOrderQty());
		existingproduct.setDescription(productDTO.getDescription());
		existingproduct.setLocation(productDTO.getLocation());
		existingproduct.setActive(productDTO.isActive());
		existingproduct.setProductState(ProductState.PENDING);
		existingproduct.setGst(productDTO.getGst());
		existingproduct.setTermsAndCondition(productDTO.getTermsAndCondition());
		existingproduct.setQuotationFormat(productDTO.getQuotationFormat());
		existingproduct.setModified(true);
		existingproduct.setAutoQuotation(productDTO.isAutoQuotation());

		if (existingproduct.getSpecifications() != null) {
			existingproduct.getSpecifications().clear();
		}

		existingproduct.setSpecifications(productDTO.getSpecifications());
	}
}
