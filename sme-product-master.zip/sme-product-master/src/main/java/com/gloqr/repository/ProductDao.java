package com.gloqr.repository;

import java.util.List;

import com.gloqr.dto.ProductVO;
import com.gloqr.entity.Product;
import com.gloqr.responses.ProductDetails;
import com.gloqr.responses.ProductResponse;
import com.gloqr.responses.SingleProduct;

public interface ProductDao {

	List<ProductResponse> topProducts(int page);

	ProductDetails productByUuid(String productUuid);

	void deleteProduct(String productUuid, String suuid);

	void evictTopProducts();

	void saveProduct(Product product);

	void productBiCount(String productUuid);

	List<ProductVO> productsOfSME(String sUuid);

	List<SingleProduct> pendingProductsOfSME(String sUuid);

	void updateAutoQutationStatus(String productUuid, boolean autoQuotation, String getsUuid);

	SingleProduct productForUpdate(String productUuid);

}
