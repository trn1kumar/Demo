package com.gloqr.repository;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.constants.Constants;
import com.gloqr.constants.ProductState;
import com.gloqr.dto.ProductVO;
import com.gloqr.entity.Product;
import com.gloqr.entity.ProductImage;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.Mapper;
import com.gloqr.responses.ProductDetails;
import com.gloqr.responses.ProductResponse;
import com.gloqr.responses.SingleProduct;
import com.gloqr.service.PricingService;

@Repository
public class ProductDaoImpl implements ProductDao {

	Logger logger = LogManager.getLogger();

	@Autowired
	private ProductRepo productRepo;

	@Value("${products.page.limit}")
	private Integer pageLimit;

	@Autowired
	private Mapper mapper;

	@Autowired
	private PricingService pricingService;

	@Override
	@Cacheable(value = "topProducts", key = "#page")
	public List<ProductResponse> topProducts(int page) {

		if (page <= 0) {
			page = 1;
		}

		List<Product> products = productRepo.findByActiveTrueAndProductState(ProductState.APPROVED,
				PageRequest.of(--page, pageLimit, Sort.Direction.DESC, "biCount"));

		if (products != null) {
			List<ProductResponse> response = new ArrayList<>();
			products.stream().forEach(p -> response.add(mapper.convertToDto(p, ProductResponse.class)));

			return response;
		} else {
			throw new CustomException("Top products not Found", HttpStatus.NOT_FOUND);
		}

	}

	@Override
	@Cacheable(value = "productDto", key = "#productUuid")
	public ProductDetails productByUuid(String productUuid) {
		Product product = productRepo.findByProductUuid(productUuid);

		if (product != null && !product.getProductState().equals(ProductState.DELETED)) {
			return mapper.convertToDto(product, ProductDetails.class);
		} else {
			throw new CustomException("Product not found with id :: " + productUuid, HttpStatus.NOT_FOUND);
		}

	}

	@Override
	@Caching(evict = { @CacheEvict(value = { "smeProducts", "smePendingProducts" }, key = "#product.getsUuid()"),
			@CacheEvict(value = { "productDto", "productAllDetails" }, key = "#product.getProductUuid()") })
	public void saveProduct(Product product) {
		try {
			productRepo.save(product);
		} catch (Exception e) {
			throw new CustomException("Error Saving Product", e);
		}
	}

	@Override
	@Transactional
	@Caching(evict = { @CacheEvict(value = { "smeProducts", "smePendingProducts" }, key = "#suuid"),
			@CacheEvict(value = { "productDto", "productAllDetails" }, key = "#productUuid") })
	public void deleteProduct(String productUuid, String suuid) {
		Product product = productRepo.findByProductUuid(productUuid);

		if (product.getsUuid().equals(suuid) && !product.isActive()) {
			product.setProductState(ProductState.DELETED);
			productRepo.save(product);
		} else {
			throw new CustomException("Product not found for id :: " + productUuid + " & " + suuid,
					HttpStatus.NOT_FOUND);
		}

		pricingService.updateImageStorageCredits(product.getImages().stream().mapToLong(ProductImage::getSize).sum(),
				Constants.CREDIT, "Deleted Product Images for id :: " + product.getProductUuid());
	}

	@CacheEvict(value = { "topProducts" }, allEntries = true)
	@Override
	public void evictTopProducts() {
		logger.info("Evicted Top Products Cache");
	}

	@Override
	@Caching(evict = { @CacheEvict(value = { "productDto", "productAllDetails" }, key = "#productUuid"),
			@CacheEvict(value = "topProducts", allEntries = true) })
	public void productBiCount(String productUuid) {
		Product product = productRepo.findByProductUuid(productUuid);

		if (product != null) {
			product.setBiCount(product.getBiCount() + 1);
			try {
				productRepo.save(product);
			} catch (Exception e) {
				throw new CustomException("Error while updating BI Count of product id :: " + productUuid, e);
			}
		} else {
			logger.warn("Product Not Found for id :: " + productUuid);
		}

	}

	@Override
	@Cacheable(value = "smeProducts", key = "#sUuid")
	public List<ProductVO> productsOfSME(String sUuid) {

		List<Product> smeProducts = productRepo.findBySUuid(sUuid);

		if (smeProducts == null || smeProducts.isEmpty()) {
			throw new CustomException("Products not found for SME id :: " + sUuid, HttpStatus.NOT_FOUND);
		}

		List<ProductVO> products = new ArrayList<>();
		smeProducts.stream().forEach(p -> products.add(mapper.convertToDto(p, ProductVO.class)));

		return products;
	}

	@Override
	@Cacheable(value = "smePendingProducts", key = "#sUuid")
	public List<SingleProduct> pendingProductsOfSME(String sUuid) {
		List<Product> smeProducts = productRepo.findBySUuid(sUuid);

		if (smeProducts == null || smeProducts.isEmpty()) {
			throw new CustomException("Products not found for SME id :: " + sUuid, HttpStatus.NOT_FOUND);
		}

		List<SingleProduct> products = new ArrayList<>();
		smeProducts.stream().filter(f -> f.getProductState().equals(ProductState.PENDING) && f.isActive())
				.forEach(p -> products.add(mapper.convertToDto(p, SingleProduct.class)));

		if (products.isEmpty()) {
			throw new CustomException("Pending Products not found for SME id :: " + sUuid, HttpStatus.NOT_FOUND);
		}

		return products;
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "smeProducts", key = "#sUuid"),
			@CacheEvict(value = "productAllDetails", key = "#productUuid") })
	public void updateAutoQutationStatus(String productUuid, boolean autoQuotation, String sUuid) {
		productRepo.updateAutoQutationStatus(productUuid, autoQuotation);
	}

	@Override
	@Cacheable(value = "productAllDetails", key = "#productUuid")
	public SingleProduct productForUpdate(String productUuid) {
		Product product = productRepo.findByProductUuid(productUuid);

		if (product != null && !product.getProductState().equals(ProductState.DELETED)) {
			return mapper.convertToDto(product, SingleProduct.class);
		} else {
			throw new CustomException("Product not found with id :: " + productUuid, HttpStatus.NOT_FOUND);
		}
	}

}
