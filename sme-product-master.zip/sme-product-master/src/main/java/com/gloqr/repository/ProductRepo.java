package com.gloqr.repository;

import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gloqr.constants.ProductState;
import com.gloqr.dto.ItemCountUpdate;
import com.gloqr.entity.Product;

public interface ProductRepo extends JpaRepository<Product, Long> {

	@Query("SELECT new com.gloqr.dto.ItemCountUpdate(COUNT(CASE WHEN p.productState!='DELETED' THEN 1 END),COUNT(CASE WHEN p.active=1 AND p.productState='APPROVED' THEN 1 END) ,COUNT(CASE WHEN p.active=1 AND p.productState='PENDING' THEN 1 END)) FROM Product p where p.sUuid=:sUuid")
	ItemCountUpdate getCounts(@Param("sUuid") String sUuid);

	List<Product> findByActiveTrueAndProductState(ProductState productState, Pageable pageable);

	List<Product> findBySUuid(String sUuid);

	Product findByProductUuid(String productUuid);

	@Query("SELECT p.sUuid from Product p")
	Set<String> getSuuids();

	@Transactional
	@Modifying
	@Query("update Product p set p.autoQuotation= :autoQuotation where p.productUuid= :productUuid")
	void updateAutoQutationStatus(@Param("productUuid") String productUuid,
			@Param("autoQuotation") boolean autoQuotation);

	int countBySUuidAndProductStateIsNotIn(String sUuid, ProductState productState);

	int countBySUuidAndProductStateAndActiveTrue(String sUuid, ProductState productState);

	@Query(value = "SELECT FLOOR(MIN(p.discountedPrice)) FROM Product p JOIN "
			+ "p.subCategory sc JOIN sc.productCategory c " + "where c.categoryUuid=:categoryUuid AND c.active=true "
			+ "AND p.active=true AND p.productState=:productState")
	Double categoryMinPrice(@Param("categoryUuid") String categoryUuid,
			@Param("productState") ProductState productState);

	@Query(value = "SELECT CEIL(MAX(p.discountedPrice)) FROM Product p JOIN "
			+ "p.subCategory sc JOIN sc.productCategory c " + "where c.categoryUuid=:categoryUuid AND c.active=true "
			+ "AND p.active=true AND p.productState=:productState")
	Double categoryMaxPrice(@Param("categoryUuid") String categoryUuid,
			@Param("productState") ProductState productState);

	@Query(value = "SELECT FLOOR(MIN(p.discountedPrice)) FROM Product p JOIN p.subCategory sc "
			+ "where sc.subCategoryUuid=:subCategoryUuid AND sc.active=true "
			+ "AND p.active=true AND p.productState=:productState")
	Double subCategoryMinPrice(@Param("subCategoryUuid") String subCategoryUuid,
			@Param("productState") ProductState productState);

	@Query(value = "SELECT CEIL(MAX(p.discountedPrice)) FROM Product p JOIN p.subCategory sc "
			+ "where sc.subCategoryUuid=:subCategoryUuid AND sc.active=true "
			+ "AND p.active=true AND p.productState=:productState")
	Double subCategoryMaxPrice(@Param("subCategoryUuid") String subCategoryUuid,
			@Param("productState") ProductState productState);

}
