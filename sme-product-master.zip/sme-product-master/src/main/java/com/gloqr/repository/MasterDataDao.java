package com.gloqr.repository;

import java.util.List;
import java.util.Set;

import com.gloqr.dto.CategoryDTO;
import com.gloqr.dto.SubCategoryDTO;
import com.gloqr.entity.PriceUnit;

public interface MasterDataDao {

	Set<String> getSubCategorySpecifications(String subCategoryUuid);

	void savePriceUnits(Set<PriceUnit> priceUnits);

	Set<String> getPriceUnits();

	List<CategoryDTO> getCategories();

	CategoryDTO getCategory(String categoryUuid);

	void evictCategoryCache();

	SubCategoryDTO getSubCategory(String subCategoryUuid);

}
