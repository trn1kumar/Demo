package com.gloqr.repository;

import java.util.TreeSet;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.gloqr.entity.PriceUnit;

public interface PriceUnitRepo extends JpaRepository<PriceUnit, Long> {

	@Query(value = "SELECT price_unit_name FROM product_price_units", nativeQuery = true)
	TreeSet<String> getPriceUnits();
}
