package com.gloqr.repository;

import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gloqr.entity.ProductImage;

public interface ProductImageRepo extends JpaRepository<ProductImage, Long> {

	ProductImage findByFileLocation(String fileLocation);

	@Transactional
	@Modifying
	@Query("update ProductImage p set p.businessPostImage= true where p.fileLocation IN :fileLocation")
	public void updateBusinessPostImage(@Param("fileLocation") Set<String> fileLocations);

	void deleteByFileLocation(String fileLocation);
}
