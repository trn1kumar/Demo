package com.gloqr.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.dto.CategoryDTO;
import com.gloqr.dto.SubCategoryDTO;
import com.gloqr.entity.PriceUnit;
import com.gloqr.entity.ProductCategory;
import com.gloqr.entity.ProductSubCategory;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.Mapper;

@Repository
public class MasterDataDaoImpl implements MasterDataDao {

	Logger logger = LogManager.getLogger();

	@Autowired
	private CategoryRepo categoryRepo;

	@Autowired
	private SubCategoryRepo subCategoryRepo;

	@Autowired
	private PriceUnitRepo priceUnitRepo;

	@Autowired
	private Mapper mapper;

	@Override
	@Cacheable(value = "productCategories")
	public List<CategoryDTO> getCategories() {
		List<ProductCategory> categories = categoryRepo.findByActiveTrueOrderByCategoryNameAsc();

		if (categories == null || categories.isEmpty()) {
			throw new CustomException("No Products Categories Found", HttpStatus.NOT_FOUND);
		}

		List<CategoryDTO> response = new ArrayList<>();

		categories.stream().forEach(f -> response.add(mapper.convertToDto(f, CategoryDTO.class)));

		return response;
	}

	@Override
	@Cacheable(value = "productCategory", key = "#categoryUuid")
	public CategoryDTO getCategory(String categoryUuid) {
		ProductCategory category = categoryRepo.findByCategoryUuidAndActiveTrue(categoryUuid);

		if (category != null) {
			return mapper.convertToDto(category, CategoryDTO.class);
		} else {
			throw new CustomException("Product Category not found with " + categoryUuid, HttpStatus.NOT_FOUND);
		}
	}

	@Override
	@Cacheable(value = "productSubcategorySpecs", key = "#subCategoryUuid")
	public Set<String> getSubCategorySpecifications(String subCategoryUuid) {
		return subCategoryRepo.getSubcategorySpecifications(subCategoryUuid);
	}

	@Override
	@CacheEvict(value = "productPriceUnits", allEntries = true)
	public void savePriceUnits(Set<PriceUnit> priceUnits) {
		try {
			priceUnitRepo.saveAll(priceUnits);
		} catch (Exception e) {
			throw new CustomException("Error while saving price units", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	@Cacheable(value = "productPriceUnits")
	public Set<String> getPriceUnits() {
		return priceUnitRepo.getPriceUnits();
	}

	@Override
	@CacheEvict(value = { "productCategory", "productCategories" }, allEntries = true)
	public void evictCategoryCache() {
		logger.info("Evicted Category Cache :: cacheNames[productCategory,productCategories]");
	}

	@Override
	@Cacheable(value = "productSubCategory", key = "#subCategoryUuid")
	public SubCategoryDTO getSubCategory(String subCategoryUuid) {
		ProductSubCategory subCategory = subCategoryRepo.findBySubCategoryUuidAndActiveTrue(subCategoryUuid);

		if (subCategory != null) {
			return mapper.convertToDto(subCategory, SubCategoryDTO.class);
		} else {
			throw new CustomException("Product SubCategory not found with " + subCategoryUuid, HttpStatus.NOT_FOUND);
		}
	}

}
