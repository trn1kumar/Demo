package com.gloqr.repository;

public interface ImageDao {

	void deleteByFilelocation(String fileLocation);
}
