package com.gloqr.repository;

import java.util.TreeSet;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.gloqr.entity.ProductSubCategory;

public interface SubCategoryRepo extends JpaRepository<ProductSubCategory, Long> {

	ProductSubCategory findBySubCategoryUuidAndActiveTrue(String subCategoryUuid);

	@Query("select i.name from ProductSubCategory p JOIN p.specifications i where p.subCategoryUuid=:subCategoryUuid")
	TreeSet<String> getSubcategorySpecifications(String subCategoryUuid);
}
