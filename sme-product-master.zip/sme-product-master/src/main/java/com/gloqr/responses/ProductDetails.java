package com.gloqr.responses;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.gloqr.constants.ProductState;
import com.gloqr.dto.ImageDTO;
import com.gloqr.dto.SMEInformationDto;
import com.gloqr.dto.SubCategoryDTO;

@JsonInclude(Include.NON_NULL)
public class ProductDetails extends ProductResponse {

	private static final long serialVersionUID = 1L;

	private String description;
	private String location;
	private long stock;
	private Map<String, String> specifications;
	private List<ImageDTO> images;
	private SubCategoryDTO subCategory;
	private SMEInformationDto smeInfo;
	private boolean active;
	private ProductState productState;

	public String getDescription() {
		return description;
	}

	public String getLocation() {
		return location;
	}

	public long getStock() {
		return stock;
	}

	public Map<String, String> getSpecifications() {
		return specifications;
	}

	public List<ImageDTO> getImages() {
		return images;
	}

	public SubCategoryDTO getSubCategory() {
		return subCategory;
	}

	public SMEInformationDto getSmeInfo() {
		return smeInfo;
	}

	public ProductState getProductState() {
		return productState;
	}

	public boolean isActive() {
		return active;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public void setStock(long stock) {
		this.stock = stock;
	}

	public void setSpecifications(Map<String, String> specifications) {
		this.specifications = specifications;
	}

	public void setImages(List<ImageDTO> images) {
		this.images = images;
	}

	public void setSubCategory(SubCategoryDTO subCategory) {
		this.subCategory = subCategory;
	}

	public void setSmeInfo(SMEInformationDto smeInfo) {
		this.smeInfo = smeInfo;
	}

	public void setProductState(ProductState productState) {
		this.productState = productState;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

}
