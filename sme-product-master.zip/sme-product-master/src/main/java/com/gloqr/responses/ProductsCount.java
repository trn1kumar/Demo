package com.gloqr.responses;

public class ProductsCount {

	private String smeId;
	private int count;

	public ProductsCount(String smeId, int count) {
		super();
		this.smeId = smeId;
		this.count = count;
	}

	public String getSmeId() {
		return smeId;
	}

	public int getCount() {
		return count;
	}

}
