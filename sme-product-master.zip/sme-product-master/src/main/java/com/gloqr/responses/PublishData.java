package com.gloqr.responses;

import java.util.List;

import javax.validation.constraints.NotBlank;

import com.gloqr.constants.ProductState;
import com.gloqr.constants.ProductStatus;
import com.gloqr.dto.ImageDTO;

public class PublishData {

	@NotBlank(message = "{product.uuid}")
	private String id;

	// for sme admin
	private ProductStatus smeAction;

	// for gloqr admin
	private ProductState state;
	private String feedbackMessage;
	private List<ImageDTO> editedImages;

	private String subCategoryUuid;

	public List<ImageDTO> getEditedImages() {
		return editedImages;
	}

	public String getId() {
		return id;
	}

	public ProductStatus getSmeAction() {
		return smeAction;
	}

	public ProductState getState() {
		return state;
	}

	public String getFeedbackMessage() {
		return feedbackMessage;
	}

	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}

	public String getSubCategoryUuid() {
		return subCategoryUuid;
	}

}
