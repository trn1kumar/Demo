package com.gloqr.responses;

import java.util.List;

public class AdminProductPublish {

	private String smeId;
	private String userId;
	private List<PublishData> data;

	public String getSmeId() {
		return smeId;
	}

	public String getUserId() {
		return userId;
	}

	public List<PublishData> getData() {
		return data;
	}

}
