package com.gloqr.responses;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_DEFAULT)
public class ProductResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	private String productUuid;
	private String productName;
	private String productUrlName;
	private String sUuid;
	private String smeName;
	private String mainImage;
	private String priceUnit;
	private Double price;
	private Double discountedPrice;
	private int discount;
	private boolean addedToCart;
	private int biCount;
	private int minOrderQty;

	public int getMinOrderQty() {
		return minOrderQty;
	}

	public void setMinOrderQty(int minOrderQty) {
		this.minOrderQty = minOrderQty;
	}

	public String getProductUuid() {
		return productUuid;
	}

	public String getProductName() {
		return productName;
	}

	public String getProductUrlName() {
		return productUrlName;
	}

	public String getsUuid() {
		return sUuid;
	}

	public String getSmeName() {
		return smeName;
	}

	public String getMainImage() {
		return mainImage;
	}

	public Double getPrice() {
		return price;
	}

	public Double getDiscountedPrice() {
		return discountedPrice;
	}

	public int getDiscount() {
		return discount;
	}

	public boolean isAddedToCart() {
		return addedToCart;
	}

	public int getBiCount() {
		return biCount;
	}

	public void setProductUuid(String productUuid) {
		this.productUuid = productUuid;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public void setProductUrlName(String productUrlName) {
		this.productUrlName = productUrlName;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public void setMainImage(String mainImage) {
		this.mainImage = mainImage;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public void setDiscountedPrice(Double discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}

	public void setAddedToCart(boolean addedToCart) {
		this.addedToCart = addedToCart;
	}

	public void setBiCount(int biCount) {
		this.biCount = biCount;
	}

	public String getPriceUnit() {
		return priceUnit;
	}

	public void setPriceUnit(String priceUnit) {
		this.priceUnit = priceUnit;
	}
}
