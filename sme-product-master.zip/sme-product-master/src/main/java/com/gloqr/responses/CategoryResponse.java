package com.gloqr.responses;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_DEFAULT)
public class CategoryResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	private String categoryUuid;
	private String urlName;
	private String categoryName;
	private String fileLocation;

	public String getCategoryUuid() {
		return categoryUuid;
	}

	public String getUrlName() {
		return urlName;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public void setCategoryUuid(String categoryUuid) {
		this.categoryUuid = categoryUuid;
	}

	public void setUrlName(String urlName) {
		this.urlName = urlName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

}
