package com.gloqr.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FileUploadResponse {
	
	private String fileLocation;
	private String fileType;
	private long size;

	public String getFileType() {
		return fileType;
	}

	public long getSize() {
		return size;
	}

	public String getFileLocation() {
		return fileLocation;
	}
}
