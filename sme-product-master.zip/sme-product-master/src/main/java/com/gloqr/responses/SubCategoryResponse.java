package com.gloqr.responses;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_DEFAULT)
public class SubCategoryResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	private String subCategoryUuid;
	private String urlName;
	private String subCategoryName;
	private String fileLocation;

	public String getSubCategoryUuid() {
		return subCategoryUuid;
	}

	public String getUrlName() {
		return urlName;
	}

	public String getSubCategoryName() {
		return subCategoryName;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public void setSubCategoryUuid(String subCategoryUuid) {
		this.subCategoryUuid = subCategoryUuid;
	}

	public void setUrlName(String urlName) {
		this.urlName = urlName;
	}

	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

}
