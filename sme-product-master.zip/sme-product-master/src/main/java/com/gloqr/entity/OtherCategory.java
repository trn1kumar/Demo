package com.gloqr.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Entity
@Table(name = "Product_Other_Category")
public class OtherCategory implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(length = 100)
	@Size(max = 100, message = "Category Name should be less than 100")
	private String customCategory;

	@Column(length = 100)
	@Size(max = 100, message = "SubCategory Name should be less than 100")
	private String customSubCategory;

	private String categoryUuid;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCustomCategory() {
		return customCategory;
	}

	public void setCustomCategory(String customCategory) {
		this.customCategory = customCategory;
	}

	public String getCustomSubCategory() {
		return customSubCategory;
	}

	public void setCustomSubCategory(String customSubCategory) {
		this.customSubCategory = customSubCategory;
	}

	public String getCategoryUuid() {
		return categoryUuid;
	}

	public void setCategoryUuid(String categoryUuid) {
		this.categoryUuid = categoryUuid;
	}

}
