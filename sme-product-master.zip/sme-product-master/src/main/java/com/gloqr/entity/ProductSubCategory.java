package com.gloqr.entity;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.IndexedEmbedded;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "Product_SubCategory")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class ProductSubCategory extends Audit {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SubCategory_ID")
	private Long subCategoryID;

	@Column(name = "SubCategory_UUID", unique = true, nullable = false, updatable = false)
	@Field(analyze = Analyze.NO)
	private String subCategoryUuid;

	@Column(name = "SubCategory_Name", unique = true, nullable = false, length = 200)
	private String subCategoryName;

	@Column(name = "SubCategory_URL_Name", nullable = false, length = 200)
	private String urlName;

	@Column(name = "SubCategory_Image_Location")
	private String fileLocation;

	@Column(name = "SubCategory_Active")
	private boolean active;

	@Column(name = "Products_Count", columnDefinition = "BIGINT(20) UNSIGNED")
	private long productsCount;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "SubCategory_ID", nullable = false)
	private Set<MasterSpecification> specifications;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "Category_ID", nullable = false)
	@JsonIgnoreProperties("subCategories")
	@IndexedEmbedded(includeEmbeddedObjectId = true)
	private ProductCategory productCategory;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "subCategory")
	@JsonIgnoreProperties("subCategory")
	private List<Product> products;

	public Long getSubCategoryID() {
		return subCategoryID;
	}

	public String getSubCategoryUuid() {
		return subCategoryUuid;
	}

	public String getSubCategoryName() {
		return subCategoryName;
	}

	public String getUrlName() {
		return urlName;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public boolean isActive() {
		return active;
	}

	public long getProductsCount() {
		return productsCount;
	}

	public Set<MasterSpecification> getSpecifications() {
		return specifications;
	}

	public ProductCategory getProductCategory() {
		return productCategory;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setSubCategoryID(Long subCategoryID) {
		this.subCategoryID = subCategoryID;
	}

	public void setSubCategoryUuid(String subCategoryUuid) {
		this.subCategoryUuid = subCategoryUuid;
	}

	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}

	public void setUrlName(String urlName) {
		this.urlName = urlName;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setProductsCount(long productsCount) {
		this.productsCount = productsCount;
	}

	public void setSpecifications(Set<MasterSpecification> specifications) {
		this.specifications = specifications;
	}

	public void setProductCategory(ProductCategory productCategory) {
		this.productCategory = productCategory;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

}
