package com.gloqr.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Product_Image")
public class ProductImage extends Audit {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Image_ID")
	private Long imageID;

	@Column(name = "Image_Location", nullable = false, unique = true)
	private String fileLocation;

	@Column(name = "Image_Location_One")
	private String fileLocationOne;

	@Column(name = "Image_Location_Two")
	private String fileLocationTwo;

	@Column(name = "Image_Size")
	private long size;

	@Column(name = "Main_Image")
	private boolean mainImage;

	@Column(name = "Image_Is_Active")
	private boolean active;

	@Column(name = "Business_Post_Image")
	private boolean businessPostImage;

	public ProductImage(String fileLocation) {
		super();
		this.fileLocation = fileLocation;
	}

	public String getFileLocationOne() {
		return fileLocationOne;
	}

	public void setFileLocationOne(String fileLocationOne) {
		this.fileLocationOne = fileLocationOne;
	}

	public String getFileLocationTwo() {
		return fileLocationTwo;
	}

	public void setFileLocationTwo(String fileLocationTwo) {
		this.fileLocationTwo = fileLocationTwo;
	}

	public ProductImage() {
		super();
	}

	public Long getImageID() {
		return imageID;
	}

	public void setImageID(Long imageID) {
		this.imageID = imageID;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public long getSize() {
		return size;
	}

	public boolean isMainImage() {
		return mainImage;
	}

	public boolean isActive() {
		return active;
	}

	public boolean isBusinessPostImage() {
		return businessPostImage;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

	public void setSize(long size) {
		this.size = size;
	}

	public void setMainImage(boolean mainImage) {
		this.mainImage = mainImage;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setBusinessPostImage(boolean businessPostImage) {
		this.businessPostImage = businessPostImage;
	}

}
