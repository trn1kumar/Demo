package com.gloqr.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Field;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "Product_Category")
public class ProductCategory extends Audit {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Category_ID")
	private Long categoryID;

	@Column(name = "Category_UUID", unique = true, nullable = false, updatable = false)
	@Field(analyze = Analyze.NO)
	private String categoryUuid;

	@Column(name = "Category_Name", unique = true, nullable = false, length = 200)
	private String categoryName;

	@Column(name = "Category_URL_Name", nullable = false, length = 200)
	private String urlName;

	@Column(name = "Category_Image_Location")
	private String fileLocation;

	@Column(name = "Category_Active")
	private boolean active;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "productCategory")
	@JsonIgnoreProperties("productCategory")
	private List<ProductSubCategory> subCategories;

	public String getCategoryUuid() {
		return categoryUuid;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public String getUrlName() {
		return urlName;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public boolean isActive() {
		return active;
	}

	public List<ProductSubCategory> getSubCategories() {
		return subCategories;
	}

	public void setCategoryUuid(String categoryUuid) {
		this.categoryUuid = categoryUuid;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public void setUrlName(String urlName) {
		this.urlName = urlName;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setSubCategories(List<ProductSubCategory> subCategories) {
		this.subCategories = subCategories;
	}

}
