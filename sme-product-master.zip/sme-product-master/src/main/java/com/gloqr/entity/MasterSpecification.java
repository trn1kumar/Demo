package com.gloqr.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Product_Master_Specifications")
public class MasterSpecification implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Specification_ID")
	private Long specificationID;

	@Column(name = "Specification_Name", nullable = false, length = 50)
	private String name;

	public MasterSpecification(String name) {
		super();
		this.name = name;
	}

	public MasterSpecification() {
		super();
	}

	public Long getSpecificationID() {
		return specificationID;
	}

	public void setSpecificationID(Long specificationID) {
		this.specificationID = specificationID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
