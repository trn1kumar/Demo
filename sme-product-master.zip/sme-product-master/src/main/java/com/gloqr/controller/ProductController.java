package com.gloqr.controller;

import java.util.List;
import java.util.Set;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.aspectlogger.CheckCredits;
import com.gloqr.aspectlogger.PublishCheckCredits;
import com.gloqr.constants.Constants;
import com.gloqr.constants.URLMapping;
import com.gloqr.dto.ProductDTO;
import com.gloqr.dto.ProductVO;
import com.gloqr.exception.CustomException;
import com.gloqr.responses.CustomHttpResponse;
import com.gloqr.responses.FileUploadResponse;
import com.gloqr.responses.ProductDetails;
import com.gloqr.responses.ProductResponse;
import com.gloqr.responses.ProductsCount;
import com.gloqr.responses.PublishData;
import com.gloqr.responses.SingleProduct;
import com.gloqr.service.NotificationService;
import com.gloqr.service.ProductService;
import com.gloqr.util.RequestParser;
import com.gloqr.util.ResponseMaker;

@RestController
@RequestMapping(URLMapping.BASE_URL)
public class ProductController {

	@Autowired
	private ProductService productService;

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private RequestParser requestParser;

	@Autowired
	private NotificationService notification;

	@PostMapping(URLMapping.PRODUCT)
	@PreAuthorize(value = Constants.ROLE_SME)
	@CheckCredits
	public ResponseEntity<CustomHttpResponse<String>> addProduct(@RequestBody @Valid ProductDTO productDTO) {
		String sUuid = requestParser.getSuuid();
		productService.addProduct(productDTO, sUuid);

		// ASYNC Call
		notification.updateCountInSmeModule(sUuid, requestParser.getHeader());

		return responseMaker.successResponse("Product Added Successfully", HttpStatus.CREATED);
	}

	@GetMapping(URLMapping.TOP_PRODUCTS)
	public ResponseEntity<CustomHttpResponse<List<ProductResponse>>> topProducts(
			@RequestParam(value = "page", defaultValue = "1") int page) {

		String userUuid = null;
		if (requestParser.isLoggedIn()) {
			userUuid = requestParser.getUserUUID();
		}

		return responseMaker.successResponse(productService.topProducts(userUuid, page), HttpStatus.OK);
	}

	@GetMapping(URLMapping.PRODUCT_BY_UUID)
	public ResponseEntity<CustomHttpResponse<ProductDetails>> productByUuid(@PathVariable String productUuid) {

		String userUuid = null;
		if (requestParser.isLoggedIn()) {
			userUuid = requestParser.getUserUUID();
		}

		return responseMaker.successResponse(productService.productByUuid(productUuid, userUuid), HttpStatus.OK);
	}

	@GetMapping(URLMapping.PRODUCT_FOR_UPDATE)
	public ResponseEntity<CustomHttpResponse<SingleProduct>> productForUpdate(@PathVariable String productUuid) {

		return responseMaker.successResponse(productService.productForUpdate(productUuid), HttpStatus.OK);
	}

	@DeleteMapping(URLMapping.PRODUCT_BY_UUID)
	@PreAuthorize(value = Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> deleteProduct(@PathVariable String productUuid) {
		String sUuid = requestParser.getSuuid();
		productService.deleteProduct(productUuid, sUuid);
		// ASYNC Call
		notification.updateCountInSmeModule(sUuid, requestParser.getHeader());
		return responseMaker.successResponse("Product Deleted Successfully", HttpStatus.OK);
	}

	@PutMapping(URLMapping.PRODUCT_BY_UUID)
	@PreAuthorize(value = Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> updateProduct(@PathVariable String productUuid,
			@RequestBody @Valid ProductDTO productDTO) {

		if (StringUtils.isBlank(productUuid)) {
			throw new CustomException("Product Uuid cannot be null or empty.", HttpStatus.BAD_REQUEST);
		}
		String sUuid = requestParser.getSuuid();
		productService.updateProduct(productUuid, sUuid, productDTO);
		// ASYNC Call
		notification.updateCountInSmeModule(sUuid, requestParser.getHeader());
		return responseMaker.successResponse("Product Updated Successfully", HttpStatus.OK);
	}

	@PutMapping(URLMapping.AUTO_QUOTATION)
	@PreAuthorize(value = Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> changeAutoQuotationStatus(@PathVariable String productUuid,
			@RequestBody ProductDTO productDTO) {

		productService.updateAutoQuotationStatus(productUuid, productDTO);

		return responseMaker.successResponse("Auto Quotation Status Updated Successfully", HttpStatus.OK);
	}

	@PutMapping(URLMapping.PRODUCT)
	@PreAuthorize(value = Constants.ROLE_SME)
	@PublishCheckCredits
	public ResponseEntity<CustomHttpResponse<String>> updateProductStatus(@RequestBody @Valid Set<PublishData> data) {

		productService.updateProductStatus(data);
		// ASYNC Call
		notification.updateCountInSmeModule(requestParser.getSuuid(), requestParser.getHeader());
		return responseMaker.successResponse("Product Status Updated Successfully", HttpStatus.OK);
	}

	@PreAuthorize(value = Constants.ROLE_SME_AND_USER)
	@PutMapping(URLMapping.PRODUCT_BI_COUNT)
	public ResponseEntity<CustomHttpResponse<String>> updateBiCount(@PathVariable String productUuid) {

		productService.productBiCount(productUuid);

		return responseMaker.successResponse("Business Interest Count Updated Successfully", HttpStatus.OK);
	}

	@GetMapping(URLMapping.SME_PRODUCT_COUNT)
	public ResponseEntity<CustomHttpResponse<ProductsCount>> smeProductsCount(@PathVariable String sUuid,
			@RequestParam(value = "status") boolean viewMode) {

		return responseMaker.successResponse(productService.smeProductsCount(sUuid, viewMode), HttpStatus.OK);
	}

	@GetMapping(URLMapping.SME_PRODUCTS)
	@PreAuthorize(value = Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<List<ProductVO>>> getProductsOfSME(
			@RequestParam(value = "status", defaultValue = "active") String status) {
		List<ProductVO> productsVo = null;

		if (status.equals("all")) {
			productsVo = productService.productsOfSME(requestParser.getSuuid());
		} else {
			productsVo = productService.productsOfSME(requestParser.getSuuid(), status);
		}

		return responseMaker.successResponse(productsVo, HttpStatus.OK);
	}

	@GetMapping(URLMapping.SME_PRODUCTS_VIEW)
	public ResponseEntity<CustomHttpResponse<List<ProductResponse>>> getAppprovedProducts(@PathVariable String sUuid) {
		String userUuid = null;
		if (requestParser.isLoggedIn()) {
			userUuid = requestParser.getUserUUID();
		}

		return responseMaker.successResponse(productService.smeProductsViewMode(sUuid, userUuid), HttpStatus.OK);
	}

	@PutMapping(URLMapping.BUSINESS_POST_IMAGE)
	@PreAuthorize(value = Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> modifyPostImages(@RequestBody List<FileUploadResponse> images) {

		productService.updateBusinessPostImages(images);

		return responseMaker.successResponse("Business Post Image Status Updated Successfully", HttpStatus.OK);
	}

}
