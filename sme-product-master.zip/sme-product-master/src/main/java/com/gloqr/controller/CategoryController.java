package com.gloqr.controller;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.Constants;
import com.gloqr.constants.URLMapping;
import com.gloqr.dto.CategoryDTO;
import com.gloqr.responses.CustomHttpResponse;
import com.gloqr.responses.SubCategoryResponse;
import com.gloqr.service.CategoryService;
import com.gloqr.util.ResponseMaker;

@RestController
@RequestMapping(URLMapping.BASE_URL)
public class CategoryController {

	@Autowired
	private CategoryService categoryService;

	@Autowired
	private ResponseMaker responseMaker;

	@GetMapping(URLMapping.NAV_CATEGORIES)
	public ResponseEntity<CustomHttpResponse<List<CategoryDTO>>> menuBarData() {

		return responseMaker.successResponse(categoryService.menuBarData(), HttpStatus.OK);
	}

	@GetMapping(URLMapping.CATEGORY)
	@PreAuthorize(value = Constants.ROLE_GLOQR_AND_SME)
	public ResponseEntity<CustomHttpResponse<Map<String, Object>>> productCategories() {

		return responseMaker.successResponse(categoryService.productCategories(), HttpStatus.OK);
	}

	@GetMapping(URLMapping.SUBCATEGORY)
	@PreAuthorize(value = Constants.ROLE_GLOQR_AND_SME)
	public ResponseEntity<CustomHttpResponse<List<SubCategoryResponse>>> productSubCategories(
			@PathVariable String categoryUuid) {

		return responseMaker.successResponse(categoryService.productSubCategories(categoryUuid), HttpStatus.OK);
	}

	@GetMapping(URLMapping.SPECIFICATION)
	@PreAuthorize(value = Constants.ROLE_GLOQR_AND_SME)
	public ResponseEntity<CustomHttpResponse<Set<String>>> subCategorySpecs(
			@PathVariable String subCategoryUuid) {

		return responseMaker.successResponse(categoryService.subCategorySpecs(subCategoryUuid), HttpStatus.OK);
	}

}
