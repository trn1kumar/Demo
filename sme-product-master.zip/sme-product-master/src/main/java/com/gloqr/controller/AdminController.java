package com.gloqr.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.Constants;
import com.gloqr.constants.URLMapping;
import com.gloqr.dto.CategoryDTO;
import com.gloqr.dto.MasterDataDTO;
import com.gloqr.dto.SubCategoryDTO;
import com.gloqr.exception.CustomException;
import com.gloqr.repository.ProductRepo;
import com.gloqr.responses.AdminProductPublish;
import com.gloqr.responses.CustomHttpResponse;
import com.gloqr.responses.PublishData;
import com.gloqr.responses.SingleProduct;
import com.gloqr.service.AdminService;
import com.gloqr.service.NotificationService;
import com.gloqr.util.RequestParser;
import com.gloqr.util.ResponseMaker;

@RestController
@RequestMapping(URLMapping.BASE_URL_ADMIN)
public class AdminController {

	@Autowired
	private AdminService adminService;

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private RequestParser requestParser;

	@Autowired
	private NotificationService notification;

	@Autowired
	ProductRepo productRepo;

	@PostMapping(URLMapping.CATEGORY)
	@PreAuthorize(value = Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<String>> addProductCategory(@RequestBody @Valid CategoryDTO categoryDTO) {

		adminService.addProductCategory(categoryDTO);

		return responseMaker.successResponse("Product Category Added Successfully", HttpStatus.CREATED);
	}

	@PostMapping(URLMapping.SUBCATEGORY)
	@PreAuthorize(value = Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<String>> addProductSubCategory(@PathVariable String categoryUuid,
			@RequestBody @Valid SubCategoryDTO subCategoryDTO) {

		if (StringUtils.isNotBlank(categoryUuid)) {
			adminService.addProductSubCategory(categoryUuid, subCategoryDTO);
		} else {
			throw new CustomException("Category UUID cannot be null or empty", HttpStatus.BAD_REQUEST);
		}

		return responseMaker.successResponse("Product SubCategory Added Successfully", HttpStatus.CREATED);
	}

	@PostMapping(URLMapping.SPECIFICATION)
	@PreAuthorize(value = Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<String>> addSubCategorySpecifications(@PathVariable String subCategoryUuid,
			@RequestBody @Valid Set<MasterDataDTO> specificationDTO) {

		if (StringUtils.isNotBlank(subCategoryUuid)) {
			adminService.addSubCategorySpecifications(subCategoryUuid, specificationDTO);
		} else {
			throw new CustomException("SubCategory UUID cannot be null or empty", HttpStatus.BAD_REQUEST);
		}

		return responseMaker.successResponse("SubCategory Specifications Added Successfully", HttpStatus.CREATED);
	}

	@PostMapping(URLMapping.PRICE_UNIT)
	@PreAuthorize(value = Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<String>> addPriceUnits(
			@RequestBody @Valid Set<MasterDataDTO> priceUnitsDTO) {

		adminService.addPriceUnits(priceUnitsDTO);

		return responseMaker.successResponse("Price Units Added Successfully", HttpStatus.CREATED);
	}

	@PutMapping(URLMapping.PRODUCT_STATE)
	@PreAuthorize(value = Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<String>> updateProductState(
			@RequestBody @Valid AdminProductPublish productPublish) {

		adminService.updateProductState(productPublish);
		// ASYNC Call
		notification.updateCountInSmeModule(productPublish.getSmeId(), requestParser.getHeader());

		return responseMaker.successResponse("Product State Updated Successfully", HttpStatus.OK);
	}

	@PutMapping(URLMapping.PRODUCT_IMAGES)
	@PreAuthorize(value = Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<String>> updateProductImages(@RequestBody @Valid PublishData publishData)
			throws IOException {

		adminService.updateProductImages(publishData);

		return responseMaker.successResponse("Product Images Updated Successfully", HttpStatus.OK);
	}

	@PutMapping(URLMapping.UPDATE_COUNTS)
	@PreAuthorize(value = Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<String>> update() {

		Set<String> suuids = productRepo.getSuuids();

		for (String suuid : suuids) {
			notification.updateCountInSmeModule(suuid, requestParser.getHeader());
		}

		return responseMaker.successResponse("Count Updated Successfully", HttpStatus.OK);
	}

	@GetMapping(URLMapping.SME_PENDING_PRODUCTS)
	@PreAuthorize(value = Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<List<SingleProduct>>> getCategories(@PathVariable String sUuid) {

		return responseMaker.successResponse(adminService.pendingProductsOfSME(sUuid), HttpStatus.OK);
	}

	@GetMapping(URLMapping.SME_PENDING_PRODUCTS_COUNT)
	@PreAuthorize(value = Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<Map<String, Integer>>> getCategoriesCount(
			@RequestParam List<String> smeIds) {

		return responseMaker.successResponse(adminService.smePendingProductsCount(smeIds), HttpStatus.OK);
	}

}
