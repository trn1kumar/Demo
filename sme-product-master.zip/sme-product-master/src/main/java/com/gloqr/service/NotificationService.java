package com.gloqr.service;

import java.util.List;

import com.gloqr.entity.Product;

public interface NotificationService {

	void productsVerificationSummaryNotifi(String smeId, List<Product> products);

	void updateCountInSmeModule(String sUuid, String token);

}
