package com.gloqr.service;

import java.util.List;

import com.gloqr.dto.ImageDTO;
import com.gloqr.entity.Product;
import com.gloqr.responses.PublishData;

public interface BusinessPostService {
	
	public void createBusinessPost(Product product, List<ImageDTO> images);

	public void activateBusinessPost(List<PublishData> postedProducts);
}
