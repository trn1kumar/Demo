package com.gloqr.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.dto.ImageDTO;
import com.gloqr.endpoint.BusinessPostEndpoint;
import com.gloqr.entity.Product;
import com.gloqr.exception.CustomException;
import com.gloqr.responses.PublishData;
import com.gloqr.responses.PublishFeed;

@Service
public class BusinessPostServiceImpl implements BusinessPostService {

	Logger logger = LogManager.getLogger();

	@Autowired
	private BusinessPostEndpoint postEndpoint;

	@Override
	public void createBusinessPost(Product product, List<ImageDTO> images) {
		PublishFeed feed = new PublishFeed(product.getsUuid(), product.getProductUuid(), product.getProductName(),
				product.getDescription(), images);

		logger.info("Creating Business Post for Product");

		if (product.isActive()) {
			feed.setActive(true);
		}

		try {
			postEndpoint.createBusinessPost(feed);
		} catch (CustomException e) {
			throw e;
		}

	}

	@Override
	public void activateBusinessPost(List<PublishData> postedProducts) {
		logger.info("Activating Business Post for Product");

		postEndpoint.updateBusinessPostStatus(postedProducts);
	}

}
