package com.gloqr.service;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.apache.lucene.search.Query;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.hibernate.search.query.engine.spi.FacetManager;
import org.hibernate.search.query.facet.Facet;
import org.hibernate.search.query.facet.FacetingRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.constants.ProductState;
import com.gloqr.dto.CategoryDTO;
import com.gloqr.dto.ImageDTO;
import com.gloqr.dto.MasterDataDTO;
import com.gloqr.dto.SubCategoryDTO;
import com.gloqr.entity.MasterSpecification;
import com.gloqr.entity.PriceUnit;
import com.gloqr.entity.Product;
import com.gloqr.entity.ProductCategory;
import com.gloqr.entity.ProductSubCategory;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.Mapper;
import com.gloqr.repository.CategoryRepo;
import com.gloqr.repository.ImageDao;
import com.gloqr.repository.MasterDataDao;
import com.gloqr.repository.ProductDao;
import com.gloqr.repository.ProductRepo;
import com.gloqr.repository.SubCategoryRepo;
import com.gloqr.responses.AdminProductPublish;
import com.gloqr.responses.PublishData;
import com.gloqr.responses.SingleProduct;
import com.gloqr.util.CustomGenerator;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private CategoryRepo categoryRepo;

	@Autowired
	private SubCategoryRepo subCategoryRepo;

	@Autowired
	private CustomGenerator generator;

	@Autowired
	private Mapper mapper;

	@Autowired
	private MasterDataDao masterDao;

	@Autowired
	private ProductRepo productRepo;

	@Autowired
	private ProductDao productDao;

	@Autowired
	private PricingService pricingService;

	private String dateFormat = "E, dd MMM yyyy HH:mm:ss";

	@Autowired
	private EntityManager entityManager;

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private ImageDao imageDao;

	@Autowired
	private FileService fileService;

	@Override
	@Transactional
	public void addProductCategory(CategoryDTO categoryDTO) {

		categoryDTO.setCategoryUuid(generator.generateUUID());
		categoryDTO.setUrlName(generator.filterName(categoryDTO.getCategoryName()));

		ProductCategory category = mapper.convertToEntity(categoryDTO, ProductCategory.class);
		category.setActive(true);

		if (category.getSubCategories() != null)
			category.getSubCategories().stream().forEach(s -> {
				s.setSubCategoryUuid(generator.generateUUID());
				s.setUrlName(generator.filterName(s.getSubCategoryName()));
				s.setActive(true);
				s.setProductCategory(category);
			});

		try {
			categoryRepo.save(category);
			masterDao.evictCategoryCache();
		} catch (Exception e) {
			throw new CustomException("Error while saving product category", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	@Transactional
	public void addProductSubCategory(String categoryUuid, SubCategoryDTO subCategoryDTO) {
		ProductCategory category = getProductCategory(categoryUuid);

		ProductSubCategory subCategory = mapper.convertToEntity(subCategoryDTO, ProductSubCategory.class);
		subCategory.setSubCategoryUuid(generator.generateUUID());
		subCategory.setUrlName(generator.filterName(subCategory.getSubCategoryName()));
		subCategory.setActive(true);
		subCategory.setProductCategory(category);

		saveSubCategory(subCategory);
	}

	@Override
	public void addSubCategorySpecifications(String subCategoryUuid, Set<MasterDataDTO> specificationDTO) {
		ProductSubCategory subCategory = getProductSubCategory(subCategoryUuid);
		Set<MasterSpecification> specifications = new HashSet<>();
		specificationDTO.stream()
				.forEach(s -> specifications.add(mapper.convertToEntity(s, MasterSpecification.class)));

		subCategory.getSpecifications().addAll(specifications);
		saveSubCategory(subCategory);
	}

	@Override
	public void addPriceUnits(@Valid Set<MasterDataDTO> priceUnitsDTO) {
		Set<PriceUnit> priceUnits = new HashSet<>();
		priceUnitsDTO.stream().forEach(p -> priceUnits.add(mapper.convertToEntity(p, PriceUnit.class)));
		masterDao.savePriceUnits(priceUnits);
	}

	private ProductCategory getProductCategory(String categoryUuid) {
		ProductCategory productCategory = categoryRepo.findByCategoryUuidAndActiveTrue(categoryUuid);

		if (productCategory != null) {
			return productCategory;
		} else {
			throw new CustomException("Product Category not found for uuid :: " + categoryUuid, HttpStatus.BAD_REQUEST);
		}

	}

	@Override
	public ProductSubCategory getProductSubCategory(String subCategoryUuid) {
		ProductSubCategory subCategory = subCategoryRepo.findBySubCategoryUuidAndActiveTrue(subCategoryUuid);

		if (subCategory != null) {
			return subCategory;
		} else {
			throw new CustomException("Product SubCategory not found for uuid :: " + subCategoryUuid,
					HttpStatus.BAD_REQUEST);
		}
	}

	@Override
	@Transactional
	public void updateProductState(AdminProductPublish productPublish) {

		List<Product> products = new ArrayList<>();

		for (PublishData data : productPublish.getData()) {
			ProductState state = data.getState();
			Product product = productByUuid(data.getId());

			if (product.isActive() && product.getProductState().equals(ProductState.PENDING)) {
				product.setProductState(state);
				if (product.getProductState().equals(ProductState.REJECTED)) {
					product.setActive(false);
				}
				if (StringUtils.isNotBlank(data.getSubCategoryUuid())
						&& product.getProductState().equals(ProductState.APPROVED)) {
					product.setSubCategory(getProductSubCategory(data.getSubCategoryUuid()));
				}

				checkFeedMessage(data, state, product);
				products.add(product);
			}
		}

		if (!products.isEmpty()) {
			products.stream().forEach(p -> {
				if (p.isActive() && p.getProductState().equals(ProductState.APPROVED)) {
					p.getSubCategory().setProductsCount(p.getSubCategory().getProductsCount() + 1);
				}
				productDao.saveProduct(p);
			});
			productDao.evictTopProducts();
			masterDao.evictCategoryCache();
		}

		long credits = productPublish.getData().stream().filter(p -> p.getState().equals(ProductState.REJECTED))
				.count();

		if (credits > 0) {
			pricingService.adminUpdateCredits(credits, productPublish.getSmeId(), productPublish.getUserId());
		}

		notificationService.productsVerificationSummaryNotifi(productPublish.getSmeId(), products);
	}

	@Override
	@org.springframework.transaction.annotation.Transactional
	public void updateProductImages(PublishData publishData) throws IOException {
		Product product = productByUuid(publishData.getId());

		List<String> deleteImages = new ArrayList<>();

		product.getImages().forEach(existImg -> {
			for (ImageDTO imgDto : publishData.getEditedImages()) {
				if (imgDto.getFileLocation().equals(existImg.getFileLocation())) {

					if (StringUtils.isNotBlank(imgDto.getFileLocationOne())) {
						if (checkModifiedFiles(existImg.getFileLocation(), imgDto.getFileLocationOne(),
								existImg.getFileLocationOne(), deleteImages)) {
							existImg.setFileLocationOne(imgDto.getFileLocationOne());
						}
					} else {
						existImg.setFileLocationOne(existImg.getFileLocation());
					}

					if (StringUtils.isNotBlank(imgDto.getFileLocationTwo())) {
						if (checkModifiedFiles(existImg.getFileLocation(), imgDto.getFileLocationTwo(),
								existImg.getFileLocationTwo(), deleteImages)) {
							existImg.setFileLocationTwo(imgDto.getFileLocationTwo());
							if (existImg.isMainImage()) {
								product.setMainImage(imgDto.getFileLocationTwo());
							}
						}
					} else {
						existImg.setFileLocationTwo(existImg.getFileLocation());
						if (existImg.isMainImage()) {
							product.setMainImage(existImg.getFileLocation());
						}
					}

					break;
				}
			}
		});
		productDao.saveProduct(product);
		if (!deleteImages.isEmpty())
			fileService.deleteMultipleFiles(deleteImages);
	}

	private boolean checkModifiedFiles(String existFileLocation, String newFileLocation, String existFileLocationOne,
			List<String> deleteImages) {
		if (!(existFileLocation.equals(newFileLocation) || newFileLocation.equals(existFileLocationOne))) {

			if (!existFileLocation.equals(existFileLocationOne)) {
				deleteImages.add(existFileLocationOne);
			}
			imageDao.deleteByFilelocation(newFileLocation);
			return true;
		}
		return false;
	}

	@Override
	public Map<String, Integer> smePendingProductsCount(List<String> smeIds) {
		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(Product.class).get();

		Query query1 = queryBuilder.keyword().onField("productState").matching(ProductState.PENDING).createQuery();
		Query query2 = queryBuilder.keyword().onField("active").matching("true").createQuery();

		FacetingRequest facetReq1 = queryBuilder.facet().name("sUuidFacet").onField("sUuid").discrete()
				.includeZeroCounts(true).createFacetingRequest();

		Query finalQuery = queryBuilder.bool().must(query1).must(query2).createQuery();

		FullTextQuery queryResult = fullTextEntityManager.createFullTextQuery(finalQuery, Product.class);
		FacetManager facetManager = queryResult.getFacetManager();
		facetManager.enableFaceting(facetReq1);

		List<Facet> facets = facetManager.getFacets("sUuidFacet");

		Map<String, Integer> map = null;

		if (!facets.isEmpty()) {
			map = new HashMap<>();
			for (Facet f : facets) {
				if (smeIds.contains(f.getValue())) {
					map.put(f.getValue(), f.getCount());
				}
			}
		}

		return map;
	}

	@Override
	public List<SingleProduct> pendingProductsOfSME(String sUuid) {

		return productDao.pendingProductsOfSME(sUuid);
	}

	private void checkFeedMessage(PublishData publishData, ProductState state, Product existProduct) {

		if (StringUtils.isNotBlank(publishData.getFeedbackMessage())) {
			String dateAndAction = "[ Date:-" + new SimpleDateFormat(dateFormat).format(new Date()) + " Action:-"
					+ state + " ] ";

			publishData.setFeedbackMessage(dateAndAction.concat(publishData.getFeedbackMessage()));

			if (StringUtils.isNotBlank(existProduct.getFeedbackMessage())) {
				existProduct.setFeedbackMessage(
						existProduct.getFeedbackMessage().concat("| " + publishData.getFeedbackMessage()));
			} else {
				existProduct.setFeedbackMessage(publishData.getFeedbackMessage());
			}
		}

	}

	private void saveSubCategory(ProductSubCategory subCategory) {
		try {
			subCategoryRepo.save(subCategory);
			masterDao.evictCategoryCache();
		} catch (Exception e) {
			throw new CustomException("Error while saving product subcategory", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private Product productByUuid(String productUuid) {
		Product product = productRepo.findByProductUuid(productUuid);

		if (product != null) {
			return product;
		} else {
			throw new CustomException("Product not found for id :: " + productUuid, HttpStatus.BAD_REQUEST);
		}
	}

}
