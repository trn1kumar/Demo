package com.gloqr.service;

import java.util.List;

import com.gloqr.responses.ProductResponse;

public interface CartService {

	void addedToCartList(String userUUID, List<ProductResponse> products);

	boolean isAddedToCart(String userUUID, String productUuid);
}
