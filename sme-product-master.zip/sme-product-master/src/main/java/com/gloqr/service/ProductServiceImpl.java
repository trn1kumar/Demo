package com.gloqr.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.constants.Constants;
import com.gloqr.constants.ProductState;
import com.gloqr.constants.ProductStatus;
import com.gloqr.dto.ImageDTO;
import com.gloqr.dto.ProductDTO;
import com.gloqr.dto.ProductVO;
import com.gloqr.endpoint.SmeServerEndpoint;
import com.gloqr.entity.Product;
import com.gloqr.entity.ProductImage;
import com.gloqr.entity.ProductSubCategory;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.Mapper;
import com.gloqr.repository.MasterDataDao;
import com.gloqr.repository.ProductDao;
import com.gloqr.repository.ProductImageRepo;
import com.gloqr.repository.ProductRepo;
import com.gloqr.responses.FileUploadResponse;
import com.gloqr.responses.ProductDetails;
import com.gloqr.responses.ProductResponse;
import com.gloqr.responses.ProductsCount;
import com.gloqr.responses.PublishData;
import com.gloqr.responses.SingleProduct;
import com.gloqr.util.CustomGenerator;

@Service
public class ProductServiceImpl implements ProductService {

	Logger logger = LogManager.getLogger();

	@Autowired
	private ProductRepo productRepo;

	@Autowired
	private Mapper mapper;

	@Autowired
	private AdminService adminService;

	@Autowired
	private CustomGenerator generator;

	@Autowired
	private SmeServerEndpoint smeEndpoint;

	@Autowired
	private BusinessPostService postService;

	@Autowired
	private PricingService pricingService;

	@Autowired
	private ProductDao productDao;

	@Autowired
	private CartService cartService;

	@Autowired
	private ProductImageRepo imageRepo;

	@Autowired
	private MasterDataDao masterDao;

	@Override
	@Transactional
	public void addProduct(ProductDTO productDTO, String sUuid) {

		ProductSubCategory subCategory = null;

		if (StringUtils.isNotBlank(productDTO.getSubCategoryUuid())) {
			subCategory = adminService.getProductSubCategory(productDTO.getSubCategoryUuid());
		}

		Product product = mapper.convertToEntity(productDTO, Product.class);
		product.setSubCategory(subCategory);
		product.setsUuid(sUuid);
		product.setProductState(ProductState.PENDING);
		product.setProductUuid(generator.generateUUID());
		product.setProductUrlName(generator.filterName(product.getProductName()));

		if (product.getDiscount() != 0) {
			product.setDiscountedPrice(product.getPrice() - ((product.getPrice() * product.getDiscount()) / 100));
		} else {
			product.setDiscountedPrice(product.getPrice());
		}

		product.setSmeName(smeEndpoint.getSme(sUuid).getSmeName().trim());

		List<ProductImage> images = new ArrayList<>();
		product.getImages().stream().forEach(i -> {
			ProductImage image = imageRepo.findByFileLocation(i.getFileLocation());
			if (i.isMainImage()) {
				product.setMainImage(i.getFileLocation());
				image.setMainImage(true);
			}
			if (product.isBusinessPost()) {
				image.setBusinessPostImage(true);
			}
			image.setActive(true);
			image.setFileLocationOne(i.getFileLocation());
			image.setFileLocationTwo(i.getFileLocation());
			images.add(image);
		});
		product.setImages(images);

		productDao.saveProduct(product);

		try {
			if (product.isBusinessPost()) {
				postService.createBusinessPost(product, productDTO.getImages());
				if (product.isActive()) {
					product.setBusinessPostActivated(true);
				}
			}
		} catch (CustomException e) {
			logger.error("Error while creating business post :: " + e.getMessage());
		}

		if (product.isActive()) {
			pricingService.updateListingCredits(1, Constants.DEBIT,
					"New Product Publish with id :: " + product.getProductUuid());
		}

		pricingService.updateImageStorageCredits(product.getImages().stream().mapToLong(ProductImage::getSize).sum(),
				Constants.DEBIT, "New Product Images for id :: " + product.getProductUuid());
	}

	@Override
	public List<ProductResponse> topProducts(String userUUID, int page) {

		List<ProductResponse> products = productDao.topProducts(page);

		if (StringUtils.isNotBlank(userUUID)) {
			cartService.addedToCartList(userUUID, products);
		}

		return products;
	}

	@Override
	public ProductDetails productByUuid(String productUuid, String userUUID) {
		ProductDetails product = productDao.productByUuid(productUuid);

		product.setSmeInfo(smeEndpoint.getSme(product.getsUuid()));

		if (StringUtils.isNotBlank(userUUID) && cartService.isAddedToCart(userUUID, productUuid)) {
			product.setAddedToCart(true);
		}

		if (product.getSpecifications().isEmpty()) {
			product.setSpecifications(null);
		} else {
			product.setSpecifications(new TreeMap<>(product.getSpecifications()));
		}

		return product;
	}

	@Override
	public void deleteProduct(String productUuid, String suuid) {
		productDao.deleteProduct(productUuid, suuid);
	}

	@Override
	public SingleProduct productForUpdate(String productUuid) {

		return productDao.productForUpdate(productUuid);
	}

	@Override
	@Transactional
	public void updateProduct(String productUuid, String sUuid, ProductDTO productDTO) {
		Product existingProduct = productByUuid(productUuid);

		checkProductStateForUpdate(existingProduct, sUuid);

		long deletedImageSize = 0;
		long newImagesSize = 0;

		if (productDTO.getDeletedImages() != null && !productDTO.getDeletedImages().isEmpty()) {
			List<ProductImage> deleteImages = new ArrayList<>();
			for (ImageDTO di : productDTO.getDeletedImages()) {
				existingProduct.getImages().stream().forEach(ei -> {
					if (di.getFileLocation().equals(ei.getFileLocation())) {
						ei.setActive(false);
						deleteImages.add(ei);
					}
				});
				deletedImageSize += di.getSize();
			}
			existingProduct.getImages().removeAll(deleteImages);
		}

		if (productDTO.getImages() != null && !productDTO.getImages().isEmpty()) {
			for (ImageDTO ni : productDTO.getImages()) {
				ProductImage newImage = imageRepo.findByFileLocation(ni.getFileLocation());
				newImage.setActive(true);
				newImage.setFileLocationOne(newImage.getFileLocation());
				newImage.setFileLocationTwo(newImage.getFileLocation());
				existingProduct.getImages().add(newImage);
				newImagesSize += ni.getSize();
			}
		}

		for (ProductImage img : existingProduct.getImages()) {
			if (img.getFileLocation().equals(productDTO.getMainImage())) {
				img.setMainImage(true);
				existingProduct.setMainImage(productDTO.getMainImage());
			}
		}

		existingProduct.setSmeName(smeEndpoint.getSme(sUuid).getSmeName().trim());
		mapper.modifyExistingProduct(existingProduct, productDTO);

		productDao.saveProduct(existingProduct);

		updateProductCredits(existingProduct, deletedImageSize, newImagesSize);
	}

	@Override
	public void updateAutoQuotationStatus(String productUuid, ProductDTO productDTO) {
		ProductDetails p = productDao.productByUuid(productUuid);
		if (p.isActive()) {
			productDao.updateAutoQutationStatus(productUuid, productDTO.isAutoQuotation(), p.getsUuid());
		} else {
			throw new CustomException("Product is not in Active State", HttpStatus.BAD_REQUEST);
		}
	}

	@Override
	@Transactional
	public void updateProductStatus(Set<PublishData> data) {

		List<PublishData> businessPostProducts = new ArrayList<>();
		List<Product> products = new ArrayList<>();

		for (PublishData publishData : data) {
			boolean status = false;

			if (publishData.getSmeAction().equals(ProductStatus.ACTIVE)) {
				status = true;
			}

			Product product = productByUuid(publishData.getId());

			if ((status && product.isActive()) || (!status && !product.isActive())) {
				continue;
			}

			if (product.isBusinessPost() && !product.isBusinessPostActivated() && status) {
				businessPostProducts.add(publishData);
				product.setBusinessPostActivated(true);
			}
			product.setActive(status);
			products.add(product);
		}

		doActions(businessPostProducts, products);
	}

	@Override
	public void productBiCount(String productUuid) {
		productDao.productBiCount(productUuid);
	}

	@Override
	public ProductsCount smeProductsCount(String sUuid, boolean viewMode) {
		int count = 0;

		if (viewMode) {
			count = productRepo.countBySUuidAndProductStateAndActiveTrue(sUuid, ProductState.APPROVED);
		} else {
			count = productRepo.countBySUuidAndProductStateIsNotIn(sUuid, ProductState.DELETED);
		}
		return new ProductsCount(sUuid, count);
	}

	@Override
	public List<ProductVO> productsOfSME(String sUuid) {
		List<ProductVO> products = productDao.productsOfSME(sUuid);

		return products.stream().filter(p -> !p.getProductState().equals(ProductState.DELETED))
				.collect(Collectors.toList());
	}

	@Override
	public List<ProductVO> productsOfSME(String sUuid, String status) {
		List<ProductVO> products = productDao.productsOfSME(sUuid);

		List<ProductVO> list = new ArrayList<>();

		if (status.equals("active")) {
			products.stream().filter(p -> p.isActive() && (!p.getProductState().equals(ProductState.DELETED)))
					.forEach(p -> list.add(p));
		} else if (status.equals("deactive")) {
			products.stream().filter(p -> !p.isActive() && (!p.getProductState().equals(ProductState.DELETED)))
					.forEach(p -> list.add(p));
		}
		if (list.isEmpty()) {
			throw new CustomException("Products Not Found for SME id :: " + sUuid, HttpStatus.NOT_FOUND);
		}

		return list;
	}

	@Override
	public List<ProductResponse> smeProductsViewMode(String sUuid, String userUUID) {
		List<ProductVO> products = productDao.productsOfSME(sUuid);

		List<ProductResponse> response = new ArrayList<>();

		products.stream()
				.filter(p -> p.isActive() && p.getProductState().equals(ProductState.APPROVED)
						&& (!p.getProductState().equals(ProductState.DELETED)))
				.forEach(p -> response.add(mapper.convertToDto(p, ProductResponse.class)));

		if (response.isEmpty()) {
			throw new CustomException("Products Not Found for SME id :: " + sUuid, HttpStatus.NOT_FOUND);
		}

		if (StringUtils.isNotBlank(userUUID)) {
			cartService.addedToCartList(userUUID, response);
		}

		return response;
	}

	@Override
	public void updateBusinessPostImages(List<FileUploadResponse> images) {
		Set<String> fileLocations = new HashSet<>();
		images.stream().forEach(i -> fileLocations.add(i.getFileLocation()));
		imageRepo.updateBusinessPostImage(fileLocations);
	}

	public void doActions(List<PublishData> businessPostProducts, List<Product> products) {

		if (!products.isEmpty()) {
			products.stream().forEach(p -> {
				if (p.getProductState().equals(ProductState.APPROVED)) {
					if (p.isActive()) {
						p.getSubCategory().setProductsCount(p.getSubCategory().getProductsCount() + 1);
					} else {
						p.getSubCategory().setProductsCount(p.getSubCategory().getProductsCount() - 1);
					}
				}
				productDao.saveProduct(p);
			});
			productDao.evictTopProducts();
			masterDao.evictCategoryCache();

			Optional<Product> publishData = null;

			publishData = products.stream().findFirst();

			if (publishData.isPresent() && publishData.get().isActive()) {
				pricingService.updateListingCredits(products.size(), Constants.DEBIT, "Activated Products");
			} else {
				pricingService.updateListingCredits(products.size(), Constants.CREDIT, "Deactived Products");
				masterDao.evictCategoryCache();
			}

		}

		if (!businessPostProducts.isEmpty()) {
			postService.activateBusinessPost(businessPostProducts);
		}

	}

	private void updateProductCredits(Product existingProduct, long deletedImageSize, long newImagesSize) {
		if (existingProduct.isActive()) {
			pricingService.updateListingCredits(1, Constants.DEBIT,
					"Update product and publish for id :: " + existingProduct.getProductUuid());
		}

		if (newImagesSize > deletedImageSize) {
			long remainingSize = pricingService.checkImageCredits();
			long debitSize = newImagesSize - deletedImageSize;

			if (remainingSize < debitSize) {
				throw new CustomException("No credits left for ", HttpStatus.PAYMENT_REQUIRED);
			}
			if (remainingSize > debitSize) {
				pricingService.updateImageStorageCredits(debitSize, Constants.DEBIT,
						"New Images Added for Existing Product for id :: " + existingProduct.getProductUuid());
			}
		}

		if (newImagesSize < deletedImageSize) {
			pricingService.updateImageStorageCredits((deletedImageSize - newImagesSize), Constants.CREDIT,
					"Image Deleted for Existing Product for id :: " + existingProduct.getProductUuid());
		}

	}

	private void checkProductStateForUpdate(Product product, String sUuid) {
		if (!product.getsUuid().equals(sUuid)) {
			throw new CustomException("You are not allowed to edit this product", HttpStatus.NOT_ACCEPTABLE);
		}
		if (product.isActive() && (product.getProductState().equals(ProductState.APPROVED)
				|| product.getProductState().equals(ProductState.PENDING))) {
			throw new CustomException("Product is Active. First deactivate the product then try again",
					HttpStatus.BAD_REQUEST);
		}
	}

	private Product productByUuid(String productUuid) {
		Product product = productRepo.findByProductUuid(productUuid);

		if (product != null) {
			return product;
		} else {
			throw new CustomException("Product not found for id :: " + productUuid, HttpStatus.BAD_REQUEST);
		}
	}

}
