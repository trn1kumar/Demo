package com.gloqr.service;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.gloqr.responses.FileUploadResponse;

public interface FileService {

	// Multiple files upload
	List<FileUploadResponse> sendMultipleFiles(List<MultipartFile> files, String location, String smeId)
			throws IOException;

	// Single file upload
	FileUploadResponse sendSingleFile(MultipartFile file, String fileLocation) throws IOException;

	// Delete multiple files from Content Server
	void deleteMultipleFiles(List<String> fileLocations) throws IOException;

}