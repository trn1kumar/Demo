package com.gloqr.service;

import java.util.List;
import java.util.Set;

import com.gloqr.dto.ProductDTO;
import com.gloqr.dto.ProductVO;
import com.gloqr.responses.FileUploadResponse;
import com.gloqr.responses.ProductDetails;
import com.gloqr.responses.ProductResponse;
import com.gloqr.responses.ProductsCount;
import com.gloqr.responses.PublishData;
import com.gloqr.responses.SingleProduct;

public interface ProductService {

	void addProduct(ProductDTO productDTO, String sUuid);

	List<ProductResponse> topProducts(String userUUID, int page);

	ProductDetails productByUuid(String productUuid, String userUUID);

	void deleteProduct(String productUuid, String suuid);

	void updateProduct(String productUuid, String sUuid, ProductDTO productDTO);

	void updateProductStatus(Set<PublishData> data);

	void productBiCount(String productUuid);

	ProductsCount smeProductsCount(String sUuid, boolean viewMode);

	List<ProductVO> productsOfSME(String sUuid);

	List<ProductVO> productsOfSME(String sUuid, String status);

	List<ProductResponse> smeProductsViewMode(String sUuid, String userUUID);

	void updateBusinessPostImages(List<FileUploadResponse> images);

	SingleProduct productForUpdate(String productUuid);

	void updateAutoQuotationStatus(String productUuid, ProductDTO productDTO);

}
