package com.gloqr.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.endpoint.CartEndpoint;
import com.gloqr.responses.ProductResponse;

@Service
public class CartServiceImpl implements CartService {

	@Autowired
	private CartEndpoint cartEndpoint;

	@Override
	public void addedToCartList(String userUUID, List<ProductResponse> products) {
		List<String> productUuids = cartEndpoint.addedToCartList(userUUID);
		if (productUuids != null) {
			products.stream().forEach(p -> {
				if (productUuids.contains(p.getProductUuid())) {
					p.setAddedToCart(true);
				}
			});
		}
	}

	@Override
	public boolean isAddedToCart(String userUUID, String productUuid) {
		List<String> productUuids = cartEndpoint.addedToCartList(userUUID);

		return productUuids != null && !productUuids.isEmpty() && productUuids.contains(productUuid);
	}

}
