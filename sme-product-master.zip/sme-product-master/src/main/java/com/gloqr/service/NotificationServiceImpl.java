package com.gloqr.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.gloqr.constants.ProductState;
import com.gloqr.dto.SMEInformationDto;
import com.gloqr.endpoint.NotificationEndPoint;
import com.gloqr.endpoint.SmeServerEndpoint;
import com.gloqr.entity.Product;
import com.gloqr.model.notification.EmailEvent;
import com.gloqr.repository.ProductRepo;

@Service
public class NotificationServiceImpl implements NotificationService {

	private Logger log = LogManager.getLogger();

	@Autowired
	private SmeServerEndpoint smeEndpoint;

	@Autowired
	private NotificationEndPoint notificationEndpoint;

	@Autowired
	private TemplateEngine templateEngine;

	@Value(value = "${verification.email.subject}")
	private String verificationEmailSubject;

	@Value(value = "${website.url}")
	private String websiteUrl;

	@Value(value = "${content.server.url}")
	private String contentServerUrl;

	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd 'at' hh:mm:ss a");

	public static final String VERIFICATION_TEMPLATE = "productsVerification.html";

	@Autowired
	private ProductRepo productRepo;

	@Override
	@Async
	public void productsVerificationSummaryNotifi(String smeId, List<Product> products) {

		SMEInformationDto sme = smeEndpoint.getSme(smeId);

		if (StringUtils.isNotBlank(sme.getContactEmail())) {
			List<Product> approvedProduct = new ArrayList<>();
			List<Product> rejectedProduct = new ArrayList<>();

			products.stream().forEach(product -> {
				if (product.getProductState().equals(ProductState.APPROVED))
					approvedProduct.add(product);
				else if (product.getProductState().equals(ProductState.REJECTED))
					rejectedProduct.add(product);
			});

			Context context = new Context();
			context.setVariable("smeName", sme.getSmeName());
			context.setVariable("approvedProduct", approvedProduct);
			context.setVariable("rejectedProduct", rejectedProduct);
			context.setVariable("totalApproved", approvedProduct.size());
			context.setVariable("totalRejected", rejectedProduct.size());
			context.setVariable("approvedDateTime", formatter.format(new Date()));
			context.setVariable("homeUrl", websiteUrl);
			context.setVariable("contentServerUrl", contentServerUrl);

			String mailPage = templateEngine.process(VERIFICATION_TEMPLATE, context);
			EmailEvent emailEvent = new EmailEvent(sme.getContactEmail(), verificationEmailSubject, mailPage);

			notificationEndpoint.sendEmail(emailEvent);

		} else {
			log.warn("Cant't send email..Email ID cannot be empty or null for SME ID :: " + smeId);
		}
	}

	@Override
	@Async
	public void updateCountInSmeModule(String sUuid, String token) {
		smeEndpoint.countUpdate(sUuid, productRepo.getCounts(sUuid), token);
	}

}
