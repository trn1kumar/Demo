package com.gloqr.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.endpoint.ContentServerEndpoint;
import com.gloqr.entity.ProductImage;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.Mapper;
import com.gloqr.repository.ProductImageRepo;
import com.gloqr.responses.FileUploadResponse;

@Service
public class FileServiceImpl implements FileService {

	@Autowired
	private ContentServerEndpoint contentServerEndpoint;

	@Autowired
	private ProductImageRepo imageRepo;

	@Autowired
	private Mapper mapper;

	@Override
	public List<FileUploadResponse> sendMultipleFiles(List<MultipartFile> files, String location, String smeId)
			throws IOException {

		List<String> imageNames = new ArrayList<>();

		files.forEach(file -> {
			String name = new Random().nextInt(10000) + file.getOriginalFilename();
			imageNames.add(name);
		});

		List<FileUploadResponse> uploadedImages = contentServerEndpoint.sendFilesToContentServer(files, imageNames,
				location.replace("{smeId}", smeId));

		List<ProductImage> temporaryImages = new ArrayList<>();

		uploadedImages.stream().forEach(u -> temporaryImages.add(mapper.convertToEntity(u, ProductImage.class)));

		try {
			imageRepo.saveAll(temporaryImages);
		} catch (Exception e) {
			throw new CustomException("Error while saving files in db", HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return uploadedImages;
	}

	@Override
	public FileUploadResponse sendSingleFile(MultipartFile file, String fileLocation) throws IOException {
		FileUploadResponse response = null;
		String imageName = null;
		try {
			imageName = new Random().nextInt(10000) + file.getOriginalFilename();
			response = contentServerEndpoint.sendSingleFile(file, imageName, fileLocation);
		} catch (CustomException e) {
			throw new CustomException(e.getMessage(), e.getStatus());
		}
		return response;
	}

	@Override
	public void deleteMultipleFiles(List<String> fileLocations) throws IOException {
		contentServerEndpoint.deleteMultipleFiles(fileLocations);
	}

}
