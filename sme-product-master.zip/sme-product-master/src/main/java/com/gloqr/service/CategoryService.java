package com.gloqr.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.gloqr.dto.CategoryDTO;
import com.gloqr.responses.SubCategoryResponse;

public interface CategoryService {

	List<CategoryDTO> menuBarData();

	Map<String, Object> productCategories();

	List<SubCategoryResponse> productSubCategories(String categoryUuid);

	Set<String> subCategorySpecs(String subCategoryUuid);

}
