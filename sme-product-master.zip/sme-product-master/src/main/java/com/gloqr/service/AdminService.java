package com.gloqr.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.Valid;

import com.gloqr.dto.CategoryDTO;
import com.gloqr.dto.MasterDataDTO;
import com.gloqr.dto.SubCategoryDTO;
import com.gloqr.entity.ProductSubCategory;
import com.gloqr.responses.AdminProductPublish;
import com.gloqr.responses.PublishData;
import com.gloqr.responses.SingleProduct;

public interface AdminService {

	/* Add Category */
	void addProductCategory(CategoryDTO categoryDTO);

	/* Add Category */
	void addProductSubCategory(String categoryUuid, SubCategoryDTO subCategoryDTO);

	/* Add SubCategory Specifications */
	void addSubCategorySpecifications(String subCategoryUuid, Set<MasterDataDTO> specificationDTO);

	/* Add Price Units */
	void addPriceUnits(@Valid Set<MasterDataDTO> priceUnitsDTO);

	/* SubCategory by uuid */
	ProductSubCategory getProductSubCategory(String subCategoryUuid);

	/* Reject or Approved products */
	void updateProductState(AdminProductPublish productPublish);

	/* Update of new edited images of product */
	void updateProductImages(PublishData publishData) throws IOException;

	/* Pending products of SME */
	List<SingleProduct> pendingProductsOfSME(String sUuid);

	/* Pending products of SME */
	Map<String, Integer> smePendingProductsCount(List<String> smeIds);
}
