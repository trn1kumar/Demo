package com.gloqr.endpoint;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.gloqr.model.notification.EmailEvent;
import com.gloqr.model.notification.SmsEvent;

public class NotificationEndPoint {

	private Client client;
	private String endPoint;
	private String emailPath;
	private String smsPath;

	Logger log = LogManager.getLogger();

	public NotificationEndPoint(Client client, String endPoint, String emailPath, String smsPath) {
		super();
		this.client = client;
		this.endPoint = endPoint;
		this.emailPath = emailPath;
		this.smsPath = smsPath;
	}

	public void sendSMS(SmsEvent smsEvent) {
		log.info("Sending SMS to Mobile Number :: " + smsEvent.getMobileNo());
		try {
			Response response = client.target(endPoint).path(smsPath).request(MediaType.APPLICATION_JSON)
					.post(Entity.entity(smsEvent, MediaType.APPLICATION_JSON));

			log.info("SMS Sent Response :: " + response.toString());
		} catch (Exception e) {
			log.error("Error while sending SMS :: " + e.toString());
		}
	}

	public void sendEmail(EmailEvent emailEvent) {
		log.info("Sending Email to Id :: " + emailEvent.getEmailId());
		try {
			Response response = client.target(endPoint).path(emailPath).request(MediaType.APPLICATION_JSON)
					.post(Entity.entity(emailEvent, MediaType.APPLICATION_JSON));

			log.info("Email Sent Response :: " + response.toString());
		} catch (Exception e) {
			log.error("Error while sending Email :: " + e.toString());
		}
	}
}
