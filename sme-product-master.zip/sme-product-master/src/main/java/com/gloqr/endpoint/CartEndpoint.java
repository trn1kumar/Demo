package com.gloqr.endpoint;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.gloqr.responses.CustomHttpResponse;
import com.gloqr.security.JWTConstants;
import com.gloqr.util.RequestParser;

public class CartEndpoint {
	Logger logger = LogManager.getLogger();

	private Client client;
	private String cartEndpointURL;
	private String listPath;

	@Autowired
	private RequestParser requestParser;

	public CartEndpoint(Client client, String cartEndpointURL, String listPath) {
		super();
		this.client = client;
		this.cartEndpointURL = cartEndpointURL;
		this.listPath = listPath;
	}

	public List<String> addedToCartList(String userUUID) {
		logger.info("Getting list of Product UUID from Cart Module for Checking is Product Added to cart for id :: "
				+ userUUID);

		Response response = null;
		List<String> productUuids = null;
		try {
			response = client.target(cartEndpointURL).path(listPath).request(MediaType.APPLICATION_JSON)
					.header(JWTConstants.HEADER_STRING, requestParser.getHeader()).get();

			logger.info("Response from Cart enpoint :: " + response.toString());

			CustomHttpResponse<List<String>> httpResponse = response
					.readEntity(new GenericType<CustomHttpResponse<List<String>>>() {
					});

			return httpResponse.getData();
		} catch (Exception e) {
			logger.info("Error in Cart Endpoint :: " + e.toString());
		}
		return productUuids;
	}
}
