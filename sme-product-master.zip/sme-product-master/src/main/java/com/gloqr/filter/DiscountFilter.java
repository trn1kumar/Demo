package com.gloqr.filter;

import java.io.Serializable;

public class DiscountFilter implements Comparable<DiscountFilter>, Serializable {

	private static final long serialVersionUID = 1L;

	private String value;
	private boolean selected;
	private int count;

	public DiscountFilter(String value, int count) {
		super();
		this.value = value;
		this.count = count;
	}

	public DiscountFilter() {
		super();
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public String getValue() {
		return value;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DiscountFilter other = (DiscountFilter) obj;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value)) {
			return false;
		}
		return true;
	}

	@Override
	public int compareTo(DiscountFilter o) {
		return this.value.compareTo(o.value);
	}
}
