package com.gloqr.filter;

import java.io.Serializable;

public class FilterResult implements Serializable {

	private static final long serialVersionUID = 1L;

	private Filter filter;
	private ProductFilter response;
	private Object category;

	public FilterResult(Filter filter, ProductFilter response) {
		super();
		this.filter = filter;
		this.response = response;
	}

	public FilterResult() {
		super();
	}

	public Object getCategory() {
		return category;
	}

	public void setCategory(Object category) {
		this.category = category;
	}

	public Filter getFilter() {
		return filter;
	}

	public ProductFilter getResponse() {
		return response;
	}

	public void setFilter(Filter filter) {
		this.filter = filter;
	}

	public void setResponse(ProductFilter response) {
		this.response = response;
	}

}
