package com.gloqr.filter;

import java.io.Serializable;
import java.util.List;

import com.gloqr.responses.ProductResponse;

public class ProductFilter implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<ProductResponse> result;
	private long totalCount;

	public ProductFilter() {

	}

	public ProductFilter(List<ProductResponse> result, long totalCount) {
		this.result = result;
		this.totalCount = totalCount;
	}

	public List<ProductResponse> getResult() {
		return result;
	}

	public long getTotalCount() {
		return totalCount;
	}

	public void setResult(List<ProductResponse> result) {
		this.result = result;
	}

	public void setTotalCount(long totalCount) {
		this.totalCount = totalCount;
	}

}
