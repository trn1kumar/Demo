package com.gloqr.constants;

public enum ProductState {
	PENDING, APPROVED, REJECTED, DELETED
}
