package com.gloqr.constants;

public enum QuotationFormat {

	FORMAT_ONE, FORMAT_TWO, FORMAT_THREE;

}
