package com.gloqr.constants;

public class Constants {

	private Constants() {
		super();
	}

	// Role Constants
	public static final String ROLE_SME = "hasAnyRole('SME-ADMIN')";
	public static final String ROLE_USER = "hasAnyRole('USER')";
	public static final String ROLE_SME_AND_USER = "hasAnyRole('SME-ADMIN','USER')";
	public static final String ROLE_GLOQR_ADMIN = "hasAnyRole('GLOQR-SUPER-ADMIN')";
	public static final String ROLE_GLOQR_AND_SME = "hasAnyRole('GLOQR-SUPER-ADMIN','SME-ADMIN')";
	
	public static final String GLOQR_SUPER_ADMIN = "GLOQR-SUPER-ADMIN";

	// Content Server File Path
	public static final String FILE_LOCATION = "sme/{smeId}/products";
	public static final String CATEGORY_FILE_LOCATION = "gloqr-platform/categoryImages/products";

	// Pricing
	public static final String CREDIT = "CREDIT";
	public static final String DEBIT = "DEBIT";
}
