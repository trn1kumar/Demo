package com.gloqr.constants;

public enum ProductStatus {

	ACTIVE, DEACTIVE;
}
