package com.gloqr.constants;

public class URLMapping {

	private URLMapping() {
		super();
	}

	public static final String BASE_URL = "api/products";

	// Admin Controller
	public static final String BASE_URL_ADMIN = BASE_URL + "/admin";

	public static final String CATEGORY = "categories";
	public static final String SUBCATEGORY = "categories/{categoryUuid}/subcategories";
	public static final String SPECIFICATION = "subcategories/{subCategoryUuid}/specifications";
	public static final String PRICE_UNIT = "price-units";
	public static final String PRODUCT_STATE = "state";
	public static final String PRODUCT_IMAGES = "images";
	public static final String SME_PENDING_PRODUCTS = "sme/{sUuid}/pending";
	public static final String SME_PENDING_PRODUCTS_COUNT = "count";
	public static final String UPDATE_COUNTS = "update-counts";

	// File Controller
	public static final String MULTIPLE_FILE = "files";
	public static final String SINGLE_FILE = "file";

	// Product Controller
	public static final String PRODUCT = "product";
	public static final String TOP_PRODUCTS = "top";
	public static final String SIMILAR_PRODUCTS = "similar";
	public static final String PRODUCT_BY_UUID = "{productUuid}/product";
	public static final String PRODUCT_FOR_UPDATE = "{productUuid}/product-details";
	public static final String PRODUCT_BI_COUNT = "{productUuid}/bi-count";
	public static final String SME_PRODUCT_COUNT = "sme/{sUuid}/count";
	public static final String SME_PRODUCTS = "sme";
	public static final String SME_PRODUCTS_VIEW = "{sUuid}/sme";
	public static final String BUSINESS_POST_IMAGE = "post-images";
	public static final String AUTO_QUOTATION = "{productUuid}/auto-quotation";

	// Search Controller
	public static final String PRODUCTS_BY_CATEGORY = "{categoryName}";
	public static final String PRODUCTS_BY_SUBCATEGORY = "{categoryName}/{subCategoryName}";
	public static final String SEARCH_SUGGEST = "search-suggests";
	public static final String SEARCH_RESULT = "search/p";

	// Category Controller
	public static final String NAV_CATEGORIES = "nav-categories";
}
