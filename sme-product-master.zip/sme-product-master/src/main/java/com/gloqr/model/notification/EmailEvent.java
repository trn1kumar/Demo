package com.gloqr.model.notification;

import java.io.File;

public class EmailEvent {

	private String emailId;
	private String subject;
	private String eventMessage;
	private boolean sentStatus;
	private File file;

	public EmailEvent() {
		super();
	}

	public EmailEvent(String emailId, String subject, String eventMessage) {
		super();
		this.emailId = emailId;
		this.subject = subject;
		this.eventMessage = eventMessage;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getEventMessage() {
		return eventMessage;
	}

	public void setEventMessage(String eventMessage) {
		this.eventMessage = eventMessage;
	}

	public boolean isSentStatus() {
		return sentStatus;
	}

	public void setSentStatus(boolean sentStatus) {
		this.sentStatus = sentStatus;
	}

	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}

}
