package com.gloqr.util;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.exception.CustomException;

@Component
public class FileUtil {

	private final List<String> fileTypes = Arrays.asList("image/png", "image/jpeg", "image/jpg");

	public void checkFileFormat(MultipartFile file) {
		if (fileTypes.indexOf(file.getContentType()) == -1) {
			throw new CustomException(
					"Please select correct format for File type. Supported file formats are .png .jpeg .jpg",
					HttpStatus.BAD_REQUEST);
		}
	}

	public void checkFileFormat(List<MultipartFile> files) {

		if (files.size() > 5) {
			throw new CustomException("Maximum 5 Files can be uploaded", HttpStatus.BAD_REQUEST);
		}

		files.stream().forEach(file -> {
			if (fileTypes.indexOf(file.getContentType()) == -1) {
				throw new CustomException(
						"Please select correct format for File type. Supported file formats are .png .jpeg .jpg",
						HttpStatus.BAD_REQUEST);
			}
		});

	}
}
