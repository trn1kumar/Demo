package com.gloqr.exception;

import java.util.List;

public class ValidationErrors {

	private List<String> errors;

	public ValidationErrors(List<String> errors) {
		super();
		this.errors = errors;
	}

	public ValidationErrors() {
		super();
	}

	public List<String> getErrors() {
		return errors;
	}

}
