package com.gloqr.aspectlogger;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.gloqr.dto.ImageDTO;
import com.gloqr.dto.ProductDTO;
import com.gloqr.exception.CreditType;
import com.gloqr.exception.CustomException;
import com.gloqr.exception.NoCreditException;
import com.gloqr.service.PricingService;

@Aspect
@Configuration
public class CheckCreditsImpl {

	@Autowired
	private PricingService pricingService;

	@Before("execution(* com.gloqr.controller.*.*(..)) && @annotation(checkCredits) && args(productDTO)")
	public void beforeMethodExecution(JoinPoint joinPoint, CheckCredits checkCredits, ProductDTO productDTO) {
		long totalImagesSize = 0;

		try {
			if (productDTO.getImages() != null && !productDTO.getImages().isEmpty()) {
				for (ImageDTO image : productDTO.getImages()) {
					totalImagesSize += image.getSize();
				}

				if (pricingService.checkImageCredits() < totalImagesSize) {
					throw new NoCreditException(CreditType.IMAGE_STORAGE);
				}
			}

			if (productDTO.isActive()) {
				pricingService.checkListingCredits();
			}

		} catch (CustomException e) {
			throw new CustomException(e.getMessage(), e.getStatus());
		}
	}

}
