package com.gloqr.dto;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_DEFAULT)
public class SubCategoryDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String subCategoryUuid;

	private String urlName;

	@NotBlank(message = "{subcategory.name}")
	private String subCategoryName;

	@NotBlank(message = "{file.location}")
	private String fileLocation;

	@Valid
	private List<MasterDataDTO> specifications;

	@JsonIgnoreProperties("subCategories")
	private CategoryDTO productCategory;

	private long productsCount;

	public long getProductsCount() {
		return productsCount;
	}

	public String getSubCategoryUuid() {
		return subCategoryUuid;
	}

	public String getUrlName() {
		return urlName;
	}

	public String getSubCategoryName() {
		return subCategoryName;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public List<MasterDataDTO> getSpecifications() {
		return specifications;
	}

	public void setSubCategoryUuid(String subCategoryUuid) {
		this.subCategoryUuid = subCategoryUuid;
	}

	public void setUrlName(String urlName) {
		this.urlName = urlName;
	}

	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

	public void setProductsCount(long productsCount) {
		this.productsCount = productsCount;
	}

	public CategoryDTO getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(CategoryDTO productCategory) {
		this.productCategory = productCategory;
	}

}
