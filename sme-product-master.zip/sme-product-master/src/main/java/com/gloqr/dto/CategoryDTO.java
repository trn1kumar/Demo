package com.gloqr.dto;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class CategoryDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String categoryUuid;

	private String urlName;

	@NotBlank(message = "{category.name}")
	private String categoryName;

	@NotBlank(message = "{file.location}")
	private String fileLocation;

	@JsonIgnoreProperties("productCategory")
	@Valid
	private List<SubCategoryDTO> subCategories;

	public String getFileLocation() {
		return fileLocation;
	}

	public String getCategoryUuid() {
		return categoryUuid;
	}

	public String getUrlName() {
		return urlName;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public List<SubCategoryDTO> getSubCategories() {
		return subCategories;
	}

	public void setCategoryUuid(String categoryUuid) {
		this.categoryUuid = categoryUuid;
	}

	public void setUrlName(String urlName) {
		this.urlName = urlName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

	public void setSubCategories(List<SubCategoryDTO> subCategories) {
		this.subCategories = subCategories;
	}

}
