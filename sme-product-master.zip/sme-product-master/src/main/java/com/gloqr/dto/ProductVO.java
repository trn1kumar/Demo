package com.gloqr.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.gloqr.constants.ProductState;

@JsonInclude(Include.NON_DEFAULT)
public class ProductVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String productUuid;
	private String productName;
	private String productUrlName;
	private String sUuid;
	private String smeName;
	private String mainImage;
	private String priceUnit;
	private Double price;
	private Double discountedPrice;
	private int discount;
	private int biCount;
	private int minOrderQty;
	private ProductState productState;
	private boolean active;
	private boolean modified;
	private boolean autoQuotation;
	private Date createdAt;
	private Date updatedAt;
	private String feedbackMessage;

	public boolean isAutoQuotation() {
		return autoQuotation;
	}

	public void setAutoQuotation(boolean autoQuotation) {
		this.autoQuotation = autoQuotation;
	}

	public int getBiCount() {
		return biCount;
	}

	public void setBiCount(int biCount) {
		this.biCount = biCount;
	}

	public int getMinOrderQty() {
		return minOrderQty;
	}

	public void setMinOrderQty(int minOrderQty) {
		this.minOrderQty = minOrderQty;
	}

	public String getProductUuid() {
		return productUuid;
	}

	public String getProductName() {
		return productName;
	}

	public String getProductUrlName() {
		return productUrlName;
	}

	public String getsUuid() {
		return sUuid;
	}

	public String getSmeName() {
		return smeName;
	}

	public String getMainImage() {
		return mainImage;
	}

	public String getPriceUnit() {
		return priceUnit;
	}

	public Double getPrice() {
		return price;
	}

	public Double getDiscountedPrice() {
		return discountedPrice;
	}

	public int getDiscount() {
		return discount;
	}

	public void setProductUuid(String productUuid) {
		this.productUuid = productUuid;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public void setProductUrlName(String productUrlName) {
		this.productUrlName = productUrlName;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public void setMainImage(String mainImage) {
		this.mainImage = mainImage;
	}

	public void setPriceUnit(String priceUnit) {
		this.priceUnit = priceUnit;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public void setDiscountedPrice(Double discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}

	public ProductState getProductState() {
		return productState;
	}

	public boolean isActive() {
		return active;
	}

	public boolean isModified() {
		return modified;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public String getFeedbackMessage() {
		return feedbackMessage;
	}

	public void setProductState(ProductState productState) {
		this.productState = productState;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setModified(boolean modified) {
		this.modified = modified;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}

}
