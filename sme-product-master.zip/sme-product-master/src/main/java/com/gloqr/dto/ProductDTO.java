package com.gloqr.dto;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.gloqr.constants.QuotationFormat;
import com.gloqr.entity.OtherCategory;

public class ProductDTO {

	private String subCategoryUuid;

	@Size(min = 3, max = 100, message = "{product.name.size}")
	@NotBlank(message = "{product.name}")
	private String productName;

	@NotBlank(message = "{product.desc}")
	@Size(min = 50, max = 1500, message = "{product.desc.size}")
	private String description;

	@Size(max = 200, message = "{product.location.size}")
	@Pattern(regexp = "^[a-zA-Z, ]*$", message = "{product.location.pattern}")
	private String location;

	@Size(min = 20, max = 2000, message = "{product.terms.size}")
	@NotBlank(message = "{product.terms}")
	private String termsAndCondition;
	private String priceUnit;

	@NotNull(message = "{product.price}")
	private Double price;

	private int discount;
	private float gst;
	private long stock;
	private boolean active;
	private boolean businessPost;
	private boolean autoQuotation;
	private Map<String, String> specifications;

	@Min(value = 1, message = "{product.minorderqty.min}")
	private int minOrderQty;

	@Valid
	private List<ImageDTO> images;

	private List<ImageDTO> deletedImages;

	@NotNull(message = "{quotation.format}")
	private QuotationFormat quotationFormat;

	@Valid
	private OtherCategory otherCategory;

	private String mainImage;

	public boolean isAutoQuotation() {
		return autoQuotation;
	}

	public String getProductName() {
		return productName;
	}

	public String getDescription() {
		return description;
	}

	public String getLocation() {
		return location;
	}

	public String getTermsAndCondition() {
		return termsAndCondition;
	}

	public String getPriceUnit() {
		return priceUnit;
	}

	public Double getPrice() {
		return price;
	}

	public int getDiscount() {
		return discount;
	}

	public float getGst() {
		return gst;
	}

	public long getStock() {
		return stock;
	}

	public int getMinOrderQty() {
		return minOrderQty;
	}

	public boolean isBusinessPost() {
		return businessPost;
	}

	public Map<String, String> getSpecifications() {
		return specifications;
	}

	public List<ImageDTO> getImages() {
		return images;
	}

	public QuotationFormat getQuotationFormat() {
		return quotationFormat;
	}

	public String getSubCategoryUuid() {
		return subCategoryUuid;
	}

	public boolean isActive() {
		return active;
	}

	public List<ImageDTO> getDeletedImages() {
		return deletedImages;
	}

	public OtherCategory getOtherCategory() {
		return otherCategory;
	}

	public String getMainImage() {
		return mainImage;
	}
}
