package com.gloqr.http.response.module;

public class ResponseMessages {

	private ResponseMessages() {
		throw new IllegalStateException("ResponseMessages class.can't initiate");
	}

	public static final String SUCCESS = "Success";
	public static final String VERIFIED = "User Verified Successfully";

	public static final String ACCOUNT_UPDATED = "Account Details Changed Successfully";

	public static final String UPLOADED_PROFILE_IMG = "Profile Img Uploded Successfully";
	public static final String REMOVED_PROFILE_IMG = "Profile Img Removed Successfully";

	public static final String PASSWORD_UPDATED = "Password Changed Successfully";

	public static final String USERNAME_CHECKED_AND_OTP_GENERATED = "OTP Successfully sent on {username}";
}
