package com.gloqr.vo;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(Include.NON_DEFAULT)
public class RegisterUser {

	private String uuid;

	@NotBlank(message = "please enter your fullname")
	@Pattern(regexp = "^[a-zA-Z? ]+$", message = "please enter valid fullname,numbers and special characters not allowed")
	private String userFullName;

	@NotBlank(message = "Username (email/mobile number)Required.")
	private String username;

	@Length(min = 5, message = "Your password must have at least 5 characters")
	@NotBlank(message = "Please enter your password")
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private String userPassword;

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	@Override
	public String toString() {
		return "RegisterUser [userFullName=" + userFullName + ", username=" + username + "]";
	}

}
