package com.gloqr.vo;

import javax.validation.constraints.NotBlank;


//@FieldMatch(first = "password", second = "confirmPassword", message = "The password fields must match")
public class ResetPassword {

	@NotBlank(message = "uuid required")
	private String uuid;

	@NotBlank(message = "password can not be empty")
	private String newPassword;

	private String confirmPassword;

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

}
