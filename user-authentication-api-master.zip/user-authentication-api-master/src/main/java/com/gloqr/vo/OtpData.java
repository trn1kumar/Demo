package com.gloqr.vo;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.gloqr.constants.NotificationFlow;
import com.gloqr.constants.UserState;

public class OtpData {

	private String uuid;

	@NotBlank(message = "Username (email/mobile number) Required.")
	private String username;

	@JsonProperty(access = Access.WRITE_ONLY)
	private UserState userState;

	@JsonProperty(access = Access.WRITE_ONLY)
	private NotificationFlow flowType;

	@JsonProperty(access = Access.WRITE_ONLY)
	private int otp;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public UserState getUserState() {
		return userState;
	}

	public void setUserState(UserState userState) {
		this.userState = userState;
	}

	public int getOtp() {
		return otp;
	}

	public void setOtp(int otp) {
		this.otp = otp;
	}

	public NotificationFlow getFlowType() {
		return flowType;
	}

	public void setFlowType(NotificationFlow flowType) {
		this.flowType = flowType;
	}

}
