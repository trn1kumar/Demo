package com.gloqr.vo;

import javax.validation.constraints.NotBlank;


public class UserUpdate {

	private String uuid;

	private String userFullName;

	@NotBlank(message = "Username (email/mobile number) Required.")
	private String newUsername;

	private String password;

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getNewUsername() {
		return newUsername;
	}

	public void setNewUsername(String newUsername) {
		this.newUsername = newUsername;
	}

}
