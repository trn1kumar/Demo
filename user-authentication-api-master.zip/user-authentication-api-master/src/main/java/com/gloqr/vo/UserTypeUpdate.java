package com.gloqr.vo;

import javax.validation.constraints.NotNull;

import com.gloqr.constants.UserType;

public class UserTypeUpdate {

	private String uuid;

	@NotNull(message = "newUserType Required")
	private UserType newUserType;

	private String sUuid;

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public UserType getNewUserType() {
		return newUserType;
	}

	public void setNewUserType(UserType newUserType) {
		this.newUserType = newUserType;
	}

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

}
