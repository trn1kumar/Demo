package com.gloqr.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.entities.Address;

public interface AddressRepository extends JpaRepository<Address, Long> {
		
	Address findByAddrsUuid(String addrsUuid);
}
