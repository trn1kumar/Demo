package com.gloqr.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.entities.UserRole;

public interface RoleRepository extends JpaRepository<UserRole, Long>{

	UserRole findByRole(String smeAdmin);

}
