package com.gloqr.repository;

import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gloqr.entities.User;

public interface UserRepository extends JpaRepository<User, Long> {

	User findByUuid(String uuid);

	User findByUserEmail(String emailId);

	User findByUserMobile(String usermobile);

	boolean existsByUuid(String uuid);
	
	List<User> findAllByUuidIn(Set<String> userUuids);

	@Modifying
	@Transactional
	@Query("update User u set u.password = :password where u.uuid = :uuid")
	void updatePassword(@Param("password") String password, @Param("uuid") String uuid);

	@Query("select password from User u where u.uuid=:uuid")
	String getPassword(@Param("uuid") String uuid);

	@Query("select u from User u JOIN u.userDetail ud where u.userEmail=:email AND ud.userVerified=true")
	User findVerifiedUserByEmail(@Param("email") String email);

	@Query("select u from User u JOIN u.userDetail ud where u.userMobile=:mobileNumber AND ud.userVerified=true")
	User findVerifiedUserByMobileNumber(@Param("mobileNumber") String mobileNumber);

	@Query("SELECT CASE WHEN COUNT(u) > 0 THEN true ELSE false END FROM User u JOIN u.userDetail ud WHERE u.userEmail=:email AND ud.userVerified=true")
	boolean existsVerifiedUserByEmail(@Param("email") String email);

	@Query("SELECT CASE WHEN COUNT(u) > 0 THEN true ELSE false END FROM User u JOIN u.userDetail ud WHERE u.userMobile=:mobileNumber AND ud.userVerified=true")
	boolean existsVerifiedUserByMobile(@Param("mobileNumber") String mobileNumber);

	

}
