package com.gloqr.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.gloqr.exception.CustomException;

@Component
public class UserMapper {

	public <T> T convertToEntity(Object srcObj, Class<T> targetClass) {
		T entity = null;

		try {
			entity = new ModelMapper().map(srcObj, targetClass);
		} catch (IllegalArgumentException e) {
			throw new CustomException("source or destinationType can not be null", HttpStatus.BAD_REQUEST, e);
		} catch (Exception e) {
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
		return entity;
	}

	public <T> T convertToDto(Object srcObj, Class<T> targetClass) {
		T dto = null;

		try {
			dto = new ModelMapper().map(srcObj, targetClass);
		} catch (IllegalArgumentException e) {
			throw new CustomException("source or destinationType can not be null", HttpStatus.BAD_REQUEST, e);
		} catch (Exception e) {
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
		return dto;
	}

}
