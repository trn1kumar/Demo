package com.gloqr.dao;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.entities.Address;
import com.gloqr.entities.User;
import com.gloqr.exception.CustomException;
import com.gloqr.repository.AddressRepository;
import com.gloqr.repository.UserRepository;

@Service
public class UserDaoImpl implements UserDao {

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private AddressRepository addressRepository;

	@Override
	public User saveUser(User user) {
		try {
			userRepo.save(user);
		} catch (Exception e) {
			throw new CustomException("Exception in saveUser(){ }. message:- " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
		return user;
	}

	@Override
	public Address getAddress(String addrsUuid) {
		Address address = addressRepository.findByAddrsUuid(addrsUuid);
		if (address != null) {
			return address;
		} else {
			throw new CustomException("Address Not found " + addrsUuid, HttpStatus.NOT_FOUND);
		}

	}

	@Override
	public Address saveAddress(Address address) {
		try {
			addressRepository.save(address);
		} catch (Exception e) {
			throw new CustomException("Exception in saveAddress(){ }.", HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
		return address;
	}

	@Override
	public boolean isUserExist(String uuid) {
		return userRepo.existsByUuid(uuid);
	}

	@Override
	public User getUserByUuid(String uuid) {
		User user = userRepo.findByUuid(uuid);
		if (user == null) {
			throw new CustomException("User not present with id " + uuid, HttpStatus.NOT_FOUND);
		}
		return user;
	}

	@Override
	public User findByUserEmail(String emailId) {
		return userRepo.findByUserEmail(emailId);

	}

	@Override
	public User findByUserMobile(String mobileNum) {
		return userRepo.findByUserMobile(mobileNum);
	}

	@Override
	public User getVerifiedUserByEmailId(String email) {
		return userRepo.findVerifiedUserByEmail(email);
	}

	@Override
	public User getVerifiedUserByMobileNumber(String mobileNumber) {
		return userRepo.findVerifiedUserByMobileNumber(mobileNumber);
	}

	@Override
	public void deleteUnVerifiedUser(User user) {
		try {

			if (user.getUserDetail().isUserVerified()) {
				throw new CustomException("Trying to delete verified user. User deletion failed!",
						HttpStatus.BAD_REQUEST);
			}

			user.getRoles().removeAll(user.getRoles());
			userRepo.delete(user);
		} catch (Exception e) {
			throw new CustomException("Exception in deleteUnVerifiedUser(){ }. message:- " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
	}

	@Override
	public boolean isVerifiedUserFoundByEmail(String email) {
		return userRepo.existsVerifiedUserByEmail(email);
	}

	@Override
	public boolean isVerifiedUserFoundByMobile(String mobile) {
		return userRepo.existsVerifiedUserByMobile(mobile);
	}

	@Override
	public List<User> getUsersInfo(Set<String> userUuids) {

		List<User> users = userRepo.findAllByUuidIn(userUuids);
		if (users.isEmpty()) {
			throw new CustomException("Users list is empty", HttpStatus.NOT_FOUND);
		}
		return users;
	}
}
