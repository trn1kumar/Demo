package com.gloqr.dao;

import java.util.List;
import java.util.Set;

import com.gloqr.entities.Address;
import com.gloqr.entities.User;

public interface UserDao {

	User saveUser(User user);

	Address getAddress(String addrsUuid);

	Address saveAddress(Address existAddress);

	boolean isUserExist(String uuid);

	User getUserByUuid(String uuid);

	User findByUserEmail(String emailId);

	User findByUserMobile(String mobileNum);

	User getVerifiedUserByEmailId(String email);

	User getVerifiedUserByMobileNumber(String mobileNumber);

	void deleteUnVerifiedUser(User user);

	public boolean isVerifiedUserFoundByEmail(String email);

	public boolean isVerifiedUserFoundByMobile(String mobile);

	List<User> getUsersInfo(Set<String> userUuids);

}
