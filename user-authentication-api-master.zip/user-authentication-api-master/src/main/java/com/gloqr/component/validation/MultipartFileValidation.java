package com.gloqr.component.validation;

import org.springframework.web.multipart.MultipartFile;

public interface MultipartFileValidation {

	public void checkValidation(MultipartFile logoImage);
}
