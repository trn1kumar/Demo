package com.gloqr.entities;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.gloqr.audit.DateAuditable;
import com.gloqr.constants.RegistrationProviders;

@Entity
@Table(name = "User_Detail")
public class UserDetail extends DateAuditable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "user_detail_id")
	private Long id;

	@Column(name = "user_detail_uuid")
	private String userDetailsUuid;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id")
	private List<Address> address;

	@Column(name = "registration_provider")
	@Enumerated(EnumType.STRING)
	private RegistrationProviders registrationProvider;

	@Column(name = "profileImage")
	private String profileImage;

	@Column(name = "active")
	private boolean active;

	@Column(name = "userVerified")
	private boolean userVerified;

	@Column(name = "emailVerified")
	private boolean emailVerified;

	@Column(name = "mobileVerified")
	private boolean mobileVerified;

	@Column(name = "last_login")
	private Date lastLogin;

	@Column(name = "active_from")
	private Date activeFrom;

	@Column(name = "deactive_from")
	private Date deactiveFrom;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<Address> getAddress() {
		return address;
	}

	public String getUserDetailsUuid() {
		return userDetailsUuid;
	}

	public void setUserDetailsUuid(String userDetailsUuid) {
		this.userDetailsUuid = userDetailsUuid;
	}

	public void setAddress(List<Address> address) {
		this.address = address;
	}

	public RegistrationProviders getRegistrationProvider() {
		return registrationProvider;
	}

	public void setRegistrationProvider(RegistrationProviders registrationProvider) {
		this.registrationProvider = registrationProvider;
	}

	public String getProfileImage() {
		return profileImage;
	}

	public void setProfileImage(String profileImage) {
		this.profileImage = profileImage;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean isUserVerified() {
		return userVerified;
	}

	public void setUserVerified(boolean userVerified) {
		this.userVerified = userVerified;
	}

	public boolean isEmailVerified() {
		return emailVerified;
	}

	public void setEmailVerified(boolean emailVerified) {
		this.emailVerified = emailVerified;
	}

	public boolean isMobileVerified() {
		return mobileVerified;
	}

	public void setMobileVerified(boolean mobileVerified) {
		this.mobileVerified = mobileVerified;
	}

	public Date getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(Date lastLogin) {
		this.lastLogin = lastLogin;
	}

	public Date getActiveFrom() {
		return activeFrom;
	}

	public void setActiveFrom(Date activeFrom) {
		this.activeFrom = activeFrom;
	}

	public Date getDeactiveFrom() {
		return deactiveFrom;
	}

	public void setDeactiveFrom(Date deactiveFrom) {
		this.deactiveFrom = deactiveFrom;
	}

}
