package com.gloqr.aspectlogger;

import java.util.Arrays;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import com.gloqr.exception.CustomException;

@Aspect
@Component
public class CentralLoggingHandler {

	private static final Logger log = LogManager.getLogger();

	@Pointcut("execution(* com.gloqr.controller.*.*(..))")
	private void loggingOperation() {
	}
	
	@Before(value = "loggingOperation()")
	public void logBefore(JoinPoint joinPoint) {
		log.debug("In " + joinPoint.getSignature().getDeclaringTypeName() + " having method :: "
				+ joinPoint.getSignature().getName() + "() begins with ");

		log.info("In " + joinPoint.getSignature().getDeclaringTypeName() + " having method :: "
				+ joinPoint.getSignature().getName() + "() begins with ");

	}

	@AfterReturning(pointcut = "loggingOperation()", returning = "result")
	public void logAfterReturning(JoinPoint joinPoint, Object result) {
		log.debug("In " + joinPoint.getSignature().getDeclaringTypeName() + " having method :: "
				+ joinPoint.getSignature().getName() + "() ends with " + result);
		log.info("In " + joinPoint.getSignature().getDeclaringTypeName() + " having method :: "
				+ joinPoint.getSignature().getName() + "() ends with " + result);
	}

	@AfterThrowing(pointcut = "loggingOperation()", throwing = "e")
	public void logAfterThrowing(JoinPoint joinPoint, Throwable e) {
		log.error("An exception " + e.getMessage() + " has been thrown in class "
				+ joinPoint.getSignature().getDeclaringTypeName() + " which has method "
				+ joinPoint.getSignature().getName() + "()" + " with arguments "
				+ Arrays.toString(joinPoint.getArgs()));

		log.debug("An exception " + e.getMessage() + " has been thrown in class "
				+ joinPoint.getSignature().getDeclaringTypeName() + " which has method "
				+ joinPoint.getSignature().getName() + "()" + " with arguments "
				+ Arrays.toString(joinPoint.getArgs()));
		if (!(e instanceof CustomException)) {
			log.error(e);
			log.debug(e);
		}

	}

	

}
