package com.gloqr.security.configuration;

import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.gloqr.entities.User;
import com.gloqr.exception.CustomException;
import com.gloqr.security.context.holder.AuthUser;
import com.gloqr.service.UserService;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.SignatureException;

@Component
public class JwtTokenUtil {

	@Autowired
	private UserService userService;

	private Logger log = LogManager.getLogger(JwtTokenUtil.class);

	public Claims getJwtClaims(String jwtToken) {
		try {

			final JwtParser jwtParser = Jwts.parser().setSigningKey(JwtConstants.SIGNING_KEY);

			final Jws<?> claimsJws = jwtParser.parseClaimsJws(jwtToken);

			return (Claims) claimsJws.getBody();
		} catch (ExpiredJwtException e) {
			throw new CustomException("The JwtToken is expired and not valid anymore", HttpStatus.FORBIDDEN, e);
		} catch (SignatureException e) {
			throw new CustomException("Invalid JwtToken Signature. Message: " + e.getMessage(), HttpStatus.FORBIDDEN,
					e);
		} catch (MalformedJwtException e) {
			throw new CustomException("Invalid JwtToken Format. Message: " + e.getMessage(), HttpStatus.FORBIDDEN, e);
		} catch (Exception e) {
			throw new CustomException("an error occured during parsing JwtToken. Message: " + e.getMessage(),
					HttpStatus.FORBIDDEN, e);
		}

	}

	public String generateToken(Authentication authentication, User user) {
		final String authorities = authentication.getAuthorities().stream().map(GrantedAuthority::getAuthority)
				.collect(Collectors.joining(","));
		final String userFirstName = user.getUserFullName().split(" ")[0];
		return Jwts.builder().claim(JwtConstants.FIRST_NAME, userFirstName)
				.claim(JwtConstants.PROFILE_IMAGE, user.getUserDetail().getProfileImage())
				.claim(JwtConstants.USER_TYPE, user.getUserType()).claim(JwtConstants.SME_ID, user.getsUuid())
				.claim(JwtConstants.USER_ID, user.getUuid()).setSubject(authentication.getName())
				.claim(JwtConstants.AUTHORITIES_KEY, authorities).signWith(SignatureAlgorithm.HS256, JwtConstants.SIGNING_KEY)
				.setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + JwtConstants.ACCESS_TOKEN_VALIDITY_SECONDS * 1000))
				.compact();
	}

	UsernamePasswordAuthenticationToken getAuthentication(final String jwtToken, final UserDetails userDetails) {

		final Claims claims = getJwtClaims(jwtToken);
		final Collection<? extends GrantedAuthority> authorities = Arrays
				.stream(claims.get(JwtConstants.AUTHORITIES_KEY).toString().split(",")).map(SimpleGrantedAuthority::new)
				.collect(Collectors.toList());

		return new UsernamePasswordAuthenticationToken(userDetails, "", authorities);
	}

	public String authenticateUser(User user, String username) {

		if (user == null || username == null) {
			throw new CustomException("'user' or 'username' is null.required both", HttpStatus.INTERNAL_SERVER_ERROR);
		}

		UserDetails userDetails = new AuthUser(user.getUuid(), user.getsUuid(), username, user.getPassword(),
				userService.getAuthority(user.getRoles()));

		Authentication authentication = new UsernamePasswordAuthenticationToken(userDetails, "",
				userDetails.getAuthorities());

		final String token = this.generateToken(authentication, user);
		log.info("authenticated user " + authentication.getName() + ", setting security context");
		SecurityContextHolder.getContext().setAuthentication(authentication);
		return token;

	}

}
