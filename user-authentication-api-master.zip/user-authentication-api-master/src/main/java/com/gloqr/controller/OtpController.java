package com.gloqr.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.UrlMapping;
import com.gloqr.exception.CustomException;
import com.gloqr.http.response.module.CustomHttpResponse;
import com.gloqr.http.response.module.ResponseMaker;
import com.gloqr.http.response.module.ResponseMessages;
import com.gloqr.service.OtpService;
import com.gloqr.util.ValidationUtil;
import com.gloqr.vo.OtpData;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = UrlMapping.ROOT_API)
public class OtpController {

	@Autowired
	private ValidationUtil validationUtil;

	@Autowired
	private OtpService otpService;

	@Autowired
	private ResponseMaker responseMaker;

	@PostMapping(UrlMapping.GENERATE_OTP)
	public ResponseEntity<CustomHttpResponse<OtpData>> generateOtp(@Valid @RequestBody OtpData userDetail) {

		/*
		 * Used in 'FORGOT_PASS, OTP_LOGIN' flow and resend otp for particular flow and also sign up resend otp flow .
		 */

		try {

			if (userDetail.getFlowType() == null) {
				throw new CustomException("Flow Type Required", HttpStatus.BAD_REQUEST);
			}

			if (userDetail.getUserState() == null) {
				throw new CustomException("Userstate Required", HttpStatus.BAD_REQUEST);
			}

			validationUtil.checkUsernameValidation(userDetail.getUsername());
			otpService.generateAndSendOtp(userDetail);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(userDetail, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

}
