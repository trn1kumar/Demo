package com.gloqr.controller;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Collections;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.gloqr.constants.RegistrationProviders;
import com.gloqr.constants.UrlMapping;
import com.gloqr.constants.UserConstants.BooleanFlag;
import com.gloqr.entities.User;
import com.gloqr.exception.CustomException;
import com.gloqr.http.response.module.CustomHttpResponse;
import com.gloqr.http.response.module.ResponseMaker;
import com.gloqr.http.response.module.ResponseMessages;
import com.gloqr.model.AuthToken;
import com.gloqr.model.FacebookOAuthToken;
import com.gloqr.model.GoogleOAuthToken;
import com.gloqr.model.SocialUser;
import com.gloqr.security.configuration.JwtTokenUtil;
import com.gloqr.service.OtpService;
import com.gloqr.service.SocialLoginService;
import com.gloqr.service.UserService;
import com.gloqr.util.ValidationUtil;
import com.gloqr.vo.LoginUser;
import com.gloqr.vo.OtpData;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken.Payload;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = UrlMapping.ROOT_API)
public class LoginController {
	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private OtpService otpService;

	@Autowired
	private UserService userService;

	@Autowired
	private SocialLoginService socialLoginService;

	@Autowired
	private ValidationUtil validationUtil;

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	private static final Logger log = LogManager.getLogger();

	@PostMapping(UrlMapping.LOGIN)
	public ResponseEntity<CustomHttpResponse<AuthToken>> login(@RequestBody LoginUser loginUser) {

		User user = null;
		try {
			validationUtil.checkUsernameValidation(loginUser.getUsername());

			final Authentication authentication = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(loginUser.getUsername(), loginUser.getPassword()));

			if (StringUtils.isNumeric(loginUser.getUsername()))
				user = userService.getVerifiedUserByMobileNumber(loginUser.getUsername());
			else
				user = userService.getVerifiedUserByEmailId(loginUser.getUsername());

			final String token = jwtTokenUtil.generateToken(authentication, user);

			SecurityContextHolder.getContext().setAuthentication(authentication);

			log.info("authenticated user login " + authentication.getName() + ", setting security context");

			return responseMaker.successResponse(new AuthToken(token), ResponseMessages.SUCCESS, HttpStatus.OK);
		} catch (CustomException e) {
			throw e;
		} catch (BadCredentialsException e) {
			throw new CustomException(e.getMessage(), HttpStatus.UNAUTHORIZED);
		}

	}

	@PostMapping(UrlMapping.OTP_LOGIN)
	public ResponseEntity<CustomHttpResponse<AuthToken>> optLogin(@Valid @RequestBody OtpData otpData) {

		User user = null;
		try {
			final String username = otpData.getUsername();

			otpService.verifyOTP(otpData.getUuid(), otpData.getOtp());
			if (StringUtils.isNumeric(username))
				user = userService.getVerifiedUserByMobileNumber(username);
			else
				user = userService.getVerifiedUserByEmailId(username);

			final String token = jwtTokenUtil.authenticateUser(user,username);

			return responseMaker.successResponse(new AuthToken(token), ResponseMessages.SUCCESS, HttpStatus.OK);
		} catch (Exception e) {
			throw e;
		}

	}

	@PostMapping(UrlMapping.GOOGLE_LOGIN)
	public ResponseEntity<CustomHttpResponse<AuthToken>> googleLogin(@Valid @RequestBody GoogleOAuthToken oAuthToken)
			throws GeneralSecurityException, IOException {
		log.info("request for google social login.");
		SocialUser googleUser;

		HttpTransport httpTransport = GoogleNetHttpTransport.newTrustedTransport();
		JsonFactory jsonFactory = JacksonFactory.getDefaultInstance();

		GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(httpTransport, jsonFactory)
				// Specify the CLIENT_ID of the app that accesses the backend:
				.setAudience(Collections.singletonList(oAuthToken.getClientId()))
				// Or, if multiple clients access the backend:
				// .setAudience(Arrays.asList(CLIENT_ID_1, CLIENT_ID_2, CLIENT_ID_3))
				.build();

		// (Receive idTokenString by HTTPS POST)

		GoogleIdToken idToken = null;
		try {

			log.info("Verifying token from google and getting googleIdToken");
			idToken = verifier.verify(oAuthToken.getAuthToken());
			log.info("Verifed.. and Got GoogleIdToken Successfully");
		} catch (GeneralSecurityException e) {
			log.warn("Verification Canceled by some General Security", e);
		} catch (IOException e) {
			log.warn("Verification Canceled by IO Exception ", e);
		}
		if (idToken != null) {
			Payload payload = idToken.getPayload();

			// Get profile information from payload
			googleUser = new SocialUser();
			googleUser.setEmail(payload.getEmail());
			googleUser.setEmailVerified(payload.getEmailVerified());
			googleUser.setName((String) payload.get("name"));
			googleUser.setImage((String) payload.get("picture"));
			googleUser.setRegistrationProviders(RegistrationProviders.GOOGLE);

			User user = socialLoginService.getLogin(googleUser);
			final String token = jwtTokenUtil.authenticateUser(user,user.getUserEmail());
			return responseMaker.successResponse(new AuthToken(token), ResponseMessages.SUCCESS, HttpStatus.OK);

		} else {
			throw new CustomException("Invalid Token Id", HttpStatus.UNAUTHORIZED);
		}

	}

	@PostMapping(value = UrlMapping.FACEBOOK_LOGIN)
	public ResponseEntity<CustomHttpResponse<AuthToken>> facebookLogin(@Valid @RequestBody SocialUser facebookUser) {

		log.info("request for facebook social login with facebookUserId:{}  and email:{}", facebookUser.getId(),
				facebookUser.getEmail());

		FacebookOAuthToken response = null;
		FacebookOAuthToken result = null;
		final String userToken = facebookUser.getToken();
		final RestTemplate restTemplate = new RestTemplate();
		try {
			log.info("Getting Access Token From Facebook.....");
			final String getAccessTokenUrl = FacebookOAuthToken.ACCESS_TOKEN_URL
					.replace(FacebookOAuthToken.CLIENT_ID, facebookUser.getFacebookClientId())
					.replace(FacebookOAuthToken.CLIENT_SECRET, facebookUser.getFacebookClientSecret());
			response = restTemplate.getForObject(getAccessTokenUrl, FacebookOAuthToken.class);
			log.info("Got Access Token Successfully");
		} catch (Exception e) {
			throw new CustomException(
					"An Error Occured for Getting Access Token From Facebook,Check Client Id or Client Secret are Valid",
					HttpStatus.BAD_REQUEST, e);
		}
		try {
			log.info("Getting User Data From Facebook for User Token ");
			final String tokenVerificationUrl = FacebookOAuthToken.TOKEN_VERIFICATION_URL
					.replace(FacebookOAuthToken.USER_TOKEN, userToken)
					.replace(FacebookOAuthToken.ACCESSTOKEN, response.getAccess_token());
			result = restTemplate.getForObject(tokenVerificationUrl, FacebookOAuthToken.class);

			log.info("Verifying User...");

			if (facebookUser.getId().equals(result.getData().getUser_id())) {
				log.info("User Verified.");
				facebookUser.setEmailVerified(BooleanFlag.TRUE);
				facebookUser.setRegistrationProviders(RegistrationProviders.FACEBOOK);
				User user = socialLoginService.getLogin(facebookUser);
				final String token = jwtTokenUtil.authenticateUser(user,user.getUserEmail());
				return responseMaker.successResponse(new AuthToken(token), ResponseMessages.SUCCESS, HttpStatus.OK);
			} else {
				throw new CustomException("User Not Verified From Facebook.", HttpStatus.BAD_REQUEST);
			}

		} catch (CustomException e) {
			throw e;
		} catch (Exception e) {
			throw new CustomException("Error for Getting User Data From Facebook,Check User Token are Valid.",
					HttpStatus.BAD_REQUEST, e);
		}

	}

}
