package com.gloqr.controller;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.UrlMapping;
import com.gloqr.entities.User;
import com.gloqr.exception.CustomException;
import com.gloqr.http.response.module.CustomHttpResponse;
import com.gloqr.http.response.module.ResponseMaker;
import com.gloqr.http.response.module.ResponseMessages;
import com.gloqr.model.AuthToken;
import com.gloqr.security.configuration.JwtTokenUtil;
import com.gloqr.service.RegistrationService;
import com.gloqr.vo.OtpData;
import com.gloqr.vo.RegisterUser;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = UrlMapping.ROOT_API)
public class RegistrationController {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private RegistrationService registrationService;

	@Autowired
	private ResponseMaker responseMaker;

	@PostMapping(value = UrlMapping.SIGNUP)
	public ResponseEntity<CustomHttpResponse<RegisterUser>> signup(@Valid @RequestBody RegisterUser registerUser) {
		log.info("Request for signup from {}", registerUser);
		try {

			registrationService.saveUser(registerUser);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(registerUser, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@PostMapping(value = UrlMapping.VERIFY_USER)
	public ResponseEntity<CustomHttpResponse<AuthToken>> verifyUser(@Valid @RequestBody OtpData otpData) {

		try {
			if (otpData.getUuid() == null) {
				throw new CustomException("User Id can not be null", HttpStatus.BAD_REQUEST);
			}
			log.info("Verifying username:{} and Id:{}", otpData.getUsername(), otpData.getUuid());
			final User user = registrationService.activeAndVerifyUser(otpData);
			log.info("User Verified Successfully");
			final String token = jwtTokenUtil.authenticateUser(user,otpData.getUsername());
			return responseMaker.successResponse(new AuthToken(token), ResponseMessages.VERIFIED, HttpStatus.OK);
		} catch (Exception e) {
			throw e;
		}

	}

}
