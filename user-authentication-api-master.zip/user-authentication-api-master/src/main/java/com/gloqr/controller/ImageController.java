package com.gloqr.controller;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.component.validation.MultipartFileValidation;
import com.gloqr.constants.Roles;
import com.gloqr.constants.UrlMapping;
import com.gloqr.constants.UserConstants;
import com.gloqr.entities.User;
import com.gloqr.http.response.module.CustomHttpResponse;
import com.gloqr.http.response.module.ResponseMaker;
import com.gloqr.http.response.module.ResponseMessages;
import com.gloqr.model.AuthToken;
import com.gloqr.security.configuration.JwtTokenUtil;
import com.gloqr.security.context.holder.AuthUser;
import com.gloqr.service.ImageService;
import com.gloqr.service.UserService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = UrlMapping.ROOT_API)
public class ImageController {

	@Autowired
	private UserService smeUserService;

	@Autowired
	private ImageService imageService;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	MultipartFileValidation multipartFileValidation;

	@Autowired
	ResponseMaker responseMaker;

	Logger logger = LogManager.getLogger();

	@PreAuthorize(Roles.ALL_ROLES)
	@PostMapping(UrlMapping.UPLOAD_PROFILE_IMAGE)
	public ResponseEntity<CustomHttpResponse<AuthToken>> uploadProfileImg(Authentication authentication,
			@RequestParam(value = "profileImage", required = false) MultipartFile profileImage) throws IOException {

		final AuthUser userDetails = (AuthUser) authentication.getPrincipal();
		final String uuid = userDetails.getUuid();
		final String username = userDetails.getUsername();
		User user = null;
		String newProfileImage = null;

		multipartFileValidation.checkValidation(profileImage);

		try {
			user = smeUserService.getUserByUuid(uuid);

			newProfileImage = imageService.sendFilesToContentServer(uuid, profileImage,
					UserConstants.ProfileImageDirectory.PROFILE);

			String existProfileImage = user.getUserDetail().getProfileImage();

			if (!StringUtils.isEmpty(existProfileImage)) {
				imageService.deleteFileFromContentServer(existProfileImage);
			}
			user.getUserDetail().setProfileImage(newProfileImage);
			smeUserService.saveUser(user);
			final String refreshJwtToken = jwtTokenUtil.authenticateUser(user, username);
			return responseMaker.successResponse(new AuthToken(refreshJwtToken), ResponseMessages.UPLOADED_PROFILE_IMG,
					HttpStatus.OK);
		} catch (Exception e) {
			throw e;
		}

	}

	@PreAuthorize(Roles.ALL_ROLES)
	@DeleteMapping(UrlMapping.REMOVE_PROFILE_IMAGE)
	public ResponseEntity<CustomHttpResponse<AuthToken>> removeProfileImage(Authentication authentication)
			throws IOException {
		final AuthUser userDetails = (AuthUser) authentication.getPrincipal();
		final String username = userDetails.getUsername();
		final String uuid = userDetails.getUuid();
		AuthToken authToken = null;
		try {

			User user = smeUserService.getUserByUuid(uuid);
			String existProfileImage = user.getUserDetail().getProfileImage();
			if (!StringUtils.isEmpty(existProfileImage)) {
				imageService.deleteFileFromContentServer(existProfileImage);
				user.getUserDetail().setProfileImage(null);
				smeUserService.saveUser(user);
				final String refreshJwtToken = jwtTokenUtil.authenticateUser(user, username);
				authToken = new AuthToken(refreshJwtToken);
			}

		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(authToken, ResponseMessages.REMOVED_PROFILE_IMG, HttpStatus.OK);

	}
}
