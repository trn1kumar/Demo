package com.gloqr.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.UrlMapping;
import com.gloqr.http.response.module.CustomHttpResponse;
import com.gloqr.http.response.module.ResponseMaker;
import com.gloqr.http.response.module.ResponseMessages;
import com.gloqr.service.PasswordService;
import com.gloqr.vo.ResetPassword;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = UrlMapping.ROOT_API)
@SuppressWarnings("rawtypes")
public class PasswordController {

	@Autowired
	private PasswordService passwordService;

	@Autowired
	private ResponseMaker responseMaker;

	@PostMapping(UrlMapping.RESET_PASSWORD)
	public ResponseEntity<CustomHttpResponse> resetPassword(@Valid @RequestBody ResetPassword resetPassword,
			@RequestParam int otp) {
		try {
			passwordService.changePassword(resetPassword, otp);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.PASSWORD_UPDATED, HttpStatus.OK);
	}
}
