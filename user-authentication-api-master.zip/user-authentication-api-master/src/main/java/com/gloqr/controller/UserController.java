package com.gloqr.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.Roles;
import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.AddressDto;
import com.gloqr.dto.UserDto;
import com.gloqr.entities.Address;
import com.gloqr.entities.User;
import com.gloqr.http.response.module.CustomHttpResponse;
import com.gloqr.http.response.module.ResponseMaker;
import com.gloqr.http.response.module.ResponseMessages;
import com.gloqr.mapper.UserMapper;
import com.gloqr.model.AuthToken;
import com.gloqr.security.configuration.JwtTokenUtil;
import com.gloqr.security.context.holder.AuthUser;
import com.gloqr.service.OtpService;
import com.gloqr.service.UserService;
import com.gloqr.util.ValidationUtil;
import com.gloqr.vo.UserTypeUpdate;
import com.gloqr.vo.UserUpdate;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = UrlMapping.ROOT_API)
@SuppressWarnings("rawtypes")
public class UserController {

	@Autowired
	private UserService userService;

	@Autowired
	private OtpService otpService;

	@Autowired
	private UserMapper userMapper;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private ValidationUtil validationUtil;

	@Autowired
	private ResponseMaker responseMaker;

	private static final Logger log = LogManager.getLogger();

	@PreAuthorize(Roles.ALL_ROLES)
	@GetMapping(UrlMapping.GET_ACCOUNT_INFO)
	public ResponseEntity<CustomHttpResponse<UserDto>> getAccountInfo(Authentication authentication) {

		UserDto userDto = null;

		final AuthUser userDetails = (AuthUser) authentication.getPrincipal();
		try {
			userDto = userMapper.convertToDto(userService.getUserByUuid(userDetails.getUuid()), UserDto.class);

		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(userDto, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.GET_USER_INFO)
	public ResponseEntity<CustomHttpResponse<UserDto>> getUserInfo(@PathVariable(value = "uuid") String uuid) {

		UserDto userDto = null;
		try {
			User user = userService.getUserByUuid(uuid);
			userDto = userMapper.convertToDto(user, UserDto.class);
			userDto.getUserDetail().setRegistrationProvider(null);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(userDto, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.GET_USERS_INFO)
	public ResponseEntity<CustomHttpResponse<Map<String, UserDto>>> getUsersInfo(@RequestParam Set<String> userUuids) {

		Map<String, UserDto> usersMap = new HashMap<>();
		try {
			List<User> users = userService.getUsersInfo(userUuids);
			users.forEach(user -> {
				user.setUserDetail(null);
				usersMap.put(user.getUuid(), userMapper.convertToDto(user, UserDto.class));
			});

		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(usersMap, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@PreAuthorize(Roles.ALL_ROLES)
	@PostMapping(UrlMapping.SAVE_ADDRESS)
	public ResponseEntity<CustomHttpResponse> saveUserAddress(Authentication authentication,
			@RequestBody AddressDto addressDto) {

		final AuthUser userDetails = (AuthUser) authentication.getPrincipal();

		try {
			Address address = userMapper.convertToEntity(addressDto, Address.class);
			userService.saveUserAddress(address, userDetails.getUuid());
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.CREATED);
	}

	@PreAuthorize(Roles.ALL_ROLES)
	@PutMapping(UrlMapping.UPDATE_FULLNAME)
	public ResponseEntity<CustomHttpResponse<AuthToken>> updateUserFullName(Authentication authentication,
			@RequestBody UserUpdate userUpdate) {
		final AuthUser userDetails = (AuthUser) authentication.getPrincipal();
		final String username = userDetails.getUsername();
		try {
			userUpdate.setUuid(userDetails.getUuid());
			User user = userService.updateUserFullName(userUpdate);
			final String refreshJwtToken = jwtTokenUtil.authenticateUser(user, username);
			return responseMaker.successResponse(new AuthToken(refreshJwtToken), ResponseMessages.ACCOUNT_UPDATED,
					HttpStatus.OK);
		} catch (Exception e) {
			throw e;
		}

	}

	@PreAuthorize(Roles.ALL_ROLES)
	@PostMapping(value = UrlMapping.CHECK_USERNAME)
	public ResponseEntity<CustomHttpResponse> checkEmailOrMobileExist(Authentication authentication,
			@Valid @RequestBody UserUpdate userUpdate) {
		final AuthUser userDetails = (AuthUser) authentication.getPrincipal();
		final String newUsername = userUpdate.getNewUsername();
		validationUtil.checkUsernameValidation(newUsername);
		try {
			userUpdate.setUuid(userDetails.getUuid());
			userService.checkEmailOrMobileExist(userUpdate);
		} catch (Exception e) {
			throw e;
		}
		String resMsg = ResponseMessages.USERNAME_CHECKED_AND_OTP_GENERATED.replace("{username}", newUsername);
		return responseMaker.successResponse(resMsg, HttpStatus.OK);
	}

	@PreAuthorize(Roles.ALL_ROLES)
	@PutMapping(UrlMapping.UPDATE_USERNAME)
	public ResponseEntity<CustomHttpResponse<AuthToken>> updateUsername(Authentication authentication,
			@Valid @RequestBody UserUpdate userUpdate, @RequestParam int otp) {

		final AuthUser userDetails = (AuthUser) authentication.getPrincipal();
		final String uuid = userDetails.getUuid();

		try {
			final String newUsername = userUpdate.getNewUsername();
			validationUtil.checkUsernameValidation(newUsername);
			otpService.verifyOTP(uuid, otp);
			userUpdate.setUuid(uuid);
			final User user = userService.updateUsername(userUpdate);
			final String token = jwtTokenUtil.authenticateUser(user, newUsername);
			return responseMaker.successResponse(new AuthToken(token), ResponseMessages.ACCOUNT_UPDATED, HttpStatus.OK);
		} catch (Exception e) {
			throw e;
		}
	}

	@PreAuthorize(Roles.ALL_ROLES)
	@PutMapping(UrlMapping.UPDATE_USERTYPE)
	public ResponseEntity<CustomHttpResponse<AuthToken>> updateUserType(Authentication authentication,
			@Valid @RequestBody UserTypeUpdate typeUpdate) {

		final AuthUser userDetails = (AuthUser) authentication.getPrincipal();
		final String username = userDetails.getUsername();
		final String uuid = userDetails.getUuid();
		try {
			typeUpdate.setUuid(uuid);
			final User user = userService.changeUserType(typeUpdate);
			final String refreshJwtToken = jwtTokenUtil.authenticateUser(user, username);
			return responseMaker.successResponse(new AuthToken(refreshJwtToken), ResponseMessages.SUCCESS,
					HttpStatus.OK);
		} catch (Exception e) {
			throw e;
		}
	}

	@PreAuthorize(Roles.ALL_ROLES)
	@GetMapping(UrlMapping.VALIDATE_TOKEN)
	public ResponseEntity<CustomHttpResponse> validate() {
		log.info("UserController  :: Validated Request");
		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.OK);
	}

}
