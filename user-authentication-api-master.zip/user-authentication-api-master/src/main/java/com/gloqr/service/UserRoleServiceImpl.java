package com.gloqr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.entities.UserRole;
import com.gloqr.exception.CustomException;
import com.gloqr.repository.RoleRepository;

@Service
public class UserRoleServiceImpl implements UserRoleService {

	@Autowired
	RoleRepository roleRepository;

	public UserRole getRole(String role) {
		UserRole role1 = roleRepository.findByRole(role);
		if (role1 == null) {
			throw new CustomException("Invalid role selection:  " + role, HttpStatus.NOT_FOUND);
		}
		return role1;
	}
}
