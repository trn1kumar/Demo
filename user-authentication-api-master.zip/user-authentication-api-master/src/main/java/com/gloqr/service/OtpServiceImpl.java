package com.gloqr.service;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.constants.UserState;
import com.gloqr.entities.User;
import com.gloqr.exception.CustomException;
import com.gloqr.util.OtpUtil;
import com.gloqr.vo.OtpData;

@Service
public class OtpServiceImpl implements OtpService {

	@Autowired
	private UserService userService;

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private OtpUtil otpUtil;

	@Override
	public void verifyOTP(String uuid, int otp) {
		List<Integer> otpList = otpUtil.getOtp(uuid);

		if (otpList != null && otpList.contains(otp)) {
			otpUtil.clearOTP(uuid);
		} else {
			throw new CustomException("Invalid OTP.Please enter correct OTP", 600, HttpStatus.BAD_REQUEST);
		}

	}

	@Override
	public OtpData generateAndSendOtp(OtpData otpData) {
		User user = null;
		final String username = otpData.getUsername();

		if (StringUtils.isNumeric(username)) {
			user = sendOtpOnMobileNumber(otpData);
			otpData.setUuid(user.getUuid());
		} else {
			user = sendOtpOnEmailId(otpData);
			otpData.setUuid(user.getUuid());

		}
		return otpData;

	}

	private User sendOtpOnMobileNumber(OtpData otpData) {
		User user = null;
		String mobileNum = otpData.getUsername();
		UserState userState = otpData.getUserState();
		switch (userState) {

		case VERIFIED:
			user = userService.getVerifiedUserByMobileNumber(mobileNum);
			break;

		case UN_VERIFIED:
			user = userService.getUserByMobileNumber(mobileNum);
			if (user == null) {
				throw new CustomException(mobileNum + " Not Found.", HttpStatus.NOT_FOUND);
			}
			break;
		default:
			throw new CustomException(userState + "is invalid user state selection for send otp.",
					HttpStatus.BAD_REQUEST);
		}

		final int otp = otpUtil.generateOTP(user.getUuid());
		notificationService.sendVerificationCodeOnMobile(user.getUserFullName(), mobileNum, otp);
		return user;
	}

	private User sendOtpOnEmailId(OtpData otpData) {
		User user = null;
		String emailId = otpData.getUsername();
		UserState userState = otpData.getUserState();

		switch (userState) {

		case VERIFIED:
			user = userService.getVerifiedUserByEmailId(emailId);
			break;

		case UN_VERIFIED:
			user = userService.getUserByEmailId(emailId);
			if (user == null) {
				throw new CustomException(emailId + " Not Found.", HttpStatus.NOT_FOUND);
			}
			break;
		default:
			throw new CustomException(userState + " is invalid user state selection for send otp.",
					HttpStatus.BAD_REQUEST);
		}

		final int otp = otpUtil.generateOTP(user.getUuid());
		notificationService.sendVerificationCodeOnEmail(user.getUserFullName(), emailId, otp,
				otpData.getFlowType().getOtpFlowSubTitleMsg());
		return user;
	}

}
