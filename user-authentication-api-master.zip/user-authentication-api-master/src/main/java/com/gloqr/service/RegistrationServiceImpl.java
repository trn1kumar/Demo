package com.gloqr.service;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.gloqr.constants.NotificationFlow;
import com.gloqr.constants.RegistrationProviders;
import com.gloqr.constants.Roles;
import com.gloqr.constants.UserConstants.BooleanFlag;
import com.gloqr.constants.UserType;
import com.gloqr.dao.UserDao;
import com.gloqr.entities.User;
import com.gloqr.entities.UserDetail;
import com.gloqr.entities.UserRole;
import com.gloqr.exception.CustomException;
import com.gloqr.util.OtpUtil;
import com.gloqr.util.UuidUtil;
import com.gloqr.util.ValidationUtil;
import com.gloqr.vo.OtpData;
import com.gloqr.vo.RegisterUser;

@Service
public class RegistrationServiceImpl implements RegistrationService {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private UserDao userDao;

	@Autowired
	private UserService userService;

	@Autowired
	private UserRoleService userRoleService;

	@Autowired
	private ValidationUtil validationUtil;

	@Autowired
	private OtpUtil otpUtil;

	@Autowired
	private OtpService otpService;

	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	@Autowired
	private NotificationService notificationService;

	@Override
	public void saveUser(RegisterUser registerUser) {

		User user = null;
		final String username = registerUser.getUsername();
		validationUtil.checkUsernameValidation(username);

		/*
		 * check user already present or not if verified user found throw an exception
		 * otherwise remove it from database and register new coming user.
		 */
		this.checkUserAlreadyPresentOrNot(registerUser);

		user = new User();
		user.setUserFullName(registerUser.getUserFullName());
		user.setPassword(registerUser.getUserPassword());
		if (StringUtils.isNumeric(username)) {
			user.setUserMobile(username);
		} else {
			user.setUserEmail(username);
		}

		this.setDetails(user, RegistrationProviders.GLOQR);
		userService.saveUser(user);
		registerUser.setUuid(user.getUuid());
		final int otp = otpUtil.generateOTP(user.getUuid());

		if (user.getUserEmail() != null)
			notificationService.sendVerificationCodeOnEmail(user.getUserFullName(), user.getUserEmail(), otp,
					NotificationFlow.SIGN_UP_VERIFICATION.getOtpFlowSubTitleMsg());
		else if (user.getUserMobile() != null)
			notificationService.sendVerificationCodeOnMobile(user.getUserFullName(), user.getUserMobile(), otp);

	}

	@Override
	public User activeAndVerifyUser(OtpData otpData) {
		User user = null;
		final String username = otpData.getUsername();

		otpService.verifyOTP(otpData.getUuid(), otpData.getOtp());

		if (StringUtils.isNumeric(username)) {
			user = userDao.findByUserMobile(username);
			user.getUserDetail().setMobileVerified(BooleanFlag.TRUE);
		} else {
			user = userDao.findByUserEmail(username);
			user.getUserDetail().setEmailVerified(BooleanFlag.TRUE);
		}
		user.getUserDetail().setUserVerified(BooleanFlag.TRUE);
		user.getUserDetail().setActive(BooleanFlag.TRUE);
		user.getUserDetail().setActiveFrom(new Date(System.currentTimeMillis()));

		return userService.saveUser(user);
	}

	private void checkUserAlreadyPresentOrNot(RegisterUser registerUser) {
		log.info("Checking user already present for {}", registerUser);
		final String username = registerUser.getUsername();
		User user = null;

		if (StringUtils.isNumeric(username)) {
			user = userDao.findByUserMobile(username);
		} else {
			user = userDao.findByUserEmail(username);
		}

		if (user != null) {
			if (user.getUserDetail().isUserVerified()) {
				log.warn("Verified User Found");
				// throw user already exist exception
				throw new CustomException(username + " Already Exist", HttpStatus.BAD_REQUEST);
			} else {
				// delete user from database
				log.warn("Un-Verified User Found. Deleting it from Database and Registering given User {}", username);
				userDao.deleteUnVerifiedUser(user);
			}

		} else {
			log.warn("User Not Found");
		}

	}

	@Override
	public void setDetails(User user, RegistrationProviders registrationProvider) {
		Set<UserRole> roles = null;
		UserDetail userDetail = null;

		user.setUuid(UuidUtil.getUuid(user.getUserFullName()));
		user.setUserType(UserType.NORMAL);
		userDetail = new UserDetail();
		userDetail.setUserDetailsUuid(UuidUtil.getUuid().substring(0, 8));
		userDetail.setRegistrationProvider(registrationProvider);
		roles = new HashSet<>();
		roles.add(userRoleService.getRole(Roles.USER_ROLE));
		user.setRoles(roles);
		user.setUserDetail(userDetail);
		if (user.getPassword() != null) {
			user.setPassword(bcryptEncoder.encode(user.getPassword()));
		} else {
			user.setPassword(bcryptEncoder.encode(UuidUtil.getUuid().substring(0, 8)));
		}
	}

}
