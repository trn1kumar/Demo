package com.gloqr.service;

import com.gloqr.entities.UserRole;

public interface UserRoleService {

	public UserRole getRole(String role);

}
