package com.gloqr.service;

import com.gloqr.vo.ResetPassword;

public interface PasswordService {

	public void changePassword(ResetPassword resetPassword, int otp);

}
