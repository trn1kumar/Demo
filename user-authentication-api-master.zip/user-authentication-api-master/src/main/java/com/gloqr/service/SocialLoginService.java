package com.gloqr.service;

import com.gloqr.entities.User;
import com.gloqr.model.SocialUser;

public interface SocialLoginService {

	public User getLogin(SocialUser socialUser);

}
