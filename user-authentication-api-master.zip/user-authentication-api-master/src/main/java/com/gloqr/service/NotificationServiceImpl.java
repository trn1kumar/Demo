package com.gloqr.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.gloqr.configuration.PropertyValues;
import com.gloqr.exception.CustomException;
import com.gloqr.model.EmailEvent;
import com.gloqr.model.SmsEvent;
import com.gloqr.rest.endpoint.NotificationPoint;

@Service
@Async("taskExecutor")
public class NotificationServiceImpl implements NotificationService {

	@Autowired
	private PropertyValues propertyValues;

	@Autowired
	private TemplateEngine templateEngine;

	@Autowired
	private NotificationPoint notificationPoint;

	private void sendNotifications(List<Object> events) {
		events.parallelStream().forEach(e -> notificationPoint.sendNotification(e));
	}

	public void sendOtp(String mobileNum, String email, int otp) {

		final List<Object> events = new ArrayList<>();
		if (mobileNum != null) {
			final String smsMsg = propertyValues.getSmsMsg().replace("{otp}", String.valueOf(otp));
			SmsEvent smsEvent = new SmsEvent(mobileNum, smsMsg);
			events.add(smsEvent);
		}

		if (email != null) {
			final String contentServerUrl = propertyValues.getContentServerUrl();
			final String divBackGroundImgUrl = contentServerUrl.replace("{imgLocation}", "");
			Context context = new Context();
			context.setVariable("homeUrl", propertyValues.getBaseUrl());
			context.setVariable("contentServerUrl", contentServerUrl);
			context.setVariable("divBackGroundImgUrl", divBackGroundImgUrl);
			context.setVariable("otp", otp);
			context.setVariable("otpValidaty", propertyValues.getOtpValidity());
			String eventMsg = templateEngine.process("otp-email.html", context);
			String mailSub = "Otp Verification for your gloqr Account";
			EmailEvent emailEvent = new EmailEvent(email, mailSub, eventMsg);
			events.add(emailEvent);
		}
		sendNotifications(events);
	}

	public void sendOtp(String username, String mobileNum, String email, char[] otpArray, String otpFlowMsg) {

		final List<Object> events = new ArrayList<>();
		if (mobileNum != null) {
			final String smsMsg = propertyValues.getSmsMsg().replace("{otp}", String.valueOf(otpArray));
			SmsEvent smsEvent = new SmsEvent(mobileNum, smsMsg);
			events.add(smsEvent);
		}

		if (email != null) {
			final String contentServerUrl = propertyValues.getContentServerUrl();
			Context context = new Context();
			context.setVariable("homeUrl", propertyValues.getBaseUrl());
			context.setVariable("contentServerUrl", contentServerUrl);

			context.setVariable("name", "Rahul Jadhav");
			context.setVariable("otpArray", otpArray);
			context.setVariable("otpFlowMsg", otpFlowMsg);
			context.setVariable("otpValidaty", propertyValues.getOtpValidity());
			String eventMsg = templateEngine.process("OtpVerify", context);

			String mailSub = "Otp Verification for your gloqr Account";
			EmailEvent emailEvent = new EmailEvent(email, mailSub, eventMsg);
			events.add(emailEvent);
		}
		sendNotifications(events);
	}

	public void sendVerificationCodeOnEmail(String userFullName, String email, int otp, String otpFlowSubTitleMsg) {
		if (email != null) {
			final String contentServerUrl = propertyValues.getContentServerUrl();
			final char[] otpCharArray = String.valueOf(otp).toCharArray();
			Context context = new Context();
			context.setVariable("homeUrl", propertyValues.getBaseUrl());
			context.setVariable("contentServerUrl", contentServerUrl);

			context.setVariable("name", userFullName);
			context.setVariable("otpArray", otpCharArray);
			context.setVariable("otpFlowMsg", otpFlowSubTitleMsg);
			context.setVariable("otpValidaty", propertyValues.getOtpValidity());
			String eventMsg = templateEngine.process("OtpVerify", context);

			String mailSub = "Otp Verification for your gloqr Account";
			EmailEvent emailEvent = new EmailEvent(email, mailSub, eventMsg);
			notificationPoint.sendNotification(emailEvent);
		} else {
			throw new CustomException("email can't be empty", HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	public void sendVerificationCodeOnMobile(String userFullName, String mobileNum, int otp) {
		if (mobileNum != null) {
			final String smsMsg = propertyValues.getSmsMsg().replace("{otp}", String.valueOf(otp));
			SmsEvent smsEvent = new SmsEvent(mobileNum, smsMsg);
			notificationPoint.sendNotification(smsEvent);
		} else {
			throw new CustomException("mobile number can't be empty", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/*
	 * @Override public void sendVerificationCode(String userFullName, String
	 * mobileNum, String email, int otp, NotificationFlow flow) { switch (flow) {
	 * 
	 * case SIGN_UP_VERIFICATION: sendOtp(userFullName, mobileNum, email,
	 * String.valueOf(otp).toCharArray(),
	 * NotificationFlow.SIGN_UP_VERIFICATION.getOtpFlowSubTitleMsg()); break;
	 * 
	 * case OTP_LOGIN: sendOtp(userFullName, mobileNum, email,
	 * String.valueOf(otp).toCharArray(),
	 * NotificationFlow.OTP_LOGIN.getOtpFlowSubTitleMsg()); break;
	 * 
	 * case FORGOT_PASS: sendOtp(userFullName, mobileNum, email,
	 * String.valueOf(otp).toCharArray(),
	 * NotificationFlow.FORGOT_PASS.getOtpFlowSubTitleMsg()); break;
	 * 
	 * case CREDENTIALS_UPDATE: sendOtp(userFullName, mobileNum, email,
	 * String.valueOf(otp).toCharArray(),
	 * NotificationFlow.CREDENTIALS_UPDATE.getOtpFlowSubTitleMsg()); break;
	 * 
	 * default: log.warn("Invalid Notification flow: {} Selected.", flow); }
	 * 
	 * }
	 */

}
