package com.gloqr.service;

import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.constants.UserConstants.BooleanFlag;
import com.gloqr.dao.UserDao;
import com.gloqr.entities.User;
import com.gloqr.model.SocialUser;

@Service
public class SocialLoginServiceImpl implements SocialLoginService {

	@Autowired
	private UserDao userDao;

	@Autowired
	private UserService userService;

	@Autowired
	private RegistrationService registrationService;

	private Logger log = LogManager.getLogger();

	@Override
	public User getLogin(SocialUser socialUser) {

		log.info("request for social login by email:-{} and registration-provider:{}", socialUser.getEmail(),
				socialUser.getRegistrationProviders());

		User user = this.isNewUser(socialUser.getEmail());

		// if verified user found return exist user and provide login

		if (user != null) {
			log.info("user with email:-{} found,exsting user return for login.", socialUser.getEmail());
			return user;
		}

		// else create new account
		log.info("user with email:-{} not-found,registrating new user.", socialUser.getEmail());
		user = new User();
		user.setUserEmail(socialUser.getEmail());
		user.setUserFullName(socialUser.getName());
		registrationService.setDetails(user, socialUser.getRegistrationProviders());
		user.getUserDetail().setProfileImage(socialUser.getImage());
		user.getUserDetail().setEmailVerified(socialUser.isEmailVerified());
		user.getUserDetail().setUserVerified(BooleanFlag.TRUE);
		user.getUserDetail().setActive(BooleanFlag.TRUE);
		user.getUserDetail().setActiveFrom(new Date(System.currentTimeMillis()));
		userService.saveUser(user);
		return user;
	}

	private User isNewUser(String gmail) {

		final User user = userDao.findByUserEmail(gmail);

		if (user != null) {
			if (user.getUserDetail().isUserVerified()) {
				return user;
			} else {
				// delete user from database
				userDao.deleteUnVerifiedUser(user);
			}

		}
		return null;

	}

}
