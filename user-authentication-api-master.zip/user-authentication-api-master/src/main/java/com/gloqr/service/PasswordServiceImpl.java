package com.gloqr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.gloqr.exception.CustomException;
import com.gloqr.repository.UserRepository;
import com.gloqr.vo.ResetPassword;

@Service
public class PasswordServiceImpl implements PasswordService {

	@Autowired
	private UserRepository smeUserRepo;

	@Autowired
	private UserService smeUserService;

	@Autowired
	private OtpService otpService;

	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	@Override
	public void changePassword(ResetPassword resetPassword,int otp) {

		final String uuid = resetPassword.getUuid();
		final String newPassword = resetPassword.getNewPassword();

		otpService.verifyOTP(uuid, otp);
		if (!smeUserService.existsByUuid(uuid)) {
			throw new CustomException("User not found by id : " + uuid, HttpStatus.NOT_FOUND);
		}
		smeUserRepo.updatePassword(bcryptEncoder.encode(newPassword), uuid);
	}
}
