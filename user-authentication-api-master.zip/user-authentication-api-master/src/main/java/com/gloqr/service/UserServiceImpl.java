package com.gloqr.service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gloqr.constants.NotificationFlow;
import com.gloqr.constants.Roles;
import com.gloqr.constants.UserConstants.UserTypeUpdateExceptionCause;
import com.gloqr.constants.UserType;
import com.gloqr.dao.UserDao;
import com.gloqr.entities.Address;
import com.gloqr.entities.User;
import com.gloqr.entities.UserRole;
import com.gloqr.exception.CustomException;
import com.gloqr.security.context.holder.AuthUser;
import com.gloqr.util.OtpUtil;
import com.gloqr.util.UuidUtil;
import com.gloqr.vo.UserTypeUpdate;
import com.gloqr.vo.UserUpdate;

@Service(value = "smeUserService")
public class UserServiceImpl implements UserDetailsService, UserService {

	@Autowired
	private UserDao userDao;

	@Autowired
	private UserRoleService userRoleService;

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private OtpUtil otpUtil;

	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	private Logger log = LogManager.getLogger(UserServiceImpl.class);

	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public User saveUser(User user) {
		return userDao.saveUser(user);
	}

	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public void saveUserAddress(Address address, String uuid) {

		if (address.getAddrsUuid() != null) {
			this.updateUserAddress(address);

		} else {
			User user = userDao.getUserByUuid(uuid);
			address.setAddrsUuid(UuidUtil.getUuid());
			user.getUserDetail().getAddress().add(address);
			userDao.saveUser(user);
		}
	}

	@Override
	public void updateUserAddress(Address address) {
		Address existAddress = userDao.getAddress(address.getAddrsUuid());
		address.setAddressId(existAddress.getAddressId());
		userDao.saveAddress(existAddress);

	}

	@Override
	public User updateUserFullName(UserUpdate userUpdate) {

		String uuid = userUpdate.getUuid();
		String userFullName = userUpdate.getUserFullName();

		if (!StringUtils.isEmpty(userFullName)) {
			User user = userDao.getUserByUuid(uuid);
			user.setUserFullName(userFullName);
			userDao.saveUser(user);
			return user;
		} else {
			throw new CustomException("full name required", HttpStatus.BAD_REQUEST);
		}
	}

	@Override
	public User updateUsername(UserUpdate userUpdate) {
		final String username = userUpdate.getNewUsername();
		if (StringUtils.isNumeric(username)) {
			return updateMobileNumber(userUpdate);
		} else {
			return updateEmail(userUpdate);
		}
	}

	private User updateMobileNumber(UserUpdate userUpdate) {
		final String uuid = userUpdate.getUuid();
		final String newMobileNum = userUpdate.getNewUsername();

		final String userPassword = userUpdate.getPassword();
		if (userPassword == null) {
			throw new CustomException("User Password should not be null", HttpStatus.BAD_REQUEST);
		}

		final User user = userDao.getUserByUuid(uuid);
		boolean isPasswordMatches = bcryptEncoder.matches(userPassword, user.getPassword());

		if (isPasswordMatches) {
			if (this.checkAndDeleteExistUnverifiedUserByMobile(newMobileNum))
				throw new CustomException(newMobileNum + " already exist", 601, HttpStatus.BAD_REQUEST);

			user.setUserMobile(newMobileNum);
			return userDao.saveUser(user);
		} else {
			throw new CustomException("Invalid Password", 602, HttpStatus.BAD_REQUEST);
		}

	}

	private boolean checkAndDeleteExistUnverifiedUserByMobile(String mobileNum) {
		final User user = userDao.findByUserMobile(mobileNum);

		if (user != null && user.getUserDetail().isUserVerified()) {
			return true;
		} else if (user != null && !user.getUserDetail().isUserVerified()) {
			userDao.deleteUnVerifiedUser(user);
		}
		return false;
	}

	private User updateEmail(UserUpdate userUpdate) {
		final String uuid = userUpdate.getUuid();
		final String newEmail = userUpdate.getNewUsername();
		final String userPassword = userUpdate.getPassword();
		if (userPassword == null) {
			throw new CustomException("User Password should not be null", HttpStatus.BAD_REQUEST);
		}

		final User user = userDao.getUserByUuid(uuid);

		boolean isPasswordMatches = bcryptEncoder.matches(userPassword, user.getPassword());
		if (isPasswordMatches) {
			if (this.checkAndDeleteExistUnverifiedUserByEmail(newEmail))
				throw new CustomException(newEmail + " already exist", 601, HttpStatus.BAD_REQUEST);

			user.setUserEmail(newEmail);
			return userDao.saveUser(user);
		} else {
			throw new CustomException("Invalid Password", 602, HttpStatus.BAD_REQUEST);
		}

	}

	private boolean checkAndDeleteExistUnverifiedUserByEmail(String newEmail) {
		final User user = userDao.findByUserEmail(newEmail);

		if (user != null && user.getUserDetail().isUserVerified()) {
			return true;
		} else if (user != null && !user.getUserDetail().isUserVerified()) {
			userDao.deleteUnVerifiedUser(user);
		}
		return false;
	}

	@Override
	public User getUserByUuid(String uuid) {
		return userDao.getUserByUuid(uuid);
	}

	@Override
	public User changeUserType(UserTypeUpdate typeUpdate) {
		User user = null;
		user = userDao.getUserByUuid(typeUpdate.getUuid());
		UserType newUserType = typeUpdate.getNewUserType();
		if (newUserType == null) {
			throw new CustomException("New UserType is empty.can't update type.Updation failed",
					HttpStatus.BAD_REQUEST);
		}

		log.info(user + " Going to change user type from " + user.getUserType() + " to " + newUserType);

		switch (newUserType) {
		case SME:
			if (StringUtils.isBlank(typeUpdate.getsUuid())) {
				throw new CustomException("smeId is blank.can't update type.Updation failed", HttpStatus.BAD_REQUEST);
			}
			user.setsUuid(typeUpdate.getsUuid());
			this.changeTypeToSMEUser(user);
			break;
		case NORMAL:
			this.changeTypeToNormalUser(user);
			break;
		case GLOQR:
			this.changeTypeToSmefaceUser(user);
			break;
		}

		userDao.saveUser(user);
		log.info("User Type Changed Successfully into " + newUserType + " for " + user);
		return user;
	}

	private void changeTypeToSMEUser(User user) {
		if (user.getUserType().equals(UserType.SME)) {
			this.throwException(user, UserTypeUpdateExceptionCause.SAME_TYPE);
		}
		if (user.getUserType().equals(UserType.GLOQR)) {
			this.throwException(user, UserTypeUpdateExceptionCause.INVALID_SELECTION);
		}
		user.setUserType(UserType.SME);
		user.getRoles().add(userRoleService.getRole(Roles.SME_ADMIN));
	}

	private void changeTypeToNormalUser(User user) {
		if (user.getUserType().equals(UserType.NORMAL)) {
			this.throwException(user, UserTypeUpdateExceptionCause.SAME_TYPE);
		} else {
			user.setsUuid(null);
			user.setUserType(UserType.NORMAL);
			boolean bool = user.getRoles().removeIf(
					role -> role.getRole().equals(Roles.SME_ADMIN) || role.getRole().equals(Roles.SMEFACE_SUPER_ADMIN));
			if (bool) {
				log.info(Roles.SME_ADMIN + " roles Removed Successfully for " + user);
			}
		}
	}

	private void changeTypeToSmefaceUser(User user) {

		if (user.getUserType().equals(UserType.GLOQR)) {
			this.throwException(user, UserTypeUpdateExceptionCause.SAME_TYPE);
		}
		if (user.getUserType().equals(UserType.SME)) {
			this.throwException(user, UserTypeUpdateExceptionCause.INVALID_SELECTION);

		}
		user.setUserType(UserType.GLOQR);
		user.getRoles().add(userRoleService.getRole(Roles.SMEFACE_SUPER_ADMIN));

	}

	private void throwException(User user, String cause) {
		if (cause.equals(UserTypeUpdateExceptionCause.SAME_TYPE)) {
			throw new CustomException(
					user + " has already " + user.getUserType() + " type. can't update type.Updation failed",
					HttpStatus.BAD_REQUEST);
		} else if (cause.equals(UserTypeUpdateExceptionCause.INVALID_SELECTION)) {
			throw new CustomException(
					user + " has a " + user.getUserType() + " type. can't update type.Updation failed",
					HttpStatus.BAD_REQUEST);
		}

	}

	@Override
	public User getUserByMobileNumber(String mobileNum) {
		return userDao.findByUserMobile(mobileNum);
	}

	@Override
	public User getUserByEmailId(String mailId) {
		return userDao.findByUserEmail(mailId);
	}

	@Override
	public User getVerifiedUserByMobileNumber(String mobileNum) {
		User user = userDao.getVerifiedUserByMobileNumber(mobileNum);
		if (user != null) {
			return user;
		} else {
			throw new CustomException(mobileNum + " Not Exist.Please Register with us", HttpStatus.NOT_FOUND);
		}

	}

	@Override
	public User getVerifiedUserByEmailId(String mailId) {
		User user = userDao.getVerifiedUserByEmailId(mailId);
		if (user != null) {
			return user;
		} else {
			throw new CustomException(mailId + " Not Exist.Please Register with us", HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public boolean existsByUuid(String uuid) {
		return userDao.isUserExist(uuid);
	}

	@Override
	public AuthUser loadUserByUsername(String username) {

		log.info("getting Authentication for...  ::  " + username);

		User user = null;
		if (StringUtils.isNumeric(username))
			user = userDao.findByUserMobile(username);
		else
			user = userDao.findByUserEmail(username);

		if (user != null && user.getUserDetail().isUserVerified()) {
			log.info("Authenticated User Name  :: " + user.getUserFullName() + " and Active:: "
					+ user.getUserDetail().isUserVerified());
			return new AuthUser(user.getUuid(), user.getsUuid(), username, user.getPassword(),
					getAuthority(user.getRoles()));
		}

		log.info(username + " Not Authenticate");
		throw new UsernameNotFoundException("Bad credentials");

	}

	@Override
	public List<SimpleGrantedAuthority> getAuthority(Set<UserRole> roles) {

		return roles.stream().map(userRole -> new SimpleGrantedAuthority("ROLE_" + userRole.getRole()))
				.collect(Collectors.toList());
	}

	@Override
	public void checkEmailOrMobileExist(UserUpdate userInfo) {

		final String newUsername = userInfo.getNewUsername();

		if (StringUtils.isNumeric(newUsername))
			checkVerifiedUserFoundByMobile(userInfo.getUuid(), newUsername);
		else
			checkVerifiedUserFoundByEmail(userInfo.getUuid(), newUsername);

	}

	private void checkVerifiedUserFoundByEmail(String uuid, String email) {

		boolean isFound = userDao.isVerifiedUserFoundByEmail(email);
		if (isFound) {
			throw new CustomException(email + " Already Exist", HttpStatus.BAD_REQUEST);
		} else {
			User user = getUserByUuid(uuid);
			int otp = otpUtil.generateOTP(uuid);
			notificationService.sendVerificationCodeOnEmail(user.getUserFullName(), email, otp,
					NotificationFlow.CREDENTIALS_UPDATE.getOtpFlowSubTitleMsg());
		}

	}

	private void checkVerifiedUserFoundByMobile(String uuid, String mobile) {

		boolean isFound = userDao.isVerifiedUserFoundByMobile(mobile);
		if (isFound) {
			throw new CustomException(mobile + " Already Exist", HttpStatus.BAD_REQUEST);
		} else {
			User user = getUserByUuid(uuid);
			int otp = otpUtil.generateOTP(uuid);
			notificationService.sendVerificationCodeOnMobile(user.getUserFullName(), mobile, otp);
		}

	}

	@Override
	public List<User> getUsersInfo(Set<String> userUuids) {
		return userDao.getUsersInfo(userUuids);
	}

}
