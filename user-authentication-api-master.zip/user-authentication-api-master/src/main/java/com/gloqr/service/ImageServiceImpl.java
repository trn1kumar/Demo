package com.gloqr.service;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.exception.CustomException;
import com.gloqr.model.multipart.UploadFileResponse;
import com.gloqr.repository.UserRepository;
import com.gloqr.rest.endpoint.ContentServerEndpoint;
import com.gloqr.util.RandomNumber;

@Service
public class ImageServiceImpl implements ImageService {

	@Autowired
	ContentServerEndpoint contentServerEndpoint;

	@Autowired
	UserRepository smeUserRepo;

	Logger logger = LogManager.getLogger();

	@Override
	public String sendFilesToContentServer(String uuid, MultipartFile file, String fileLocation) throws IOException {

		String imageName = RandomNumber.generate(10000000) + file.getOriginalFilename();
		UploadFileResponse fileDetail = null;
		try {
			fileDetail = contentServerEndpoint.sendFilesToContentServer(file, imageName,
					fileLocation.replace("{uuid}", uuid));
		} catch (IllegalArgumentException e) {
			throw new CustomException("IllegalArgumentException when Upload file", HttpStatus.INTERNAL_SERVER_ERROR, e);
		} catch (IOException e) {
			throw new CustomException("IOException when Upload file", HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

		return fileDetail.getFileLocation();

	}

	@Override
	public void deleteFileFromContentServer(String fileLocation) throws IOException {
		try {
			contentServerEndpoint.deleteFileFromContentServer(fileLocation);
		} catch (CustomException e) {
			logger.error(e);
		}
	}
}
