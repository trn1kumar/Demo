package com.gloqr.service;

public interface NotificationService {

	// void sendVerificationCode(String userFullName, String mobileNum, String
	// email, int otp, NotificationFlow flow);

	public void sendVerificationCodeOnEmail(String userFullName, String email, int otp, String otpFlowSubTitleMsg);

	public void sendVerificationCodeOnMobile(String userFullName, String mobileNum, int otp);

}
