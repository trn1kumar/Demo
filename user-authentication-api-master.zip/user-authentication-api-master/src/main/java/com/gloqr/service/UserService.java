package com.gloqr.service;

import java.util.List;
import java.util.Set;

import org.springframework.security.core.authority.SimpleGrantedAuthority;

import com.gloqr.entities.Address;
import com.gloqr.entities.User;
import com.gloqr.entities.UserRole;
import com.gloqr.vo.UserTypeUpdate;
import com.gloqr.vo.UserUpdate;

public interface UserService {

	public User saveUser(User user);

	public void saveUserAddress(Address address, String uuid);

	public void updateUserAddress(Address address);

	public User updateUserFullName(UserUpdate userUpdateObj);

	public User changeUserType(UserTypeUpdate typeUpadate);

	public boolean existsByUuid(String uuid);

	public void checkEmailOrMobileExist(UserUpdate userInfo);

	public User getUserByUuid(String uuid);

	public User getUserByMobileNumber(String mobileNum);

	public User getUserByEmailId(String mailId);

	public User getVerifiedUserByMobileNumber(String mobileNum);

	public User getVerifiedUserByEmailId(String mailId);

	public User updateUsername(UserUpdate userUpdate);

	public List<SimpleGrantedAuthority> getAuthority(Set<UserRole> roles);

	public List<User> getUsersInfo(Set<String> userUuids);

}
