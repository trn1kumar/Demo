package com.gloqr.service;

import com.gloqr.constants.RegistrationProviders;
import com.gloqr.entities.User;
import com.gloqr.vo.OtpData;
import com.gloqr.vo.RegisterUser;

public interface RegistrationService {

	public void saveUser(RegisterUser registerUser);

	public User activeAndVerifyUser(OtpData otpData);

	public void setDetails(User user, RegistrationProviders registrationProviders);

}
