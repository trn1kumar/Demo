package com.gloqr.service;

import com.gloqr.vo.OtpData;

public interface OtpService {

	public void verifyOTP(String uuid, int otp);

	public OtpData generateAndSendOtp(OtpData userDetail);

}
