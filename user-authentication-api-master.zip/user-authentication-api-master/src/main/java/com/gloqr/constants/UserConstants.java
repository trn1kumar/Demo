package com.gloqr.constants;

public class UserConstants {

	private UserConstants() {
		throw new IllegalStateException("UserConstants class.can't initiate");
	}

	public class OtpConstants {
		public static final int EXPIRE_MINS = 5;
	}

	public class ProfileImageDirectory {
		public static final String PROFILE = "users/{uuid}/profiles";
	}

	public class BooleanFlag {
		public static final boolean FALSE = false;
		public static final boolean TRUE = true;
	}

	public class UserTypeUpdateExceptionCause {
		public static final String SAME_TYPE = "SAME_TYPE_UPDATE";
		public static final String INVALID_SELECTION = "INVALID_TYPE_CHOICE";
	}

}
