package com.gloqr.constants;

public enum NotificationFlow {

	SIGN_UP_VERIFICATION("complete the registration process."), OTP_LOGIN("login your account."),
	FORGOT_PASS("change the password for gloqr account."),
	CREDENTIALS_UPDATE("update email address for your gloqr account.");

	private String otpFlowSubTitleMsg;

	NotificationFlow(String otpFlowSubTitleMsg) {
		this.otpFlowSubTitleMsg = otpFlowSubTitleMsg;
	}

	public String getOtpFlowSubTitleMsg() {
		return otpFlowSubTitleMsg;
	}

}
