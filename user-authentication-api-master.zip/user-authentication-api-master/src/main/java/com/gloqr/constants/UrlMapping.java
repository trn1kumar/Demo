package com.gloqr.constants;

public class UrlMapping {

	private UrlMapping() {
		throw new IllegalStateException("UrlMapping class, can't Initiate");
	}

	// root api
	public static final String ROOT_API = "/api/users";

	// image controller
	public static final String UPLOAD_PROFILE_IMAGE = "/upload/profile/image";
	public static final String REMOVE_PROFILE_IMAGE = "/remove/profile/image";

	// LoginController
	public static final String LOGIN = "/login";
	public static final String OTP_LOGIN = "/login/otp";
	public static final String GOOGLE_LOGIN = "/login/google";
	public static final String FACEBOOK_LOGIN = "/login/facebook";

	// OtpController
	public static final String GENERATE_OTP = "/otp/generate";
	public static final String VERIFY_OTP = "/verify-otp";

	// PasswordController
	public static final String RESET_PASSWORD = "/password/reset";

	// RegistrationController
	public static final String SIGNUP = "/signup";
	public static final String VERIFY_USER = "/verify";
	

	// UserController
	public static final String GET_ACCOUNT_INFO = "/account";
	public static final String GET_USER_INFO = "/{uuid}/basic-info";
	public static final String GET_USERS_INFO = "/details";
	public static final String SAVE_ADDRESS = "/address";
	public static final String UPDATE_FULLNAME = "/fullname";
	public static final String UPDATE_USERNAME = "/username";
	public static final String UPDATE_USERTYPE = "/usertype";
	public static final String VALIDATE_TOKEN = "/validate";
	public static final String CHECK_USERNAME = "/check/username/otp/generate";

}
