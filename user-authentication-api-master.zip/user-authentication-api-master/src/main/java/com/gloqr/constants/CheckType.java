package com.gloqr.constants;

public enum CheckType {
	CHECK_MOBILE, CHECK_EMAIL
}
