package com.gloqr.constants;

public enum UserState {
	VERIFIED, UN_VERIFIED
}
