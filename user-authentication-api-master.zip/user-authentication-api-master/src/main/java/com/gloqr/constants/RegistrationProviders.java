package com.gloqr.constants;

public enum RegistrationProviders {
	GLOQR, FACEBOOK, GOOGLE
}
