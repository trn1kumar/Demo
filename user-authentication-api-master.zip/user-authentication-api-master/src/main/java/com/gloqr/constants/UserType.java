package com.gloqr.constants;

public enum UserType {
	NORMAL,SME,GLOQR
}
