package com.gloqr.constants;

public class Roles {

	private Roles() {
		throw new IllegalStateException("Constants class.can't initiate");
	}

	public static final String USER_ROLE = "USER";
	public static final String SMEFACE_SUPER_ADMIN = "GLOQR-SUPER-ADMIN";
	public static final String SME_ADMIN = "SME-ADMIN";

	public static final String ALL_ROLES = "hasAnyRole('USER','GLOQR-SUPER-ADMIN','SME-ADMIN')";
}
