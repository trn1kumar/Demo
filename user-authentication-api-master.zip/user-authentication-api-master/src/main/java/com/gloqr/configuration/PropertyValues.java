package com.gloqr.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PropertyValues {

	@Value(PropertyNames.BASE_URL)
	private String baseUrl;

	@Value(PropertyNames.CONTENT_SERVER_URL)
	private String contentServerUrl;

	@Value(PropertyNames.OTP_VALIDITY)
	private long otpValidity;

	@Value(PropertyNames.NOTIFY_EMAIL_SUB)
	private String emailSub;

	@Value(PropertyNames.NOTIFY_SMS_MSG)
	private String smsMsg;

	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	public String getContentServerUrl() {
		return contentServerUrl;
	}

	public void setContentServerUrl(String contentServerUrl) {
		this.contentServerUrl = contentServerUrl;
	}

	public String getEmailSub() {
		return emailSub;
	}

	public void setEmailSub(String emailSub) {
		this.emailSub = emailSub;
	}

	public String getSmsMsg() {
		return smsMsg;
	}

	public void setSmsMsg(String smsMsg) {
		this.smsMsg = smsMsg;
	}

	public long getOtpValidity() {
		return otpValidity;
	}

	public void setOtpValidity(long otpValidity) {
		this.otpValidity = otpValidity;
	}

	public static final class PropertyNames {

		private PropertyNames() {
			throw new IllegalStateException("PropertyNames class.can't initiate");
		}

		public static final String BASE_URL = "${base-url}";
		public static final String CONTENT_SERVER_URL = "${content-server.localized-url}";
		public static final String OTP_VALIDITY = "${otp.validity.mins}";

		public static final String NOTIFY_EMAIL_SUB = "${notify.email-sub}";
		public static final String NOTIFY_SMS_MSG = "${notify.sms-msg}";

	}

}
