package com.gloqr.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.gloqr.constants.RegistrationProviders;

@JsonInclude(Include.NON_DEFAULT)
public class UserDetailDto {

	private String udUuid;

	private List<AddressDto> address;
	
	private RegistrationProviders registrationProvider;

	private String profileImage;

	public String getUdUuid() {
		return udUuid;
	}

	public void setUdUuid(String udUuid) {
		this.udUuid = udUuid;
	}

	public List<AddressDto> getAddress() {
		return address;
	}

	public void setAddress(List<AddressDto> address) {
		this.address = address;
	}

	public String getProfileImage() {
		return profileImage;
	}

	public void setProfileImage(String profileImage) {
		this.profileImage = profileImage;
	}

	public RegistrationProviders getRegistrationProvider() {
		return registrationProvider;
	}

	public void setRegistrationProvider(RegistrationProviders registrationProvider) {
		this.registrationProvider = registrationProvider;
	}

}
