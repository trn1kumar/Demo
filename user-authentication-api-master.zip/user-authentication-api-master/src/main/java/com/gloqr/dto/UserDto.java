package com.gloqr.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_DEFAULT)
public class UserDto {

	private String uuid;

	private String userEmail;

	private String userMobile;

	private String userFullName;

	private UserDetailDto userDetail;

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserMobile() {
		return userMobile;
	}

	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public UserDetailDto getUserDetail() {
		return userDetail;
	}

	public void setUserDetail(UserDetailDto userDetail) {
		this.userDetail = userDetail;
	}


	
	
	

}
