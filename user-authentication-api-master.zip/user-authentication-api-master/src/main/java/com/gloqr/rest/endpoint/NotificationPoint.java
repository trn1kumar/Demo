package com.gloqr.rest.endpoint;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.gloqr.model.EmailEvent;
import com.gloqr.model.SmsEvent;

public class NotificationPoint {

	private Client client;
	private String endPointUri;
	private String smsNotificationPath;
	private String emailEndPointPath;
	Logger log = LogManager.getLogger(NotificationPoint.class.getName());

	public NotificationPoint(Client client, String endPointUri, String smsNotificationPath, String emailEndPointPath) {

		this.client = client;
		this.endPointUri = endPointUri;
		this.smsNotificationPath = smsNotificationPath;
		this.emailEndPointPath = emailEndPointPath;
	}

	public <T> void sendNotification(T t) {

		if (t instanceof SmsEvent) {
			log.info("Sending SMS {method=POST ,uri={}{} ,body={} }", endPointUri, smsNotificationPath, t);
			SmsEvent sms = (SmsEvent) t;

			try {
				Response response = client.target(endPointUri).path(smsNotificationPath)
						.request(MediaType.APPLICATION_JSON).post(Entity.entity(sms, MediaType.APPLICATION_JSON));

				log.info(response);
			} catch (Exception e) {
				log.error("failed to send sme event. Exception:- " + e.getMessage());
			}

		} else if (t instanceof EmailEvent) {
			log.info("Sending Email {method=POST ,uri={}{} ,body={} }", endPointUri, emailEndPointPath, t);
			EmailEvent email = (EmailEvent) t;
			try {
				Response response = client.target(endPointUri).path(emailEndPointPath)
						.request(MediaType.APPLICATION_JSON).post(Entity.entity(email, MediaType.APPLICATION_JSON));
				log.info(response);
			} catch (Exception e) {
				log.error("failed to send email event. Exception:- " + e.getMessage());
			}
		}
	}

}
