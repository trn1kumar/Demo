package com.gloqr.model;

import javax.validation.constraints.NotNull;

public class GoogleOAuthToken {

	@NotNull(message="Google OAuth Token Required")
	private String authToken;

	@NotNull(message="Client Id Required")
	private String clientId;

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getAuthToken() {
		return authToken;
	}

	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}

}
