package com.gloqr.model;

public class SmsEvent {

	private String mobileNo;
	private String eventMessage;

	public SmsEvent(String mobileNo, String eventMessage) {
		super();
		this.mobileNo = mobileNo;
		this.eventMessage = eventMessage;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEventMessage() {
		return eventMessage;
	}

	public void setEventMessage(String eventMessage) {
		this.eventMessage = eventMessage;
	}


	@Override
	public String toString() {
		return "SmsEvent [mobileNo=" + mobileNo + ", eventMessage=" + eventMessage +"]";
	}

}
