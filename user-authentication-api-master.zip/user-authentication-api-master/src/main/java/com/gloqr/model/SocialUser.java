package com.gloqr.model;

import javax.validation.constraints.NotNull;

import com.gloqr.constants.RegistrationProviders;

public class SocialUser {

	private String facebookClientId;

	private String facebookClientSecret;

	private String token;

	@NotNull(message = "Email requried")
	private String email;

	private String id;

	@NotNull(message = "Fullname requried")
	private String name;

	private String image;

	private RegistrationProviders registrationProviders;

	private boolean emailVerified;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isEmailVerified() {
		return emailVerified;
	}

	public void setEmailVerified(boolean emailVerified) {
		this.emailVerified = emailVerified;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getFacebookClientSecret() {
		return facebookClientSecret;
	}

	public void setFacebookClientSecret(String facebookClientSecret) {
		this.facebookClientSecret = facebookClientSecret;
	}

	public String getFacebookClientId() {
		return facebookClientId;
	}

	public void setFacebookClientId(String facebookClientId) {
		this.facebookClientId = facebookClientId;
	}

	public RegistrationProviders getRegistrationProviders() {
		return registrationProviders;
	}

	public void setRegistrationProviders(RegistrationProviders registrationProviders) {
		this.registrationProviders = registrationProviders;
	}

}
