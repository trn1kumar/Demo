package com.gloqr.model;

public class FacebookOAuthToken {
	public static final String CLIENT_ID = "{clientId}";
	public static final String CLIENT_SECRET = "{clientSecret}";
	public static final String ACCESSTOKEN = "{access_token}";
	public static final String USER_TOKEN = "{userToken}";

	public static final String ACCESS_TOKEN_URL = "https://graph.facebook.com/oauth/access_token?client_id=" + CLIENT_ID
			+ "&client_secret=" + CLIENT_SECRET + "&grant_type=client_credentials";

	public static final String TOKEN_VERIFICATION_URL = "https://graph.facebook.com/debug_token?input_token=" + USER_TOKEN
			+ "&access_token=" + ACCESSTOKEN;

	private String access_token;
	private FacebookUserData data;

	public String getAccess_token() {
		return access_token;
	}

	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}

	public FacebookUserData getData() {
		return data;
	}

	public void setData(FacebookUserData data) {
		this.data = data;
	}

	public class FacebookUserData {

		private String user_id;
		private String app_id;
		private String type;
		private String application;
		private String expires_at;
		private String is_valid;
		private String[] scopes;

		public String getUser_id() {
			return user_id;
		}

		public void setUser_id(String user_id) {
			this.user_id = user_id;
		}

		public String getApp_id() {
			return app_id;
		}

		public void setApp_id(String app_id) {
			this.app_id = app_id;
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public String getApplication() {
			return application;
		}

		public void setApplication(String application) {
			this.application = application;
		}

		public String getExpires_at() {
			return expires_at;
		}

		public void setExpires_at(String expires_at) {
			this.expires_at = expires_at;
		}

		public String getIs_valid() {
			return is_valid;
		}

		public void setIs_valid(String is_valid) {
			this.is_valid = is_valid;
		}

		public String[] getScopes() {
			return scopes;
		}

		public void setScopes(String[] scopes) {
			this.scopes = scopes;
		}

	}
}
