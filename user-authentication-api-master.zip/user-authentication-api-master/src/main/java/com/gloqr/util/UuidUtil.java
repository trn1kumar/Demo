package com.gloqr.util;

import java.util.UUID;

public class UuidUtil {

	public static String getUuid(String str) {

		String[] strs = str.toLowerCase().split(" ");
		if (strs.length > 1) {
			return strs[0] + "-" + strs[1] + "-"+ RandomStringGenerator.generateRandomString(4)
					+ RandomStringGenerator.generateRandomNumber(10000);
		}
		return strs[0] + "-"+ RandomStringGenerator.generateRandomString(4)
				+ RandomStringGenerator.generateRandomNumber(10000);

	}

	public static String getUuid() {
		return UUID.randomUUID().toString().replace("-", "");
	}
}
