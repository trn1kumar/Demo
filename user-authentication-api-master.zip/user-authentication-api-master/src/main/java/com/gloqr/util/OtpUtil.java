package com.gloqr.util;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import javax.validation.constraints.NotNull;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.gloqr.configuration.PropertyValues.PropertyNames;
import com.gloqr.exception.CustomException;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

@Component
public class OtpUtil {

	private static final Logger LOG = LogManager.getLogger();
	private LoadingCache<String, ArrayList<Integer>> otpCache;

	public OtpUtil(@Value(PropertyNames.OTP_VALIDITY) long otpValidity) {
		super();
		LOG.info("OTP Validity is {} MINUTES.", otpValidity);
		if (otpValidity <= 0) {
			throw new CustomException("OTP validity should be grether then ZERO. Provided Value is: " + otpValidity,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		otpCache = CacheBuilder.newBuilder().expireAfterWrite(otpValidity, TimeUnit.MINUTES)
				.build(new CacheLoader<String, ArrayList<Integer>>() {
					public ArrayList<Integer> load(String key) {
						return new ArrayList<>();
					}
				});
	}

	/*
	 * This method is used to push the opt number against Key. Using user id as key
	 */
	public int generateOTP(@NotNull String key) {
		final int otp = 100 + RandomNumber.generate(900);
		List<Integer> otpList = getOtp(key);
		otpList.add(otp);
		otpCache.put(key, (ArrayList<Integer>) otpList);
		this.printOtp();
		return otp;
	}

	// This method is used to return the Otp number against Key->Key values
	public List<Integer> getOtp(String key) {
		try {
			return otpCache.get(key);
		} catch (ExecutionException e) {
			return new ArrayList<>();
		}

	}

	// This method is used to clear the OTP catched already
	public void clearOTP(String key) {
		otpCache.invalidate(key);
	}

	// This method is used to print the OTP.used only for developer perspective
	private void printOtp() {
		otpCache.asMap().forEach((k, v) -> LOG.info("{} {}", k, v));

	}
}
