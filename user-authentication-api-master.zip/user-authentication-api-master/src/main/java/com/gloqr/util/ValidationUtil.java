package com.gloqr.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;

import com.gloqr.exception.CustomException;

@Component
public class ValidationUtil {

	public static List<String> fromBindingErrors(Errors errors) {
		List<String> validErrors = new ArrayList<>();
		for (ObjectError objectError : errors.getAllErrors()) {
			validErrors.add(objectError.getDefaultMessage());
		}
		return validErrors;
	}

	public void checkUsernameValidation(String username) {
		if (!(StringUtils.isNumeric(username) && username.length() == 10)
				&& !(!StringUtils.isNumeric(username) && username.contains("@") && username.contains("."))) {
			throw new CustomException("Please enter valid Email ID/Mobile number", HttpStatus.BAD_REQUEST);
		}
	}

}
