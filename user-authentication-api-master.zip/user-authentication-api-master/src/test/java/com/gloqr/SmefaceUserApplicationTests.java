package com.gloqr;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.gloqr.dao.UserDaoImpl;
import com.gloqr.entities.User;
import com.gloqr.repository.UserRepository;
import com.gloqr.service.UserServiceImpl;

@SpringBootTest()
public class SmefaceUserApplicationTests {

	@InjectMocks
	private UserServiceImpl userService;

	@Mock
	private UserRepository userRepository;
	
	@Mock
	private UserDaoImpl userDao;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void test() {
		User user = new User();
		user.setUuid("123");
		
		when(userDao.getUserByUuid(user.getUuid())).thenReturn(user);
		User savedUser = userService.getUserByUuid("1231");
		assertThat(user.getUuid(), is(savedUser.getUuid()));
	}

}
