package com.gloqr.constants;

public enum Privacy {
	CIRCLE,PUBLIC,PRIVATE
}
