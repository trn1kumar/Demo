package com.gloqr.model;

import java.util.List;

public class SMEBusinessPostForAdminPanel {

	private String smeId;
	private String userId;
	
	private List<PublishData> postsInfo;

	public String getSmeId() {
		return smeId;
	}

	public String getUserId() {
		return userId;
	}

	public List<PublishData> getPostsInfo() {
		return postsInfo;
	}

	public void setSmeId(String smeId) {
		this.smeId = smeId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public void setPostsInfo(List<PublishData> postsInfo) {
		this.postsInfo = postsInfo;
	}

	@Override
	public String toString() {
		return "SMEBusinessPostForAdminPanel [smeId=" + smeId + ", userId=" + userId + ", postsInfo=" + postsInfo + "]";
	}
	
	
	

}
