package com.gloqr.rest.endpoint;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.gloqr.dto.SMEDto;
import com.gloqr.entity.File;
import com.gloqr.exception.CustomException;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.security.configuration.JwtConstants;
import com.gloqr.security.context.holder.AuthenticationFacade;

public class SmeEndPoint {

	@Autowired
	AuthenticationFacade authenticationFacade;

	private Client client;
	private String endPointUri;
	private String specificSMEsPath;
	private String smeVoPath;
	private String imgUpdatePath;

	public static final String IDS = "smeIds";
	public static final String LOCATIONS = "imageLocations";

	Logger log = LogManager.getLogger(SmeEndPoint.class.getName());

	public SmeEndPoint(Client client, String endPointUri, String specificSMEsPath, String smeVoPath,
			String imgUpdatePath) {
		this.client = client;
		this.endPointUri = endPointUri;
		this.specificSMEsPath = specificSMEsPath;
		this.smeVoPath = smeVoPath;
		this.imgUpdatePath = imgUpdatePath;
	}

	public Map<String, SMEDto> getSMEs(Set<String> smeIds) {
		
		log.info("Getting SMEs details...");
		log.info("Connecting to SME Module...  method=GET ,uri= {}{} ,params={}:{}", endPointUri, specificSMEsPath,
				IDS, smeIds);

		Response response = null;
		CustomHttpResponse<Map<String, SMEDto>> customResponse = null;

		

		try {
			Object[] smeIdParams = smeIds.stream().toArray(String[]::new);
			
			response = client.target(endPointUri).path(specificSMEsPath).queryParam(IDS, smeIdParams)
					.request(MediaType.APPLICATION_JSON).get();
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);

		Integer statusCode = response.getStatus();
		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}
		try {
			customResponse = response.readEntity(new GenericType<CustomHttpResponse<Map<String, SMEDto>>>() {
			});
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}
		if (customResponse.isError()) {
			throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
		}

		return customResponse.getData();

	}

	public SMEDto getSME(String smeId) {
		
		log.info("Getting SME details.  smeId:-{}", smeId);
		log.info("Connecting to SME Module...  {method=GET, uri: {}{} }", endPointUri,
				smeVoPath.replace("{smeId}", smeId));

		Response response = null;
		CustomHttpResponse<SMEDto> customResponse = null;

		
		try {
			response = client.target(endPointUri).path(smeVoPath.replace("{smeId}", smeId))
					.request(MediaType.APPLICATION_JSON).get();
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);
		Integer statusCode = response.getStatus();

		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}
		try {
			customResponse = response.readEntity(new GenericType<CustomHttpResponse<SMEDto>>() {
			});
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}
		if (customResponse.isError()) {
			throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
		}

		return customResponse.getData();

	}

	public void updateBusinessPostImagesByFalse(List<File> files) {
		Response response = null;
		CustomHttpResponse<String> customResponse = null;

		log.info("Updating Business Post Images False for SME INFRAS");
		log.info("Connecting to SME Module...  {method=PUT ,uri= {}{} ,body= {} }", endPointUri, imgUpdatePath,
				"'FileObjs'");

		try {
			response = client.target(endPointUri).path(imgUpdatePath).request(MediaType.APPLICATION_JSON)
					.header(JwtConstants.HEADER_STRING, authenticationFacade.getJwtToken())
					.put(Entity.entity(files, MediaType.APPLICATION_JSON));
		} catch (Exception e) {
			throwConnectionRefusedException(e);

		}

		logResponse(response);
		Integer statusCode = response.getStatus();
		if (statusCode == HttpStatus.OK.value()) {
			try {
				customResponse = response.readEntity(new GenericType<CustomHttpResponse<String>>() {
				});
				if (customResponse.isError()) {
					log.error(customResponse.getMessage());
				}
			} catch (Exception e) {
				throwEntityResponseReadException(e);
			}

		} else {
			throwInvalidResponseException(statusCode);
		}
	}

	private void throwEntityResponseReadException(Exception e) {
		throw new CustomException("Exception at read response from SME Module. Message: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private void throwInvalidResponseException(int statusCode) {
		throw new CustomException("Invalid Response from SME Module: ", HttpStatus.resolve(statusCode));
	}

	private void throwConnectionRefusedException(Exception e) {
		throw new CustomException("Couldn't Connect to SME module, Exception: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private void logResponse(Response response) {
		log.info("Response From SME Module : " + response);
	}

}
