package com.gloqr.model;

import com.gloqr.constants.BusinessPostState;
import com.gloqr.constants.PostStatus;

public class PublishData {

	private String id;

	// sme admin
	private PostStatus smeAction;

	// smeface admin
	private BusinessPostState state;
	private String feedbackMessage;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}


	public String getFeedbackMessage() {
		return feedbackMessage;
	}

	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}

	public BusinessPostState getState() {
		return state;
	}

	public void setState(BusinessPostState state) {
		this.state = state;
	}

	public PostStatus getSmeAction() {
		return smeAction;
	}

	public void setSmeAction(PostStatus smeAction) {
		this.smeAction = smeAction;
	}

	@Override
	public String toString() {
		return "PublishData [id=" + id + ", smeAction=" + smeAction + ", state=" + state + ", feedbackMessage="
				+ feedbackMessage + "]";
	}
	
	
	
}
