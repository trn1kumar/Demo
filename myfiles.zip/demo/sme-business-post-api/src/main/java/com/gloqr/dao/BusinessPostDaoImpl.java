package com.gloqr.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.constants.BusinessPostState;
import com.gloqr.entity.BusinessPost;
import com.gloqr.exception.CustomException;
import com.gloqr.model.PublishData;
import com.gloqr.repository.SMEBusinessPostRepository;

@Repository
public class BusinessPostDaoImpl implements BusinessPostDao {

	@Autowired
	SMEBusinessPostRepository businessPostRepo;

	@Override
	public void save(BusinessPost businessPost) {
		try {
			businessPostRepo.save(businessPost);
		} catch (Exception e) {
			throw new CustomException("Exception while saving post. Message:: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

	}

	@Override
	public void savePosts(List<BusinessPost> posts) {
		try {
			businessPostRepo.saveAll(posts);
		} catch (Exception e) {
			throw new CustomException("Exception in :: savePosts(),  message:  " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@Override
	public List<BusinessPost> getApprovedAndActiveTruePosts(String smeUuid) {
		List<BusinessPost> posts = null;
		posts = businessPostRepo.findBySmeUuidAndPostStateAndActiveTrue(smeUuid, BusinessPostState.APPROVED);
		if (posts != null && !posts.isEmpty()) {
			return posts;
		} else {
			throw new CustomException("No posts found for sme  " + smeUuid, HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public List<BusinessPost> getPostsBySMEId(String smeId) {

		List<BusinessPost> posts = businessPostRepo.findBySmeUuid(smeId);

		if (posts != null && !posts.isEmpty())
			return posts;
		else
			throw new CustomException("Post Not available for sme  " + smeId, HttpStatus.NOT_FOUND);
	}

	@Override
	public List<BusinessPost> getPendingAndRejectedPosts(String smeId) {
		List<BusinessPost> posts = businessPostRepo.findBySmeUuidAndPostStateNotIn(smeId, BusinessPostState.APPROVED);

		if (posts != null && !posts.isEmpty())
			return posts;
		else
			throw new CustomException("Post Not available for sme  " + smeId, HttpStatus.NOT_FOUND);

	}

	@Override
	public void delete(BusinessPost post) {
		try {
			businessPostRepo.delete(post);
		} catch (Exception e) {
			throw new CustomException("Failed to delete Business-Post by ID: " + post.getBusinessPostId(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
	}

	@Override
	public List<BusinessPost> getApprovedTaggedPostsBySmeId(List<String> taggedPostIds, String smeUuid) {
		List<BusinessPost> posts = businessPostRepo.findByBusinessPostIdInAndPostStateAndActive(taggedPostIds,
				BusinessPostState.APPROVED, true);

		if (posts != null && !posts.isEmpty()) {
			return posts;
		} else {
			throw new CustomException("No Tagged Posts availables In " + taggedPostIds, HttpStatus.NOT_FOUND);
		}

	}

	@Override
	public void updatePostsStatus(List<PublishData> publish) {
		businessPostRepo.updatePostStatus(publish);

	}

	@Override
	public BusinessPost getPostById(String postId) {
		Optional<BusinessPost> postOpt = null;
		postOpt = businessPostRepo.findById(postId);
		if (!postOpt.isPresent())
			throw new CustomException("Post not present with id " + postId, HttpStatus.NOT_FOUND);
		return postOpt.get();
	}

}
