package com.gloqr.dao;

import java.util.List;

import com.gloqr.entity.BusinessPost;
import com.gloqr.model.PublishData;

public interface BusinessPostDao {

	void save(BusinessPost businessPost);

	void savePosts(List<BusinessPost> posts);

	BusinessPost getPostById(String postId);

	List<BusinessPost> getApprovedAndActiveTruePosts(String smeId);

	List<BusinessPost> getPostsBySMEId(String smeId);

	List<BusinessPost> getPendingAndRejectedPosts(String smeId);

	void delete(BusinessPost post);

	List<BusinessPost> getApprovedTaggedPostsBySmeId(List<String> taggedPostIds, String smeUuid);

	void updatePostsStatus(List<PublishData> publish);

}
