package com.gloqr.controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.constants.BusinessPostConstants.FileDirectory;
import com.gloqr.constants.Roles;
import com.gloqr.constants.UrlMapping;
import com.gloqr.entity.File;
import com.gloqr.exception.CustomException;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.model.http.response.ResponseMessages;
import com.gloqr.security.context.holder.UserDetails;
import com.gloqr.service.FileService;

@RestController
@CrossOrigin("*")
@RequestMapping(UrlMapping.ROOT_API)
@SuppressWarnings("rawtypes")
public class FileController {

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private FileService fileService;

	private Logger log = LogManager.getLogger();

	@PostMapping(UrlMapping.UPLOAD_FILES)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse<List<File>>> uploadBusinessPostFiles(Authentication authentication,
			@RequestParam(value = "files") MultipartFile[] multipartFiles) {
		final UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = userDetails.getSmeId();
		log.info("Request for Upload Business-Post Files by smeId: {}", loggedInSmeId);
		List<File> images = null;

		try {
			images = fileService.sendFilesToContentServer(Arrays.asList(multipartFiles),
					FileDirectory.FILE_DIR.replace("{loggedInSmeId}", loggedInSmeId));
		} catch (IllegalArgumentException | IOException e) {
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return responseMaker.successResponse(images, ResponseMessages.FILE_UPLODED, HttpStatus.OK);
	}

	@DeleteMapping(UrlMapping.DELETE_FILE)
	public ResponseEntity<CustomHttpResponse> deleteBusinessPostFiles(@PathVariable String fileLocation) {

		try {
			fileService.deleteFileFromContentServer(fileLocation);
		} catch (IllegalArgumentException | IOException e) {
			log.error("Exception:: ", e);
		}
		return responseMaker.successResponse(ResponseMessages.FILE_UPLODED, HttpStatus.OK);
	}
}
