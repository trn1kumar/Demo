package com.gloqr.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gloqr.constants.BusinessPostState;
import com.gloqr.constants.CreditType;
import com.gloqr.constants.BusinessPostConstants.PostStatus;
import com.gloqr.entity.BusinessPost;
import com.gloqr.exception.CustomException;
import com.gloqr.model.PricingRequest;
import com.gloqr.model.PublishData;
import com.gloqr.model.SMEBusinessPostForAdminPanel;
import com.gloqr.repository.SMEBusinessPostRepository;
import com.gloqr.rest.endpoint.PricingEndpoint;

@Service
public class GloqrAdminServiceImpl implements GloqrAdminService {

	public static final String DATE_FORMAT = "E, dd MMM yyyy HH:mm:ss";

	private Logger log = LogManager.getLogger();

	@Autowired
	private SMEBusinessPostRepository smeBusinessPostRepository;

	@Autowired
	private BusinessPostService businessPostService;

	@Autowired
	private PricingEndpoint pricingEnpoint;

	@Autowired
	private NotificationService notificationService;

	@Override
	public Map<String, Integer> getSMEPostsCount(List<String> smeIds) {
		Map<String, Integer> counts = new HashMap<>();

		smeIds.forEach(smeid -> {
			int count = smeBusinessPostRepository.countBySmeUuidAndPostStateAndActive(smeid, BusinessPostState.PENDING,
					true);
			counts.put(smeid, count);
		});
		return counts;

	}

	public List<BusinessPost> getPosts(String smeUuid) {
		List<BusinessPost> posts = smeBusinessPostRepository.findBySmeUuidAndPostStateAndActiveTrue(smeUuid,
				BusinessPostState.PENDING);
		if (posts != null && !posts.isEmpty()) {
			return posts;
		} else {
			throw new CustomException("No Posts Available for sme:- " + smeUuid, HttpStatus.NOT_FOUND);
		}

	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public void approveOrRejectBusinessPostsState(SMEBusinessPostForAdminPanel posts) {
		List<BusinessPost> saveForBatchUpdate = new ArrayList<>();

		for (PublishData post : posts.getPostsInfo()) {
			this.changeState(saveForBatchUpdate, post, post.getId(), post.getState());
		}
		this.updateStates(posts.getUserId(), posts.getSmeId(), saveForBatchUpdate);
	}

	private void changeState(List<BusinessPost> saveForBatchUpdate, PublishData post, String postId,
			BusinessPostState postState) {
		try {

			BusinessPost existPost = businessPostService.getSinglePost(postId);

			if (existPost.isActive() && existPost.getPostState().equals(BusinessPostState.PENDING)) {
				existPost.setPostState(postState);
				if (postState.equals(BusinessPostState.REJECTED)) {
					existPost.setActive(PostStatus.FALSE);
				}
				if (post.getFeedbackMessage() != null) {
					String dateAndAction = "[ Date:-" + new SimpleDateFormat(DATE_FORMAT).format(new Date())
							+ " Action:-" + postState + " ] ";
					post.setFeedbackMessage(dateAndAction.concat(post.getFeedbackMessage()));

					if (existPost.getFeedbackMessage() != null) {
						existPost.setFeedbackMessage(
								existPost.getFeedbackMessage().concat("| " + post.getFeedbackMessage()));
					} else {
						existPost.setFeedbackMessage(post.getFeedbackMessage());
					}

				}
				saveForBatchUpdate.add(existPost);
			}
		} catch (Exception e) {
			log.error("Exception:- {}", e.getMessage());
		}

	}

	private void updateStates(String userId, String smeId, List<BusinessPost> saveForBatchUpdate) {

		if (!saveForBatchUpdate.isEmpty()) {
			businessPostService.saveMultiplePosts(saveForBatchUpdate);

			long rejectedPostsCount = saveForBatchUpdate.stream()
					.filter(post -> post.getPostState().equals(BusinessPostState.REJECTED)).count();

			if (rejectedPostsCount > 0) {
				PricingRequest pricingRequest = new PricingRequest();
				pricingRequest.setCreditType(CreditType.BUSINESS_POST);
				pricingRequest.setCredits(rejectedPostsCount);
				pricingRequest.setAction("CREDIT");
				pricingRequest.setsUuid(smeId);
				pricingRequest.setUserUUID(userId);

				pricingEnpoint.updateCredits(pricingRequest);
			}
			notificationService.schedulePostsStateChangedSummaryNotifi(smeId, saveForBatchUpdate, rejectedPostsCount);
		} else {
			log.info("No Posts available for modify state");
		}
	}

}
