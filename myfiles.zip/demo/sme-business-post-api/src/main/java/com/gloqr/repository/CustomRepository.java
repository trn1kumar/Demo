package com.gloqr.repository;

import java.util.List;

import com.gloqr.model.PublishData;

public interface CustomRepository {

	void updatePostStatus(List<PublishData> publish);

}
