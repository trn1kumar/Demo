package com.gloqr.dto;

public class BusinessPostsCount {

	private String smeId;
	private int businessPostCount;
	
	public BusinessPostsCount(String smeId, int businessPostCount) {
		super();
		this.smeId = smeId;
		this.businessPostCount = businessPostCount;
	}
	public String getSmeId() {
		return smeId;
	}
	public int getBusinessPostCount() {
		return businessPostCount;
	}
	public void setSmeId(String smeId) {
		this.smeId = smeId;
	}
	public void setBusinessPostCount(int businessPostCount) {
		this.businessPostCount = businessPostCount;
	}
	
	
}
