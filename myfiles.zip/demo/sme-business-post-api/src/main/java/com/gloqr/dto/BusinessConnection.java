package com.gloqr.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BusinessConnection {

	private String smeId;

	public String getSmeId() {
		return smeId;
	}

	public void setSmeId(String smeId) {
		this.smeId = smeId;
	}


}
