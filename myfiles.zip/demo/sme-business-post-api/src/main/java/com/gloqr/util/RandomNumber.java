package com.gloqr.util;

import java.util.Random;

public class RandomNumber {
	
	public static Integer generate(int length) {
		return new Random().nextInt(length);
	}
}
