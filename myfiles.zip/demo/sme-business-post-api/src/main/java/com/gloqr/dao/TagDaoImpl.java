package com.gloqr.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.entity.Tag;
import com.gloqr.exception.CustomException;
import com.gloqr.repository.TagRepository;

@Service
public class TagDaoImpl implements TagDao {

	@Autowired
	private TagRepository tagRepo;

	@Override
	public void saveTag(Tag tag) {
		try {
			tagRepo.save(tag);
		} catch (Exception e) {
			throw new CustomException("Error while saving tag. " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

	}

	@Override
	public Tag getTag(String tagId) {
		Optional<Tag> tagOpt = tagRepo.findById(tagId);
		if (tagOpt.isPresent()) {
			return tagOpt.get();
		} else {
			throw new CustomException("Tag not present with id:: " + tagId, HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public void deleteTag(Tag tag) {
		try {
			tagRepo.delete(tag);
		} catch (Exception e) {
			throw new CustomException("Exception while deleting tag by id:: " + tag.getSmeId(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

	}

}
