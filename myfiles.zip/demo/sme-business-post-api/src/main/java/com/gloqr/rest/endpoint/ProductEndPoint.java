package com.gloqr.rest.endpoint;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;

import com.gloqr.entity.File;
import com.gloqr.exception.CustomException;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.security.configuration.JwtConstants;
import com.gloqr.security.context.holder.AuthenticationFacade;

public class ProductEndPoint {

	private Client client;
	private String endPointUri;
	private String postImgEditPath;

	@Autowired
	private AuthenticationFacade authenticationFacade;

	private Logger log = LogManager.getLogger();

	public ProductEndPoint(Client client, String endPointUri, String postImgEditPath) {
		super();
		this.client = client;
		this.endPointUri = endPointUri;
		this.postImgEditPath = postImgEditPath;
	}

	@Async(value = "taskExecutor")
	public void updateBusinessPostImagesByFalse(List<File> files) {
		Response response = null;
		CustomHttpResponse<String> customResponse = null;

		log.info("Updating Business Post Images False for PRODUCTS");
		log.info("Connecting to Product Module...  {method=PUT ,uri= {}{} ,body= {} }", endPointUri, postImgEditPath,
				"'FileObjs'");
		try {
			response = client.target(endPointUri).path(postImgEditPath).request(MediaType.APPLICATION_JSON)
					.header(JwtConstants.HEADER_STRING, authenticationFacade.getJwtToken())
					.put(Entity.entity(files, MediaType.APPLICATION_JSON));
		} catch (Exception e) {
			throwConnectionRefusedException(e);

		}

		logResponse(response);

		Integer statusCode = response.getStatus();
		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}

		try {
			customResponse = response.readEntity(new GenericType<CustomHttpResponse<String>>() {
			});
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}

		if (customResponse.isError()) {
			throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
		}

	}

	private void throwEntityResponseReadException(Exception e) {
		throw new CustomException("Exception at read response from Product Module. Message: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	private void throwInvalidResponseException(int statusCode) {
		throw new CustomException("Invalid Response from Product Module: ", HttpStatus.resolve(statusCode));
	}

	private void throwConnectionRefusedException(Exception e) {
		throw new CustomException("Couldn't Connect to Product module, Exception: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	private void logResponse(Response response) {
		log.info("Response From Product Module : " + response);
	}

}
