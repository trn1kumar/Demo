package com.gloqr.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.gloqr.entity.File;

public interface FileRepository extends MongoRepository<File, String>{

	List<File> findByFileLocationIn(Set<String> fileLocations);

	
}
