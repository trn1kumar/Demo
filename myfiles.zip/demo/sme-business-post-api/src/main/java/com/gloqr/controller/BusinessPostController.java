package com.gloqr.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.aop.CheckAndUpdate;
import com.gloqr.aop.PublishCheckAndUpdate;
import com.gloqr.constants.Roles;
import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.BusinessPostDto;
import com.gloqr.dto.SMEDto;
import com.gloqr.entity.BusinessPost;
import com.gloqr.mapper.BusinessPostMapper;
import com.gloqr.model.PublishData;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.model.http.response.ResponseMessages;
import com.gloqr.security.context.holder.UserDetails;
import com.gloqr.service.BusinessPostService;
import com.gloqr.service.SMEService;

@RestController
@RequestMapping(UrlMapping.ROOT_API)
@CrossOrigin("*")
@SuppressWarnings("rawtypes")
public class BusinessPostController {

	private Logger log = LogManager.getLogger();

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private BusinessPostService businessPostService;

	@Autowired
	private BusinessPostMapper businessPostMapper;

	@Autowired
	private SMEService smeService;

	@PostMapping(UrlMapping.BUSINESS_POST)
	@PreAuthorize(Roles.SME_ADMIN)
	@CheckAndUpdate
	public ResponseEntity<CustomHttpResponse<BusinessPostDto>> createBusinessPost(Authentication authentication,
			@Valid @RequestBody BusinessPostDto businessPostDto,
			@RequestParam(required = false) boolean publishedPost) {

		final UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = userDetails.getSmeId();
		log.info("Request for Create Business-Post by smeId: {} and publishedPost: {}", loggedInSmeId, publishedPost);
		BusinessPost businessPost = null;
		BusinessPostDto postDto = null;

		try {
			businessPostDto.setSmeUuid(loggedInSmeId);
			businessPost = businessPostService
					.createPost(businessPostMapper.convertToEntity(businessPostDto, BusinessPost.class));

			postDto = businessPostMapper.convertToDto(businessPost, BusinessPostDto.class);

			if (publishedPost) {
				return ResponseEntity.ok().build();
			}

			postDto.setSmeInfo(smeService.getSME(businessPost.getSmeUuid()));
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(postDto, ResponseMessages.POST_CREATED, HttpStatus.CREATED);

	}

	@PutMapping(UrlMapping.BUSINESS_POST)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> updateBusinessPost(Authentication authentication,
			@RequestBody BusinessPostDto businessPostDto) {
		final UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = userDetails.getSmeId();
		log.info("Request for Update Business-Post by smeId: {}", loggedInSmeId);
		try {
			businessPostService.updatePost(businessPostMapper.convertToEntity(businessPostDto, BusinessPost.class));
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.POST_UPDATED, HttpStatus.OK);
	}

	@DeleteMapping(UrlMapping.SINGLE_POST)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> deleteBusinessPost(Authentication authentication,
			@PathVariable String businessPostId) {
		final UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = userDetails.getSmeId();
		log.info("Request for Delete Business-Post by smeId: {}", loggedInSmeId);
		try {
			businessPostService.deleteBusinessPost(loggedInSmeId, businessPostId);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.POST_DELETED, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.SINGLE_POST)
	public ResponseEntity<CustomHttpResponse<BusinessPostDto>> getPost(@PathVariable String businessPostId) {
		BusinessPostDto postDto = null;
		try {
			BusinessPost post = businessPostService.getSinglePost(businessPostId);
			postDto = businessPostMapper.convertToDto(post, BusinessPostDto.class);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(postDto, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.BUSINESS_POSTS)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse<List<BusinessPostDto>>> getLoggedInSMEsPosts(Authentication authentication,
			@RequestParam(required = false) boolean fetchPendingOrRejectedPosts) {

		UserDetails userDetails = (UserDetails) authentication.getPrincipal();

		List<BusinessPostDto> postsDto = new ArrayList<>();
		try {
			List<BusinessPost> posts = businessPostService.getPostsBySMEIdForEditMode(userDetails.getSmeId(),
					fetchPendingOrRejectedPosts);

			Set<String> smeIds = posts.stream().map(BusinessPost::getSmeUuid).collect(Collectors.toSet());
			Map<String, SMEDto> smes = smeService.getSMEs(smeIds);

			posts.forEach(post -> {
				BusinessPostDto postDto = businessPostMapper.convertToDto(post, BusinessPostDto.class);
				postDto.setSmeInfo(smes.get(post.getSmeUuid()));
				postsDto.add(postDto);

			});
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(postsDto, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.SME_POSTS)
	public ResponseEntity<CustomHttpResponse<List<BusinessPostDto>>> getPostsForViewMode(Authentication authentication,
			@PathVariable String smeId) {
		List<BusinessPostDto> postsDto = new ArrayList<>();
		try {

			List<BusinessPost> posts = businessPostService.getPostsForViewMode(authentication, smeId);

			Set<String> smeIds = posts.stream().map(BusinessPost::getSmeUuid).collect(Collectors.toSet());
			Map<String, SMEDto> smes = smeService.getSMEs(smeIds);

			posts.forEach(post -> {
				BusinessPostDto postDto = businessPostMapper.convertToDto(post, BusinessPostDto.class);
				postDto.setSmeInfo(smes.get(post.getSmeUuid()));
				postsDto.add(postDto);

			});

		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(postsDto, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@PutMapping(UrlMapping.MODIFY_STATUS)
	@PreAuthorize(Roles.SME_ADMIN)
	@PublishCheckAndUpdate
	public ResponseEntity<CustomHttpResponse> updatePostStatus(@RequestBody List<PublishData> datas) {
		try {
			businessPostService.updateStatus(datas);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.POST_UPDATED, HttpStatus.OK);
	}

}
