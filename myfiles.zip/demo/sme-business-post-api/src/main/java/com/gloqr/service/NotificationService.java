package com.gloqr.service;

import java.util.List;

import com.gloqr.entity.BusinessPost;

public interface NotificationService {

	void unscheduleJob(String jobName);

	void schedulePostsStateChangedSummaryNotifi(String smeId, List<BusinessPost> saveForBatchUpdate,
			long rejectedPostsCount);


}
