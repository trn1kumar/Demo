package com.gloqr.entity;

import java.util.List;
import java.util.Set;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import com.gloqr.audit.DateAuditable;
import com.gloqr.constants.BusinessPostState;
import com.gloqr.constants.PostType;
import com.gloqr.constants.Privacy;

@Document(collection = "sme_posts")
public class BusinessPost extends DateAuditable {

	@Id
	private String businessPostId;

	@Indexed
	private String smeUuid;

	private String title;

	private String description;

	private boolean active ;
	
	private Privacy privacy;

	private PostType postType ;

	@Indexed
	private String publishFeedId;

	private BusinessPostState postState;

	private String feedbackMessage;

	private boolean postModified;

	@DBRef
	private List<File> files;

	private int postLikeCount;

	private int postCommentCount;

	private Set<String> likes;

	private Set<PostComment> postComments;

	private Set<String> tags;

	public String getBusinessPostId() {
		return businessPostId;
	}

	public void setBusinessPostId(String businessPostId) {
		this.businessPostId = businessPostId;
	}

	public String getSmeUuid() {
		return smeUuid;
	}

	public void setSmeUuid(String smeUuid) {
		this.smeUuid = smeUuid;
	}

	public String getFeedbackMessage() {
		return feedbackMessage;
	}

	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}


	public Set<String> getTags() {
		return tags;
	}

	public void setTags(Set<String> tags) {
		this.tags = tags;
	}

	public int getPostLikeCount() {
		return postLikeCount;
	}

	public void setPostLikeCount(int postLikeCount) {
		this.postLikeCount = postLikeCount;
	}

	public int getPostCommentCount() {
		return postCommentCount;
	}

	public void setPostCommentCount(int postCommentCount) {
		this.postCommentCount = postCommentCount;
	}

	public Set<PostComment> getPostComments() {
		return postComments;
	}

	public void setPostComments(Set<PostComment> postComments) {
		this.postComments = postComments;
	}

	public Set<String> getLikes() {
		return likes;
	}

	public void setLikes(Set<String> likes) {
		this.likes = likes;
	}

	public List<File> getFiles() {
		return files;
	}

	public void setFiles(List<File> files) {
		this.files = files;
	}

	public String getPublishFeedId() {
		return publishFeedId;
	}

	public void setPublishFeedId(String publishFeedId) {
		this.publishFeedId = publishFeedId;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}


	public Privacy getPrivacy() {
		return privacy;
	}

	public void setPrivacy(Privacy privacy) {
		this.privacy = privacy;
	}

	public PostType getPostType() {
		return postType;
	}

	public void setPostType(PostType postType) {
		this.postType = postType;
	}

	public BusinessPostState getPostState() {
		return postState;
	}

	public void setPostState(BusinessPostState postState) {
		this.postState = postState;
	}

	public boolean isPostModified() {
		return postModified;
	}

	public void setPostModified(boolean postModified) {
		this.postModified = postModified;
	}

}
