package com.gloqr.rest.endpoint;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;

import com.gloqr.exception.CustomException;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.notification.SchedulerJobInfo;

public class NotificationEndPoint {

	private Client client;
	private String endPointUri;
	private String smsEndPointPath;
	private String emailEndPointPath;
	private String scheduleJobPath;
	private String unscheduleJobPath;

	Logger log = LogManager.getLogger();

	public NotificationEndPoint(Client client, String endPointUri, String smsEndPointPath, String emailEndPointPath,
			String scheduleJobPath, String unscheduleJobPath) {
		this.client = client;
		this.endPointUri = endPointUri;
		this.smsEndPointPath = smsEndPointPath;
		this.emailEndPointPath = emailEndPointPath;
		this.scheduleJobPath = scheduleJobPath;
		this.unscheduleJobPath = unscheduleJobPath;
	}

	@Async(value = "taskExecutor")
	public void scheduleJob(SchedulerJobInfo schedulerJobInfo) {

		Response response = null;
		CustomHttpResponse<?> customResponse = null;
		log.info("Scheduling New Job..");
		log.info("Connecting to Notification Module... {method=POST ,uri= {}{} ,body= {} }", endPointUri,
				scheduleJobPath, schedulerJobInfo);
		try {
			response = client.target(endPointUri).path(scheduleJobPath).request(MediaType.APPLICATION_JSON)
					.post(Entity.entity(schedulerJobInfo, MediaType.APPLICATION_JSON));
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);

		Integer statusCode = response.getStatus();
		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}
		try {
			customResponse = response.readEntity(new GenericType<CustomHttpResponse<?>>() {
			});
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}
		if (customResponse.isError()) {
			throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
		}
	}

	@Async(value = "taskExecutor")
	public void unscheduleJob(String jobName) {

		Response response = null;
		CustomHttpResponse<?> customResponse = null;

		log.info("UnScheduling Job with JobName {}", jobName);
		log.info("Connecting to Notification Module...  {method=PUT ,uri= {}{} ,params=jobName:{} }", endPointUri,
				unscheduleJobPath, jobName);
		try {
			response = client.target(endPointUri).path(unscheduleJobPath).queryParam("jobName", jobName)
					.request(MediaType.APPLICATION_JSON).put(Entity.entity("", MediaType.APPLICATION_JSON));
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);

		Integer statusCode = response.getStatus();
		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}
		try {
			customResponse = response.readEntity(new GenericType<CustomHttpResponse<?>>() {
			});
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}
		if (customResponse.isError()) {
			throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
		}

	}

	private void throwEntityResponseReadException(Exception e) {
		throw new CustomException("Exception at read response from Notification Module. Message: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	private void throwInvalidResponseException(int statusCode) {
		throw new CustomException("Invalid Response from Notification Module: ", HttpStatus.resolve(statusCode));
	}

	private void throwConnectionRefusedException(Exception e) {
		throw new CustomException("Couldn't Connect to Notification module, Exception: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	private void logResponse(Response response) {
		log.info("Response From Notification Module : " + response);
	}

}
