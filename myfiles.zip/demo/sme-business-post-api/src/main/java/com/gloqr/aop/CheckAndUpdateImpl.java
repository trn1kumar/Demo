package com.gloqr.aop;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.gloqr.constants.CreditType;
import com.gloqr.constants.PostType;
import com.gloqr.dao.FileDao;
import com.gloqr.dto.BusinessPostDto;
import com.gloqr.entity.File;
import com.gloqr.exception.CustomException;
import com.gloqr.exception.NoCreditException;
import com.gloqr.model.PricingRequest;
import com.gloqr.rest.endpoint.PricingEndpoint;

@Aspect
@Configuration
public class CheckAndUpdateImpl {

	Logger logger = LogManager.getLogger(CheckAndUpdateImpl.class.getName());

	@Autowired
	private PricingEndpoint pricingEnpoint;

	@Autowired
	private FileDao fileDao;

	@Before("@annotation(com.gloqr.aop.CheckAndUpdate)")
	public void beforeMethodExecution(JoinPoint joinPoint) {

		Object[] objs = joinPoint.getArgs();
		BusinessPostDto businessPost = (BusinessPostDto) objs[1];

		try {

			if (businessPost.getPostType() != null && businessPost.getPostType().equals(PostType.DEFAULT)
					&& businessPost.getFiles() != null) {

				Set<String> fileLocations = businessPost.getFiles().stream().map(File::getFileLocation)
						.collect(Collectors.toSet());
				List<File> files = fileDao.getFilesByLocations(fileLocations);
				long totalFileSize = 0;

				for (File file : files) {
					file.setActive(true);
					totalFileSize += file.getSize();
				}
				businessPost.setFiles(files);

				logger.info("Checking Available Credits for IMAGE STORAGE for size:  " + totalFileSize);
				if (pricingEnpoint.checkCredits(CreditType.IMAGE_STORAGE) < totalFileSize) {
					throw new NoCreditException(CreditType.IMAGE_STORAGE);
				}
			}

			if (businessPost.isActive()) {
				pricingEnpoint.checkCredits(CreditType.BUSINESS_POST);
			}
		} catch (CustomException e) {
			logger.info(e.getMessage());
			throw e;
		}

	}

	@AfterReturning("@annotation(com.gloqr.aop.CheckAndUpdate)")
	public void updateCredits(JoinPoint joinPoint) {

		PricingRequest pricingRequest = null;
		Object[] objs = joinPoint.getArgs();
		BusinessPostDto businessPost = (BusinessPostDto) objs[1];

		try {

			if (businessPost.getPostType() != null && businessPost.getPostType().equals(PostType.DEFAULT)
					&& businessPost.getFiles() != null) {
				long totalFileSize = businessPost.getFiles().stream().mapToLong(File::getSize).sum();
				pricingEnpoint.updateCredits(CreditType.IMAGE_STORAGE, totalFileSize,"Image Updation for Add business post","DEBIT");
			}

			if (businessPost.isActive()) {
				logger.info("Updating Credits of " + CreditType.BUSINESS_POST);

				pricingRequest = new PricingRequest();
				pricingRequest.setUsedFor("Adding Business post");
				pricingRequest.setAction("DEBIT");
				pricingRequest.setCredits(1);
				pricingRequest.setCreditType(CreditType.BUSINESS_POST);
				pricingEnpoint.updateCredits(pricingRequest);
			}
		} catch (Exception e) {
			logger.info(e.getMessage());
			throw e;
		}

	}

}
