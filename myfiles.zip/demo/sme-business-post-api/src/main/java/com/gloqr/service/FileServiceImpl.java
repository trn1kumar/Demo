package com.gloqr.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.constants.PostType;
import com.gloqr.dao.FileDao;
import com.gloqr.entity.File;
import com.gloqr.model.UploadFileResponse;
import com.gloqr.rest.endpoint.ContentServerEndpoint;
import com.gloqr.rest.endpoint.ProductEndPoint;
import com.gloqr.rest.endpoint.ServiceEndPoint;
import com.gloqr.rest.endpoint.SmeEndPoint;
import com.gloqr.util.RandomNumber;

@Service
public class FileServiceImpl implements FileService {

	private Logger log = LogManager.getLogger();

	@Autowired
	private ContentServerEndpoint contentServerEndpoint;

	@Autowired
	private SmeEndPoint smeInformationEndPoint;

	@Autowired
	private ServiceEndPoint serviceEndPoint;

	@Autowired
	private ProductEndPoint productEndPoint;

	@Autowired
	private FileDao fileDao;

	@Override
	public List<File> sendFilesToContentServer(List<MultipartFile> multipartFiles, String fileLocation)
			throws IOException {

		List<File> files = null;

		List<String> names = new ArrayList<>();
		multipartFiles.forEach(file -> {
			String imageName = RandomNumber.generate(1000) + file.getOriginalFilename();
			names.add(imageName);
		});

		List<UploadFileResponse> fileDetails = contentServerEndpoint.sendFilesToContentServer(multipartFiles, names,
				fileLocation);

		files = new ArrayList<>();
		for (UploadFileResponse fileDetail : fileDetails) {
			files.add(new File(fileDetail.getFileName(), fileDetail.getFileLocation(), false, fileDetail.getSize()));
		}

		fileDao.saveFiles(files);

		return files;

	}

	@Override
	public void deleteFileFromContentServer(String fileLocation) throws IOException {
		// contentServerEndpoint.deleteFileFromContentServer(fileLocation);
	}

	@Override
	public void updateBusinessPostImages(PostType postType, List<File> files) {
		switch (postType) {

		case INFRA:
			smeInformationEndPoint.updateBusinessPostImagesByFalse(files);
			break;
		case SERVICE:
			serviceEndPoint.updateBusinessPostImagesByFalse(files);
			break;
		case PRODUCT:
			productEndPoint.updateBusinessPostImagesByFalse(files);
			break;
		case VACANCY:
			// vacancy post type, don't have images for modification
			break;

		default:
			log.warn("Invalid PostType Selection");
		}
	}
}
