package com.gloqr.rest.endpoint;

import java.util.Set;

import javax.ws.rs.client.Client;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.gloqr.dto.BusinessConnection;
import com.gloqr.exception.CustomException;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.security.configuration.JwtConstants;
import com.gloqr.security.context.holder.AuthenticationFacade;

public class SMECircleEndPoint {

	private Client client;
	private String endPointUri;
	private String connectionsPath;

	@Autowired
	private AuthenticationFacade authenticationFacade;

	private Logger log = LogManager.getLogger(SMECircleEndPoint.class.getName());

	public SMECircleEndPoint(Client client, String endPointUri, String connectionsPath) {
		super();
		this.client = client;
		this.endPointUri = endPointUri;
		this.connectionsPath = connectionsPath;
	}

	public Set<BusinessConnection> getBusinessConnection(String smeId) {
		log.info("Getting Connections of smeId:- {}", smeId);
		log.info("Connecting Circle Module... {method=GET, uri: {}{} ,param: isBusinessPostServiceRequest={} }",
				endPointUri, connectionsPath, true);

		Response response = null;
		Set<BusinessConnection> businessConnections = null;
		CustomHttpResponse<Set<BusinessConnection>> httpResponse = null;

		try {
			response = client.target(endPointUri).path(connectionsPath).queryParam("isBusinessPostServiceRequest", true)
					.request(MediaType.APPLICATION_JSON)
					.header(JwtConstants.HEADER_STRING, authenticationFacade.getJwtToken()).get();

		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);

		Integer statusCode = response.getStatus();

		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}

		try {
			httpResponse = response.readEntity(new GenericType<CustomHttpResponse<Set<BusinessConnection>>>() {
			});
			businessConnections = httpResponse.getData();

		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}

		if (businessConnections != null && !businessConnections.isEmpty()) {
			return businessConnections;
		} else {
			throw new CustomException("No Connections Found for SME " + smeId, HttpStatus.NOT_FOUND);
		}
	}

	private void throwEntityResponseReadException(Exception e) {
		throw new CustomException("Exception at read response from Circle Module. Message: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private void throwInvalidResponseException(int statusCode) {
		throw new CustomException("Invalid Response from Circle Module: ", HttpStatus.resolve(statusCode));
	}

	private void throwConnectionRefusedException(Exception e) {
		throw new CustomException("Couldn't Connect to Circle module, Exception: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	private void logResponse(Response response) {
		log.info("Response From Circle Module : " + response);
	}

}
