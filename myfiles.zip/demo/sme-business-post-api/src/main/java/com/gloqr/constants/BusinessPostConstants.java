package com.gloqr.constants;

import org.springframework.http.HttpStatus;

import com.gloqr.exception.CustomException;

public class BusinessPostConstants {

	BusinessPostConstants() {
		throw new CustomException("BusinessPostConstants class.can't inititate", HttpStatus.OK);
	}

	public class FileDirectory {
		public static final String FILE_DIR = "sme/{loggedInSmeId}/business-posts";
	}

	public class PostStatus {
		public static final String ACTIVE = "active";
		public static final String DEACTIVE = "deactive";
		public static final boolean TRUE = true;
		public static final boolean FALSE = false;
	}

	/*public class RoleAccess {
		public static final String ADMIN = "hasAnyRole('SME-ADMIN')";
		public static final String ADMIN_AND_USER = "hasAnyRole('USER','SME-ADMIN')";

		public static final String USER_ROLE = "USER";
		public static final String SMEFACE_DBA = "SMEFACE-DBA";
		public static final String SMEFACE_SUPER_ADMIN = "SMEFACE-SUPER-ADMIN";
		public static final String SMEFACE_ADMIN = "SMEFACE-ADMIN";
		public static final String SME_SUPER_ADMIN = "SME-SUPER-ADMIN";
		public static final String SME_ADMIN = "SME-ADMIN";
	}*/
}
