package com.gloqr.dao;

import com.gloqr.entity.Tag;

public interface TagDao {

	void saveTag(Tag tag);

	Tag getTag(String tagId);

	void deleteTag(Tag tag);

}
