package com.gloqr.service;

import java.util.List;
import java.util.Map;

import com.gloqr.entity.BusinessPost;
import com.gloqr.model.SMEBusinessPostForAdminPanel;

public interface GloqrAdminService {

	Map<String,Integer> getSMEPostsCount(List<String> smeIds);

	public List<BusinessPost> getPosts(String smeId);

	void approveOrRejectBusinessPostsState( SMEBusinessPostForAdminPanel posts);

}
