package com.gloqr.service;

public interface CreditCheckService {

}
