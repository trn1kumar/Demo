package com.gloqr.security.context.holder;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.Authentication;

public interface AuthenticationFacade {
	public Authentication getAuthentication();

	public HttpServletRequest getContextHolder();

	public String getJwtToken();
}
