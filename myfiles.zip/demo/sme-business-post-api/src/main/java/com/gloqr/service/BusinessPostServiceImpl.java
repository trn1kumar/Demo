package com.gloqr.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import com.gloqr.constants.BusinessPostState;
import com.gloqr.constants.CreditType;
import com.gloqr.constants.PostType;
import com.gloqr.constants.Privacy;
import com.gloqr.dao.BusinessPostDao;
import com.gloqr.dao.FileDao;
import com.gloqr.dao.TagDao;
import com.gloqr.dto.BusinessConnection;
import com.gloqr.entity.BusinessPost;
import com.gloqr.entity.File;
import com.gloqr.entity.Tag;
import com.gloqr.exception.CustomException;
import com.gloqr.model.PricingRequest;
import com.gloqr.model.PublishData;
import com.gloqr.rest.endpoint.PricingEndpoint;
import com.gloqr.rest.endpoint.SMECircleEndPoint;
import com.gloqr.security.context.holder.UserDetails;

@Service
public class BusinessPostServiceImpl implements BusinessPostService {

	@Autowired
	private TagDao tagDao;

	@Autowired
	private SMECircleEndPoint smeCircleEndPoint;

	@Autowired
	private FileDao fileDao;

	@Autowired
	private FileService fileService;

	@Autowired
	private BusinessPostDao businessPostDao;

	@Autowired
	private PricingEndpoint pricingEndpoint;

	private static final String DEBIT = "DEBIT";
	private static final String CREDIT = "CREDIT";

	Logger log = LogManager.getLogger();

	@Override
	public BusinessPost createPost(BusinessPost businessPost) {

		Set<BusinessConnection> conns = validateBusinessPost(businessPost);

		businessPost.setPostState(BusinessPostState.PENDING);

		List<File> files = businessPost.getFiles();
		if (files != null && !files.isEmpty()) {
			fileDao.saveFiles(files);
		}
		businessPostDao.save(businessPost);

		if (businessPost.getPrivacy().equals(Privacy.CIRCLE)) {
			Set<String> tags = new HashSet<>();
			if (conns != null) {
				conns.parallelStream().forEach(conn -> tags.add(conn.getSmeId()));
			}
			businessPost.setTags(tags);
			businessPostDao.save(businessPost);
			this.tagPost(businessPost.getBusinessPostId(), tags);

		}
		if (businessPost.getPrivacy().equals(Privacy.PRIVATE)) {
			this.tagPost(businessPost.getBusinessPostId(), businessPost.getTags());
		}

		return businessPost;
	}

	@Override
	public BusinessPost updatePost(BusinessPost businessPost) {

		List<File> updatedFiles = null;
		List<File> existFiles = null;

		if (businessPost.getBusinessPostId() != null) {
			BusinessPost existPost = this.getSinglePost(businessPost.getBusinessPostId());

			if (existPost.isActive() || existPost.getPostState().equals(BusinessPostState.APPROVED)) {
				throw new CustomException(
						"Given Business post is in eighter Active mode or Approved State. couldn't update",
						HttpStatus.BAD_REQUEST);
			}

			businessPost.setPostModified(true);
			businessPost.setPostType(existPost.getPostType());
			businessPost.setPrivacy(existPost.getPrivacy());
			businessPost.setPostState(BusinessPostState.PENDING);
			businessPost.setFeedbackMessage(existPost.getFeedbackMessage());
			businessPost.setCreationDate(existPost.getCreationDate());
			businessPost.setTags(existPost.getTags());

			if (businessPost.getFiles() != null && !businessPost.getFiles().isEmpty()) {
				Set<String> fileLocations = businessPost.getFiles().stream().map(File::getFileLocation)
						.collect(Collectors.toSet());
				updatedFiles = fileDao.getFilesByLocations(fileLocations);
			}

			existFiles = existPost.getFiles();
			PricingRequest pricingRequest = this.manageFiles(businessPost, existFiles, updatedFiles);

			if (pricingRequest != null) {
				pricingEndpoint.updateCredits(pricingRequest);
			}
			pricingEndpoint.updateCredits(CreditType.BUSINESS_POST, 1, "Updating Business post", DEBIT);

			businessPostDao.save(businessPost);
			return businessPost;
		} else {
			throw new CustomException("Unable to Update", HttpStatus.BAD_REQUEST);
		}

	}

	private void tagPost(String postId, Set<String> tags) {

		tags.forEach(tagId -> {
			Tag tag = null;
			try {
				tag = tagDao.getTag(tagId);
				tag.getTaggedPosts().add(postId);
			} catch (CustomException e) {
				tag = new Tag(tagId, Arrays.asList(postId));
			}

			tagDao.saveTag(tag);
		});
	}

	@Override
	public BusinessPost getSinglePost(String postId) {
		return businessPostDao.getPostById(postId);
	}

	public List<BusinessPost> getPostsBySMEIdForEditMode(String smeId, boolean fetchPendingOrRejectedPosts) {

		List<BusinessPost> posts = null;

		if (fetchPendingOrRejectedPosts) {
			posts = businessPostDao.getPendingAndRejectedPosts(smeId);
		} else {
			try {
				posts = businessPostDao.getPostsBySMEId(smeId);
			} catch (CustomException e) {
				log.info(e.getErrorMessage());
			}
			posts = addTaggedPosts(posts, smeId);

		}
		return posts;

	}

	@Override
	public List<BusinessPost> getPostsForViewMode(Authentication authentication, String smeUuid) {

		List<BusinessPost> posts = null;

		if (authentication != null && ((UserDetails) authentication.getPrincipal()).getSmeId() != null) {
			String loggedInSmeId = ((UserDetails) authentication.getPrincipal()).getSmeId();
			log.info("{} viewing {}'s Business-Posts", loggedInSmeId, smeUuid);
			try {
				posts = businessPostDao.getApprovedAndActiveTruePosts(smeUuid);
			} catch (CustomException e) {
				log.error("Exception while get {} sme's posts for view mode. Message: {}", smeUuid,
						e.getErrorMessage());
			}

			posts = addTaggedPosts(posts, smeUuid);
			posts = filterPostByPrivacy(posts, loggedInSmeId);

			if (posts != null && !posts.isEmpty()) {
				return posts;

			} else {
				throw new CustomException("No Posts available for sme " + smeUuid, HttpStatus.NOT_FOUND);
			}

		} else {

			log.info(
					"No SME USER Logged-In.Fetch only Approved And Active Posts of SME {} ,which are having Public Privacy for view mode",
					smeUuid);

			posts = businessPostDao.getApprovedAndActiveTruePosts(smeUuid);
			posts = posts.stream().filter(post -> post.getPrivacy().equals(Privacy.PUBLIC))
					.collect(Collectors.toList());
			return posts;
		}

	}

	private List<BusinessPost> addTaggedPosts(List<BusinessPost> posts, String smeUuid) {

		try {
			List<BusinessPost> taggedPosts = this.getTaggedPosts(smeUuid);

			if (posts != null) {
				posts.addAll(taggedPosts);
			} else {
				posts = new ArrayList<>(taggedPosts);
			}

		} catch (CustomException e) {
			log.info(e.getErrorMessage());
		}

		if (posts != null && !posts.isEmpty()) {
			Collections.sort(posts, Collections.reverseOrder());
			return posts;

		} else {
			throw new CustomException("No Posts available for sme " + smeUuid, HttpStatus.NOT_FOUND);
		}
	}

	private List<BusinessPost> getTaggedPosts(String smeUuid) {

		List<BusinessPost> posts = null;

		Tag tag = tagDao.getTag(smeUuid);

		List<String> taggedPostIds = tag.getTaggedPosts();

		if (taggedPostIds != null && !taggedPostIds.isEmpty()) {

			posts = businessPostDao.getApprovedTaggedPostsBySmeId(taggedPostIds, smeUuid);
		}

		return posts;
	}

	private List<BusinessPost> filterPostByPrivacy(List<BusinessPost> posts, String loggedInSmeId) {

		if (posts == null) {
			throw new CustomException("Business posts can not be null.", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return posts
				.parallelStream().filter(post -> post.getPrivacy().equals(Privacy.PUBLIC)
						|| post.getSmeUuid().equals(loggedInSmeId) || post.getTags().contains(loggedInSmeId))
				.collect(Collectors.toList());
	}

	@Override
	public void deleteBusinessPost(final String smeId, final String postId) {

		try {
			BusinessPost post = this.getSinglePost(postId);

			if (!post.getSmeUuid().equals(smeId)) {
				throw new CustomException("Unauthorized Access.Post Deletion Failed", HttpStatus.UNAUTHORIZED);
			}

			List<File> files = post.getFiles();
			if (files != null && !files.isEmpty()) {
				/*
				 * deactive business-posts files
				 */
				fileDao.deactiveFiles(files);
			}

			if (!post.getPrivacy().equals(Privacy.PUBLIC)) {

				// delete tags for that post
				Set<String> tags = post.getTags();
				if (tags != null && !tags.isEmpty()) {
					tags.forEach(tagId -> {
						Tag tag = tagDao.getTag(tagId);
						tag.getTaggedPosts().remove(postId);
						if (tag.getTaggedPosts().isEmpty())
							tagDao.deleteTag(tag);
						else
							tagDao.saveTag(tag);
					});
				}
			}

			/*
			 * delete post
			 */
			businessPostDao.delete(post);

		} catch (CustomException e) {
			throw e;
		}

	}

	@Override
	public void updateStatus(List<PublishData> publish) {
		businessPostDao.updatePostsStatus(publish);
	}

	@Override
	public void saveMultiplePosts(List<BusinessPost> posts) {
		businessPostDao.savePosts(posts);

	}

	private long getFilesTotalSize(List<File> files) {
		return files.stream().mapToLong(File::getSize).sum();
	}

	private PricingRequest manageFiles(BusinessPost businessPost, List<File> existFiles, List<File> updatedFiles) {

		PricingRequest pricingRequest = null;
		if (updatedFiles != null && !updatedFiles.isEmpty()) {

			if (existFiles != null && !existFiles.isEmpty()) {
				pricingRequest = this.manageNewAndDeletedImagesAndImageCredits(existFiles, updatedFiles);
				deactiveFiles(businessPost.getPublishFeedId(), businessPost.getPostType(), existFiles);
			} else {

				long newFilesSize = getFilesTotalSize(updatedFiles);
				pricingRequest = new PricingRequest(CreditType.IMAGE_STORAGE, newFilesSize, DEBIT);

			}
			businessPost.setFiles(updatedFiles);

		} else {

			if (existFiles != null && !existFiles.isEmpty()) {
				deactiveFiles(businessPost.getPublishFeedId(), businessPost.getPostType(), existFiles);
				long deletedFilesSize = getFilesTotalSize(existFiles);
				pricingRequest = new PricingRequest(CreditType.IMAGE_STORAGE, deletedFilesSize, CREDIT);
			}
		}

		return pricingRequest;
	}

	private PricingRequest manageNewAndDeletedImagesAndImageCredits(List<File> existFiles, List<File> updatedFiles) {

		int newFilesSize = 0;
		int newFilesCount = 0;
		for (File updateFile : updatedFiles) {
			boolean bool = true;
			Iterator<File> iterator = existFiles.iterator();
			while (iterator.hasNext()) {
				File file = iterator.next();
				if (file.getFileId().equals(updateFile.getFileId())) {
					updateFile.setFileId(file.getFileId());
					updateFile.setActive(file.isActive());
					iterator.remove();
					bool = false;
					break;
				}
			}
			if (bool) {
				updateFile.setActive(true);
				++newFilesCount;
				newFilesSize += updateFile.getSize();
			}

		}

		long deletedFilesSize = getFilesTotalSize(existFiles);

		return getPricingRequestObj(newFilesCount, existFiles.size(), deletedFilesSize, newFilesSize);

	}

	private PricingRequest getPricingRequestObj(int newFilesCount, int deletedFilesCount, long deletedFilesSize,
			long newFilesSize) {

		PricingRequest pricingRequest = null;
		String action = null;

		long finalImageStorageSize = deletedFilesSize - newFilesSize;

		if (finalImageStorageSize > 0) {
			action = CREDIT;
			pricingRequest = new PricingRequest(CreditType.IMAGE_STORAGE, finalImageStorageSize, action);
		} else if (finalImageStorageSize < 0) {
			finalImageStorageSize = Math.abs(finalImageStorageSize);
			action = DEBIT;
			if (pricingEndpoint.checkCredits(CreditType.IMAGE_STORAGE) < finalImageStorageSize) {
				pricingEndpoint.noCreditsLeftException(CreditType.IMAGE_STORAGE);
			}
			pricingRequest = new PricingRequest(CreditType.IMAGE_STORAGE, finalImageStorageSize, action);
		}

		log.info(
				"new files: [total {}. size: {} ] and deleted files: [total {}. size: {} ]. final files size: {} and action: {}",
				newFilesCount, newFilesSize, deletedFilesCount, deletedFilesSize, finalImageStorageSize, action);
		return pricingRequest;
	}

	private Set<BusinessConnection> validateBusinessPost(BusinessPost businessPost) {
		Set<BusinessConnection> conns = null;
		if (businessPost.getPrivacy().equals(Privacy.CIRCLE)) {
			log.info("Business Post Privacy is 'CIRCLE'");

			conns = smeCircleEndPoint.getBusinessConnection(businessPost.getSmeUuid());
			if (!(conns != null && !conns.isEmpty())) {
				throw new CustomException(
						"Business-Post Privacy is 'CIRCLE' ,No Connections Found for SME " + businessPost.getSmeUuid(),
						HttpStatus.BAD_REQUEST);
			}

		} else if (businessPost.getPrivacy().equals(Privacy.PRIVATE)
				&& !(businessPost.getTags() != null && !businessPost.getTags().isEmpty())) {
			log.info("Business Post Privacy is 'PRIVATE'");
			throw new CustomException("Business-Post Privacy is 'PRIVATE' ,So PostTags can't be empty",
					HttpStatus.BAD_REQUEST);
		} else if (businessPost.getPrivacy().equals(Privacy.PUBLIC)) {
			log.info("Business Post Privacy is 'PUBLIC'");
		}

		return conns;
	}

	private void deactiveFiles(String publishFeedId, PostType postType, List<File> deletedFiles) {

		if (!postType.equals(PostType.DEFAULT) || publishFeedId != null) {
			fileDao.deleteFiles(deletedFiles);
			fileService.updateBusinessPostImages(postType, deletedFiles);
		} else {
			fileDao.deactiveFiles(deletedFiles);
		}

	}

}
