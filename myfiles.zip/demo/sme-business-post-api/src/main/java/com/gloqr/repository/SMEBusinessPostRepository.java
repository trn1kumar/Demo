package com.gloqr.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.gloqr.constants.BusinessPostState;
import com.gloqr.entity.BusinessPost;

public interface SMEBusinessPostRepository extends MongoRepository<BusinessPost, String>, CustomRepository {

	List<BusinessPost> findBySmeUuid(String smeId);

	int countBySmeUuid(String smeId);

	boolean existsByBusinessPostId(String postId);

	List<BusinessPost> findBySmeUuidAndPostStateAndActiveTrue(String smeId, BusinessPostState state);

	List<BusinessPost> findBySmeUuidAndPostStateNotIn(String smeId, BusinessPostState state);

	List<BusinessPost> findAllByBusinessPostId(Set<String> taggedPostIds);

	int countBySmeUuidAndPostStateAndActive(String smeid, BusinessPostState pending, boolean b);

	List<BusinessPost> findByBusinessPostIdInAndPostStateAndActive(List<String> taggedPostIds,
			BusinessPostState state, boolean active);

}