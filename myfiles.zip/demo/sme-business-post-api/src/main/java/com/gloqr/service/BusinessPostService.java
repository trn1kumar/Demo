package com.gloqr.service;

import java.util.List;

import org.springframework.security.core.Authentication;

import com.gloqr.entity.BusinessPost;
import com.gloqr.model.PublishData;

public interface BusinessPostService {

	BusinessPost createPost(BusinessPost businessPost);

	public List<BusinessPost> getPostsForViewMode(Authentication authentication, String smeUuid1);

	public List<BusinessPost> getPostsBySMEIdForEditMode(String smeId, boolean fetchPendingOrRejectedPosts);

	BusinessPost updatePost(BusinessPost businessPost);

	void deleteBusinessPost(final String smeId,final String postId);

	BusinessPost getSinglePost(String businessPostId);
	
	void updateStatus(List<PublishData> publish);

	void saveMultiplePosts(List<BusinessPost> saveForBatchUpdate);
}
