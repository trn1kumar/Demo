package com.gloqr.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.gloqr.configuration.PropertyValues;
import com.gloqr.dto.SMEDto;
import com.gloqr.entity.BusinessPost;
import com.gloqr.exception.CustomException;
import com.gloqr.model.notification.EmailEvent;
import com.gloqr.model.notification.SchedulerJobInfo;
import com.gloqr.model.notification.SmsEvent;
import com.gloqr.rest.endpoint.NotificationEndPoint;
import com.gloqr.util.UuidUtil;

@Service
public class NotificationServiceImpl implements NotificationService {

	private Logger log = LogManager.getLogger();

	@Autowired
	private SMEService smeService;

	@Autowired
	private NotificationEndPoint notificationEndpoint;

	@Autowired
	private TemplateEngine templateEngine;

	@Autowired
	private PropertyValues propertyValues;

	private void scheduleNewJob(String jobName, SmsEvent smsEvent, EmailEvent emailEvent) {
		SchedulerJobInfo schedulerJobInfo = new SchedulerJobInfo();
		schedulerJobInfo.setJobName(jobName);
		schedulerJobInfo.setSchedulerGroup(propertyValues.getSchedulerGroupName());
		schedulerJobInfo.setSmsEvent(smsEvent);
		schedulerJobInfo.setEmailEvent(emailEvent);

		notificationEndpoint.scheduleJob(schedulerJobInfo);
	}

	@Override
	@Async("taskExecutor")
	public void unscheduleJob(String jobName) {
		try {
			notificationEndpoint.unscheduleJob(jobName);
		} catch (Exception e) {
			log.error("can't unscheduleJob ." + jobName, e);
		}
	}

	@Override
	@Async("taskExecutor")
	public void schedulePostsStateChangedSummaryNotifi(String smeId, List<BusinessPost> saveForBatchUpdate,
			long rejectedPostsCount) {
		try {
			SMEDto smeDto = smeService.getSME(smeId);
			String emailId = smeDto.getContactEmail();
			if (emailId != null) {
				Context context = new Context();
				context.setVariable("smeName", smeDto.getSmeName());
				context.setVariable("refundedCredits", rejectedPostsCount);
				String mailPage = templateEngine.process("postVerifications.html", context);
				String mailSub = propertyValues.getVerifyPostsEmailSub();
				EmailEvent emailEvent = new EmailEvent(emailId, mailSub, mailPage);
				scheduleNewJob(PropertyValues.VERIFY_POSTS_JOB_NAME_PREFIX + UuidUtil.getUuid(), null, emailEvent);
			} else {
				throw new CustomException("email id can't be null for schedule notification.",
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error("can't schedule new job notification. Exception:- {}", e.getMessage());
		}
	}

}
