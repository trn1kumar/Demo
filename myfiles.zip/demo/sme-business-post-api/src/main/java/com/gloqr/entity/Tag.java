package com.gloqr.entity;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "tags")
public class Tag {

	@Id
	private String smeId;

	List<String> taggedPosts;

	public Tag() {
		super();
	}

	public Tag(String smeId) {
		super();
		this.smeId = smeId;
	}

	public Tag(String smeId, List<String> taggedPosts) {
		super();
		this.smeId = smeId;
		this.taggedPosts = taggedPosts;
	}

	public String getSmeId() {
		return smeId;
	}

	public void setSmeId(String smeId) {
		this.smeId = smeId;
	}

	public List<String> getTaggedPosts() {
		return taggedPosts;
	}

	public void setTaggedPosts(List<String> taggedPosts) {
		this.taggedPosts = taggedPosts;
	}

}
