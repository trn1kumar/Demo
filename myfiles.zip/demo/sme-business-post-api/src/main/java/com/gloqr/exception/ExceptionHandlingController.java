package com.gloqr.exception;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.gloqr.model.http.response.CustomErrorResponse;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.util.ValidationUtil;

@ControllerAdvice
@SuppressWarnings("rawtypes")
public class ExceptionHandlingController {

	@Autowired
	private ResponseMaker responseMaker;


	@ExceptionHandler(CustomException.class)
	public ResponseEntity<CustomHttpResponse> throwCustomException(CustomException ex) {
		return responseMaker.errorResponse(ex.getErrorMessage(), ex.getHttpStatus());
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<CustomHttpResponse> throwException(Exception ex) {
		return responseMaker.errorResponse(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(NoCreditException.class)
	public ResponseEntity<CustomHttpResponse<Object>> noCreditExceptionHandler(NoCreditException e) {
		String msg = "No credits left for " + e.geCreditType();

		CustomHttpResponse<Object> obj = new CustomHttpResponse<>(true, HttpStatus.PAYMENT_REQUIRED.value(),
				HttpStatus.PAYMENT_REQUIRED, msg);

		obj.setErrorResponse(new CustomErrorResponse(e.geCreditType().getCode(), msg, e.geCreditType().getValue()));

		return new ResponseEntity<>(obj, HttpStatus.OK);
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ExceptionResponse> invalidInput(MethodArgumentNotValidException ex) {
		BindingResult result = ex.getBindingResult();
		ValidationErrors response = new ValidationErrors();
		response.setErrorCode(HttpStatus.BAD_REQUEST.value());
		response.setErrorMessage("Invalid Inputs.");
		response.setErrors(ValidationUtil.fromBindingErrors(result));

		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(CustomValidation.class)
	public ResponseEntity<ExceptionResponse> invalidInput(CustomValidation ex) {
		ValidationErrors validationError = ex.getValidationError();
		validationError.setErrorCode(HttpStatus.BAD_REQUEST.value());
		validationError.setErrorMessage("Invalid inputs.");
		return new ResponseEntity<>(validationError, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(NullPointerException.class)
	public ResponseEntity<CustomHttpResponse> nullPointerException(NullPointerException ex) {
		return responseMaker.errorResponse(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
