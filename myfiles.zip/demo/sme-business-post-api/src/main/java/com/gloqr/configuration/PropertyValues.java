package com.gloqr.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PropertyValues {

	public static final String VERIFY_POSTS_JOB_NAME_PREFIX = "verifyBusinessPost_";

	@Value(PropertyNames.SCHEDULER_GROUP_NAME)
	private String schedulerGroupName;

	@Value(PropertyNames.VERIFY_POSTS_EMAIL_SUB)
	private String verifyPostsEmailSub;

	public String getSchedulerGroupName() {
		return schedulerGroupName;
	}

	public void setSchedulerGroupName(String schedulerGroupName) {
		this.schedulerGroupName = schedulerGroupName;
	}

	public String getVerifyPostsEmailSub() {
		return verifyPostsEmailSub;
	}

	public void setVerifyPostsEmailSub(String verifyPostsEmailSub) {
		this.verifyPostsEmailSub = verifyPostsEmailSub;
	}

	public static final class PropertyNames {

		private PropertyNames() {
			throw new IllegalStateException("PropertyNames class.can't initiate");
		}

		public static final String SCHEDULER_GROUP_NAME = "${scheduler.group-name}";
		public static final String VERIFY_POSTS_EMAIL_SUB = "${notify.verify-business-post.email-subject}";
	}

}
