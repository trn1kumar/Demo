package com.gloqr.constants;

public enum BusinessPostState {
	PENDING, APPROVED, REJECTED
}
