package com.gloqr.aop;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.gloqr.constants.CreditType;
import com.gloqr.constants.PostStatus;
import com.gloqr.exception.NoCreditException;
import com.gloqr.model.PricingRequest;
import com.gloqr.model.PublishData;
import com.gloqr.rest.endpoint.PricingEndpoint;

@Aspect
@Configuration
@SuppressWarnings("unchecked")
public class PublishCheckAndUpdateImpl {

	@Autowired
	private PricingEndpoint pricingEnpoint;

	@Before("@annotation(com.gloqr.aop.PublishCheckAndUpdate)")
	public void beforeMethodExecution(JoinPoint joinPoint) {

		Object[] objs = joinPoint.getArgs();
		List<PublishData> datas = (ArrayList<PublishData>) objs[0];

		Optional<PublishData> dataOpt = datas.stream().findFirst();
		if (dataOpt.isPresent() && dataOpt.get().getSmeAction().equals(PostStatus.ACTIVE)
				&& pricingEnpoint.checkCredits(CreditType.BUSINESS_POST) < datas.size()) {
			throw new NoCreditException(CreditType.BUSINESS_POST);
		}

	}

	@AfterReturning("@annotation(com.gloqr.aop.PublishCheckAndUpdate)")
	public void updateCredits(JoinPoint joinPoint) {

		Object[] objs = joinPoint.getArgs();
		List<PublishData> datas = (ArrayList<PublishData>) objs[0];
		PricingRequest pricingRequest = new PricingRequest();

		pricingRequest.setCreditType(CreditType.BUSINESS_POST);
		pricingRequest.setCredits(datas.size());

		Optional<PublishData> dataOpt = datas.stream().findFirst();
		if (dataOpt.isPresent() && dataOpt.get().getSmeAction().equals(PostStatus.ACTIVE)) {
			pricingRequest.setAction("DEBIT");
			pricingRequest.setUsedFor("Activating Business post");
			pricingEnpoint.updateCredits(pricingRequest);
		}

	}

}
