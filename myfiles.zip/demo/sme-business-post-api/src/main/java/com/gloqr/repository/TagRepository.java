package com.gloqr.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.gloqr.entity.Tag;

public interface TagRepository extends MongoRepository<Tag, String> {

}
