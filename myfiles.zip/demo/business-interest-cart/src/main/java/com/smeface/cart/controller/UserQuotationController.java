package com.smeface.cart.controller;

import java.io.IOException;

import org.glassfish.jersey.media.multipart.FormDataParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.google.gson.Gson;
import com.smeface.cart.constant.APIList;
import com.smeface.cart.constant.BusinessInterestStatus;
import com.smeface.cart.entity.CartItem;
import com.smeface.cart.entity.QuotationFile;
import com.smeface.cart.exception.CustomException;
import com.smeface.cart.status.entity.ThirdStage;
import com.smeface.cart.util.HttpRequestParser;
import com.smeface.cart.util.SendFilesToContentServer;
import com.smeface.servcie.UserQuotationService;

@RestController
@RequestMapping(APIList.USER_BASE_URL)
public class UserQuotationController {

	@Autowired
	private UserQuotationService userQuotationService;

	@Autowired
	private SendFilesToContentServer sendfiles;
	
	@Autowired
	private HttpRequestParser requestParser;

	@PostMapping(value = APIList.userActionAPI.REVISE)
	public ResponseEntity<?> revise(MultipartHttpServletRequest requestBody,
			@FormDataParam("files") MultipartFile files, Authentication authentication)
			throws  IOException {

		QuotationFile quotationFile = null;
		CartItem cartItem = null;
		try {
			Gson g = new Gson();
			cartItem = g.fromJson(requestBody.getParameter("sent"), CartItem.class);
		} catch (Exception e) {
			throw new CustomException("Failed to parse json data", HttpStatus.BAD_REQUEST);
		}
		try {
			if (files != null) {
				quotationFile = sendfiles.sendFileToContentServer(files,
						BusinessInterestStatus.QUOTATION.replace("{sUuid}", requestParser.getUserUUID()));

			}
			userQuotationService.revise(cartItem, quotationFile);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}
	}

	@PostMapping(value = APIList.userActionAPI.REJECT)
	public ResponseEntity<?> reject(@RequestBody CartItem cartItem) {
		try {
			userQuotationService.reject(cartItem);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}
	}

	@PostMapping(value = APIList.userActionAPI.ACCEPT)
	public ResponseEntity<?> accept(MultipartHttpServletRequest requestBody,
			@FormDataParam("files") MultipartFile files, Authentication authentication)
			throws  IOException {

		QuotationFile quotationFile = null;
		CartItem cartItem = null;
		try {
			Gson g = new Gson();
			cartItem = g.fromJson(requestBody.getParameter("sent"), CartItem.class);
		} catch (Exception e) {
			throw new CustomException("Failed to parse json data", HttpStatus.BAD_REQUEST);
		}
		try {
			if (files != null) {
				quotationFile = sendfiles.sendFileToContentServer(files,
						BusinessInterestStatus.QUOTATION.replace("{sUuid}", requestParser.getUserUUID()));

			}
			ThirdStage thirdStage = userQuotationService.accept(cartItem, quotationFile);
			return new ResponseEntity<>(thirdStage,HttpStatus.OK);
		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}
	}

}
