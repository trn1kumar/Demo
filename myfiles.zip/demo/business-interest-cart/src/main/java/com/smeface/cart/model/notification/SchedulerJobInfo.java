package com.smeface.cart.model.notification;

public class SchedulerJobInfo {

	private String jobName;

	private String schedulerGroup;

	private EmailEvent emailEvent;

	private SmsEvent smsEvent;

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public EmailEvent getEmailEvent() {
		return emailEvent;
	}

	public void setEmailEvent(EmailEvent emailEvent) {
		this.emailEvent = emailEvent;
	}

	public SmsEvent getSmsEvent() {
		return smsEvent;
	}

	public void setSmsEvent(SmsEvent smsEvent) {
		this.smsEvent = smsEvent;
	}

	public String getSchedulerGroup() {
		return schedulerGroup;
	}

	public void setSchedulerGroup(String schedulerGroup) {
		this.schedulerGroup = schedulerGroup;
	}

}
