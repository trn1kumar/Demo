package com.smeface.cart.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "CART")
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler","id"})
public class Cart implements Serializable {

	private static final long serialVersionUID = -2954548630436559446L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(name = "CART_UUID", unique = true)
	private String uuid;
	
	@Column(name = "USER_UUID", unique = true)
	@NotBlank(message="User UID cannot be left blank")
	private String userUuid;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "cartId", nullable = false)
	@JsonIgnoreProperties
	@Valid
	private List<CartItem> cartItem;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "cartId", nullable = false)
	@JsonIgnoreProperties
	private List<RecievdBusinessInterest> recievdBusinessInterests;

	@Column(name = "ACTIVE_STATUS")
	private Boolean isActive;

	@Transient
	private Integer sentCount;

	@Transient
	private Integer receiveCount;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<RecievdBusinessInterest> getRecievdBusinessInterests() {
		return recievdBusinessInterests;
	}

	public void setRecievdBusinessInterests(List<RecievdBusinessInterest> recievdBusinessInterests) {
		this.recievdBusinessInterests = recievdBusinessInterests;
	}

	public List<CartItem> getCartItem() {
		return cartItem;
	}

	public void setCartItem(List<CartItem> cartItem) {
		this.cartItem = cartItem;
	}

	public Integer getSentCount() {
		return sentCount;
	}

	public void setSentCount(Integer sentCount) {
		this.sentCount = sentCount;
	}

	public Integer getReceiveCount() {
		return receiveCount;
	}

	public void setReceiveCount(Integer receiveCount) {
		this.receiveCount = receiveCount;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getUserUuid() {
		return userUuid;
	}

	public void setUserUuid(String userUuid) {
		this.userUuid = userUuid;
	}

	
}
