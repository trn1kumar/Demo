package com.smeface.cart.dto;

import java.util.List;
import java.util.Map;

import com.smeface.cart.constant.QuotationFormat;

public class CommonField{

	private String sUuid;
	private String smeName;
	private String mainImage;
	private String priceUnit;
	private Double price;
	private Double discountedPrice;
	private int discount;
	private boolean active;
	private QuotationFormat quotationFormat;
	private String termsAndCondition;
	private float gst;
	private String description;
	private String location;
	private Map<String, String> specifications;
	private List<ImageDto> images;

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public String getSmeName() {
		return smeName;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public String getMainImage() {
		return mainImage;
	}

	public void setMainImage(String mainImage) {
		this.mainImage = mainImage;
	}

	public String getPriceUnit() {
		return priceUnit;
	}

	public void setPriceUnit(String priceUnit) {
		this.priceUnit = priceUnit;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Double getDiscountedPrice() {
		return discountedPrice;
	}

	public void setDiscountedPrice(Double discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

	public int getDiscount() {
		return discount;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public QuotationFormat getQuotationFormat() {
		return quotationFormat;
	}

	public void setQuotationFormat(QuotationFormat quotationFormat) {
		this.quotationFormat = quotationFormat;
	}

	public String getTermsAndCondition() {
		return termsAndCondition;
	}

	public void setTermsAndCondition(String termsAndCondition) {
		this.termsAndCondition = termsAndCondition;
	}

	public float getGst() {
		return gst;
	}

	public void setGst(float gst) {
		this.gst = gst;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Map<String, String> getSpecifications() {
		return specifications;
	}

	public void setSpecifications(Map<String, String> specifications) {
		this.specifications = specifications;
	}

	public List<ImageDto> getImages() {
		return images;
	}

	public void setImages(List<ImageDto> images) {
		this.images = images;
	}

}
