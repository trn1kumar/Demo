package com.smeface.cart.service;

import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.smeface.cart.aspectlogger.CentralLoggingHandler;
import com.smeface.cart.constant.CartConstants;
import com.smeface.cart.constant.CreditType;
import com.smeface.cart.dao.CartDaoImpl;
import com.smeface.cart.dto.BiAttributeMapper;
import com.smeface.cart.dto.PricingRequestDTO;
import com.smeface.cart.dto.ProductDTO;
import com.smeface.cart.dto.QuotationPDF;
import com.smeface.cart.dto.SMEInformationDto;
import com.smeface.cart.dto.SMEServiceDTO;
import com.smeface.cart.dto.UserDto;
import com.smeface.cart.entity.Cart;
import com.smeface.cart.entity.CartItem;
import com.smeface.cart.entity.QuotationFormat;
import com.smeface.cart.entity.RecievdBusinessInterest;
import com.smeface.cart.exception.CustomException;
import com.smeface.cart.mapper.NameConverter;
import com.smeface.cart.model.RecieveBusinessInterestModel;
import com.smeface.cart.repository.CartItemRepo;
import com.smeface.cart.repository.CartRepo;
import com.smeface.cart.repository.RecieveBusinessInterestRepo;
import com.smeface.cart.rest.PricingEndpoint;
import com.smeface.cart.rest.ProductRestEndPoint;
import com.smeface.cart.rest.ServiceRestEndPoint;
import com.smeface.cart.rest.SmeServerEndpoint;
import com.smeface.cart.rest.UserServerEndpoint;
import com.smeface.cart.status.entity.FinalStage;
import com.smeface.cart.status.entity.FirstStage;
import com.smeface.cart.status.entity.OrderStatus;
import com.smeface.cart.status.entity.SecondStage;
import com.smeface.cart.status.entity.ThirdStage;
import com.smeface.cart.util.ConvertNumberIntoWord;
import com.smeface.cart.util.HttpRequestParser;
import com.smeface.cart.util.UniqueId;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Service
@Transactional
public class CartItemServiceImpl implements CartItemService {

	@Autowired
	private CartItemRepo cartItemRepo;

	@Autowired
	private CartDaoImpl cartDao;

	@Autowired
	private CartRepo cartRepo;

	@Autowired
	private RecieveBusinessInterestRepo recieveBusinessInterestRepo;

	@Autowired
	private ProductRestEndPoint productRestEndPoint;

	@Autowired
	private ServiceRestEndPoint serviceRestEndPoint;

	@Autowired
	private UserServerEndpoint userServerEndpoint;

	@Autowired
	private SmeServerEndpoint smeServerEndpoint;

	@Autowired
	private PricingEndpoint pricingEndpoint;

	@Autowired
	private ConvertNumberIntoWord intoWord;

	@Autowired
	private RecieveBusinessInterestModel recieveBusinessInterestModel;

	@Value("${cart.perpage}")
	private Integer limit;

	@Value("${quotation.file.path}")
	private String quotationPath;

	@Value("${quotation.format.path}")
	private String quotationFormatPath;

	@Autowired
	private NameConverter nameConverter;

	@Autowired
	private HttpRequestParser requestParser;

	// private static final String OUTPUT_DIR = "/home/";

	private static final Logger LOGGER = LogManager.getLogger(CentralLoggingHandler.class);

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public synchronized void cart(Cart cartRequest, String smeId) {

		try {

			cartRequest.setIsActive(true);
			Cart oldCart = cartRepo.findByUserUuid(cartRequest.getUserUuid());
			cartRequest.getCartItem().stream().forEach(a -> {
				if (cartRequest.getCartItem().stream().findAny().get().getProvider()
						.equals(CartConstants.BusinessInterest.PRODUCT)) {
					a.setCartAttribute(getBusinessInterestDetails(a.getBusinessInterestUUID(), ProductDTO.class,
							a.getBusinessInterestQuantity(), smeId));
				} else {
					a.setCartAttribute(getBusinessInterestDetails(a.getBusinessInterestUUID(), SMEServiceDTO.class,
							a.getBusinessInterestQuantity(), smeId));
				}
			});
			if (oldCart == null) {

				cartRequest.getCartItem().parallelStream().forEach(u -> {

					u.setOrderStatus(new OrderStatus.CartOrderStageBuilder()
							.currentStatus(CartConstants.UserStages.SENT).build());
					u.setIsActive(CartConstants.Flag.TRUE);
					u.setUserUUId(cartRequest.getUserUuid());
					u.setUuid(UniqueId.getUUID());

				});
				cartRequest.setUuid(UniqueId.getUUIDs());
				cartDao.save(cartRequest);

				recievedBusinessInterest(cartRequest);
				/*
				 * productRestEndPoint.updateBiCountOfProduct(
				 * cartRequest.getCartItem().stream().findAny().get().getBusinessInterestUUID())
				 * ;
				 */

			} else {

				List<CartItem> cartItems = oldCart.getCartItem();
				if (cartItems != null) {

					cartItems.forEach(a -> {
						if (a.getBusinessInterestUUID()
								.equals(cartRequest.getCartItem().stream().findAny().get().getBusinessInterestUUID())
								&& a.getIsActive() == CartConstants.Flag.TRUE
								&& a.isRejectStatus() == CartConstants.Flag.FALSE) {
							throw new CustomException("User have already generated interest on this product",
									HttpStatus.ALREADY_REPORTED);
						}
					});

					oldCart.setCartItem(cartRequest.getCartItem());
					oldCart.getCartItem().parallelStream().forEach(u -> {
						u.setOrderStatus(new OrderStatus.CartOrderStageBuilder()
								.currentStatus(CartConstants.UserStages.SENT).build());
						u.setIsActive(CartConstants.Flag.TRUE);
						u.setUserUUId(cartRequest.getUserUuid());
						u.setUuid(UniqueId.getUUID());

					});

					cartDao.save(oldCart);
					recievedBusinessInterest(cartRequest);

				}
			}
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());

		}

	}

	private BiAttributeMapper getBusinessInterestDetails(String uid, Class<?> obj, Integer businessInterestQuantity,
			String smeId) {
		if (obj.equals(ProductDTO.class)) {
			ProductDTO productDTO = productRestEndPoint.getProduct(uid, false, null);
			if (productDTO.getsUuid().equals(smeId)) {
				throw new CustomException("SME can't create Business Interest on it own product/service",
						HttpStatus.NOT_ACCEPTABLE);
			}
			return nameConverter.converter(productDTO, businessInterestQuantity);
		}
		if (obj.equals(SMEServiceDTO.class)) {
			SMEServiceDTO smeServiceDTO = serviceRestEndPoint.getService(uid, false, null);
			if (smeServiceDTO.getsUuid().equals(smeId)) {
				throw new CustomException("SME can't create Business Interest on it own product/service",
						HttpStatus.NOT_ACCEPTABLE);
			}
			return nameConverter.converter(smeServiceDTO, businessInterestQuantity);
		}
		return null;

	}

	private BiAttributeMapper getBusinessInterestDetails(String uid, Class<?> obj, Integer businessInterestQuantity) {

		if (obj.equals(ProductDTO.class)) {
			ProductDTO productDTO = productRestEndPoint.getProduct(uid, true, requestParser.getHeader());
			return nameConverter.converter(productDTO, businessInterestQuantity);
		}
		if (obj.equals(SMEServiceDTO.class)) {
			SMEServiceDTO smeServiceDTO = serviceRestEndPoint.getService(uid, true, requestParser.getHeader());
			return nameConverter.converter(smeServiceDTO, businessInterestQuantity);
		}
		return null;

	}

	@Async
	@Override
	public void biCountUpdate(Cart cart, String token) {
		cart.getCartItem().stream().forEach(a -> {
			if (cart.getCartItem().stream().findAny().get().getProvider()
					.equals(CartConstants.BusinessInterest.PRODUCT)) {
				productRestEndPoint.updateBiCountOfProduct(a.getBusinessInterestUUID(), token);
			} else {
				serviceRestEndPoint.updateBiCountOfProduct(a.getBusinessInterestUUID(), token);
			}
		});
	}

	@Override
	public void removeCartItem(String uuid) {

		try {
			CartItem cartItem = cartItemRepo.findByUuidAndRejectStatus(uuid, CartConstants.Flag.FALSE);
			RecievdBusinessInterest recievdBusinessInterest = recieveBusinessInterestRepo
					.findByBusinessInterestUUIDAndUserUUIDAndIsActive(cartItem.getBusinessInterestUUID(),
							cartItem.getUserUUId(), CartConstants.Flag.TRUE);
			if (recievdBusinessInterest != null) {
				recievdBusinessInterest.setIsActive(CartConstants.Flag.FALSE);
			}

			cartItem.setIsActive(CartConstants.Flag.FALSE);

			cartItemRepo.saveAndFlush(cartItem);
			recieveBusinessInterestRepo.saveAndFlush(recievdBusinessInterest);

		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}
	}

	@Override
	public synchronized CartItem updateBusinessInterest(CartItem cartItem) {
		try {
			CartItem cartItem2 = cartItemRepo.findBySmeCartId(cartItem.getSmeCartId());
			if (cartItem2 != null) {
				if (cartItem2.getIsActive() == CartConstants.Flag.TRUE) {
					cartItem2.setBusinessInterestQuantity(cartItem.getBusinessInterestQuantity());
					cartItemRepo.saveAndFlush(cartItem2);
					return cartItem;
				} else {
					throw new CustomException("Product has been removed by provider", HttpStatus.NO_CONTENT);
				}

			} else {
				throw new CustomException("Product not found", HttpStatus.NOT_FOUND);
			}
		} catch (CustomException e) {

			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

	}

	private void recievedBusinessInterest(Cart cartRequest) {

		SMEInformationDto smeInformationDto = getSmeDetails(cartRequest);
		Cart oldCart = cartRepo.findByUserUuid(smeInformationDto.getUuid());

		if (oldCart != null) {

			List<RecievdBusinessInterest> oldRecievdBusinessInterest = oldCart.getRecievdBusinessInterests();
			oldRecievdBusinessInterest.add(recieveBusinessInterestModel.setValues(cartRequest));
			oldCart.setIsActive(cartRequest.getIsActive());
			oldCart.setUserUuid(smeInformationDto.getUuid());
			oldRecievdBusinessInterest.stream().forEach(r -> r.setSmeUserID(smeInformationDto.getUuid()));
			oldCart.setRecievdBusinessInterests(oldRecievdBusinessInterest);
			cartDao.save(oldCart);

		} else {
			Cart cart = new Cart();
			List<RecievdBusinessInterest> listRecieveBusinessInterest = new ArrayList<>();
			listRecieveBusinessInterest.add(recieveBusinessInterestModel.setValues(cartRequest));
			cart.setIsActive(cartRequest.getIsActive());
			cart.setUserUuid(smeInformationDto.getUuid());
			listRecieveBusinessInterest.stream().forEach(r -> r.setSmeUserID(smeInformationDto.getUuid()));
			cart.setUuid(UniqueId.getUUIDs());
			cart.setRecievdBusinessInterests(listRecieveBusinessInterest);
			cartDao.save(cart);
		}

	}

	@Override
	public int totalCountOfUserCart(String userUUID) {
		try {
			int sentCount = cartDao.getSentCount(userUUID);
			int recieveCount = cartDao.getRecievedCount(userUUID);
			return sentCount + recieveCount;
		} catch (Exception e) {
			LOGGER.info(e);
			throw e;
		}

	}

	private SMEInformationDto getSmeDetails(Cart cartRequest) {
		try {

			SMEInformationDto smeInformationDto = null;
			if (cartRequest.getCartItem().stream().findAny().isPresent()) {

				for (CartItem cartItem : cartRequest.getCartItem()) {
					if (cartItem.getProvider().equalsIgnoreCase(CartConstants.BusinessInterest.PRODUCT)) {
						ProductDTO product = productRestEndPoint.getProduct(cartItem.getBusinessInterestUUID(), false,
								null);
						smeInformationDto = smeServerEndpoint.getSme(product.getsUuid());
					} else {
						SMEServiceDTO smeServiceDTO = serviceRestEndPoint.getService(cartItem.getBusinessInterestUUID(),
								false, null);
						smeInformationDto = smeServerEndpoint.getSme(smeServiceDTO.getsUuid());
					}
				}

			}
			if (smeInformationDto != null) {
				return smeInformationDto;
			} else {
				throw new CustomException("Error while fecthing sme information", HttpStatus.INTERNAL_SERVER_ERROR);
			}

			/*
			 * if (cartRequest.getCartItem().stream().findAny().get().getProvider()
			 * .equalsIgnoreCase(CartConstants.BusinessInterest.PRODUCT)) { product =
			 * productRestEndPoint
			 * .getProduct(cartRequest.getCartItem().stream().findAny().get().
			 * getBusinessInterestUUID()); smeInformationDto =
			 * smeServerEndpoint.getSme(product.getsUuid()); } else { smeServiceDTO =
			 * serviceRestEndPoint
			 * .getService(cartRequest.getCartItem().stream().findAny().get().
			 * getBusinessInterestUUID()); smeInformationDto =
			 * smeServerEndpoint.getSme(smeServiceDTO.getsUuid()); }
			 */

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		} catch (Exception err) {
			throw new CustomException(err.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@Override
	public Set<String> getProductCartItems(String userUUID) {
		List<CartItem> cartItemList = null;
		Set<String> productUUIDs = new HashSet<>();
		try {
			cartItemList = this.getCartItems(userUUID, CartConstants.BusinessInterest.PRODUCT, CartConstants.Flag.TRUE);
			cartItemList.forEach(c -> productUUIDs.add(c.getBusinessInterestUUID()));
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

		return productUUIDs;
	}

	@Override
	public Set<String> getServiceCartItems(String userUUID) {
		List<CartItem> cartItemList = null;
		Set<String> serviceUUIDs = new HashSet<>();
		try {
			cartItemList = this.getCartItems(userUUID, CartConstants.BusinessInterest.SERVICE, CartConstants.Flag.TRUE);
			cartItemList.forEach(c -> serviceUUIDs.add(c.getBusinessInterestUUID()));
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

		return serviceUUIDs;
	}

	private List<CartItem> getCartItems(String userUUID, String provider, Boolean b) {
		Optional<List<CartItem>> cartItemList = null;

		cartItemList = cartItemRepo.findByUserUUIdAndProviderAndIsActiveAndRejectStatus(userUUID, provider, b,
				CartConstants.Flag.FALSE);
		if (cartItemList.isPresent()) {
			return cartItemList.get();
		} else {
			throw new CustomException("CartItems not found", HttpStatus.NOT_FOUND);
		}
	}

	@Override
	@Transactional
	public UserDto userDetails(PricingRequestDTO pricingRequestDTO) {

		try {
			RecievdBusinessInterest recievdBusinessInterest = cartDao.getRecieveInterest(pricingRequestDTO.getUuid());

			/*
			 * recieveBusinessInterestRepo
			 * .findByUuidAndIsActive(pricingRequestDTO.getUuid(), CartConstants.Flag.TRUE);
			 */
			UserDto user = null;
			if (recievdBusinessInterest.getViewStatus() == CartConstants.Flag.FALSE) {
				pricingRequestDTO.setCreditType(CreditType.BUSINESS_INTEREST_VIEW);
				pricingRequestDTO
						.setUsedFor("Business interest read for cart id: " + recievdBusinessInterest.getUuid());
				pricingRequestDTO.setAction("DEBIT");
				pricingRequestDTO.setCredits(1);
				recievdBusinessInterest.setViewStatus(true);
				cartDao.saveRecievedItem(recievdBusinessInterest);
				user = userServerEndpoint.getUser(recievdBusinessInterest.getUserUUID());
				pricingEndpoint.updateCredits(pricingRequestDTO);
				return user;

			} else if (recievdBusinessInterest.getViewStatus() == CartConstants.Flag.TRUE) {
				return userServerEndpoint.getUser(recievdBusinessInterest.getUserUUID());
			} else {
				throw new CustomException("Something went wrong while fetching user details", HttpStatus.BAD_REQUEST);
			}

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}

	}

	@Override
	public boolean checkUUIDisExist(String userUUID, String uuid) {
		try {
			if (cartItemRepo.findByBusinessInterestUUIDAndUserUUIdAndIsActiveAndRejectStatus(uuid, userUUID,
					CartConstants.Flag.TRUE, CartConstants.Flag.FALSE) != null) {
				return true;
			}
		} catch (Exception e) {
			LOGGER.info(e);
		}
		return false;
	}

	@Override
	public Cart getRecievedInterest(String userId, int page) {
		try {

			if (page <= 0) {
				page = 1;
			}
			List<RecievdBusinessInterest> recievdBusinessInterests = cartDao.getRecieveItem(userId, page).stream()
					.filter(recieveIterest -> recieveIterest.getIsActive() == true
							&& !(recieveIterest.getOrderStatus().getCurrentStatus()
									.equalsIgnoreCase(CartConstants.UserStages.BI_CLOSED))
							&& !(recieveIterest.getOrderStatus().getCurrentStatus()
									.equalsIgnoreCase(CartConstants.SMEStages.PO_CONFIRMED)))
					.collect(Collectors.toList());

			if (recievdBusinessInterests != null) {
				recievdBusinessInterests.stream().filter(r -> r.getViewStatus() == CartConstants.Flag.TRUE)
						.forEach(re -> re.setUserDetails(userDetails(new PricingRequestDTO(re.getUuid()))));
				recievdBusinessInterests.stream()
						.forEach(item -> item.setOrderStatus(this.getStages(item.getOrderStatus()))

						);
				Cart cart = new Cart();
				cart.setRecievdBusinessInterests(recievdBusinessInterests);

				cart.setSentCount(cartDao.getSentCount(userId));
				cart.setReceiveCount(cartDao.getRecievedCount(userId));
				cart.setCartItem(null);
				return cart;

			} else {
				throw new CustomException("Problem while fetching recieve cart", HttpStatus.NOT_FOUND);
			}

		} catch (CustomException e) {
			LOGGER.info(e);
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}
	}

	@Override
	public Cart getSentInterest(String userId, int page) {
		try {

			List<CartItem> activeCartItems = cartDao.getCartItem(userId, page).stream()
					.filter(cart -> cart.getIsActive() == true
							&& !(cart.getOrderStatus().getCurrentStatus()
									.equalsIgnoreCase(CartConstants.UserStages.BI_CLOSED))
							&& !(cart.getOrderStatus().getCurrentStatus()
									.equalsIgnoreCase(CartConstants.SMEStages.PO_CONFIRMED)))
					.collect(Collectors.toList());

			if (activeCartItems != null) {
				Cart cart = new Cart();
				cart.setCartItem(activeCartItems);

				activeCartItems.stream().forEach(item -> item.setOrderStatus(this.getStages(item.getOrderStatus())));
				Integer recieveCount = cartDao.getRecievedCount(userId);
				cart.setSentCount(cartDao.getSentCount(userId));
				cart.setReceiveCount(recieveCount);
				cart.setRecievdBusinessInterests(null);
				return cart;

			} else {
				throw new CustomException("Problem while fetching cart", HttpStatus.BAD_REQUEST);
			}

		} catch (CustomException e) {

			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

	}

	private OrderStatus getStages(OrderStatus orderStatus) {

		orderStatus.setFirstStage(
				new FirstStage.FirstStageBuilder().stepStatus(CartConstants.Flag.STEP_STATUS_COMPLETED).build());
		if (orderStatus.getCurrentStatus().equals(CartConstants.UserStages.BI_CLOSED)) {
			orderStatus.getFirstStage().setStepStatus(CartConstants.UserStages.BI_CLOSED);
		}

		orderStatus.setSecondStage(new SecondStage.SecondStageBuilder().messageCenter(orderStatus.getRemark())
				.quotationFile(orderStatus.getQuotationFileLocation()).build());
		if (orderStatus.getQuotationFileLocation() != null || orderStatus.getRemark() != null) {
			if (!orderStatus.getCurrentStatus().equals(CartConstants.UserStages.BI_CLOSED))
				orderStatus.getSecondStage().setStepStatus(CartConstants.Flag.STEP_STATUS_COMPLETED);
			if (orderStatus.getCurrentStatus().equals(CartConstants.UserStages.BI_CLOSED)
					&& (orderStatus.getFirstStage().getStepStatus().equals(CartConstants.UserStages.BI_CLOSED))) {
				orderStatus.getSecondStage().setStepStatus(CartConstants.UserStages.BI_CLOSED);
				orderStatus.getFirstStage().setStepStatus(CartConstants.Flag.STEP_STATUS_COMPLETED);
			}

		} else {
			orderStatus.getSecondStage().setStepStatus(CartConstants.Flag.STEP_STATUS_PENDING);
		}
		orderStatus.setThirdStage(new ThirdStage.ThirdStageBuilder().remark(orderStatus.getPurchaseOrderRemark())
				.quotationFile(orderStatus.getPurchaseOrderLocation()).build());

		if (orderStatus.getPurchaseOrderLocation() != null || orderStatus.getPurchaseOrderRemark() != null) {
			orderStatus.getThirdStage().setStepStatus(CartConstants.Flag.STEP_STATUS_COMPLETED);
			if (orderStatus.getCurrentStatus().equals(CartConstants.UserStages.BI_CLOSED)) {
				orderStatus.getThirdStage().setStepStatus(CartConstants.UserStages.BI_CLOSED);
				orderStatus.getSecondStage().setStepStatus(CartConstants.Flag.STEP_STATUS_COMPLETED);
				orderStatus.getFirstStage().setStepStatus(CartConstants.Flag.STEP_STATUS_COMPLETED);
			}
		}
		orderStatus.setFinalStage(new FinalStage());

		if (orderStatus.getThirdStage().getStepStatus().equals(CartConstants.Flag.STEP_STATUS_COMPLETED)
				&& orderStatus.getCurrentStatus().equalsIgnoreCase(CartConstants.SMEStages.PO_CONFIRMED)) {
			orderStatus.getFinalStage().setStepStatus(CartConstants.Flag.STEP_STATUS_COMPLETED);
			if (orderStatus.getCurrentStatus().equals(CartConstants.UserStages.BI_CLOSED)) {
				orderStatus.getFinalStage().setStepStatus(CartConstants.UserStages.BI_CLOSED);
			}
		}

		return orderStatus;
	}

	@Override
	public QuotationPDF generateQuotation(String cartId) throws JRException {

		RecievdBusinessInterest cartItem = recieveBusinessInterestRepo.findByUuid(cartId);
		QuotationFormat quotationFormat = this.getAttribute(cartItem);
		JasperReport jasperReport = JasperCompileManager.compileReport(quotationFormatPath);

		ArrayList<QuotationFormat> list = new ArrayList<>();
		list.add(quotationFormat);
		Map<String, Object> parameter = new HashMap<>();
		try {
			JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(list);

			JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameter, dataSource);

			String quotationName = "Quotation" + cartItem.getUuid() + ".pdf";

			File directory = new File(quotationPath.replace("{sUuid}", cartItem.getSmeId()));

			if (!directory.exists()) {
				directory.mkdirs();
			}
			JasperExportManager.exportReportToPdfFile(jasperPrint,
					quotationPath.replace("{sUuid}", cartItem.getSmeId()) + "/" + quotationName);

			QuotationPDF quotationFile = new QuotationPDF();
			quotationFile.setFileLocation("sme/" + cartItem.getSmeId() + "/QuotationFile/" + quotationName);

			return quotationFile;
		} catch (Exception e) {
			throw e;
		}
	}

	private QuotationFormat getAttribute(RecievdBusinessInterest cartItem) {
		BiAttributeMapper biAttributeMapper = null;
		String smeId = cartItem.getCartAttribute().getsUuid();
		String userId = cartItem.getUserUUID();
		if (cartItem.getProvider().equals(CartConstants.BusinessInterest.PRODUCT)) {
			biAttributeMapper = this.getBusinessInterestDetails(cartItem.getBusinessInterestUUID(), ProductDTO.class,
					cartItem.getBusinessInterestQuantity());
		} else {
			biAttributeMapper = this.getBusinessInterestDetails(cartItem.getBusinessInterestUUID(), SMEServiceDTO.class,
					cartItem.getBusinessInterestQuantity());
		}
		SMEInformationDto smDto = smeServerEndpoint.getSme(smeId);
		UserDto userDto = userServerEndpoint.getUser(userId);
		QuotationFormat quotationFormat = nameConverter.converter(biAttributeMapper, smDto, userDto);
		quotationFormat.setOrderId(cartItem.getUuid());

		DecimalFormat formatter = new DecimalFormat("#0.00");

		Double gstAdded = this.gstPrice(Double.valueOf(quotationFormat.getDiscountedPrice()),
				quotationFormat.getGstPercentage());

		quotationFormat.setAddedGST(formatter.format(gstAdded));

		Double totalAmount = gstAdded + Double.valueOf(quotationFormat.getDiscountedPrice());

		quotationFormat.setTotalAmount(formatter.format(totalAmount));

		quotationFormat.setAmountInWords(intoWord.amountToWords((int) Math.round(totalAmount)) + " Only");
		return quotationFormat;

	}

	private Double gstPrice(Double discountedPrice, double gst) {
		return discountedPrice * (gst / 100);
	}

}
