package com.smeface.cart.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@JsonIgnoreProperties(ignoreUnknown = true)
public class RecievedBusinessInterestDto {

	private String smeId;

	private String userName;

	private String mobileNumber;

	private String eMailid;

	private Integer businessInterestQuantity;

	private Double totalAmount;

	private Boolean viewStatus;



	private String businessInterestUUID;

	public String getSmeId() {
		return smeId;
	}

	public void setSmeId(String smeId) {
		this.smeId = smeId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Boolean isViewStatus() {
		return viewStatus;
	}

	public void setViewStatus(Boolean viewStatus) {
		this.viewStatus = viewStatus;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String geteMailid() {
		return eMailid;
	}

	public void seteMailid(String eMailid) {
		this.eMailid = eMailid;
	}

	public Integer getBusinessInterestQuantity() {
		return businessInterestQuantity;
	}

	public void setBusinessInterestQuantity(Integer businessInterestQuantity) {
		this.businessInterestQuantity = businessInterestQuantity;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getBusinessInterestUUID() {
		return businessInterestUUID;
	}

	public void setBusinessInterestUUID(String businessInterestUUID) {
		this.businessInterestUUID = businessInterestUUID;
	}

}
