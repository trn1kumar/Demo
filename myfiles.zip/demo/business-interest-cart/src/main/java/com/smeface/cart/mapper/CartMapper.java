package com.smeface.cart.mapper;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import com.smeface.cart.dto.CartDto;
import com.smeface.cart.entity.Cart;

@Component
public class CartMapper {
	private Logger logger = LogManager.getLogger(CartMapper.class);

	public CartDto convertToDto(Cart cart) {
		ModelMapper mapper = new ModelMapper();
		try {

			return mapper.map(cart, CartDto.class);

		} catch (Exception e) {
			logger.info(Level.ALL, e);
		}
		return null;
	}

	public Cart convertToEntity(CartDto cartDTO) {
		ModelMapper mapper = new ModelMapper();
		try {
			return mapper.map(cartDTO, Cart.class);

		} catch (Exception e) {
			logger.info(Level.ALL, e);
		}
		return null;
	}
}
