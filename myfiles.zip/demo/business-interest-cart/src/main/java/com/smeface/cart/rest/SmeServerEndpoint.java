package com.smeface.cart.rest;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.http.HttpStatus;

import com.smeface.cart.dto.SMEInformationDto;
import com.smeface.cart.exception.CustomException;
import com.smeface.cart.util.CustomHttpResponse;

public class SmeServerEndpoint {

	private Client client;
	private String smeEndPointUrl;
	private String getSmeUser;

	public SmeServerEndpoint(Client client, String getSmeUser, String smeEndPointUrl) {
		this.client = client;
		this.getSmeUser = getSmeUser;
		this.smeEndPointUrl = smeEndPointUrl;
	}

	public SMEInformationDto getSme(String smeId) {
		CustomHttpResponse<SMEInformationDto> customResponse = null;

		client = ClientBuilder.newClient();
		Response response = client.target(smeEndPointUrl).path(getSmeUser + String.valueOf(smeId))
				.request(MediaType.APPLICATION_JSON).get();

		Integer responseCode = response.getStatus();

		if (responseCode == HttpStatus.OK.value()) {
			try {
				customResponse = response.readEntity(new GenericType<CustomHttpResponse<SMEInformationDto>>() {
				});
			} catch (Exception e) {
				throw new CustomException("Exception at read response from SME Module. Message: " + e.getMessage(),
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
			if (customResponse.isError()) {
				throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
			}
			return customResponse.getData();

		} else {
			throw new CustomException("Invalid Response from SME Module: ", HttpStatus.resolve(responseCode));
		}
	}
}
