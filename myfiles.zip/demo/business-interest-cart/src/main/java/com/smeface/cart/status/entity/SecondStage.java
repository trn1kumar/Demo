package com.smeface.cart.status.entity;

import java.io.Serializable;

public class SecondStage implements Serializable {

	private static final long serialVersionUID = 4946853747386130113L;
	private Integer id;
	private String stepStatus = "Pending";
	private String quotationFile;
	private String messageCenter;
	private String statusName = "Quotation";

	public SecondStage() {
		super();
	}

	public static class SecondStageBuilder {

		private String stepStatus = "Pending";
		private String quotationFile;
		private String messageCenter;
		private String statusName = "Quotation";

		public SecondStageBuilder stepStatus(String stepStatus) {
			this.stepStatus = stepStatus;
			return this;
		}

		public SecondStageBuilder quotationFile(String quotationFile) {
			this.quotationFile = quotationFile;
			return this;
		}

		public SecondStageBuilder messageCenter(String messageCenter) {
			this.messageCenter = messageCenter;
			return this;
		}

		public SecondStageBuilder statusName(String statusName) {
			this.statusName = statusName;
			return this;
		}

		public SecondStage build() {
			return new SecondStage(this);
		}
	}

	public SecondStage(SecondStageBuilder secondStageBuilder) {
		this.stepStatus = secondStageBuilder.stepStatus;
		this.messageCenter = secondStageBuilder.messageCenter;
		this.quotationFile = secondStageBuilder.quotationFile;
		this.statusName = secondStageBuilder.statusName;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getStatusName() {
		return statusName;
	}

	public String getStepStatus() {
		return stepStatus;
	}

	public void setStepStatus(String stepStatus) {
		this.stepStatus = stepStatus;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

	public String getQuotationFile() {
		return quotationFile;
	}

	public void setQuotationFile(String quotationFile) {
		this.quotationFile = quotationFile;
	}

	public String getMessageCenter() {
		return messageCenter;
	}

	public void setMessageCenter(String messageCenter) {
		this.messageCenter = messageCenter;
	}

}