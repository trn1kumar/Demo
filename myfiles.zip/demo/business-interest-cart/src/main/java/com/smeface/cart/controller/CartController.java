package com.smeface.cart.controller;

import java.util.HashMap;
import java.util.Set;

import javax.validation.Valid;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smeface.cart.aspectlogger.BeforeCall;
import com.smeface.cart.constant.APIList;
import com.smeface.cart.dto.PricingRequestDTO;
import com.smeface.cart.dto.UserDto;
import com.smeface.cart.entity.Cart;
import com.smeface.cart.entity.CartItem;
import com.smeface.cart.exception.CustomException;
import com.smeface.cart.service.CartItemService;
import com.smeface.cart.util.HttpRequestParser;
import com.smeface.cart.util.JsonResponse;
import com.smeface.servcie.NotificationService;

/*
*
*
  @author Robin_Kumar
*
*/
@RestController
@RequestMapping(APIList.BASE_URL)
public class CartController {

	@Autowired
	private CartItemService cartItemService;

	@Autowired
	private NotificationService notificationService;
	
	@Autowired
	private HttpRequestParser requestParser;

	private Logger log = LogManager.getLogger(CartController.class);

	@PostMapping(value = APIList.cartAPI.ADD_BUSINESS_INTEREST, produces = MediaType.APPLICATION_JSON_VALUE)
	@PreAuthorize(APIList.ROLE_SME_AND_USER)
	public ResponseEntity<?> addBusinessInterestToCart(@RequestBody @Valid Cart cart) {

		try {
			String token = requestParser.getHeader();
			CartItem cartItem = cart.getCartItem().stream().findFirst().get();
			if (cart.getUserUuid() != null && cartItem.getBusinessInterestUUID() != null) {
				String smeId = null;
				if(requestParser.isSME()) {
					smeId = requestParser.getSuuid();
				}
				
				cartItemService.cart(cart,smeId);
				cartItemService.biCountUpdate(cart, token);
				notificationService.scheduleNotification(cart.getCartItem(),"BI_GENERATION",null);
				return ResponseEntity.ok(new JsonResponse("Business interest generated", HttpStatus.OK.value()));

			} else {
				throw new CustomException("User uid or Item UUID not present", HttpStatus.UNAUTHORIZED);
			}

		} catch (CustomException e) {
			log.log(Level.ALL, e);
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());

		} catch (Exception err) {
			log.log(Level.ALL, err);
			throw new CustomException(err.getMessage(), HttpStatus.BAD_REQUEST);
		}

	}

	@GetMapping(value = APIList.cartAPI.CART_OF_USER, produces = MediaType.APPLICATION_JSON_VALUE)
	@PreAuthorize(APIList.ROLE_SME_AND_USER)
	public ResponseEntity<?> getBusinessInterest(@PathVariable String userUUId,
			@RequestParam(value = "count", required = false) String count,
			@RequestParam(value = "u", required = false) String userCart,
			@RequestParam(value = "page", required = false, defaultValue = "1") int page) {
		Cart cart = null;
		try {
			String newCount = "count";
			if (!newCount.equalsIgnoreCase(count)) {
				if (userUUId != null) {
					if (userCart != null && userCart.equals("user")) {
						cart = cartItemService.getSentInterest(userUUId, page);

						return new ResponseEntity<>(cart, HttpStatus.OK);

					} else {
						cart = cartItemService.getRecievedInterest(userUUId, page);

						return new ResponseEntity<>(cart, HttpStatus.OK);

					}

				} else {
					throw new CustomException("No User is  logged in", HttpStatus.UNAUTHORIZED);
				}
			} else {
				int totalCount = cartItemService.totalCountOfUserCart(userUUId);
				if (totalCount == 0) {
					totalCount = 0;
				}
				HashMap<String, Integer> map = new HashMap<>();
				map.put("Count", totalCount);

				return new ResponseEntity<>(map, HttpStatus.OK);
			}

		} catch (CustomException e) {
			log.log(Level.ALL, e);
			throw new CustomException(e.getMessage(), e.getErrorCode());
		}

	}

	@DeleteMapping(value = APIList.cartAPI.REMOVE_BUSINESS_INTEREST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> removeBusinessInterest(@PathVariable String uuid) {
		try {

			if (uuid != null) {
				cartItemService.removeCartItem(uuid);
			}

		} catch (CustomException e) {
			log.log(Level.ALL, e);
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@PutMapping(value = APIList.cartAPI.UPDATE_BUSINESS_INTEREST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> changeQuantity(@RequestBody CartItem cartItem) {

		try {
			if (cartItem != null && cartItem.getSmeCartId() != null) {
				cartItemService.updateBusinessInterest(cartItem);
				return new ResponseEntity<>("Business interest updated", HttpStatus.OK);
			} else {
				throw new CustomException("Business Interest not found", HttpStatus.NOT_FOUND);
			}
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

	}

	@GetMapping(APIList.cartAPI.PRODUCTS_CART_ITEMS)
	@PreAuthorize(APIList.ROLE_SME_AND_USER)
	public ResponseEntity<?> getProductsCartItems(@PathVariable String userUUID) {
		Set<String> productUUIDs = null;
		try {
			if (userUUID != null) {
				productUUIDs = cartItemService.getProductCartItems(userUUID);
			}
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

		return new ResponseEntity<>(productUUIDs, HttpStatus.OK);
	}

	@GetMapping(APIList.cartAPI.SERVICES_CART_ITEMS)
	@PreAuthorize(APIList.ROLE_SME_AND_USER)
	public ResponseEntity<?> getServicesCartItems(@PathVariable String userUUID) {
		Set<String> serviceUUIDs = null;
		try {
			if (userUUID != null) {
				serviceUUIDs = cartItemService.getServiceCartItems(userUUID);
			}
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

		return new ResponseEntity<>(serviceUUIDs, HttpStatus.OK);
	}

	@PreAuthorize(APIList.ROLE_SME)
	@PutMapping(APIList.cartAPI.GET_USER_DETAILS)
	@BeforeCall
	public ResponseEntity<?> getUserDetails(@RequestBody PricingRequestDTO pricingRequestDTO) {

		try {

			if (pricingRequestDTO.getUuid() != null) {
				
					UserDto userDtoResponse = cartItemService.userDetails(pricingRequestDTO);
					return new ResponseEntity<>(userDtoResponse, HttpStatus.OK);
				

			} else {
				throw new CustomException("Path variable not found", HttpStatus.NOT_FOUND);
			}
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

	}

	@GetMapping(APIList.cartAPI.UUID_ISEXIST)
	public ResponseEntity<?> checkServiceUUIDisExist(@PathVariable String userUUID, @PathVariable String uuid) {

		try {
			if (!cartItemService.checkUUIDisExist(userUUID, uuid)) {
				throw new CustomException("Uuid not found for user " + userUUID, HttpStatus.NOT_FOUND);
			}
		} catch (CustomException e) {
		    
			log.log(Level.ALL,e);
			throw e;
		}

		return new ResponseEntity<>(HttpStatus.OK);
	}
}
