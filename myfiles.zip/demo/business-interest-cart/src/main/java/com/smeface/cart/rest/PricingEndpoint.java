package com.smeface.cart.rest;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.smeface.cart.constant.CreditType;
import com.smeface.cart.dto.PricingRequestDTO;
import com.smeface.cart.exception.CustomException;
import com.smeface.cart.exception.NoCreditException;
import com.smeface.cart.securityconfiguration.Constants;
import com.smeface.cart.util.CreditsCheckResponse;
import com.smeface.cart.util.CustomHttpResponse;
import com.smeface.cart.util.HttpRequestParser;

@Component
public class PricingEndpoint {

	Logger logger = LogManager.getLogger();

	private Client client;
	private String pricingEnpointUrl;
	private String checkCreditsPath;

	@Autowired
	private HttpRequestParser requestParser;

	public PricingEndpoint(Client client, String pricingEnpointUrl, String checkCreditsPath) {
		super();
		this.client = client;
		this.pricingEnpointUrl = pricingEnpointUrl;
		this.checkCreditsPath = checkCreditsPath;
	}

	public long checkCredits(CreditType creditType) {

		Response response = null;
		CustomHttpResponse<CreditsCheckResponse> httpResponse = null;
		try {
			response = client.target(pricingEnpointUrl).path(checkCreditsPath).queryParam("type", creditType.toString())
					.request(MediaType.APPLICATION_JSON).header(Constants.HEADER_STRING, requestParser.getHeader())
					.get();

			logger.info(response.toString());

			httpResponse = response.readEntity(new GenericType<CustomHttpResponse<CreditsCheckResponse>>() {
			});

			logger.info(httpResponse.toString());

			if (httpResponse.isError() && httpResponse.getCode() == HttpStatus.PAYMENT_REQUIRED.value()) {
				throw new NoCreditException(CreditType.BUSINESS_INTEREST_VIEW);
			}
			return httpResponse.getData().getCredits();
		} catch (NoCreditException e) {
			throw e;
		} catch (Exception e) {
			logger.info("Error while :: " + e.toString());
			throw new CustomException("Error while " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public void updateCredits(PricingRequestDTO pricingRequestDTO) {

		CustomHttpResponse<?> httpResponse = null;
		Response response = null;
		try {
			response = client.target(pricingEnpointUrl).path(checkCreditsPath).request(MediaType.APPLICATION_JSON)
					.header(Constants.HEADER_STRING, requestParser.getHeader())
					.put(Entity.entity(pricingRequestDTO, MediaType.APPLICATION_JSON));

			logger.info(response.toString());

			httpResponse = response.readEntity(new GenericType<CustomHttpResponse<?>>() {
			});

			logger.info(httpResponse.toString());

			if (httpResponse.isError() && httpResponse.getCode() == HttpStatus.PAYMENT_REQUIRED.value()) {
				throw new NoCreditException(CreditType.BUSINESS_INTEREST_VIEW);
			}
		} catch (NoCreditException e) {
			throw e;

		} catch (Exception e) {
			logger.info("Error while :: " + e.toString());
			throw new CustomException("Error while " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
