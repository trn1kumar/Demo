package com.smeface.cart.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.smeface.cart.entity.CartItem;

@Repository
public interface CartItemRepo extends JpaRepository<CartItem, Long>{

	CartItem findBySmeCartId(Long smeCartId);
	CartItem findByUuidAndRejectStatus(String uuid, boolean bool);
	CartItem findByBusinessInterestUUIDAndUserUUIdAndIsActiveAndRejectStatus(String businessInterestUUID, String userUUID, Boolean bool, boolean rejectStatus);     
	
	List<CartItem> findByUserUUIdAndIsActive(String userUUID,Boolean b, Pageable pageable);
	Optional<List<CartItem>> findByUserUUIdAndProviderAndIsActiveAndRejectStatus(String userUUID,String provider,Boolean b, boolean rejectStatus);
//	Integer countByUserUUIdAndIsActiveTrue(String userId);
	List<CartItem> findByUserUUId(String userUUID, Pageable pageable);
	
	CartItem findByUuid(String cartId);
	
	@Query(value = "SELECT COUNT(*) FROM CartItem c JOIN " + "c.orderStatus os "
			+ "where c.userUUId=:smeId AND c.isActive=true "
			+ "AND os.currentStatus!=:biClosed AND os.currentStatus!=:poConfirmed")
	Integer sentCartCount(String smeId,String biClosed,String poConfirmed);
	
}
