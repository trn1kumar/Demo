package com.smeface.cart.mapper;

import java.text.DecimalFormat;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.smeface.cart.dto.BiAttributeMapper;
import com.smeface.cart.dto.ProductDTO;
import com.smeface.cart.dto.SMEInformationDto;
import com.smeface.cart.dto.SMEServiceDTO;
import com.smeface.cart.dto.UserDto;
import com.smeface.cart.entity.QuotationFormat;
import com.smeface.cart.exception.CustomException;

@Component
public class NameConverter {

	@Value("${sme.logo.path}")
	private String smeLogoPath;

	private NameConverter() {
		super();
	}

	public <T> BiAttributeMapper converter(T obj, Integer businessInterestQuantity) {

		if (obj != null) {
			if (obj instanceof ProductDTO) {
				BiAttributeMapper setFeild = new BiAttributeMapper();
				setFeild.setItemDisplayName(((ProductDTO) obj).getProductName());
				if (((ProductDTO) obj).getImages() != null && !((ProductDTO) obj).getImages().isEmpty())
					setFeild.setItemImage(((ProductDTO) obj).getImages().get(0).getFileLocation());
				setFeild.setItemURL(((ProductDTO) obj).getProductUrlName());
				setFeild.setGst(((ProductDTO) obj).getGst());
				setFeild.setItemActualPrice(((ProductDTO) obj).getPrice());
				setFeild.setDiscountedPrice(((ProductDTO) obj).getDiscountedPrice());
				setFeild.setDiscount(((ProductDTO) obj).getDiscount());
				setFeild.setTermsAndCondition(((ProductDTO) obj).getTermsAndCondition());
				setFeild.setBusinessInterestQuantity(businessInterestQuantity);
				setFeild.setPriceUnit(((ProductDTO) obj).getPriceUnit());
				setFeild.setDescription(((ProductDTO) obj).getDescription());
				setFeild.setItemImage(((ProductDTO) obj).getMainImage());
				setFeild.setBusinessInterestUUID(((ProductDTO) obj).getProductUuid());
				setFeild.setSmeName(((ProductDTO) obj).getSmeName());
				setFeild.setsUuid(((ProductDTO) obj).getsUuid());
				return setFeild;
			} else {
				if (obj instanceof SMEServiceDTO) {
					BiAttributeMapper setFeild = new BiAttributeMapper();
					setFeild.setItemDisplayName(((SMEServiceDTO) obj).getServiceName());
					setFeild.setItemImage(((SMEServiceDTO) obj).getMainImage());
					setFeild.setItemURL(((SMEServiceDTO) obj).getServiceUrlName());
					setFeild.setTermsAndCondition(((SMEServiceDTO) obj).getTermsAndCondition());
					setFeild.setDiscountedPrice(((SMEServiceDTO) obj).getDiscountedPrice());
					setFeild.setDiscount(((SMEServiceDTO) obj).getDiscount());
					setFeild.setDescription(((SMEServiceDTO) obj).getDescription());
					setFeild.setBusinessInterestQuantity(businessInterestQuantity);
					setFeild.setItemActualPrice(((SMEServiceDTO) obj).getPrice());
					setFeild.setPriceUnit(((SMEServiceDTO) obj).getPriceUnit());
					setFeild.setBusinessInterestUUID(((SMEServiceDTO) obj).getServiceUuid());
					setFeild.setGst(((SMEServiceDTO) obj).getGst());
					setFeild.setSmeName(((SMEServiceDTO) obj).getSmeName());
					setFeild.setsUuid(((SMEServiceDTO) obj).getsUuid());
					return setFeild;
				} else {
					throw new CustomException("Error while converting in Name mapper converter",
							HttpStatus.EXPECTATION_FAILED);
				}
			}
		} else {
			return null;
		}

	}

	public <T> QuotationFormat converter(T obj, T obj1, T obj2) {
		QuotationFormat setFeild = new QuotationFormat();

		if (obj != null && obj1 != null && obj2 != null) {

			if (obj instanceof BiAttributeMapper && obj1 instanceof SMEInformationDto && obj2 instanceof UserDto) {
				BiAttributeMapper biAttributeMapper = (BiAttributeMapper) obj;
				SMEInformationDto smeInformationDto = (SMEInformationDto) obj1;
				UserDto userDto = (UserDto) obj2;
				setFeild.setItemName(biAttributeMapper.getItemDisplayName());

				setFeild.setGstin(smeInformationDto.getGstin());
				setFeild.setSmeLogo(smeLogoPath + smeInformationDto.getLogoImage());
				Double d = (biAttributeMapper.getDiscountedPrice() * biAttributeMapper.getBusinessInterestQuantity());
				DecimalFormat formatter = new DecimalFormat("#0.00");
				
				setFeild.setDiscountedPrice(formatter.format(d));

				setFeild.setItemActualPrice(biAttributeMapper.getItemActualPrice());
				setFeild.setItemImage(biAttributeMapper.getItemImage());
				setFeild.setGstPercentage(biAttributeMapper.getGst());
				setFeild.setTermsAndCondition(biAttributeMapper.getTermsAndCondition());

				setFeild.setQuantity(biAttributeMapper.getBusinessInterestQuantity());

				setFeild.setDiscount(biAttributeMapper.getDiscount());
				setFeild.setSmeEmail(smeInformationDto.getContactEmail());
				setFeild.setSmeName(smeInformationDto.getSmeName());
				if (smeInformationDto.getContactPhone() != null)
					setFeild.setSmePhone(smeInformationDto.getContactPhone());
				setFeild.setUnit(biAttributeMapper.getPriceUnit());
				setFeild.setUserEmail(userDto.getUserEmail());
				if (userDto.getUserMobile() != null)
					setFeild.setUserMobile(userDto.getUserMobile());
				setFeild.setUserName(userDto.getUserFullName());
				setFeild.setAddress(smeInformationDto.getSmeAddress().toString());

			}

		}
		return setFeild;
	}
}
