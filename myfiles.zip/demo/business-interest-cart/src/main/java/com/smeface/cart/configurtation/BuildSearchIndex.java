package com.smeface.cart.configurtation;

import javax.persistence.EntityManager;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.hibernate.CacheMode;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.Search;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;


@Component
public class BuildSearchIndex implements ApplicationListener<ApplicationReadyEvent> {

	@Autowired
	private EntityManager entityManager;
	
	private Logger log = LogManager.getLogger(BuildSearchIndex.class);

	@Override
	@Transactional
	public void onApplicationEvent(final ApplicationReadyEvent event) {

		log.info("Started Initializing Indexes");
	
		try {
			FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);
			fullTextEntityManager.createIndexer()
								 .batchSizeToLoadObjects(25)
								 .threadsToLoadObjects(12)
								 .idFetchSize(150)
								 .cacheMode(CacheMode.IGNORE)
								 .startAndWait();
			
			log.info("Completed indexing");			
		} catch (InterruptedException e) {
			log.log(Level.WARN, "Interrupted!", e);
			Thread.currentThread().interrupt();
			log.info("An error occurred trying to build the serach index: " +e.toString());
		}
		
		

	}

}
