package com.smeface.cart.entity;

import com.smeface.cart.dto.BiAttributeMapper;
import com.smeface.cart.dto.SMEInformationDto;
import com.smeface.cart.dto.UserDto;

public class QuotationFile {

	private Long quotationID;

	private String fileName;

	private boolean active;

	private String fileLocation;

	private BiAttributeMapper attributeMapper;

	private SMEInformationDto smeInformationDto;

	private UserDto userDto;

	public QuotationFile(String fileName, boolean active) {
		this.fileName = fileName;
		this.active = active;
	}

	public QuotationFile() {

	}
	public QuotationFile(String fileLocation) {
		super();
		this.fileLocation = fileLocation;
	}

	public BiAttributeMapper getAttributeMapper() {
		return attributeMapper;
	}

	public void setAttributeMapper(BiAttributeMapper attributeMapper) {
		this.attributeMapper = attributeMapper;
	}

	public SMEInformationDto getSmeInformationDto() {
		return smeInformationDto;
	}

	public void setSmeInformationDto(SMEInformationDto smeInformationDto) {
		this.smeInformationDto = smeInformationDto;
	}

	public UserDto getUserDto() {
		return userDto;
	}

	public void setUserDto(UserDto userDto) {
		this.userDto = userDto;
	}

	public Long getQuotationID() {
		return quotationID;
	}

	public void setQuotationID(Long quotationID) {
		this.quotationID = quotationID;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

}
