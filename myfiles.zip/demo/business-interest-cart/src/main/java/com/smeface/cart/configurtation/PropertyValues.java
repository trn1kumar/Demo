package com.smeface.cart.configurtation;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PropertyValues {

	@Value(PropertyNames.SCHEDULER_GROUP_NAME)
	private String schedulerGroupName;

	@Value(PropertyNames.QUOTATION_PATH)
	private String quotationPath;

	@Value(PropertyNames.BI_GENERATION_EMAIL_SUB)
	private String biGenerationEmailSub;

	@Value(PropertyNames.BI_GENERATION_SMS_MSG)
	private String biGenerationSmsMsg;

	@Value(PropertyNames.QUOTATION_RECEIVED_EMAIL_SUB)
	private String quotationReceivedEmailSub;

	@Value(PropertyNames.QUOTATION_RECEIVED_SMS_MSG)
	private String quotationReceivedSmsMsg;

	@Value(PropertyNames.PURCHASE_ORDER_RECEIVED_EMAIL_SUB)
	private String purchaseOrderReceivedEmailSub;

	@Value(PropertyNames.PURCHASE_ORDER_RECEIVED_SMS_MSG)
	private String purchaseOrderReceivedSmsMsg;

	@Value(PropertyNames.CONFIRM_ORDER_EMAIL_SUB)
	private String confirmOrderEmailSub;

	@Value(PropertyNames.CONFIRM_ORDER_SMS_MSG)
	private String confirmOrderSmsMsg;

	@Value(PropertyNames.BASE_URL)
	private String baseUrl;

	@Value(PropertyNames.CONTENT_SERVER_URL)
	private String contentServerUrl;

	@Value(PropertyNames.CART_URL)
	private String cartUrl;

	public String getSchedulerGroupName() {
		return schedulerGroupName;
	}

	public void setSchedulerGroupName(String schedulerGroupName) {
		this.schedulerGroupName = schedulerGroupName;
	}

	public String getQuotationPath() {
		return quotationPath;
	}

	public void setQuotationPath(String quotationPath) {
		this.quotationPath = quotationPath;
	}

	public String getBiGenerationSmsMsg() {
		return biGenerationSmsMsg;
	}

	public void setBiGenerationSmsMsg(String biGenerationSmsMsg) {
		this.biGenerationSmsMsg = biGenerationSmsMsg;
	}

	public String getBiGenerationEmailSub() {
		return biGenerationEmailSub;
	}

	public void setBiGenerationEmailSub(String biGenerationEmailSub) {
		this.biGenerationEmailSub = biGenerationEmailSub;
	}

	public String getQuotationReceivedEmailSub() {
		return quotationReceivedEmailSub;
	}

	public void setQuotationReceivedEmailSub(String quotationReceivedEmailSub) {
		this.quotationReceivedEmailSub = quotationReceivedEmailSub;
	}

	public String getQuotationReceivedSmsMsg() {
		return quotationReceivedSmsMsg;
	}

	public void setQuotationReceivedSmsMsg(String quotationReceivedSmsMsg) {
		this.quotationReceivedSmsMsg = quotationReceivedSmsMsg;
	}

	public String getPurchaseOrderReceivedEmailSub() {
		return purchaseOrderReceivedEmailSub;
	}

	public void setPurchaseOrderReceivedEmailSub(String purchaseOrderReceivedEmailSub) {
		this.purchaseOrderReceivedEmailSub = purchaseOrderReceivedEmailSub;
	}

	public String getPurchaseOrderReceivedSmsMsg() {
		return purchaseOrderReceivedSmsMsg;
	}

	public void setPurchaseOrderReceivedSmsMsg(String purchaseOrderReceivedSmsMsg) {
		this.purchaseOrderReceivedSmsMsg = purchaseOrderReceivedSmsMsg;
	}

	public String getConfirmOrderEmailSub() {
		return confirmOrderEmailSub;
	}

	public void setConfirmOrderEmailSub(String confirmOrderEmailSub) {
		this.confirmOrderEmailSub = confirmOrderEmailSub;
	}

	public String getConfirmOrderSmsMsg() {
		return confirmOrderSmsMsg;
	}

	public void setConfirmOrderSmsMsg(String confirmOrderSmsMsg) {
		this.confirmOrderSmsMsg = confirmOrderSmsMsg;
	}

	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	public String getContentServerUrl() {
		return contentServerUrl;
	}

	public void setContentServerUrl(String contentServerUrl) {
		this.contentServerUrl = contentServerUrl;
	}

	public String getCartUrl() {
		return cartUrl;
	}

	public void setCartUrl(String cartUrl) {
		this.cartUrl = cartUrl;
	}

	public static final class PropertyNames {

		private PropertyNames() {
			throw new IllegalStateException("PropertyNames class.can't initiate");
		}

		public static final String QUOTATION_PATH = "${quotation.file.path}";

		// Notification properties names
		public static final String SCHEDULER_GROUP_NAME = "${scheduler.group-name}";

		public static final String BI_GENERATION_EMAIL_SUB = "${notify.email-subject.bi.generation}";
		public static final String BI_GENERATION_SMS_MSG = "${notify.smsMsg.bi.generation}";

		public static final String QUOTATION_RECEIVED_EMAIL_SUB = "${notify.email-subject.quotation.received}";
		public static final String QUOTATION_RECEIVED_SMS_MSG = "${notify.smsMsg.quotation.received}";

		public static final String PURCHASE_ORDER_RECEIVED_EMAIL_SUB = "${notify.email-subject.purchase-order.received}";
		public static final String PURCHASE_ORDER_RECEIVED_SMS_MSG = "${notify.smsMsg.purchase-order.received}";

		public static final String CONFIRM_ORDER_EMAIL_SUB = "${notify.email-subject.confirm-order}";
		public static final String CONFIRM_ORDER_SMS_MSG = "${notify.smsMsg.confirm-order}";

		public static final String BASE_URL = "${base-url}";
		public static final String CONTENT_SERVER_URL = "${content-server.localized-url}";
		public static final String CART_URL = "${cart-url}";

	}

}
