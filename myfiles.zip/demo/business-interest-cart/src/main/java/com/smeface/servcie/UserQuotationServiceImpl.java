package com.smeface.servcie;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.smeface.cart.dao.CartDao;
import com.smeface.cart.entity.CartItem;
import com.smeface.cart.entity.QuotationFile;
import com.smeface.cart.entity.RecievdBusinessInterest;
import com.smeface.cart.exception.CustomException;
import com.smeface.cart.repository.CartItemRepo;
import com.smeface.cart.repository.RecieveBusinessInterestRepo;
import com.smeface.cart.status.entity.OrderStatus;
import com.smeface.cart.status.entity.ThirdStage;
import com.smeface.cart.util.UpdateAtrribute;

@Service
public class UserQuotationServiceImpl implements UserQuotationService {

	@Autowired
	private CartItemRepo cartItemRepo;

	@Autowired
	private CartDao cartDao;

	@Autowired
	private RecieveBusinessInterestRepo recieveBusinessInterestRepo;

	@Autowired
	private NotificationService notificationService;

	@Override
	public void revise(CartItem cartItem, QuotationFile quotationFile) {
		try {

			/*
			 * CartItem oldCartItem = this.checkStatus(cartItem.getUuid());
			 * cartItem.setOrderStatus(new
			 * OrderStatus.CartOrderStageBuilder().currentStatus("Revised")
			 * .quotationFileLocation(quotationFile.getFileLocation())
			 * .remark(existingRecievdBusinessInterest.getOrderStatus().getRemark()).build()
			 * ); this.saveCartItemData(oldCartItem);
			 * 
			 * RecievdBusinessInterest existingRecievdBusinessInterest =
			 * this.checkStatus(recievdBusinessInterest);
			 * existingRecievdBusinessInterest.setOrderStatus(new
			 * OrderStatus.CartOrderStageBuilder() .currentStatus("Revised")
			 * .quotationFileLocation(existingRecievdBusinessInterest.getOrderStatus().
			 * getQuotationFileLocation())
			 * .remark(existingRecievdBusinessInterest.getOrderStatus().getRemark()).build()
			 * ); this.saveData(existingRecievdBusinessInterest);
			 */

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}

	}

	@Override
	public void reject(CartItem cartItem) {
		try {
			CartItem oldCartItem = this.checkStatus(cartItem.getUuid());
			oldCartItem.getOrderStatus().setCurrentStatus("BI closed");
			oldCartItem.getOrderStatus().setRejectRemark(cartItem.getOrderStatus().getRejectRemark());
			oldCartItem.setRejectStatus(true);

			this.saveCartItemData(oldCartItem);

			RecievdBusinessInterest existingRecievdBusinessInterest = this.getSmeAction(oldCartItem);
			existingRecievdBusinessInterest.getOrderStatus().setCurrentStatus("BI closed");
			existingRecievdBusinessInterest.getOrderStatus()
					.setRejectRemark(cartItem.getOrderStatus().getRejectRemark());
			existingRecievdBusinessInterest.setRejectStatus(true);
			this.saveReceiveItemData(existingRecievdBusinessInterest);

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}

	}

	private RecievdBusinessInterest getSmeAction(CartItem cartItem) {
		RecievdBusinessInterest recievdBusinessInterest = recieveBusinessInterestRepo
				.findByUuidAndRejectStatus(cartItem.getUuid(), false);

		if (recievdBusinessInterest != null) {
			return recievdBusinessInterest;
		} else {
			return null;
		}

	}

	@Override
	public CartItem getQuotation(String uuid) {

		try {
			return checkStatus(uuid);

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}

	}

	@Override
	public ThirdStage accept(CartItem cartItem, QuotationFile quotationFile) {
		try {
			CartItem oldCartItem = this.checkStatus(cartItem.getUuid());
			RecievdBusinessInterest currentItem = new RecievdBusinessInterest();
			currentItem.setOrderStatus(new OrderStatus.CartOrderStageBuilder().build());
			if (quotationFile != null) {
				currentItem.getOrderStatus().setPurchaseOrderLocation(quotationFile.getFileLocation());
				cartItem.getOrderStatus().setPurchaseOrderLocation(quotationFile.getFileLocation());
			}
			cartItem.getOrderStatus().setCurrentStatus("PO Sent");
			UpdateAtrribute.copyNonNullProperties(cartItem.getOrderStatus(), oldCartItem.getOrderStatus());
			this.saveCartItemData(oldCartItem);

			RecievdBusinessInterest existingRecievdBusinessInterest = this.getSmeAction(oldCartItem);

			currentItem.getOrderStatus().setCurrentStatus("PO Received");
			currentItem.getOrderStatus().setPurchaseOrderRemark(cartItem.getOrderStatus().getPurchaseOrderRemark());
			UpdateAtrribute.copyNonNullProperties(currentItem.getOrderStatus(),
					existingRecievdBusinessInterest.getOrderStatus());
			this.saveReceiveItemData(existingRecievdBusinessInterest);
			ThirdStage thirdStage = new ThirdStage.ThirdStageBuilder().build();
			if (quotationFile != null) {
				thirdStage.setQuotationFile(quotationFile.getFileLocation());

			} else {
				thirdStage.setRemark(cartItem.getOrderStatus().getPurchaseOrderRemark());
			}
			notificationService.scheduleNotification(Arrays.asList(oldCartItem), "PURCHASE_ORDER",null);
			return thirdStage;
		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}

	}

	private CartItem checkStatus(String uuid) {
		try {
			CartItem existingCartItem = cartItemRepo.findByUuidAndRejectStatus(uuid, false);
			if (existingCartItem != null) {
				return existingCartItem;
			} else {
				throw new CustomException("cart item not found", HttpStatus.NOT_FOUND);
			}
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private void saveReceiveItemData(RecievdBusinessInterest businessInterest) {
		try {
			cartDao.saveRecievedItem(businessInterest);
			// recieveBusinessInterestRepo.save(businessInterest);
		} catch (CustomException e) {
			throw new CustomException("Error while saving RecievdBusinessInterest data into DB",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private void saveCartItemData(CartItem cartItem) {
		try {
			cartDao.saveCartItem(cartItem);
			// cartItemRepo.save(cartItem);
		} catch (CustomException e) {
			throw new CustomException("Error while saving RecievdBusinessInterest data into DB",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
