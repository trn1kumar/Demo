package com.smeface.cart.controller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.smeface.cart.entity.QuotationFormat;

@Controller
public class EmailController {

	
	@PostMapping("/interest-shown")
	public String generateInterestEmail(Model model, @RequestBody QuotationFormat setFeild) {
		
		model.addAttribute("cartRest",setFeild);
		return "InterestGeneration";
	}
	
	@PostMapping("/quotation-mail")
	public String quotationEmail(Model model, @RequestBody QuotationFormat setFeild) {
		
		model.addAttribute("cartRest",setFeild);
		return "Quotation";
	}

}
