package com.smeface.cart.rest;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.glassfish.jersey.media.multipart.MultiPart;
import org.glassfish.jersey.media.multipart.file.FileDataBodyPart;
import org.springframework.http.HttpStatus;
import org.springframework.web.multipart.MultipartFile;

import com.smeface.cart.dto.UploadFileResponse;
import com.smeface.cart.exception.CustomException;

public class ContentServerEndpoint {

	private Client client;
	private String fileServerEndPoint;
	private String uploadMultipleFiles;
	private String deleteFile;

	Logger log = LogManager.getLogger(ContentServerEndpoint.class.getName());

	public ContentServerEndpoint(Client client, String contentServerEndPoint, String uploadMultipleFiles,
			String deleteFile) {
		this.client = client;
		this.fileServerEndPoint = contentServerEndPoint;
		this.uploadMultipleFiles = uploadMultipleFiles;
		this.deleteFile = deleteFile;
	}

	public List<UploadFileResponse> sendFileToContentServer(MultipartFile multipartFile2, String name,
			String fileLocation) throws IOException {

		try {
			WebTarget webTarget = client.target(fileServerEndPoint).path(uploadMultipleFiles).path(fileLocation);
			MultiPart multiPart = new MultiPart();
			multiPart.setMediaType(MediaType.MULTIPART_FORM_DATA_TYPE);

			File tmpFile = convert(multipartFile2, name);
			FileDataBodyPart fileDataBodyPart = new FileDataBodyPart("files", (tmpFile),
					MediaType.APPLICATION_OCTET_STREAM_TYPE);

			multiPart.bodyPart(fileDataBodyPart);

			Response response = webTarget.request(MediaType.APPLICATION_JSON_TYPE)
					.post(Entity.entity(multiPart, multiPart.getMediaType()));
			this.cleanUp(tmpFile);
			return response.readEntity(new GenericType<List<UploadFileResponse>>() {
			});

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());

		}

	}

	public File convert(MultipartFile file, String name) throws IOException {
		try {
			File convFile = new File(name);
			convFile.createNewFile();
			FileOutputStream fos = new FileOutputStream(convFile);
			fos.write(file.getBytes());
			fos.close();
			return convFile;
		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}
	}

	private boolean cleanUp(File tmpFile) {
		tmpFile.delete();
		return true;
	}

	public void deleteFileFromContentServer(String fileLocation) throws IOException {

		Response response = null;
		Client client = ClientBuilder.newClient();
		try {
			response = client.target(fileServerEndPoint).path(deleteFile).path(fileLocation)
					.request(MediaType.APPLICATION_JSON).delete();
		} catch (Exception e) {
			log.log(Level.ALL, e);
			throw new CustomException(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		Integer responseCode = response.getStatus();

		if (responseCode != HttpStatus.OK.value()) {
			throw new CustomException("Problem for delete image from content server", HttpStatus.CONFLICT);
		}

	}
}
