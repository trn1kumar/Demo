package com.smeface.cart.controller;

import java.io.IOException;

import org.glassfish.jersey.media.multipart.FormDataParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.google.gson.Gson;
import com.smeface.cart.constant.APIList;
import com.smeface.cart.constant.BusinessInterestStatus;
import com.smeface.cart.entity.QuotationFile;
import com.smeface.cart.entity.RecievdBusinessInterest;
import com.smeface.cart.exception.CustomException;
import com.smeface.cart.status.entity.SecondStage;
import com.smeface.cart.util.HttpRequestParser;
import com.smeface.cart.util.SendFilesToContentServer;
import com.smeface.servcie.SMEQuotationService;

import net.sf.jasperreports.engine.JRException;

@RestController
@RequestMapping(APIList.SME_BASE_URL)
public class SmeQuotationController {

	@Autowired
	private SMEQuotationService quotationService;

	@Autowired
	private SendFilesToContentServer sendfiles;
	
	@Autowired
	private HttpRequestParser requestParser;
	
	@PostMapping(value = APIList.smeActionAPI.REVISE)
	public ResponseEntity<?> revise(MultipartHttpServletRequest requestBody,
			@FormDataParam("files") MultipartFile files, Authentication authentication)
			throws IOException {
		QuotationFile quotationFile = null;
		RecievdBusinessInterest recievdBusinessInterest = null;

		try {
			Gson g = new Gson();
			recievdBusinessInterest = g.fromJson(requestBody.getParameter("recieve"), RecievdBusinessInterest.class);
		} catch (Exception e) {
			throw new CustomException("Failed to parse json data", HttpStatus.BAD_REQUEST);
		}

		try {
			if (files != null) {
				quotationFile = sendfiles.sendFileToContentServer(files,
						BusinessInterestStatus.QUOTATION.replace("{sUuid}", requestParser.getSuuid()));

			}
			quotationService.revise(recievdBusinessInterest, quotationFile);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}
	}

	@PostMapping(value = APIList.smeActionAPI.REJECT)
	public ResponseEntity<?> reject(@RequestBody RecievdBusinessInterest recievdBusinessInterest) {
		try {
			quotationService.reject(recievdBusinessInterest);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}
	}

	@PostMapping(value = APIList.smeActionAPI.ACCEPT)
	public ResponseEntity<?> accept(MultipartHttpServletRequest requestBody,
			@FormDataParam("files") MultipartFile files, Authentication authentication)
			throws IOException, JRException {
		QuotationFile images = null;
		RecievdBusinessInterest recievdBusinessInterest = null;

		try {
			Gson g = new Gson();
			recievdBusinessInterest = g.fromJson(requestBody.getParameter("recieve"), RecievdBusinessInterest.class);
		} catch (Exception e) {
			throw new CustomException("Failed to parse json data", HttpStatus.BAD_REQUEST);
		}
		try {

			if (files != null && recievdBusinessInterest.getQuotationType().equals("MANUAL")) {
				images = sendfiles.sendFileToContentServer(files,
						BusinessInterestStatus.QUOTATION.replace("{sUuid}", requestParser.getSuuid()));

			}
			SecondStage secondStage = quotationService.accept(recievdBusinessInterest, images);

			return new ResponseEntity<>(secondStage, HttpStatus.OK);
		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}
	}

	@PostMapping(value = APIList.smeActionAPI.CONFIRM)
	public ResponseEntity<?> confirmOrder(@RequestBody RecievdBusinessInterest recievdBusinessInterest) {
		try {
			quotationService.confirmOrder(recievdBusinessInterest);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}
	}

}
