package com.smeface.cart.util;

import com.smeface.cart.constant.CreditType;

public class CreditsCheckResponse {

	private long credits;
	String displayName;
	private CreditType creditType;

	public CreditsCheckResponse() {
		super();
	}

	public long getCredits() {
		return credits;
	}

	public void setCredits(long credits) {
		this.credits = credits;
	}

	public String getDisplayName() {
		return creditType.getValue();
	}

	public CreditType getCreditType() {
		return creditType;
	}

	public void setCreditType(CreditType creditType) {
		this.creditType = creditType;
	}

}