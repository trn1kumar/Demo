package com.smeface.cart.aspectlogger;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.smeface.cart.constant.CartConstants;
import com.smeface.cart.constant.CreditType;
import com.smeface.cart.dto.PricingRequestDTO;
import com.smeface.cart.entity.RecievdBusinessInterest;
import com.smeface.cart.repository.RecieveBusinessInterestRepo;
import com.smeface.cart.rest.PricingEndpoint;

@Aspect
@Configuration
public class CheckCredits {

	@Autowired
	private PricingEndpoint pricingEndpoint;

	@Autowired
	private RecieveBusinessInterestRepo businessInterestRepo;

	private Logger logger = LogManager.getLogger(CentralLoggingHandler.class);

	@Before("execution(* *.*(..)) && @annotation(auditable) && args(pricingRequestDTO)")
	public Object beforeMethodExecution(JoinPoint joinPoint, BeforeCall auditable,
			PricingRequestDTO pricingRequestDTO) {
		RecievdBusinessInterest businessInterest = businessInterestRepo
				.findByUuidAndIsActive(pricingRequestDTO.getUuid(), true);
		logger.info("Checking for credits...");
		if (businessInterest.getViewStatus() == CartConstants.Flag.FALSE) {
			pricingEndpoint.checkCredits(CreditType.BUSINESS_INTEREST_VIEW);
		}
		return true;

	}

}
