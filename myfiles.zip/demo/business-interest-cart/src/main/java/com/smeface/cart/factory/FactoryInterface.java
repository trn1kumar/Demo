package com.smeface.cart.factory;

public interface FactoryInterface<T> {

     T returnObject();
    
   
}
