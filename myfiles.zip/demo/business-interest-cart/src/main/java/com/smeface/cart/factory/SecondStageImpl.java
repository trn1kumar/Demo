package com.smeface.cart.factory;

import com.smeface.cart.status.entity.SecondStage;

public class SecondStageImpl implements FactoryInterface<Object> {

	@Override
	public Object returnObject() {
		return new SecondStage.SecondStageBuilder().build();
	}

}
