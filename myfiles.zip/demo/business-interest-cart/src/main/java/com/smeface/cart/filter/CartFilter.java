package com.smeface.cart.filter;

import java.util.List;

import com.smeface.cart.entity.RecievdBusinessInterest;

public interface CartFilter {

	public List<RecievdBusinessInterest> getCartByProductName(String productName, String smeId);
	public List<RecievdBusinessInterest> getCartByUserName(String userName, String smeId);
	public List<RecievdBusinessInterest> getCartByStage(String stage, String smeId);
	
}
