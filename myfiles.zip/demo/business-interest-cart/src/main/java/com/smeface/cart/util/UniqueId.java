package com.smeface.cart.util;

import java.util.UUID;

public class UniqueId {
	protected static String[] hardKey = new String[100];

	private UniqueId() {
		super();
	}

	public static synchronized String getUUID() {
		RandomNumber number = new RandomNumber();
		return "BI" + number.numberGenerator() + number.numberGenerator();
	}

	public static synchronized String getUUIDs() {
		String uuid = UUID.randomUUID().toString();
		return uuid.replace("-", "");
	}

}