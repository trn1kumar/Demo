package com.smeface.servcie;

import com.smeface.cart.entity.QuotationFile;
import com.smeface.cart.entity.RecievdBusinessInterest;
import com.smeface.cart.status.entity.SecondStage;

import net.sf.jasperreports.engine.JRException;

public interface SMEQuotationService {

	public SecondStage accept(RecievdBusinessInterest recievdBusinessInterest, QuotationFile quotationFile) throws JRException;

	public void reject(RecievdBusinessInterest recievdBusinessInterest);

	public void revise(RecievdBusinessInterest recievdBusinessInterest, QuotationFile quotationFile);

	public void confirmOrder(RecievdBusinessInterest recievdBusinessInterest);

	public RecievdBusinessInterest getQuotation(String uuid);

}
