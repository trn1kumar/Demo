package com.smeface.cart.factory;

import com.smeface.cart.status.entity.OrderStatus;

public class OrderStatusImpl implements FactoryInterface<Object> {

	@Override
	public Object returnObject() {
		return new OrderStatus.CartOrderStageBuilder().build();
	}

}
