package com.smeface.servcie;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.smeface.cart.dao.CartDao;
import com.smeface.cart.dto.QuotationPDF;
import com.smeface.cart.entity.CartItem;
import com.smeface.cart.entity.QuotationFile;
import com.smeface.cart.entity.RecievdBusinessInterest;
import com.smeface.cart.exception.CustomException;
import com.smeface.cart.repository.CartItemRepo;
import com.smeface.cart.repository.RecieveBusinessInterestRepo;
import com.smeface.cart.service.CartItemService;
import com.smeface.cart.status.entity.OrderStatus;
import com.smeface.cart.status.entity.SecondStage;
import com.smeface.cart.util.UpdateAtrribute;

import net.sf.jasperreports.engine.JRException;

@Service
public class SMEQuotationServiceImpl implements SMEQuotationService {

	@Autowired
	private RecieveBusinessInterestRepo recieveBusinessInterestRepo;

	@Autowired
	private CartItemService cartItemService;

	@Autowired
	private CartItemRepo cartItemRepo;

	@Autowired
	private CartDao cartDao;
	
	@Autowired
	private NotificationService notificationService;

	@Override
	public SecondStage accept(RecievdBusinessInterest recievdBusinessInterest, QuotationFile files) throws JRException {
		try {
			RecievdBusinessInterest existingRecievdBusinessInterest = this.checkStatus(recievdBusinessInterest);
			CartItem currentItem = new CartItem();
			currentItem.setOrderStatus(new OrderStatus.CartOrderStageBuilder().build());
			QuotationFile file =null;
			if(recievdBusinessInterest.getQuotationType().equals("MANUAL") && files == null) {
					
			}else {
				 file = this.generateQuotation(recievdBusinessInterest, files);
				 recievdBusinessInterest.getOrderStatus().setQuotationFileLocation(file.getFileLocation());
				 currentItem.getOrderStatus().setQuotationFileLocation(file.getFileLocation());
			}
			
			recievdBusinessInterest.getOrderStatus().setCurrentStatus("Quotation Sent");
			UpdateAtrribute.copyNonNullProperties(recievdBusinessInterest.getOrderStatus(),
					existingRecievdBusinessInterest.getOrderStatus());

			this.saveData(existingRecievdBusinessInterest);
			CartItem oldCartItem = this.getUserAction(existingRecievdBusinessInterest);
			currentItem.getOrderStatus().setCurrentStatus("Quotation Received");
			currentItem.getOrderStatus().setRemark(recievdBusinessInterest.getOrderStatus().getRemark());
			UpdateAtrribute.copyNonNullProperties(currentItem.getOrderStatus(), oldCartItem.getOrderStatus());
			this.saveCartItemData(oldCartItem);
			SecondStage secondStage = new SecondStage.SecondStageBuilder().build();
			if(file!=null) {
				secondStage.setQuotationFile(file.getFileLocation());
			}
			secondStage.setMessageCenter(recievdBusinessInterest.getOrderStatus().getRemark());
			notificationService.scheduleNotification(Arrays.asList(oldCartItem),"QUOTATION",null);
			return secondStage;

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}

	}

	public QuotationFile generateQuotation(RecievdBusinessInterest recievdBusinessInterest, QuotationFile file)
			throws JRException {
		if (recievdBusinessInterest.isQuotationGenerated()) {
			if (recievdBusinessInterest.getQuotationType().equals("MANUAL")) {
				
				// delete generated quotation from content server
			} else {
				file = new QuotationFile();
				file.setFileLocation(recievdBusinessInterest.getQuotationPDF().stream()/*.filter(a -> a.isSelected())*/
						.findFirst().get().getFileLocation());
			}
		} else {
			if (recievdBusinessInterest.getQuotationType().equals("DEFAULT")) {
				QuotationPDF pdf = cartItemService.generateQuotation(recievdBusinessInterest.getUuid());
				file = new QuotationFile();
				file.setFileLocation(pdf.getFileLocation());
			}
		}
		return file;
	}

	@Override
	public void reject(RecievdBusinessInterest recievdBusinessInterest) {
		try {
			RecievdBusinessInterest existingRecievdBusinessInterest = this.checkStatus(recievdBusinessInterest);
			existingRecievdBusinessInterest.getOrderStatus().setCurrentStatus("BI closed");
			existingRecievdBusinessInterest.getOrderStatus()
					.setRejectRemark(recievdBusinessInterest.getOrderStatus().getRejectRemark());
			existingRecievdBusinessInterest.setRejectStatus(true);
			this.saveData(existingRecievdBusinessInterest);
			CartItem oldCartItem = this.getUserAction(existingRecievdBusinessInterest);
			oldCartItem.getOrderStatus().setCurrentStatus("BI closed");
			oldCartItem.getOrderStatus().setRejectRemark(recievdBusinessInterest.getOrderStatus().getRejectRemark());
			oldCartItem.setRejectStatus(true);
			this.saveCartItemData(oldCartItem);

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}

	}

	@Override
	public void revise(RecievdBusinessInterest recievdBusinessInterest, QuotationFile file) {
		try {
			RecievdBusinessInterest existingRecievdBusinessInterest = this.checkStatus(recievdBusinessInterest);
			existingRecievdBusinessInterest.setOrderStatus(new OrderStatus.CartOrderStageBuilder()
					.currentStatus("Revised")
					.quotationFileLocation(existingRecievdBusinessInterest.getOrderStatus().getQuotationFileLocation())
					.remark(existingRecievdBusinessInterest.getOrderStatus().getRemark()).build());
			this.saveData(existingRecievdBusinessInterest);
			CartItem oldCartItem = this.getUserAction(existingRecievdBusinessInterest);
			oldCartItem.setOrderStatus(new OrderStatus.CartOrderStageBuilder().currentStatus("Revised")
					.quotationFileLocation(file.getFileLocation())
					.remark(existingRecievdBusinessInterest.getOrderStatus().getRemark()).build());
			this.saveCartItemData(oldCartItem);

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}

	}

	@Override
	public RecievdBusinessInterest getQuotation(String uuid) {

		try {
			RecievdBusinessInterest recievdBusinessInterest = recieveBusinessInterestRepo
					.findByUuidAndRejectStatus(uuid, false);
			if (recievdBusinessInterest != null) {
				return recievdBusinessInterest;
			} else {
				throw new CustomException("Proudct details mismatch", HttpStatus.CONFLICT);
			}

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}
	}

	@Override
	public void confirmOrder(RecievdBusinessInterest recievdBusinessInterest) {

		try {
			RecievdBusinessInterest existingRecievdBusinessInterest = this.checkStatus(recievdBusinessInterest);
			existingRecievdBusinessInterest.getOrderStatus().setCurrentStatus("PO Confirmed");
			existingRecievdBusinessInterest.setRejectStatus(true);
			this.saveData(existingRecievdBusinessInterest);

			CartItem oldCartItem = this.getUserAction(existingRecievdBusinessInterest);
			oldCartItem.getOrderStatus().setCurrentStatus("PO Confirmed");
			oldCartItem.setRejectStatus(true);
			this.saveCartItemData(oldCartItem);
			notificationService.scheduleNotification(Arrays.asList(oldCartItem),"CONFIRM_ORDER",null);
		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}

	}

	private void saveData(RecievdBusinessInterest businessInterest) {
		try {
			cartDao.saveRecievedItem(businessInterest);
		} catch (CustomException e) {
			throw new CustomException("Error while saving RecievdBusinessInterest data into DB",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private void saveCartItemData(CartItem cartItem) {
		try {
			cartDao.saveCartItem(cartItem);
		} catch (CustomException e) {
			throw new CustomException("Error while saving RecievdBusinessInterest data into DB",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private CartItem getUserAction(RecievdBusinessInterest recievdBusinessInterest) {

		CartItem cartItem = cartItemRepo.findByBusinessInterestUUIDAndUserUUIdAndIsActiveAndRejectStatus(
				recievdBusinessInterest.getBusinessInterestUUID(), recievdBusinessInterest.getUserUUID(), true, false);
		if (cartItem != null) {
			return cartItem;
		} else {
			return null;
		}

	}

	public RecievdBusinessInterest checkStatus(RecievdBusinessInterest recievdBusinessInterest) {
		try {

			RecievdBusinessInterest oldRecievdBusinessInterest = recieveBusinessInterestRepo
					.findByUuidAndRejectStatus(recievdBusinessInterest.getUuid(), false);
			if (oldRecievdBusinessInterest != null) {

				return oldRecievdBusinessInterest;
			} else {
				throw new CustomException("Recieve interest not found with uuid " + recievdBusinessInterest.getUuid(),
						HttpStatus.NOT_FOUND);
			}
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
