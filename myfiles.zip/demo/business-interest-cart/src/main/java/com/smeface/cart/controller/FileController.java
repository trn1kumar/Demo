package com.smeface.cart.controller;

import java.io.IOException;

import org.glassfish.jersey.media.multipart.FormDataParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.smeface.cart.constant.APIList;
import com.smeface.cart.constant.BusinessInterestStatus;
import com.smeface.cart.dto.QuotationPDF;
import com.smeface.cart.entity.QuotationFile;
import com.smeface.cart.service.CartItemService;
import com.smeface.cart.util.CustomHttpResponse;
import com.smeface.cart.util.SendFilesToContentServer;

import net.sf.jasperreports.engine.JRException;

@RestController
@RequestMapping(APIList.BASE_URL)
public class FileController {

	@Autowired
	private SendFilesToContentServer sendfiles;

	@Autowired
	private CartItemService cartItemService;

	@PostMapping("/{sUuid}/upload")
	public ResponseEntity<?> smeUpload(@FormDataParam("files") MultipartFile files, @PathVariable String sUuid)
			throws IOException {
		QuotationFile images = null;
		if (files != null) {
			images = sendfiles.sendFileToContentServer(files,
					BusinessInterestStatus.QUOTATION.replace("{sUuid}", sUuid));
		}
		return new ResponseEntity<>(images, HttpStatus.OK);
	}

	@GetMapping("/quotation-gen/{cartId}")
	public ResponseEntity<?> QuotationGeneration(@PathVariable("cartId") String cartId) throws JRException {
		QuotationPDF  quotationFile = cartItemService.generateQuotation(cartId);
		return ResponseEntity.ok()
				.body(new CustomHttpResponse<>("Quotation generated successfully", HttpStatus.CREATED, quotationFile));
	}

	@PostMapping("/{userUUID}/user-upload")
	public ResponseEntity<?> userUpload(@FormDataParam("files") MultipartFile files, @PathVariable String userUUID)
			throws IOException {
		QuotationFile images = null;
		if (files != null) {
			images = sendfiles.sendFileToContentServer(files,
					BusinessInterestStatus.USER_QUOTATION.replace("{uuid}", userUUID));
		}
		return new ResponseEntity<>(images, HttpStatus.OK);
	}
}