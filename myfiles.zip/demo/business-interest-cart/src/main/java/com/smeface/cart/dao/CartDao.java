package com.smeface.cart.dao;

import java.util.List;

import com.smeface.cart.entity.Cart;
import com.smeface.cart.entity.CartItem;
import com.smeface.cart.entity.RecievdBusinessInterest;

public interface CartDao {

	public void save(Cart cart);
	
	public List<CartItem> getCartItem(String userId, int page);
	
	public int getSentCount(String userId);
	
	public int getRecievedCount(String userId);
	
	public List<RecievdBusinessInterest> getRecieveItem(String userId, int page);
	
	public void saveRecievedItem(RecievdBusinessInterest recievdBusinessInterest);
	
	public void saveCartItem(CartItem cartItem);
	
	public RecievdBusinessInterest getRecieveInterest(String uid);

}
