package com.smeface.cart.util;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.smeface.cart.exception.CustomException;
import com.smeface.cart.securityconfiguration.Constants;
import com.smeface.cart.securityconfiguration.JwtTokenUtil;

import io.jsonwebtoken.Claims;

@Component
public class HttpRequestParser {

	@Autowired
	private HttpServletRequest httpRequest;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	private Claims getClaims() {
		String header = httpRequest.getHeader(Constants.HEADER_STRING);
		String authToken = header.replace(Constants.TOKEN_PREFIX, "");
		return jwtTokenUtil.getAllClaimsFromToken(authToken);
	}

	public String getUserUUID() {
		String userUUID = (String) this.getClaims().get(Constants.USER_ID);
		if (StringUtils.isNotBlank(userUUID)) {
			return userUUID;
		} else {
			throw new CustomException("UserUUID cannot be null or empty", HttpStatus.BAD_REQUEST);
		}

	}

	public String getSuuid() {
		String sUuid = (String) this.getClaims().get(Constants.SME_ID);
		if (StringUtils.isNotBlank(sUuid)) {
			return sUuid;
		} else {
			throw new CustomException("sUuid cannot be null or empty", HttpStatus.BAD_REQUEST);
		}
	}

	public String getUserName() {
		return (String) this.getClaims().get(Constants.FIRST_NAME);
	}

	public boolean isSME() {
		String userType = (String) this.getClaims().get(Constants.USER_TYPE);
		return userType.equals("SME");
	}

	public String getHeader() {
		return httpRequest.getHeader(Constants.HEADER_STRING);
	}

	public HttpHeaders getCurrentReqHeader() {
		HttpHeaders headers = new HttpHeaders();

		String header = httpRequest.getHeader(Constants.HEADER_STRING);
		headers.set(Constants.HEADER_STRING, header);

		return headers;
	}
}