package com.smeface.cart.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Analyzer;
import org.hibernate.search.annotations.Field;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@Table(name = "CartAttribute")
@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler", "nameCartId" })
public class BiAttributeMapper implements Serializable {

	private static final long serialVersionUID = -2062600309388511331L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long nameCartId;

	@Column(name = "ItemDisplayName")
	@Field(analyze = Analyze.YES)
	@Analyzer(definition = "customanalyzer")
	private String itemDisplayName;

	@Column(name = "ItemURL")
	private String itemURL;

	@Transient
	private double gst;
	@Transient
	private String termsAndCondition;
	@Transient
	private Integer businessInterestQuantity;
	@Transient
	private Double itemActualPrice;
	@Transient
	private int discount;
	
	@Transient
	private String description;
	@Transient
	private String userName;

	@Column(name = "sUuid")
	private String sUuid;

	@Column(name = "smeName")
	private String smeName;

	@Column(name = "priceUnit")
	private String priceUnit;

	@Column(name = "businessInterestUUID")
	private String businessInterestUUID;

	@Column(name = "price")
	private Double discountedPrice;

	@Column(name = "itemImage")
	private String itemImage;

	public BiAttributeMapper() {
		super();
	}

	public String getItemDisplayName() {
		return itemDisplayName;
	}

	public void setItemDisplayName(String itemDisplayName) {
		this.itemDisplayName = itemDisplayName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPriceUnit() {
		return priceUnit;
	}

	public void setPriceUnit(String priceUnit) {
		this.priceUnit = priceUnit;
	}

	public Integer getBusinessInterestQuantity() {
		return businessInterestQuantity;
	}

	public void setBusinessInterestQuantity(Integer businessInterestQuantity) {
		this.businessInterestQuantity = businessInterestQuantity;
	}

	public String getItemURL() {
		return itemURL;
	}

	public void setItemURL(String itemURL) {
		this.itemURL = itemURL;
	}

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public String getSmeName() {
		return smeName;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public String getBusinessInterestUUID() {
		return businessInterestUUID;
	}

	public void setBusinessInterestUUID(String businessInterestUUID) {
		this.businessInterestUUID = businessInterestUUID;
	}

	public Double getDiscountedPrice() {
		return discountedPrice;
	}

	public void setDiscountedPrice(Double price) {
		this.discountedPrice = price;
	}

	public Long getNameCartId() {
		return nameCartId;
	}

	public void setNameCartId(Long nameCartId) {
		this.nameCartId = nameCartId;
	}

	public String getItemImage() {
		return itemImage;
	}

	public void setItemImage(String itemImage) {
		this.itemImage = itemImage;
	}

	public double getGst() {
		return gst;
	}

	public void setGst(double gst) {
		this.gst = gst;
	}

	public String getTermsAndCondition() {
		return termsAndCondition;
	}

	public void setTermsAndCondition(String termsAndCondition) {
		this.termsAndCondition = termsAndCondition;
	}

	public Double getItemActualPrice() {
		return itemActualPrice;
	}

	public void setItemActualPrice(Double itemActualPricePrice) {
		this.itemActualPrice = itemActualPricePrice;
	}

	public int getDiscount() {
		return discount;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}

}
