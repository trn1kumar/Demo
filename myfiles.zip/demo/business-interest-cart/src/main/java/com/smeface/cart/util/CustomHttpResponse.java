package com.smeface.cart.util;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class CustomHttpResponse<T> {

	private String message;
	private int code;
	private HttpStatus status;
	private boolean error;
	private T data;
	private CustomErrorResponse errorResponse;

	public CustomHttpResponse() {
		super();
	}

	public CustomHttpResponse(String message, HttpStatus status, T data) {
		super();
		this.message = message;
		this.status = status;
		this.data = data;
	}

	public CustomHttpResponse(String message, HttpStatus status) {
		super();
		this.message = message;
		this.status = status;
		this.code = status.value();
	}

	public CustomErrorResponse getErrorResponse() {
		return errorResponse;
	}

	public void setErrorResponse(CustomErrorResponse errorResponse) {
		this.errorResponse = errorResponse;
	}

	public String getMessage() {
		return message;
	}

	public int getCode() {
		return code;
	}

	public HttpStatus getStatus() {
		return status;
	}

	public boolean isError() {
		return error;
	}

	public T getData() {
		return data;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}

	public void setError(boolean error) {
		this.error = error;
	}

	public void setData(T data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "CustomHttpResponse [message=" + message + ", code=" + code + ", status=" + status + ", error=" + error
				+ ", data=" + data + "]";
	}

}
