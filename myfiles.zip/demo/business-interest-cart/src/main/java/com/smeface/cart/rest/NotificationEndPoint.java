package com.smeface.cart.rest;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;

import com.smeface.cart.exception.CustomException;
import com.smeface.cart.model.notification.EmailEvent;
import com.smeface.cart.model.notification.SchedulerJobInfo;
import com.smeface.cart.model.notification.SmsEvent;
import com.smeface.cart.util.CustomHttpResponse;



public class NotificationEndPoint {

	private Client client;
	private String endPoint;
	private String smsEndPointPath;
	private String emailEndPointPath;
	private String scheduleJobPath;
	private String unscheduleJobPath;

	Logger log = LogManager.getLogger();

	public NotificationEndPoint(Client client, String endPoint, String smsEndPointPath, String emailEndPointPath,
			String scheduleJobPath, String unscheduleJobPath) {
		this.client = client;
		this.endPoint = endPoint;
		this.smsEndPointPath = smsEndPointPath;
		this.emailEndPointPath = emailEndPointPath;
		this.scheduleJobPath = scheduleJobPath;
		this.unscheduleJobPath = unscheduleJobPath;
	}

	private void logEndpointDetail() {
		log.info("Notification Endpoint Detail: " + this.toString());
	}
	
	
	public <T> void sendNotification(T t) {

		if (t instanceof SmsEvent) {
			SmsEvent sms = (SmsEvent) t;
			Response response = client.target(endPoint).path(smsEndPointPath)
					.request(MediaType.APPLICATION_JSON).post(Entity.entity(sms, MediaType.APPLICATION_JSON));

			log.info(response);

		} else if (t instanceof EmailEvent) {
			EmailEvent email = (EmailEvent) t;
			Response response = client.target(endPoint).path(emailEndPointPath)
					.request(MediaType.APPLICATION_JSON).post(Entity.entity(email, MediaType.APPLICATION_JSON));
			log.info(response);
		}
	}

	@SuppressWarnings("rawtypes")
	public void scheduleJob(SchedulerJobInfo schedulerJobInfo) {

		Response response = null;
		CustomHttpResponse customResponse = null;

		logEndpointDetail();
		try {
			response = client.target(endPoint).path(scheduleJobPath).request(MediaType.APPLICATION_JSON)
					.post(Entity.entity(schedulerJobInfo, MediaType.APPLICATION_JSON));
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);

		Integer statusCode = response.getStatus();
		if (statusCode == HttpStatus.OK.value()) {
			try {
				customResponse = response.readEntity(new GenericType<CustomHttpResponse>() {
				});
			} catch (Exception e) {
				throwEntityResponseReadException(e);
			}
			if (customResponse.isError()) {
				throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
			}
		} else {
			throwInvalidResponseException(statusCode);
		}
	}

	@SuppressWarnings("rawtypes")
	public void unscheduleJob(String jobName) {

		Response response = null;
		CustomHttpResponse customResponse = null;

		logEndpointDetail();
		try {
			response = client.target(endPoint).path(unscheduleJobPath).queryParam("jobName", jobName)
					.request(MediaType.APPLICATION_JSON).put(Entity.entity("", MediaType.APPLICATION_JSON));
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);

		Integer statusCode = response.getStatus();
		if (statusCode == HttpStatus.OK.value()) {
			try {
				customResponse = response.readEntity(new GenericType<CustomHttpResponse>() {
				});
			} catch (Exception e) {
				throwEntityResponseReadException(e);
			}
			if (customResponse.isError()) {
				throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
			}
		} else {
			throwInvalidResponseException(statusCode);
		}
	}

	private void throwEntityResponseReadException(Exception e) {
		throw new CustomException("Exception at read response from Notification Module. Message: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private void throwInvalidResponseException(int statusCode) {
		throw new CustomException("Invalid Response from Notification Module: ", HttpStatus.resolve(statusCode));
	}

	private void throwConnectionRefusedException(Exception e) {
		throw new CustomException("Couldn't Connect to Notification module, Exception: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private void logResponse(Response response) {
		log.info("Response From Notification Module : " + response);
	}

	@Override
	public String toString() {
		return "NotificationEndPoint [endPoint=" + endPoint + ", smsEndPointPath=" + smsEndPointPath
				+ ", emailEndPointPath=" + emailEndPointPath + ", scheduleJobPath=" + scheduleJobPath + "]";
	}

}
