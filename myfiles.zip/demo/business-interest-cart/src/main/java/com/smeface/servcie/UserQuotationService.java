package com.smeface.servcie;

import com.smeface.cart.entity.CartItem;
import com.smeface.cart.entity.QuotationFile;
import com.smeface.cart.status.entity.ThirdStage;

public interface UserQuotationService {

	public void revise(CartItem cartItem, QuotationFile quotationFile);

	public ThirdStage accept(CartItem cartItem, QuotationFile quotationFile);

	public void reject(CartItem cartItem);

	public CartItem getQuotation(String uuid);
	

}
