package com.smeface.cart.constant;

public class NotificationConstants {

	public static final String BI_GENERATION_JOBNAME_PREFIX = "BIGeneration_";
	public static final String QUOTATION_RECEIVED_JOBNAME_PREFIX = "QuotationReceived_";
	public static final String PURCHASE_ORDER_RECEIVED_JOBNAME_PREFIX = "PurchaseOrderReceived_";

	public static final String BI_GENERATION_TEMPLATES = "interestGeneration.html";
	public static final String QUOTATION_RECEIVED_TEMPLATES = "quotationReceived.html";
	public static final String PURCHASE_ORDER_RECEIVED_TEMPLATES = "purchaseOrderReceived.html";
	public static final String ORDER_CONFIRMED_TEMPLATES = "orderConfirmed.html";
}
