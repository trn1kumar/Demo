package com.smeface.audit;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.AuditorAware;

import com.smeface.cart.util.HttpRequestParser;

public class AuditorAwareImpl implements AuditorAware<String> {

	@Autowired
	private HttpRequestParser requestParser;

	@Override
	public Optional<String> getCurrentAuditor() {
		
		return Optional.of(requestParser.getUserName());
	}
}
