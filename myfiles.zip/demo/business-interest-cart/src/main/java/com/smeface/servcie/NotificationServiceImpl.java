package com.smeface.servcie;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.smeface.cart.configurtation.PropertyValues;
import com.smeface.cart.constant.CartConstants;
import com.smeface.cart.constant.NotificationConstants;
import com.smeface.cart.dto.BiAttributeMapper;
import com.smeface.cart.dto.ProductDTO;
import com.smeface.cart.dto.SMEInformationDto;
import com.smeface.cart.dto.SMEServiceDTO;
import com.smeface.cart.dto.UserDto;
import com.smeface.cart.entity.CartItem;
import com.smeface.cart.entity.QuotationFormat;
import com.smeface.cart.exception.CustomException;
import com.smeface.cart.mapper.NameConverter;
import com.smeface.cart.model.notification.EmailEvent;
import com.smeface.cart.model.notification.SchedulerJobInfo;
import com.smeface.cart.model.notification.SmsEvent;
import com.smeface.cart.rest.NotificationEndPoint;
import com.smeface.cart.rest.ProductRestEndPoint;
import com.smeface.cart.rest.ServiceRestEndPoint;
import com.smeface.cart.rest.SmeServerEndpoint;
import com.smeface.cart.rest.UserServerEndpoint;

@Service
public class NotificationServiceImpl extends NotificationConstants implements NotificationService {

	private Logger log = LogManager.getLogger();

	@Autowired
	private ProductRestEndPoint productRestEndPoint;

	@Autowired
	private NotificationEndPoint notificationEndpoint;

	@Autowired
	private UserServerEndpoint userServerEndpoint;

	@Autowired
	private ServiceRestEndPoint serviceRestEndPoint;

	@Autowired
	private SmeServerEndpoint smeServerEndpoint;

	@Autowired
	private PropertyValues propertyValues;

	@Autowired
	private TemplateEngine templateEngine;

	@Autowired
	private NameConverter nameConverter;

	@Async
	@Override
	public void scheduleNotification(List<CartItem> cartItems, String stage, String token) {

		ProductDTO product = null;
		BiAttributeMapper mapper = null;
		SMEServiceDTO serviceDTO = null;
		SMEInformationDto smeInformationDto = null;
		UserDto userDto = null;
		String quotationFileLocation = null;
		String purchaseOrderFileLocation = null;
		for (CartItem item : cartItems) {
			quotationFileLocation = item.getOrderStatus().getQuotationFileLocation();
			purchaseOrderFileLocation = item.getOrderStatus().getPurchaseOrderLocation();
			if (item.getProvider().equals(CartConstants.BusinessInterest.PRODUCT)) {
				product = productRestEndPoint.getProduct(item.getBusinessInterestUUID(), false, token);
				smeInformationDto = smeServerEndpoint.getSme(product.getsUuid());
				userDto = userServerEndpoint.getUser(item.getUserUUId());
				mapper = nameConverter.converter(product, item.getBusinessInterestQuantity());
			} else {
				serviceDTO = serviceRestEndPoint.getService(item.getBusinessInterestUUID(), false, token);
				mapper = nameConverter.converter(serviceDTO, item.getBusinessInterestQuantity());
				smeInformationDto = smeServerEndpoint.getSme(serviceDTO.getsUuid());
				userDto = userServerEndpoint.getUser(item.getUserUUId());
			}

		}

		EmailEvent emailEvent = null;
		SmsEvent smsEvent = null;
		String smeEmail = smeInformationDto.getContactEmail();
		String userEmail = userDto.getUserEmail();

		try {

			// Sms notification
			QuotationFormat setFeild = nameConverter.converter(mapper, smeInformationDto, userDto);
			setFeild.setOrderId(cartItems.get(0).getUuid());
			switch (stage) {

			case "BI_GENERATION":
				if (smeEmail != null) {
					Context context = new Context();
					context.setVariable("homeUrl", propertyValues.getBaseUrl());
					context.setVariable("cartUrl", propertyValues.getCartUrl());
					context.setVariable("contentServerUrl", propertyValues.getContentServerUrl());
					context.setVariable("cartRest", setFeild);
					String mailPage = templateEngine.process(BI_GENERATION_TEMPLATES, context);
					String mailSub = propertyValues.getBiGenerationEmailSub();
					emailEvent = new EmailEvent(smeEmail, mailSub, mailPage);
				}
				if (smeInformationDto.getContactPhone() != null) {
					String smsMsg = propertyValues.getBiGenerationSmsMsg()
							.replace("{userName}", userDto.getUserFullName())
							.replace("{productName}", mapper.getItemDisplayName())
							.replace("{orderId}", setFeild.getOrderId());
					smsEvent = new SmsEvent(smeInformationDto.getContactPhone(), smsMsg);
				}

				scheduleNotification(BI_GENERATION_JOBNAME_PREFIX + setFeild.getOrderId(), smsEvent, emailEvent);
				break;
			case "QUOTATION":
				unscheduleNotification(BI_GENERATION_JOBNAME_PREFIX + setFeild.getOrderId());

				if (userEmail != null) {
					Context context = new Context();
					context.setVariable("homeUrl", propertyValues.getBaseUrl());
					context.setVariable("cartUrl", propertyValues.getCartUrl());
					context.setVariable("contentServerUrl", propertyValues.getContentServerUrl());
					context.setVariable("cartRest", setFeild);
					String mailPage = templateEngine.process(QUOTATION_RECEIVED_TEMPLATES, context);
					String mailSub = propertyValues.getQuotationReceivedEmailSub().replace("{smename}",
							setFeild.getSmeName());
					emailEvent = new EmailEvent(userEmail, mailSub, mailPage, quotationFileLocation);

				}
				if (userDto.getUserMobile() != null) {

					String smsMsg = propertyValues.getQuotationReceivedSmsMsg()
							.replace("{orderId}", setFeild.getOrderId())
							.replace("{productName}", setFeild.getItemName());
					smsEvent = new SmsEvent(userDto.getUserMobile(), smsMsg);
				}

				scheduleNotification(QUOTATION_RECEIVED_JOBNAME_PREFIX + setFeild.getOrderId(), smsEvent, emailEvent);
				break;

			case "PURCHASE_ORDER":
				unscheduleNotification(QUOTATION_RECEIVED_JOBNAME_PREFIX + setFeild.getOrderId());
				if (smeEmail != null) {

					Context context = new Context();
					context.setVariable("homeUrl", propertyValues.getBaseUrl());
					context.setVariable("cartUrl", propertyValues.getCartUrl());
					context.setVariable("contentServerUrl", propertyValues.getContentServerUrl());
					context.setVariable("cartRest", setFeild);
					String mailPage = templateEngine.process(PURCHASE_ORDER_RECEIVED_TEMPLATES, context);
					String mailSub = propertyValues.getPurchaseOrderReceivedEmailSub().replace("{userName}",
							userDto.getUserFullName());
					emailEvent = new EmailEvent(smeEmail, mailSub, mailPage, purchaseOrderFileLocation);

				}
				if (smeInformationDto.getContactPhone() != null) {
					String smsMsg = propertyValues.getPurchaseOrderReceivedSmsMsg()
							.replace("{userName}", userDto.getUserFullName())
							.replace("{orderId}", setFeild.getOrderId())
							.replace("{productName}", setFeild.getItemName());
					smsEvent = new SmsEvent(smeInformationDto.getContactPhone(), smsMsg);
				}
				scheduleNotification(PURCHASE_ORDER_RECEIVED_TEMPLATES + setFeild.getOrderId(), smsEvent, emailEvent);
				break;
			case "CONFIRM_ORDER":
				unscheduleNotification(PURCHASE_ORDER_RECEIVED_TEMPLATES + setFeild.getOrderId());
				if (userEmail != null) {
					Context context = new Context();
					context.setVariable("homeUrl", propertyValues.getBaseUrl());
					context.setVariable("cartUrl", propertyValues.getCartUrl());
					context.setVariable("contentServerUrl", propertyValues.getContentServerUrl());
					context.setVariable("cartRest", setFeild);
					String mailPage = templateEngine.process(ORDER_CONFIRMED_TEMPLATES, context);

					String mailSub = propertyValues.getConfirmOrderEmailSub();
					emailEvent = new EmailEvent(userEmail, mailSub, mailPage);
				}
				if (userDto.getUserMobile() != null) {
					String smsMsg = propertyValues.getConfirmOrderSmsMsg().replace("{smename}", setFeild.getSmeName())
							.replace("{orderId}", setFeild.getOrderId())
							.replace("{productName}", setFeild.getItemName());
					smsEvent = new SmsEvent(userDto.getUserMobile(), smsMsg);
				}
				List<Object> events = new ArrayList<>();
				events.add(smsEvent);
				events.add(emailEvent);
				// this is confirmed order notification so notify directly one time
				sendEventsNotifications(events);
				break;
			}

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}
	}

	private void scheduleNotification(String jobName, SmsEvent smsEvent, EmailEvent emailEvent) {
		try {
			SchedulerJobInfo schedulerJobInfo = new SchedulerJobInfo();
			schedulerJobInfo.setJobName(jobName);
			schedulerJobInfo.setSchedulerGroup(propertyValues.getSchedulerGroupName());
			schedulerJobInfo.setSmsEvent(smsEvent);
			schedulerJobInfo.setEmailEvent(emailEvent);

			notificationEndpoint.scheduleJob(schedulerJobInfo);
		} catch (Exception e) {
			log.error("can't schedule job " + jobName + " Exception: " + e.getMessage());
		}
	}

	@Async
	private void unscheduleNotification(String jobName) {
		try {
			notificationEndpoint.unscheduleJob(jobName);
		} catch (Exception e) {
			log.error("can't unschedule job " + jobName + " Exception: " + e.getMessage());
		}
	}

	private void sendEventsNotifications(List<Object> events) {
		events.parallelStream().forEach(event -> notificationEndpoint.sendNotification(event));
	}
}
