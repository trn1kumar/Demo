package com.smeface.cart.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.smeface.cart.constant.CartConstants;
import com.smeface.cart.dto.UserDto;
import com.smeface.cart.entity.Cart;
import com.smeface.cart.entity.RecievdBusinessInterest;
import com.smeface.cart.rest.UserServerEndpoint;
import com.smeface.cart.status.entity.OrderStatus;

@Component
public class RecieveBusinessInterestModel {

	@Autowired
	private UserServerEndpoint userServerEndpoint;

	public RecievdBusinessInterest setValues(Cart cartRequest) {

		RecievdBusinessInterest recievdBusinessInterest = new RecievdBusinessInterest();

		Integer businessInterestQuantity = cartRequest.getCartItem().parallelStream()
				.filter(x -> x.getBusinessInterestQuantity() >= 1).findFirst().get().getBusinessInterestQuantity();
		UserDto userDto = getUserDetails(cartRequest.getUserUuid());
		recievdBusinessInterest.setBusinessInterestQuantity(businessInterestQuantity);
		recievdBusinessInterest
				.setSmeId(cartRequest.getCartItem().stream().findAny().get().getCartAttribute().getsUuid());
		recievdBusinessInterest.setUserUUID(cartRequest.getUserUuid());
		recievdBusinessInterest.setViewStatus(false);
		recievdBusinessInterest.setOrderStatus(
				new OrderStatus.CartOrderStageBuilder().currentStatus(CartConstants.SMEStages.RECEIVE).build());
		recievdBusinessInterest.setCartAttribute(cartRequest.getCartItem().stream().findAny().get().getCartAttribute());
		recievdBusinessInterest.setUuid(cartRequest.getCartItem().stream().findAny().get().getUuid());
		recievdBusinessInterest.setUserName(userDto.getUserFullName());
		recievdBusinessInterest.setIsActive(cartRequest.getIsActive());
		recievdBusinessInterest.setProvider(cartRequest.getCartItem().stream().findAny().get().getProvider());

		recievdBusinessInterest
				.setBusinessInterestUUID(cartRequest.getCartItem().stream().findAny().get().getBusinessInterestUUID());

		return recievdBusinessInterest;
	}

	private UserDto getUserDetails(String uuid) {

		return userServerEndpoint.getUser(uuid);
	}
}
