package com.smeface.cart.configurtation;

import javax.annotation.Resource;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.smeface.cart.rest.ContentServerEndpoint;
import com.smeface.cart.rest.NotificationEndPoint;
import com.smeface.cart.rest.PricingEndpoint;
import com.smeface.cart.rest.ProductRestEndPoint;
import com.smeface.cart.rest.ServiceRestEndPoint;
import com.smeface.cart.rest.SmeServerEndpoint;
import com.smeface.cart.rest.UserServerEndpoint;

@Configuration
@PropertySource(value = { "file:${location}/business_interest_${env}.properties" })
public class RestServerConfiguration {

	@Resource
	private Environment environment;

	@Bean
	public ContentServerEndpoint contentConfiguration() {
		Client client = ClientBuilder.newBuilder().register(MultiPartFeature.class).build();

		String contentServerEndPoint = environment.getRequiredProperty("contentserver.endpoint");
		String uploadMultipleFiles = environment.getRequiredProperty("files.endpoint.path");
		String deleteFile = environment.getRequiredProperty("deletefiles.endpoint.path");
		return new ContentServerEndpoint(client, contentServerEndPoint, uploadMultipleFiles, deleteFile);
	}

	@Bean
	public SmeServerEndpoint smeServerEndpoint() {

		Client client = ClientBuilder.newClient();
		String smeEndPointUrl = environment.getRequiredProperty("sme.endpoint");
		String getSmeUser = environment.getRequiredProperty("getsmeuser.path");
		return new SmeServerEndpoint(client, getSmeUser, smeEndPointUrl);
	}

	@Bean
	public ProductRestEndPoint productServerEndpoint() {

		Client client = ClientBuilder.newClient();
		String productEndPointUrl = environment.getRequiredProperty("product.endpoint");
		String getProductPath = environment.getRequiredProperty("product.path");
		String getBiPath = environment.getRequiredProperty("product.bi.count");
		return new ProductRestEndPoint(client, productEndPointUrl, getProductPath, getBiPath);
	}

	@Bean
	public ServiceRestEndPoint serviceServerEndpoint() {

		Client client = ClientBuilder.newClient();
		String productEndPointUrl = environment.getRequiredProperty("service.endpoint");
		String getProductPath = environment.getRequiredProperty("service.path");
		String getBiPath = environment.getRequiredProperty("service.bi.count");
		return new ServiceRestEndPoint(client, productEndPointUrl, getProductPath, getBiPath);
	}

	@Bean
	public UserServerEndpoint userServerEndpoint() {

		Client client = ClientBuilder.newClient();
		String smeEndPointUrl = environment.getRequiredProperty("user.endpoint");
		String getSmeUser = environment.getRequiredProperty("getuser.path");
		return new UserServerEndpoint(client, getSmeUser, smeEndPointUrl);
	}

	@Bean
	public NotificationEndPoint notificationConfiguration() {
		Client client = ClientBuilder.newClient();
		String notificationEndPoint = environment.getRequiredProperty("notification.endpoint");
		String smsEndPointPath = environment.getRequiredProperty("sms.endpoint.path");
		String emailEndPointPath = environment.getRequiredProperty("email.endpoint.path");
		String scheduleJobPath = environment.getRequiredProperty("schedule.job.path");
		String unscheduleJobPath = environment.getRequiredProperty("unschedule.job.path");

		return new NotificationEndPoint(client, notificationEndPoint, smsEndPointPath, emailEndPointPath,
				scheduleJobPath, unscheduleJobPath);
	}

	@Bean
	public PricingEndpoint pricingEndpoint() {

		Client client = ClientBuilder.newClient();
		String pricingEndpointUrl = environment.getRequiredProperty("pricing.endpoint");
		String checkCreditsPath = environment.getRequiredProperty("user.credits");

		return new PricingEndpoint(client, pricingEndpointUrl, checkCreditsPath);
	}

}
