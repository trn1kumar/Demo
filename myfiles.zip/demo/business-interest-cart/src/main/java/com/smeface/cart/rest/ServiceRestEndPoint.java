package com.smeface.cart.rest;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

import com.smeface.cart.dto.SMEServiceDTO;
import com.smeface.cart.exception.CustomException;
import com.smeface.cart.securityconfiguration.Constants;
import com.smeface.cart.util.CustomHttpResponse;

public class ServiceRestEndPoint {

	private Client client;
	private String serviceEndPointUrl;
	private String getServicePath;
	private String getBiPath;

	@Value("${service.details.path}")
	private String detailsPath;

	public ServiceRestEndPoint(Client client, String serviceEndPointUrl, String getServicePath, String getBiPath) {
		this.getServicePath = getServicePath;
		this.client = client;
		this.getBiPath = getBiPath;
		this.serviceEndPointUrl = serviceEndPointUrl;
	}

	private Logger logger = LogManager.getLogger();

	public SMEServiceDTO getService(String pUuid, boolean details, String token) {

		String path = null;
		if (details) {
			path = detailsPath.replace("{serviceUUID}", pUuid);
		} else {
			path = getServicePath.replace("{serviceUUID}", pUuid);
		}

		client = ClientBuilder.newClient();
		Response response = client.target(serviceEndPointUrl).path(path).request(MediaType.APPLICATION_JSON)
				.header(Constants.HEADER_STRING, token).get();

		CustomHttpResponse<SMEServiceDTO> serviceDTO = null;
		Integer responseCode = response.getStatus();

		if (responseCode == HttpStatus.OK.value()) {
			serviceDTO = response.readEntity(new GenericType<CustomHttpResponse<SMEServiceDTO>>() {
			});
			return serviceDTO.getData();

		} else if (responseCode == HttpStatus.NOT_FOUND.value()) {
			return null;

		} else {
			throw new CustomException(" Internal Exception occrurred while fetching service,Invalid Response: "
					+ response.getStatusInfo().getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public void updateBiCountOfProduct(String serviceId, String token) {
		try {
			String pathUrl = getBiPath.replace("{serviceUUID}", serviceId);
			Response response = client.target(serviceEndPointUrl).path(pathUrl).request(MediaType.APPLICATION_JSON)
					.header(Constants.HEADER_STRING, token).put(Entity.entity(serviceId, MediaType.APPLICATION_JSON));
			CustomHttpResponse<?> body = response.readEntity(new GenericType<CustomHttpResponse<?>>() {
			});
			if (!body.isError()) {
				logger.log(Level.ALL, "Updated service business count successfully");
			}
		} catch (CustomException e) {
			logger.log(Level.ALL, e);
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}
	}
}
