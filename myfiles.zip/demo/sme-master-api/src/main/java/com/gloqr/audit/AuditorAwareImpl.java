package com.gloqr.audit;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.Authentication;

import com.gloqr.security.context.holder.AuthenticationFacade;
import com.gloqr.security.context.holder.UserDetails;

public class AuditorAwareImpl implements AuditorAware<String> {

	@Autowired
	AuthenticationFacade authenticationFacade;

	@Override
	public Optional<String> getCurrentAuditor() {

		Authentication authentication = authenticationFacade.getAuthentication();

		if (authentication == null || !authentication.isAuthenticated()) {
			return null;
		}

		return Optional.of(((UserDetails)authentication.getPrincipal()).getSubject());

	}
}