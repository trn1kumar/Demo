package com.gloqr.component.filter;

import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;

import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.BooleanClause.Occur;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.DatabaseRetrievalMethod;
import org.hibernate.search.query.ObjectLookupMethod;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gloqr.entities.SMEInformation;

@Component(value = "categoryFilter")
public class CategoryFilterComponentImpl implements FilterComponent {

	@Autowired
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public <T> List<SMEInformation> filter(T categoriesFilterParam, int firstResult, int maxResult) {

		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(SMEInformation.class).get();

		List<Query> queryList = new LinkedList<>();
		((Set<String>) categoriesFilterParam).forEach(category -> {
			Query query = queryBuilder.bool()
					.must(queryBuilder.keyword().onField("smeCategory.categoryUrl").matching(category).createQuery())
					.must(queryBuilder.keyword().onField("active").matching(true).createQuery()).createQuery();

			queryList.add(query);
		});

		BooleanQuery.Builder booleanQuery = new BooleanQuery.Builder();
		queryList.forEach(q -> {
			booleanQuery.add(q, Occur.SHOULD);
		});
		FullTextQuery fullTextQuery = fullTextEntityManager.createFullTextQuery(booleanQuery.build(),
				SMEInformation.class);

		fullTextQuery.setFirstResult(firstResult);
		fullTextQuery.setMaxResults(maxResult);

		fullTextQuery.initializeObjectsWith(ObjectLookupMethod.SECOND_LEVEL_CACHE, DatabaseRetrievalMethod.QUERY);
		List<SMEInformation> smes = fullTextQuery.getResultList();

		return smes;

		/*
		 * List<SMEInformation> smes = new ArrayList<>();
		 * 
		 * FullTextEntityManager fullTextEntityManager =
		 * Search.getFullTextEntityManager(entityManager);
		 * 
		 * QueryBuilder queryBuilder =
		 * fullTextEntityManager.getSearchFactory().buildQueryBuilder()
		 * .forEntity(SMECategory.class).get();
		 * 
		 * List<Query> queryList = new LinkedList<Query>(); ((Set<String>)
		 * categoriesFilterParam).forEach(category->{
		 * queryList.add(queryBuilder.keyword().onFields("categoryUrl").matching(
		 * category).createQuery()); });
		 * 
		 * BooleanQuery.Builder booleanQuery = new BooleanQuery.Builder();
		 * queryList.forEach(q->{ booleanQuery.add(q, BooleanClause.Occur.SHOULD); });
		 * FullTextQuery fullTextQuery =
		 * fullTextEntityManager.createFullTextQuery(booleanQuery.build(),
		 * SMECategory.class);
		 * 
		 * fullTextQuery.setFirstResult(firstResult);
		 * fullTextQuery.setMaxResults(maxResult);
		 * 
		 * fullTextQuery.initializeObjectsWith( ObjectLookupMethod.SECOND_LEVEL_CACHE,
		 * DatabaseRetrievalMethod.QUERY); List<SMECategory> categoryResult =
		 * fullTextQuery.getResultList();
		 * 
		 * categoryResult.forEach(category->smes.addAll(category.getSmes()));
		 * 
		 * return smes;
		 */

	}
}
