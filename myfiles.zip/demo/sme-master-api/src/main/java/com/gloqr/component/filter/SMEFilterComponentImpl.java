package com.gloqr.component.filter;

import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;

import org.apache.lucene.search.BooleanClause.Occur;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Query;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.DatabaseRetrievalMethod;
import org.hibernate.search.query.ObjectLookupMethod;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gloqr.entities.SMEInformation;

@Component(value = "cityFilter")
public class SMEFilterComponentImpl implements FilterComponent {

	@Autowired
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public <T> List<SMEInformation> filter(T citiesFilterParam, int firstResult, int maxResult) {

		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(SMEInformation.class).get();

		List<Query> queryList = new LinkedList<>();
		((Set<String>) citiesFilterParam).forEach(city -> {

			Query query = queryBuilder.bool()
					.must(queryBuilder.keyword().onField("smeAddress.city").matching(city).createQuery())
					.must(queryBuilder.keyword().onField("active").matching(true).createQuery()).createQuery();

			queryList.add(query);
		});

		BooleanQuery.Builder booleanQuery = new BooleanQuery.Builder();
		queryList.forEach(q -> {
			booleanQuery.add(q, Occur.SHOULD);
		});
		FullTextQuery fullTextQuery = fullTextEntityManager.createFullTextQuery(booleanQuery.build(),
				SMEInformation.class);
		if (maxResult > 0) {
			fullTextQuery.setFirstResult(firstResult);
			fullTextQuery.setMaxResults(maxResult);
		}

		fullTextQuery.initializeObjectsWith(ObjectLookupMethod.SECOND_LEVEL_CACHE, DatabaseRetrievalMethod.QUERY);
		List<SMEInformation> smes = fullTextQuery.getResultList();

		return smes;

	}
}
