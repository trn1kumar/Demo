package com.gloqr.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.UrlMapping;
import com.gloqr.service.GloqrHomePageMasterService;

@RequestMapping(value = UrlMapping.ROOT_API)
@RestController
@CrossOrigin("*")
public class GloqrHomePageController {

	@Autowired
	GloqrHomePageMasterService smefaceMasterService;

	@GetMapping("/homepage-data")
	public ResponseEntity<?> getSMEFaceHomePageData(@RequestParam(value = "u") String userID,
			@RequestParam(value = "s") String smeId) throws InterruptedException {

		return ResponseEntity.ok(smefaceMasterService.getData(userID, smeId));
	}
}
