package com.gloqr.model.http.response;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class CustomHttpResponse<T> {

	private int code;
	private HttpStatus status;
	private boolean error;
	private String message;
	private CustomErrorResponse errorResponse;

	private T data;

	public CustomHttpResponse() {
		super();
	}

	public CustomHttpResponse(int code, HttpStatus status, String message) {
		this.code = code;
		this.status = status;
		this.message = message;
	}

	public CustomHttpResponse(boolean error, int code, HttpStatus status, String message, T data) {
		this.error = error;
		this.code = code;
		this.status = status;
		this.message = message;
		this.data = data;
	}

	public CustomHttpResponse(boolean error, int code, HttpStatus status, String message) {
		this.error = error;
		this.code = code;
		this.status = status;
		this.message = message;
	}

	public CustomErrorResponse getErrorResponse() {
		return errorResponse;
	}

	public void setErrorResponse(CustomErrorResponse errorResponse) {
		this.errorResponse = errorResponse;
	}

	public String getMessage() {
		return message;
	}

	public int getCode() {
		return code;
	}

	public HttpStatus getStatus() {
		return status;
	}

	public boolean isError() {
		return error;
	}

	public T getData() {
		return data;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}

	public void setError(boolean error) {
		this.error = error;
	}

	public void setData(T data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "CustomHttpResponse [message=" + message + ", code=" + code + ", status=" + status + ", error=" + error;
	}

}
