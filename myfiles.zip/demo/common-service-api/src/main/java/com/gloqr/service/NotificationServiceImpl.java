package com.gloqr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.gloqr.notification.EmailEvent;
import com.gloqr.rest.endpoint.NotificationEndPoint;

@Service
public class NotificationServiceImpl implements NotificationService {

	@Autowired
	private NotificationEndPoint notification;

	@Value("${email.subject}")
	private String emailSubject;

	@Value("${email.message}")
	private String emailMessage;

	@Override
	@Async
	public void sendEmail(String emailId, String userName) {
		notification.sendEmailNotification(
				new EmailEvent(emailId, emailSubject, emailMessage.replace("{userName}", userName)));
	}

}
