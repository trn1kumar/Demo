package com.gloqr.service;

public interface NotificationService {

	void sendEmail(String emailId, String userName);

}
