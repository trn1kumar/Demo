package com.gloqr.entity.services;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.gloqr.dto.ImageDto;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SMEService {

	private String serviceUUID;
	private String serviceUrlName;
	private String serviceDisplayName;
	private String smeName;
	private String sUuid;
	private PriceDetailsResponse priceDetails;
	private List<ImageDto> serviceImages;
	private Integer discount;
	private double discountedPrice;
	private boolean status;
	private boolean active;
	
	public String getServiceUUID() {
		return serviceUUID;
	}
	public String getServiceUrlName() {
		return serviceUrlName;
	}
	public String getServiceDisplayName() {
		return serviceDisplayName;
	}
	public String getSmeName() {
		return smeName;
	}
	public String getsUuid() {
		return sUuid;
	}
	public PriceDetailsResponse getPriceDetails() {
		return priceDetails;
	}
	
	public Integer getDiscount() {
		return discount;
	}
	public double getDiscountedPrice() {
		return discountedPrice;
	}
	public boolean isStatus() {
		return status;
	}
	public boolean isActive() {
		return active;
	}
	public void setServiceUUID(String serviceUUID) {
		this.serviceUUID = serviceUUID;
	}
	public void setServiceUrlName(String serviceUrlName) {
		this.serviceUrlName = serviceUrlName;
	}
	public void setServiceDisplayName(String serviceDisplayName) {
		this.serviceDisplayName = serviceDisplayName;
	}
	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}
	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}
	public void setPriceDetails(PriceDetailsResponse priceDetails) {
		this.priceDetails = priceDetails;
	}
	
	public void setDiscount(Integer discount) {
		this.discount = discount;
	}
	public void setDiscountedPrice(double discountedPrice) {
		this.discountedPrice = discountedPrice;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public List<ImageDto> getServiceImages() {
		return serviceImages;
	}
	public void setServiceImages(List<ImageDto> serviceImages) {
		this.serviceImages = serviceImages;
	}
	
	
}
