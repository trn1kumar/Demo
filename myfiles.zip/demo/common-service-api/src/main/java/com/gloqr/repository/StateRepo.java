package com.gloqr.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.entity.address.State;


public interface StateRepo extends JpaRepository<State, Long>{

	State findByStateCode(String stateCode);


}
