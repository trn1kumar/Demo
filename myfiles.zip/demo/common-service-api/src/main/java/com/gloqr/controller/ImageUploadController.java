package com.gloqr.controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.constants.SMEFileDirectory;
import com.gloqr.entity.Image;
import com.gloqr.exception.CustomException;
import com.gloqr.service.ContentServerService;

@RestController
@CrossOrigin("*")
@RequestMapping(value = "/smeface/admin")
public class ImageUploadController {

	@Autowired
	private ContentServerService sendFilesToConetntServerInte;

	Logger log = LogManager.getLogger(ImageUploadController.class.getName());

	@PostMapping(value = "/home-slider", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> uploadSmeSlider(@FormDataParam("sliders") MultipartFile[] sliders) throws IOException {
		try {

			if (sliders != null && sliders.length > 0) {
				List<Image> images = null;

				images = sendFilesToConetntServerInte.sendFilesToContentServer(Arrays.asList(sliders),
						SMEFileDirectory.SMEFACE_HOMEPAGE);
				for (Image image : images) {
					image.setProvider("SMEFACE-SLIDER");
					sendFilesToConetntServerInte.saveImage(image);
				}

				HashMap<String, HttpStatus> resposne = new HashMap<>();
				resposne.put("Images uploaded sucessfully", HttpStatus.OK);
				return new ResponseEntity<HashMap<String, HttpStatus>>(resposne, HttpStatus.OK);

			} else {
				throw new CustomException("Image not uplaoded properly", HttpStatus.NO_CONTENT);
			}

		} catch (Exception e) {
			throw e;
		}

	}

	@PostMapping(value = "/smeface-logo", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> uploadSmeLogo(@FormDataParam("sliders") MultipartFile sliders) throws IOException {
		try {

			if (sliders != null && !sliders.isEmpty()) {
				Image images = null;

				images = sendFilesToConetntServerInte.sendFileToContentServer(sliders, SMEFileDirectory.SMEFACE_LOGO);
				images.setProvider("SMEFACE-LOGO");
				sendFilesToConetntServerInte.saveImage(images);

				HashMap<String, HttpStatus> resposne = new HashMap<>();
				resposne.put("Images uploaded sucessfully", HttpStatus.OK);
				return new ResponseEntity<HashMap<String, HttpStatus>>(resposne, HttpStatus.OK);

			} else {
				throw new CustomException("Image not uplaoded properly", HttpStatus.NO_CONTENT);
			}

		} catch (Exception e) {
			throw e;
		}

	}

	@GetMapping(value = "/image")
	public ResponseEntity<?> getImageLocation() {
		try {

			HashMap<String, List<Image>> images = sendFilesToConetntServerInte.getImageFileLocation();
			return new ResponseEntity<HashMap<String, List<Image>>>(images, HttpStatus.OK);
		} catch (Exception e) {
			throw e;
		}

	}

	@GetMapping(value = "/logo-image")
	public ResponseEntity<?> getLogoImageLocation() {
		try {

			Image image = sendFilesToConetntServerInte.getSmefaceLogo();
			return new ResponseEntity<Image>(image, HttpStatus.OK);
		} catch (CustomException e) {
			throw e;
		}

	}
}
