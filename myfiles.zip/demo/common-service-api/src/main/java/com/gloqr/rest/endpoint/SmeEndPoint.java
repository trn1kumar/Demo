package com.gloqr.rest.endpoint;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;

import com.gloqr.dto.smes.SMEDto;
import com.gloqr.exception.CustomException;
import com.gloqr.model.http.response.CustomHttpResponse;

public class SmeEndPoint {

	private Client client;
	private String endPointUri;
	private String searchSmes;

	private Logger log = LogManager.getLogger();

	public SmeEndPoint(Client client, String endPointUri, String searchSmes) {
		super();
		this.client = client;
		this.endPointUri = endPointUri;
		this.searchSmes = searchSmes;
	}

	public List<SMEDto> getSmes() {

		/*
		 * Implementation pending
		 */

		return null;
	}

	public List<SMEDto> getSearchedSmes(String searchText, int smeMaxResult) {

		Response response = null;
		CustomHttpResponse<List<SMEDto>> customResponse = null;
		log.info("Getting TOP SME details.");
		log.info("Connecting to SME Module...  {method=GET, uri: {} ,params=searchText:{} }", endPointUri, searchText);

		try {

			response = client.target(endPointUri).path(searchSmes).queryParam("searchText", searchText)
					.queryParam("maxResult", smeMaxResult).request(MediaType.APPLICATION_JSON).get();
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);
		Integer statusCode = response.getStatus();

		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}
		try {
			customResponse = response.readEntity(new GenericType<CustomHttpResponse<List<SMEDto>>>() {
			});
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}
		if (customResponse.isError()) {
			throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
		}
		return customResponse.getData();

	}

	private void throwEntityResponseReadException(Exception e) {
		throw new CustomException("Exception at read response from SME Module. Message: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private void throwInvalidResponseException(int statusCode) {
		throw new CustomException("Invalid Response from SME Module: ", HttpStatus.resolve(statusCode));
	}

	private void throwConnectionRefusedException(Exception e) {
		throw new CustomException("Couldn't Connect to SME module, Exception: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private void logResponse(Response response) {
		log.info("Response From SME Module : " + response);
	}

}
