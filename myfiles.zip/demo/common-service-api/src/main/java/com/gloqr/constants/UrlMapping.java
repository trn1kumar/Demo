package com.gloqr.constants;

public class UrlMapping {

	private UrlMapping() {
		throw new IllegalStateException("UrlMapping class.can't initiate");
	}
	// AddressControllerUrls
	public static final String ROOT_API = "/api/common-service"; // root level api
	public static final String ADD_CITIES = "/cities";
	public static final String ADD_STATES = "/states";
	public static final String ADD_COUNTRIES = "/countries";

	public static final String GET_CITY = "/city";
	public static final String GET_STATE = "/state";
	public static final String GET_COUNTRY = "/country";

	public static final String GET_CITIES = "/cities";
	public static final String GET_STATES = "/states";
	public static final String GET_COUNTRIES = "/countries";

	public static final String GET_INDIAN_STATES = "/india/states";

	public static final String GET_CITY_BY_PINCODE = "/pincode";

	public static final String NEW_CONTACT = "contact-us";
	
	//AddressSearchControllerUrls
	public static final String SUGGEST_CITIES = "/cities/suggest-result";

	// SMEFaceMasterSearchControllerUrls
	public static final String HOMEPAGE_SEARCH = "/homepage-search/suggest-result";

}
