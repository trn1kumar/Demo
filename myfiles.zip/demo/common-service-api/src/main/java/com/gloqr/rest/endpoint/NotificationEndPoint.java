package com.gloqr.rest.endpoint;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;

import com.gloqr.exception.CustomException;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.notification.EmailEvent;

public class NotificationEndPoint {

	Logger logger = LogManager.getLogger();

	private Client client;
	private String endpoint;
	private String emailPath;

	public NotificationEndPoint(Client client, String notificationEndPoint, String emailEndPointPath) {
		this.client = client;
		this.endpoint = notificationEndPoint;
		this.emailPath = emailEndPointPath;
	}

	@SuppressWarnings("rawtypes")
	public void sendEmailNotification(EmailEvent emailEvent) {
		Response response = null;
		CustomHttpResponse customResponse = null;

		logger.info("Sending Email to :: " + emailEvent.getEmailId());

		try {
			response = client.target(endpoint).path(emailPath).request(MediaType.APPLICATION_JSON)
					.post(Entity.entity(emailEvent, MediaType.APPLICATION_JSON));

			logger.info("Response from Notification enpoint :: " + response.toString());

		} catch (Exception e) {
			throw new CustomException("Internal Server Error While Sending Email " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

		customResponse = response.readEntity(new GenericType<CustomHttpResponse>() {
		});

		if (customResponse.isError()) {
			logger.error("Error occured while sending email");
		} else {
			logger.error("Email Sent Successfully!!");
		}

	}

}
