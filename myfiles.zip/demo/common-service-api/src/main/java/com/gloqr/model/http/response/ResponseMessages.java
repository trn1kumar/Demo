package com.gloqr.model.http.response;

import org.springframework.http.HttpStatus;

import com.gloqr.exception.CustomException;

public class ResponseMessages {
	private ResponseMessages() {
		throw new CustomException("ResponseMessages class, can't initiate", HttpStatus.INTERNAL_SERVER_ERROR);
	}

	public static final String SUCCESS = "Success";
	public static final String CITITES_ADDED = "Citties Added Successfully";
	public static final String STATES_ADDED = "States Added Successfully";
	public static final String CONTRIES_ADDED = "Countries Added Successfully";
}
