package com.gloqr.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.dto.SMEFaceMaster;
import com.gloqr.dto.smes.SMEDto;
import com.gloqr.entity.products.SMEProduct;
import com.gloqr.entity.services.SMEService;
import com.gloqr.rest.endpoint.ProductEndPoint;
import com.gloqr.rest.endpoint.ServiceEndPoint;
import com.gloqr.rest.endpoint.SmeEndPoint;

@Service
public class GloqrHomePageServiceImpl implements GloqrHomePageMasterService {

	@Autowired
	SmeEndPoint smeEndPoint;

	@Autowired
	ProductEndPoint productEndPoint;

	@Autowired
	ServiceEndPoint serviceEndPoint;

	@Override
	public List<SMEProduct> getProducts(String userId, String smeId) {
		return productEndPoint.getProducts(userId, smeId);
	}

	@Override
	public List<SMEService> getServices(String userId, String smeId) {
		return serviceEndPoint.getSMEsServices(userId, smeId);
	}

	@Override
	public List<SMEDto> getSMEs() {
		return smeEndPoint.getSmes();
	}

	@Override
	public SMEFaceMaster getData(String userId, String smeId) throws InterruptedException {
		SMEFaceMaster master = new SMEFaceMaster();

		Thread t1 = new Thread(() -> {
			List<SMEProduct> products = this.getProducts(userId, smeId);
			master.setTopProducts(products);
			master.setTopProductsCount(products.size());
		}, "SMEProdcutThread");
		Thread t2 = new Thread(() -> {
			List<SMEService> services = this.getServices(userId, smeId);
			master.setTopServices(services);
			master.setTopServicesCount(services.size());
		}, "SMEServiceThread");
		Thread t3 = new Thread(() -> {
			List<SMEDto> smes = this.getSMEs();
			master.setTopSmes(smes);
			master.setTopSmesCount(smes.size());
		}, "SMEThread");

		

		t1.start();
		t2.start();
		t3.start();
		

		try {
			t1.join();
			t2.join();
			t3.join();
		
		} catch (InterruptedException e) {
			e.printStackTrace();
			throw e;
		}

		return master;
	}

}
