package com.gloqr.configuration;

import javax.annotation.Resource;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.gloqr.rest.endpoint.ContentServerEndpoint;
import com.gloqr.rest.endpoint.NotificationEndPoint;
import com.gloqr.rest.endpoint.ProductEndPoint;
import com.gloqr.rest.endpoint.ServiceEndPoint;
import com.gloqr.rest.endpoint.SmeEndPoint;

@Configuration
public class BeanConfiguration {

	@Resource
	private Environment environment;

	@Bean
	public SmeEndPoint smeEndPointConfig() {
		Client client = ClientBuilder.newClient();
		String endPoint = environment.getRequiredProperty("sme.endpoint");
		String searchSmes = environment.getRequiredProperty("search.smes");
		return  new SmeEndPoint(client, endPoint, searchSmes);
	}

	@Bean
	public ProductEndPoint productEndPointConfig() {
		Client client = ClientBuilder.newClient();
		String endPoint = environment.getRequiredProperty("product.endpoint");
		String productsPath = environment.getRequiredProperty("products.path");
		String searchSuggest = environment.getRequiredProperty("search.product.suggest");

		return new ProductEndPoint(client, endPoint, productsPath, searchSuggest);

	}

	@Bean
	public ServiceEndPoint serviceEndPointConfig() {
		Client client = ClientBuilder.newClient();
		String endPoint = environment.getRequiredProperty("service.endpoint");
		String servicesPath = environment.getRequiredProperty("services.path");
		String searchSuggest = environment.getRequiredProperty("search.service.suggest");

		return new ServiceEndPoint(client, endPoint, servicesPath, searchSuggest);
	}

	@Bean
	public ContentServerEndpoint contentConfiguration() {
		Client client = ClientBuilder.newBuilder().register(MultiPartFeature.class).build();

		String endPoint = environment.getRequiredProperty("contentserver.endpoint");
		String uploadFiles = environment.getRequiredProperty("files.endpoint.path");
		String uploadFile = environment.getRequiredProperty("file.endpoint.path");
		String deleteFile = environment.getRequiredProperty("deletefiles.endpoint.path");
		return new ContentServerEndpoint(client, endPoint, uploadFiles,
				uploadFile, deleteFile);
	}
	
	@Bean
	public NotificationEndPoint notificationConfiguration() {
		Client client = ClientBuilder.newClient();
		String notificationEndPoint = environment.getRequiredProperty("notification.endpoint");
		String emailEndPointPath = environment.getRequiredProperty("email.endpoint.path");


		return new NotificationEndPoint(client, notificationEndPoint, emailEndPointPath);
	}

	@Bean(name = "taskExecutor")
	public TaskExecutor workExecutor() {
		ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
		threadPoolTaskExecutor.setThreadNamePrefix("Async-Thread");

		threadPoolTaskExecutor.setCorePoolSize(5);
		threadPoolTaskExecutor.setMaxPoolSize(10);
		threadPoolTaskExecutor.setQueueCapacity(600);
		threadPoolTaskExecutor.afterPropertiesSet();

		return threadPoolTaskExecutor;
	}
	
}
