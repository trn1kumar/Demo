package com.gloqr.dto;

import java.util.List;

import com.gloqr.entity.address.State;

public class CountryDto {

	
	private String countryCode;
	private String countryName;
	private List<State> states;
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public List<State> getStates() {
		return states;
	}
	public void setStates(List<State> states) {
		this.states = states;
	}
}
