package com.gloqr.service;

import java.util.List;

import com.gloqr.entity.address.City;

public interface AddressSearchService {

	public List<City> getSearchResult(String searchText, Integer pincode);
}
