package com.gloqr.service;

import java.util.List;

import com.gloqr.dto.SMEFaceMaster;
import com.gloqr.dto.smes.SMEDto;
import com.gloqr.entity.products.SMEProduct;
import com.gloqr.entity.services.SMEService;

public interface GloqrHomePageMasterService {
	

	List<SMEProduct> getProducts(String userId, String smeId);

	List<SMEService> getServices(String userId, String smeId);

	List<SMEDto> getSMEs();

	SMEFaceMaster getData(String userID, String smeId) throws InterruptedException;
}
