package com.gloqr.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.entity.address.Country;
import com.gloqr.exception.CustomException;
import com.gloqr.repository.CountryRepo;

@Repository
public class CountryDaoImpl implements CountryDao {

	@Autowired
	private CountryRepo countryRepo;

	@Override
	public void saveCountries(List<Country> countries) {
		try {
			countryRepo.saveAll(countries);
		} catch (Exception e) {
			throw new CustomException("Exception while saving Countries. message:- " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

	}

	@Override
	public List<Country> getCountries() {
		List<Country> countries = countryRepo.findAll();
		if (!countries.isEmpty()) {
			return countries;
		} else {
			throw new CustomException("Countries Not Available", HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public Country getCountry(String countryCode) {
		Country country = countryRepo.findByCountryCode(countryCode);
		if (country == null)
			throw new CustomException("Country Not Found for Code " + countryCode, HttpStatus.NOT_FOUND);
		return country;
	}

}
