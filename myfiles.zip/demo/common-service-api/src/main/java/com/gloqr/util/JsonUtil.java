package com.gloqr.util;
/*package com.smeface.admin.util;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.google.gson.Gson;
import com.smeface.exception.CustomException;

@Component
public class JsonUtil {
	public <T> T parseJsonData(MultipartHttpServletRequest request, String parseKey, Class<T> parseClass) {
		T t = null;
		try {
			t = new Gson().fromJson(request.getParameter(parseKey), parseClass);

		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomException("Failed to parse json data", HttpStatus.BAD_REQUEST);
		}
		return t;

	}

}
*/