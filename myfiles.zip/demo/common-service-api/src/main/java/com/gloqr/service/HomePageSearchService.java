package com.gloqr.service;

import com.gloqr.dto.SearchResultDto;

public interface HomePageSearchService {
	public SearchResultDto getSearchedResult(String searchText, String searchModule);

}
