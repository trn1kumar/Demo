package com.gloqr.util;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;

import com.gloqr.exception.CustomException;

public class ValidationUtil {

	private ValidationUtil() {
		throw new CustomException("ValidationUtil Can't initiate", HttpStatus.INTERNAL_SERVER_ERROR);
	}

	public static List<String> fromBindingErrors(Errors errors) {
		List<String> validErrors = new ArrayList<>();
		for (ObjectError objectError : errors.getAllErrors()) {
			validErrors.add(objectError.getDefaultMessage());
		}
		return validErrors;
	}

}
