package com.gloqr.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.gloqr.entity.Image;

public interface ContentServerService {

	public List<Image> sendFilesToContentServer(List<MultipartFile> files, String fileContentDirName)
			throws IllegalArgumentException, IOException;
	
	public Image sendFileToContentServer(MultipartFile file, String fileContentDirName) throws IllegalArgumentException, IOException;
	
	public void saveImage(Image image);
	
	public HashMap<String, List<Image>> getImageFileLocation();
	
	public Image getSmefaceLogo();
}
