package com.gloqr.security.configuration;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.stream.Collectors;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.filter.OncePerRequestFilter;

import com.gloqr.exception.CustomException;
import com.gloqr.security.context.holder.UserDetails;

import io.jsonwebtoken.Claims;

public class JwtAuthenticationFilter extends OncePerRequestFilter {

	private static final Logger log = LogManager.getLogger();

	@Value("${authentication.path}")
	private String authenticationPoint;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		ResponseEntity<String> authResponse = null;
		String header = request.getHeader(JwtConstants.HEADER_STRING);

		if (header != null) {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.set(JwtConstants.HEADER_STRING, header);
			try {
				log.info("Validating Token. [method:GET ,uri:{}]", authenticationPoint);
				authResponse = restTemplate.exchange(authenticationPoint, HttpMethod.GET,
						new HttpEntity<String>(httpHeaders), String.class);
			} catch (Exception e) {
				logger.error("Exception while Validating Token", e);
				throw new CustomException("Invalid Authorization", HttpStatus.UNAUTHORIZED);
			}

			if (HttpStatus.OK == authResponse.getStatusCode()) {

				final String authToken = header.replace(JwtConstants.TOKEN_PREFIX, "");

				final Claims claims = jwtTokenUtil.getJwtClaims(authToken);

				String subject = claims.getSubject();
				String smeId = (String) claims.get(JwtConstants.SME_ID);
				String userId = (String) claims.get(JwtConstants.USER_ID);
				String userName = (String) claims.get(JwtConstants.FIRST_NAME);
				String userType = (String) claims.get(JwtConstants.USER_TYPE);
				final Collection<? extends GrantedAuthority> authorities = Arrays
						.stream(claims.get(JwtConstants.AUTHORITIES_KEY).toString().split(","))
						.map(SimpleGrantedAuthority::new).collect(Collectors.toList());

				UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
						new UserDetails(subject, smeId, userId, userName, userType), "", authorities);
				logger.info("authenticated user " + subject + ", setting security context");
				SecurityContextHolder.getContext().setAuthentication(authentication);

			}
		}
		filterChain.doFilter(request, response);

	}

}
