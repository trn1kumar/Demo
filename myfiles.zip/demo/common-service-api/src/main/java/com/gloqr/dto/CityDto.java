package com.gloqr.dto;


public class CityDto {

	
	private String cityCode;

	private String cityName;

	private String formattedCityName;
	
	private StateDto state;

	public String getCityCode() {
		return cityCode;
	}

	public String getCityName() {
		return cityName;
	}

	public String getFormattedCityName() {
		return formattedCityName;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public void setFormattedCityName(String formattedCityName) {
		this.formattedCityName = formattedCityName;
	}

	public StateDto getState() {
		return state;
	}

	public void setState(StateDto state) {
		this.state = state;
	}

	
	
}
