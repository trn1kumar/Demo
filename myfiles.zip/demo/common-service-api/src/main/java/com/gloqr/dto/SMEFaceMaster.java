package com.gloqr.dto;

import java.util.List;

import com.gloqr.dto.smes.SMEDto;
import com.gloqr.entity.products.SMEProduct;
import com.gloqr.entity.services.SMEService;

public class SMEFaceMaster {

	private int topProductsCount;
	private int topServicesCount;
	private int topSmesCount;

	private List<SMEProduct> topProducts;
	private List<SMEService> topServices;
	private List<SMEDto> topSmes;

	public int getTopProductsCount() {
		return topProductsCount;
	}

	public int getTopServicesCount() {
		return topServicesCount;
	}

	public int getTopSmesCount() {
		return topSmesCount;
	}

	public List<SMEProduct> getTopProducts() {
		return topProducts;
	}

	public List<SMEService> getTopServices() {
		return topServices;
	}

	public List<SMEDto> getTopSmes() {
		return topSmes;
	}

	public void setTopProductsCount(int topProductsCount) {
		this.topProductsCount = topProductsCount;
	}

	public void setTopServicesCount(int topServicesCount) {
		this.topServicesCount = topServicesCount;
	}

	public void setTopSmesCount(int topSmesCount) {
		this.topSmesCount = topSmesCount;
	}

	public void setTopProducts(List<SMEProduct> topProducts) {
		this.topProducts = topProducts;
	}

	public void setTopServices(List<SMEService> topServices) {
		this.topServices = topServices;
	}

	public void setTopSmes(List<SMEDto> topSmes) {
		this.topSmes = topSmes;
	}

}
