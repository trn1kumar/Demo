package com.gloqr.dto;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class SearchResultDto {
	

	private Map<String, List<? extends Object>> searchedResult;

	public Map<String, List<? extends Object>> getSearchedResult() {
		return searchedResult;
	}

	public void setSearchedResult(Map<String, List<? extends Object>> searchedResult) {
		this.searchedResult = searchedResult;
	}
	

}
