package com.gloqr.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.SearchResultDto;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.model.http.response.ResponseMessages;
import com.gloqr.service.HomePageSearchService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = UrlMapping.ROOT_API)
public class HomePageSearchController {

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private HomePageSearchService smefaceMasterSearchService;

	@GetMapping(UrlMapping.HOMEPAGE_SEARCH)
	public ResponseEntity<CustomHttpResponse<SearchResultDto>> getSearchResults(
			@RequestParam(value = "searchText") String searchText,
			@RequestParam(value = "searchModule") String searchModule) {

		SearchResultDto searchResult = smefaceMasterSearchService.getSearchedResult(searchText, searchModule);
		return responseMaker.successResponse(searchResult, ResponseMessages.SUCCESS, HttpStatus.OK);
	}
}
