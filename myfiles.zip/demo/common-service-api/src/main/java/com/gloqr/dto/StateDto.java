package com.gloqr.dto;

import java.util.List;

import com.gloqr.entity.address.City;

public class StateDto {

	
	private String stateCode;
	private String stateName;
	private String formattedStateName;
	private CountryDto country;
	private List<City> cities;
	
	public String getStateCode() {
		return stateCode;
	}
	public String getStateName() {
		return stateName;
	}
	public String getFormattedStateName() {
		return formattedStateName;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public void setFormattedStateName(String formattedStateName) {
		this.formattedStateName = formattedStateName;
	}
	public CountryDto getCountry() {
		return country;
	}
	public void setCountry(CountryDto country) {
		this.country = country;
	}
	public List<City> getCities() {
		return cities;
	}
	public void setCities(List<City> cities) {
		this.cities = cities;
	}
	
	
}
