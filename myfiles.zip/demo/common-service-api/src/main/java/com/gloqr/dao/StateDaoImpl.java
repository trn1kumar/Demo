package com.gloqr.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.entity.address.State;
import com.gloqr.exception.CustomException;
import com.gloqr.repository.StateRepo;

@Repository
public class StateDaoImpl implements StateDao {

	@Autowired
	private StateRepo stateRepo;

	@Override
	public void saveStates(List<State> states) {
		try {
			stateRepo.saveAll(states);
		} catch (Exception e) {
			throw new CustomException("Exception while saving States. message:- " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

	}

	@Override
	public List<State> getStatesWithCities() {
		List<State> states = stateRepo.findAll(Sort.by(Direction.ASC, "stateName"));
		if (!states.isEmpty()) {
			return states;
		} else {
			throw new CustomException("States Not Available", HttpStatus.NOT_FOUND);
		}

	}

	@Override
	public State getState(String stateCode) {
		State state = stateRepo.findByStateCode(stateCode);
		if (state == null)
			throw new CustomException("State Not Found for Code " + stateCode, HttpStatus.NOT_FOUND);
		return state;
	}

}
