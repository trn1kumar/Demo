package com.gloqr.entity;

public class SMEFaceFooter {

}
