package com.gloqr.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.entity.address.Pincode;

public interface PincodeRepo extends JpaRepository<Pincode, Long>{

	Pincode findByPincode(int pincode);

}
