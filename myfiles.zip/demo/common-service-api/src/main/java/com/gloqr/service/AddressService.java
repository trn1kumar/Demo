package com.gloqr.service;

import java.util.List;

import com.gloqr.entity.address.City;
import com.gloqr.entity.address.Country;
import com.gloqr.entity.address.State;

public interface AddressService {

	public void saveCities(List<City> cities);

	public void saveStates(List<State> states);

	public void saveCountries(List<Country> countries);

	public City getCity(String cityCode);

	public State getState(String stateCode);

	public Country getCountry(String countryCode);
	
	public List<City> getCitiesByState(String stateCode);

	public List<State> getStatesByCountry(String countryCode);

	public List<Country> getCountries();

	public City getCityByPincode(int pincode);

	public List<State> getStatesWithCities();


}
