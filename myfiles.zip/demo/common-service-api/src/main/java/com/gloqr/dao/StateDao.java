package com.gloqr.dao;

import java.util.List;

import com.gloqr.entity.address.State;

public interface StateDao {

	void saveStates(List<State> states);

	List<State> getStatesWithCities();

	State getState(String stateCode);

}
