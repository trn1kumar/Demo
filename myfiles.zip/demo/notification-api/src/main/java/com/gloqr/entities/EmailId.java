package com.gloqr.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/*@Entity(name = "notification_email_ids")*/
public class EmailId {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private String emailId;
	private int totalSentCount;

	@ManyToOne(optional = false)
	@JoinColumn(name = "email_event_id")
	private EmailEvent emailEvent;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public int getTotalSentCount() {
		return totalSentCount;
	}

	public void setTotalSentCount(int totalSentCount) {
		this.totalSentCount = totalSentCount;
	}

}
