package com.gloqr.controller;

import static com.gloqr.notification.EventService.EVENTSERVICE;


import javax.annotation.PostConstruct;
import javax.mail.MessagingException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.SchedulerJobInfoDto;
import com.gloqr.entities.EmailEvent;
import com.gloqr.entities.Event;
import com.gloqr.entities.SchedulerJobInfo;
import com.gloqr.entities.SmsEvent;
import com.gloqr.http.response.module.CustomHttpResponse;
import com.gloqr.http.response.module.ResponseMaker;
import com.gloqr.http.response.module.ResponseMessage;
import com.gloqr.jpa.repositories.SchedulerBasicConfigRepo;
import com.gloqr.mapper.NotificationMapper;
import com.gloqr.notification.EmailPublisher;
import com.gloqr.notification.EmailSubscriber;
import com.gloqr.notification.EventType;
import com.gloqr.notification.Filter;
import com.gloqr.notification.InvalidEventException;
import com.gloqr.notification.SmsPublisher;
import com.gloqr.notification.SmsSubscriber;
import com.gloqr.service.SchedulerService;

@RestController
@RequestMapping(value = UrlMapping.ROOT_API)
@SuppressWarnings("rawtypes")
public class NotificationController {

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private SmsPublisher smsPublisher;

	@Autowired
	private EmailPublisher emailPublisher;

	@Autowired
	private SmsSubscriber smsSubscriber;

	@Autowired
	private EmailSubscriber emailSubscriber;

	@Autowired
	private SchedulerService schedulerService;

	@Autowired
	private NotificationMapper mapper;

	@Value("${sms.sender}")
	private String sender;

	Logger log = LogManager.getLogger(NotificationController.class.getName());

	@Autowired
	SchedulerBasicConfigRepo schedulerBasicConfigRepo;

	@PostConstruct
	public void intializeApplication() {
		log.info("Initalizing Application..........");
		Filter filter = new Filter();
		filter.apply(EventType.SMSEVENT, Event.LOW, Event.AVERAGE, Event.CRITICAL);

		smsSubscriber.setFilter(filter);

		Filter filter1 = new Filter();
		filter1.apply(EventType.EMAILEVENT, Event.LOW, Event.CRITICAL);

		emailSubscriber.setFilter(filter1);

		try {
			EVENTSERVICE.subscribe(smsSubscriber, SmsEvent.class);
			EVENTSERVICE.subscribe(emailSubscriber, EmailEvent.class);
		} catch (InvalidEventException e) {
			log.error("Exception thrown: " + e.getLocalizedMessage(), e);
		}
		log.info("Application Initialized.");

	}

	@PostMapping(value = UrlMapping.SEND_MAIL)
	public ResponseEntity<CustomHttpResponse> sendMail(@RequestBody EmailEvent emailEvent) throws MessagingException {
		log.info("Request received for sending mail : " + emailEvent.toString());

		emailPublisher.publish(emailEvent);

		return responseMaker.successResponse("Mail sent.", HttpStatus.OK);

	}

	@PostMapping(value = UrlMapping.SEND_SMS)
	public ResponseEntity<CustomHttpResponse> sendSMS(@RequestBody final SmsEvent smsEvent) throws MessagingException {
		log.info("Request received for sending sms : " + smsEvent.toString());

		smsEvent.setSender(sender);
		smsPublisher.publish(smsEvent);

		return responseMaker.successResponse("SMS sent.", HttpStatus.OK);
	}

	@PostMapping("/schedule-job")
	public ResponseEntity<CustomHttpResponse> scheduleNewJob(@RequestBody SchedulerJobInfoDto schedulerJobInfoDto) {
		SchedulerJobInfo schedulerJobInfo = mapper.convertToEntity(schedulerJobInfoDto, SchedulerJobInfo.class);
		if (schedulerJobInfo.getSmsEvent() != null) {
			schedulerJobInfo.getSmsEvent().setSender(sender);
		}
		schedulerService.saveSchedulerJobInfo(schedulerJobInfo);
		return responseMaker.successResponse(ResponseMessage.SUCCESS, HttpStatus.OK);
	}

	@PutMapping("/unschedule-job")
	public ResponseEntity<CustomHttpResponse> unscheduleJob(@RequestParam String jobName) {
		schedulerService.unscheduleJob(jobName);
		return responseMaker.successResponse(ResponseMessage.SUCCESS, HttpStatus.OK);
	}

}
