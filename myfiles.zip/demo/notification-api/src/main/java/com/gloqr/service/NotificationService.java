package com.gloqr.service;

import java.util.List;

import com.gloqr.entities.Event;

public interface NotificationService {

	void sendNotifications(List<Event> events);

}
