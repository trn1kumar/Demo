package com.gloqr.jpa.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.gloqr.entities.SchedulerJobInfo;

public interface SchedulerJobInfoRepo extends JpaRepository<SchedulerJobInfo, Long> {

	@Query("SELECT s FROM SchedulerJobInfo s JOIN  s.schedulerBasicConfigs sc where s.completed=false AND s.hourlyExecutionComplete=false AND sc.schedulerType='HOURLY'")
	List<SchedulerJobInfo> findHourlyExecutedJobs();

	@Query("SELECT s FROM SchedulerJobInfo s JOIN  s.schedulerBasicConfigs sc where s.completed=false AND s.dailyExecutionComplete=false AND sc.schedulerType='DAILY'")
	List<SchedulerJobInfo> findDailyExecutedJobs();

	@Query("SELECT s FROM SchedulerJobInfo s JOIN  s.schedulerBasicConfigs sc where s.completed=false AND s.monthlyExecutionComplete=false AND sc.schedulerType='MONTHLY'")
	List<SchedulerJobInfo> findMonthlyExecutedJobs();

	@Query("SELECT s FROM SchedulerJobInfo s JOIN  s.schedulerBasicConfigs sc where s.completed=false AND s.weeklyExecutionComplete=false AND sc.schedulerType='WEEKLY'")
	List<SchedulerJobInfo> findWeeklyExecutedJobs();

	@Query("SELECT s FROM SchedulerJobInfo s JOIN  s.schedulerBasicConfigs sc where s.completed=false AND s.yearlyExecutionComplete=false AND sc.schedulerType='YEARLY'")
	List<SchedulerJobInfo> findYearlyExecutedJobs();

	@Transactional
	@Modifying
	@Query("UPDATE SchedulerJobInfo s set s.hourlyExecutedCount = s.hourlyExecutedCount + 1 WHERE s.jobName = :jobName")
	void increaseHourlyExecutedCount(@Param("jobName") String jobName);

	@Transactional
	@Modifying
	@Query("UPDATE SchedulerJobInfo s set s.hourlyExecutionComplete=true WHERE s.jobName = :jobName")
	void updatehourlyExecutionCompleteByTrue(@Param("jobName") String jobName);

	@Transactional
	@Modifying
	@Query("UPDATE SchedulerJobInfo s set s.completed=true WHERE s.jobName = :jobName")
	void updateCompleteByTrue(@Param("jobName") String jobName);

}
