package com.gloqr.dto;

import com.gloqr.constants.SchedulerGroup;
import com.gloqr.entities.EmailEvent;
import com.gloqr.entities.SmsEvent;

public class SchedulerJobInfoDto {

	private String jobName;

	private SchedulerGroup schedulerGroup;

	private EmailEvent emailEvent;

	private SmsEvent smsEvent;

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public EmailEvent getEmailEvent() {
		return emailEvent;
	}

	public void setEmailEvent(EmailEvent emailEvent) {
		this.emailEvent = emailEvent;
	}

	public SmsEvent getSmsEvent() {
		return smsEvent;
	}

	public void setSmsEvent(SmsEvent smsEvent) {
		this.smsEvent = smsEvent;
	}

	public SchedulerGroup getSchedulerGroup() {
		return schedulerGroup;
	}

	public void setSchedulerGroup(SchedulerGroup schedulerGroup) {
		this.schedulerGroup = schedulerGroup;
	}

}
