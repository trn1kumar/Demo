package com.gloqr.notification.aspect;

import com.gloqr.entities.EmailEvent;
import com.gloqr.entities.SmsEvent;

public interface SmefaceLogger
{
	public void logRequest(SmsEvent event);
	public void logRequest(EmailEvent event);
}
