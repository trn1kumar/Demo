package com.gloqr.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.gloqr.audit.DateAuditable;
import com.gloqr.constants.SchedulerGroup;
import com.gloqr.constants.SchedulerState;

@Entity
@Table(name = "scheduler_job_info")
public class SchedulerJobInfo extends DateAuditable {

	@Id
	@GeneratedValue
	private Long schedulerJobId;

	@Column(name = "job_name", unique = true, updatable = false)
	private String jobName;

	@Column(name = "scheduler_group")
	@Enumerated(EnumType.STRING)
	private SchedulerGroup schedulerGroup;

	@Column(name = "scheduler_state")
	@Enumerated(EnumType.STRING)
	private SchedulerState schedulerState;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "jobs_join_configs", joinColumns = @JoinColumn(name = "schedulerJobId", referencedColumnName = "schedulerJobId"), inverseJoinColumns = @JoinColumn(name = "configId", referencedColumnName = "configId"))
	private List<SchedulerBasicConfig> schedulerBasicConfigs;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "email_event_id")
	private EmailEvent emailEvent;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "sms_event_id")
	private SmsEvent smsEvent;

	private int hourlyExecutedCount;
	private int dailyExecutedCount;
	private int monthlyExecutedCount;
	private int weeklyExecutedCount;
	private int yearlyExecutedCount;

	private boolean hourlyExecutionComplete;
	private boolean dailyExecutionComplete;
	private boolean monthlyExecutionComplete;
	private boolean weeklyExecutionComplete;
	private boolean yearlyExecutionComplete;

	private boolean completed;

	public Long getSchedulerJobId() {
		return schedulerJobId;
	}

	public void setSchedulerJobId(Long schedulerJobId) {
		this.schedulerJobId = schedulerJobId;
	}

	public SchedulerState getSchedulerState() {
		return schedulerState;
	}

	public void setSchedulerState(SchedulerState schedulerState) {
		this.schedulerState = schedulerState;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public List<SchedulerBasicConfig> getSchedulerBasicConfigs() {
		return schedulerBasicConfigs;
	}

	public void setSchedulerBasicConfigs(List<SchedulerBasicConfig> schedulerBasicConfigs) {
		this.schedulerBasicConfigs = schedulerBasicConfigs;
	}

	public SchedulerGroup getSchedulerGroup() {
		return schedulerGroup;
	}

	public void setSchedulerGroup(SchedulerGroup schedulerGroup) {
		this.schedulerGroup = schedulerGroup;
	}

	public EmailEvent getEmailEvent() {
		return emailEvent;
	}

	public void setEmailEvent(EmailEvent emailEvent) {
		this.emailEvent = emailEvent;
	}

	public SmsEvent getSmsEvent() {
		return smsEvent;
	}

	public void setSmsEvent(SmsEvent smsEvent) {
		this.smsEvent = smsEvent;
	}

	public int getHourlyExecutedCount() {
		return hourlyExecutedCount;
	}

	public void setHourlyExecutedCount(int hourlyExecutedCount) {
		this.hourlyExecutedCount = hourlyExecutedCount;
	}

	public int getDailyExecutedCount() {
		return dailyExecutedCount;
	}

	public void setDailyExecutedCount(int dailyExecutedCount) {
		this.dailyExecutedCount = dailyExecutedCount;
	}

	public int getMonthlyExecutedCount() {
		return monthlyExecutedCount;
	}

	public void setMonthlyExecutedCount(int monthlyExecutedCount) {
		this.monthlyExecutedCount = monthlyExecutedCount;
	}

	public int getWeeklyExecutedCount() {
		return weeklyExecutedCount;
	}

	public void setWeeklyExecutedCount(int weeklyExecutedCount) {
		this.weeklyExecutedCount = weeklyExecutedCount;
	}

	public int getYearlyExecutedCount() {
		return yearlyExecutedCount;
	}

	public void setYearlyExecutedCount(int yearlyExecutedCount) {
		this.yearlyExecutedCount = yearlyExecutedCount;
	}

	public boolean isHourlyExecutionComplete() {
		return hourlyExecutionComplete;
	}

	public void setHourlyExecutionComplete(boolean hourlyExecutionComplete) {
		this.hourlyExecutionComplete = hourlyExecutionComplete;
	}

	public boolean isDailyExecutionComplete() {
		return dailyExecutionComplete;
	}

	public void setDailyExecutionComplete(boolean dailyExecutionComplete) {
		this.dailyExecutionComplete = dailyExecutionComplete;
	}

	public boolean isMonthlyExecutionComplete() {
		return monthlyExecutionComplete;
	}

	public void setMonthlyExecutionComplete(boolean monthlyExecutionComplete) {
		this.monthlyExecutionComplete = monthlyExecutionComplete;
	}

	public boolean isWeeklyExecutionComplete() {
		return weeklyExecutionComplete;
	}

	public void setWeeklyExecutionComplete(boolean weeklyExecutionComplete) {
		this.weeklyExecutionComplete = weeklyExecutionComplete;
	}

	public boolean isYearlyExecutionComplete() {
		return yearlyExecutionComplete;
	}

	public void setYearlyExecutionComplete(boolean yearlyExecutionComplete) {
		this.yearlyExecutionComplete = yearlyExecutionComplete;
	}

	public boolean isCompleted() {
		return completed;
	}

	public void setCompleted(boolean completed) {
		this.completed = completed;
	}

}
