package com.gloqr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.entities.SmsEvent;
import com.gloqr.jpa.repositories.SmsNotificationRepository;

@Service
public class SmsNotificationService {

	@Autowired
	private SmsNotificationRepository smsNotificationRepository;

	public void saveSmsToDB(SmsEvent smsEvent) {
		smsNotificationRepository.save(smsEvent);

	}

}
