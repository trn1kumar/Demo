package com.gloqr.constants;

public enum SchedulerType {

	HOURLY,DAILY, MONTHLY, WEEKLY,YEARLY
}
