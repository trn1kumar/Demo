package com.gloqr.constants;

public class UrlMapping {

	private UrlMapping() {
		throw new IllegalStateException("UrlMapping class.can't initiate");
	}

	public static final String ROOT_API = "/notification";
	public static final String SEND_MAIL = "/mail";
	public static final String SEND_SMS = "/sms";
}
