package com.gloqr.jpa.repositories;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.entities.EmailEvent;

@Transactional
public interface EmailNotificationRepository extends JpaRepository<EmailEvent, Long> {
//
//	List<EmailEvent> findBySentStatus(boolean sentStatus);
}
