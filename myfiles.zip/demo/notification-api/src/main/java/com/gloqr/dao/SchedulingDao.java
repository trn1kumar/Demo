package com.gloqr.dao;

import java.util.List;

import com.gloqr.constants.SchedulerGroup;
import com.gloqr.entities.SchedulerBasicConfig;
import com.gloqr.entities.SchedulerJobInfo;

public interface SchedulingDao {

	public void saveSchedulerJobInfo(SchedulerJobInfo schedulerJobInfo);

	public List<SchedulerBasicConfig> getSchedulerConfigsBySchedulerGroup(SchedulerGroup schedulerGroup);

	public void increaseHourlyExecutedCount(String jobName);

	public void updateHourlyExecutedByTrue(String jobName);

	public List<SchedulerJobInfo> getHourlyExecutedJobs();
	
	public List<SchedulerJobInfo> getDailyExecutedJobs();

	public List<SchedulerJobInfo> getWeeklyExecutedJobs();

	public List<SchedulerJobInfo> getMonthlyExecutedJobs();

	public List<SchedulerJobInfo> getYearlyExecutedJobs();

	public void unscheduleJobByJobName(String jobName);

}
