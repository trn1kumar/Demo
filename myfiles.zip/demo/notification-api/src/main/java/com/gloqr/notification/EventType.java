package com.gloqr.notification;

public enum EventType
{
	SMSEVENT,
	EMAILEVENT;
}

