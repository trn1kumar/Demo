package com.gloqr.dao;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.gloqr.constants.SchedulerGroup;
import com.gloqr.entities.SchedulerBasicConfig;
import com.gloqr.entities.SchedulerJobInfo;
import com.gloqr.exceptions.CustomException;
import com.gloqr.jpa.repositories.SchedulerBasicConfigRepo;
import com.gloqr.jpa.repositories.SchedulerJobInfoRepo;

@Repository
public class SchedulingDaoImpl implements SchedulingDao {
	Logger log = LogManager.getLogger();

	@Autowired
	private SchedulerJobInfoRepo schedulerJobInfoRepo;

	@Autowired
	private SchedulerBasicConfigRepo schedulerConfigRepo;

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = false, noRollbackFor = Exception.class)
	public void saveSchedulerJobInfo(SchedulerJobInfo schedulerJobInfo) {
		schedulerJobInfoRepo.save(schedulerJobInfo);
	}

	@Override
	public List<SchedulerBasicConfig> getSchedulerConfigsBySchedulerGroup(SchedulerGroup schedulerGroup) {
		List<SchedulerBasicConfig> configs = schedulerConfigRepo.findBySchedulerGroup(schedulerGroup);
		if (configs.isEmpty()) {
			throw new CustomException("No Scheduler Configuration available for Group Name " + schedulerGroup,
					HttpStatus.NOT_FOUND);
		}
		return configs;
	}

	@Override
	public List<SchedulerJobInfo> getHourlyExecutedJobs() {
		return schedulerJobInfoRepo.findHourlyExecutedJobs();
	}

	@Override
	public List<SchedulerJobInfo> getDailyExecutedJobs() {
		return schedulerJobInfoRepo.findDailyExecutedJobs();
	}

	@Override
	public List<SchedulerJobInfo> getWeeklyExecutedJobs() {
		return schedulerJobInfoRepo.findWeeklyExecutedJobs();
	}

	@Override
	public List<SchedulerJobInfo> getMonthlyExecutedJobs() {
		return schedulerJobInfoRepo.findMonthlyExecutedJobs();
	}

	@Override
	public List<SchedulerJobInfo> getYearlyExecutedJobs() {
		return schedulerJobInfoRepo.findYearlyExecutedJobs();
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = false, noRollbackFor = Exception.class)
	public void increaseHourlyExecutedCount(String jobName) {
		log.info("Increasing Hourly Executed Count by One for {}" , jobName);
		schedulerJobInfoRepo.increaseHourlyExecutedCount(jobName);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = false, noRollbackFor = Exception.class)
	public void updateHourlyExecutedByTrue(String jobName) {
		log.info("Updating Hourly Executed true for {}" , jobName);
		schedulerJobInfoRepo.updatehourlyExecutionCompleteByTrue(jobName);

	}

	@Override
	public void unscheduleJobByJobName(String jobName) {
		log.info("unsheculing job name {}" , jobName);
		schedulerJobInfoRepo.updateCompleteByTrue(jobName);

	}

}
