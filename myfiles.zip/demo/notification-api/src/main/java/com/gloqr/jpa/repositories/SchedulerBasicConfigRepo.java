package com.gloqr.jpa.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.constants.SchedulerGroup;
import com.gloqr.entities.SchedulerBasicConfig;

public interface SchedulerBasicConfigRepo extends JpaRepository<SchedulerBasicConfig, Long> {

	List<SchedulerBasicConfig> findBySchedulerGroup(SchedulerGroup schedulerGroup);

}
