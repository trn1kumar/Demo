
package com.gloqr.notification;

import java.io.BufferedInputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import com.gloqr.entities.EmailEvent;
import com.gloqr.entities.Event;
import com.gloqr.service.EmailNotificationService;

public class EmailSubscriber extends Subscriber {
	private Logger log = LogManager.getLogger();

	@Autowired
	private JavaMailSender emailSender;

	@Autowired
	private EmailNotificationService emailNotificationService;

	private String mailSender;

	@Value("${content-server-endpoint}")
	private String contentServerEndpoint;

	public EmailSubscriber(String mailSender) {
		this.mailSender = mailSender;
	}

	Logger logger = LogManager.getLogger(EmailSubscriber.class.getName());

	@Override
	public void inform(Event event) throws MessagingException {

		EmailEvent emailEvent = (EmailEvent) event;
		log.info("Sending mail to {}", emailEvent.getEmailId());
		MimeMessage message = emailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
				StandardCharsets.UTF_8.name());
		String attachmentFileLocation = emailEvent.getAttachmentFileLocation();
		if (attachmentFileLocation != null) {
			String[] strs = attachmentFileLocation.split("/");
			String fileName = strs[strs.length - 1];
			helper.addAttachment(fileName, new ByteArrayResource(getFileFromContentServer(attachmentFileLocation)));

		}

		helper.setText(emailEvent.getEventMessage(), true);

		helper.setSubject(emailEvent.getSubject());

		helper.setTo(emailEvent.getEmailId());
		helper.setFrom(mailSender);
		emailSender.send(message);
		emailEvent.setTotalSentCount(emailEvent.getTotalSentCount() + 1);
		emailNotificationService.saveEmailToDB(emailEvent);
		log.info("Mail Sent to {}", emailEvent.getEmailId());
	}

	private byte[] getFileFromContentServer(String attachmentFileLocation) {

		BufferedInputStream inputStream = null;
		byte[] bytes = null;
		try {
			String contentServerFilePath = contentServerEndpoint + attachmentFileLocation;
			log.info("Downloading attachment file from content server. Localized URL:- {}", contentServerFilePath);
			inputStream = new BufferedInputStream(new URL(contentServerFilePath).openStream());
			bytes = IOUtils.toByteArray(inputStream);

		} catch (Exception e) {
			log.error("Failed to add a file atachment: file location: {} and exception: {}", attachmentFileLocation,
					e.getMessage());
		}
		return bytes;

	}

	public EventType getSubscriberEventType() {
		return EventType.EMAILEVENT;
	}

	public String getMailSender() {
		return mailSender;
	}

	public void setMailSender(String mailSender) {
		this.mailSender = mailSender;
	}

}
