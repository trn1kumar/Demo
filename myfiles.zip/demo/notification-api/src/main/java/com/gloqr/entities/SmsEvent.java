package com.gloqr.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.gloqr.notification.aspect.SmefaceLogger;

@Entity(name = "notification_sms_event")
public class SmsEvent extends Event {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "sms_event_id")
	private long smsEventId;

	@Column(name = "mobile_no")
	private String mobileNo;

	@Column(name = "eventMessage", columnDefinition = "TEXT")
	private String eventMessage;

	@Column(name = "sender")
	private String sender;

	@Column(name = "totalSentCount")
	private int totalSentCount;

	public void acceptLogIntercepter(SmefaceLogger logger) {
		logger.logRequest(this);
	}

	public String getEventMessage() {
		return eventMessage;
	}

	public void setEventMessage(String eventMessage) {
		this.eventMessage = eventMessage;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public long getSmsEventId() {
		return smsEventId;
	}

	public void setSmsEventId(long smsEventId) {
		this.smsEventId = smsEventId;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public int getTotalSentCount() {
		return totalSentCount;
	}

	public void setTotalSentCount(int totalSentCount) {
		this.totalSentCount = totalSentCount;
	}

}
