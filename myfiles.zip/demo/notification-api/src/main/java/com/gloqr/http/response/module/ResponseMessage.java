package com.gloqr.http.response.module;

public class ResponseMessage {

	public static final String SUCCESS = "Success";
}
