package com.gloqr.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.gloqr.constants.SchedulerType;
import com.gloqr.dao.SchedulingDao;
import com.gloqr.entities.Event;
import com.gloqr.entities.SchedulerBasicConfig;
import com.gloqr.entities.SchedulerJobInfo;

@Service
public class SchedulerServiceImpl implements SchedulerService {

	Logger log = LogManager.getLogger();

	@Autowired
	private SchedulingDao schedulingDao;

	@Autowired
	private NotificationService notificationService;

	@Override
	public void saveSchedulerJobInfo(SchedulerJobInfo schedulerJobInfo) {
		List<SchedulerBasicConfig> schedulerBasicConfigs = schedulingDao
				.getSchedulerConfigsBySchedulerGroup(schedulerJobInfo.getSchedulerGroup());
		schedulerJobInfo.setSchedulerBasicConfigs(schedulerBasicConfigs);
		schedulingDao.saveSchedulerJobInfo(schedulerJobInfo);
	}

	@Scheduled(fixedRate = 10000)
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true, noRollbackFor = Exception.class)
	public void executeHourlyJobs() {
		List<SchedulerJobInfo> jobs = schedulingDao.getHourlyExecutedJobs();
		if (!jobs.isEmpty()) {
			manageHourlyExecutedJobs(jobs);
		} 

	}

	private void manageHourlyExecutedJobs(List<SchedulerJobInfo> jobs) {
		jobs.forEach(jobInfo -> {

			int hourlyExecutedCount = jobInfo.getHourlyExecutedCount();

			int freq = jobInfo.getSchedulerBasicConfigs().stream()
					.filter(j -> j.getSchedulerType().equals(SchedulerType.HOURLY)).findFirst().get().getFrequency();
			if (hourlyExecutedCount < freq) {
				log.info("Hourly Executing jobs name " + jobInfo.getJobName());
				List<Event> events = new ArrayList<>();
				if (jobInfo.getSmsEvent() != null)
					events.add(jobInfo.getSmsEvent());
				if (jobInfo.getEmailEvent() != null)
					events.add(jobInfo.getEmailEvent());
				notificationService.sendNotifications(events);

				log.info("Increasing Hourly Executed Count by 1 for " + jobInfo.getJobName());
				jobInfo.setHourlyExecutedCount(hourlyExecutedCount + 1);
				int nextExecutedCount = hourlyExecutedCount + 1;
				if (nextExecutedCount == freq) {
					log.info("Updating Hourly Execution Complete true for " + jobInfo.getJobName());
					jobInfo.setHourlyExecutionComplete(true);
				}
				setJobExecutionCompleteStatus(jobInfo);
				schedulingDao.saveSchedulerJobInfo(jobInfo);
			}
		});
	}

	@Scheduled(fixedRate = 10000000)
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true, noRollbackFor = Exception.class)
	public void executeDailyJobs() {
		List<SchedulerJobInfo> jobs = schedulingDao.getDailyExecutedJobs();
		if (!jobs.isEmpty()) {
			manageDailyExecutedJobs(jobs);
		} 

	}

	private void manageDailyExecutedJobs(List<SchedulerJobInfo> jobs) {
		jobs.forEach(jobInfo -> {

			int dailyExecutedCount = jobInfo.getDailyExecutedCount();

			int freq = jobInfo.getSchedulerBasicConfigs().stream()
					.filter(j -> j.getSchedulerType().equals(SchedulerType.DAILY)).findFirst().get().getFrequency();
			if (dailyExecutedCount < freq) {
				log.info("Daily Executing jobs name " + jobInfo.getJobName());
				List<Event> events = new ArrayList<>();
				if (jobInfo.getSmsEvent() != null)
					events.add(jobInfo.getSmsEvent());
				if (jobInfo.getEmailEvent() != null)
					events.add(jobInfo.getEmailEvent());
				// notificationService.sendNotifications(events);

				log.info("Increasing Daily Executed Count by 1 for " + jobInfo.getJobName());
				jobInfo.setDailyExecutedCount(dailyExecutedCount + 1);
				int nextExecutedCount = dailyExecutedCount + 1;
				if (nextExecutedCount == freq) {
					log.info("Updating Daily Execution Complete true for " + jobInfo.getJobName());
					jobInfo.setDailyExecutionComplete(true);
				}
				setJobExecutionCompleteStatus(jobInfo);
				schedulingDao.saveSchedulerJobInfo(jobInfo);
			}
		});
	}

	@Scheduled(fixedRate = 10000000)
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true, noRollbackFor = Exception.class)
	public void executeWeeklyJobs() {
		List<SchedulerJobInfo> jobs = schedulingDao.getWeeklyExecutedJobs();
		if (!jobs.isEmpty()) {
			manageWeeklyExecutedJobs(jobs);
		} 

	}

	private void manageWeeklyExecutedJobs(List<SchedulerJobInfo> jobs) {
		jobs.forEach(jobInfo -> {

			int weeklyExecutedCount = jobInfo.getWeeklyExecutedCount();

			int freq = jobInfo.getSchedulerBasicConfigs().stream()
					.filter(j -> j.getSchedulerType().equals(SchedulerType.WEEKLY)).findFirst().get().getFrequency();
			if (weeklyExecutedCount < freq) {
				log.info("Weekly Executing jobs name " + jobInfo.getJobName());
				List<Event> events = new ArrayList<>();
				if (jobInfo.getSmsEvent() != null)
					events.add(jobInfo.getSmsEvent());
				if (jobInfo.getEmailEvent() != null)
					events.add(jobInfo.getEmailEvent());
				// notificationService.sendNotifications(events);

				log.info("Increasing Weekly Executed Count by 1 for " + jobInfo.getJobName());
				jobInfo.setWeeklyExecutedCount(weeklyExecutedCount + 1);
				int nextExecutedCount = weeklyExecutedCount + 1;
				if (nextExecutedCount == freq) {
					log.info("Updating Weekly Execution Complete true for " + jobInfo.getJobName());
					jobInfo.setWeeklyExecutionComplete(true);
				}
				setJobExecutionCompleteStatus(jobInfo);
				schedulingDao.saveSchedulerJobInfo(jobInfo);
			}
		});
	}

	@Scheduled(fixedRate = 10000000)
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true, noRollbackFor = Exception.class)
	public void executeMonthlyJobs() {
		List<SchedulerJobInfo> jobs = schedulingDao.getMonthlyExecutedJobs();
		if (!jobs.isEmpty()) {
			manageMonthlyExecutedJobs(jobs);
		} 

	}

	private void manageMonthlyExecutedJobs(List<SchedulerJobInfo> jobs) {
		jobs.forEach(jobInfo -> {

			int monthlyExecutedCount = jobInfo.getMonthlyExecutedCount();

			int freq = jobInfo.getSchedulerBasicConfigs().stream()
					.filter(j -> j.getSchedulerType().equals(SchedulerType.MONTHLY)).findFirst().get().getFrequency();
			if (monthlyExecutedCount < freq) {
				log.info("Monthly Executing jobs name " + jobInfo.getJobName());
				List<Event> events = new ArrayList<>();
				if (jobInfo.getSmsEvent() != null)
					events.add(jobInfo.getSmsEvent());
				if (jobInfo.getEmailEvent() != null)
					events.add(jobInfo.getEmailEvent());
				// notificationService.sendNotifications(events);

				log.info("Increasing Monthly Executed Count by 1 for " + jobInfo.getJobName());
				jobInfo.setMonthlyExecutedCount(monthlyExecutedCount + 1);
				int nextExecutedCount = monthlyExecutedCount + 1;
				if (nextExecutedCount == freq) {
					log.info("Updating Monthly Execution Complete true for " + jobInfo.getJobName());
					jobInfo.setMonthlyExecutionComplete(true);
				}
				setJobExecutionCompleteStatus(jobInfo);
				schedulingDao.saveSchedulerJobInfo(jobInfo);
			}
		});
	}

	@Scheduled(fixedRate = 10000000)
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true, noRollbackFor = Exception.class)
	public void executeYearlyJobs() {
		List<SchedulerJobInfo> jobs = schedulingDao.getYearlyExecutedJobs();
		if (!jobs.isEmpty()) {
			manageYearlyExecutedJobs(jobs);
		} 

	}

	private void manageYearlyExecutedJobs(List<SchedulerJobInfo> jobs) {
		jobs.forEach(jobInfo -> {

			int yearlyExecutedCount = jobInfo.getYearlyExecutedCount();

			int freq = jobInfo.getSchedulerBasicConfigs().stream()
					.filter(j -> j.getSchedulerType().equals(SchedulerType.YEARLY)).findFirst().get().getFrequency();
			if (yearlyExecutedCount < freq) {
				log.info("Yearly Executing jobs name " + jobInfo.getJobName());
				List<Event> events = new ArrayList<>();
				if (jobInfo.getSmsEvent() != null)
					events.add(jobInfo.getSmsEvent());
				if (jobInfo.getEmailEvent() != null)
					events.add(jobInfo.getEmailEvent());
				// notificationService.sendNotifications(events);

				log.info("Increasing Yearly Executed Count by 1 for " + jobInfo.getJobName());
				jobInfo.setYearlyExecutedCount(yearlyExecutedCount + 1);
				int nextExecutedCount = yearlyExecutedCount + 1;
				if (nextExecutedCount == freq) {
					log.info("Updating Yearly Execution Complete true for " + jobInfo.getJobName());
					jobInfo.setYearlyExecutionComplete(true);
				}
				setJobExecutionCompleteStatus(jobInfo);
				schedulingDao.saveSchedulerJobInfo(jobInfo);
			}
		});
	}

	private void setJobExecutionCompleteStatus(SchedulerJobInfo jobInfo) {

		boolean isComplete = false;

		for (SchedulerBasicConfig jobConfig : jobInfo.getSchedulerBasicConfigs()) {

			if (jobConfig.getSchedulerType().equals(SchedulerType.HOURLY)) {
				if (jobInfo.isHourlyExecutionComplete()) {
					isComplete = true;
				} else {
					isComplete = false;
					break;
				}
			}

			if (jobConfig.getSchedulerType().equals(SchedulerType.DAILY)) {
				if (jobInfo.isDailyExecutionComplete()) {
					isComplete = true;
				} else {
					isComplete = false;
					break;
				}
			}

			if (jobConfig.getSchedulerType().equals(SchedulerType.MONTHLY)) {
				if (jobInfo.isMonthlyExecutionComplete()) {
					isComplete = true;
				} else {
					isComplete = false;
					break;
				}
			}

			if (jobConfig.getSchedulerType().equals(SchedulerType.WEEKLY)) {
				if (jobInfo.isWeeklyExecutionComplete()) {
					isComplete = true;
				} else {
					isComplete = false;
					break;
				}
			}

			if (jobConfig.getSchedulerType().equals(SchedulerType.YEARLY)) {
				if (jobInfo.isYearlyExecutionComplete()) {
					isComplete = true;
				} else {
					isComplete = false;
					break;
				}
			}

		}
		jobInfo.setCompleted(isComplete);
	}

	@Override
	public void unscheduleJob(String jobName) {
		schedulingDao.unscheduleJobByJobName(jobName);
	}

}
