package com.gloqr.notification.aspect;

import com.gloqr.entities.EmailEvent;
import com.gloqr.entities.SmsEvent;

public class SmeFaceConsoleLogger implements SmefaceLogger
{

	@Override
	public void logRequest(SmsEvent event)
	{
		System.out.println("Notification sent to: " + event.getMobileNo());		
	}

	@Override
	public void logRequest(EmailEvent event)
	{
		System.out.println("Notification sent to: " + event.getEmailId());		
	}
}
