
package com.gloqr.notification;

import java.io.IOException;

import javax.mail.MessagingException;

import com.gloqr.entities.Event;

public abstract class Publisher
{
	public abstract void publish(Event event) throws MessagingException ;
}
