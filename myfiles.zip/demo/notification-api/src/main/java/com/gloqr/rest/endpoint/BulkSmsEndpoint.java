package com.gloqr.rest.endpoint;

import javax.ws.rs.client.Client;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class BulkSmsEndpoint {

	private Client client;
	private String endPoint;
	private String smsApiKey;
	
	

	Logger log = LogManager.getLogger(BulkSmsEndpoint.class.getName());

	public BulkSmsEndpoint(Client client, String endPoint,String smsApiKey) {
		this.client = client;
		this.endPoint = endPoint;
		this.smsApiKey=smsApiKey;
	}

	public void callBulkSmsApi(String mobileNumber, String message, String sender) {

		Response response = client.target(endPoint).queryParam("apikey", smsApiKey).queryParam("sender", sender)
				.queryParam("number", mobileNumber).queryParam("message", message).request().get();
		int responseCode = response.getStatus();
		if (responseCode == 200) {
			String res = response.readEntity(String.class);
			String messageId = res.trim().split("\n")[0];
			log.info("SMS sent with message Id : " + messageId);
		} else {
			log.error("Error sending SMS : Mobile No : " + mobileNumber + " , message : " + message
					+ " . Status code : " + response.getStatusInfo().getStatusCode() + " , Reason : "
					+ response.getStatusInfo().getReasonPhrase());
		}

	}

}
