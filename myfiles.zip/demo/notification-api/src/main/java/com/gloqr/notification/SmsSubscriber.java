package com.gloqr.notification;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.entities.Event;
import com.gloqr.entities.SmsEvent;
import com.gloqr.rest.endpoint.BulkSmsEndpoint;
import com.gloqr.service.SmsNotificationService;

@Service
public class SmsSubscriber extends Subscriber {
	@Autowired
	SmsNotificationService smsNotificationService;

	@Autowired
	BulkSmsEndpoint bulkSmsEndpoint;

	Logger log = LogManager.getLogger(SmsSubscriber.class.getName());

	@Override
	public void inform(Event event) {
		SmsEvent smsEvent = (SmsEvent) event;
		log.info("SMS : " + smsEvent.getEventMessage() + " sending to " + smsEvent.getMobileNo());
		bulkSmsEndpoint.callBulkSmsApi(smsEvent.getMobileNo(), smsEvent.getEventMessage(), smsEvent.getSender());
		smsEvent.setTotalSentCount(smsEvent.getTotalSentCount() + 1);
		smsNotificationService.saveSmsToDB(smsEvent);
		log.info("SMS : sent to " + smsEvent.getMobileNo());
	}

	public EventType getSubscriberEventType() {
		return EventType.SMSEVENT;
	}
}
