package com.gloqr.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.gloqr.constants.SchedulerGroup;
import com.gloqr.constants.SchedulerType;

@Entity
@Table(name = "scheduler_basic_config")
public class SchedulerBasicConfig {

	@Id
	@GeneratedValue
	private Long configId;

	@Column(name = "scheduler_type")
	@Enumerated(EnumType.STRING)
	private SchedulerType schedulerType;
	
	@Column(name = "scheduler_group")
	@Enumerated(EnumType.STRING)
	private SchedulerGroup schedulerGroup;

	@Column(name = "frequency")
	private int frequency;

	public Long getConfigId() {
		return configId;
	}

	public void setConfigId(Long configId) {
		this.configId = configId;
	}

	public SchedulerType getSchedulerType() {
		return schedulerType;
	}

	public void setSchedulerType(SchedulerType schedulerType) {
		this.schedulerType = schedulerType;
	}

	public int getFrequency() {
		return frequency;
	}

	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}

}
