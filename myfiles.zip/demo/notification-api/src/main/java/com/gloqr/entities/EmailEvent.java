
package com.gloqr.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.gloqr.notification.aspect.SmefaceLogger;

@Entity(name = "notification_email_event")
public class EmailEvent extends Event {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "email_event_id")
	private Long emailEventId;

	@Column(name = "email_id")
	private String emailId;

	@Column(name = "email_subject")
	private String subject;

	@Column(name = "eventMessage", columnDefinition = "TEXT")
	private String eventMessage;

	@Column(name = "attachment_file_location")
	private String attachmentFileLocation;

	@Column(name = "totalSentCount")
	private int totalSentCount;

	public void acceptLogIntercepter(SmefaceLogger logger) {
		logger.logRequest(this);
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public int getTotalSentCount() {
		return totalSentCount;
	}

	public void setTotalSentCount(int totalSentCount) {
		this.totalSentCount = totalSentCount;
	}

	public String getEventMessage() {
		return eventMessage;
	}

	public void setEventMessage(String eventMessage) {
		this.eventMessage = eventMessage;
	}

	public Long getEmailEventId() {
		return emailEventId;
	}

	public void setEmailEventId(Long emailEventId) {
		this.emailEventId = emailEventId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAttachmentFileLocation() {
		return attachmentFileLocation;
	}

	public void setAttachmentFileLocation(String attachmentFileLocation) {
		this.attachmentFileLocation = attachmentFileLocation;
	}

}
