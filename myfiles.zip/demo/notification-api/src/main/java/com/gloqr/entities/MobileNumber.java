package com.gloqr.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/*@Entity(name = "motification_mobile_nos")*/
public class MobileNumber {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "mobile_num_id")
	private long id;

	@Column(name = "mobile_no")
	private Long mobileNo;

	@Column(name = "total_sent_count")
	private int totalSentCount;

	@ManyToOne(optional = false)
	@JoinColumn(name = "sms_event_id")
	private SmsEvent smsEvent;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public int getTotalSentCount() {
		return totalSentCount;
	}

	public void setTotalSentCount(int totalSentCount) {
		this.totalSentCount = totalSentCount;
	}

	public SmsEvent getSmsEvent() {
		return smsEvent;
	}

	public void setSmsEvent(SmsEvent smsEvent) {
		this.smsEvent = smsEvent;
	}

	@Override
	public String toString() {
		return "MobileNumber [mobileNo=" + mobileNo + ", totalSentCount=" + totalSentCount + "]";
	}

}
