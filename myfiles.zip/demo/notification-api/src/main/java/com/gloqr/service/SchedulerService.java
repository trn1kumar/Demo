package com.gloqr.service;

import com.gloqr.entities.SchedulerJobInfo;

public interface SchedulerService {

	void saveSchedulerJobInfo(SchedulerJobInfo schedulerJobInfo);

	void unscheduleJob(String jobName);

}
