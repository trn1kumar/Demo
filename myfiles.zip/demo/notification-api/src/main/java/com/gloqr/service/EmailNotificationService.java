package com.gloqr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.entities.EmailEvent;
import com.gloqr.jpa.repositories.EmailNotificationRepository;

@Service
public class EmailNotificationService {

	@Autowired
	private EmailNotificationRepository emailNotificationRepository;

	public void saveEmailToDB(EmailEvent emailEvent) {
		emailNotificationRepository.save(emailEvent);
	}

}
