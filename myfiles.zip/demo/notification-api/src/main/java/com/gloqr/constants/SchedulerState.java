package com.gloqr.constants;

public enum SchedulerState {

	WAITING,COMPLETED,RUNNING
}
