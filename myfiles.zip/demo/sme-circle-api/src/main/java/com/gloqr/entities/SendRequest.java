package com.gloqr.entities;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.gloqr.constants.CircleState;

@Document(collection = "sme_send_request")
public class SendRequest extends CircleStatusInfo {

	@Id
	private String sendReqUuid;

	@Field(value = "to_sme_id")
	private String toSmeId;

	public SendRequest() {
		super();
	}

	public SendRequest(String toSmeId, CircleState state) {
		super(state);
		this.toSmeId = toSmeId;
	}

	public String getToSmeId() {
		return toSmeId;
	}

	public void setToSmeId(String toSmeId) {
		this.toSmeId = toSmeId;
	}

	public String getSendReqUuid() {
		return sendReqUuid;
	}

	public void setSendReqUuid(String sendReqUuid) {
		this.sendReqUuid = sendReqUuid;
	}

}
