package com.gloqr.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.Roles;
import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.CountAndData;
import com.gloqr.dto.SMECircleDto;
import com.gloqr.dto.SMEDto;
import com.gloqr.entities.ReceiveRequest;
import com.gloqr.entities.SMECircle;
import com.gloqr.entities.SMEConnection;
import com.gloqr.entities.SendRequest;
import com.gloqr.exception.CustomException;
import com.gloqr.model.Privacy;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.security.context.holder.UserDetails;
import com.gloqr.service.MutualConnectionService;
import com.gloqr.service.SMECircleService;
import com.gloqr.service.SMEDetailServiceImpl;
import com.gloqr.service.SMEStatusCheckService;
import com.gloqr.vo.ConnectionVo;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.ROOT_API)
@SuppressWarnings("rawtypes")
public class SMECircleController {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private SMECircleService circleService;

	@Autowired
	private SMEDetailServiceImpl smeDetailService;

	@Autowired
	private MutualConnectionService mutualConnectionService;

	@Autowired
	private SMEStatusCheckService smeStatusCheckService;

	@PreAuthorize(Roles.SME_ADMIN)
	@PostMapping(UrlMapping.CIRCLE)
	public ResponseEntity<CustomHttpResponse> circle(Authentication authentication) {
		final UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = user.getSmeId();
		final String loggedInUserId = user.getUserId();

		log.info("Request for creating CIRCLE by userId: {} and smeId: {}", loggedInUserId, loggedInSmeId);

		try {
			if (loggedInUserId == null || loggedInSmeId == null) {
				throw new CustomException("either 'userId' or 'smeId' is null.required both.", HttpStatus.BAD_REQUEST);
			}
			circleService.saveOrUpdateSMECricle(new SMECircle(loggedInSmeId, loggedInUserId));
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse("Circle created Successfully", HttpStatus.CREATED);

	}

	@PreAuthorize(Roles.SME_ADMIN)
	@PostMapping(UrlMapping.SEND_REQ)
	public ResponseEntity<CustomHttpResponse> sendRequest(Authentication authentication,
			@RequestBody SMECircleDto sme) {
		final UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = user.getSmeId();
		final String loggedInUserId = user.getUserId();
		final String smeId = sme.getSmeId();
		log.info("Sending Circle Request by smeId: {} to smeId: {}", loggedInSmeId, smeId);
		try {
			circleService.sendRequest(loggedInSmeId, loggedInUserId, smeId);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse("Request Sent Successfully", HttpStatus.OK);
	}

	@PreAuthorize(Roles.SME_ADMIN)
	@PostMapping(UrlMapping.ACCEPT_REQUEST)
	public ResponseEntity<CustomHttpResponse> acceptReceivedRequest(Authentication authentication,
			@RequestBody ConnectionVo connectionVo) {
		final UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = user.getSmeId();
		final String receivedReqId = connectionVo.getReceiveReqUuid();
		log.info("Accepting Received Request by smeId: {} and receivedReqId: {}", loggedInSmeId, receivedReqId);

		try {
			circleService.makeConnection(loggedInSmeId, receivedReqId);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse("Request Accepted Successfully", HttpStatus.OK);
	}

	@PreAuthorize(Roles.SME_ADMIN)
	@PostMapping(UrlMapping.REJECT_REQUEST)
	public ResponseEntity<CustomHttpResponse> rejectReceivedRequest(Authentication authentication,
			@RequestBody ConnectionVo connectionVo) {

		final UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = user.getSmeId();
		final String receivedReqId = connectionVo.getReceiveReqUuid();
		log.info("Rejecting Received Request by smeId: {} and receivedReqId: {}", loggedInSmeId, receivedReqId);

		try {
			circleService.rejectReceivedRequest(loggedInSmeId, receivedReqId);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse("Request Rejected Successfully", HttpStatus.OK);
	}

	@PreAuthorize(Roles.SME_ADMIN)
	@PostMapping(UrlMapping.CANCEL_REQUEST)
	public ResponseEntity<CustomHttpResponse> cancelSentRequest(Authentication authentication,
			@RequestBody ConnectionVo connectionVo) {
		final UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = user.getSmeId();
		final String sentReqId = connectionVo.getSendReqUuid();
		log.info("Canceling Sent Request by smeId: {} and sentReqId: {}", loggedInSmeId, sentReqId);
		try {
			circleService.cancelSentRequest(loggedInSmeId, sentReqId);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse("Request Canceled Successfully", HttpStatus.OK);

	}

	@PreAuthorize(Roles.SME_ADMIN)
	@PostMapping(UrlMapping.REMOVE_CONNECTION)
	public ResponseEntity<CustomHttpResponse> removeBusinessCircleConnection(Authentication authentication,
			@RequestBody ConnectionVo connectionVo) {
		final UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = user.getSmeId();
		final String connectionId = connectionVo.getConnectionUuid();
		log.info("Removing connection from cricle  by smeId: {} and connectionId: {}", loggedInSmeId, connectionId);
		try {
			circleService.removeConnection(loggedInSmeId, connectionId);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse("Request Removed Successfully", HttpStatus.OK);

	}

	@PreAuthorize(Roles.SME_ADMIN)
	@GetMapping(UrlMapping.GET_RECEIVED_REQUEST)
	public ResponseEntity<CustomHttpResponse<List<SMEDto>>> getReceivedReqs(Authentication authentication) {
		final UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = user.getSmeId();

		List<ReceiveRequest> requests = null;
		List<SMEDto> smesInfo = null;
		try {
			requests = circleService.getAllReceivedRequest(loggedInSmeId);
			smesInfo = smeDetailService.getAllReceivedRequestSmes(requests);
			mutualConnectionService.findMutualConnection(smesInfo, null, loggedInSmeId);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(smesInfo, "Success", HttpStatus.OK);

	}

	@PreAuthorize(Roles.SME_ADMIN)
	@GetMapping(UrlMapping.GET_SENT_REQUEST)
	public ResponseEntity<CustomHttpResponse<List<SMEDto>>> getSentReqs(Authentication authentication) {
		final UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = user.getSmeId();

		List<SendRequest> sentRequests = null;
		List<SMEDto> smesInfo = null;
		try {
			sentRequests = circleService.getAllSentRequest(loggedInSmeId);
			smesInfo = smeDetailService.getAllSentRequestSmes(sentRequests);
			mutualConnectionService.findMutualConnection(smesInfo, null, loggedInSmeId);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(smesInfo, "Success", HttpStatus.OK);

	}

	@PreAuthorize(Roles.SME_ADMIN)
	@GetMapping(UrlMapping.GET_COUNTS)
	public ResponseEntity<CustomHttpResponse<SMECircleDto>> getBusinessCircleCounts(Authentication authentication) {
		final UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = user.getSmeId();

		return responseMaker.successResponse(circleService.getCounts(loggedInSmeId), "Success", HttpStatus.OK);

	}

	@SuppressWarnings("unchecked")
	@PreAuthorize(Roles.SME_ADMIN)
	@GetMapping(UrlMapping.GET_CONNECTION)
	public ResponseEntity<CustomHttpResponse<Object>> getCircleConnections(Authentication authentication,
			boolean isBusinessPostServiceRequest) {

		CountAndData countAnddata = null;
		List<SMEDto> smesInfo = null;

		try {
			UserDetails userDetails = (UserDetails) authentication.getPrincipal();
			countAnddata = circleService.getSMEConnections(userDetails.getSmeId());

			if (isBusinessPostServiceRequest) {
				return responseMaker.successResponse((List<SMEConnection>) countAnddata.getResult(), "Success",
						HttpStatus.OK);

			}

			smesInfo = smeDetailService.getAllConnectedSmes((List<SMEConnection>) countAnddata.getResult());
			mutualConnectionService.findMutualConnection(smesInfo, (List<SMEConnection>) countAnddata.getResult(),
					null);
			countAnddata.setResult(smesInfo);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(countAnddata, "Success", HttpStatus.OK);

	}

	@SuppressWarnings("unchecked")
	@PreAuthorize(Roles.SME_ADMIN_AND_USER)
	@GetMapping(UrlMapping.GET_SME_CONNECTION)
	public ResponseEntity<CustomHttpResponse<List<SMEDto>>> getCircleConnectionsForViewMode(
			Authentication authentication, @PathVariable String smeId) {

		CountAndData data = null;
		List<SMEDto> smesInfo = null;
		SMECircle loggedInSmeCircle = null;

		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		try {
			data = circleService.getSMEConnections(smeId);

			smesInfo = smeDetailService.getAllConnectedSmes((List<SMEConnection>) data.getResult());

			try {
				loggedInSmeCircle = circleService.getBusinessCircle(userDetails.getSmeId());
				if (loggedInSmeCircle.getMyConnections() != null && !loggedInSmeCircle.getMyConnections().isEmpty())
					mutualConnectionService.findMutualConnection(smesInfo, loggedInSmeCircle.getMyConnections(), null);

			} catch (CustomException e) {
				log.warn("Exception:: message:- {}", e.getErrorMessage());

			}
			smeStatusCheckService.checkStatus(loggedInSmeCircle, smesInfo, userDetails.getSmeId());

		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(smesInfo, "Success", HttpStatus.OK);

	}

	@PreAuthorize(Roles.SME_ADMIN)
	@GetMapping(UrlMapping.CIRCLE)
	public ResponseEntity<CustomHttpResponse<SMECircleDto>> getBusinessCircle(Authentication authentication) {

		final UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = user.getSmeId();

		SMECircle myCircle = null;
		SMECircleDto myCircleDto = null;
		try {
			myCircle = circleService.getBusinessCircle(loggedInSmeId);
			myCircleDto = smeDetailService.getSMECircle(myCircle);

		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(myCircleDto, "Success", HttpStatus.OK);

	}

	@PreAuthorize(Roles.SME_ADMIN)
	@GetMapping(UrlMapping.GET_PEOPLE_YOU_MAY_KNOW)
	public ResponseEntity<CustomHttpResponse<List<SMEDto>>> getPeopleYouMayKnow(Authentication authentication) {

		final UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = user.getSmeId();

		List<SMEDto> smes = null;

		try {
			smes = circleService.getPeopleYouMayKnow(loggedInSmeId);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(smes, "Success", HttpStatus.OK);

	}

	@PreAuthorize(Roles.SME_ADMIN)
	@PostMapping(UrlMapping.CHANGE_PRIVACY)
	public ResponseEntity<CustomHttpResponse> changeCirclePrivacy(@RequestBody Privacy circlePrivacy) {
		try {
			circleService.changeCirclePrivacy(circlePrivacy);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse("Circle Privacy Changed Successfully", HttpStatus.OK);
	}

}
