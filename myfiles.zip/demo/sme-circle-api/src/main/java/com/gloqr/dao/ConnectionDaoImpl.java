package com.gloqr.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.constants.CircleState;
import com.gloqr.entities.SMEConnection;
import com.gloqr.exception.CustomException;
import com.gloqr.repositories.MyConnectionRepository;


@Repository
public class ConnectionDaoImpl implements ConnectionDao {

	@Autowired
	MyConnectionRepository connectionRepo;

	@Override
	public void saveConnection(SMEConnection smeConnection) {
		try {
			connectionRepo.save(smeConnection);
		} catch (Exception e) {
			throw new CustomException("Exception in saveConnection() { } ", HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	public SMEConnection getConnection(String connectionUuId) {
		SMEConnection myConnection = connectionRepo.findByConnectionUuidAndCircleState(connectionUuId,
				CircleState.CONNECTED);

		if (myConnection == null) {
			throw new CustomException("No Connection with " + connectionUuId, HttpStatus.NOT_FOUND);
		}
		return myConnection;

	}
}
