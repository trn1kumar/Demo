package com.gloqr.dao;

import com.gloqr.entities.SMEConnection;

public interface ConnectionDao {

	
	public void saveConnection(SMEConnection smeConnection);
	
	public SMEConnection getConnection(String connectionUuId);
}
