package com.gloqr.dto;

public class CountAndData {

	private int seeMoreCount;
	private Object result;

	public CountAndData() {
		super();
	}
	
	public CountAndData(Object result) {
		super();
		this.setResult(result);
	}

	public CountAndData(int seeMoreCount) {
		super();
		this.seeMoreCount = seeMoreCount;
	}

	public CountAndData(int seeMoreCount, Object result) {
		super();
		this.seeMoreCount = seeMoreCount;
		this.setResult(result);
	}

	public int getSeeMoreCount() {
		return seeMoreCount;
	}

	public void setSeeMoreCount(int seeMoreCount) {
		this.seeMoreCount = seeMoreCount;
	}

	public Object getResult() {
		return result;
	}

	public void setResult(Object result) {
		this.result = result;
	}

}
