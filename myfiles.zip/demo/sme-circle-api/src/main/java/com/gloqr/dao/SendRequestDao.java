package com.gloqr.dao;

import java.util.List;

import com.gloqr.entities.SendRequest;

public interface SendRequestDao {

	public void addSentReqs(List<SendRequest> sendReqs);
	public void save(SendRequest sendReq);
	public SendRequest getSentRequest(String sendReqUuid);
}
