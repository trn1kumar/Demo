package com.gloqr.dto;

import java.util.Map;

public class SMEFilterDto {

	private Map<String, Object> filters;

	public Map<String, Object> getFilters() {
		return filters;
	}

	public void setFilters(Map<String, Object> filters) {
		this.filters = filters;
	}
}
