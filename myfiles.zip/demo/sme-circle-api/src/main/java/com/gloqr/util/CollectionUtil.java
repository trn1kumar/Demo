package com.gloqr.util;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class CollectionUtil {

	public <T> void reverse(List<T> list) {
		Collections.reverse(list);
	}
}
