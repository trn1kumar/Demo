package com.gloqr.constants;

public class CircleModuleConstants {

	private CircleModuleConstants() {
		throw new IllegalStateException("CircleModuleConstants class.could not initiate");
	}

	public class CircleStatus {
		public static final String SENT_REQ = "SENT_REQ";
		public static final String RECIEVED_REQ = "RECIEVED_REQ";
		public static final String CONNECTED = "CONNECTED";
		public static final String NEW = "NEW";
		public static final String OWNER = "OWNER";

	}

	public class CirclePrivacy {
		public static final String MY_CIRCLE = "Circle";
		public static final String PRIVATE = "Private";
		public static final String PUBLIC = "Public";
	}

}
