package com.gloqr.dao;

import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.entities.SMECircle;
import com.gloqr.exception.CustomException;
import com.gloqr.repositories.SMECircleRepository;

@Repository
public class SMECircleDaoImpl implements SMECircleDao {

	Logger log = LogManager.getLogger(SMECircleDaoImpl.class.getName());

	@Autowired
	SMECircleRepository circleRepository;

	@Override
	public SMECircle saveOrUpdateSMECricle(SMECircle smeCircle) {
		try {
			return circleRepository.save(smeCircle);
		} catch (Exception e) {
			throw new CustomException("Error while saving SMECircle.  message:  " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR,e);
		}

	}

	public SMECircle getSMECricle(String smeId) {
		Optional<SMECircle> smeCircleOpt = circleRepository.findBySmeId(smeId);
		if (smeCircleOpt.isPresent()) {
			return smeCircleOpt.get();
		} else {
			throw new CustomException("BusinessCircle not found for Given SME ", HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public boolean isBusinessCircleExist(String smeId) {
		return circleRepository.existsById(smeId);
	}
	
	

	@Override
	public void changePrivacy(String smeId, String privacy) {
		
	}

}
