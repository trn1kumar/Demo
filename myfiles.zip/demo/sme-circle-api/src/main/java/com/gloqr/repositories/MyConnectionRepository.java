package com.gloqr.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.gloqr.constants.CircleState;
import com.gloqr.entities.SMEConnection;

public interface MyConnectionRepository extends MongoRepository<SMEConnection, Long> {
	public SMEConnection findByConnectionUuidAndCircleState(String connectionUuId, CircleState circleState);
}
