package com.gloqr.constants;

public class UrlMapping {

	private UrlMapping() {
		throw new IllegalStateException("UrlMapping class.can't initiate");
	}

	public static final String ROOT_API = "/api/circle"; // root level api

	public static final String CIRCLE = "/";

	public static final String SEND_REQ = "/send-request"; // send request

	public static final String ACCEPT_REQUEST = "/add-connection"; // Accept Received Request

	public static final String REJECT_REQUEST = "/reject-received-request"; // Reject Received Request

	public static final String CANCEL_REQUEST = "/cancel-sent-request"; // Cancel Sent Request

	public static final String REMOVE_CONNECTION = "/remove-connection"; // Remove Connection

	public static final String GET_RECEIVED_REQUEST = "/received-requests"; // Get Received Request

	public static final String GET_SENT_REQUEST = "/sent-requests"; // Get Sent Request

	public static final String GET_CONNECTION = "/my-connections"; // Get Business Circle Connection

	public static final String GET_SME_CONNECTION = "/sme/{smeId}/circle-connections"; // Get Business Circle Connection
	// for sme

	public static final String GET_PEOPLE_YOU_MAY_KNOW = "/people-you-may-know";// get people you may know

	public static final String CHANGE_PRIVACY = "/privacy";

	public static final String GET_COUNTS = "/circle-counts";

	// SMEControllerUrls
	public static final String TOP_SMES = "/top-smes"; // getPlatformListedSmes.
	public static final String SMES = "/smes/fetch";
}
