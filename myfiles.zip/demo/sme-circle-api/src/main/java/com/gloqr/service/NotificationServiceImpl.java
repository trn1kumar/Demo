package com.gloqr.service;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.gloqr.configuration.PropertyValues;
import com.gloqr.constants.NotificationConstants;
import com.gloqr.dto.AddressDto;
import com.gloqr.dto.SMEDto;
import com.gloqr.entities.SMEConnection;
import com.gloqr.exception.CustomException;
import com.gloqr.model.notification.EmailEvent;
import com.gloqr.model.notification.SchedulerJobInfo;
import com.gloqr.model.notification.SmsEvent;
import com.gloqr.rest.endpoint.NotificationEndPoint;

@Service
@Async("taskExecutor")
public class NotificationServiceImpl extends NotificationConstants implements NotificationService {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private SMEService smeService;

	@Autowired
	private MutualConnectionService mutualConnectionService;

	@Autowired
	private NotificationEndPoint notificationEndpoint;

	@Autowired
	private TemplateEngine templateEngine;

	@Autowired
	private PropertyValues propertyValues;

	private void scheduleNewJob(String jobName, SmsEvent smsEvent, EmailEvent emailEvent) {
		SchedulerJobInfo schedulerJobInfo = new SchedulerJobInfo();
		schedulerJobInfo.setJobName(jobName);
		schedulerJobInfo.setSchedulerGroup(propertyValues.getSchedulerGroupName());
		schedulerJobInfo.setSmsEvent(smsEvent);
		schedulerJobInfo.setEmailEvent(emailEvent);

		notificationEndpoint.scheduleJob(schedulerJobInfo);
	}

	@Override
	public void unscheduleJob(String jobName) {
		try {
			notificationEndpoint.unscheduleJob(jobName);
		} catch (Exception e) {
			log.error("can't unscheduleJob ." + jobName, e);
		}
	}

	@Override
	public void scheduleReqReceivedNotification(SMEDto reqSenderSmeDeatils, List<SMEConnection> senderSmesConnections,
			SMEDto reqReceiverSmeDeatils, List<SMEConnection> receiverSmesConnections) {
		try {
			SmsEvent smsEvent = null;
			EmailEvent emailEvent = null;
			int mutualConnsCount = 0;
			int circleConnsCount = 0;
			String mobileNum = reqReceiverSmeDeatils.getContactPhone();
			String email = reqReceiverSmeDeatils.getContactEmail();
			checkMobileOrEmailAvailable(mobileNum, email);
			if (senderSmesConnections != null && receiverSmesConnections != null) {
				mutualConnsCount = mutualConnectionService
						.getMutualConnection(senderSmesConnections, receiverSmesConnections).size();
			}

			if (senderSmesConnections != null)
				circleConnsCount = senderSmesConnections.size();

			if (mobileNum != null) {
				smsEvent = createPendingReqNotificationSmsEvent(reqSenderSmeDeatils, mutualConnsCount, mobileNum);
			}

			if (email != null) {
				emailEvent = createPendingReqNotificationEmailEvent(reqSenderSmeDeatils, mutualConnsCount,
						circleConnsCount, email);
			}
			scheduleNewJob(PENDING_REQ_JOB_NAME_PREFIX + reqReceiverSmeDeatils.getReceiveReqUuid(), smsEvent,
					emailEvent);
		} catch (Exception e) {
			log.error("can't scheduleJob for Request Received Notification.", e);
		}

	}

	private SmsEvent createPendingReqNotificationSmsEvent(SMEDto reqSenderSmeDeatils, int mutualConnsCount,
			String mobileNum) {
		String smeAddress = "";
		String reqSenderSmeName = reqSenderSmeDeatils.getSmeName();
		AddressDto address = reqSenderSmeDeatils.getSmeAddress();
		if (address != null) {
			smeAddress = "(" + address.getLocality() + ", " + address.getCity() + ")";
		}

		String smsMsg = propertyValues.getPendingReqSmsMsg().replace("{smename}", reqSenderSmeName)
				.replace("{address}", smeAddress)
				.replace("{mutual-connection-count}", String.valueOf(mutualConnsCount));

		return new SmsEvent(mobileNum, smsMsg);

	}

	private EmailEvent createPendingReqNotificationEmailEvent(SMEDto reqSenderSmeDeatils, int mutualConnsCount,
			int circleConnsCount, String email) {
		String smeAddress = "";
		String reqSenderSmeName = reqSenderSmeDeatils.getSmeName();
		AddressDto address = reqSenderSmeDeatils.getSmeAddress();
		if (address != null) {
			smeAddress = "(" + address.getLocality() + ", " + address.getCity() + ")";
		}

		String emailSubject = propertyValues.getPendingReqEmailSub().replace("{smename}", reqSenderSmeName)
				.replace("{address}", smeAddress);
		Context context = new Context();
		context.setVariable("homeUrl", propertyValues.getBaseUrl());
		context.setVariable("smeDetailsUrl", propertyValues.getSmeDetailsUrl());
		context.setVariable("pendingReqUrl", propertyValues.getPendingReqUrl());
		context.setVariable("contentServerUrl", propertyValues.getContentServerUrl());
		context.setVariable("smeDetails", reqSenderSmeDeatils);
		context.setVariable("mutualConnsCount", mutualConnsCount);
		context.setVariable("circleConnsCount", circleConnsCount);
		String eventMessage = templateEngine.process(PENDING_REQ_NOTIFI_TEMPLATE, context);
		return new EmailEvent(email, emailSubject, eventMessage);
	}

	@Override
	public void scheduleReqAcceptedNotification(String reqSentUuid, String reqAcceptedSmeId,
			List<SMEConnection> reqAcceptedSmesConns, String reqSenderSmeId, List<SMEConnection> reqSenderSmesConns) {

		try

		{
			SmsEvent smsEvent = null;
			EmailEvent emailEvent = null;
			int mutualConnsCount = 0;
			int circleConnsCount = 0;
			Set<String> smeIds = new HashSet<>();
			smeIds.add(reqSenderSmeId);
			smeIds.add(reqAcceptedSmeId);
			Map<String, SMEDto> smesMap = smeService.getSpecificSmesDetails(smeIds);
			smeService.checkAllSmeIsPresent(smesMap, smeIds);
			SMEDto reqSenderSmeDeatils = smesMap.get(reqSenderSmeId);
			SMEDto reqAcceptedSmeDeatils = smesMap.get(reqAcceptedSmeId);

			String mobileNum = reqSenderSmeDeatils.getContactPhone();
			String email = reqSenderSmeDeatils.getContactEmail();
			checkMobileOrEmailAvailable(mobileNum, email);

			mutualConnsCount = mutualConnectionService.getMutualConnection(reqSenderSmesConns, reqAcceptedSmesConns)
					.size();

			circleConnsCount = reqAcceptedSmesConns.size();

			if (mobileNum != null) {
				smsEvent = createReqAcceptedNotificationSmsEvent(reqAcceptedSmeDeatils, mobileNum);
			}

			if (email != null) {
				emailEvent = createReqAcceptedNotificationEmailEvent(reqAcceptedSmeDeatils, mutualConnsCount,
						circleConnsCount, email);
			}

			scheduleNewJob(ACCEPTED_REQ_JOB_NAME_PREFIX + reqSentUuid, smsEvent, emailEvent);
		} catch (Exception e) {
			log.error("can't scheduleJob for Request Accepted Notification.", e);
		}

	}

	private SmsEvent createReqAcceptedNotificationSmsEvent(SMEDto reqAcceptedSmeDeatils,
			String mobileNum) {
		String smeAddress = "";
		String reqAcceptedSmeName = reqAcceptedSmeDeatils.getSmeName();
		AddressDto address = reqAcceptedSmeDeatils.getSmeAddress();
		if (address != null) {
			smeAddress = "(" + address.getLocality() + ", " + address.getCity() + ")";
		}

		String smsMsg = propertyValues.getAcceptedReqSmsMsg().replace("{smename}", reqAcceptedSmeName)
				.replace("{address}", smeAddress);

		return new SmsEvent(mobileNum, smsMsg);

	}

	private EmailEvent createReqAcceptedNotificationEmailEvent(SMEDto reqAcceptedSmeDeatils, int mutualConnsCount,
			int circleConnsCount, String email) {

		String smeAddress = "";
		String reqAcceptedSmeName = reqAcceptedSmeDeatils.getSmeName();
		AddressDto address = reqAcceptedSmeDeatils.getSmeAddress();
		if (address != null) {
			smeAddress = "(" + address.getLocality() + ", " + address.getCity() + ")";
		}

		String emailSubject = propertyValues.getAcceptedReqEmailSub().replace("{smename}", reqAcceptedSmeName)
				.replace("{address}", smeAddress);

		Context context = new Context();
		context.setVariable("homeUrl", propertyValues.getBaseUrl());
		context.setVariable("smeDetailsUrl", propertyValues.getSmeDetailsUrl());
		context.setVariable("contentServerUrl", propertyValues.getContentServerUrl());
		context.setVariable("circleUrl", propertyValues.getCircleUrl());
		context.setVariable("smeDetails", reqAcceptedSmeDeatils);
		context.setVariable("mutualConnsCount", mutualConnsCount);
		context.setVariable("circleConnsCount", circleConnsCount);
		String eventMessage = templateEngine.process(ACCEPTED_REQ_NOTIFI_TEMPLATE, context);
		return new EmailEvent(email, emailSubject, eventMessage);
	}

	private void checkMobileOrEmailAvailable(String mobileNum, String email) {
		if (mobileNum == null && email == null) {
			throw new CustomException("mobile no. and email both are null.required either mobile no or email.",
					HttpStatus.BAD_REQUEST);
		}
	}

}
