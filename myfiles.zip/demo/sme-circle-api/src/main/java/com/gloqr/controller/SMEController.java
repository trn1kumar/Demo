package com.gloqr.controller;

import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.Roles;
import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.SMEDto;
import com.gloqr.dto.SMEFilterAndResultResponse;
import com.gloqr.entities.SMECircle;
import com.gloqr.exception.CustomException;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.security.context.holder.UserDetails;
import com.gloqr.service.SMECircleServiceImpl;
import com.gloqr.service.SMEService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.ROOT_API)
public class SMEController {

	private Logger log = LogManager.getLogger();

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private SMEService smeService;

	@Autowired
	private SMECircleServiceImpl circleService;

	@PreAuthorize(Roles.SME_ADMIN)
	@GetMapping(UrlMapping.TOP_SMES)
	public ResponseEntity<CustomHttpResponse<List<SMEDto>>> getTopSmes(Authentication authentication) {

		UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSme = user.getSmeId();
		SMECircle smeCircle = null;
		List<SMEDto> smes = null;
		try {
			try {
				smeCircle = circleService.getBusinessCircle(loggedInSme);
			} catch (CustomException e) {
				log.warn("Exception:: message: {}", e.getErrorMessage());
			}
			smes = smeService.topSmes(smeCircle, loggedInSme);
		} catch (CustomException e) {
			throw e;
		}

		return responseMaker.successResponse(smes, "Success", HttpStatus.OK);

	}

	@GetMapping(UrlMapping.SMES)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse<SMEFilterAndResultResponse>> getAllSmes(
			@RequestParam(required = false) Set<String> categoriesFilterParam,
			@RequestParam(required = false) Set<String> citiesFilterParam, @RequestParam(required = false) Integer page,
			@RequestParam(required = false) Integer firstResult, Authentication authentication) {
		SMEFilterAndResultResponse smeFilterAndResultResponse = null;
		SMECircle smeCircle = null;

		try {
			UserDetails user = (UserDetails) authentication.getPrincipal();
			final String loggedInSme = user.getSmeId();
			try {
				smeCircle = circleService.getBusinessCircle(loggedInSme);
			} catch (CustomException e) {
				log.warn("Exception:: message: {}", e.getErrorMessage());
			}
			smeFilterAndResultResponse = smeService.getAllSmes(smeCircle, categoriesFilterParam, citiesFilterParam,
					page, firstResult, loggedInSme);

		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(smeFilterAndResultResponse, "Success", HttpStatus.OK);

	}
}
