package com.gloqr.repositories;


import org.springframework.data.mongodb.repository.MongoRepository;

import com.gloqr.constants.CircleState;
import com.gloqr.entities.ReceiveRequest;

public interface ReceiveRequestRepository extends MongoRepository<ReceiveRequest, Long> {

	public ReceiveRequest findByReceiveReqUuidAndCircleState(String receiveReqUuid,CircleState circleState);

}
