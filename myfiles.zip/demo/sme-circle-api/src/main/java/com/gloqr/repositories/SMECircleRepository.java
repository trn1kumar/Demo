package com.gloqr.repositories;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.gloqr.entities.SMECircle;

public interface SMECircleRepository extends MongoRepository<SMECircle, String> {

	Optional<SMECircle> findBySmeId(String smeId);

	/*
	 * @Modifying
	 * 
	 * @Transactional
	 * 
	 * @Query("update SMECircle c set c.circlePrivacy = :privacy where c.sUuid = :smeId"
	 * ) void changePrivacy(@Param("smeId") String smeId, @Param("privacy") String
	 * privacy);
	 * 
	 * @Query("select circlePrivacy from SMECircle c where c.sUuid = :smeId") String
	 * getPriavcy(@Param("smeId") String smeId);
	 */

}
