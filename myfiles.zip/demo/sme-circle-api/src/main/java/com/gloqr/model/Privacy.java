package com.gloqr.model;

public class Privacy {
	
	private String smeId;
	private String privacy;
	
	public String getSmeId() {
		return smeId;
	}
	public void setSmeId(String smeId) {
		this.smeId = smeId;
	}
	public String getPrivacy() {
		return privacy;
	}
	public void setPrivacy(String privacy) {
		this.privacy = privacy;
	}

}
