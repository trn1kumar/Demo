package com.gloqr.service;

import java.util.List;
import java.util.Set;

import com.gloqr.dto.SMEDto;
import com.gloqr.entities.SMEConnection;

public interface MutualConnectionService {

	public List<SMEDto> findMutualConnection(List<SMEDto> receivedRequestSmes, List<SMEConnection> myCircleConnections,
			String loggedInSmeId);

	public Set<String> getMutualConnection(List<SMEConnection> connectionsList1, List<SMEConnection> connectionsList2);
}
