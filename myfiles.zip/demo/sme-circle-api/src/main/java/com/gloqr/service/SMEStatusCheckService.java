package com.gloqr.service;

import java.util.List;

import com.gloqr.dto.SMEDto;
import com.gloqr.entities.ReceiveRequest;
import com.gloqr.entities.SMECircle;
import com.gloqr.entities.SMEConnection;
import com.gloqr.entities.SendRequest;

public interface SMEStatusCheckService {

	public void checkStatus(SMECircle myCircle, List<SMEDto> smes,String smeId);

	public void setStatusOfMyConnectedSmes(List<SMEConnection> myConn, List<SMEDto> smes);

	public void setStatusOfSentReqSmes(List<SendRequest> sentReq, List<SMEDto> smes);

	public void setStatusOfRecievedReqSmes(List<ReceiveRequest> recieveReq, List<SMEDto> smes);
}
