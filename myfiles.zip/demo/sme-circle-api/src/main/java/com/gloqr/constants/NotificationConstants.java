package com.gloqr.constants;

public class NotificationConstants {

	
	public static final String PENDING_REQ_JOB_NAME_PREFIX = "Pending_Req_";
	public static final String ACCEPTED_REQ_JOB_NAME_PREFIX = "Accepted_Req_";
	public static final String PENDING_REQ_NOTIFI_TEMPLATE = "pendingRequest.html";
	public static final String ACCEPTED_REQ_NOTIFI_TEMPLATE = "requestAccepted.html";
}
