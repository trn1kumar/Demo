package com.gloqr.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.dto.SMECircleDto;
import com.gloqr.dto.SMEDto;
import com.gloqr.entities.ReceiveRequest;
import com.gloqr.entities.SMECircle;
import com.gloqr.entities.SMEConnection;
import com.gloqr.entities.SendRequest;

@Service
public class SMEDetailServiceImpl {
	
	@Autowired
	SMEService smeService;
	
	
	public List<SMEDto> getAllReceivedRequestSmes(List<ReceiveRequest> requests) {
		List<SMEDto> receivedRequestSmes = new ArrayList<>();
		requests.stream().forEach(req -> {
			SMEDto sme = smeService.getSME(req.getFromSmeId());
			sme.setCreationDate(req.getCreationDate());
			sme.setReceiveReqUuid(req.getReceiveReqUuid());
			receivedRequestSmes.add(sme);
		});

		return receivedRequestSmes;
	}

	
	public List<SMEDto> getAllSentRequestSmes(List<SendRequest> sentRequests) {
		List<SMEDto> sentRequestSmes = new ArrayList<>();
		sentRequests.stream().forEach(req -> {
			SMEDto sme = smeService.getSME(req.getToSmeId());
			sme.setCreationDate(req.getCreationDate());
			sme.setSendReqUuid(req.getSendReqUuid());
			sentRequestSmes.add(sme);
		});
		return sentRequestSmes;
	}

	public List<SMEDto> getAllConnectedSmes(List<SMEConnection> circleConnections) {
		List<SMEDto> circleConnectionSmes = new ArrayList<>();
		circleConnections.stream().forEach(conn -> {
			SMEDto sme = smeService.getSME(conn.getSmeId());
			sme.setConnectionUuid(conn.getConnectionUuid());
			circleConnectionSmes.add(sme);
		});
		return circleConnectionSmes;
	}

	public SMECircleDto getSMECircle(SMECircle myCircle) {
		SMECircleDto circleDto = new SMECircleDto();
		
		
		circleDto.setSmeId(myCircle.getSmeId());
		if (myCircle.getSendRequests() != null && !myCircle.getSendRequests().isEmpty()) {
			circleDto.setSendReqCount(myCircle.getSendRequests().size());
			circleDto.setSendRequests(this.getAllSentRequestSmes(myCircle.getSendRequests()));
		}
		if (myCircle.getReceiveRequests() != null && !myCircle.getReceiveRequests().isEmpty()) {
			circleDto.setReceivedReqCount(myCircle.getReceiveRequests().size());
			circleDto.setReceiveRequests(this.getAllReceivedRequestSmes(myCircle.getReceiveRequests()));
		}
		if (myCircle.getMyConnections() != null && !myCircle.getMyConnections().isEmpty()) {
			circleDto.setConnectionCount(myCircle.getMyConnections().size());
			circleDto.setMyConnetions(this.getAllConnectedSmes(myCircle.getMyConnections()));
		}
		return circleDto;
	}

	

}
