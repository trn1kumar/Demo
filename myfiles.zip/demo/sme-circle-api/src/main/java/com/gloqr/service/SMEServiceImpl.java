package com.gloqr.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.dto.SMEDto;
import com.gloqr.dto.SMEFilterAndResultResponse;
import com.gloqr.entities.SMECircle;
import com.gloqr.exception.CustomException;
import com.gloqr.rest.endpoint.SmeEndPoint;

@Service
public class SMEServiceImpl implements SMEService {

	@Autowired
	SmeEndPoint smeInformationEndPoint;

	@Autowired
	SMEStatusCheckService smeStatusCheckService;

	@Override
	public SMEDto getSME(String smeId) {
		return smeInformationEndPoint.getSME(smeId);
	}

	@Override
	public List<SMEDto> getTopSME() {
		List<SMEDto> smes = null;
		try {
			smes = smeInformationEndPoint.getTopSME();
			return smes;

		} catch (CustomException e) {
			throw e;
		}

	}

	@Override
	public List<SMEDto> topSmes(SMECircle smeCircle, String loggedInSme) {
		List<SMEDto> smes = this.getTopSME();
		smeStatusCheckService.checkStatus(smeCircle, smes, loggedInSme);

		return smes;
	}

	@Override
	public SMEFilterAndResultResponse getAllSmes(SMECircle smeCircle, Set<String> categoriesFilterParam,
			Set<String> citiesFilterParam, Integer page, Integer firstResult, String loggedInSme) {
		SMEFilterAndResultResponse smeFilterAndResultResponse = null;

		smeFilterAndResultResponse = this.getAllSME(categoriesFilterParam, citiesFilterParam, page, firstResult);
		smeStatusCheckService.checkStatus(smeCircle, smeFilterAndResultResponse.getResult(), loggedInSme);

		return smeFilterAndResultResponse;
	}

	private SMEFilterAndResultResponse getAllSME(Set<String> categoriesFilterParam, Set<String> citiesFilterParam,
			Integer page, Integer firstResult) {
		SMEFilterAndResultResponse smeFilterAndResultResponse = null;
		try {
			smeFilterAndResultResponse = smeInformationEndPoint.getAllSME(categoriesFilterParam, citiesFilterParam,
					page, firstResult);
			if (smeFilterAndResultResponse == null) {
				throw new CustomException("SMEFilterAndResultResponse is Empty", HttpStatus.NOT_FOUND);
			}
		} catch (CustomException e) {
			throw e;
		}

		return smeFilterAndResultResponse;
	}

	@Override
	public Map<String, SMEDto> getSpecificSmesDetails(Set<String> smeIds) {
		return smeInformationEndPoint.getSpecificSMEs(smeIds);
	}

	public void checkAllSmeIsPresent(Map<String, SMEDto> smesMap, Set<String> smeIds) {

		smeIds.parallelStream().forEach(smeId -> {
			if (!smesMap.containsKey(smeId)) {
				throw new CustomException("Given SME is in deactive mode or not found with smeId: " + smeId,
						HttpStatus.NOT_FOUND);
			}
		});

	}

}
