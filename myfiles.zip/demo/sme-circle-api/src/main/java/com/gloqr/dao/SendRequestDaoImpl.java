package com.gloqr.dao;

import java.util.List;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.constants.CircleState;
import com.gloqr.entities.SendRequest;
import com.gloqr.exception.CustomException;
import com.gloqr.repositories.SendRequestRepository;

@Repository
public class SendRequestDaoImpl implements SendRequestDao {

	@Autowired
	SendRequestRepository sendReqRepo;

	Logger log = LogManager.getLogger(SendRequestDaoImpl.class.getName());

	@Override
	public void addSentReqs(List<SendRequest> sendReqs) {
		try {
			sendReqRepo.saveAll(sendReqs);
		} catch (Exception e) {
			log.log(Level.ALL, e.getMessage());
			throw new CustomException("Exception in saveMultipleSendReqs(). message:  " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	
	@Override
	public void save(SendRequest sendReq) {
		try {
			sendReqRepo.save(sendReq);
		} catch (Exception e) {
			log.log(Level.ALL, e.getMessage());
			throw new CustomException("Exception in saveSendRequest(). message:  " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	
	public SendRequest getSentRequest(String sendReqUuid) {

		SendRequest sentRequest = sendReqRepo.findBySendReqUuidAndCircleState(sendReqUuid,
				CircleState.PENDING);
		if (sentRequest == null) {
			throw new CustomException("No Sent Request Pending With " + sendReqUuid, HttpStatus.NOT_FOUND);
		}

		return sentRequest;
	}
	
	
}
