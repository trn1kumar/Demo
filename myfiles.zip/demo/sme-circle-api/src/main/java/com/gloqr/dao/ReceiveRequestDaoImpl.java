package com.gloqr.dao;

import java.util.List;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.constants.CircleState;
import com.gloqr.entities.ReceiveRequest;
import com.gloqr.exception.CustomException;
import com.gloqr.repositories.ReceiveRequestRepository;

@Repository
public class ReceiveRequestDaoImpl implements ReceiveRequestDao {

	@Autowired
	ReceiveRequestRepository receiveReqsRepo;

	Logger log = LogManager.getLogger(ReceiveRequestDaoImpl.class.getName());

	@Override
	public void addReceivedReqs(List<ReceiveRequest> receivedReqs) {

		try {
			receiveReqsRepo.saveAll(receivedReqs);
		} catch (Exception e) {
			log.log(Level.ALL, e.getMessage());
			throw new CustomException("Exception in saveMultipleSendReqs(). message:  " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public void saveReceivedReq(ReceiveRequest receiveRequest) {
		try {
			receiveReqsRepo.save(receiveRequest);
		} catch (Exception e) {
			log.log(Level.ALL, e.getMessage());
			throw new CustomException("Exception in saveReceivedReq(). message:  " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	@Override
	public ReceiveRequest getReceivedRequest(String receiveReqUuid) {

		ReceiveRequest receiveRequest = receiveReqsRepo.findByReceiveReqUuidAndCircleState(receiveReqUuid,
				CircleState.PENDING);

		if (receiveRequest == null) {
			throw new CustomException("No ReceiveRequest Pending with " + receiveReqUuid, HttpStatus.NOT_FOUND);
		}
		return receiveRequest;
	}

}
