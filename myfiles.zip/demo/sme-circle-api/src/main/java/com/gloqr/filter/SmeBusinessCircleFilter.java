package com.gloqr.filter;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.gloqr.dto.SMEDto;
import com.gloqr.entities.ReceiveRequest;
import com.gloqr.entities.SMECircle;
import com.gloqr.entities.SMEConnection;
import com.gloqr.entities.SendRequest;

@Component
public class SmeBusinessCircleFilter {

	/*
	 * @ filter My Circle
	 */
	public List<SMEDto> filterMyCircle(SMECircle myCircle, List<SMEDto> smes) {

		final List<String> myCircles = new ArrayList<>();

		if (myCircle.getMyConnections() != null && !myCircle.getMyConnections().isEmpty()) {
			for (SMEConnection conn : myCircle.getMyConnections()) {
				myCircles.add(conn.getSmeId());
			}
		}

		if (myCircle.getSendRequests() != null && !myCircle.getSendRequests().isEmpty()) {
			for (SendRequest req : myCircle.getSendRequests()) {
				myCircles.add(req.getToSmeId());

			}
		}

		if (myCircle.getReceiveRequests() != null && !myCircle.getReceiveRequests().isEmpty()) {
			for (ReceiveRequest req : myCircle.getReceiveRequests()) {
				myCircles.add(req.getFromSmeId());
			}
		}

		for (String smeUuid : myCircles) {
			smes = smes.parallelStream().filter(sme -> !sme.getsUuid().equals(smeUuid)).collect(Collectors.toList());
		}

		return smes;

	}

}
