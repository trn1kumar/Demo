package com.gloqr.service;

import java.util.List;

import com.gloqr.dto.CountAndData;
import com.gloqr.dto.SMECircleDto;
import com.gloqr.dto.SMEDto;
import com.gloqr.entities.ReceiveRequest;
import com.gloqr.entities.SMECircle;
import com.gloqr.entities.SMEConnection;
import com.gloqr.entities.SendRequest;
import com.gloqr.model.Privacy;

public interface SMECircleService {
	public void saveOrUpdateSMECricle(SMECircle circle);

	public void sendRequest(final String loggedInSmeId, final String loggedInUserId, final String reqReceiverSmeId);

	public void makeConnection(final String loggedInSmeId, final String receivedReqId);

	public void rejectReceivedRequest(final String loggedInSmeId, final String receivedReqId);

	public void cancelSentRequest(final String loggedInSmeId, final String sentReqId);

	public void removeConnection(final String loggedInSmeId, final String connectionId);

	public SMECircle getBusinessCircle(String smeId);

	public List<ReceiveRequest> getAllReceivedRequest(String smeId);


	public List<SendRequest> getAllSentRequest(String smeId);

	public List<SMEConnection> getAllConnections(String smeId);

	public List<SMEDto> getPeopleYouMayKnow(String smeId);

	public void changeCirclePrivacy(Privacy circlePrivacy);

	public String getPrivacy(String smeId);

	public CountAndData getSMEConnections(String smeId);

	public SMECircleDto getCounts(String smeId);

}
