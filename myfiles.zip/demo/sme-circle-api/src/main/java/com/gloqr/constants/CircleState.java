package com.gloqr.constants;

public enum CircleState {
	PENDING, ACCEPTED, REJECTED, CANCELED, CONNECTED, DISCONNECTED
}
