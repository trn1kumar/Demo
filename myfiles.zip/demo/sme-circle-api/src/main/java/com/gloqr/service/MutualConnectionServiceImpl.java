package com.gloqr.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.dto.SMEDto;
import com.gloqr.entities.SMEConnection;
import com.gloqr.exception.CustomException;

import io.jsonwebtoken.lang.Assert;

@Service
public class MutualConnectionServiceImpl implements MutualConnectionService {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private SMEService smeService;

	@Autowired
	private SMECircleService circleService;

	@Override
	public Set<String> getMutualConnection(List<SMEConnection> connectionsList1, List<SMEConnection> connectionsList2) {

		Set<String> mutualConnectionsIds = new HashSet<>();
		connectionsList1.parallelStream().forEach(connection -> {
			String connectionId = connection.getSmeId();
			Optional<SMEConnection> opt = connectionsList2.parallelStream()
					.filter(smeConnection -> connectionId.equals(smeConnection.getSmeId())).findFirst();

			if (opt.isPresent()) {
				mutualConnectionsIds.add(opt.get().getSmeId());
			}

		});

		return mutualConnectionsIds;
	}

	@Override
	public List<SMEDto> findMutualConnection(List<SMEDto> smes, List<SMEConnection> connections, String loggedInSmeId) {

		Set<String> mutualConnectionsIds = null;
		List<SMEConnection> connectionsList1 = null;

		try {
			if (connections != null) {
				// get mutual connection of own connections
				connectionsList1 = connections;
			} else {
				// get mutual connection of own sent requests and received requests and people
				// you may know
				StackTraceElement trace = new Exception().getStackTrace()[0];
				Assert.notNull(loggedInSmeId, "Id can not be null. Exception in " + trace.getClassName() + ". method "
						+ trace.getMethodName() + ". line number. " + trace.getLineNumber());

				connectionsList1 = circleService.getAllConnections(loggedInSmeId);

			}

			for (SMEDto sme : smes) {
				try {
					if (!sme.getsUuid().equals(loggedInSmeId)) {
						List<SMEConnection> connectionsList2 = circleService.getAllConnections(sme.getsUuid());
						mutualConnectionsIds = getMutualConnection(connectionsList1, connectionsList2);
						if (mutualConnectionsIds != null && !mutualConnectionsIds.isEmpty()) {
							Map<String, SMEDto> map = smeService.getSpecificSmesDetails(mutualConnectionsIds);
							List<SMEDto> smeDetails = new ArrayList<>(map.values());
							sme.setMutualConnectionCount(smeDetails.size());
							sme.setMutualConnections(smeDetails);
						}
					}
				} catch (CustomException e) {
					log.warn("Exception in findMutualConnection() ::  message:- {}", e.getErrorMessage());
				}
			}

		} catch (CustomException e) {
			log.warn("Exception in findMutualConnection() ::  message:- {}", e.getErrorMessage());
		}
		return smes;
	}
}
