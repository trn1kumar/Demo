package com.gloqr.dto;

import java.util.List;

public class SMEFilterAndResultResponse {

	private int totalCount;
	private SMEFilterDto filter;
	private List<SMEDto> result;
	
	
	public int getTotalCount() {
		return totalCount;
	}
	public SMEFilterDto getFilter() {
		return filter;
	}
	public List<SMEDto> getResult() {
		return result;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	public void setFilter(SMEFilterDto filter) {
		this.filter = filter;
	}
	public void setResult(List<SMEDto> result) {
		this.result = result;
	}

}
