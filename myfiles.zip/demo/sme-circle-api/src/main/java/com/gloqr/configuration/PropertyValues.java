package com.gloqr.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PropertyValues {

	@Value(PropertyNames.SCHEDULER_GROUP_NAME)
	private String schedulerGroupName;

	@Value(PropertyNames.PENDING_REQ_NOTIFI_SMS_MSG)
	private String pendingReqSmsMsg;

	@Value(PropertyNames.PENDING_REQ_NOTIFI_EMAIL_SUB)
	private String pendingReqEmailSub;

	@Value(PropertyNames.ACCEPTED_REQ_NOTIFI_SMS_MSG)
	private String acceptedReqSmsMsg;

	@Value(PropertyNames.ACCEPTED_REQ_NOTIFI_EMAIL_SUB)
	private String acceptedReqEmailSub;

	@Value(PropertyNames.BASE_URL)
	private String baseUrl;

	@Value(PropertyNames.SME_DETAILS_URL)
	private String smeDetailsUrl;

	@Value(PropertyNames.PENDING_REQ_URL)
	private String pendingReqUrl;

	@Value(PropertyNames.VIEW_CIRCLE_URL)
	private String circleUrl;

	@Value(PropertyNames.CONTENT_SERVER_URL)
	private String contentServerUrl;

	public String getPendingReqSmsMsg() {
		return pendingReqSmsMsg;
	}

	public void setPendingReqSmsMsg(String pendingReqSmsMsg) {
		this.pendingReqSmsMsg = pendingReqSmsMsg;
	}

	public String getPendingReqEmailSub() {
		return pendingReqEmailSub;
	}

	public void setPendingReqEmailSub(String pendingReqEmailSub) {
		this.pendingReqEmailSub = pendingReqEmailSub;
	}

	public String getAcceptedReqSmsMsg() {
		return acceptedReqSmsMsg;
	}

	public void setAcceptedReqSmsMsg(String acceptedReqSmsMsg) {
		this.acceptedReqSmsMsg = acceptedReqSmsMsg;
	}

	public String getAcceptedReqEmailSub() {
		return acceptedReqEmailSub;
	}

	public void setAcceptedReqEmailSub(String acceptedReqEmailSub) {
		this.acceptedReqEmailSub = acceptedReqEmailSub;
	}

	public String getSchedulerGroupName() {
		return schedulerGroupName;
	}

	public void setSchedulerGroupName(String schedulerGroupName) {
		this.schedulerGroupName = schedulerGroupName;
	}


	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	public String getSmeDetailsUrl() {
		return smeDetailsUrl;
	}

	public void setSmeDetailsUrl(String smeDetailsUrl) {
		this.smeDetailsUrl = smeDetailsUrl;
	}

	public String getPendingReqUrl() {
		return pendingReqUrl;
	}

	public void setPendingReqUrl(String pendingReqUrl) {
		this.pendingReqUrl = pendingReqUrl;
	}

	public String getCircleUrl() {
		return circleUrl;
	}

	public void setCircleUrl(String circleUrl) {
		this.circleUrl = circleUrl;
	}

	public String getContentServerUrl() {
		return contentServerUrl;
	}

	public void setContentServerUrl(String contentServerUrl) {
		this.contentServerUrl = contentServerUrl;
	}

	public static final class PropertyNames {

		private PropertyNames() {
			throw new IllegalStateException("PropertyNames class.can't initiate");
		}

		public static final String SCHEDULER_GROUP_NAME = "${scheduler.group-name}";
		public static final String PENDING_REQ_NOTIFI_SMS_MSG = "${notify.sms-msg.pending-req}";
		public static final String PENDING_REQ_NOTIFI_EMAIL_SUB = "${notify.email-subject.pending-req}";
		public static final String ACCEPTED_REQ_NOTIFI_SMS_MSG = "${notify.sms-msg.accepted-req}";
		public static final String ACCEPTED_REQ_NOTIFI_EMAIL_SUB = "${notify.email-subject.accepted-req}";

		public static final String BASE_URL = "${base-url}";
		public static final String SME_DETAILS_URL = "${sme.details.localized-url}";
		public static final String CONTENT_SERVER_URL = "${content-server.localized-url}";
		public static final String VIEW_CIRCLE_URL = "${my-connections.localized-url}";
		public static final String PENDING_REQ_URL = "${pending-req.localized-url}";

	}

}
