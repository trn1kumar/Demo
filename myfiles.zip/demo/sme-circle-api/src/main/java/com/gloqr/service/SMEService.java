package com.gloqr.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.gloqr.dto.SMEDto;
import com.gloqr.dto.SMEFilterAndResultResponse;
import com.gloqr.entities.SMECircle;

public interface SMEService {

	public SMEDto getSME(String smeId);

	public List<SMEDto> getTopSME();

	public List<SMEDto> topSmes(SMECircle smeCircle, String loggedInSme);

	public SMEFilterAndResultResponse getAllSmes(SMECircle smeCircle, Set<String> categoriesFilterParam,
			Set<String> citiesFilterParam, Integer page, Integer firstResult, String loggedInSme);

	public Map<String, SMEDto> getSpecificSmesDetails(Set<String> smeIds);
	
	
	public void checkAllSmeIsPresent(Map<String, SMEDto> smesMap, Set<String> smeIds);

}
