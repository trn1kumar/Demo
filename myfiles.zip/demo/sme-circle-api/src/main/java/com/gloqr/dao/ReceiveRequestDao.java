package com.gloqr.dao;

import java.util.List;

import com.gloqr.entities.ReceiveRequest;

public interface ReceiveRequestDao {

	public void addReceivedReqs(List<ReceiveRequest> receivedReqs);
	public void saveReceivedReq(ReceiveRequest receiveRequest);
	public ReceiveRequest getReceivedRequest(String receiveReqUuid);
}
