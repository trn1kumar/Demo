package com.gloqr.constants;

public enum CreditType {

	CIRCLE_CONNECTION(101, "Active Connections Allowed");
	
	private final int code;
	private final String value;

	private CreditType(int code,String value) {
		this.code = code;
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}
	
	public int getCode() {
		return this.code;
	}
	
}
