package com.gloqr.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_DEFAULT)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AddressDto {

	private String locality;
	private String city;
	private String state;
	
	public String getLocality() {
		return locality;
	}
	public String getCity() {
		return city;
	}
	public String getState() {
		return state;
	}
	public void setLocality(String locality) {
		this.locality = locality;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	
}
