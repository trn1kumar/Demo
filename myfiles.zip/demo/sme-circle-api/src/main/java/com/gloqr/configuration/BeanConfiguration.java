package com.gloqr.configuration;

import javax.annotation.Resource;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.gloqr.mongo.event.CascadingMongoEventListener;
import com.gloqr.rest.endpoint.NotificationEndPoint;
import com.gloqr.rest.endpoint.PricingEndpoint;
import com.gloqr.rest.endpoint.SmeEndPoint;

@Configuration
@EnableAsync
public class BeanConfiguration {

	Logger log = LogManager.getLogger();

	@Resource
	private Environment environment;

	@Bean
	public CascadingMongoEventListener mongoEventListener() {
		return new CascadingMongoEventListener();
	}

	@Bean(name = "taskExecutor")
	public TaskExecutor workExecutor() {
		int poolsize = 0;
		int maxPoolSize = 0;
		int capacity = 0;

		ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
		threadPoolTaskExecutor.setThreadNamePrefix(environment.getRequiredProperty("thread.name.prefix"));
		try {
			poolsize = Integer.parseInt(environment.getRequiredProperty("pool.size"));
			maxPoolSize = Integer.parseInt(environment.getRequiredProperty("max.pool.size"));
			capacity = Integer.parseInt(environment.getRequiredProperty("queue.capacity"));
		} catch (NumberFormatException e) {
			log.info(("Problem Occurred to read thread property " + e.getLocalizedMessage()
					+ " from application properties.make sure that provided property is integer"));
			System.exit(0);
		}
		threadPoolTaskExecutor.setCorePoolSize(poolsize);
		threadPoolTaskExecutor.setMaxPoolSize(maxPoolSize);
		threadPoolTaskExecutor.setQueueCapacity(capacity);
		threadPoolTaskExecutor.afterPropertiesSet();
		log	.info("ThreadPoolTaskExecutor set");
		return threadPoolTaskExecutor;
	}

	@Bean
	public SmeEndPoint smeInformationConfiguration() {
		Client client = ClientBuilder.newClient();
		String smeInformationEndPoint = environment.getRequiredProperty("sme.endpoint");
		String listTopSME = environment.getRequiredProperty("list.top.sme");
		String listAllSME = environment.getRequiredProperty("list.all.sme");
		String listSme = environment.getRequiredProperty("list.sme");
		String specificSMEsPath = environment.getRequiredProperty("list.specific.smes.path");
		return new SmeEndPoint(client, smeInformationEndPoint, listTopSME, listAllSME, listSme,
				specificSMEsPath);
	}

	@Bean
	public PricingEndpoint pricingEndpoint() {

		Client client = ClientBuilder.newClient();
		String pricingEndpointUrl = environment.getRequiredProperty("pricing.endpoint");
		String checkCreditsPath = environment.getRequiredProperty("user.credits");

		return new PricingEndpoint(client, pricingEndpointUrl, checkCreditsPath);
	}

	@Bean
	public NotificationEndPoint notificationConfiguration() {
		Client client = ClientBuilder.newClient();
		String notificationEndPoint = environment.getRequiredProperty("notification.endpoint");
		String smsEndPointPath = environment.getRequiredProperty("sms.endpoint.path");
		String emailEndPointPath = environment.getRequiredProperty("email.endpoint.path");
		String scheduleJobPath = environment.getRequiredProperty("schedule.job.path");
		String unscheduleJobPath = environment.getRequiredProperty("unschedule.job.path");

		return new NotificationEndPoint(client, notificationEndPoint, smsEndPointPath, emailEndPointPath,
				scheduleJobPath, unscheduleJobPath);
	}

}
