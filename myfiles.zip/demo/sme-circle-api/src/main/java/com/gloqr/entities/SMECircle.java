package com.gloqr.entities;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.gloqr.audit.Auditable;
import com.gloqr.constants.CircleModuleConstants.CirclePrivacy;
import com.gloqr.mongo.event.CascadeSave;

@Document(collection = "sme_circle")
public class SMECircle extends Auditable {

	@Id
	@Field(value = "sme_id")
	private String smeId;

	@Field(value = "user_id")
	private String userId;

	@Field(value = "privacy")
	private String circlePrivacy = CirclePrivacy.PUBLIC;

	@DBRef(lazy = true)
	@CascadeSave
	private List<SendRequest> sendRequests;

	@DBRef(lazy = true)
	@CascadeSave
	private List<ReceiveRequest> receiveRequests;

	@DBRef(lazy = true)
	@CascadeSave
	private List<SMEConnection> myConnections;

	public SMECircle() {
		super();
	}

	public SMECircle(String smeId, String uuid) {
		super();
		this.smeId = smeId;
		this.userId = uuid;
	}

	public SMECircle(String smeId, List<ReceiveRequest> receiveRequests) {
		super();
		this.smeId = smeId;
		this.receiveRequests = receiveRequests;
	}

	public String getSmeId() {
		return smeId;
	}

	public void setSmeId(String smeId) {
		this.smeId = smeId;
	}

	public List<SendRequest> getSendRequests() {
		return sendRequests;
	}

	public void setSendRequests(List<SendRequest> sendRequests) {
		this.sendRequests = sendRequests;
	}

	public List<ReceiveRequest> getReceiveRequests() {
		return receiveRequests;
	}

	public void setReceiveRequests(List<ReceiveRequest> receiveRequests) {
		this.receiveRequests = receiveRequests;
	}

	public List<SMEConnection> getMyConnections() {
		return myConnections;
	}

	public void setMyConnections(List<SMEConnection> myConnections) {
		this.myConnections = myConnections;
	}

	public String getCirclePrivacy() {
		return circlePrivacy;
	}

	public void setCirclePrivacy(String circlePrivacy) {
		this.circlePrivacy = circlePrivacy;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
