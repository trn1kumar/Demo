package com.gloqr.constants;

public enum CircleStatus {
	SENT_REQ, RECIEVED_REQ, CONNECTED, NEW, OWNER
}
