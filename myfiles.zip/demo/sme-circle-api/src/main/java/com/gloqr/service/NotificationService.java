package com.gloqr.service;

import java.util.List;

import com.gloqr.dto.SMEDto;
import com.gloqr.entities.SMEConnection;

public interface NotificationService {

	void scheduleReqReceivedNotification(SMEDto reqSenderSmeDeatils, List<SMEConnection> senderSmesConnections,
			SMEDto reqReceiverSmeDeatils, List<SMEConnection> myConnections);

	void unscheduleJob(String jobName);

	void scheduleReqAcceptedNotification(String reqSentUuid, String reqAcceptedSmeId,List<SMEConnection> reqAcceptedSmesConns,String reqSenderSmeId,List<SMEConnection> reqSenderSmesConns);

}
