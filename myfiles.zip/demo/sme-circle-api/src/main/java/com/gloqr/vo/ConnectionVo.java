package com.gloqr.vo;

public class ConnectionVo {

	private String sUuid;

	private String receiveReqUuid;

	private String sendReqUuid;

	private String connectionUuid;

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public String getReceiveReqUuid() {
		return receiveReqUuid;
	}

	public void setReceiveReqUuid(String receiveReqUuid) {
		this.receiveReqUuid = receiveReqUuid;
	}

	public String getSendReqUuid() {
		return sendReqUuid;
	}

	public void setSendReqUuid(String sendReqUuid) {
		this.sendReqUuid = sendReqUuid;
	}

	public String getConnectionUuid() {
		return connectionUuid;
	}

	public void setConnectionUuid(String connectionUuid) {
		this.connectionUuid = connectionUuid;
	}

	
}
