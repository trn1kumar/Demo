package com.gloqr.exception;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.gloqr.util.ValidationUtil;

@ControllerAdvice
public class ExceptionHandlingController {

	Logger log = LogManager.getLogger(ExceptionHandlingController.class.getName());

	@ExceptionHandler(CustomException.class)
	public ResponseEntity<ExceptionResponse> throwCustomException(CustomException ex) {
		ExceptionResponse response = new ExceptionResponse();
		response.setErrorCode(ex.getHttpStatus().toString());
		response.setErrorMessage(ex.getMessage());
		return new ResponseEntity<>(response, ex.getHttpStatus());
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ExceptionResponse> invalidInput(MethodArgumentNotValidException ex) {
		BindingResult result = ex.getBindingResult();
		ValidationErrors response = new ValidationErrors();
		response.setErrorCode(HttpStatus.BAD_REQUEST.toString());
		response.setErrorMessage("Invalid inputs.");
		response.setErrors(ValidationUtil.fromBindingErrors(result));

		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
	}

	

	@ExceptionHandler(NullPointerException.class)
	public ResponseEntity<ExceptionResponse> nullPointerException(NullPointerException exception) {

		ExceptionResponse response = new ExceptionResponse();
		response.setErrorCode("500");
		response.setErrorMessage(exception.getMessage());
		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
	}
}
