package com.gloqr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.PropertySource;

import com.gloqr.property.FileStorageProperties;

@SpringBootApplication
@EnableConfigurationProperties({
		FileStorageProperties.class
})
@PropertySource(value = { "file:${location}/content-server.properties" })
public class ContentServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContentServerApplication.class, args);
	}
}
