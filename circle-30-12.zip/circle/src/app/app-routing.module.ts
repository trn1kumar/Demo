import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService } from './core/guards/auth-guard.service';
import { NotFoundComponent } from './modules/shared/components/not-found/not-found.component';
import { HomeGuardService } from './core/guards/home-guard.service';


const routes: Routes = [
  { path : '' , loadChildren:'./modules/home/home.module#HomeModule',canActivate:[HomeGuardService]},
  { path : 'vacancies',loadChildren:'./modules/vacancy/vacancy.module#VacancyModule',canActivate:[HomeGuardService]},
  { path : 'services', loadChildren: './modules/sme-service/sme-service.module#SmeServiceModule',canActivate:[HomeGuardService]},
  { path : 'cart' , loadChildren:'./modules/cart/cart.module#CartModule',canActivate:[AuthGuardService]},
  { path : 'circle' , loadChildren:'./modules/circle/circle.module#CircleModule',canActivate:[AuthGuardService]},
  { path : 'account' , loadChildren:'./modules/user/user.module#UserModule',canActivate:[AuthGuardService]},
  { path : 'sme' , loadChildren:'./modules/sme/sme.module#SmeModule',canActivate:[HomeGuardService]},
  { path : 'smes', loadChildren:'./modules/sme-filter/sme-filter.module#SmeFilterModule',canActivate:[HomeGuardService]},
  { path : 'social',loadChildren:'./modules/business-post/business-post.module#BusinessPostModule',canActivate:[HomeGuardService]},
  { path : 'pages', loadChildren:'./pages/pages.module#PagesModule'},
  { path : 'search' , loadChildren:'./modules/master-search/master-search.module#MasterSearchModule'},
  { path : '' , loadChildren:'./modules/product/product.module#ProductModule',canActivate:[HomeGuardService]},
  { path : '**' , component:NotFoundComponent}
]; 
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
