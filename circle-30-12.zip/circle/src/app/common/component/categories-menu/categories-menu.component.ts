import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { HomePageService } from 'src/app/core/services/home-page/home-page.service';
import { VacancyFilter, FilterByJobRole, FilterByLocation, FilterByExperience, FilterBySalary, FilterBySme } from 'src/app/core/models/jobPost';
import { SMECategoryDto } from 'src/app/core/models/sme-information';
import { CategoriesMenuService } from './categories-menu.service';
import { SMEFilterDto, CategoryFilter, FilterByCity } from 'src/app/core/models/sme-filter-response';

@Component({
  selector: 'app-categories-menu',
  templateUrl: './categories-menu.component.html',
  styleUrls: ['./categories-menu.component.css']
})
export class CategoriesMenuComponent implements OnInit {

    homepageSMEFilterCategories$:SMEFilterDto
    homePageVacancyCategories$:VacancyFilter
    homepageCategory$:Array<any>
    homePageServiceCategories$:Array<any>

    smeCategoryMenu:Map<string,Array<CategoryFilter>>;
    smeCityMenu:Map<string,Array<FilterByCity>>;

    vacancyJobRoleMenu:Map<string,Array<FilterByJobRole>>;
    vacancyLocationMenu:Map<string,Array<FilterByLocation>>;
    vacancyExperienceMenu:Map<string,Array<FilterByLocation>>;
    vacancySalaryMenu:Map<string,Array<FilterBySalary>>;
    vacancySMEMenu:Map<string,Array<FilterBySme>>;

    


      private serviceURL : string = 'services/c/'
      private smeURL : string = 'sme/'
  
  constructor(private categoriesMenuServices : CategoriesMenuService,private  router:Router) { }

  ngOnInit() {
     this.categoriesMenuServices.smeCategoriesDto().subscribe(
       res=>
       {
         this.homepageSMEFilterCategories$=res;
         this.smeCategoryMenu=new Map<string,Array<CategoryFilter>>();
         this.smeCategoryMenu.set('Category',res.filters['Category']);

         this.smeCityMenu=new Map<string,Array<FilterByCity>>();
         this.smeCityMenu.set('City',res.filters['City']);
       }
     )  
     
      this.categoriesMenuServices.vacancyCategories().subscribe(
      res=>
      {
        this.homePageVacancyCategories$ =res
        this.vacancyJobRoleMenu=new Map<string,Array<FilterByJobRole>>();
        this.vacancyJobRoleMenu.set('Job Role',res.filters['Job_Role']);

        this.vacancyLocationMenu=new Map<string,Array<FilterByLocation>>();
        this.vacancyLocationMenu.set('Location',res.filters['Location']);

        this.vacancyExperienceMenu=new Map<string,Array<FilterByLocation>>();
        this.vacancyExperienceMenu.set('Experience',res.filters['Experience']);

        this.vacancySalaryMenu=new Map<string,Array<FilterBySalary>>();
        this.vacancySalaryMenu.set('Salary',res.filters['Salary']);

        this.vacancySMEMenu=new Map<string,Array<FilterBySme>>();
        this.vacancySMEMenu.set('SME',res.filters['SME']);
       

      })
     this.categoriesMenuServices.categories().subscribe(
       res=> {
         this.homepageCategory$=res
       }
     )
     this.categoriesMenuServices.serviceCategories().subscribe(
      res=> {
        this.homePageServiceCategories$=res
      }
    )
  }
    

  smeNameClick(sUuid){
    let url =  'sme/' + sUuid
    window.open(url,'_blank')
  }

  productClick(name){
    this.router.navigateByUrl(name)
  }

  serviceClick(name){
    this.router.navigateByUrl(this.serviceURL+name)
  }


}
