import { Component, Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { Product } from "src/app/core/models/product";
import { SMECircleDto } from "src/app/core/models/business-circle";
import { VacancyFilter } from "src/app/core/models/jobPost";
import { SMECategoryDto } from "src/app/core/models/sme-information";
import { RestURL } from "src/app/core/models/rest-api-url";
import { shareReplay } from "rxjs/operators";
import { HttpClient } from "@angular/common/http";
import { SMEFilterDto } from "src/app/core/models/sme-filter-response";
const CACHE_SIZE = 1;

@Injectable({
  providedIn: 'root'
})
export class CategoriesMenuService {


  constructor(private http: HttpClient) { }

  private homePageProduct$: Observable<Array<Product>>
  private homePageSMEs$: Observable<Array<SMECircleDto>>
  private categories$: Observable<any>
  private serviceCategories$: Observable<any>
  private vacacncyCategories$: Observable<VacancyFilter>
  private smeFilter$: Observable<SMEFilterDto>

  public smeCategoriesDto(): Observable<SMEFilterDto> {
    if (!this.smeFilter$) {
      this.smeFilter$ = this.http.get<SMEFilterDto>(RestURL.smeInformartionURL + "filter").pipe(
        shareReplay(CACHE_SIZE)
      )
    }
    return this.smeFilter$
  }

  public categories(): Observable<any> {
    if (!this.categories$) {
      this.categories$ = this.http.get(RestURL.categoryURL + '/' + 'categories-and-sub').pipe(
        shareReplay(CACHE_SIZE)
      )
    }
    return this.categories$
  }

  public serviceCategories(): Observable<any> {
    if (!this.serviceCategories$) {
      this.serviceCategories$ = this.http.get(RestURL.serviceURL + 'categories').pipe(
        shareReplay(CACHE_SIZE)
      )
    }
    return this.serviceCategories$
  }

  public vacancyCategories(): Observable<VacancyFilter> {
    if (!this.vacacncyCategories$) {
      this.vacacncyCategories$ = this.http.get<VacancyFilter>(RestURL.jobPostUrl + 'filter').pipe(
        shareReplay(CACHE_SIZE)
      )
    }
    return this.vacacncyCategories$
  }
}
