import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import * as fromRoot from '../../../../../app.reducers'
import { User, UserUpdate } from 'src/app/core/models/user';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { TokenStorageService } from 'src/app/core/services/token/token-storage.service';
import { MatDailogService } from 'src/app/core/services/extra/matdialog.config';
import { BusinessCartService } from 'src/app/core/services/cart/business-cart.service';
import { UserService } from 'src/app/core/services/user/user.service';
import { getTotalCartCount } from 'src/app/modules/home/reducers/home.selector';
import { RestURL } from 'src/app/core/models/rest-api-url';
import { MatDialogConfig } from '@angular/material';
import { SearchService } from 'src/app/core/services/search/search.service';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
 
  uuid:string
  user$ : Observable<User>
  totalCartCount : number
  searchCatagory:any;
  searchedResult:any
  dropdownMenu:boolean=true
  smeMasterSearchResult:any
  productMasterSearchResult:any
  serviceMasterSearchResult:any
  defaultSearchDropDown:boolean=false
  profileImage:string
  smefaceImage:boolean=true
  searchCatagoryArr = ["All","Products", "Services", "SME"];
  searchText = new FormControl();
  selected = this.searchCatagoryArr[0];
  constructor(public jwtToken : JwtTokenService, public token : TokenStorageService ,
    private matDialogService : MatDailogService ,private dialogService: MatDailogService, private router : Router,
    private cartService : BusinessCartService,private userService:UserService,private searchService:SearchService,
    private store: Store<fromRoot.AppState>) { }

  ngOnInit() {
    this.profileImage=this.jwtToken.getProfileImage();
  
    if(this.token.isLoggedIn()){
      this.uuid = this.jwtToken.getUserId();
      this.user$ = this.userService.getUserProfile(this.uuid)
    }
    this.cartService.cartCount(this.jwtToken.getUserId())
    this.store.select(getTotalCartCount).subscribe(
      res => {
        this.totalCartCount = res
        }
      )
      this.searchText.valueChanges.subscribe(
        value => {
          if(value === ""||value.length<2){
            this.defaultSearchDropDown=false
          }else{
               this.getSearchBarResult(value,this.selected)
          }
        
        }
      )
     
  }

  checkImage(imageUrl:string)
  {
    
    if(imageUrl != null && imageUrl.startsWith("https://")){
      this.smefaceImage=false 
    }
  
    return this.smefaceImage
  }

  getSearchBarResult(searchText:string,searchModule:string)
  {
    this.searchService.searchSuggest(searchText,searchModule).subscribe(
      res=>{
      this.productMasterSearchResult=res.searchedResult["products"];
      this.serviceMasterSearchResult=res.searchedResult["services"];
      this.smeMasterSearchResult=res.searchedResult["sme"];
      if(this.productMasterSearchResult!=undefined&&this.productMasterSearchResult.length>0||this.serviceMasterSearchResult!=undefined&&this.serviceMasterSearchResult.length>0||this.smeMasterSearchResult!=undefined&&this.smeMasterSearchResult.length>0){
        this.defaultSearchDropDown=true
      }else{
        this.defaultSearchDropDown=false
      }
     
      
    },err=>{

    })
  }

  selectCatagory(val){
    this.selected = val;
    this.defaultSearchDropDown=false
    this.dropdownMenu=false
  }
  
  onClickSuggestion(){
    this.defaultSearchDropDown=false
  }

  openLoginDialog(){
    this.matDialogService.openLoginDialog()
  }
  
  logout(){
    window.location.reload()
    this.token.logout()
    this.router.navigate([''])
  }

  editProfile(){
    this.router.navigate([''])
  }
  
  getImage(imageName) {
    if(imageName !=null)
    {
      return RestURL.contentServerUrl + (imageName);
    }else
    return "/assets/logo/noimage.png"
  }

  onListSmeface()
  {
    if (!this.token.isLoggedIn()) {
      const dialogRef = this.dialogService.openLoginDialog()
      dialogRef.afterClosed().subscribe(
        res => {
          if (this.token.isLoggedIn()) {
            this.router.navigateByUrl('/sme/list-sme')
          }
        }
      )
    }

}

scrolltoTop(){
  window.scrollTo(0,0)
}
}
