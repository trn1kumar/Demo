import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SmeFooterComponent } from './sme-footer.component';

describe('SmeFooterComponent', () => {
  let component: SmeFooterComponent;
  let fixture: ComponentFixture<SmeFooterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SmeFooterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SmeFooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
