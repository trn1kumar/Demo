import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { SMEInformation } from 'src/app/core/models/sme-information';
import { RestURL } from 'src/app/core/models/rest-api-url';

@Component({
  selector: 'app-sme-header',
  templateUrl: './sme-header.component.html',
  styleUrls: ['./sme-header.component.css']
})
export class SmeHeaderComponent implements OnInit {

  @Input()
  smeInfo : SMEInformation

  constructor(private router : Router) { }

  ngOnInit() {

  }

  scrolltoTop(){
    window.scrollTo(0,0)
  }
  
  getImage(imageName){
    if(imageName != null){
      return RestURL.contentServerUrl+(imageName);
    }else
    return "/assets/not-found/not-available.jpeg"
  }
}
