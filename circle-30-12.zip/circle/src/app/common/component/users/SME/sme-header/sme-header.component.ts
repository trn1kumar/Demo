import { Component, OnInit, Input } from '@angular/core';
import { MatDialog } from '@angular/material';
import { SMEInformation } from 'src/app/core/models/sme-information';
import { UserUpdate } from 'src/app/core/models/user';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { UserService } from 'src/app/core/services/user/user.service';
import { TokenStorageService } from 'src/app/core/services/token/token-storage.service';
import { RestURL } from 'src/app/core/models/rest-api-url';
import { OtpverifyAdminDialog } from 'src/app/core/services/extra/otp-verify-admin.config';


@Component({
  selector: 'app-sme-header',
  templateUrl: './sme-header.component.html',
  styleUrls: ['./sme-header.component.css']
})
export class SmeHeaderComponent implements OnInit {

  @Input()
  smeInfo : SMEInformation

  @Input()
  totalCartCount: number
  userUpdate:UserUpdate
  profileImage:string
  constructor(public jwtToken : JwtTokenService,public otpDialog:OtpverifyAdminDialog,public userService:UserService, public token : TokenStorageService,private matDialog : MatDialog) { }

  ngOnInit() {
    this.profileImage=this.jwtToken.getProfileImage();

    if(this.smeInfo){
      localStorage.setItem('smeName' ,this.smeInfo.smeName)
    }
  }
  scrolltoTop(){
    window.scrollTo(0,0)
  }

  getImage(imageName) {
    if(imageName !=null)
    {
      return RestURL.contentServerUrl + (imageName);
    }else
    return "/assets/logo/noimage.png"
  }

  onAdminClick1()
  {
    let uuid=this.jwtToken.getUserId();
      let userUuid=new UserUpdate();
      userUuid.uuid=uuid
     
      this.userService.sendOtp(userUuid).subscribe(
     res=>
     {
        sessionStorage.clear();
        this.userUpdate=res.body
        const dialogRef = this.otpDialog.openOtpVerifyDialog(this.userUpdate)
     }
   )
  }


  // onAdminClick()
  // {
  //   let uuid=this.jwtToken.getUserId();

  //   let userUuid=new UserUpdate();
  //   userUuid.uuid=uuid
    
   
  //  this.userService.sendOtp(userUuid).subscribe(
  //    res=>
  //    {
  //      sessionStorage.clear();
  //     //  sessionStorage.setItem('uuid',btoa(uuid))
  //       this.userUpdate=res.body
  //       console.log('userUpdate',this.userUpdate)
  //       console.log('otp',res)
  //       this.openOtpDialog(this.userUpdate)
  //    }
  //  )
     
  // }
  // openOtpDialog(userUpdate:UserUpdate){
  //   const dialogConfig = new MatDialogConfig();
  //   dialogConfig.autoFocus = false
  //   dialogConfig.width = '400px'
  //   dialogConfig.data=userUpdate
  //   this.otpDialogRef = this.matDialog.open(OtpVerifyAdminPage ,dialogConfig)
  // }

  logout(){
    window.location.reload()
    this.token.logout()
  }
}
