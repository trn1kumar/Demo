import { Component, OnInit, Input } from '@angular/core';

import { MatDialog, MatDialogRef, MatDialogConfig } from '@angular/material';
import { SMEInformation } from 'src/app/core/models/sme-information';
import { RestURL } from 'src/app/core/models/rest-api-url';


@Component({
  selector: 'app-sme-footer',
  templateUrl: './sme-footer.component.html',
  styleUrls: ['./sme-footer.component.css']
})
export class SmeFooterComponent implements OnInit {
  
  @Input()
  smeInfo : SMEInformation
  constructor(private dialog:MatDialog) { }

  ngOnInit() {
  }

  getImage(imageName){
    if(imageName != null){
      return RestURL.contentServerUrl+(imageName);
    }else
    return "/assets/not-found/not-available.jpeg"
  }
  onMapClick(googlemapLink)
  {
    let url =  googlemapLink
   
    window.open(url, '_blank')
  }

}