import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { shareReplay } from 'rxjs/operators';
import { RestURL } from '../../models/rest-api-url';
import { PricingConstants } from '../../models/pricing';

const CACHE_SIZE = 1;

@Injectable({
  providedIn: 'root'
})
export class PricingService {

  private url: string = RestURL.pricingURL
  private BI_READ$:Observable<any>
  private pricingDetails$: Observable<any>
  constructor(private http: HttpClient) { }

  public getPricingDetails(): Observable<any> {
    if (!this.pricingDetails$) {
      this.pricingDetails$ = this.http.get(this.url).pipe(
        shareReplay(1)
      )
    }
    return this.pricingDetails$
  }

  public getUserPricingDetails(): Observable<any> {
    return this.http.get(this.url + 'pricing-details')
  }

  public getUserPricingDetailsWithInitial(): Observable<any> {
    return this.http.get(this.url + 'pricing-details',{params:{getData:'initial'}})
  }

  public checkCredits(type: string): Observable<any> {
    return this.http.get(this.url + 'check',{params:{type:type}})
  }

  public upgradePlan(requestData): Observable<any> {
    return this.http.put(this.url + 'upgrade-plan',requestData)
  }

  public updateCredits(requestData): Observable<any>{
    return this.http.put(this.url + 'update-credits',requestData,{observe : 'response'})
  }
}
