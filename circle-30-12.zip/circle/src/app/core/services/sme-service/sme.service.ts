import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { RestURL } from '../../models/rest-api-url';
import { shareReplay } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class SmeService {

  private url = RestURL.serviceURL
  private categories$: Observable<Array<any>>;
  private services$: Observable<Array<any>>

  constructor(private http: HttpClient) { }

  public categoryNames() {
    if (!this.categories$) {
      this.categories$ = this.http.get<Array<any>>(this.url + 'categories-names').pipe(
        shareReplay(1)
      )
    }
    return this.categories$;
  }

  public services(): Observable<any> {
    if (!this.services$) {
      this.services$ = this.http.get<Array<any>>(this.url)
    }
    return this.services$
  }
  public servicesForUser(userUUID): Observable<any> {
    if (!this.services$) {
      this.services$ = this.http.get<Array<any>>(this.url,{params:{u:userUUID}})
    }
    return this.services$
  }

  public categoryByUuid(categoryUuid: string): Observable<Array<any>> {
    return this.http.get<Array<any>>(this.url  + categoryUuid + '/category')
  }

  public saveService(formData): Observable<any> {
    return this.http.post(this.url + 'service', formData)
  }

  public serviceByUuid(serviceUUID: string): Observable<any> {
    return this.http.get(this.url + serviceUUID + '/service')
  }

  public serviceByUuidTypeUSER(serviceUUID: string,userUUID: string): Observable<any> {
    return this.http.get(this.url + serviceUUID + '/service',{params:{u:userUUID}})
  }

  public categoryByName(url: string):Observable<any>{
    return this.http.get(RestURL.serviceCategoryURL + url)
  }

  public allCategories():Observable<any> {
    return this.http.get(this.url + 'categories')
  }

  public serviceBySuuid(sUuid: string,status:string):Observable<any>{
    if(status == null)
    {
      return this.http.get(this.url + sUuid + '/sme-services')
    }
    return this.http.get(this.url + sUuid + '/sme-services',{params:{status:status}})
  }

  public serviceBySuuidWithStatus(sUuid: string,userUUID:string,status:string):Observable<any>{
    return this.http.get(this.url + sUuid + '/sme-services',{params:{u:userUUID,status:status}})
  }

  public removeService(data:any){
    return this.http.delete(this.url + data.serviceUUID + '/' + data.sUuid,{})
  }

  public getSmeService(serviceUUID:string,sUuid:string):Observable<any>{
    return this.http.get(this.url + serviceUUID + '/' + sUuid + '/check');
  }

  public updateService(data:any){
    return this.http.put(this.url + data.serviceUUID + '/update' , data)
  }

  public getSubCategorySpecifications(masterSubCategoryUUID:string): Observable<any> {
    return this.http.get(this.url + masterSubCategoryUUID + '/specifications')
  }

  public getPricePerNames(){
    return this.http.get<Array<string>>(this.url + 'price-per-names')
  }
}
