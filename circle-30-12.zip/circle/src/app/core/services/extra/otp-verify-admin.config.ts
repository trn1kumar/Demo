import { Injectable } from "@angular/core";
import { MatDialogRef, MatDialogConfig, MatDialog } from "@angular/material";
import { OtpVerificationAdminComponent } from "src/app/modules/shared/components/otp-verification-admin/otp-verification-admin.component";
import { UserUpdate } from "../../models/user";

@Injectable()
export class OtpverifyAdminDialog {

    otpVerifyDialogRef : MatDialogRef<OtpVerificationAdminComponent>;

    private dialogConfig = new MatDialogConfig();

    constructor(private matDialog : MatDialog){
        this.dialogConfig.autoFocus = false
        this.dialogConfig.width = '400px'
        this.dialogConfig.disableClose=true
    }

    openOtpVerifyDialog(userUpdate:UserUpdate) {
        
        this.otpVerifyDialogRef = this.matDialog.open(OtpVerificationAdminComponent , this.dialogConfig)
      
        return this.otpVerifyDialogRef
    }
    
}
