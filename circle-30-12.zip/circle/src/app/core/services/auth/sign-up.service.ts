import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { RestURL } from '../../models/rest-api-url';

@Injectable({
  providedIn: 'root'
})
export class SignUpService {

  private url = RestURL.authURL
  private headers = new HttpHeaders ({
    'Content-Type' : 'application/json',
  })
  constructor(private http : HttpClient) { }

  public generateOTP(userData) : Observable<any>{
    return this.http.post(this.url + 'signup' , userData , { observe : 'response' })
  }

  public verifyOTP(enteredOTP,verify:string) : Observable<any> {
    if(verify!=null){
      return this.http.post(this.url + 'verify-otp' , enteredOTP ,{ params:{param:verify},observe : 'response' , headers : this.headers})
    }
    return this.http.post(this.url + 'verify-otp/' , enteredOTP ,{ observe : 'response' , headers : this.headers})
  }

  public resendOTP(uuid : string) : Observable<any> {
    return this.http.post(this.url + 'resend-otp' , JSON.stringify({ uuid : uuid }), 
    { observe : 'response' , headers : this.headers })
  }

  public userType(uuid : string) : Observable<any> {
    return this.http.put(this.url + 'usertype' , JSON.stringify({ uuid : uuid }), 
    { observe : 'response' , headers : this.headers })
  }
  
}
