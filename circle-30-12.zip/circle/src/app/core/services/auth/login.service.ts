import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { RestURL } from '../../models/rest-api-url';
import { shareReplay } from 'rxjs/operators';

const CACHE_SIZE = 1;

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private userDetail$: Observable<any>

  private url = RestURL.authURL
  private headers = new HttpHeaders ({
    'Content-Type' : 'application/json',
  })
  
  constructor(private http : HttpClient) { }

  login(loginCredentials) : Observable<any> {
    return this.http.post(this.url + 'login' , loginCredentials , { observe : 'response'})
  }

  loginWithOTP(username) : Observable<any> {
    return this.http.post(this.url + 'otp-login' , JSON.stringify( { username : username } ) , 
            { headers : this.headers })
  }

  forgotPassword(username) : Observable<any> {
    return this.http.post(this.url + 'forgot-password' , username , { headers : this.headers })
  }

  resendOTP(uuid) : Observable<any> {
    return this.http.post(this.url + 'resend-otp' , uuid ,{ headers : this.headers })
  }

  resetPassword(newPassword,token) : Observable<any> {
    return this.http.post(this.url +'reset-password' , newPassword , { headers : this.headers.set('Authorization','Bearer '+token) })
  }

  googleSocialLogin(data):Observable<any>
  {
    return this.http.post(this.url+'login/google',data)
  }

  facebookSocialLogin(fbdata):Observable<any>
  {
    return this.http.post(this.url+'login/facebook',fbdata)
  }

  // public getUserVo(uuid:string):Observable<any>
  // {
  //   return this.http.get(this.url+uuid+'/basic-info')
  // }

    public getUserVo(uuid:string):Observable<any>
    {
        if(!this.userDetail$){
          this.userDetail$=this.http.get(this.url+uuid+'/basic-info').pipe(
            shareReplay(CACHE_SIZE)
          )
        }
        return this.userDetail$;
    }

}
