import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { RestURL } from '../../models/rest-api-url';

@Injectable({
  providedIn: 'root'
})
export class SearchService {

  

  private headers = new HttpHeaders ({
    'Content-Type' : 'application/json',
  })

  constructor(private http : HttpClient) { }

  public searchSuggest(searchText:string,searchModule:string) : Observable<any> {
    return this.http.get(RestURL.adminURL+'search/auto-suggest',{params:{
      searchText:searchText,
      searchModule:searchModule
    }})
  }


  public getProductSearchResult(url:string): Observable<any>{
    return this.http.get(RestURL.productSearchURL+url)
  }

  public getProductSearchResultForUSER(url:string,userUUID): Observable<any>{
    return this.http.get(RestURL.productSearchURL+url,{params:{u:userUUID}})
  }
  
  public getServiceSearchResult(url:string){
    return this.http.get(RestURL.serviceCategoryURL+"/services"+url)
  }
  public getServiceSearchResultForUSER(url:string,userUUID){
    return this.http.get(RestURL.serviceCategoryURL+"/services"+url,{params:{u:userUUID}})
  }

}
