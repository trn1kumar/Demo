import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RestURL } from '../../models/rest-api-url';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BusinessCircleService {

  private url = RestURL.circleURL

  constructor(private http: HttpClient) { }  
  /* Circle Post API Start*/
  public makeConnection(makeCon): Observable<any> {
    return this.http.post(this.url + 'add-connection', makeCon)
  }

  public deniedConnection(delCon): Observable<any> {
    return this.http.post(this.url + 'reject-received-request', delCon)
  }

  public removeConnection(removeCon): Observable<any> {
    return this.http.post(this.url + 'remove-connection', removeCon)
  }

  public addBusinessRequest(circle): Observable<any> {
    return this.http.post(this.url + 'send-request', circle)
  }

  public cancelRequest(cancelReq): Observable<any> {
    return this.http.post(this.url + 'cancel-sent-request', cancelReq)
  }

  /* Circle Post API End*/

  /* Circle GET API START*/

  public getAllReceviedRequest(sUuid): Observable<any> {
    return this.http.get(this.url + sUuid + '/received-requests')
  }

  public getMyCircleConnection(sUuid): Observable<any> {
    return this.http.get(this.url + sUuid + '/my-connections')
  }

  public getPeopleYouMayKnow(sUuid): Observable<any> {
    return this.http.get(this.url + sUuid + '/people-you-may-know')
  }

  public getAllSentRequest(sUuid): Observable<any> {
    return this.http.get(this.url + sUuid + '/sent-requests')
  }

  public getBusinessCircle(sUuid): Observable<any> {
    return this.http.get(this.url + sUuid)
  }

  public getPendingRequestCount(sUuid): Observable<any> {
    return this.http.get(this.url + sUuid + '/received-requests/count')
  }

  /* Circle GET API End*/
  public smeLoginCircle(sUuid : string):Observable<any>{
    return this.http.get(this.url+sUuid+ '/smes')
  }
}
