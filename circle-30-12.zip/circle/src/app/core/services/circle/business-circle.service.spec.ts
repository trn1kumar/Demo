import { TestBed, inject } from '@angular/core/testing';

import { BusinessCircleService } from './business-circle.service';

describe('BusinessCircleService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BusinessCircleService]
    });
  });

  it('should be created', inject([BusinessCircleService], (service: BusinessCircleService) => {
    expect(service).toBeTruthy();
  }));
});
