import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { RestURL } from '../../models/rest-api-url';
import { SMEInfrastructure } from '../../models/sme-infrastructure';
import { strictEqual } from 'assert';
import { SMEInformation } from '../../models/sme-information';
import { SearchRequest } from '../../models/search';
import { SMEImageParameter } from '../../models/sme-image-parameter';

@Injectable({
  providedIn: 'root'
})
export class SmeInfoService {

  private url = RestURL.smeInformartionURL
  private url2=RestURL.adminURL
   
  constructor(private http : HttpClient) { }

  public smes(url): Observable<any>{
    return this.http.get(RestURL.smeCategoryURL+url)
  }

  public smesWithPagination(filterByCategories,filterByCities,page,firstResult):Observable<any>{
    return this.http.get(RestURL.smeInformartionURL+'fetch',{
      params: {
        categoriesFilterParam:filterByCategories,
        citiesFilterParam:filterByCities,
        page: page,
        firstResult:firstResult
      }
    })
    
  }

  public smeUuid(uuid) : Observable<any> {
    return this.http.get(this.url + 'user/' + uuid)
  }

  public categories() : Observable<any> {
    return this.http.get(RestURL.categoryURL+'/')
  }

  public smeCategories() : Observable<any>{
    return this.http.get(RestURL.smeInformartionURL+'categories')
  }

  public subCategories(categoryName : string) : Observable<any> {
    return this.http.get(RestURL.categoryURL+'/' + categoryName  + '/sub-categories')
  }

  public addCertificates(uploadCertificate,id):Observable<any>
  {
    return this.http.post(this.url+id+'/sme/certificates', uploadCertificate)
  }

  public updateCertificates(formData,id):Observable<any>
  {
    return this.http.post(this.url+id+'/sme/certificates',formData)
  }
  
  public getCertificate(crtiUuid):Observable<any>
  {
    return this.http.get(this.url+' '+'/sme/certificates/'+crtiUuid)
  }

  public deleteCertificate(crtiUuid):Observable<any>
  {
    return this.http.delete(this.url+' '+'/sme/certificate/'+crtiUuid)
  }

  public addInfrastrctures(formData,id): Observable<any>
  {
    return this.http.post(this.url+id+'/sme/infrastructures', formData)
  }

  public getInfrastructure(infraUuid):Observable<any>
  {
    return this.http.get(this.url+' '+'/sme/infrastructures/'+infraUuid)
  }

  public updateInfrastructure(formData,id): Observable<any>
  {
    return this.http.post(this.url+id+'/sme/infrastructures', formData)
  }

  public deleteInfrastructure(infraUuid):Observable<any>
  {
    return this.http.delete(this.url+' '+'/sme/infrastructure/' +infraUuid)
  }

  public addTeam(formData,id):Observable<any>
  {
    return this.http.post(this.url+id+'/sme/teams', formData)
  }

  public updateTeam(formData,id):Observable<any>
  {
    return this.http.post(this.url+id+'/sme/teams', formData)
  }

  public getTeam(teamUuid):Observable<any>
  {
    return this.http.get(this.url+' '+'/sme/teams/'+teamUuid)
  }

  public deleteTeam(teamUuid):Observable<any>
  {
    return this.http.delete(this.url+ ' ' + '/sme/team/' +teamUuid)
  }

  public deleteVacancy(vacancyUuid):Observable<any>
  {
    return this.http.delete(this.url+ ' ' + '/sme/vacancy/' +vacancyUuid)
  }
  public addGallery(formData,id):Observable<any>
  {
    return this.http.post(this.url+id+'/sme/galleries', formData)
  }

  public updateGallery(formData,id):Observable<any>
  {
    return this.http.post(this.url+id+'/sme/galleries', formData)
  }

  public getGallery(galleryUuid):Observable<any>
  {
    return this.http.get(this.url+' '+'/sme/galleries/'+galleryUuid)
  }

  public deleteGallery(galleryUuid):Observable<any>
  {
    return this.http.delete(this.url+' '+'/sme/gallery/'+galleryUuid)
  }
  
  public addCompanyInfo(formData):Observable<any>
  {
    return this.http.post(this.url+'sme', formData)
  }

  public getCitySuggestion(searchText,pincode):Observable<any>
  {
  
    return this.http.get(this.url2+'address/suggest',{
      params: {
        searchText:searchText,
        pincode:pincode,
      }
    })
  }
  public getSmeByUserId(userId):Observable<any>
  {
    return this.http.get(this.url+'/user/'+userId)
  }

  public getBasicInfo(sUuid):Observable<any>
  {
    return this.http.get(this.url+''+sUuid)
  }

  public updateBasicInfo(formData):Observable<any>
  {
    return this.http.put(this.url+'sme',formData)
  }

  
  public getLoginSmeInfo(sUuid):Observable<any>
  {
    return this.http.get(this.url+sUuid+'/vo',{observe:'response'})
  }

  public getInfraByUuid(infraUuid):Observable<SMEInfrastructure>
  {
    return this.http.get<SMEInfrastructure>(this.url +' '+'/sme'+'/infrastructures/'+infraUuid)
  }

  public gstNumberValidate(gstNumber:string):Observable<any>
  {
    return this.http.get(this.url+gstNumber+'/validate')
  }

  /*Upload Images*/ 

  smeImagesUpload(sUuid,formData,smeParameter)
  {
    return this.http.post(this.url+sUuid+'/images',formData,smeParameter)
  }
} 
