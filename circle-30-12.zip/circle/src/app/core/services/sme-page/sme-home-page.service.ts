import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { RestURL } from '../../models/rest-api-url';
import { Product } from '../../models/product';
import { SMECertificate } from '../../models/sme-certificates';
import { SMEGallery } from '../../models/sme-gallery';
import { SMEInfrastructure } from '../../models/sme-infrastructure';
import { SMEManagementTeam } from '../../models/sme-management-team';

@Injectable({
  providedIn: 'root'
})
export class SmeHomePageService {

  private url = RestURL.smeInformartionURL

  constructor(private http : HttpClient) { }

  public sUuid(sUuid : string) : Observable<any>{
    return this.http.get(this.url + sUuid)
  }

  public smeProducts(sUuid : string,status:string) : Observable<any>{
    if(status == null){
      return this.http.get<Array<Product>>(RestURL.productURL + 'smes/' + sUuid)
    }
    return this.http.get<Array<Product>>(RestURL.productURL + 'smes/' + sUuid,{params:{status:status}})
  }

  public smeCertificates(sUuid : string,status:string) : Observable<any>{
    if(status == null)
    {
      return this.http.get<Array<SMECertificate>>(this.url + sUuid + '/sme/certificates')
    }
    return this.http.get<Array<SMECertificate>>(this.url + sUuid + '/sme/certificates',{params:{status:status}})
    
  }

  public smeInfrastructure(sUuid : string,status:string) : Observable<any>{
    if(status == null)
    {
      return this.http.get<Array<SMEInfrastructure>>(this.url + sUuid + '/sme/infrastructures')
    }
    return this.http.get<Array<SMEInfrastructure>>(this.url + sUuid + '/sme/infrastructures',{params:{status:status}})
  }

  public smeManagementTeam(sUuid : string,status:string) : Observable<any>{
    if(status == null)
    {
      return this.http.get<Array<SMEManagementTeam>>(this.url + sUuid + '/sme/teams')
    }
    return this.http.get<Array<SMEManagementTeam>>(this.url + sUuid + '/sme/teams',{params:{status:status}})
  }

  public smeGallery(sUuid : string,status:string) : Observable<any>{
    if(status == null)
    {
      return this.http.get<Array<SMEGallery>>(this.url + sUuid + '/sme/galleries')

    }
    return this.http.get<Array<SMEGallery>>(this.url + sUuid + '/sme/galleries',{params:{status:status}})
  }

  public smeCircle(sUuid : string,loggedInId:string) : Observable<any>{
    return this.http.get(RestURL.circleURL + sUuid + '/my-connections/for/'+loggedInId+'/sme')
  }

  public sliderImage(sUuid:string,formData):Observable<any>
  {
    return this.http.post(RestURL.smeInformartionURL+sUuid+'/upload/slider-image',formData)
  }

  public getSliderImage(sUuid:string):Observable<any>
  {
    return this.http.get(RestURL.smeInformartionURL+sUuid+'/homepage/slider/images')
  }

  public changeSmeProfileImage(sUuid:string,uploadFormData):Observable<any>
  {
    return this.http.post(this.url+sUuid+'/change/logo-image',uploadFormData)
  }

  
}
