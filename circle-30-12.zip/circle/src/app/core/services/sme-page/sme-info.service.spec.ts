import { TestBed, inject } from '@angular/core/testing';

import { SmeInfoService } from './sme-info.service';

describe('SmeInfoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SmeInfoService]
    });
  });

  it('should be created', inject([SmeInfoService], (service: SmeInfoService) => {
    expect(service).toBeTruthy();
  }));
});
