import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { RestURL } from '../../models/rest-api-url';
import { Store } from '@ngrx/store';
import * as fromRoot from '../../../app.reducers'
import { Received_BI } from '../../models/receive-bi';
import { Sent_BI } from '../../models/sent-bi';
import { shareReplay } from 'rxjs/operators';
import { getCartState } from 'src/app/modules/home/reducers/home.selector';

const CACHE_SIZE = 1;

@Injectable({
  providedIn: 'root'
})
export class BusinessCartService {

  private url = RestURL.cartURL
  private callOnce:boolean
  private receivedCartItems$: Observable<Array<Received_BI>>
  private sentCartItems$: Observable<Array<Sent_BI>>

  constructor(private http: HttpClient, private store: Store<fromRoot.AppState>) { }

  public generateBI(businessInterest): Observable<any> {
    return this.http.post(this.url + 'business-interest', businessInterest)
  }

  public cartCount(uuid) {
    if (!this.callOnce) {
      this.http.get(this.url + uuid + '/c', { params: { count: 'count' } }).subscribe(
        res => {
          this.store.dispatch({ type: 'Store_Total_Cart_Count', payload: res })
        }
      )
      this.callOnce = true
    }
  }

  public receivedCartItems(uuid,page): Observable<any> {
    return this.http.get<Array<Received_BI>>(this.url + uuid + '/c',{params:{page:page},observe:'response'});
  }

  public sentCartItems(uuid,page): Observable<any> {
    return  this.http.get<Array<Sent_BI>>(this.url + uuid + '/c', { params: { u: 'user',page:page } });
  }

  public deleteBusinessInterest(cartItemId): Observable<any> {
    return this.http.delete(this.url + cartItemId + '/r/business-interest')
  }

  public sendQuotationSME(quotation:any): Observable<any> {
    return this.http.post(RestURL.cartURL + 'sme/accept', quotation)
  }
  
  public sendQuotationUSER(quotation:any): Observable<any> {
    return this.http.post(RestURL.cartURL + 'user/accept', quotation)
  }

  public rejectBusinessInterestSME(data): Observable<any> {
    return this.http.post(RestURL.cartURL + 'sme/reject', data)
  }

  public rejectBusinessInterestUSER(data): Observable<any> {
    return this.http.post(RestURL.cartURL + 'user/reject', data)
  }

  public acceptPurchaseOrder(data): Observable<any> {
    return this.http.post(RestURL.cartURL + 'sme/confirm', data)
  }

  public updateCartItemQuantity(updateQuantity: number): Observable<any> {
    return this.http.post(this.url + '',
      JSON.stringify({ updateQuantity: updateQuantity }),
      { observe: 'response' })
  }

  public getUserDetails(data: any): Observable<any> {
    return this.http.put(this.url + 'user-details', data)
  }

}
