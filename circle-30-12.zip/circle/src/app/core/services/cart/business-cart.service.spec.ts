import { TestBed, inject } from '@angular/core/testing';

import { BusinessCartService } from './business-cart.service';

describe('BusinessCartService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BusinessCartService]
    });
  });

  it('should be created', inject([BusinessCartService], (service: BusinessCartService) => {
    expect(service).toBeTruthy();
  }));
});
