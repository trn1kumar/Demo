import { TestBed, inject } from '@angular/core/testing';
import { PublishDataService } from './publish-data.service';


describe('PublishDataService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PublishDataService]
    });
  });

  it('should be created', inject([PublishDataService], (service: PublishDataService) => {
    expect(service).toBeTruthy();
  }));
});
