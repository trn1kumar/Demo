import { TestBed, inject } from '@angular/core/testing';

import { BusinessPostService } from './business-post.service';

describe('BusinessPostService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BusinessPostService]
    });
  });

  it('should be created', inject([BusinessPostService], (service: BusinessPostService) => {
    expect(service).toBeTruthy();
  }));
});
