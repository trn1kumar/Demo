import { TestBed, inject } from '@angular/core/testing';

import { UserTypeGuardService } from './user-type-guard.service';

describe('UserTypeGuardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UserTypeGuardService]
    });
  });

  it('should be created', inject([UserTypeGuardService], (service: UserTypeGuardService) => {
    expect(service).toBeTruthy();
  }));
});
