import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';
import { JwtTokenService } from '../services/token/jwt-token.service';
import { SnackBarConfig } from '../services/extra/snackbar.config';
import { MatSnackBar } from '@angular/material';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate {

  constructor(private jwtHelper: JwtHelperService,private snackBarConfig : SnackBarConfig,
    private jwtToken: JwtTokenService, private router: Router,private snackBar : MatSnackBar) { }

    canActivate(): boolean {
      if (!this.isAuthenticated()) {
      localStorage.clear()
      this.router.navigateByUrl('/');
      return false;
      }
      return true;
      }
      
      // Check whether the token is expired
      public isAuthenticated(): boolean {
      const token = localStorage.getItem('AuthToken')
      return !this.jwtHelper.isTokenExpired(token);
      }
}

