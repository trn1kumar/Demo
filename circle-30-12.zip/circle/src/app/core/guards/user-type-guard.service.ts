import { Injectable } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Router, CanActivate } from '@angular/router';
import { JwtTokenService } from '../services/token/jwt-token.service';

@Injectable({
  providedIn: 'root'
})
export class UserTypeGuardService implements CanActivate{

  constructor(private jwtHelper: JwtHelperService,
    private jwtToken: JwtTokenService, private router: Router) { }

  canActivate(): boolean {
    const token = localStorage.getItem('AuthToken')
    if(this.jwtHelper.isTokenExpired(token)){
      localStorage.clear()
      this.router.navigateByUrl('/');
      return false;
    }else{
      if(this.jwtToken.getUserType()){
        this.router.navigateByUrl('/');
        return false
      }
    }
    return true;
  }

}
