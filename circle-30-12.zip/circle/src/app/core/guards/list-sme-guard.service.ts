import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { JwtTokenService } from '../services/token/jwt-token.service';

@Injectable({
  providedIn: 'root'
})
export class ListSmeGuardService implements CanActivate{

  constructor(private jwtToken: JwtTokenService, private router: Router) { }

    canActivate(): boolean {
      if(this.jwtToken.getUserType())
      {
        return true
      }
      else{
        this.router.navigateByUrl('/');
        return false
      }
    }
}
