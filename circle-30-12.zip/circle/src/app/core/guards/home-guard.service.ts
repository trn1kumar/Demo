import { Injectable } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Router, CanActivate } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class HomeGuardService implements CanActivate{

  constructor(private jwtHelper: JwtHelperService , private router: Router) { }

  canActivate(): boolean {
    if(localStorage.getItem('AuthToken') != null){
      const token = localStorage.getItem('AuthToken')
      if(!this.checkTokenExpired(token)){
        return true
      }else{
        localStorage.clear()
        this.router.navigateByUrl('/');
      }
    }else{
      return true
    }
  }

  checkTokenExpired(token) : boolean{
    return this.jwtHelper.isTokenExpired(token)
  }

}
