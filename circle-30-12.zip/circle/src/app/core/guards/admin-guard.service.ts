import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { JwtTokenService } from '../services/token/jwt-token.service';
import { OtpVerificationAdminComponent } from 'src/app/modules/shared/components/otp-verification-admin/otp-verification-admin.component';
import { OtpverifyAdminDialog } from '../services/extra/otp-verify-admin.config';
import { UserService } from '../services/user/user.service';
import { UserUpdate } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class AdminGuardService implements CanActivate{

  userUpdate:UserUpdate;
  constructor(private jwtToken:JwtTokenService,public userService:UserService,private router:Router,public otpDialog:OtpverifyAdminDialog) { }

  canActivate():boolean{
    let uuid=this.jwtToken.getUserId();
    let userUuid=new UserUpdate();
    userUuid.uuid=uuid
   
    this.userService.sendOtp(userUuid).subscribe(
   res=>
   {
      sessionStorage.clear();
      this.userUpdate=res.body
   })
   
   const dialogRef = this.otpDialog.openOtpVerifyDialog(this.userUpdate)
      
   dialogRef.afterClosed().subscribe(
     response=>
     {
       if(response == true)
       {
         return true;
       }
       else{
         return false
       }
     }
 )
   
    return true;
  }
}
