import { TestBed, inject } from '@angular/core/testing';

import { ListSmeGuardService } from './list-sme-guard.service';

describe('ListSmeGuardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ListSmeGuardService]
    });
  });

  it('should be created', inject([ListSmeGuardService], (service: ListSmeGuardService) => {
    expect(service).toBeTruthy();
  }));
});
