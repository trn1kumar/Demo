import { Image } from "./image";
import { Auditable } from "./auditable";

export class SMEManagementTeam extends Auditable
{
    fullName : string
    designation : string
    experience : number
    fbLink : string
    linkedinLink : string
    teamUuid : string
    twitterLink : string
    mail:string
    active:boolean
    profileImageUrl:string;
    profileDesc:string
}