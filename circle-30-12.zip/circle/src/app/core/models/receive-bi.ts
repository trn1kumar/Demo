import { User } from "./user";
import { QuotationFile } from "src/app/modules/cart/business-cart/sme-cart/components/sme-cart-items/accept-dialog.component";

export class Received_BI {
    viewStatus : boolean
    userDetails : User
    status : string
    spinner:boolean
    recievdBusinessInterests:Array<any>
    sentCount:number
    receiveCount:number
    orderStatus:OrderStatus
}
export class OrderStatus{
    firstStage:FirstStage
    secondStage:SecondStage
    thirdStage:ThirdStage
    finalStage:FinalStage
    currentStatus:string
}

export class FirstStage{
    stepStatus:string
    messageCenter:MessageCenter
    statusName:string
}

export class SecondStage{
    stepStatus:string
    statusName:string
    quotationFile:QuotationFile
    messageCenter:MessageCenter
}

export class ThirdStage{
    stepStatus:string
    statusName:string
    quotationFile:QuotationFile
    messageCenter:MessageCenter
}

export class FinalStage{
    stepStatus:string
    statusName:string
}

export class MessageCenter{
    message:string
}