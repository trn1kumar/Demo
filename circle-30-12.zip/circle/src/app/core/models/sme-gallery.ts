import { Auditable } from "./auditable";
import { SMEImage } from "./image";

export class SMEGallery extends Auditable{
    galleryUuid:string
    description:string
    active:boolean
    galleryTitle:string
    images:Array<SMEImage>
}