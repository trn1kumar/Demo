export class SocialLoginCredentials{
    public static readonly facebookClientId:string='1148977558604556';
    public static readonly facebookClientSecret:string='0e50a9fe5bfa29502eca4c2cd08e47e6';
    public static readonly googleClientId:string='735327285764-d7tb2je02ujnvq9j75fvqvefup1nkc5d.apps.googleusercontent.com'
}


export class FacebookUser {
    facebookClientId:string;
    facebookClientSecret:string;
    provider: string;
    id: string;
    email: string;
    name: string;
    image: string;
    token?: string;
    idToken?: string;
}