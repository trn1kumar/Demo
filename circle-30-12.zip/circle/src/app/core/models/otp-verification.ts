export class OtpVerification {
    uuid: string;
    otp: string;
}