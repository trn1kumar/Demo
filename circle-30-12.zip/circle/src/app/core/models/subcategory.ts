import { Product } from "./product";

export class SubCategory{
    title: string
    url: string
    uuid : string
    products : Product
}