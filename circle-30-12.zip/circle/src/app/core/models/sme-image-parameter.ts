export class SMEImageParameter
{
    param:string
}