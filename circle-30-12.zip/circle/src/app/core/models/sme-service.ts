import { SMEInformationDto } from "./product";

export class SMEService{
    serviceUUID: string
    serviceDisplayName: string
    serviceUrlName: string
    serviceDescription: string
    location: string
    sUuid: string
    smeName: string;
    priceDetails: PriceDetails
    isActive : boolean
    serviceImages : Array<ServiceImage>
    masterSubCategory:ServiceMasterSubCategory
    specifications: Map<string,string> = new Map<string,string>()
    active:boolean
    status:boolean
    masterSubCategoryUUID:string
    businessPost:boolean
    discount:number
    smeInfo:SMEInformationDto
}
export class PriceDetails{
    price: number
    pricePer: string
}
export class ServiceMasterSubCategory{
    masterSubCategoryUUID: string
}
export class ServiceImage{
    fileLocation: string
    mainImage: boolean
}

export class AddService{
    masterSubCategoryUUID: string
    smeService:SMEService
}

export class CategoryResponse{
    
    category:{
        fileLocation: string
        serviceCategoryDisplayName: string
        serviceCategoryURLName: string
        serviceCategoryUUID: string
    }
    smeServices:Array<SMEService>
}
