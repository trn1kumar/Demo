export class PricingRequest{
    sUuid:string
    plan:string
    type:string
    userUUID:string
}

export class AddCredits{
    type:string
    credits:number
    action:string = "CREDIT"
}

export class PricingConstants{
    public static readonly businessPost : string = "BUSINESS_POST";
    public static readonly listing : string = "LISTING";
    public static readonly bi_read : string = "BI_READ";
    public static readonly connection : string = "CONNECTION";
    public static readonly job_post : string = "JOB_POST";
    public static readonly image_storage_size : string = "IMAGE_STORAGE_SIZE";

    public static readonly freePackage : string= "Free Package";
	public static readonly smallPackage : string= "Small Business Package";
	public static readonly mediumPackage : string= "Medium Business Package";
	public static readonly bigPackage : string= "Big Business Package";
}

export class UserPricing{
    planName: number
    listings: number
    connections: number
    biReadCredits: number
    imageStorageSize: number
    jobPostings: number
    businessPosts: number
    initialPricing: {
        listings: number
        connections: number
        biReadCredits: number
        imageStorageSize: number
        jobPostings: number
        businessPosts: number
    }
}