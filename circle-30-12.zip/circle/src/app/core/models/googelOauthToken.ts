export class GoogleOauthToken{

    authToken:string;
    clientId:string;
}