export class PublishData
{
    id:string
    status:boolean
    businessPost:boolean
}
