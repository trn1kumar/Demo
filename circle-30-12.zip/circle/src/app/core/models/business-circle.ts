import { Image } from "./image";

export class BusinessCircle
{
    sUuid:string;

    sendRequests:SMECircleDto[];

    receiveRequests:SMECircleDto[];

    myConnetions:SMECircleDto[];
}

export class SendRequest{
    toSmeId:string;
}

export class SMECircleDto
{
    sUuid:string;
    smeName:string;
    contactPerson:string;
    images: Image[];
    receiveReqUuid:string;
    sendReqUuid:string;
    mutualConnectionCount:number;
    connectionUud:string;
    status:string
    logoImage:string
    mutualConnections:SMECircleDto[]

}

export class ConnectionVo
{
    sUuid:string;
    connectionUuid:string;
    receiveReqUuid:string;
    sendReqUuid:string;
}