export class RestURL {

    public static readonly BASE_URL: string = 'https://smeface.com/smeface/';
    // SignUp & Login   
   public static readonly authURL: string =RestURL.BASE_URL+ 'users/';
    
    // Content Server
    public static readonly contentServerDeleteUrl: string = RestURL.BASE_URL + 'cdn/api/file/';
    public static readonly contentServerUrl: string = RestURL.BASE_URL + 'cdn/';

    // Product
    public static readonly productURL: string = RestURL.BASE_URL + 'products/';
    public static readonly productSearchURL: string = RestURL.BASE_URL + 'products';
    public static readonly cartURL: string = RestURL.BASE_URL + 'cart/';
    public static readonly categoryURL: string =  RestURL.BASE_URL+'categories';

    // Admin
    public static readonly adminURL: string = RestURL.BASE_URL+ 'admin/';
   
    
    // SME

    public static readonly smeInformartionURL: string =RestURL.BASE_URL+ 'smes/';
    public static readonly smeCategoryURL:string = 'https://smeface.com/smeface';


    // Circle
    public static readonly circleURL: string = RestURL.BASE_URL + 'circle/';

    // Service
    public static readonly serviceURL: string = RestURL.BASE_URL + 'api/services/';
    public static readonly serviceCategoryURL: string = RestURL.BASE_URL + 'api';

    // Business Post;
    public static readonly businessPostURL: string = RestURL.BASE_URL + 'business-post/';

    // JobPost

    public static readonly jobPostUrl: string = RestURL.BASE_URL+'vacancies/';
    public static readonly jobPostCategoryUrl: string ='https://smeface.com/smeface';

    
    // Search
    public static readonly searchURL: string = RestURL.BASE_URL + 'search/';
    
    // Pricing
    public static readonly pricingURL: string = RestURL.BASE_URL + 'api/pricing/';

}
