import { ModalImage } from "angular-modal-gallery";

export class Image {
    fileLocation:string
    mainImage: boolean
}

export class SMEImage
{
    imageLocation:string
    imgUuid:string
    imageName: string
    modal:ModalImage
}