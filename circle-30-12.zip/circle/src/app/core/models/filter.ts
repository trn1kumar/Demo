export class Filter {

     price:PriceFilter;
	 smeFilter:Array<SmeFilter>;
   
}
export class ServiceFilter {

	price:PriceFilter;
	smeFilter:Array<SerivceSmeFilter>;
  
}

export class SmeFilter {
     smeNames:string
	 sUUID:string
	 isSelected:Boolean
}

export class PriceFilter{
    maxPrice:number
	minPrice:number

}
export class SerivceSmeFilter {
	smeName:string
	sUUID:string
	selected:Boolean
}
export class MatChipVaue {
	smeNames:string
  sUUID:string
  
  }