import { Image } from "./image";
import { Category } from "./category";
import { SubCategory } from "./subcategory";

export class Product{

    uuid : string
    productName : string
    productDisplayName : string
    price : number
    weight : number
    description:string
    sUuid : string
    smeName : string
    stock : number
    location : string
    discount : number
    discountedPrice : number
    images : Image[]
    fileLocation : string
    totalBIGenerated:number
    sub_Category:SubCategory
    status:boolean
    subCategory:SubCategory
    specifications: Map<string,string> = new Map<string,string>()
    isActive:boolean
    subUUID:string
    priceUnit:string
    priceCurrency:string
    businessPost:boolean
    minOrderQty:number
    smeInformationDto:SMEInformationDto
}

export class ProductCategoryResponse{
    breadcrumbs: Array<string>
    products: Array<Product>
    productCategory:Category
}
export class SMEInformationDto {
    sUuid:string
    smeName:string
      smeAddress:AddressDto;
}
export class AddressDto {
     locality:string;
     city:string;
}