export class CircleStatus {
    public readonly SENT_REQ: string = "SENT_REQ";
    public readonly RECIEVED_REQ: string = "RECIEVED_REQ";
    public readonly CONNECTED: string = "CONNECTED";
    public readonly NEW: string = "NEW";
    public readonly OWNER: string = "OWNER";
}