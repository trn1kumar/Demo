import { Image, SMEImage } from "./image";
import { Auditable } from "./auditable";

export class SMECertificate extends Auditable{
    crtiUuid : string
    certificateType : string
    certificateDesc : string
    images : Array<SMEImage>
    active:boolean
}