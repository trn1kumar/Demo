export class Address
{
      addrsUuid:string;

	  street1:string;

	  street2:string;

	  city:string;

	  country:string;

	  state:string;

	  pincode:string;
}