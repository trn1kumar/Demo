export class ProceedPayment{
    credits:number
    amount:string
    type:string
    returnURL:string
}