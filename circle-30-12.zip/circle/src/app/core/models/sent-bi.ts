import { Product } from "./product";
import { OrderStatus } from "./receive-bi";

export class Sent_BI{
    smeCartId : number
    businessInterestQuantity : number
    products : Product
    status:string
    orderStatus:OrderStatus
}