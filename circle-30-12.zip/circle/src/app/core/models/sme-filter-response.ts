import { SMEInformation, SMEAddress } from "./sme-information";

export class SMEFilterResponse{
    result:Array<SMEInformationDto>;
    filter:SMEFilterDto;
}

export class SMEFilterDto{
    filters:Map<string,Array<any>>;
}

export class SMECategoryDto{
    categoryUuid:string
    categoryUrl:string
    categoryName:string
    smes:Array<SMEInformationDto>
    totalSmesCount:number;
}

export class SMEInformationDto{
    smeName:string;
	sUuid:string;
	logoImage:string;
	smeAddress: SMEAddress ;
}

export class FilterByCity{
    city:string;
	totalCount:number;
	selected:boolean;
}

export class CategoryFilter {

	categoryUuid:string;
	categoryUrl:string
	categoryName:string;
	totalSmesCount:number;
    selected:boolean;
}