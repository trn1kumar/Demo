import { SmeViewLayoutModule } from './sme-view-layout.module';

describe('SmeViewLayoutModule', () => {
  let smeViewLayoutModule: SmeViewLayoutModule;

  beforeEach(() => {
    smeViewLayoutModule = new SmeViewLayoutModule();
  });

  it('should create an instance', () => {
    expect(smeViewLayoutModule).toBeTruthy();
  });
});
