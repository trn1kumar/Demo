import { SMELayoutModule } from './sme-layout.module';

describe('SMELayoutModule', () => {
  let sMELayoutModule: SMELayoutModule;

  beforeEach(() => {
    sMELayoutModule = new SMELayoutModule();
  });

  it('should create an instance', () => {
    expect(sMELayoutModule).toBeTruthy();
  });
});
