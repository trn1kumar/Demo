import { Component, OnInit, Input } from '@angular/core';
import { NguCarousel } from '@ngu/carousel';
import { MatSnackBar } from '@angular/material';
import { Store } from '@ngrx/store';
import * as fromRoot from '../../../../app.reducers'
import { Product } from 'src/app/core/models/product';
import { TokenStorageService } from 'src/app/core/services/token/token-storage.service';
import { MatDailogService } from 'src/app/core/services/extra/matdialog.config';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { BusinessCartService } from 'src/app/core/services/cart/business-cart.service';
import { SnackBarConfig } from 'src/app/core/services/extra/snackbar.config';
import { ProductService } from 'src/app/core/services/product/product.service';
import { CartItem } from 'src/app/core/models/cart-item';
import { BusinessInterest } from 'src/app/core/models/business-interest';
import { RestURL } from 'src/app/core/models/rest-api-url';



const provider = 'PRODUCT'

@Component({
  selector: 'app-similar-product',
  templateUrl: './similar-product.component.html',
  styleUrls: ['./similar-product.component.css']
})
export class SimilarProductComponent implements OnInit {

  @Input()
  productName: string
  
  @Input()
  subCategoryName: string

  products: Array<Product>

  carousel: NguCarousel

  constructor(private token: TokenStorageService,
    private dialogService: MatDailogService, private jwtToken: JwtTokenService,
    private cartService: BusinessCartService, private snackBar: MatSnackBar,
    private snackBarConfig: SnackBarConfig, private productService: ProductService,
    private store: Store<fromRoot.AppState>) { }

  ngOnInit() {
  
    this.productService.getSimillarProducts(this.productName,this.subCategoryName).subscribe(
      res =>{
        this.products = res
      }
    )

    this.carousel = {
      grid: { xs: 1, sm: 3, md: 4, lg: 6, all: 230 },
      speed: 600,
      interval: 3000,
      point: {
        visible: false
      },
      load: 2,
      easing: 'ease',
      animation: 'lazy',
      touch: true
    }
  }

  businessInterest(uuid, index) {

    if (!this.token.isLoggedIn()) {
      const dialogRef = this.dialogService.openLoginDialog()
      dialogRef.afterClosed().subscribe(
        res => {
          if (this.token.isLoggedIn()) {
            this.genrateBusinessInterest(uuid, index)
          }
        }
      )
    } else {
      this.genrateBusinessInterest(uuid, index)
    }

  }

  genrateBusinessInterest(uuid, index) {

    let cartItem = new CartItem()
    cartItem.businessInterestQuantity = 1
    cartItem.businessInterestUUID = uuid
    cartItem.provider = provider

    let businessInterest = new BusinessInterest()
    businessInterest.cartItem.push(cartItem)
    businessInterest.userUuid = this.jwtToken.getUserId()

    // console.log("BI : ", businessInterest)

    this.cartService.generateBI(businessInterest).subscribe(
      res => {
        this.snackBar.open('Buisness Interest Generated', '', this.snackBarConfig.getSnackBarConfig())
        this.store.dispatch({ type: 'Increment_Total_Cart_Count' })
        this.products.splice(index,1)
      },
      err => {
        if (err.error.errorCode == 208) {
          this.snackBar.open('Product already in cart', '', this.snackBarConfig.getSnackBarConfig())
        }
      }
    )
  }

  getImage(result){
    if(result != null){
      return RestURL.contentServerUrl+(result.fileLocation);
    }else
    return "/assets/not-found/not-available.jpeg"
  }

  productNameClick(productName,uuid){
    let url = productName + '/p/' + uuid
    window.open(url,'_blank')
  }

  smeNameClick(sUuid){
    let url =  'sme/' + sUuid
    window.open(url,'_blank')
  }
}
