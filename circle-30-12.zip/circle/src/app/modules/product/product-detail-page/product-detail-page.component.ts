import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { ProductService } from 'src/app/core/services/product/product.service';
import { Product } from 'src/app/core/models/product';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { TokenStorageService } from 'src/app/core/services/token/token-storage.service';


@Component({
  selector: 'app-product-detail-page',
  templateUrl: './product-detail-page.component.html',
  styleUrls: ['./product-detail-page.component.css']
})
export class ProductDetailPageComponent implements OnInit, OnDestroy {
  similarProduct : Array<Product>;
  product: Product = null;
  subcription$: Subscription

  proudctUuid : any;
  showSpinner : boolean = true
  notFound : boolean = false
  constructor(private route : ActivatedRoute , private productService : ProductService,
    private jwtToken: JwtTokenService,private token: TokenStorageService) { 
   
    this.subcription$ = this.route.params.subscribe(
     params =>{
      this.productBYUuid(params['uuid'])
     }
   )
  }

  ngOnInit() {
  }

  productBYUuid(serviceUUID:string){
    if(this.token.isLoggedIn()){
      this.forUser(serviceUUID);
    }else{
      this.forAll(serviceUUID)
    }
  }

  forAll(serviceUUID:string){
    this.productService.productByUuid(serviceUUID).subscribe(
      res => {
        this.showSpinner = false
        this.product = res
      },
      err => {
        this.showSpinner = false
        this.notFound = true
      }
    )
  }

  forUser(serviceUUID:string){
    this.productService.productByUuidForUSER(serviceUUID,this.jwtToken.getUserId()).subscribe(
      res => {
        this.showSpinner = false
        this.product = res
      },
      err => {
        this.showSpinner = false
        this.notFound = true
      }
    )
  }

  ngOnDestroy(): void {
    this.subcription$.unsubscribe()
  }
  
}
