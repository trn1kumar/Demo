import { Component, OnInit, Input } from '@angular/core';
import { Image } from 'src/app/core/models/image';
import { RestURL } from 'src/app/core/models/rest-api-url';


@Component({
  selector: 'app-product-images',
  templateUrl: './product-images.component.html',
  styleUrls: ['./product-images.component.css']
})
export class ProductImagesComponent implements OnInit {

  @Input()
  images : Image[] = null
  @Input()
  selectedImage : Image = null

  showBottomImages = true

  constructor() { }

  ngOnInit() {
    if(this.images.length != null || this.images.length != undefined){
      this.checkLength(this.images)
    }
  }

  onMouseOver(image : Image){
    this.selectedImage = image
  }

  checkLength(images){
    if(images.length == 1){
      this.showBottomImages = false
    }
  }

  getImage(result){
    if(result != null){
      return RestURL.contentServerUrl+(result.fileLocation);
    }else
    return "/assets/not-found/not-available.jpeg"
  }

}
