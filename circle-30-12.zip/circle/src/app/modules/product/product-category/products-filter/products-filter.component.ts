import { Component, OnInit, Input } from '@angular/core';
// import { Filter, PriceFilter, SmeFilter } from '../../../core/models/filter';
import { Options, LabelType } from 'ng5-slider';
import { Params, ActivatedRoute, Router } from '@angular/router';
import { Filter, SmeFilter, MatChipVaue } from 'src/app/core/models/filter';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-products-filter',
  templateUrl: './products-filter.component.html',
  styleUrls: ['./products-filter.component.css']
})

export class ProductsFilterComponent implements OnInit {
  @Input()
  filter: Filter
  str: string = ""
  priceFilter: string
  selectable = true;
  removable = true;
  minPrice: number
  resetButton: boolean = false
  resetSmeButton: boolean = false
  filters: Array<string>
  showVar: boolean
  showPriceChip: boolean = false
  matChip: Array<MatChipVaue> = new Array;
  maxPrice: number
  
  smefilter: Array<SmeFilter>
  smeFilterSearch: Array<SmeFilter>;
  searchSME = new FormControl()
  options: Options = {

    translate: (value: number, label: LabelType): string => {
      switch (label) {
        case LabelType.Low:
          return '<i class="fa fa-inr"></i>&nbsp;' + value;
        case LabelType.High:
          return '&nbsp;<i class="fa fa-inr"></i>&nbsp;' + value;
        default:
          return '<i class="fa fa-inr"></i>&nbsp;' + value;
      }
    }
  };
  constructor(private router: ActivatedRoute, private route: Router) {

  }
  onClick(name, isSelected: boolean, index: number, smeName) {

    if (isSelected) {
      this.str = this.str.replace(name, "").trim()
      this.matChip = this.matChip.splice(index + 1)
    } else {
      let matValue = new MatChipVaue()
      matValue.smeNames = smeName
      matValue.sUUID = name

      this.str = (this.str + " " + name).trim()
      this.matChip.push(matValue)
      this.showVar = false
    
    }

  }
  onSubmit() {


    if (this.str == undefined || this.str == "") {
      if (this.priceFilter != null) {
        this.onPriceSubmit()
      }
      this.resetButton = false
    } else {

      this.resetButton = true
    }
    return this.str;
  }
  remove(index: number, price: string): void {

    if (index != undefined) {
      this.str = this.clearSmeFilter(this.matChip[index].sUUID, index)
      this.matChip = this.matChip.splice(index + 1)
    }
    if (price != undefined) {
      this.clearPriceFilters()
      this.showPriceChip = false
    }

    this.applyFilter();

  }

  clearSmeFilter(selectedFeildName: string, index: number) {
    this.smefilter.forEach(res => {
      if (selectedFeildName == this.smefilter[index].sUUID)
        res.isSelected = false
    })
    this.resetButton = false
    this.str = this.str.replace(selectedFeildName, "").trim()
    return this.str
  }

  onPriceSubmit() {

    this.priceFilter = this.minPrice + "-" + this.maxPrice
    if (this.priceFilter == undefined || this.priceFilter == "") {

      this.resetButton = false
    } else {

      this.resetButton = true
    }
    if (this.minPrice != this.filter.price.minPrice || this.maxPrice != this.filter.price.maxPrice) {
      return this.priceFilter;
    } else {
      return null;
    }
  }

  ngOnInit() {
    this.minPrice = this.filter.price.minPrice
    this.maxPrice = this.filter.price.maxPrice
    this.smefilter = this.filter.smeFilter
    this.smeFilterSearch = this.filter.smeFilter

    this.searchSME.valueChanges.subscribe(
      value => {
        this.smeFilterSearch = this.filterResult(value)
      }
    )
    this.check()
  }
  clearPriceFilters() {

    this.minPrice = this.filter.price.minPrice
    this.maxPrice = this.filter.price.maxPrice
    this.priceFilter = null;
    this.resetButton = false
    if (this.str != null) {
      this.onSubmit()
    } else {
      this.route.navigate([]);
    }
    this.showPriceChip = false
  }
  clearSmeFilters() {
    this.smefilter.forEach(res => res.isSelected = false)
    this.resetButton = false
    this.str = "";
    if (this.priceFilter != null) {
      this.onPriceSubmit()

    } else {
      this.route.navigate([]);

    }
    this.showVar = false
  }
  clearFilters() {
    this.resetButton = false
    this.clearPriceFilters()
    this.clearSmeFilters()
    this.matChip = <MatChipVaue[]>[];
    this.route.navigate([]);
  }
  applyFilter() {
    const queryparams: Params = Object.assign({}, this.router.snapshot.queryParams);
    queryparams['price'] = this.onPriceSubmit()

    queryparams['sme'] = this.onSubmit()
    if (queryparams['sme'] == undefined || queryparams['sme'] == "") {

      if (queryparams['price'] != undefined || queryparams['price'] != null) {

        this.showPriceChip = true
        this.route.navigate([], { queryParams: { price: queryparams['price'] } });
      } else {

        this.route.navigate([]);
      }
    } else {
      this.route.navigate([], { queryParams: queryparams });
      this.showVar = true
    }

  }

  filterResult(value: string): Array<SmeFilter> {
    const filterValue = value.toLocaleLowerCase();

    return this.smefilter.filter(option => option.smeNames.toLowerCase().includes(filterValue))
  }

  check() {
    if (this.str != null || this.str != undefined) {
      this.showVar = true
    }
    if (this.priceFilter != null || this.priceFilter != undefined) {
      this.showPriceChip = true
    }
  }
}


