import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductsCategorySliderComponent } from './products-category-slider.component';

describe('ProductsCategorySliderComponent', () => {
  let component: ProductsCategorySliderComponent;
  let fixture: ComponentFixture<ProductsCategorySliderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductsCategorySliderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductsCategorySliderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
