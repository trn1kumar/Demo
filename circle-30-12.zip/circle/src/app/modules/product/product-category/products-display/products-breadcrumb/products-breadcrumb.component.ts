import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-products-breadcrumb',
  templateUrl: './products-breadcrumb.component.html',
  styleUrls: ['./products-breadcrumb.component.css']
})
export class ProductsBreadcrumbComponent implements OnInit {

  @Input()
  breadcrumbs: Array<String>

  constructor() { }

  ngOnInit() {
  }

}
