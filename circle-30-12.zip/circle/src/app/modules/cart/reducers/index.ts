import { CartState } from './cart.state';
import * as fromRoot from '../../../app.reducers';
import { ActionReducerMap, createFeatureSelector, createSelector } from '@ngrx/store';
import { cartReducer } from './cart.reducer';

export interface BusinessCartState {
    cart: CartState
}

export interface State extends fromRoot.AppState {
    cart: BusinessCartState
}

export const reducers: ActionReducerMap<BusinessCartState> = {
    cart: cartReducer
};

export const getCartState = createFeatureSelector<State, BusinessCartState>('cart')

export const getSentCount = createSelector(
    getCartState,
    state => state.cart.sentCount
);

export const getReceivedCount = createSelector(
    getCartState,
    state => state.cart.receivedCount
);
