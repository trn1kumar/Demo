import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import * as fromCart from '../../reducers'
import { Sent_BI } from 'src/app/core/models/sent-bi';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { BusinessCartService } from 'src/app/core/services/cart/business-cart.service';

@Component({
  selector: 'app-user-cart',
  templateUrl: './user-cart.component.html',
  styleUrls: ['./user-cart.component.css']
})
export class UserCartComponent implements OnInit {

  sentCount: number
  sentBI: Array<Sent_BI>

  showSpinner: boolean = true
  showCart: boolean
  emptyCart:boolean

  constructor(public jwtToken: JwtTokenService, private cartService: BusinessCartService,
    private store: Store<fromCart.BusinessCartState>) { }

  ngOnInit() {

    this.cartService.sentCartItems(this.jwtToken.getUserId(),1).subscribe(
      res => {
        this.showSpinner = false
        this.showCart = true
        this.sentBI = res.cartItem
        this.sentCount = res.sentCount
        this.store.dispatch({ type: 'Store_Sent_Count', payload: res.sentCount })
        if(!(this.sentBI.length > 0)){
          this.emptyCart = true
        }
      },
      err =>{
        this.emptyCart = true
        this.showSpinner = false
      }
    )

  }
}
