import { Component, OnInit, Input } from '@angular/core';
import { Store, select } from '@ngrx/store';
import * as fromCart from '../../../../reducers'
import { Sent_BI } from 'src/app/core/models/sent-bi';

@Component({
  selector: 'app-user-cart-display',
  templateUrl: './user-cart-display.component.html',
  styleUrls: ['./user-cart-display.component.css']
})
export class UserCartDisplayComponent implements OnInit {

  @Input()
  sentCount : number
  @Input()
  sentBI : Sent_BI

  constructor(private store: Store<fromCart.BusinessCartState>) { }

  ngOnInit() {
    this.store.pipe(select(fromCart.getSentCount)).subscribe(
      res => this.sentCount=+res
    )
  }

}
