import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MatSnackBar, MAT_DIALOG_DATA } from '@angular/material';
import { FormControl, Validators } from '@angular/forms';
import { BusinessCartService } from 'src/app/core/services/cart/business-cart.service';
import { SnackBarConfig } from 'src/app/core/services/extra/snackbar.config';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { OrderStatus, FirstStage, MessageCenter, SecondStage } from 'src/app/core/models/receive-bi';
import { Quotation } from '../../../sme-cart/components/sme-cart-items/accept-dialog.component';

export interface ReasonMessage {
  id: number
  message: string
}

@Component({
  template: `

    <div class="text-center">

    <mat-dialog-content>
      <div class="row">
        <div class="col-md-3 text-center" style="padding:20px">
          <b>Reason</b>
        </div>
        <div class="col-md-9">
        <mat-form-field style="width:100%">
        <mat-select placeholder="please select" [formControl]="BIclosedReason" required>
          <mat-option *ngFor="let value of reasons" [value]="value">
            <span>{{value.message}}</span>
          </mat-option>
        </mat-select>
        <mat-error *ngIf="BIclosedReason.hasError('required')">Please select reason</mat-error>
      </mat-form-field>
        </div>
      </div>
      <div *ngIf="otherReasonTextBox">
      <mat-form-field style="width:100%">
        <input matInput placeholder="Write a reason" [formControl]="reasonControl" length=1000>
      </mat-form-field>
      </div>
    </mat-dialog-content>

    <p></p>

    <div *ngIf="otherReasonTextBox">
      <button mat-stroked-button (click)="otherMessage()" color="warn">Reject</button>
    </div>
    </div>
  `
})
export class RejectDialogComponent implements OnInit {


  BIclosedReason = new FormControl(null, [Validators.required]);
  reasons: ReasonMessage[] = [
    { id: 1, message: "I bought from other seller" },
    { id: 2, message: "Not interest now" },
    { id: 3, message: "other" }
  ]
  otherReasonTextBox: boolean
  reasonControl = new FormControl()

  constructor(private dialogRef: MatDialogRef<RejectDialogComponent>, private cartService: BusinessCartService,
    @Inject(MAT_DIALOG_DATA) public data: any, private snackBar: MatSnackBar,
    private snackBarConfig: SnackBarConfig, private jwtToken: JwtTokenService) { }

  ngOnInit(): void {
    this.BIclosedReason.valueChanges.subscribe(
      res => {
        if(res.id == 3){
          this.otherReasonTextBox = true
        }else{
          this.predefinedMessage(res.message)
        }
      }
    )
  }

  predefinedMessage(message) {

    this.dialogRef.close()
    let quotation = new Quotation()
    quotation.uuid = this.data.receiveCartItemUuid
    quotation.orderStatus = new OrderStatus()
    quotation.orderStatus.currentStatus = this.data.currentStatus
    quotation.orderStatus.secondStage=new SecondStage()
    quotation.orderStatus.secondStage.messageCenter = new MessageCenter()
    quotation.orderStatus.secondStage.messageCenter.message = message

    this.reject(quotation)
  }

  otherMessage(){
    this.dialogRef.close()
    let quotation = new Quotation()
    quotation.uuid = this.data.receiveCartItemUuid
    quotation.orderStatus = new OrderStatus()
    quotation.orderStatus.currentStatus = this.data.currentStatus
    quotation.orderStatus.secondStage=new SecondStage()
    quotation.orderStatus.secondStage.messageCenter = new MessageCenter()
    quotation.orderStatus.secondStage.messageCenter.message = this.reasonControl.value
    
    this.reject(quotation)
  }

  reject(data:Quotation){
    this.cartService.rejectBusinessInterestUSER(data).subscribe(
      res =>{
        this.snackBar.open("reject succesfully","",this.snackBarConfig.getSnackBarConfig())
        this.dialogRef.close(data.orderStatus.secondStage.messageCenter)
      }
    )
  }
  

  onClickNo() {
    this.dialogRef.close()
  }

}
