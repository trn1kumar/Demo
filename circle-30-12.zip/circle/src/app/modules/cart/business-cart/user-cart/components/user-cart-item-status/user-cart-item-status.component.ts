import { Component, OnInit, Input } from '@angular/core';
import { OrderStatus } from 'src/app/core/models/receive-bi';
import { ViewQuotationComponent } from '../../../view-quotation.component';
import { MatDialogRef, MatDialogConfig, MatDialog } from '@angular/material';

const SENT = 'SENT'
const RECEIVED = 'QUOTATION RECEIVED'
const ORDERED = 'ORDERED'
const DELIVERED = 'DELIVERED'

@Component({
  selector: 'app-user-cart-item-status',
  templateUrl: './user-cart-item-status.component.html',
  styleUrls: ['./user-cart-item-status.component.css']
})
export class UserCartItemStatusComponent implements OnInit {

  @Input()
  orderStatus: OrderStatus;

  acceptDialogRef: MatDialogRef<ViewQuotationComponent>;
  constructor(private dialog: MatDialog) { }

  ngOnInit() {
    
  }


  view(status:string){
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';
    if(status === 'second'){
      dialogConfig.data = this.orderStatus.secondStage
    }
    if(status === 'third'){
      dialogConfig.data = this.orderStatus.thirdStage
    }

    this.acceptDialogRef = this.dialog.open(ViewQuotationComponent, dialogConfig);
  }

}
