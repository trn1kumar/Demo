import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserCartDisplayComponent } from './user-cart-display.component';

describe('UserCartDisplayComponent', () => {
  let component: UserCartDisplayComponent;
  let fixture: ComponentFixture<UserCartDisplayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserCartDisplayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserCartDisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
