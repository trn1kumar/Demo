import { Component, OnInit, Input } from '@angular/core';
import { MatDialog, MatDialogRef, MatDialogConfig } from '@angular/material';
import { DeleteCartDialogComponent } from './delete-cart-dialog.component';
import { Store } from '@ngrx/store';
import * as fromCart from '../../../../reducers'
import { Sent_BI } from 'src/app/core/models/sent-bi';
import { RestURL } from 'src/app/core/models/rest-api-url';
import * as fromRoot from '../../../../../../app.reducers'
import { AcceptQuotationComponent } from './accept-quotation.component';
import { RejectDialogComponent } from './reject-quotation.component';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { BusinessCartService } from 'src/app/core/services/cart/business-cart.service';
@Component({
  selector: 'app-user-cart-items',
  templateUrl: './user-cart-items.component.html',
  styleUrls: ['./user-cart-items.component.css']
})
export class UserCartItemsComponent implements OnInit {

  @Input()
  sentBI : Sent_BI[]

  deleteDialogRef: MatDialogRef<DeleteCartDialogComponent>;
  acceptDialogRef: MatDialogRef<AcceptQuotationComponent>;
  rejectDialogRef: MatDialogRef<RejectDialogComponent>;

  page = 2;
  throttle = 300;
  scrollDistance = 1;
  scrollUpDistance = 2;

  spinner:boolean
  constructor(private matDialog : MatDialog,private appStore: Store<fromRoot.AppState>,
    private cartStore: Store<fromCart.BusinessCartState>,private dialog: MatDialog,
    private jwtToken: JwtTokenService,private cartService: BusinessCartService) { }

  ngOnInit() {

  }

  onScrollDown () {
    if(this.sentBI.length > 9){
    this.spinner = true
    this.cartService.sentCartItems(this.jwtToken.getUserId(),this.page++).subscribe(
      res => {
        this.spinner = false
        this.sentBI.push(...res.cartItem)
      },
      err => {
        if(err.error.errorCode = 404){
          this.spinner = false
        }
      })
    }
  }


  deleteCartItem(cartItemId,index){
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';
    dialogConfig.data = cartItemId
    
    this.deleteDialogRef = this.matDialog.open(DeleteCartDialogComponent,dialogConfig);
    this.deleteDialogRef.afterClosed().subscribe(
      res => {
        if(res == true){
          this.sentBI.splice(index,1)
          this.appStore.dispatch({ type: 'Decrement_Total_Cart_Count' })
          this.cartStore.dispatch({ type: 'Decrement_Sent_Count'})
        }
      }
    )
  }

  rejectQuotation(receiveCartItemUuid,index,currentStatus:string){
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';
    dialogConfig.data = {receiveCartItemUuid:receiveCartItemUuid,currentStatus:currentStatus}

    this.rejectDialogRef = this.dialog.open(RejectDialogComponent, dialogConfig);
    this.rejectDialogRef.afterClosed().subscribe(
      res =>{
        
          if(currentStatus === 'Quotation'){
            this.sentBI[index].orderStatus.secondStage.stepStatus = 'BI CLOSED'
            this.sentBI[index].orderStatus.secondStage.messageCenter = res
          }
      }
    )
  }

  acceptQuotation(receiveCartItemUuid,index) {

      const dialogConfig = new MatDialogConfig();
      dialogConfig.autoFocus = false;
      dialogConfig.width = '400px';
      dialogConfig.data = {receiveCartItemUuid}

      this.acceptDialogRef = this.dialog.open(AcceptQuotationComponent, dialogConfig);
      this.acceptDialogRef.afterClosed().subscribe(
        res => {
          if(res){
            this.sentBI[index].orderStatus.currentStatus = 'Purchase Order'
            this.sentBI[index].orderStatus.thirdStage = res
            this.sentBI[index].orderStatus.thirdStage.stepStatus = 'PO SENT'
            this.sentBI[index].orderStatus.thirdStage.statusName = 'PURCHASE ORDER'
          }
        }
      )
  }

  getImage(result){
    if(result != null){
      return RestURL.contentServerUrl+(result);
    }else
    return "/assets/not-found/not-available.jpeg"
  }

  productNameClick(productName,uuid){
    let url = productName + '/p/' + uuid
    window.open(url,'_blank')
  }
  smeNameClick(sUuid){
    let url =  'sme/' + sUuid
    window.open(url,'_blank')
  }
  serviceNameClick(serviceName,uuid){
    let url = 'services/'+serviceName+'/'+uuid
    window.open(url,'_blank')
  }
}
