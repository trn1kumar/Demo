import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { RestURL } from 'src/app/core/models/rest-api-url';

@Component({
  template: `

    <div class="text-center" *ngIf="data.quotationFile">
      <a class="custom" href="{{URL}}{{data.quotationFile.fileLocation}}" target="_blank">
        Download File
      </a>
    </div>

    <div>
      <p *ngIf="data.messageCenter.message" class="message">Message</p>
      <p>{{data.messageCenter.message}}</p>
    </div>

  `,
  styles:[
    `.message{
      margin-top:10px;
      color:grey;
    }
    .custom{
      border: 1px solid #bfbfbf;
      padding: 5px;
      color: #225282;
    }
    `
  ]
})
export class ViewQuotationComponent {

  URL=RestURL.contentServerUrl

  constructor(private dialogRef: MatDialogRef<ViewQuotationComponent>,
     @Inject(MAT_DIALOG_DATA) public data: any) {
    
  }

  onClickCancle() {
    this.dialogRef.close()
  }

}
