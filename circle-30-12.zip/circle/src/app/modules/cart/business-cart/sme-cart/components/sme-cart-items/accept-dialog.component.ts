import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { FormControl } from '@angular/forms';
import { BusinessCartService } from 'src/app/core/services/cart/business-cart.service';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { SnackBarConfig } from 'src/app/core/services/extra/snackbar.config';
import { HttpClient } from '@angular/common/http';
import { RestURL } from 'src/app/core/models/rest-api-url';
import { OrderStatus, SecondStage, MessageCenter } from 'src/app/core/models/receive-bi';
import { Observable } from 'rxjs';

@Component({
  template: `

  <div class="text-center mb-2">
    <b>Accept Request and Send Quotation File</b>
  </div>

    <div class="text-center">
    <mat-icon  style="font-size:80px;color:rgb(166, 166, 166);margin-right:60px;">attach_file</mat-icon>
    </div>

    <div class="text-center mb-4">
      <input type="file" #fileInput (change)="getFileDetails($event.target.files)" required style="margin-left:55px;">
    </div>

    <div class="image-types">
      *File size should be less than 5MB.
    </div>

    <div>
      <mat-form-field class="example-full-width">
        <input matInput placeholder="Write a message" [formControl]="quotationMessage" length=1000>
      </mat-form-field>
      <div *ngIf="showError">
        <span style="color:red">please select file or write message</span>
      </div>
    </div>

    <button mat-stroked-button (click)="send()" color="primary" style="margin-right:30px">Send Quotation</button>
    <button mat-stroked-button (click)="onClickCancle()" color="primary">Cancel</button>
  `,
  styles: [
    `.example-full-width {
      width: 100%;
    }
    .image-types{
      color: grey;
      font-size: 12px;
      margin-bottom:10px;
    }`
  ]
})
export class AcceptDialogComponent {

  showError: boolean
  quotationMessage = new FormControl(null)
  uploadedFile: QuotationFile

  constructor(private dialogRef: MatDialogRef<AcceptDialogComponent>, private cartService: BusinessCartService,
    private jwtToken: JwtTokenService, @Inject(MAT_DIALOG_DATA) public data: any,
    private snackBar: MatSnackBar, private snackBarConfig: SnackBarConfig, private http: HttpClient) {
  }

  send() {
    let message: string = this.quotationMessage.value

    if ((message != undefined && message != null && message != '') || this.uploadedFile) {
      this.sendQuotation()
    } else {
      this.showError = true
    }
  }

  sendQuotation() {
    this.showError = false
    let quotation = new Quotation()
    quotation.uuid = this.data.receiveCartItemUuid
    quotation.orderStatus = new OrderStatus()
    quotation.orderStatus.secondStage = new SecondStage()
    quotation.orderStatus.secondStage.messageCenter = new MessageCenter()
    quotation.orderStatus.secondStage.messageCenter = { message: this.quotationMessage.value }

    if (this.uploadedFile) {
      quotation.orderStatus.secondStage.quotationFile = new QuotationFile()
      quotation.orderStatus.secondStage.quotationFile.fileLocation = this.uploadedFile.fileLocation
    }

    this.cartService.sendQuotationSME(quotation).subscribe(
      res => {
        this.snackBar.open("Quotation sent successfully", '', this.snackBarConfig.getSnackBarConfig())
        this.dialogRef.close(quotation.orderStatus.secondStage)
      },
    )
  }

  onClickCancle() {
    this.dialogRef.close()
  }

  getFileDetails(file: File) {
    this.showError = false
    if (file[0].size < 5242880) {
      let formData: FormData = new FormData()
      formData.append("files", file[0])
      this.uploadFile(formData).subscribe(res => {
        this.uploadedFile = new QuotationFile()
        this.uploadedFile.fileLocation = res.fileLocation
      })
    } else {
      this.showError = true
    }
  }

  uploadFile(formData: FormData): Observable<any> {
    return this.http.post(RestURL.cartURL + this.jwtToken.getSmeUuid() + '/upload', formData)
  }

}

export class QuotationFile {
  fileLocation: string
}

export class Quotation {

  uuid: string
  orderStatus: OrderStatus
}