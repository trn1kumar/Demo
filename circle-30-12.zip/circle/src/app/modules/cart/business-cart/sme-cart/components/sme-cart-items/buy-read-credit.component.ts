import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { Inject, Component } from "@angular/core";

@Component({
    template: `
        <div class="text-center" *ngIf="buyNowButton">
        <mat-icon  style="font-size:100px;color:rgb(247, 173, 62);margin-right:70px;">error_outline</mat-icon>
        </div>

        <div class="text-center" *ngIf="buyNowButton">
        <h6 style="color:red">You dont have Business Interest Read credits to view User Details</h6>
        </div>

        <div class="text-center" style="margin-top:20px" *ngIf="buyNowButton">
        <button mat-stroked-button (click)="buyNow()" color="primary">BUY NOW</button>
        <button mat-stroked-button (click)="close()" color="primary" style="margin-left:30px">Cancel</button>
        </div>

        <div class="text-center" *ngIf="okButton">
        <img src="../../../assets/smeface/check.gif" height="300" weight="300">
        <div>
        <button mat-stroked-button (click)="ok()" color="primary">Ok</button>
        </div>
        </div>
    `,
    styles: [
        ``
    ]
})
export class BuyReadCreditComponent {

    buyNowButton: boolean = true
    okButton: boolean

    constructor(private dialogRef: MatDialogRef<BuyReadCreditComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any) {
    }

    buyNow(){
        this.buyNowButton = false
        this.okButton = true
    }

    ok(){
        this.dialogRef.close(true)
    }

    close() {
        this.dialogRef.close()
    }
}  