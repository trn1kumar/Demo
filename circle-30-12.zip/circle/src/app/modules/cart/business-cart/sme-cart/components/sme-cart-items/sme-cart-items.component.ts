import { Component, OnInit, Input, Output, EventEmitter, HostListener } from '@angular/core';
import { MatDialogConfig, MatDialogRef, MatDialog } from '@angular/material';
import { AcceptDialogComponent, Quotation } from './accept-dialog.component';
import { DeleteDialogComponent } from './delete-dialog.component';
import { BusinessCartService } from 'src/app/core/services/cart/business-cart.service';
import { BuyReadCreditComponent } from './buy-read-credit.component';
import { Received_BI, OrderStatus, ThirdStage } from 'src/app/core/models/receive-bi';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { RestURL } from 'src/app/core/models/rest-api-url';
import { RejectPOComponent } from './reject-po.component';

@Component({
  selector: 'app-sme-cart-items',
  templateUrl: './sme-cart-items.component.html',
  styleUrls: ['./sme-cart-items.component.css']
})
export class SmeCartItemsComponent implements OnInit {

  @Input()
  receivedBI: Array<Received_BI>

  @Input()
  biReadCredits: number

  @Output()
  manageCredit = new EventEmitter()

  acceptDialogRef: MatDialogRef<AcceptDialogComponent>;
  deleteDialogRef: MatDialogRef<DeleteDialogComponent>;
  buyCreditDialogRef: MatDialogRef<BuyReadCreditComponent>;
  rejectPODialogRef: MatDialogRef<RejectPOComponent>;

  page = 2;
  throttle = 300;
  scrollDistance = 1;
  scrollUpDistance = 2;

  spinner:boolean
  constructor(private dialog: MatDialog, private jwtToken: JwtTokenService,
    private cartService: BusinessCartService) { }

  ngOnInit() {
    
  }

  onScrollDown () {
    if(this.receivedBI.length > 9){
    this.spinner = true
    this.cartService.receivedCartItems(this.jwtToken.getUserId(),this.page++).subscribe(
      res => {
        this.spinner = false
        this.receivedBI.push(...res.body.recievdBusinessInterests)
      },
      err => {
        if(err.error.errorCode = 404){
          this.spinner = false
        }
      })
    }
  }

  acceptPO(uuid:string,index:number){
    let acceptPO ={
      uuid:uuid
    }

    this.cartService.acceptPurchaseOrder(acceptPO).subscribe(
      res => {
        this.receivedBI[index].orderStatus.currentStatus = 'Delivered'
        this.receivedBI[index].orderStatus.finalStage.stepStatus = 'PO ACCEPTED'
      }
    )
  }

  onRejectPO(receiveCartItemUuid: string,index: number,currentStatus:string){
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';
    dialogConfig.data = {receiveCartItemUuid:receiveCartItemUuid,currentStatus:currentStatus}

    this.rejectPODialogRef = this.dialog.open(RejectPOComponent, dialogConfig);
    this.rejectPODialogRef.afterClosed().subscribe(
      res =>{
          if(res && currentStatus === 'Purchase Order'){
            this.receivedBI[index].orderStatus.thirdStage.stepStatus = 'BI CLOSED'
            this.receivedBI[index].orderStatus.thirdStage.messageCenter = res
          }
      }
    )
  }


  onRejectDialog(receiveCartItemUuid: string,index: number,currentStatus:string) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';
    dialogConfig.data = {receiveCartItemUuid:receiveCartItemUuid,currentStatus:currentStatus}

    this.deleteDialogRef = this.dialog.open(DeleteDialogComponent, dialogConfig);
    this.deleteDialogRef.afterClosed().subscribe(
      res =>{
          if(res && currentStatus === 'Receive'){
            this.receivedBI[index].orderStatus.firstStage.stepStatus = 'BI CLOSED'
            this.receivedBI[index].orderStatus.firstStage.messageCenter = res
          }
      }
    )
  }

  onAcceptDialog(receiveCartItemUuid: string, index) {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';
    dialogConfig.data = { receiveCartItemUuid }

    this.acceptDialogRef = this.dialog.open(AcceptDialogComponent, dialogConfig);
    this.acceptDialogRef.afterClosed().subscribe(
      res => {
        if (res) {
          this.receivedBI[index].orderStatus.currentStatus = 'Quotation'
          this.receivedBI[index].orderStatus.secondStage = res
          this.receivedBI[index].orderStatus.secondStage.stepStatus = 'QUOTATION SENT'
          this.receivedBI[index].orderStatus.secondStage.statusName = 'QUOTATION'
        }
      }
    )
  }


  openBuyCreditDialog(uuid: string,index) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true
    dialogConfig.autoFocus = false;
    dialogConfig.width = '500px';

    this.buyCreditDialogRef = this.dialog.open(BuyReadCreditComponent, dialogConfig);
    this.buyCreditDialogRef.afterClosed().subscribe(
      res => {
        if (res == true) {
          this.manageCredit.emit(true)
          this.receivedBI[index].viewStatus = true
          this.getUserDetails(uuid,index)
        }
      }
    )
  }
  onViewStatus(uuid: string,index:number) {
    if (this.biReadCredits > 0) {
      this.receivedBI[index].spinner = true
      this.getUserDetails(uuid,index)
    } else {
      this.openBuyCreditDialog(uuid,index)
    }

  }
  
  getUserDetails(uuid: string,index:number) {
    let data:any={
      uuid:uuid,
      sUuid:this.jwtToken.getSmeUuid(),
      userUUID:this.jwtToken.getUserId()
    }
    this.cartService.getUserDetails(data).subscribe(
      res => {
        this.receivedBI[index].userDetails = res;
        this.manageCredit.emit(false)
        this.receivedBI[index].spinner = false
      },
      err => {
        if(err.error.errorCode == 402){
          this.receivedBI[index].spinner = false
          this.openBuyCreditDialog(uuid,index)
          // this.receivedBI[index].viewStatus = false
          // this.manageCredit.emit(true)
        }else{
          this.receivedBI[index].spinner = false
        }
      }
    )
  }

  getImage(result) {
    if (result != null) {
      return RestURL.contentServerUrl + (result);
    } else
      return "/assets/not-found/not-available.jpeg"
  }

  productNameClick(productName, uuid) {
    let url = productName + '/p/' + uuid
    window.open(url, '_blank')
  }
  serviceNameClick(serviceName, uuid) {
    let url = 'services/' + serviceName + '/' + uuid
    window.open(url, '_blank')
  }
}
