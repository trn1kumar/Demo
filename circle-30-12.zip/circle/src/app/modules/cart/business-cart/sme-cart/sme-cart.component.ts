import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import * as fromCart from '../../reducers'
import { Received_BI } from 'src/app/core/models/receive-bi';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { BusinessCartService } from 'src/app/core/services/cart/business-cart.service';

@Component({
  selector: 'app-sme-cart',
  templateUrl: './sme-cart.component.html',
  styleUrls: ['./sme-cart.component.css']
})export class SmeCartComponent implements OnInit {

  receivedBI: Array<Received_BI>

  showSpinner: boolean = true
  cartIsEmpty: boolean 
  showCart: boolean

  constructor(private jwtToken: JwtTokenService, private cartService: BusinessCartService,
    private store: Store<fromCart.BusinessCartState>) { }

  ngOnInit() {
    this.getReceivedCartItems()
  }

  getReceivedCartItems(){
    let uuid = this.jwtToken.getUserId()
    
    this.cartService.receivedCartItems(uuid,1).subscribe(
      res => {
        this.showSpinner = false
        this.receivedBI = res.body.recievdBusinessInterests
        this.store.dispatch({ type: 'Store_Sent_Count', payload: res.body.sentCount })
        this.store.dispatch({ type: 'Store_Received_Count', payload: res.body.receiveCount })
        if(this.receivedBI.length > 0){
          this.showCart = true
        }else{
          this.cartIsEmpty = true
        }
      },
      err => {
        this.showSpinner = false
        this.cartIsEmpty = true
      }
    )
  }

}
