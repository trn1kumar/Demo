import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductMainCategoryComponent } from './product-main-category.component';

describe('ProductMainCategoryComponent', () => {
  let component: ProductMainCategoryComponent;
  let fixture: ComponentFixture<ProductMainCategoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductMainCategoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductMainCategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
