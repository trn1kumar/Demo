import { Component, OnInit, Input } from '@angular/core';
import { NguCarousel } from '@ngu/carousel';
import { CategoriesMenuService } from 'src/app/common/component/categories-menu/categories-menu.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { RestURL } from 'src/app/core/models/rest-api-url';

@Component({
  selector: 'app-product-main-category',
  templateUrl: './product-main-category.component.html',
  styleUrls: ['./product-main-category.component.css']
})
export class ProductMainCategoryComponent implements OnInit {

  @Input()
  homepageCategory;

  carousel: NguCarousel
  constructor(private categoriesMenuServices : CategoriesMenuService,private  router:Router) { }

  ngOnInit() {

    this.carousel = {
      grid: { xs: 1, sm: 3, md: 4, lg: 6, all: 180 },
      speed: 600,
      interval: 3000,
      point: {
        visible: false
      },
      load: 2,
      // easing: 'ease',
      // animation: 'lazy',
      touch: true
    }
  }
  onViewAll() {
    let url = '/product-categories'
    window.open(url, '_blank')
  }

  
  getImage(result) {
    if (result != null) {
      return RestURL.contentServerUrl + (result.fileLocation);
    } else
      return "/assets/not-found/not-available.jpeg"
  }

}
