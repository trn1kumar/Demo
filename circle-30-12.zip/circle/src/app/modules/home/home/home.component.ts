import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from 'src/app/core/models/product';
import { SMEService } from 'src/app/core/models/sme-service';
import { HomePageService } from 'src/app/core/services/home-page/home-page.service';
import { TokenStorageService } from 'src/app/core/services/token/token-storage.service';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { SmeService } from 'src/app/core/services/sme-service/sme.service';
import { Image } from 'src/app/core/models/image';
import { SME } from 'src/app/core/models/sme';
import { CategoriesMenuService } from 'src/app/common/component/categories-menu/categories-menu.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  products : Array<Product>
  services : Array<SMEService>
  smes: Array<SME>;
  homeSlider:Array<Image>
  homepageCategory : Array<any>
  homePageServiceCategories: Array<any>;

  constructor(private homePageService : HomePageService ,private smeService: SmeService,
    private jwtToken:JwtTokenService,private token:TokenStorageService,private categoriesMenuServices : CategoriesMenuService) { }

  ngOnInit() {

    if(this.token.isLoggedIn() && this.jwtToken.getUserType()){
      this.forUser();
    }else if(this.token.isLoggedIn() && !this.jwtToken.getUserType()){
      this.forSME()
    }else{
      this.forAll()
    }
    this.forSlider()
    this.categoriesMenuServices.categories().subscribe(
      res=>
      {
        this.homepageCategory=res;
      }
    )
    this.categoriesMenuServices.serviceCategories().subscribe(
      res=>
      {
        this.homePageServiceCategories=res
      }
    )
  }

  forAll(){
    this.homePageService.products().subscribe(
      res => {
        this.products = res
      }
    )
    this.smeService.services().subscribe(
      res => {
        this.services = res
      }
    )
    this.homePageService.sme().subscribe(
      res => {
        this.smes = res
      }
    )
 


  }

  forUser(){
    let userUUID = this.jwtToken.getUserId()
    let sUuid = this.jwtToken.getSmeUuid()
    this.homePageService.productsForUserType(userUUID).subscribe(
      res => {
        this.products = res
      }
    )
    this.smeService.servicesForUser(userUUID).subscribe(
      res => {
        this.services = res
      }
    )

    this.homePageService.sme().subscribe(
      res => {
        this.smes = res
      }
    )
  
  }

  forSME(){
    let userUUID = this.jwtToken.getUserId()
    let sUuid = this.jwtToken.getSmeUuid()
    this.homePageService.productsForSMEType(userUUID,sUuid).subscribe(
      res => {
        this.products = res
      }
    )
    this.smeService.servicesForUser(userUUID).subscribe(
      res => {
        this.services = res
      }
    )
    this.homePageService.smesForSmeType(sUuid).subscribe(
      res => {
        this.smes = res
      }
    )
  }

  forSlider()
  {
    this.homePageService.getHomeSliderImage().subscribe(
      res1=>
    {
      this.homeSlider=res1.fileLocation;
    })
  }

}
