import { Injectable } from "@angular/core";

@Injectable()
export class HomeActions {
    static Increment_Total_Cart_Count = 'Increment_Total_Cart_Count'
    static Decrement_Total_Cart_Count = 'Decrement_Total_Cart_Count'
    static Store_Total_Cart_Count = 'Store_Total_Cart_Count'
    static Default_Cart_State = 'Default_Cart_State'
    static Change_Cart_State = 'Change_Cart_State'

    incrementCartCount() {
        return { type: HomeActions.Increment_Total_Cart_Count }
    }
    decrementCartCount() {
        return { type: HomeActions.Decrement_Total_Cart_Count }
    }
    storeCartCount(count: number) {
        return { type: HomeActions.Store_Total_Cart_Count, payload: count }
    }
    changeCartState() {
        return { type: HomeActions.Change_Cart_State }
    }
    defaultCartState(){
        return { type: HomeActions.Default_Cart_State }
    }
}