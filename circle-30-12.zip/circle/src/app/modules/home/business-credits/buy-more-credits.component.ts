import { Inject, Component, OnInit } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { JwtTokenService } from "src/app/core/services/token/jwt-token.service";
import { PricingService } from "src/app/core/services/pricing/pricing.service";
import { AddCredits } from "src/app/core/models/pricing";
import { FormControl, Validators } from "@angular/forms";
import { ProceedPayment } from "src/app/core/models/payment";

@Component({
    template: `
    <div *ngIf="closeButton">
    <a href matTooltip="Close" onclick="return false" (click)="close()" 
    style="float:right ; color : rgb(43, 43, 192)">
      <mat-icon>close</mat-icon>
    </a>
    </div>

    <p *ngIf="buyCredits" style="text-align: center;font-family: 'Franklin Gothic Medium';color: #3374b6;
    font-weight: bold;font-size:17px">
        {{data.displayName}}
    </p>

    <div *ngIf="buyCredits" class="btn-group" role="group" style="margin:10px 0px;padding:0px 35%">
        <button type="button" class="btn btn-secondary" (click)="minus()">-</button>
        <div class="border" style="padding: 6px 15px;">{{credits}}</div>
        <button type="button" class="btn btn-secondary" (click)="plus()">+</button>
    </div>

    <div class="text-center" *ngIf="buyNowButton">
    <button mat-stroked-button (click)="buy()" color="primary">Buy</button>
    <span style="margin-right:20px"></span>
    <button mat-stroked-button (click)="close()" color="primary">close</button>
    </div>

    <div class="text-center" *ngIf="okButton">
        <img src="../../../assets/smeface/check.gif" height="200" weight="00">
        <div>
        <button mat-stroked-button (click)="ok()" color="primary">Ok</button>
        </div>
    </div>

    `
})
export class BuyMoreCreditsComponent implements OnInit {

    buyNowButton: boolean = true
    okButton: boolean
    closeButton: boolean = true
    buyCredits: boolean = true
    // creditsControl = new FormControl(1, [Validators.min(1)]);

    credits: number = 1
    amount: number = 12056765

    constructor(private dialogRef: MatDialogRef<BuyMoreCreditsComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any, private pricingService: PricingService,
        public jwtToken: JwtTokenService) {

    }

    ngOnInit(): void {
        // this.creditsControl.valueChanges.subscribe(
        //     value => {
        //         if (value < 0) {
        //             this.creditsControl.setValue(1)
        //         }
        //     }
        // )
    }

    plus() {
        if (this.credits > 0) {
            this.credits = ++this.credits
        } else {
            this.credits = 1
        }
    }

    minus() {
        if (this.credits != 1) {
            this.credits = --this.credits
        } else {
            this.credits = 1
        }

    }


    buy() {

        // let proceedPayment = new ProceedPayment();
        // proceedPayment.credits = this.credits
        // proceedPayment.amount = this.amount.toString()

        let object = new AddCredits()
        object.type = this.data.type
        object.action = 'CREDIT'
        object.credits = this.credits
        this.pricingService.updateCredits(object).subscribe(res => {
            if (res.status == 201) {
                this.buyNowButton = false
                this.okButton = true
                this.closeButton = false
                this.buyCredits = false
            }
        })

    }

    ok() {
        this.dialogRef.close({ type: this.data.type, credits: this.credits })
    }

    close() {
        this.dialogRef.close()
    }

}

// <div *ngIf="buyCredits" class="text-center" style="margin-bottom:20px">
// <span style="font-size:15px">Credits </span> 
// <input style="width:25%" [formControl]="creditsControl" type="number">
// </div>