import { Component, OnInit } from '@angular/core';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { TokenStorageService } from 'src/app/core/services/token/token-storage.service';
import { PricingService } from 'src/app/core/services/pricing/pricing.service';
import { Observable } from 'rxjs';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';
import { FileSizeFormatService } from 'src/app/core/services/extra/file-size-format.service';
import { BuyMoreCreditsComponent } from './buy-more-credits.component';
import { PricingConstants, UserPricing } from 'src/app/core/models/pricing';
import { Router } from '@angular/router';

@Component({
  selector: 'app-business-credits',
  templateUrl: './business-credits.component.html',
  styleUrls: ['./business-credits.component.css']
})
export class BusinessCreditsComponent implements OnInit {

  userPricing: UserPricing
  buyNowDialogRef: MatDialogRef<BuyMoreCreditsComponent>;

  businessPost: string = PricingConstants.businessPost
  listing: string = PricingConstants.listing
  bi_read: string = PricingConstants.bi_read
  connection: string = PricingConstants.connection
  imageStorage: string = PricingConstants.image_storage_size
  job_post: string = PricingConstants.job_post

  spinner:boolean = true
  constructor(private pricingService: PricingService, private dialog: MatDialog,
    public format: FileSizeFormatService, private jwtToken: JwtTokenService) { }

  ngOnInit() {
    this.getUserPricingDetails()
  }

  getUserPricingDetails() {
    this.pricingService.getUserPricingDetailsWithInitial().subscribe(
      res => {
        this.spinner = false
        this.userPricing = res
      }
    )
  }
  buyMoreCredits(type: string,displayName:string) {
    this.openDialog(type,displayName)
  }

  openDialog(type: string,displayName:string) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';
    dialogConfig.data = { type: type, displayName:displayName }

    this.buyNowDialogRef = this.dialog.open(BuyMoreCreditsComponent, dialogConfig);
    this.buyNowDialogRef.afterClosed().subscribe(
      res => {
        if (res) {

          switch (res.type) {
            case this.businessPost: {
              this.userPricing.businessPosts = this.userPricing.businessPosts + res.credits
              this.userPricing.initialPricing.businessPosts = this.userPricing.initialPricing.businessPosts + res.credits
              break;
            }
            case this.bi_read: {
              this.userPricing.biReadCredits = this.userPricing.biReadCredits + res.credits
              this.userPricing.initialPricing.biReadCredits = this.userPricing.initialPricing.biReadCredits + res.credits
              break;
            }
            case this.connection: {
              this.userPricing.connections = this.userPricing.connections + res.credits
              this.userPricing.initialPricing.connections = this.userPricing.initialPricing.connections + res.credits
              break;
            }
            case this.job_post: {
              this.userPricing.jobPostings = this.userPricing.jobPostings + res.credits
              this.userPricing.initialPricing.jobPostings = this.userPricing.initialPricing.jobPostings + res.credits
              break;
            }
            case this.imageStorage: {
              this.userPricing.imageStorageSize = this.userPricing.imageStorageSize + res.credits
              this.userPricing.initialPricing.imageStorageSize = this.userPricing.initialPricing.imageStorageSize + res.credits
              break;
            }
            case this.listing: {
              this.userPricing.listings = this.userPricing.listings + res.credits
              this.userPricing.initialPricing.listings = this.userPricing.initialPricing.listings + res.credits
              break;
            }
            default: {
              this.getUserPricingDetails()
              break;
            }
          }
        }
      })
  }


}
