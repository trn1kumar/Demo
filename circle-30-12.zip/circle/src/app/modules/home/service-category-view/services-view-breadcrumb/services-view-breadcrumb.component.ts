import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-services-view-breadcrumb',
  templateUrl: './services-view-breadcrumb.component.html',
  styleUrls: ['./services-view-breadcrumb.component.css']
})
export class ServicesViewBreadcrumbComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
