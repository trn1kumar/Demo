import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { HomePageService } from 'src/app/core/services/home-page/home-page.service';
import { NguCarousel } from '@ngu/carousel';
import { RestURL } from 'src/app/core/models/rest-api-url';

@Component({
  selector: 'app-service-category-view',
  templateUrl: './service-category-view.component.html',
  styleUrls: ['./service-category-view.component.css']
})
export class ServiceCategoryViewComponent implements OnInit {

  serviceCategories: Array<any>
  carousel: NguCarousel

  constructor(private homePageService:HomePageService) { }

  ngOnInit() {

   this.homePageService.getServiceAllCategories().subscribe(
     res=>
     {
      this.serviceCategories=res;
     }
   )
    
    this.carousel = {
      grid: { xs: 1, sm: 3, md: 4, lg: 6, all: 180 },
      speed: 600,
      interval: 3000,
      point: {
        visible: false
      },
      load: 2,
      // easing: 'ease',
      // animation: 'lazy',
      touch: true
    }
  }
  
  getImage(fileLocation){
    if(fileLocation != null){
      return RestURL.contentServerUrl+fileLocation;
    }else
    return "/assets/not-found/not-available.jpeg"
  }
}
