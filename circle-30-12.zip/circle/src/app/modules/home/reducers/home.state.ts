export interface HomeState {
    totalCartCount : number
}
export interface CheckCartState{
    status:string
}