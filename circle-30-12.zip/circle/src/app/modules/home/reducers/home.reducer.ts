import { HomeState, CheckCartState } from "./home.state";
import { HomeActions } from "../actions/home.actions";

export const Initial_State: HomeState = {
    totalCartCount: 0,
}

export const Initial_Check_Cart_State: CheckCartState = {
    status: 'DEFAULT'
}

export function homeReducer(lastState = Initial_State, { type, payload }: any): HomeState {

    switch (type) {
        case HomeActions.Increment_Total_Cart_Count:
            return { totalCartCount: lastState.totalCartCount + 1 }

        case HomeActions.Decrement_Total_Cart_Count:
            return { totalCartCount: lastState.totalCartCount - 1 }

        case HomeActions.Store_Total_Cart_Count:
            return { totalCartCount: lastState.totalCartCount = payload.Count }

        default:
            return lastState
    }
}

export function checkCartStateReducer(lastState = Initial_Check_Cart_State, { type }: any): CheckCartState {
    switch (type) {

        case HomeActions.Default_Cart_State:
            return { status: lastState.status = 'DEFAULT'};

        case HomeActions.Change_Cart_State:
            return { status: lastState.status = 'CHANGED'}

        default:
            return lastState
    }

}