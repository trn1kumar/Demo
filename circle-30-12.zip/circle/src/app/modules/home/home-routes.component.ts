import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-routes',
  templateUrl: './home-routes.component.html',
  styleUrls: ['./home-routes.component.css']
})
export class HomeRoutesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
