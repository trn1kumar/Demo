import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductCategoryViewBreadcrumbsComponent } from './product-category-view-breadcrumbs.component';

describe('ProductCategoryViewBreadcrumbsComponent', () => {
  let component: ProductCategoryViewBreadcrumbsComponent;
  let fixture: ComponentFixture<ProductCategoryViewBreadcrumbsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductCategoryViewBreadcrumbsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductCategoryViewBreadcrumbsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
