import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-category-view-breadcrumbs',
  templateUrl: './product-category-view-breadcrumbs.component.html',
  styleUrls: ['./product-category-view-breadcrumbs.component.css']
})
export class ProductCategoryViewBreadcrumbsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
