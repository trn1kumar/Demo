import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { HomePageService } from 'src/app/core/services/home-page/home-page.service';
import { NguCarousel } from '@ngu/carousel';
import { RestURL } from 'src/app/core/models/rest-api-url';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-category-view',
  templateUrl: './product-category-view.component.html',
  styleUrls: ['./product-category-view.component.css']
})
export class ProductCategoryViewComponent implements OnInit {

  productCategories:Array<any>
  carousel: NguCarousel

  constructor(private homePageService:HomePageService,private router:Router) { }

  ngOnInit() {
  this.homePageService.getProductAllCategories().subscribe(
    res=>
    {
      this.productCategories=res
    }
  )
  this.carousel = {
    grid: { xs: 1, sm: 3, md: 4, lg: 6, all: 180 },
    speed: 600,
    interval: 3000,
    point: {
      visible: false
    },
    load: 2,
    // easing: 'ease',
    // animation: 'lazy',
    touch: true
  }
  }
   
  getImage(result) {
    if (result != null) {
      return RestURL.contentServerUrl + (result.fileLocation);
    } else
      return "/assets/not-found/not-available.jpeg"
  }
  productClick(name){
    this.router.navigateByUrl(name)
  }

}
