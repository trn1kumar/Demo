import { Component, OnInit, Input } from '@angular/core';
import { NguCarousel } from '@ngu/carousel';
import { Image } from 'src/app/core/models/image';
import { RestURL } from 'src/app/core/models/rest-api-url';

@Component({
  selector: 'app-home-slider',
  templateUrl: './home-slider.component.html',
  styleUrls: ['./home-slider.component.css']
})
export class HomeSliderComponent implements OnInit {
  @Input()
  homeSlider:Array<Image>
  public carouselOne: NguCarousel;
  constructor() { }

  ngOnInit() {
    this.carouselOne = {
      grid: { xs: 1, sm: 1, md: 1, lg: 1, all: 0 },
      slide: 1,
      speed: 100,
      interval: 3000,
      point: {
        visible: false,
      },
      load: 2,
      touch: true,
      loop: true,
      custom: 'banner'
    };
  }
  getImage(imageName)
  {
    if(imageName != null){
      return RestURL.contentServerUrl+(imageName);
    }else
    return "/assets/home-slider/addImage1.png";
  }
  }
