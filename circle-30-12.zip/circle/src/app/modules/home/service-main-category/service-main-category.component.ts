import { Component, OnInit, Input } from '@angular/core';
import { NguCarousel } from '@ngu/carousel';
import { SMEService } from 'src/app/core/models/sme-service';
import { CategoriesMenuService } from 'src/app/common/component/categories-menu/categories-menu.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { RestURL } from 'src/app/core/models/rest-api-url';

@Component({
  selector: 'app-service-main-category',
  templateUrl: './service-main-category.component.html',
  styleUrls: ['./service-main-category.component.css']
})
export class ServiceMainCategoryComponent implements OnInit {

  @Input()
  homePageServiceCategories
  carousel: NguCarousel
  constructor(private categoriesMenuServices : CategoriesMenuService,private  router:Router) { }

  ngOnInit() {

    this.carousel = {
      grid: { xs: 1, sm: 3, md: 4, lg: 6, all: 180 },
      speed: 600,
      interval: 3000,
      point: {
        visible: false
      },
      load: 2,
      // easing: 'ease',
      // animation: 'lazy',
      touch: true
    }
  }
  onViewAll() {
    let url = '/service-categories'
    window.open(url, '_blank')
  }
  getImage(fileLocation){
    if(fileLocation != null){
      return RestURL.contentServerUrl+fileLocation;
    }else
    return "/assets/not-found/not-available.jpeg"
  }
}
