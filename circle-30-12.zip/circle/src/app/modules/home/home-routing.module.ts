import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { HomeRoutesComponent } from './home-routes.component';
import { BusinessCreditsComponent } from './business-credits/business-credits.component';
import { UserTypeGuardService } from 'src/app/core/guards/user-type-guard.service';
import { ProductCategoryViewComponent } from './product-category-view/product-category-view.component';
import { ServiceCategoryViewComponent } from './service-category-view/service-category-view.component';

const routes: Routes = [
  { path : '' , component:HomeRoutesComponent , 
    children : [
      { path: '' , component:HomeComponent},
      { path: 'business-credits' , component:BusinessCreditsComponent ,canActivate:[UserTypeGuardService]},
      { path: 'product-categories' , component:ProductCategoryViewComponent},
      { path: 'service-categories' , component:ServiceCategoryViewComponent},
    ]},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
