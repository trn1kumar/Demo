import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-business-post',
  templateUrl: './business-post.component.html',
  styleUrls: ['./business-post.component.css']
})
export class BusinessPostComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
