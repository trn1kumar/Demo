import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BusinessPostRoutingModule } from './business-post-routing.module';
import { BusinessPostComponent } from './business-post.component';
import { BusineeHomeComponent } from './businee-home/businee-home.component';
import { WriteFeedsComponent } from './businee-home/write-feeds/write-feeds.component';
import { DisplayFeedsComponent } from './businee-home/display-feeds/display-feeds.component';
import { SharedModule } from '../shared/shared.module';
import { BusinessProfileComponent } from './businee-home/business-profile/business-profile.component';
import { BusinessRightSideComponent } from './businee-home/business-right-side/business-right-side.component';
import { PrivateConnectionDialog } from './businee-home/write-feeds/private-connection-dialog/private-connection-dialog.component';
import { DeleteFeedDialogComponent } from './businee-home/display-feeds/delete-feed-dialog.component';
import { LayoutModule } from 'src/app/layout/users/smeface/layout.module';
import { TimeAgoPipe } from 'time-ago-pipe';
import { DeleteDialogConnection } from './businee-home/business-profile/delete-connection/delete-dialog-component';
import { SocialBreadCrumbComponent } from './businee-home/social-bread-crumb/social-bread-crumb.component';

@NgModule({
  imports: [
    CommonModule,
    BusinessPostRoutingModule,
    LayoutModule,
    SharedModule
  ],
  declarations: [
    BusinessPostComponent,
    BusineeHomeComponent,
    WriteFeedsComponent,
    DisplayFeedsComponent,
    BusinessProfileComponent,
    BusinessRightSideComponent,
    PrivateConnectionDialog,
    DeleteFeedDialogComponent,
    TimeAgoPipe,  
    DeleteDialogConnection, SocialBreadCrumbComponent
  ],
  entryComponents: [
    PrivateConnectionDialog,
    DeleteFeedDialogComponent,
    DeleteDialogConnection ]
})
export class BusinessPostModule { }
