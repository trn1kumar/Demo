import { Routes, RouterModule } from "@angular/router";
import { NgModule } from "@angular/core";
import { BusinessPostComponent } from "./business-post.component";
import { BusineeHomeComponent } from "./businee-home/businee-home.component";
import { UserTypeGuardService } from "src/app/core/guards/user-type-guard.service";

const routes: Routes = [
  {path:'',component:BusinessPostComponent,
    children:[
        {path:'',component:BusineeHomeComponent,canActivate:[UserTypeGuardService]}
        ]}
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })

export class BusinessPostRoutingModule{
    
}