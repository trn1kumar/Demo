import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-social-bread-crumb',
  templateUrl: './social-bread-crumb.component.html',
  styleUrls: ['./social-bread-crumb.component.css']
})
export class SocialBreadCrumbComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
