import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SocialBreadCrumbComponent } from './social-bread-crumb.component';

describe('SocialBreadCrumbComponent', () => {
  let component: SocialBreadCrumbComponent;
  let fixture: ComponentFixture<SocialBreadCrumbComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SocialBreadCrumbComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SocialBreadCrumbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
