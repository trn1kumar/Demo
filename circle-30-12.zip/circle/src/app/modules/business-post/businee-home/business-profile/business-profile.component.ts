import { Component, OnInit, Input } from '@angular/core';
import { BusinessCircle, SendRequest, SMECircleDto, ConnectionVo } from 'src/app/core/models/business-circle';
import { SME } from 'src/app/core/models/sme';
import { BusinessCircleService } from 'src/app/core/services/circle/business-circle.service';
import { RestURL } from 'src/app/core/models/rest-api-url';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { SnackBarConfig } from 'src/app/core/services/extra/snackbar.config';
import { MatSnackBar, MatDialogConfig, MatDialogRef, MatDialog } from '@angular/material';
import { DeleteDialogConnection } from './delete-connection/delete-dialog-component';


@Component({
  selector: 'app-business-profile',
  templateUrl: './business-profile.component.html',
  styleUrls: ['./business-profile.component.css']
})
export class BusinessProfileComponent implements OnInit {

  @Input()
  sme: any
  connectionCount:number=0;
  circle: BusinessCircle;
  receviedReq: SME[];
  sUuid: string;
  sentReq:SME[];
  pendingRequestsNotFound:boolean=false
  deleteDialogRef : MatDialogRef<DeleteDialogConnection>
  seeAll:boolean=true
  seeAllConnection:boolean=false
  circleConnection: SMECircleDto[];

  constructor(private businessCircle: BusinessCircleService,private matDialog : MatDialog,private snackbarConfig : SnackBarConfig,private snackBar: MatSnackBar,
    private jwtToken:JwtTokenService) { }

  ngOnInit() {

    let sUuid=this.jwtToken.getSmeUuid();
    this.businessCircle.getBusinessCircle(sUuid).subscribe(
     res => {
       this.circle = res;
       this.receviedReq = this.circle.receiveRequests
       if(this.receviedReq == null || this.receviedReq == undefined)
       {
         this.pendingRequestsNotFound=true;
         this.seeAll=false
       }
       /*My Conenctions START*/
      
       if(this.circle.myConnetions != undefined)
       {
         this.connectionCount = this.circle.myConnetions.length
       }
     
       
       /*My Conenctions END*/
     },
     );
     this.businessCircle.getMyCircleConnection(sUuid).subscribe(
      res => {
      this.circleConnection = res;
    },
    );
  }
 
  getImage(imageName) {

    if (imageName != null) {
      return RestURL.contentServerUrl + (imageName);
    } else
      return "/assets/logo/Male-Avatar.png"
  }
  onRemoveConnection(connectionUuid: string,index) {
    let removeCon = new ConnectionVo();
    removeCon.sUuid = this.sUuid;
    removeCon.connectionUuid = connectionUuid;

   const dialogConfig = new MatDialogConfig();
   dialogConfig.autoFocus = false;
   dialogConfig.width = '400px';
   dialogConfig.data = removeCon

   this.deleteDialogRef = this.matDialog.open(DeleteDialogConnection, dialogConfig);
   this.deleteDialogRef.afterClosed().subscribe(
     res => {
       if(res == true){
         this.circleConnection.splice(index,1)
       }
     }
   )
 }
  smeNameClick(sUuid) {
    let url = 'sme/' + sUuid
    window.open(url, '_blank')
  }
  onMyConnection()
  {
    let url = 'circle/my-connections'
    window.open(url, '_blank')
  }
}
