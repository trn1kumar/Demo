import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from "@angular/material";

import { BusinessCircleService } from "src/app/core/services/circle/business-circle.service";

import { Inject, Component } from "@angular/core";

import { SnackBarConfig } from "src/app/core/services/extra/snackbar.config";

@Component({
    selector: 'app-business-delete-conenction',
    templateUrl: './delete-connection-dialog.component.html',
    styleUrls: ['./delete-connection-dialog.component.css']
  })
export class DeleteDialogConnection
{
    constructor(private dialogRef: MatDialogRef<DeleteDialogConnection>,
        private businessCircle: BusinessCircleService,
       @Inject(MAT_DIALOG_DATA) public data: any, private snackBar: MatSnackBar,
       private snackBarConfig: SnackBarConfig) { }

   onDelete() {
    this.businessCircle.removeConnection(this.data).subscribe(
           res => {
               this.snackBar.open('remove successfully', 'Ok', this.snackBarConfig.getSnackBarConfig())
               this.dialogRef.close(true)
           },
       )  
   }
   onClickNo() {
       this.dialogRef.close()
   }
}