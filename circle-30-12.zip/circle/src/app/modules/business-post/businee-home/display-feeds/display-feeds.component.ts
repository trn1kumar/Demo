import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { DeleteFeedDialogComponent } from './delete-feed-dialog.component';
import { MatDialogRef, MatDialog, MatDialogConfig } from '@angular/material';
import { BusinessPostService } from 'src/app/core/services/business-post/business-post.service';
import { SnackBarConfig } from 'src/app/core/services/extra/snackbar.config';
import { RestURL } from 'src/app/core/models/rest-api-url';
import { MessageTimePipe } from 'src/app/modules/shared/pipes/messageTime.pipe';

@Component({
  selector: 'app-display-feeds',
  templateUrl: './display-feeds.component.html',
  styleUrls: ['./display-feeds.component.css']
})
export class DisplayFeedsComponent implements OnInit {

  @Input()
  displayFeeds
  show: boolean = true
  sUuid:string
  deleteDialogRef : MatDialogRef<DeleteFeedDialogComponent>
 
  constructor(private businessPostService: BusinessPostService, private router: Router,private snackbarConfig: SnackBarConfig, private matDialog : MatDialog) { }

  ngOnInit() {
  }
 
  onRemoveFeed(businessPostId: string,index) {
   const dialogConfig = new MatDialogConfig();
   dialogConfig.disableClose=true
   dialogConfig.autoFocus = false;
   dialogConfig.width = '400px';
   dialogConfig.data = businessPostId

   this.deleteDialogRef = this.matDialog.open(DeleteFeedDialogComponent, dialogConfig);
   this.deleteDialogRef.afterClosed().subscribe(
     res => {
       if(res == true){
         this.displayFeeds.splice(index,1)
       }
     }
   )
 }
  getImage(imageName) {

    if (imageName != null) {
      return RestURL.contentServerUrl + (imageName);
    } else
      return "/assets/logo/Male-Avatar.png"
  }
 
  smeNameClick(sUuid) {
    let url = 'sme/' + sUuid
    window.open(url, '_blank')
  }
  onShow() {
    this.show = false
  }
  machineNameClick(sUuid,id)
  {
    let url = 'sme/'+sUuid+'/infrastructure/' + id
    window.open(url, '_blank')

  }

}
