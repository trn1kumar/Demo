import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayFeedsComponent } from './display-feeds.component';

describe('DisplayFeedsComponent', () => {
  let component: DisplayFeedsComponent;
  let fixture: ComponentFixture<DisplayFeedsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisplayFeedsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayFeedsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
