import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BusineeHomeComponent } from './businee-home.component';

describe('BusineeHomeComponent', () => {
  let component: BusineeHomeComponent;
  let fixture: ComponentFixture<BusineeHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BusineeHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BusineeHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
