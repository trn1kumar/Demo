import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { SMEInformation } from 'src/app/core/models/sme-information';
import { BusinessPostDto } from 'src/app/core/models/business-post';
import { SmeInfoService } from 'src/app/core/services/sme-page/sme-info.service';
import { BusinessPostService } from 'src/app/core/services/business-post/business-post.service';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';



@Component({
  selector: 'app-businee-home',
  templateUrl: './businee-home.component.html',
  styleUrls: ['./businee-home.component.css']
})
export class BusineeHomeComponent implements OnInit {

  sme:Observable<SMEInformation>
  displayFeeds: Array<BusinessPostDto>;
  constructor(private smeService: SmeInfoService,private businessPostService:BusinessPostService,
    private jwtToken:JwtTokenService) { }

  ngOnInit() {

    let sUuid=this.jwtToken.getSmeUuid();
    this.smeService.getBasicInfo(sUuid).subscribe(
      res=>
      {
        this.sme=res;
        // console.log(res,'SME')
      }
    )

    this.businessPostService.getAllFeeds(sUuid).subscribe(
      res => {
        this.displayFeeds = res.body
      }
    )
  }

}
