import { Component, OnInit, Input } from '@angular/core';
import { HttpClient, HttpResponse, HttpEventType } from '@angular/common/http';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { PrivateConnectionDialog } from './private-connection-dialog/private-connection-dialog.component';
import { MatDialogRef, MatDialog, MatDialogConfig } from '@angular/material';
import { BusinessPostImages, BusinessPost } from 'src/app/core/models/business-post';
import { BusinessPostService } from 'src/app/core/services/business-post/business-post.service';
import { RestURL } from 'src/app/core/models/rest-api-url';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';


@Component({
  selector: 'app-write-feeds',
  templateUrl: './write-feeds.component.html',
  styleUrls: ['./write-feeds.component.css']
})
export class WriteFeedsComponent implements OnInit {

  @Input()
  sme: any
  @Input()
  displayFeeds:Array<any>

  smefaceImage: boolean = true
  businessPostForm: FormGroup
  urls = new Array<string>();
  myFiles: string[] = [];
  privateConnectionView:MatDialogRef<PrivateConnectionDialog>
  privacyCategory=
  [
      'public','circle','private'
  ]
  connectionIds:string[]=[]

  /*Images Uploaded*/
  evt: any;
  indexCount: number = 0;
  uploadedImages = new Array<string>()
  postImages = new Array<BusinessPostImages>(1);
  selectedImages = new Array<string>();
  fileTypes: Array<string> = [
    "image/jpeg",
    "image/png",
    "image/jpg"
  ]
  progressPercent: number
  showProgress: boolean = false
  showFileTypeError: boolean = false
  fileUploadFail: boolean = false

 /*Images Uploaded End*/
 
  constructor(private formBuilder: FormBuilder, private matDialog : MatDialog, private businessPostService: BusinessPostService,private http: HttpClient,
    private jwtToken:JwtTokenService) { }

  ngOnInit() {

    this.loadForm()
    
  }
  loadForm(){
    this.businessPostForm = this.formBuilder.group({
      businessPostId:new FormControl(null),
      smeUuid: new FormControl(this.jwtToken.getSmeUuid()),
      description: new FormControl(null, [Validators.required]),
      privacy: new FormControl(null)
    });
    this.businessPostForm.controls['privacy'].setValue(this.privacyCategory[0])
  }
  getImage(imageName) {

    if (imageName != null) {
      return RestURL.contentServerUrl + (imageName);
    } else
      return "/assets/logo/Male-Avatar.png"
  }
  smeNameClick(sUuid) {
    let url = 'sme/' + sUuid
    window.open(url, '_blank')
  }
  onPrivate()
  {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose=true
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';  
    this.privateConnectionView = this.matDialog.open(PrivateConnectionDialog, dialogConfig);
    this.privateConnectionView.afterClosed().subscribe(
      res => {
         this.connectionIds=res;
      }
    )
  }
  

  onFileChanged(files: Array<any>) {

    this.fileUploadFail = false
    for (let i = 0; i < files.length; i++) {
      let type = files[i].type
      if (this.fileTypes.indexOf(type) == -1) {
        this.showFileTypeError = true
        return false
      } else {
        this.showFileTypeError = false
        if (this.selectedImages.length != 5) {
          this.selectedImages.push(files[i])
        } else {
           this.uploadFile()
          return false
        }
      }
    }
     this.uploadFile()
  }

  uploadFile()
  {
    let formData:FormData=new FormData()
    Array.from(this.selectedImages).forEach(
      file => {
        if (this.uploadedImages.indexOf(file) == -1) {
          formData.append('files', file)
        }
      }
    )
    this.http.post(RestURL.businessPostURL + this.jwtToken.getSmeUuid()+'/smes/'+' '+'/feeds/files', formData, {
      reportProgress: true, observe: 'events'
    }).subscribe(
      event=>
      {
        if (event.type === HttpEventType.UploadProgress) {
          this.progressPercent = Math.round(100 * event.loaded / event.total);
        } else if (event instanceof HttpResponse) {
          Array.from(this.selectedImages).forEach(
            file => {
              this.uploadedImages.push(file)
            }
          )
          for (let i = 0; i < this.selectedImages.length; i++) {
            if (event.body[i] != null || event.body[i] != undefined) {
              this.postImages.splice(this.indexCount, 1, event.body[i])
              ++this.indexCount
            }
          }
          this.showProgress = false
        }
      },
      err => {
        this.showProgress = false
        this.fileUploadFail = true
      }
    )
  }
  
 onDeleteImage(index: number, fileLocation: string)
 {
  this.fileUploadFail = false
  this.postImages.splice(index, 1)
  this.selectedImages.splice(index, 1)
  this.postImages.push(undefined)
  --this.indexCount
  this.businessPostService.deleteImage(fileLocation).subscribe()
 }
 getImageLocation(fileLocation) {
  return RestURL.contentServerUrl + (fileLocation);
}

onSubmit() {
  if(this.businessPostForm.valid)
  {
    let formData: FormData = new FormData()
    Array.from(this.selectedImages).forEach(file => formData.append('files', file))
    
   

    let post :BusinessPost =this.businessPostForm.value;
    post.tags=this.connectionIds;
    post.files=this.postImages;
    this.businessPostService.businessPost(post).subscribe(
      res => {
        this.displayFeeds.unshift(res.body)   
        this.businessPostForm.reset();
      },
      // err => {
      //   console.log(err)
      //   if (err.status == 402) {
      //     const dialogRef = this.buyNowDialog.openbuyNowDialog()
      //     dialogRef.afterClosed().subscribe(
      //       res => {
  
      //       }
      //     )
      //   }
      // }
    );
  }
  else {
    console.log("Invalid")
  }
}
}
