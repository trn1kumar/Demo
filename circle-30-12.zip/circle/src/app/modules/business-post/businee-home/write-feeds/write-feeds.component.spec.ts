import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WriteFeedsComponent } from './write-feeds.component';

describe('WriteFeedsComponent', () => {
  let component: WriteFeedsComponent;
  let fixture: ComponentFixture<WriteFeedsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WriteFeedsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WriteFeedsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
