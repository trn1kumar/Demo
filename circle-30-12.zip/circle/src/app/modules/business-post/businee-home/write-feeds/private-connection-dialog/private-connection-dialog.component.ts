import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";
import { Inject, Component } from "@angular/core";
import { SMECircleDto } from "src/app/core/models/business-circle";
import { BusinessCircleService } from "src/app/core/services/circle/business-circle.service";
import { RestURL } from "src/app/core/models/rest-api-url";
import { JwtTokenService } from "src/app/core/services/token/jwt-token.service";

@Component({
    selector: 'app-write-feed',
    templateUrl: './private-connection-dialog-component.html',
    styleUrls: ['./private-connection-dialog.component.css']
  })
export class PrivateConnectionDialog {

    connectionIds:string[]=[]
    connections:Array<SMECircleDto>
    constructor(private dialogRef: MatDialogRef<PrivateConnectionDialog>,
        @Inject(MAT_DIALOG_DATA) public data: any,private businessCircle:BusinessCircleService ,
        private jwtToken:JwtTokenService) {
    }

    ngOnInit() {
        let sUuid=this.jwtToken.getSmeUuid();

        this.businessCircle.getMyCircleConnection(sUuid).subscribe(
            res=>
            {
                this.connections=res
            }
        )
    }
    onclick()
    {
        this.dialogRef.close(this.connectionIds)
    }
    oncl(id:string)
    {
        let index=this.connectionIds.indexOf(id)
        if(index === -1)
        {
            this.connectionIds.push(id)
        }
        else{
            this.connectionIds.splice(index,1)
        }
   
    }
    getImage(imageName) {

        if (imageName != null) {
          return RestURL.contentServerUrl + (imageName);
        } else
          return "/assets/logo/Male-Avatar.png"
      }
    smeNameClick(sUuid) {
        let url = 'sme/' + sUuid
        window.open(url, '_blank')
      }
    close() {
        this.dialogRef.close()
    }
}