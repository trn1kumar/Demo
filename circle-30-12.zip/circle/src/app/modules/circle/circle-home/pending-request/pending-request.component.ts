import { Component, OnInit } from "@angular/core";
import { SME } from "src/app/core/models/sme";
import { ConnectionVo, BusinessCircle, SMECircleDto } from "src/app/core/models/business-circle";
import { MatDialogRef, MatDialog, MatSnackBar, MatDialogConfig } from "@angular/material";
import { DeletePendingDialogComponent } from "./remove-pending-dialog.component";
import { MutualPConnectionDialogComponents } from "./mutual-connection-pending-request/mutual-pconnection-dialog.component";
import { SnackBarConfig } from "src/app/core/services/extra/snackbar.config";
import { Router } from "@angular/router";
import { BusinessCircleService } from "src/app/core/services/circle/business-circle.service";
import { RestURL } from "src/app/core/models/rest-api-url";
import { JwtTokenService } from "src/app/core/services/token/jwt-token.service";


@Component({
  selector: 'app-pending-request',
  templateUrl: './pending-request.component.html',
  styleUrls: ['./pending-request.component.css']
})
export class PendingRequestComponent implements OnInit {

  sUuid: string;
  receviedReq: SME[];
  makeConnection: ConnectionVo;
  circleConnection: BusinessCircle;
  deleteDialogRef: MatDialogRef<DeletePendingDialogComponent>
  mutualpConnectionView:MatDialogRef<MutualPConnectionDialogComponents>
  pendingRequestNotFound: boolean = false
  constructor(private snackbarConfig: SnackBarConfig, private matDialog: MatDialog, private snackBar: MatSnackBar, private router: Router, private businessCircle: BusinessCircleService,
    private jwtToken:JwtTokenService) { }

  ngOnInit() {
    this.sUuid = this.jwtToken.getSmeUuid();

    this.businessCircle.getAllReceviedRequest(this.sUuid).subscribe(res => {
      this.receviedReq = res;
    },
      err => {
        this.pendingRequestNotFound = true;
      }
    );
  }
  onOpenDialog(mutualConnections:SMECircleDto[],smeName:string)
  {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';
    dialogConfig.data ={mutualConnections,smeName}
  
    this.mutualpConnectionView = this.matDialog.open(MutualPConnectionDialogComponents, dialogConfig);
    this.mutualpConnectionView.afterClosed().subscribe(
      res => {
        if(res == true)
        {
         
        }
      }
    )
  }
  onConfirmRequest(receiveRequestId, index) {

    let makeCon = new ConnectionVo();
    makeCon.sUuid = this.sUuid;
    makeCon.receiveReqUuid = receiveRequestId;
    // console.log(makeCon);
    this.businessCircle.makeConnection(makeCon).subscribe(res => {

      this.snackBar.open('Request Accepted', 'Ok', this.snackbarConfig.getSnackBarConfig());
      this.receviedReq.splice(index, 1)
    },
    );
  }

  onDeleteRequest(receiveRequestId: string, index) {
    let delCon = new ConnectionVo();
    delCon.sUuid = this.sUuid;
    delCon.receiveReqUuid = receiveRequestId;

    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';
    dialogConfig.data = delCon

    this.deleteDialogRef = this.matDialog.open(DeletePendingDialogComponent, dialogConfig);
    this.deleteDialogRef.afterClosed().subscribe(
      res => {
        if (res == true) {
          this.receviedReq.splice(index, 1)
        }
      }
    )
  }

  getImage(imageName) {
    if (imageName != null) {
      return RestURL.contentServerUrl + (imageName);
    } else
      return "/assets/not-found/404.jpg"
  }
  smeNameClick(sUuid) {
    let url = 'sme/' + sUuid
    window.open(url, '_blank')
  }
  smeNameClickSent() {
    let url = 'circle/sent-requests/'
    window.open(url, '_blank')
  }
}
