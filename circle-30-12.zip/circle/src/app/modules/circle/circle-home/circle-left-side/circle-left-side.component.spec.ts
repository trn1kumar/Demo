import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CircleLeftSideComponent } from './circle-left-side.component';

describe('CircleLeftSideComponent', () => {
  let component: CircleLeftSideComponent;
  let fixture: ComponentFixture<CircleLeftSideComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CircleLeftSideComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CircleLeftSideComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
