import { Component, OnInit } from '@angular/core';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { SmeInfoService } from 'src/app/core/services/sme-page/sme-info.service';
import { SMEInformation } from 'src/app/core/models/sme-information';
import { Observable } from 'rxjs';
import { RestURL } from 'src/app/core/models/rest-api-url';

@Component({
  selector: 'app-circle-left-side',
  templateUrl: './circle-left-side.component.html',
  styleUrls: ['./circle-left-side.component.css']
})
export class CircleLeftSideComponent implements OnInit {

  sme:Observable<SMEInformation>

  constructor(private jwtToken:JwtTokenService,private smeService: SmeInfoService) { }

  ngOnInit() {
    let sUuid=this.jwtToken.getSmeUuid();
    this.smeService.getBasicInfo(sUuid).subscribe(
      res=>
      {
        this.sme=res;
        // console.log(res,'SME')
      }
    )
  }
  getImage(imageName) {

    if (imageName != null) {
      return RestURL.contentServerUrl + (imageName);
    } else
      return "/assets/logo/Male-Avatar.png"
  }
}
