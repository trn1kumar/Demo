import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-circle-bread-crumbs',
  templateUrl: './circle-bread-crumbs.component.html',
  styleUrls: ['./circle-bread-crumbs.component.css']
})
export class CircleBreadCrumbsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
