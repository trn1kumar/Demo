import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CircleBreadCrumbsComponent } from './circle-bread-crumbs.component';

describe('CircleBreadCrumbsComponent', () => {
  let component: CircleBreadCrumbsComponent;
  let fixture: ComponentFixture<CircleBreadCrumbsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CircleBreadCrumbsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CircleBreadCrumbsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
