import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { Inject, Component } from "@angular/core";
import { RestURL } from "src/app/core/models/rest-api-url";

@Component({
    selector: 'app-mutual-sent-request',
    templateUrl: './mutual-connection-dialog.component.html',
    styleUrls: ['./mutual-connection-dialog.component.css']
  })
export class MutualSConnectionDialogComponents
{
    constructor(private dialogRef: MatDialogRef<MutualSConnectionDialogComponents>,
        @Inject(MAT_DIALOG_DATA) public data: any,) { 
        }
 
    onClickNo() {
        this.dialogRef.close()
    }
    close() {
     this.dialogRef.close()
   }
   getImage(imageName){
     if(imageName != null){
       return RestURL.contentServerUrl + (imageName);
     }else
     return "/assets/not-found/404.jpg"
   }
   smeNameClick(sUuid)
   {
     let url =  'sme/' + sUuid
     window.open(url,'_blank')
   }
}