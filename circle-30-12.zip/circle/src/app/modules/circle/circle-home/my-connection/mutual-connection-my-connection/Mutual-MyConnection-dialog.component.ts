import { Component, Inject } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { RestURL } from "src/app/core/models/rest-api-url";


@Component({
    selector: 'app-mutual-my-connection',
    templateUrl: './mutual-connection-my-conenction.html',
    styleUrls: ['./mutual-connection-my-connection.css']
  })
export class MutualMyConnectionDialogComponents
{
    constructor(private dialogRef: MatDialogRef<MutualMyConnectionDialogComponents>,
        @Inject(MAT_DIALOG_DATA) public data: any,) { 
        }
 
    onClickNo() {
        this.dialogRef.close()
    }
    close() {
     this.dialogRef.close()
   }
   getImage(imageName){
     if(imageName != null){
       return RestURL.contentServerUrl + (imageName);
     }else
     return "/assets/not-found/404.jpg"
   }
   smeNameClick(sUuid)
   {
     let url =  'sme/' + sUuid
     window.open(url,'_blank')
   }
}