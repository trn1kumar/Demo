import { Component, OnInit, Input } from '@angular/core';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { SME } from 'src/app/core/models/sme';
import { BusinessCircleService } from 'src/app/core/services/circle/business-circle.service';
import { RestURL } from 'src/app/core/models/rest-api-url';
import { ConnectionVo } from 'src/app/core/models/business-circle';
import { MatDialogConfig, MatSnackBar, MatDialogRef, MatDialog } from '@angular/material';
import { SnackBarConfig } from 'src/app/core/services/extra/snackbar.config';
import { DeleteDialogMain } from './Delete-dialog/delete-dialog.component';

@Component({
  selector: 'app-circle-right-side',
  templateUrl: './circle-right-side.component.html',
  styleUrls: ['./circle-right-side.component.css']
})
export class CircleRightSideComponent implements OnInit {
  sUuid:string
  receviedReq: SME[];
  pendingRequestNotFound: boolean = false
  deleteDialogRef: MatDialogRef<DeleteDialogMain>

  constructor(private jwtToken:JwtTokenService,private matDialog: MatDialog,private snackbarConfig: SnackBarConfig,private snackBar: MatSnackBar,private businessCircle: BusinessCircleService) { }

  ngOnInit() {
    this.sUuid = this.jwtToken.getSmeUuid();

    this.businessCircle.getAllReceviedRequest(this.sUuid).subscribe(res => {
      this.receviedReq = res;
      console.log(this.receviedReq,'rreq')
    },
      err => {
        this.pendingRequestNotFound = true;
        console.log(err)
      }
    );
  }
  onConfirmRequest(receiveRequestId, index) {

    let makeCon = new ConnectionVo();
    makeCon.sUuid = this.sUuid;
    makeCon.receiveReqUuid = receiveRequestId;
    // console.log(makeCon);
    this.businessCircle.makeConnection(makeCon).subscribe(res => {

      this.snackBar.open('Request Accepted', 'Ok', this.snackbarConfig.getSnackBarConfig());
      this.receviedReq.splice(index, 1)
    },
    );
  }

  onDeleteRequest(receiveRequestId: string, index) {
    let delCon = new ConnectionVo();
    delCon.sUuid = this.sUuid;
    delCon.receiveReqUuid = receiveRequestId;

    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';
    dialogConfig.data = delCon

    this.deleteDialogRef = this.matDialog.open(DeleteDialogMain, dialogConfig);
    this.deleteDialogRef.afterClosed().subscribe(
      res => {
        if (res == true) {
          this.receviedReq.splice(index, 1)
        }
      }
    )
  }
  getImage(imageName) {
    if (imageName != null) {
      return RestURL.contentServerUrl + (imageName);
    } else
      return "/assets/not-found/404.jpg"
  }
}
