import { Component, Inject } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from "@angular/material";
import { BusinessCircleService } from "src/app/core/services/circle/business-circle.service";
import { SnackBarConfig } from "src/app/core/services/extra/snackbar.config";

@Component({
    selector: 'app-circle-right-side-delete',
    templateUrl: './delete-dialog.component.html',
    styleUrls: ['./delete-dialog.component.css']
  })
export class DeleteDialogMain
{
  constructor(private dialogRef: MatDialogRef<DeleteDialogMain>,
    private businessCircle: BusinessCircleService,
   @Inject(MAT_DIALOG_DATA) public data: any, private snackBar: MatSnackBar,
   private snackBarConfig: SnackBarConfig) { }

onDelete() {
this.businessCircle.deniedConnection(this.data).subscribe(
       res => {
           this.snackBar.open('remove successfully', 'Ok', this.snackBarConfig.getSnackBarConfig())
           this.dialogRef.close(true)
       },
   )  
}
onClickNo() {
   this.dialogRef.close()
}
}