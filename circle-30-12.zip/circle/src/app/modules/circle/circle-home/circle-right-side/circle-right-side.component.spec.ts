import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CircleRightSideComponent } from './circle-right-side.component';

describe('CircleRightSideComponent', () => {
  let component: CircleRightSideComponent;
  let fixture: ComponentFixture<CircleRightSideComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CircleRightSideComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CircleRightSideComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
