import { Component, OnInit, Input } from "@angular/core";
import { MatDialogRef, MatDialog, MatSnackBar, MatDialogConfig } from "@angular/material";
import { MutualConnectionDialogComponents } from "src/app/modules/sme/sme-display/sme-display/sme-category-view/sme-circle-view/mutual-connection-dialoog.component";
import { BusinessCircleService } from "src/app/core/services/circle/business-circle.service";
import { Router } from "@angular/router";
import { SnackBarConfig } from "src/app/core/services/extra/snackbar.config";
import { RestURL } from "src/app/core/models/rest-api-url";
import { SMECircleDto, BusinessCircle, SendRequest } from "src/app/core/models/business-circle";
import { JwtTokenService } from "src/app/core/services/token/jwt-token.service";


@Component({
  selector: 'app-suggestion',
  templateUrl: './suggestion.component.html',
  styleUrls: ['./suggestion.component.css']
})
export class SuggestionComponent implements OnInit {

  @Input()
  suggestion : Array<any>;
  // @Input()
  // mutualConnection:boolean=false
  sUuid:string
  mutualConnectionView:MatDialogRef<MutualConnectionDialogComponents>

  constructor(private businessCircle:BusinessCircleService,private jwtToken:JwtTokenService,private matDialog : MatDialog,private router:Router,private snackbarConfig : SnackBarConfig,private snackBar: MatSnackBar) { }

  ngOnInit() {

  }
  getImage(imageName){
    if(imageName != null){
      return RestURL.contentServerUrl + (imageName);
    }else
    return "/assets/not-found/404.jpg"
  }
  onOpenDialog(mutualConnections:SMECircleDto[],smeName:string)
  {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.width = '400px';
    dialogConfig.data ={mutualConnections,smeName}
  
    this.mutualConnectionView = this.matDialog.open(MutualConnectionDialogComponents, dialogConfig);
    this.mutualConnectionView.afterClosed().subscribe(
      res => {
        if(res == true)
        {
         
        }
      }
    )
  }

  onaddConnection(platformSMEs,index)
  {
    let circle = new BusinessCircle()
    let sendRequest = new SendRequest()
    let sendReq=[];
    circle.sUuid = this.jwtToken.getSmeUuid()
    // console.log("platformSMEs",platformSMEs.smeId);
    // console.log("smeId",circle.sUuid);
    sendRequest.toSmeId=platformSMEs.sUuid;
    // console.log("sendRequestId",sendRequest.toSmeId);
    sendReq.push(sendRequest);
    circle.sendRequests=sendReq;
    // console.log(circle);
  
    this.businessCircle.addBusinessRequest(circle).subscribe(
      response=>
      {
        // console.log("response",response);
        this.snackBar.open('Invitation Sent to '  +platformSMEs.smeName,'Ok',this.snackbarConfig.getSnackBarConfig());
        this.suggestion.splice(index,1);
      },
    )
  }
  
  smeNameClick(sUuid)
  {
    let url =  'sme/' + sUuid
    window.open(url,'_blank')
  }
  close(platformSMEs,index)
  {
    this.suggestion.splice(index,1);
  }
}
