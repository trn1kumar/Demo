import { Component, Inject } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";
import { RestURL } from "src/app/core/models/rest-api-url";

@Component({
    selector: 'app-mutual-connection',
    templateUrl: './mutual-connection-component.html',
    styleUrls: ['./mutual-connection-dialog.component.css']
  })

export class MutualConnectionDialogComponents{
    constructor(private dialogRef: MatDialogRef<MutualConnectionDialogComponents>,
       @Inject(MAT_DIALOG_DATA) public data: any,) { 
        
       }

   onClickNo() {
       this.dialogRef.close()
   }
   close() {
    this.dialogRef.close()
  }
  getImage(imageName){
    if(imageName != null){
      return RestURL.contentServerUrl + (imageName);
    }else
    return "/assets/not-found/404.jpg"
  }
  smeNameClick(sUuid){
    let url =  'sme/' + sUuid
    window.open(url,'_blank')
  }
}