import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CircleHomeComponent } from './circle-home/circle-home.component';
import { MyConnectionComponent } from './circle-home/my-connection/my-connection.component';
import { PendingRequestComponent } from './circle-home/pending-request/pending-request.component';
import { SentRequestComponent } from './circle-home/sent-request/sent-request.component';
import { CircleComponent } from './circle.component';
import { UserTypeGuardService } from 'src/app/core/guards/user-type-guard.service';

const routes: Routes = [
  { path:'',component:CircleComponent ,
    children:[
      { path : '' , component:CircleHomeComponent,canActivate:[UserTypeGuardService]},
      { path : 'my-connections' , component:MyConnectionComponent},
      { path : 'pending-requests' , component:PendingRequestComponent},
      { path : 'sent-requests' , component:SentRequestComponent}
    ]
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CircleRoutingModule { }
