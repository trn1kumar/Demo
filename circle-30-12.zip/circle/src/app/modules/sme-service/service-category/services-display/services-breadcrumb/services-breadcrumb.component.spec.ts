import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServicesBreadcrumbComponent } from './services-breadcrumb.component';

describe('ServicesBreadcrumbComponent', () => {
  let component: ServicesBreadcrumbComponent;
  let fixture: ComponentFixture<ServicesBreadcrumbComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServicesBreadcrumbComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServicesBreadcrumbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
