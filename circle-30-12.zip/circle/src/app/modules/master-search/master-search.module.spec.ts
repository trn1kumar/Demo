import { MasterSearchModule } from './master-search.module';

describe('MasterSearchModule', () => {
  let masterSearchModule: MasterSearchModule;

  beforeEach(() => {
    masterSearchModule = new MasterSearchModule();
  });

  it('should create an instance', () => {
    expect(masterSearchModule).toBeTruthy();
  });
});
