import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductSearchComponent } from './product-search/product-search.component';
import { ServiceSearchComponent } from './service-search/service-search.component';

const routes: Routes = [
  {path: 'p', component:ProductSearchComponent},
  {path: 's', component:ServiceSearchComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MasterSearchRoutingModule { }
