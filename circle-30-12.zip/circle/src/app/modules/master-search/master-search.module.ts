import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MasterSearchRoutingModule } from './master-search-routing.module';
import { ProductSearchComponent } from './product-search/product-search.component';
import { ServiceSearchComponent } from './service-search/service-search.component';
import { ProductResultComponent } from './product-search/product-result/product-result.component';
import { SharedModule } from '../shared/shared.module';
import { LayoutModule } from 'src/app/layout/users/smeface/layout.module';
import { NguCarouselModule } from '@ngu/carousel';
import { ServiceResultComponent } from './service-search/service-result/service-result.component';

@NgModule({
  imports: [
    CommonModule,
    MasterSearchRoutingModule,
    SharedModule,
    LayoutModule,
    NguCarouselModule,
  ],
  declarations: [ProductSearchComponent, ServiceSearchComponent, ProductResultComponent, ServiceResultComponent]
})
export class MasterSearchModule { }
