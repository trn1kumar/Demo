import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { SearchService } from 'src/app/core/services/search/search.service';
import { TokenStorageService } from 'src/app/core/services/token/token-storage.service';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';

@Component({
  selector: 'app-product-search',
  templateUrl: './product-search.component.html',
  styleUrls: ['./product-search.component.css']
})
export class ProductSearchComponent implements OnInit {

  products:any
  subscription$ : Subscription


  constructor(private router:Router,private searchService:SearchService,private jwtToken:JwtTokenService,
    private token:TokenStorageService) { 
    this.subscription$ = router.events
    .pipe(filter(e => e instanceof NavigationEnd))
    .subscribe((e: NavigationEnd) => {
      this.getData(e.url)
    });}

  ngOnInit() {
  }

  getData(url){

    if(this.token.isLoggedIn()){
      this.searchService.getProductSearchResultForUSER(url,this.jwtToken.getUserId()).subscribe(res=>{
        this.products=res
        console.log(this.products)
      },err=>{
  
      })
    }else{
      this.searchService.getProductSearchResult(url).subscribe(res=>{
        this.products=res
        console.log(this.products)
      },err=>{
  
      })
    }
  }
}
