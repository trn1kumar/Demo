import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { SearchService } from 'src/app/core/services/search/search.service';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { TokenStorageService } from 'src/app/core/services/token/token-storage.service';


@Component({
  selector: 'app-service-search',
  templateUrl: './service-search.component.html',
  styleUrls: ['./service-search.component.css']
})
export class ServiceSearchComponent implements OnInit {
  subscription$ : Subscription

  services:any

  constructor(private router:Router,private searchService:SearchService,private jwtToken:JwtTokenService,
    private token:TokenStorageService) { 
    this.subscription$ = router.events
    .pipe(filter(e => e instanceof NavigationEnd))
    .subscribe((e: NavigationEnd) => {
      this.getData(e.url)
    });}

  ngOnInit() {
  }

  getData(url){
    
    if(this.token.isLoggedIn()){
      this.searchService.getServiceSearchResultForUSER(url,this.jwtToken.getUserId()).subscribe(res=>{
        this.services=res
      })
    }else{
      this.searchService.getServiceSearchResult(url).subscribe(res=>{
        this.services=res
      })
    }


  }

}
