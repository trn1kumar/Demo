import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-buy-now',
  templateUrl: './buy-now.component.html',
  styleUrls: ['./buy-now.component.css']
})
export class BuyNowComponent implements OnInit {

  constructor(private dialogRef: MatDialogRef<BuyNowComponent>) { }

  ngOnInit() {
  }
  close() {
    this.dialogRef.close()
}
}
