import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MatSnackBar } from '@angular/material';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { SnackBarConfig } from 'src/app/core/services/extra/snackbar.config';
import { TokenStorageService } from 'src/app/core/services/token/token-storage.service';
import { Router } from '@angular/router';
import { SignUpService } from 'src/app/core/services/auth/sign-up.service';
import { UserUpdate } from 'src/app/core/models/user';
import { LoginService } from 'src/app/core/services/auth/login.service';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';

@Component({
  selector: 'app-otp-verification-admin',
  templateUrl: './otp-verification-admin.component.html',
  styleUrls: ['./otp-verification-admin.component.css']
})
export class OtpVerificationAdminComponent implements OnInit {

    showUserEmail = false
    verifyOtpForm: FormGroup;
    count: number = 0;
    userUpdate:UserUpdate
    waitingMsg: string = "You can Resend OTP after 5 seconds";
  constructor(private dialogRef: MatDialogRef<OtpVerificationAdminComponent>,private formBuilder:FormBuilder,private snackBar: MatSnackBar,
    private signupService: SignUpService,private jwtToken:JwtTokenService,private router:Router,private loginService:LoginService,private token: TokenStorageService,private snackBarConfig : SnackBarConfig) { }

  ngOnInit() {

    let uuid=this.jwtToken.getUserId();

    this.loginService.getUserVo(uuid).subscribe(
      res=>
      {
        this.userUpdate=res;
      }
    )
    $('#waitingmsg').hide();
    
    this.verifyOtpForm = this.formBuilder.group({
      uuid: new FormControl(uuid),
      otp: new FormControl('', [Validators.required, Validators.pattern('[0-9]+')])
    })
  }
  close() {
    this.dialogRef.close()
    this.router.navigateByUrl('/')
}
resendOTP(){

  if(this.userUpdate.uuid != null){

    ++this.count

    if(this.count >= 5){
      $('#resendLink').hide().delay(5000).show(0)
      this.count = 0
      $('#waitingmsg').show().delay(5000).hide(0)
    }

    this.signupService.resendOTP(this.userUpdate.uuid).subscribe(
      res => {
        this.snackBar.open('OTP resend successfully !!','',this.snackBarConfig.getSnackBarConfig())
      }
   )
  }
}

verifyOTP(enteredOTP){

  if(this.verifyOtpForm.valid && this.userUpdate.uuid != null){

    this.signupService.verifyOTP(enteredOTP,null).subscribe(
      res => {
        this.snackBar.open('OTP verified successfully !!','',this.snackBarConfig.getSnackBarConfig())
        this.token.saveAdminToken(res.body.token)
        this.dialogRef.close()
        this.router.navigateByUrl('/sme/admin')
      },
      err => {
        this.snackBar.open("Please enter valid OTP","Ok",this.snackBarConfig.getSnackBarConfig())
        this.verifyOtpForm.controls['otp'].setErrors({
          'wrongOTP' : true
        })
      }
    )
  }
}
}
