import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtpVerificationAdminComponent } from './otp-verification-admin.component';

describe('OtpVerificationAdminComponent', () => {
  let component: OtpVerificationAdminComponent;
  let fixture: ComponentFixture<OtpVerificationAdminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtpVerificationAdminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtpVerificationAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
