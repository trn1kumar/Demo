import { Pipe, PipeTransform } from "@angular/core";

@Pipe({ name: 'searchResultPipe' })
export class SearchResultPipe implements PipeTransform {

    transform(value: string, ...args: any[]) {

        if(value != null && value.length > 16){
            return value.slice(0,30) + '...'
        }
        return value
    }

}