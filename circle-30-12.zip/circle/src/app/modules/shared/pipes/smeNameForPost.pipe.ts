import { Pipe, PipeTransform } from "@angular/core";

@Pipe({ name: 'smeNameForPostPipe' })
export class SMENameForPost implements PipeTransform {

    transform(value: string, ...args: any[]) {

        if(value != null && value.length >= 20){
            return value.slice(0,20) + '...'
        }
        return value
    }

}