import { Pipe, PipeTransform } from "@angular/core";

@Pipe({ name: 'filterCategoryName' })
export class FilterCategoryName implements PipeTransform {

    transform(value: string, ...args: any[]) {

        if(value != null && value.length >= 25){
            return value.slice(0,25) + '...'
        }
        return value
    }

}