import {Pipe, PipeTransform} from "@angular/core";

@Pipe({
    name: 'messageTime',
    pure: false
  })
export class MessageTimePipe implements PipeTransform {
    transform(value: Date, []): string {
      var result: string;
  
      // current time
      let now = new Date().getTime();
  
      // time since message was sent in seconds
      let delta = (now - value.getTime()) / 1000;
  
      // format string
      if (delta < 10) {
        result = 'jetzt';
      } else if (delta < 60) { // sent in last minute
        result = 'vor ' + Math.floor(delta) + ' Sekunden';
      } else if (delta < 3600) { // sent in last hour
        result = 'vor ' + Math.floor(delta / 60) + ' Minuten';
      } else if (delta < 86400) { // sent on last day
        result = 'vor ' + Math.floor(delta / 3600) + ' Stunden';
      } else { // sent more than one day ago
        result = 'vor ' + Math.floor(delta / 86400) + ' Tagen';
      }
  
      return result;
    }
  }