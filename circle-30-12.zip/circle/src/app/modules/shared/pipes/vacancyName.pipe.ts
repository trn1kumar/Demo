import { Pipe, PipeTransform } from "@angular/core";

@Pipe({ name: 'vacancySmeNamePipe' })
export class VacancyNamePipe implements PipeTransform {

    transform(value: string, ...args: any[]) {

        if(value != null && value.length >= 36){
            return value.slice(0,36) + '...'
        }
        return value
    }

}