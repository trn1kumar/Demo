import { Pipe, PipeTransform } from "@angular/core";

@Pipe({ name: 'IndianCurrency' })
export class IndianCurrencyPipe implements PipeTransform {

    transform(value: string, ...args: any[]) {

        if (value != null) {
            return Number(value).
            toLocaleString('en-IN', { style: 'currency', currency: 'INR' ,maximumFractionDigits:0,minimumFractionDigits:0 })
        }

    }

}