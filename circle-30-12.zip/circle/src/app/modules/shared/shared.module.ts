/* Modules */
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedRoutingModule } from './shared-routing.module';
import { MaterialModule } from './modules/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { ProductNamePipe } from './pipes/productname.pipe';
import { SMENamePipe } from './pipes/smename.pipe';
import { SMECircle1Pipe } from './pipes/smecircle1.pipe';
import { IndianCurrencyPipe } from './pipes/currency.pipe';
import { BusinessPoDescription } from './pipes/businessPodescription.pipe';
import { SmeTermsConditionComponent } from './components/sme-terms-condition/sme-terms-condition.component';
import { SMENameForPost } from './pipes/smeNameForPost.pipe';
import { SearchResultPipe } from './pipes/search-result.pipe';
import { ReadMore } from './pipes/read-more.pipe';
import { BuyNowComponent } from './components/buy-now/buy-now.component';
import { OtpVerificationAdminComponent } from './components/otp-verification-admin/otp-verification-admin.component';
import { MessageTimePipe } from './pipes/messageTime.pipe';
import { FilterCategoryName } from './pipes/filter-category.pipe';
import { VacancyNamePipe } from './pipes/vacancyName.pipe';



export const PIPES = [
  ProductNamePipe,
  SMENamePipe,
  SMECircle1Pipe,
  IndianCurrencyPipe,
  BusinessPoDescription,
  SMENameForPost,
  SearchResultPipe,
  ReadMore,
  MessageTimePipe,
  FilterCategoryName,
  VacancyNamePipe

];

@NgModule({
  imports: [
    CommonModule,
    SharedRoutingModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  exports: [
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    NotFoundComponent,
    PIPES,
    BuyNowComponent,
    OtpVerificationAdminComponent
  ],
  declarations: [
    NotFoundComponent,
    PIPES,
    SmeTermsConditionComponent,
    BuyNowComponent,
    OtpVerificationAdminComponent,
  ],
  entryComponents: [BuyNowComponent,OtpVerificationAdminComponent]
})
export class SharedModule { }
