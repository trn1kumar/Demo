import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SmeTermsConditionComponent } from './components/sme-terms-condition/sme-terms-condition.component';
import { OtpVerificationAdminComponent } from './components/otp-verification-admin/otp-verification-admin.component';

const routes: Routes = [
  {path:'SmeTermsCondition',component:SmeTermsConditionComponent},
  {path:'otp-verify-admin',component:OtpVerificationAdminComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SharedRoutingModule { }
