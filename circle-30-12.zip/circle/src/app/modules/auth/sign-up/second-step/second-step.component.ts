import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ErrorStateMatcher, MatSnackBar, MatDialog, MatDialogRef, MatDialogConfig } from '@angular/material';
import { FormGroupDirective, NgForm, FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as $ from 'jquery';
import { TokenStorageService } from 'src/app/core/services/token/token-storage.service';
import { SignUpService } from 'src/app/core/services/auth/sign-up.service';
import { SnackBarConfig } from 'src/app/core/services/extra/snackbar.config';
import { JwtTokenService } from 'src/app/core/services/token/jwt-token.service';
import { SmeInfoService } from 'src/app/core/services/sme-page/sme-info.service';

export class StateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || isSubmitted));
  }
}
@Component({
  selector: 'app-second-step',
  templateUrl: './second-step.component.html',
  styleUrls: ['./second-step.component.css']
})
export class SecondStepComponent implements OnInit {

  constructor(private snackBar: MatSnackBar,private dialogRef : MatDialogRef<SecondStepComponent> ,
    private token: TokenStorageService, private formBuilder: FormBuilder,
    private matDialog: MatDialog, private signupService: SignUpService,
    private snackBarConfig : SnackBarConfig , private jwtToken : JwtTokenService ,
    private smeInfoService : SmeInfoService ) { }

  @ViewChild('idotp')
  field: ElementRef
  verifyOtpForm: FormGroup;
  otpMatcher = new StateMatcher();
  mobileMatcher = new StateMatcher();
  count: number = 0;
  waitingMsg: string = "You can Resend OTP after 5 seconds";
 
  showUserEmail = false
  displayUserEmail = this.userEmail()
  displayUserMobile = this.userMobile()

  ngOnInit() {
    this.field.nativeElement.focus()

    $('#waitingmsg').hide();

    this.verifyOtpForm = this.formBuilder.group({
      uuid: new FormControl(atob(sessionStorage.getItem('uuid'))),
      otp: new FormControl('', [Validators.required, Validators.pattern('[0-9]+')])
    })
  }

  verifyOTP(enteredOTP){

    if(this.verifyOtpForm.valid && sessionStorage.getItem('uuid') != null){

      this.signupService.verifyOTP(enteredOTP,null).subscribe(
        res => {
          this.snackBar.open('OTP verified successfully !!','',this.snackBarConfig.getSnackBarConfig())
          this.token.saveToken(res.body.token)
          this.dialogRef.close()
          sessionStorage.clear()
          window.location.reload()
        },
        err => {
          this.snackBar.open("Please enter valid OTP","Ok",this.snackBarConfig.getSnackBarConfig())
          this.verifyOtpForm.controls['otp'].setErrors({
            'wrongOTP' : true
          })
        }
      )
    }
  }


  resendOTP(){

    if(sessionStorage.getItem('uuid') != null){

      ++this.count

      if(this.count >= 5){
        $('#resendLink').hide().delay(5000).show(0)
        this.count = 0
        $('#waitingmsg').show().delay(5000).hide(0)
      }

      this.signupService.resendOTP(atob(sessionStorage.getItem('uuid'))).subscribe(
        res => {
          this.snackBar.open('OTP resend successfully !!','',this.snackBarConfig.getSnackBarConfig())
        }
     )
    }
  }
  close(){
    this.dialogRef.close()
    sessionStorage.clear()
  }

  userMobile(){
    if(sessionStorage.getItem('m') != null){
      return atob(sessionStorage.getItem('m'))
    }
  }

  userEmail(){
    if(sessionStorage.getItem('e') != null){
      this.showUserEmail = true
      return atob(sessionStorage.getItem('e'))
    }
  }
}
