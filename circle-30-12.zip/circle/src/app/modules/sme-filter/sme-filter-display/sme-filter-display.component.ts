import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { SmeInfoService } from 'src/app/core/services/sme-page/sme-info.service';
import { SMECategoryDto } from 'src/app/core/models/sme-information';
import { SMEFilterResponse } from 'src/app/core/models/sme-filter-response';

@Component({
  selector: 'app-sme-filter-display',
  templateUrl: './sme-filter-display.component.html',
  styleUrls: ['./sme-filter-display.component.css']
})
export class SmeFilterDisplayComponent implements OnInit {

  smeFilterAndResult:SMEFilterResponse;
  httpReqestInProgress:boolean=true;
  subscription$ : Subscription

  constructor(private router:Router,private smeService:SmeInfoService) { 
    this.subscription$ = router.events
    .pipe(filter(e => e instanceof NavigationEnd))
    .subscribe((e: NavigationEnd) => {
      this.getData(e.url);
    });
  }

  ngOnInit() {
    
  }

  getData(url){
    this.smeService.smes(url).subscribe(res=>{
      this.smeFilterAndResult=res
      this.httpReqestInProgress=false
    },err=>{
      this.httpReqestInProgress=false
      console.log(err)
    })
  }

}
