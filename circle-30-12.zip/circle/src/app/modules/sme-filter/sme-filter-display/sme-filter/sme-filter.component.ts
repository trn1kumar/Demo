import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { SMEFilterDto, CategoryFilter, FilterByCity } from 'src/app/core/models/sme-filter-response';
import { Params, ActivatedRoute, Router } from '@angular/router';
import { FormControl } from '@angular/forms';


@Component({
  selector: 'app-sme-filter',
  templateUrl: './sme-filter.component.html',
  styleUrls: ['./sme-filter.component.css']
})
export class SmeFilterComponent implements OnInit ,OnChanges{


  @Input()
  smeFilter:SMEFilterDto;

  //for store filter param
  filterByCities=new Set<String>();
  filterByCategories=new Set<String>();

  //for display filter
  categoryFilter:Array<CategoryFilter>;
  cityFilter:Array<FilterByCity>;

  //for display selected filter in matchip
  categorySelectedFilter:Array<CategoryFilter>;
  citySelectedFilter:Array<FilterByCity>;
  

  //for filter param
  cityParam:String;
  categoryParam:String;

  //for search in filter
  searchCategory=new FormControl();
  searchCity=new FormControl();

  //for matchip
  selectable = true;
  removable = true;
  
  //for clear all button
  resetButton: boolean = false
  
  constructor(private router:Router,private route: ActivatedRoute) { 
    
  }
  ngOnChanges(){

    this.categoryFilter=this.smeFilter.filters['Category'];
    this.cityFilter=this.smeFilter.filters['City'];

    this.categorySelectedFilter =new Array<CategoryFilter>();
    this.categoryFilter.filter(category=>category.selected).forEach(category=>
    this.categorySelectedFilter.push(category));
      

    this.citySelectedFilter =new Array<FilterByCity>();
    this.cityFilter.filter(city=>city.selected).forEach(city=>
    this.citySelectedFilter.push(city));
    
  }

  ngOnInit() {
 
    this.route.queryParams.subscribe(params => {
      this.categoryParam = params['categoriesFilterParam'];
      if (this.categoryParam != null && this.categoryParam != undefined && this.categoryParam.length > 0) {
        if(params['categoriesFilterParam'] instanceof Array){
          this.resetButton=true
          params['categoriesFilterParam'].forEach(categoryParam=>this.filterByCategories.add(categoryParam));
        }else{
          //this part is for store param in set coming from home category menu
          if(!this.filterByCategories.has(this.categoryParam)){
            this.resetButton=true
              this.filterByCategories.add(this.categoryParam);
          }
        }
      }
      

      this.cityParam = params['citiesFilterParam'];
      if (this.cityParam != null && this.cityParam != undefined && this.cityParam.length > 0) {
          if(params['citiesFilterParam'] instanceof Array){
            this.resetButton=true
            params['citiesFilterParam'].forEach(city=>this.filterByCities.add(city));
          }else{
            //this part is for store param in set coming from home category menu
            if(!this.filterByCities.has(this.cityParam)){
              this.resetButton=true
                this.filterByCities.add(this.cityParam);
            }
          }
      }
    })

    this.searchCategory.valueChanges.subscribe(
      value => {
          this.categoryFilter = this.getSearchCategory(value.toLowerCase())
      }
    )
    this.searchCity.valueChanges.subscribe(
      value => {
          this.cityFilter = this.getSearchCity(value.toLowerCase())
      }
    )
  }

  buildMap(obj) :Map<string,any>{
    let map = new Map<string,any>();
    Object.keys(obj).forEach(key => {
        map.set(key, obj[key]);
    });
    return map;
}

  getSearchCategory(value:string):Array<CategoryFilter>{
    const filters=this.buildMap(this.smeFilter.filters);
    return filters.get('Category').filter(category=>category.categoryName.toLowerCase().includes(value));;
  }
  getSearchCity(value:string):Array<FilterByCity>{
    const filters=this.buildMap(this.smeFilter.filters);
    return filters.get('City').filter(city=>city.city.toLowerCase().includes(value));
  }

 

  remove(categoryFilter: CategoryFilter,cityFilter:FilterByCity): void {
    if(categoryFilter!=undefined){
      this.onClicklCategoryFilter(categoryFilter.categoryUrl)
    }
    if(cityFilter!=undefined){
      this.onClickCityFilter(cityFilter.city)
    }
    this.onSubmit();
  }

 

  onClicklCategoryFilter(categoryUrl:string){
    if(this.filterByCategories.has(categoryUrl)){
      this.filterByCategories.delete(categoryUrl)
    }else{
      this.filterByCategories.add(categoryUrl)
    }
  }

  onClickCityFilter(city:string){
   
    if(this.filterByCities.has(city)){
      this.filterByCities.delete(city)
    }else{
      this.filterByCities.add(city)
    }
  }

  onSubmit(){  
    this.resetButton=true
    this.router.navigate([], { queryParams:{ categoriesFilterParam: Array.from(this.filterByCategories),citiesFilterParam: Array.from(this.filterByCities)}});
  }
  onReset(){  
    this.resetButton=false
    this.filterByCities.clear();
    this.filterByCategories.clear();
    this.router.navigate([],{});
  }
}
