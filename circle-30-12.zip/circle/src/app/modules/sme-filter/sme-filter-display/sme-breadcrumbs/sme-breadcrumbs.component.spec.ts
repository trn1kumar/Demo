import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SmeBreadcrumbsComponent } from './sme-breadcrumbs.component';

describe('SmeBreadcrumbsComponent', () => {
  let component: SmeBreadcrumbsComponent;
  let fixture: ComponentFixture<SmeBreadcrumbsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SmeBreadcrumbsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SmeBreadcrumbsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
