import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-sme-breadcrumbs',
  templateUrl: './sme-breadcrumbs.component.html',
  styleUrls: ['./sme-breadcrumbs.component.css']
})
export class SmeBreadcrumbsComponent implements OnInit {

  @Input()
  breadcrumbs:any

  constructor() { }

  ngOnInit() {
  }

}
