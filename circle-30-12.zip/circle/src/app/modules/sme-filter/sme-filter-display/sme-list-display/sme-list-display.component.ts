import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { SMECategoryDto } from 'src/app/core/models/sme-information';
import { RestURL } from 'src/app/core/models/rest-api-url';
import { SMEInformationDto } from 'src/app/core/models/sme-filter-response';
import { SmeFilterComponent } from '../sme-filter/sme-filter.component';
import { SmeInfoService } from 'src/app/core/services/sme-page/sme-info.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  providers:[SmeFilterComponent],
  selector: 'app-sme-list-display',
  templateUrl: './sme-list-display.component.html',
  styleUrls: ['./sme-list-display.component.css']
})
export class SmeListDisplayComponent implements OnInit ,OnChanges{
  ngOnChanges(): void {
    
  }

  @Input()
  smes:Array<SMEInformationDto>;
  @Input()
  smesCount:number;

  filterByCities=new Set<String>();
  filterByCategories=new Set<String>();

  cityParam:String;
  categoryParam:String;

  pagedSmes:Array<SMEInformationDto>;
  firstPageResult:number=41;
  page = 2;
  throttle = 300;
  scrollDistance = 1;
  scrollUpDistance = 2;

  constructor(private route: ActivatedRoute,private filterComponent: SmeFilterComponent,private smeService:SmeInfoService) {
    
   }

  ngOnInit() {
   
    this.route.queryParams.subscribe(params => {
      this.categoryParam = params['categoriesFilterParam'];
      if (this.categoryParam != null && this.categoryParam != undefined && this.categoryParam.length > 0) {
        if(params['categoriesFilterParam'] instanceof Array){
          this.filterByCategories.add(params['categoriesFilterParam']);
    
        }else{
          //this part is for store param in set coming from home category menu
          if(!this.filterByCategories.has(this.categoryParam)){
              this.filterByCategories.add(this.categoryParam);
          }
        }
      }


      this.cityParam = params['citiesFilterParam'];
      if (this.cityParam != null && this.cityParam != undefined && this.cityParam.length > 0) {
          if(params['citiesFilterParam'] instanceof Array){
            this.filterByCities.add(params['citiesFilterParam']);
          }else{
            //this part is for store param in set coming from home category menu
            if(!this.filterByCities.has(this.cityParam)){
                this.filterByCities.add(this.cityParam);
            }
          }
      }
    })
  }
  getImage(imageName) {
    if (imageName != null) {
      return RestURL.contentServerUrl + (imageName);
    } else
      return "/assets/not-found/not-available.jpeg"
  }

  smeNameClick(sUuid) {
    let url = 'sme/' + sUuid
    window.open(url, '_blank')
  }

  onScrollDown () {

    this.smeService.smesWithPagination(Array.from(this.filterByCategories),Array.from(this.filterByCities),this.page++,this.firstPageResult).subscribe(res=>{

      this.pagedSmes=res;
      this.smesCount=this.smesCount+res.totalCount;
      this.firstPageResult=this.firstPageResult+this.firstPageResult;
      this.smes.push(...res.result)
    },err=>{
    })
  
  }

  onReset(){
    this.filterComponent.onReset();
  }
}
