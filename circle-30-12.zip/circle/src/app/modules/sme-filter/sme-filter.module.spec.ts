import { SmeFilterModule } from './sme-filter.module';

describe('SmeFilterModule', () => {
  let smeFilterModule: SmeFilterModule;

  beforeEach(() => {
    smeFilterModule = new SmeFilterModule();
  });

  it('should create an instance', () => {
    expect(smeFilterModule).toBeTruthy();
  });
});
