import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SmeFilterRoutingModule } from './sme-filter-routing.module';
import { SmeFilterDisplayComponent } from './sme-filter-display/sme-filter-display.component';
import { SmeListDisplayComponent } from './sme-filter-display/sme-list-display/sme-list-display.component';
import { SmeFilterComponent } from './sme-filter-display/sme-filter/sme-filter.component';
import { LayoutModule } from 'src/app/layout/users/smeface/layout.module';
import { SharedModule } from '../shared/shared.module';
import { NguCarouselModule } from '@ngu/carousel';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { SmeBreadcrumbsComponent } from './sme-filter-display/sme-breadcrumbs/sme-breadcrumbs.component';

@NgModule({
  imports: [
    CommonModule,
    SmeFilterRoutingModule,
    SharedModule,
    LayoutModule,
    NguCarouselModule,
    InfiniteScrollModule,
    
  ],
  declarations: [
    SmeFilterDisplayComponent, 
    SmeListDisplayComponent, 
    SmeFilterComponent,
    SmeBreadcrumbsComponent,
  ]
})
export class SmeFilterModule { }
