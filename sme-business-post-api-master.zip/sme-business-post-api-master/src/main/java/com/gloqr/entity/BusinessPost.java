package com.gloqr.entity;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import com.gloqr.audit.DateAuditable;
import com.gloqr.constants.BusinessPostState;
import com.gloqr.constants.PostType;
import com.gloqr.constants.Privacy;

@Document(collection = "sme_posts")
public class BusinessPost extends DateAuditable {

	@Id
	private String businessPostId;

	@Indexed
	private String smeUuid;

	private String title;

	private String description;

	private Privacy privacy;
	
	private boolean active ;

	private PostType postType ;

	@Indexed
	private String publishFeedId;

	private BusinessPostState postState;

	private String feedbackMessage;

	private boolean postModified;

	@DBRef
	private List<File> files;

	private int likesCount;

	private Map<String,String> likes;

	private Set<String> tags;

	public String getBusinessPostId() {
		return businessPostId;
	}

	public void setBusinessPostId(String businessPostId) {
		this.businessPostId = businessPostId;
	}

	public String getSmeUuid() {
		return smeUuid;
	}

	public void setSmeUuid(String smeUuid) {
		this.smeUuid = smeUuid;
	}

	public String getFeedbackMessage() {
		return feedbackMessage;
	}

	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}


	public Set<String> getTags() {
		return tags;
	}

	public void setTags(Set<String> tags) {
		this.tags = tags;
	}


	public List<File> getFiles() {
		return files;
	}

	public void setFiles(List<File> files) {
		this.files = files;
	}

	public String getPublishFeedId() {
		return publishFeedId;
	}

	public void setPublishFeedId(String publishFeedId) {
		this.publishFeedId = publishFeedId;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}


	public Privacy getPrivacy() {
		return privacy;
	}

	public void setPrivacy(Privacy privacy) {
		this.privacy = privacy;
	}

	public PostType getPostType() {
		return postType;
	}

	public void setPostType(PostType postType) {
		this.postType = postType;
	}

	public BusinessPostState getPostState() {
		return postState;
	}

	public void setPostState(BusinessPostState postState) {
		this.postState = postState;
	}

	public boolean isPostModified() {
		return postModified;
	}

	public void setPostModified(boolean postModified) {
		this.postModified = postModified;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((businessPostId == null) ? 0 : businessPostId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		BusinessPost other = (BusinessPost) obj;
		if (businessPostId == null) {
			if (other.businessPostId != null)
				return false;
		} else if (!businessPostId.equals(other.businessPostId)) {
			return false;
		}
			
		return true;
	}

	public Map<String,String> getLikes() {
		return likes;
	}

	public void setLikes(Map<String,String> likes) {
		this.likes = likes;
	}

	public int getLikesCount() {
		return likesCount;
	}

	public void setLikesCount(int likesCount) {
		this.likesCount = likesCount;
	}
	
	

}
