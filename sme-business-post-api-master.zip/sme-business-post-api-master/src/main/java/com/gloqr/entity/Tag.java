package com.gloqr.entity;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "tags")
public class Tag {

	@Id
	private String smeUuid;

	private List<String> taggedPosts;

	public Tag() {
		super();
	}

	public Tag(String smeUuid) {
		super();
		this.smeUuid = smeUuid;
	}

	public Tag(String smeUuid, List<String> taggedPosts) {
		super();
		this.smeUuid = smeUuid;
		this.taggedPosts = taggedPosts;
	}

	public String getSmeUuid() {
		return smeUuid;
	}

	public void setSmeUuid(String smeUuid) {
		this.smeUuid = smeUuid;
	}

	public List<String> getTaggedPosts() {
		return taggedPosts;
	}

	public void setTaggedPosts(List<String> taggedPosts) {
		this.taggedPosts = taggedPosts;
	}

}
