package com.gloqr.dao;

import java.util.List;

import com.gloqr.entity.Tag;

public interface TagDao {

	void saveTag(Tag tag);

	Tag getTag(String tagId);

	void deleteTag(Tag tag);

	List<String> getTaggedPosts(String tagId);

}
