package com.gloqr.dao;

import java.util.List;

import com.gloqr.constants.BusinessPostState;
import com.gloqr.entity.BusinessPost;
import com.gloqr.model.ItemCountUpdate;
import com.gloqr.model.PublishData;

public interface BusinessPostDao {

	void save(BusinessPost businessPost);

	void savePosts(List<BusinessPost> posts);

	BusinessPost getPostById(String postId);

	List<BusinessPost> getApprovedAndActivePosts(String smeUuid, BusinessPostState postState);

	List<BusinessPost> getPendingOrRejectedPosts(String smeUuid);

	void delete(BusinessPost post);

	void updatePostsStatus(List<PublishData> publish);

	ItemCountUpdate getCounts(String smeUuid);

	List<BusinessPost> getTimelinePosts(String smeUuid, List<String> taggedPosts, int page, int size);

	List<BusinessPost> getTimelinePosts(String smeUuid, List<String> taggedPostIds, String postViewerSmeUuid, int page,
			int size);

	List<BusinessPost> getTimelinePosts(String smeUuid, int page, int size);

}
