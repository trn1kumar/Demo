package com.gloqr.dao;

import java.util.List;
import java.util.Set;

import com.gloqr.entity.File;

public interface FileDao {

	void saveFiles(List<File> files);

	List<File> getFilesByLocations(Set<String> fileLocations);

	void deactiveFiles(List<File> files);

	void deleteFiles(List<File> deletedFiles);

	void deleteByFileLocation(String fileLocation);

}
