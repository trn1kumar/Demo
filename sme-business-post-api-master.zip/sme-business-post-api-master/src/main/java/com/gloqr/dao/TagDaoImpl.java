package com.gloqr.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.entity.Tag;
import com.gloqr.exception.CustomException;
import com.gloqr.repository.TagRepository;

@Service
public class TagDaoImpl implements TagDao {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private TagRepository tagRepo;

	@Override
	public void saveTag(Tag tag) {
		try {
			tagRepo.save(tag);
		} catch (Exception e) {
			throw new CustomException("Error while saving tag. " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

	}

	@Override
	public Tag getTag(String tagId) {
		Optional<Tag> tagOpt = tagRepo.findById(tagId);
		if (tagOpt.isPresent()) {
			return tagOpt.get();
		} else {
			throw new CustomException("Tag not present with id:: " + tagId, HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public void deleteTag(Tag tag) {
		try {
			tagRepo.delete(tag);
		} catch (Exception e) {
			throw new CustomException("Exception while deleting tag by id:: " + tag.getSmeUuid(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

	}

	@Override
	public List<String> getTaggedPosts(String tagId) {
		Tag tag = null;
		List<String> taggedPostIds = new ArrayList<>();
		try {
			tag = getTag(tagId);
		} catch (Exception e) {
			log.error("Exception.. Message:- {}", e.getMessage());
		}
		if (tag != null)
			taggedPostIds.addAll(tag.getTaggedPosts());

		return taggedPostIds;
	}

}
