package com.gloqr.dao;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.constants.BusinessPostState;
import com.gloqr.constants.Privacy;
import com.gloqr.entity.BusinessPost;
import com.gloqr.exception.CustomException;
import com.gloqr.model.ItemCountUpdate;
import com.gloqr.model.PublishData;
import com.gloqr.repository.SMEBusinessPostRepository;

@Repository
public class BusinessPostDaoImpl implements BusinessPostDao {

	@Autowired
	private SMEBusinessPostRepository businessPostRepo;

	@Override
	public void save(BusinessPost businessPost) {
		try {
			businessPostRepo.save(businessPost);
		} catch (Exception e) {
			throw new CustomException("Exception while saving post. Message:: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

	}

	@Override
	public void savePosts(List<BusinessPost> posts) {
		try {
			businessPostRepo.saveAll(posts);
		} catch (Exception e) {
			throw new CustomException("Exception in :: savePosts(),  message:  " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@Override
	public void delete(BusinessPost post) {
		try {
			businessPostRepo.delete(post);
		} catch (Exception e) {
			throw new CustomException("Failed to delete Business-Post by ID: " + post.getBusinessPostId(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
	}

	@Override
	public void updatePostsStatus(List<PublishData> publish) {
		businessPostRepo.updatePostStatus(publish);
	}

	@Override
	public BusinessPost getPostById(String postId) {
		Optional<BusinessPost> postOpt = businessPostRepo.findById(postId);
		if (!postOpt.isPresent())
			throw new CustomException("Post not present with id " + postId, HttpStatus.NOT_FOUND);
		return postOpt.get();
	}

	@Override
	public List<BusinessPost> getTimelinePosts(String smeUuid, List<String> taggedPostIds, int page, int size) {
		return businessPostRepo.getTimelinePosts(smeUuid, taggedPostIds, null, page, size);
	}

	@Override
	public List<BusinessPost> getTimelinePosts(String smeUuid, List<String> taggedPostIds, String postViewerSmeUuid,
			int page, int size) {
		return businessPostRepo.getTimelinePosts(smeUuid, taggedPostIds, postViewerSmeUuid, page, size);
	}

	@Override
	public List<BusinessPost> getTimelinePosts(String smeUuid, int page, int size) {

		if (page <= 0)
			page = 1;

		List<BusinessPost> publicPosts = businessPostRepo.findBySmeUuidAndPostStateAndPrivacyAndActiveTrue(smeUuid,
				BusinessPostState.APPROVED, Privacy.PUBLIC,
				PageRequest.of(--page, size, new Sort(Sort.Direction.DESC, "creationDate")));

		if (publicPosts != null && !publicPosts.isEmpty())
			return publicPosts;
		else
			throw new CustomException("Posts Not Available for SME :: " + smeUuid, HttpStatus.NOT_FOUND);
	}

	@Override
	public List<BusinessPost> getApprovedAndActivePosts(String smeUuid, BusinessPostState postState) {
		List<BusinessPost> posts = null;
		posts = businessPostRepo.findBySmeUuidAndPostStateAndActiveTrue(smeUuid, postState);
		if (posts != null && !posts.isEmpty()) {
			return posts;
		} else {
			throw new CustomException("No posts found for sme  " + smeUuid, HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public List<BusinessPost> getPendingOrRejectedPosts(String smeUuid) {

		List<BusinessPost> posts = businessPostRepo.findBySmeUuidAndPostStateNotIn(smeUuid, BusinessPostState.APPROVED);

		if (posts != null && !posts.isEmpty())
			return posts;
		else
			throw new CustomException("Post Not available for sme  " + smeUuid, HttpStatus.NOT_FOUND);

	}

	@Override
	public ItemCountUpdate getCounts(String smeUuid) {
		int totalCount = businessPostRepo.countBySmeUuid(smeUuid);
		int activeApprovedCount = businessPostRepo.countBySmeUuidAndPostStateAndActive(smeUuid,
				BusinessPostState.APPROVED, true);
		int activePendingCount = businessPostRepo.countBySmeUuidAndPostStateAndActive(smeUuid,
				BusinessPostState.PENDING, true);
		return new ItemCountUpdate(totalCount, activeApprovedCount, activePendingCount);
	}

}
