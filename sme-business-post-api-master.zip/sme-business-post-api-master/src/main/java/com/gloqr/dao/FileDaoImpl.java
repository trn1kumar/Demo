package com.gloqr.dao;

import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.entity.File;
import com.gloqr.exception.CustomException;
import com.gloqr.repository.FileRepository;

@Repository
public class FileDaoImpl implements FileDao {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private FileRepository fileRepo;

	@Override
	public void saveFiles(List<File> files) {
		try {
			fileRepo.saveAll(files);
		} catch (Exception e) {
			throw new CustomException("Exception in saveMultipleFiles( ) { }. message: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public List<File> getFilesByLocations(Set<String> fileLocations) {

		List<File> files = fileRepo.findByFileLocationIn(fileLocations);

		if (files != null && !files.isEmpty()) {
			return files;
		} else {
			throw new CustomException("No files available ", HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public void deactiveFiles(List<File> files) {

		if (files == null)
			throw new CustomException("files obj can not be null for deactivate", HttpStatus.BAD_REQUEST);

		files.forEach(file -> file.setActive(false));
		saveFiles(files);

	}

	@Override
	public void deleteFiles(List<File> deletedFiles) {
		try {
			fileRepo.deleteAll(deletedFiles);
		} catch (Exception e) {
			log.error("Exception::deleteFiles()", e);
		}

	}

	@Override
	public void deleteByFileLocation(String fileLocation) {
		try {
			fileRepo.deleteByFileLocation(fileLocation);
		} catch (Exception e) {
			log.error("Exception::deleteFiles()", e);
		}

	}

}
