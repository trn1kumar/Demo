package com.gloqr.service;

public interface CountManageService {

	void updatePostsCount(String smeUuid, String jwtTokenString);

}
