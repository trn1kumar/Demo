package com.gloqr.service;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.gloqr.configuration.PropertyValues;
import com.gloqr.constants.BusinessPostState;
import com.gloqr.dto.SMEDto;
import com.gloqr.entity.BusinessPost;
import com.gloqr.exception.CustomException;
import com.gloqr.model.notification.EmailEvent;
import com.gloqr.model.notification.SmsEvent;
import com.gloqr.rest.endpoint.NotificationEndPoint;

@Service
@Async("taskExecutor")
public class NotificationServiceImpl implements NotificationService {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private SMEService smeService;

	@Autowired
	private NotificationEndPoint notificationEndpoint;

	@Autowired
	private TemplateEngine templateEngine;

	@Autowired
	private PropertyValues propertyValues;

	private void sendNotifications(SmsEvent smsEvent, EmailEvent emailEvent) {

		List<Object> events = new ArrayList<>();

		if (smsEvent != null)
			events.add(smsEvent);
		if (emailEvent != null)
			events.add(emailEvent);

		try {
			events.parallelStream().forEach(e -> notificationEndpoint.sendNotification(e));
		} catch (Exception e) {
			log.error("failed to send notifications.Exception:- " + e.getMessage());
		}
	}

	@Override
	public void sendPostsVerificationSummaryNotifi(String smeId, List<BusinessPost> saveForBatchUpdate) {
		try {
			SMEDto smeDto = smeService.getSME(smeId);
			String emailId = smeDto.getContactEmail();
			if (emailId != null) {
				
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd 'at' hh:mm:ss a");
				Date date = new Date();
				
				
				List<BusinessPost> approvedPosts =new ArrayList<>();
				List<BusinessPost> rejectedPosts =new ArrayList<>();
				
				saveForBatchUpdate.parallelStream().forEach(biPost ->{
					if(biPost.getPostState().equals(BusinessPostState.APPROVED))
						approvedPosts.add(biPost);
					else if(biPost.getPostState().equals(BusinessPostState.REJECTED))
						rejectedPosts.add(biPost);
				});
					
				
				
				Context context = new Context();
				context.setVariable("smeName", smeDto.getSmeName());
				context.setVariable("approvedPosts", approvedPosts);
				context.setVariable("rejectedPosts", rejectedPosts);
				context.setVariable("totalApproved",approvedPosts.size());
				context.setVariable("totalRejected",rejectedPosts.size());
				context.setVariable("approvedDateTime", formatter.format(date));
				context.setVariable("homeUrl", propertyValues.getBaseUrl());
				context.setVariable("contentServerUrl", propertyValues.getContentServerUrl());
				
				
				String mailPage = templateEngine.process("postVerifications.html", context);
				String mailSub = propertyValues.getVerifyPostsEmailSub();
				EmailEvent emailEvent = new EmailEvent(emailId, mailSub, mailPage);
				sendNotifications(null, emailEvent);
			} else {
				throw new CustomException("email id can't be null for schedule notification.",
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error("can't send notification. Exception:- {}", e.getMessage());
		}
	}

}
