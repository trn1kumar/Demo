package com.gloqr.service;

import java.util.List;

import com.gloqr.entity.BusinessPost;

public interface NotificationService {

	void sendPostsVerificationSummaryNotifi(String smeId, List<BusinessPost> saveForBatchUpdate);

}
