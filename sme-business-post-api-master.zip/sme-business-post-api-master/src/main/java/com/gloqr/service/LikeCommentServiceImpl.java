package com.gloqr.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.dao.BusinessPostDao;
import com.gloqr.entity.BusinessPost;

@Service
public class LikeCommentServiceImpl implements LikeCommentService {

	@Autowired
	private BusinessPostDao businessPostDao;

	@Override
	public void likePost(String postId, String likedById, String userType) {
		BusinessPost post = businessPostDao.getPostById(postId);
		Map<String, String> likes = post.getLikes();
		if (likes == null) {
			likes = new HashMap<>();
			post.setLikes(likes);
		}

		likes.put(likedById, userType);
		post.setLikesCount(likes.size());
		businessPostDao.save(post);
	}

}
