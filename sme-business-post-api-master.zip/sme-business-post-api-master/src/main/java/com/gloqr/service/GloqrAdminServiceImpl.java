package com.gloqr.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.constants.BusinessPostConstants.PostStatus;
import com.gloqr.constants.BusinessPostState;
import com.gloqr.constants.CreditType;
import com.gloqr.dao.BusinessPostDao;
import com.gloqr.dao.FileDao;
import com.gloqr.entity.BusinessPost;
import com.gloqr.entity.File;
import com.gloqr.exception.CustomException;
import com.gloqr.model.PostStateChange;
import com.gloqr.model.PricingRequest;
import com.gloqr.model.PublishData;
import com.gloqr.repository.SMEBusinessPostRepository;
import com.gloqr.rest.endpoint.PricingEndpoint;

@Service
public class GloqrAdminServiceImpl implements GloqrAdminService {

	public static final String DATE_FORMAT = "E, dd MMM yyyy HH:mm:ss";

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private SMEBusinessPostRepository businessPostRepo;

	@Autowired
	private BusinessPostService businessPostService;

	@Autowired
	private BusinessPostDao businessPostDao;

	@Autowired
	private PricingEndpoint pricingEnpoint;

	@Autowired
	private FileDao fileDao;

	@Override
	public Map<String, Integer> getSMEPostsCount(List<String> smeIds) {
		Map<String, Integer> counts = new HashMap<>();

		smeIds.forEach(smeid -> {
			int count = businessPostRepo.countBySmeUuidAndPostStateAndActive(smeid, BusinessPostState.PENDING, true);
			counts.put(smeid, count);
		});
		return counts;

	}

	public List<BusinessPost> getPosts(String smeUuid) {

		List<BusinessPost> posts = businessPostDao.getApprovedAndActivePosts(smeUuid, BusinessPostState.PENDING);
		if (posts != null && !posts.isEmpty()) {
			return posts;
		} else {
			throw new CustomException("No Posts Available for sme:- " + smeUuid, HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public List<BusinessPost> approveOrRejectBusinessPostsState(PostStateChange posts) {
		List<BusinessPost> saveForBatchUpdate = new ArrayList<>();

		for (PublishData post : posts.getPostsInfo()) {
			this.changeState(saveForBatchUpdate, post, post.getId(), post.getState());
		}
		this.updateStates(posts.getUserId(), posts.getSmeId(), saveForBatchUpdate);
		return saveForBatchUpdate;
	}

	private void changeState(List<BusinessPost> saveForBatchUpdate, PublishData post, String postId,
			BusinessPostState postState) {
		try {

			BusinessPost existPost = businessPostService.getSinglePost(postId);

			if (existPost.isActive() && existPost.getPostState().equals(BusinessPostState.PENDING)) {
				existPost.setPostState(postState);
				if (postState.equals(BusinessPostState.REJECTED)) {
					existPost.setActive(PostStatus.FALSE);
				}
				if (post.getFeedbackMessage() != null) {
					String dateAndAction = "[ Date:-" + new SimpleDateFormat(DATE_FORMAT).format(new Date())
							+ " Action:-" + postState + " ] ";
					post.setFeedbackMessage(dateAndAction.concat(post.getFeedbackMessage()));

					if (existPost.getFeedbackMessage() != null) {
						existPost.setFeedbackMessage(
								existPost.getFeedbackMessage().concat("| " + post.getFeedbackMessage()));
					} else {
						existPost.setFeedbackMessage(post.getFeedbackMessage());
					}

				}
				saveForBatchUpdate.add(existPost);
			}
		} catch (Exception e) {
			log.error("Exception:- {}", e.getMessage());
		}

	}

	private void updateStates(String userId, String smeId, List<BusinessPost> saveForBatchUpdate) {

		if (!saveForBatchUpdate.isEmpty()) {
			businessPostService.saveMultiplePosts(saveForBatchUpdate);

			long rejectedPostsCount = saveForBatchUpdate.stream()
					.filter(post -> post.getPostState().equals(BusinessPostState.REJECTED)).count();

			if (rejectedPostsCount > 0) {
				PricingRequest pricingRequest = new PricingRequest();
				pricingRequest.setCreditType(CreditType.BUSINESS_POST);
				pricingRequest.setCredits(rejectedPostsCount);
				pricingRequest.setAction("CREDIT");
				pricingRequest.setsUuid(smeId);
				pricingRequest.setUserUUID(userId);

				pricingEnpoint.updateCredits(pricingRequest);
			}

		} else {
			throw new CustomException("No Valid Post Available for Modify State", HttpStatus.BAD_REQUEST);
		}
	}

	@Override
	public List<String> updateFiles(PublishData publishData) {
		List<String> deleteContentServerImgs = null;
		List<File> files = publishData.getEditedImages();
		Set<String> fileLocations = files.stream().map(File::getFileLocation).collect(Collectors.toSet());
		List<File> existFiles = fileDao.getFilesByLocations(fileLocations);
		deleteContentServerImgs = manageImages(existFiles, files);
		fileDao.saveFiles(existFiles);
		return deleteContentServerImgs;
	}

	private List<String> manageImages(List<File> existFiles, List<File> files) {

		List<String> deleteContentServerImgs = new ArrayList<>();

		for (File existFile : existFiles) {

			Optional<File> fileOpt = files.parallelStream()
					.filter(file -> existFile.getFileLocation().equals(file.getFileLocation())).findFirst();

			if (fileOpt.isPresent()) {
				File file = fileOpt.get();

				if (file.getFileLocationOne() != null) {
					if (isLocationUpdated(existFile.getFileLocation(), existFile.getFileLocationOne(),
							file.getFileLocationOne(), deleteContentServerImgs))
						existFile.setFileLocationOne(file.getFileLocationOne());
				} else {
					if (existFile.getFileLocationOne() != null
							&& !existFile.getFileLocation().equals(existFile.getFileLocationTwo()))
						deleteContentServerImgs.add(existFile.getFileLocationOne());
					existFile.setFileLocationOne(existFile.getFileLocation());
				}

				if (file.getFileLocationTwo() != null) {
					if (isLocationUpdated(existFile.getFileLocation(), existFile.getFileLocationTwo(),
							file.getFileLocationTwo(), deleteContentServerImgs))
						existFile.setFileLocationTwo(file.getFileLocationTwo());

				} else {
					if (existFile.getFileLocationTwo() != null
							&& !existFile.getFileLocation().equals(existFile.getFileLocationTwo()))
						deleteContentServerImgs.add(existFile.getFileLocationTwo());
					existFile.setFileLocationTwo(existFile.getFileLocation());
				}
			}

		}

		return deleteContentServerImgs;

	}

	private boolean isLocationUpdated(String existLocation, String existLocation1, String newLocation,
			List<String> deleteContentServerImgs) {
		if (!(newLocation.equals(existLocation) || newLocation.equals(existLocation1))) {

			if (!existLocation.equals(existLocation1)) {
				deleteContentServerImgs.add(existLocation1);
			}
			fileDao.deleteByFileLocation(newLocation);
			return true;
		}
		return false;
	}

}
