package com.gloqr.service;

import java.util.List;
import java.util.Map;

import com.gloqr.entity.BusinessPost;
import com.gloqr.model.PostStateChange;
import com.gloqr.model.PublishData;

public interface GloqrAdminService {

	Map<String,Integer> getSMEPostsCount(List<String> smeIds);

	public List<BusinessPost> getPosts(String smeId);

	List<BusinessPost> approveOrRejectBusinessPostsState( PostStateChange posts);

	List<String> updateFiles(PublishData publishData);

}
