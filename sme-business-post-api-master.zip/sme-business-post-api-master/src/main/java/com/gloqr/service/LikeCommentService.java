package com.gloqr.service;

public interface LikeCommentService {

	void likePost(String postId, String likedById, String userType);

}
