package com.gloqr.service;

import java.util.List;

import org.springframework.security.core.Authentication;

import com.gloqr.entity.BusinessPost;
import com.gloqr.model.PublishData;

public interface BusinessPostService {

	public BusinessPost createPost(BusinessPost businessPost);

	public BusinessPost updatePost(BusinessPost businessPost, String loggedInSmeId);

	public void deleteBusinessPost(final String smeUuid, final String postId);

	public BusinessPost getSinglePost(String businessPostId);

	public void updateStatus(List<PublishData> publish);

	public void saveMultiplePosts(List<BusinessPost> saveForBatchUpdate);

	public List<BusinessPost> getPendingOrRejectedPosts(String smeUuid);

	public List<BusinessPost> getPostsForViewMode(Authentication authentication, String smeUuid, int page, int size);

	public List<BusinessPost> getTimelinePosts(String smeUuid, int page, int size);

}
