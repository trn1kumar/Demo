package com.gloqr.constants;

public enum PostStatus {
	ACTIVE, DEACTIVE
}
