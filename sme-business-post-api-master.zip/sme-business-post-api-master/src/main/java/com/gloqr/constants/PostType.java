package com.gloqr.constants;

public enum PostType {
	INFRA,VACANCY,PRODUCT,SERVICE,DEFAULT
}
