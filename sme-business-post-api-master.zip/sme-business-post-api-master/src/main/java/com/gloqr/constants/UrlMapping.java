package com.gloqr.constants;

public class UrlMapping {

	private UrlMapping() {
		throw new IllegalStateException("UrlMapping class.can't initiate");
	}

	public static final String ROOT_API = "/api/business-feeds";
	public static final String GLOQR_ADMIN_API = ROOT_API + "/gloqr-admin";

	// BusinessPostControllerUrls
	public static final String BUSINESS_POST = "/post";// POST PUT
	public static final String SINGLE_POST = "/{businessPostId}/post"; // GET DELETE
	public static final String SME_ADMIN_POSTS = "/sme-admin/posts";
	public static final String BUSINESS_POSTS = "/posts";//GET
	public static final String MODIFY_STATUS = "/post/modify-status";
	public static final String SME_POSTS = "/{smeId}/posts";

	// LikeCommentControllerUrls
	public static final String LIKE_POST = "/post/{postId}/like";// PUT

	// FileControllerUrls
	public static final String UPLOAD_FILES = "/upload-files";
	public static final String DELETE_FILE = "{fileLocation}/file";

	// GloqrAdminControllerUrls
	public static final String POSTS_COUNT = "/pending-posts/count";
	public static final String PENDING_POSTS = "/{smeId}/pending-posts";
	public static final String MODIFY_STATE = "/modify-state-of-posts";
	public static final String UPDATE_FILES = "/files";

}
