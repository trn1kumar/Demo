package com.gloqr.constants;

import org.springframework.http.HttpStatus;

import com.gloqr.exception.CustomException;

public class Roles {

	private Roles() {
		throw new CustomException("Constants class.can't initiate", HttpStatus.INTERNAL_SERVER_ERROR);
	}

	// RoleAccess
	public static final String SME_ADMIN = "hasAnyRole('SME-ADMIN')";
	public static final String GLOQR_ADMIN = "GLOQR-SUPER-ADMIN";
	public static final String SME_ADMIN_AND_GLOQR_ADMIN = "hasAnyRole('SME-ADMIN','GLOQR-SUPER-ADMIN')";
	public static final String ALL_ROLES = "hasAnyRole('USER','GLOQR-SUPER-ADMIN','SME-ADMIN')";

}
