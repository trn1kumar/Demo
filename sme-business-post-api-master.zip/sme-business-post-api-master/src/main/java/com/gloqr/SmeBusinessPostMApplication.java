package com.gloqr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableMongoAuditing
@EnableCaching
@EnableAsync
@PropertySource(value = { "file:${location}/sme_business_post.properties" })
public class SmeBusinessPostMApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmeBusinessPostMApplication.class, args);
	}

}
