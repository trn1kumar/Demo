package com.gloqr.dto;


import java.util.Set;

public class TagDto {

	private String smeId;
	
	private SMEDto smeInfo;

	private Set<BusinessPostDto> taggedPosts;

	public String getSmeId() {
		return smeId;
	}

	public void setSmeId(String smeId) {
		this.smeId = smeId;
	}

	public Set<BusinessPostDto> getTaggedPosts() {
		return taggedPosts;
	}

	public void setTaggedPosts(Set<BusinessPostDto> taggedPosts) {
		this.taggedPosts = taggedPosts;
	}

	public SMEDto getSmeInfo() {
		return smeInfo;
	}

	public void setSmeInfo(SMEDto smeInfo) {
		this.smeInfo = smeInfo;
	}

	

}
