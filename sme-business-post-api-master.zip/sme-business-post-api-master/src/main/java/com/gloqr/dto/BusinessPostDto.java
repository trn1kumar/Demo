package com.gloqr.dto;

import java.util.List;
import java.util.Set;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.gloqr.audit.DateAuditable;
import com.gloqr.constants.BusinessPostState;
import com.gloqr.constants.PostType;
import com.gloqr.constants.Privacy;
import com.gloqr.entity.File;

@JsonInclude(Include.NON_NULL)
public class BusinessPostDto extends DateAuditable {

	private String businessPostId;

	private String publishFeedId;

	private String smeUuid;

	private SMEDto smeInfo;

	@NotNull(message = "privacy can not be empty")
	private Privacy privacy;

	private PostType postType = PostType.DEFAULT;

	private String title;

	private String description;

	private String feedbackMessage;

	private BusinessPostState postState;

	private boolean active = true;

	private boolean postModified;

	private List<File> files;

	private int likesCount;

	private boolean liked;

	private Set<String> tags;

	private List<SMEDto> taggedWith;

	public String getSmeUuid() {
		return smeUuid;
	}

	public void setSmeUuid(String smeUuid) {
		this.smeUuid = smeUuid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getBusinessPostId() {
		return businessPostId;
	}

	public void setBusinessPostId(String businessPostId) {
		this.businessPostId = businessPostId;
	}

	public SMEDto getSmeInfo() {
		return smeInfo;
	}

	public void setSmeInfo(SMEDto smeInfo) {
		this.smeInfo = smeInfo;
	}

	public List<SMEDto> getTaggedWith() {
		return taggedWith;
	}

	public void setTaggedWith(List<SMEDto> taggedWith) {
		this.taggedWith = taggedWith;
	}

	public List<File> getFiles() {
		return files;
	}

	public void setFiles(List<File> files) {
		this.files = files;
	}

	public Privacy getPrivacy() {
		return privacy;
	}

	public void setPrivacy(Privacy privacy) {
		this.privacy = privacy;
	}

	public PostType getPostType() {
		return postType;
	}

	public void setPostType(PostType postType) {
		this.postType = postType;
	}

	public BusinessPostState getPostState() {
		return postState;
	}

	public void setPostState(BusinessPostState postState) {
		this.postState = postState;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getFeedbackMessage() {
		return feedbackMessage;
	}

	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}

	public boolean isPostModified() {
		return postModified;
	}

	public void setPostModified(boolean postModified) {
		this.postModified = postModified;
	}

	public String getPublishFeedId() {
		return publishFeedId;
	}

	public void setPublishFeedId(String publishFeedId) {
		this.publishFeedId = publishFeedId;
	}

	public Set<String> getTags() {
		return tags;
	}

	public void setTags(Set<String> tags) {
		this.tags = tags;
	}

	public int getLikesCount() {
		return likesCount;
	}

	public void setLikesCount(int likesCount) {
		this.likesCount = likesCount;
	}

	public boolean isLiked() {
		return liked;
	}

	public void setLiked(boolean liked) {
		this.liked = liked;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((businessPostId == null) ? 0 : businessPostId.hashCode());
		result = prime * result + ((publishFeedId == null) ? 0 : publishFeedId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		BusinessPostDto other = (BusinessPostDto) obj;
		if (businessPostId == null) {
			if (other.businessPostId != null)
				return false;
		} else if (!businessPostId.equals(other.businessPostId))
			return false;
		if (publishFeedId == null) {
			if (other.publishFeedId != null)
				return false;
		} else if (!publishFeedId.equals(other.publishFeedId))
			return false;
		return true;
	}
	
	
	

}
