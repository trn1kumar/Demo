package com.gloqr.model.http.response;

public class ResponseMessages {

	private ResponseMessages() {

	}

	public static final String POST_CREATED = "Post Created Successfully";
	public static final String POST_UPDATED = "Post Updated Successfully";
	public static final String POST_DELETED = "Post Deleted Successfully";
	public static final String POST_LIKED = "Post Liked Successfully";
	public static final String SUCCESS = "Success";
	public static final String FILE_UPLODED = "Files Uploaded Successfully";
	public static final String FILE_DELETED = "File Deleted Successfully";
}
