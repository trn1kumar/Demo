package com.gloqr.model;

import com.gloqr.constants.CreditType;

public class PricingRequest {

	private String userUUID;
	private String sUuid;
	private CreditType creditType;
	private String action;
	private String usedFor;
	private long credits;

	public PricingRequest() {
		super();
	}

	public PricingRequest(CreditType creditType, long credits, String action) {
		super();
		this.creditType = creditType;
		this.action = action;
		this.credits = credits;
	}

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getUserUUID() {
		return userUUID;
	}

	public void setUserUUID(String userUUID) {
		this.userUUID = userUUID;
	}

	public CreditType getCreditType() {
		return creditType;
	}

	public void setCreditType(CreditType creditType) {
		this.creditType = creditType;
	}

	public long getCredits() {
		return credits;
	}

	public void setCredits(long credits) {
		this.credits = credits;
	}

	public String getUsedFor() {
		return usedFor;
	}

	public void setUsedFor(String usedFor) {
		this.usedFor = usedFor;
	}

	@Override
	public String toString() {
		return "PricingRequest [userUUID=" + userUUID + ", sUuid=" + sUuid + ", type=" + creditType + ", action="
				+ action + ", credits=" + credits + "]";
	}

}
