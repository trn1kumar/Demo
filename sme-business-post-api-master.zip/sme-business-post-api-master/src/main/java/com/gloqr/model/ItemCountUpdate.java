package com.gloqr.model;

public class ItemCountUpdate {

	private static final String ITEM_TYPE = "BUSINESS_POST";
	private int totalCount;
	private int activeApprovedCount;
	private int activePendingCount;

	public ItemCountUpdate(int totalCount, int activeApprovedCount, int activePendingCount) {
		super();
		this.totalCount = totalCount;
		this.activeApprovedCount = activeApprovedCount;
		this.activePendingCount = activePendingCount;

	}

	public String getItemType() {
		return ITEM_TYPE;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public int getActiveApprovedCount() {
		return activeApprovedCount;
	}

	public void setActiveApprovedCount(int activeApprovedCount) {
		this.activeApprovedCount = activeApprovedCount;
	}

	public int getActivePendingCount() {
		return activePendingCount;
	}

	public void setActivePendingCount(int activePendingCount) {
		this.activePendingCount = activePendingCount;
	}

	@Override
	public String toString() {
		return "ItemCountUpdate [totalCount=" + totalCount + ", activeApprovedCount=" + activeApprovedCount
				+ ", activePendingCount=" + activePendingCount + "]";
	}

}
