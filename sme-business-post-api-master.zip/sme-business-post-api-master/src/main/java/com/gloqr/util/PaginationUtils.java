package com.gloqr.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mobile.device.Device;
import org.springframework.mobile.device.DeviceUtils;
import org.springframework.stereotype.Component;

import com.gloqr.configuration.PropertyValues;
import com.gloqr.security.context.holder.IContextHolder;

@Component
public class PaginationUtils implements IContextHolder {

	@Autowired
	private PropertyValues propertyValues;

	public int getPageSize() {

		int pageSize = propertyValues.getNormalPageSize();

		Device device = DeviceUtils.getCurrentDevice(this.getCurrentServletRequest());

		if (device.isMobile())
			pageSize = propertyValues.getMobilePageSize();
		if (device.isTablet())
			pageSize = propertyValues.getTabletPageSize();

		return pageSize;
	}
}
