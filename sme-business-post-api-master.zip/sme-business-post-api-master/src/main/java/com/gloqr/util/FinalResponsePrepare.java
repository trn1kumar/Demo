package com.gloqr.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import com.gloqr.dto.SMEDto;
import com.gloqr.entity.BusinessPost;
import com.gloqr.mapper.BusinessPostMapper;
import com.gloqr.security.context.holder.UserDetails;
import com.gloqr.service.SMEService;
import com.gloqr.vo.BusinessPostVo;

@Component
public class FinalResponsePrepare {

	@Autowired
	private BusinessPostMapper businessPostMapper;

	@Autowired
	private SMEService smeService;

	public List<BusinessPostVo> prepareResponse(Authentication authentication, List<BusinessPost> posts) {

		List<BusinessPostVo> postVos = new ArrayList<>();
		Set<String> smeIds = posts.stream().map(BusinessPost::getSmeUuid).collect(Collectors.toSet());
		Map<String, SMEDto> smes = smeService.getSMEs(smeIds);

		posts.forEach(post -> {
			BusinessPostVo postVo = businessPostMapper.convertToDto(post, BusinessPostVo.class);
			postVo.setSmeInfo(smes.get(post.getSmeUuid()));
			if (authentication != null && post.getLikesCount() > 0) {
				UserDetails userDetails = (UserDetails) authentication.getPrincipal();
				Map<String, String> likes = post.getLikes();
				if (likes.containsKey(userDetails.getUserId()) || likes.containsKey(userDetails.getSmeId())) {
					postVo.setLiked(true);
				}
			}
			postVos.add(postVo);
		});

		return postVos;
	}

}
