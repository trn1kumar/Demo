package com.gloqr.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PropertyValues {

	@Value(PropertyNames.BASE_URL)
	private String baseUrl;

	@Value(PropertyNames.CONTENT_SERVER_URL)
	private String contentServerUrl;

	@Value(PropertyNames.VERIFY_POSTS_EMAIL_SUB)
	private String verifyPostsEmailSub;

	@Value(PropertyNames.NORMAL_PAGE_SIZE)
	private int normalPageSize;

	@Value(PropertyNames.MOBILE_PAGE_SIZE)
	private int mobilePageSize;

	@Value(PropertyNames.TABLET_PAGE_SIZE)
	private int tabletPageSize;

	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	public String getContentServerUrl() {
		return contentServerUrl;
	}

	public void setContentServerUrl(String contentServerUrl) {
		this.contentServerUrl = contentServerUrl;
	}

	public String getVerifyPostsEmailSub() {
		return verifyPostsEmailSub;
	}

	public void setVerifyPostsEmailSub(String verifyPostsEmailSub) {
		this.verifyPostsEmailSub = verifyPostsEmailSub;
	}

	public int getNormalPageSize() {
		return normalPageSize;
	}

	public void setNormalPageSize(int normalPageSize) {
		this.normalPageSize = normalPageSize;
	}

	public int getMobilePageSize() {
		return mobilePageSize;
	}

	public void setMobilePageSize(int mobilePageSize) {
		this.mobilePageSize = mobilePageSize;
	}

	public int getTabletPageSize() {
		return tabletPageSize;
	}

	public void setTabletPageSize(int tabletPageSize) {
		this.tabletPageSize = tabletPageSize;
	}

	public static final class PropertyNames {

		private PropertyNames() {
			throw new IllegalStateException("PropertyNames class.can't initiate");
		}

		public static final String BASE_URL = "${base-url}";
		public static final String CONTENT_SERVER_URL = "${content-server.localized-url}";
		public static final String VERIFY_POSTS_EMAIL_SUB = "${notify.verify-business-post.email-subject}";
		public static final String NORMAL_PAGE_SIZE = "${normal-page-size}";
		public static final String MOBILE_PAGE_SIZE = "${mobile-page-size}";
		public static final String TABLET_PAGE_SIZE = "${tablet-page-size}";
	}

}
