package com.gloqr.configuration;

import javax.annotation.Resource;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.gloqr.rest.endpoint.ContentServerEndpoint;
import com.gloqr.rest.endpoint.NotificationEndPoint;
import com.gloqr.rest.endpoint.PricingEndpoint;
import com.gloqr.rest.endpoint.ProductEndPoint;
import com.gloqr.rest.endpoint.SMECircleEndPoint;
import com.gloqr.rest.endpoint.ServiceEndPoint;
import com.gloqr.rest.endpoint.SmeEndPoint;

@Configuration
public class BeanConfiguration {

	private static final Logger log = LogManager.getLogger();
	@Resource
	private Environment environment;

	@Bean
	public ClientConfig clientConfig() {
		ClientConfig configuration = new ClientConfig();
		configuration.property(ClientProperties.CONNECT_TIMEOUT, 10000);
		configuration.property(ClientProperties.READ_TIMEOUT, 30000);

		return configuration;
	}

	@Bean
	public SmeEndPoint smeInformationConfiguration() {
		Client client = ClientBuilder.newClient(clientConfig());
		String endPoint = environment.getRequiredProperty("sme.endpoint");
		String specificSMEsPath = environment.getRequiredProperty("specific.smes.path");
		String smeVoPath = environment.getRequiredProperty("sme.vo.path");
		String imgUpdatePath = environment.getRequiredProperty("sme.post-imgs.update.path");
		String updateCountPath = environment.getRequiredProperty("post.count.update.path");
		return new SmeEndPoint(client, endPoint, specificSMEsPath, smeVoPath, imgUpdatePath, updateCountPath);
	}

	@Bean
	public SMECircleEndPoint smeCircleBeanConfig() {
		Client client = ClientBuilder.newClient(clientConfig());
		String endPoint = environment.getRequiredProperty("sme.circle.endpoint");
		String connectionsPath = environment.getRequiredProperty("sme.connection");

		return new SMECircleEndPoint(client, endPoint, connectionsPath);
	}

	@Bean
	public ServiceEndPoint serviceEndpointConfig() {
		Client client = ClientBuilder.newClient(clientConfig());
		String endPoint = environment.getRequiredProperty("service.endpoint");
		String postImgEditPath = environment.getRequiredProperty("serive.post-imgs.update.path");
		return new ServiceEndPoint(client, endPoint, postImgEditPath);
	}

	@Bean
	public ProductEndPoint productEndpointConfig() {
		Client client = ClientBuilder.newClient(clientConfig());
		String endPoint = environment.getRequiredProperty("service.endpoint");
		String postImgEditPath = environment.getRequiredProperty("product.post-imgs.update.path");
		return new ProductEndPoint(client, endPoint, postImgEditPath);
	}

	@Bean
	public ContentServerEndpoint contentConfiguration() {
		Client client = ClientBuilder.newBuilder().register(MultiPartFeature.class).build();

		String endPoint = environment.getRequiredProperty("contentserver.endpoint");
		String uploadFiles = environment.getRequiredProperty("uploadsfiles.endpoint.path");
		String deleteFiles = environment.getRequiredProperty("deletefiles.endpoint.path");
		return new ContentServerEndpoint(client, endPoint, uploadFiles, deleteFiles);
	}

	@Bean
	public PricingEndpoint pricingEndpoint() {

		Client client = ClientBuilder.newClient(clientConfig());
		String pricingEndpointUrl = environment.getRequiredProperty("pricing.endpoint");
		String checkCreditsPath = environment.getRequiredProperty("user.credits");
		String adminUpdateCreditsPath = environment.getRequiredProperty("admin.update.credits");

		return new PricingEndpoint(client, pricingEndpointUrl, checkCreditsPath, adminUpdateCreditsPath);
	}

	@Bean(name = "taskExecutor")
	public TaskExecutor workExecutor() {
		int poolsize = 0;
		int maxPoolSize = 0;
		int capacity = 0;

		ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
		threadPoolTaskExecutor.setThreadNamePrefix(environment.getRequiredProperty("thread.name.prefix"));
		try {
			poolsize = Integer.parseInt(environment.getRequiredProperty("pool.size"));
			maxPoolSize = Integer.parseInt(environment.getRequiredProperty("max.pool.size"));
			capacity = Integer.parseInt(environment.getRequiredProperty("queue.capacity"));
		} catch (NumberFormatException e) {
			log.info(("Problem Occurred to read thread property " + e.getLocalizedMessage()
					+ " from application properties.make sure that provided property is integer"));
			System.exit(0);
		}
		threadPoolTaskExecutor.setCorePoolSize(poolsize);
		threadPoolTaskExecutor.setMaxPoolSize(maxPoolSize);
		threadPoolTaskExecutor.setQueueCapacity(capacity);
		threadPoolTaskExecutor.afterPropertiesSet();
		log.info("ThreadPoolTaskExecutor set");
		return threadPoolTaskExecutor;
	}

	@Bean
	public NotificationEndPoint notificationConfiguration() {
		Client client = ClientBuilder.newClient(clientConfig());
		String notificationEndPoint = environment.getRequiredProperty("notification.endpoint");
		String smsEndPointPath = environment.getRequiredProperty("sms.endpoint.path");
		String emailEndPointPath = environment.getRequiredProperty("email.endpoint.path");

		return new NotificationEndPoint(client, notificationEndPoint, smsEndPointPath, emailEndPointPath);
	}

}
