package com.gloqr.repository;

public interface TagCustomRepository {

}
