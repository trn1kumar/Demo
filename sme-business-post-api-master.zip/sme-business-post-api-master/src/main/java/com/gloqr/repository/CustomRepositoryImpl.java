package com.gloqr.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.BulkOperationException;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;

import com.gloqr.constants.BusinessPostConstants.PostStatus;
import com.gloqr.constants.BusinessPostState;
import com.gloqr.constants.Privacy;
import com.gloqr.entity.BusinessPost;
import com.gloqr.exception.CustomException;
import com.gloqr.model.PublishData;

public class CustomRepositoryImpl implements CustomRepository {

	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public void updatePostStatus(List<PublishData> publish) {
		int count = 0;
		int batch = 20;
		BulkOperations bulkOps = mongoTemplate.bulkOps(BulkOperations.BulkMode.UNORDERED, BusinessPost.class);
		for (PublishData p : publish) {
			Query query = new Query();
			Criteria criteria = Criteria.where("publishFeedId").is(p.getId());
			query.addCriteria(criteria);
			Update update = new Update();
			update.set("active", PostStatus.TRUE);
			bulkOps.updateOne(query, update);
			count++;
			if (count == batch) {
				this.executeBulkOps(bulkOps);
				count = 0;
			}
		}
		if (count > 0) {
			this.executeBulkOps(bulkOps);
		}
	}

	private void executeBulkOps(BulkOperations bulkOps) {
		try {
			bulkOps.execute();
		} catch (BulkOperationException e) {
			throw new CustomException(
					"Exception in :: executeBulkOps() while activating Business Posts.  Message:  " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

	}

	@Override
	public List<BusinessPost> getTimelinePosts(String smeUuid, List<String> taggedPostIds, String postViewerSmeUuid,
			int page, int size) {
		Criteria taggedPostsInCriteria = Criteria.where("businessPostId").in(taggedPostIds).and("postState")
				.is(BusinessPostState.APPROVED).and("active").is(true);
		Criteria smeUuidCriteria = Criteria.where("smeUuid").is(smeUuid);
		Criteria finalCriteria = new Criteria().orOperator(taggedPostsInCriteria, smeUuidCriteria);

		if (postViewerSmeUuid != null) {
			Criteria privacyCriteria = Criteria.where("privacy").is(Privacy.PUBLIC);
			Criteria viewerSmeUuidCriteria = Criteria.where("smeUuid").is(postViewerSmeUuid);
			Criteria tagsCriteria = Criteria.where("tags").in(postViewerSmeUuid);
			Criteria postViewerCriteria = Criteria.where("postState").is(BusinessPostState.APPROVED).and("active")
					.is(true).orOperator(privacyCriteria, viewerSmeUuidCriteria, tagsCriteria);
			finalCriteria.andOperator(postViewerCriteria);
		}

		if (page <= 0)
			page = 1;

		Query query = new Query().with(PageRequest.of(--page, size, new Sort(Sort.Direction.DESC, "creationDate")));
		query.addCriteria(finalCriteria);
		query.fields().include("smeUuid").include("title").include("description").include("files").include("likesCount")
				.include("likes").include("creationDate").include("privacy");

		List<BusinessPost> posts = mongoTemplate.find(query, BusinessPost.class);

		if (posts.isEmpty())
			throw new CustomException("Posts Not Available for SME :: " + smeUuid, HttpStatus.NOT_FOUND);

		return posts;
	}

}
