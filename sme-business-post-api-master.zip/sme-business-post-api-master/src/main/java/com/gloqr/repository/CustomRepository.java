package com.gloqr.repository;

import java.util.List;

import com.gloqr.entity.BusinessPost;
import com.gloqr.model.PublishData;

public interface CustomRepository {

	public void updatePostStatus(List<PublishData> publish);

	public List<BusinessPost> getTimelinePosts(String smeUuid, List<String> taggedPostIds, String postViewerSmeUuid,
			int page, int size);

}
