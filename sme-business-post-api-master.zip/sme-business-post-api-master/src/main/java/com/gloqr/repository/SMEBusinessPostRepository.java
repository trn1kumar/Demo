package com.gloqr.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.gloqr.constants.BusinessPostState;
import com.gloqr.constants.Privacy;
import com.gloqr.entity.BusinessPost;

public interface SMEBusinessPostRepository extends MongoRepository<BusinessPost, String>, CustomRepository {

	int countBySmeUuid(String smeUuid);

	boolean existsByBusinessPostId(String postId);

	List<BusinessPost> findBySmeUuidAndPostStateAndActiveTrue(String smeUuid, BusinessPostState state);

	@Query(fields = "{'tags' : 0,'files' : 0,'likes' : 0,'likesCount' : 0,'smeUuid' : 0,'publishFeedId' : 0,'postType' : 0}")
	List<BusinessPost> findBySmeUuidAndPostStateNotIn(String smeUuid, BusinessPostState approved);

	List<BusinessPost> findAllByBusinessPostId(Set<String> taggedPostIds);

	int countBySmeUuidAndPostStateAndActive(String smeUuid, BusinessPostState pending, boolean active);

	Set<BusinessPost> getSmeUuidBy();

	List<BusinessPost> findBySmeUuidAndPostStateAndActiveTrueOrBusinessPostIdInAndPostStateAndActiveTrue(String smeId,
			BusinessPostState state, List<String> taggedPostIds, BusinessPostState state1, Pageable pageable);

	List<BusinessPost> findBySmeUuidAndPostStateAndPrivacyAndActiveTrue(String smeUuid, BusinessPostState postState,
			Privacy privacy, PageRequest pageRequest);

}