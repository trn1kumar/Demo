package com.gloqr.security.context.holder;

import org.springframework.security.core.Authentication;

public interface AuthenticationFacade extends IContextHolder{

	public Authentication getAuthentication();

	public String getJwtToken();
}
