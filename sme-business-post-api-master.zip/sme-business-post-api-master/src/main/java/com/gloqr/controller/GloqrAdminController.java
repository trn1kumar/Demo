package com.gloqr.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.BusinessPostDto;
import com.gloqr.dto.SMEDto;
import com.gloqr.entity.BusinessPost;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.BusinessPostMapper;
import com.gloqr.model.PostStateChange;
import com.gloqr.model.PublishData;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.model.http.response.ResponseMessages;
import com.gloqr.repository.SMEBusinessPostRepository;
import com.gloqr.rest.endpoint.ContentServerEndpoint;
import com.gloqr.security.context.holder.AuthenticationFacade;
import com.gloqr.service.CountManageService;
import com.gloqr.service.GloqrAdminService;
import com.gloqr.service.NotificationService;
import com.gloqr.service.SMEService;

@RestController
@CrossOrigin(origins = "*")
@SuppressWarnings("rawtypes")
@RequestMapping(UrlMapping.GLOQR_ADMIN_API)
public class GloqrAdminController {

	@Autowired
	private ResponseMaker responseMaker;

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private GloqrAdminService gloqrAdminService;

	@Autowired
	private BusinessPostMapper businessPostMapper;

	@Autowired
	private SMEService smeService;

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private CountManageService countManageService;

	@Autowired
	private AuthenticationFacade authenticationFaced;
	
	@Autowired
	private ContentServerEndpoint contentServerEndpoint;

	@GetMapping(UrlMapping.POSTS_COUNT)
	public ResponseEntity<CustomHttpResponse<Map<String, Integer>>> getSMEPostsCount(
			@RequestParam List<String> smeIds) {
		Map<String, Integer> smePostCounts = null;
		smePostCounts = gloqrAdminService.getSMEPostsCount(smeIds);

		if (smePostCounts.isEmpty()) {
			log.info("None of smes added Posts in given Ids:- " + smeIds);
		}

		return responseMaker.successResponse(smePostCounts, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@PutMapping(UrlMapping.MODIFY_STATE)
	public ResponseEntity<CustomHttpResponse> modifyState(@RequestBody PostStateChange posts) {
		try {
			List<BusinessPost> modifiedData = gloqrAdminService.approveOrRejectBusinessPostsState(posts);
			notificationService.sendPostsVerificationSummaryNotifi(posts.getSmeId(), modifiedData);
			countManageService.updatePostsCount(posts.getSmeId(), authenticationFaced.getJwtToken());
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.POST_UPDATED, HttpStatus.OK);

	}

	@PutMapping(UrlMapping.UPDATE_FILES)
	public ResponseEntity<CustomHttpResponse> updateImages(@RequestBody PublishData publishData) {
		try {
			List<String> deleteImgLocations = gloqrAdminService.updateFiles(publishData);
			if (deleteImgLocations != null && !deleteImgLocations.isEmpty())
				contentServerEndpoint.deleteFilesFromContentServer(deleteImgLocations);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.PENDING_POSTS)
	public ResponseEntity<CustomHttpResponse<List<BusinessPostDto>>> getSMEPosts(@PathVariable String smeId) {
		List<BusinessPostDto> postsDto = new ArrayList<>();

		try {
			SMEDto smeInfo = smeService.getSME(smeId);
			List<BusinessPost> posts = gloqrAdminService.getPosts(smeId);
			posts.forEach(post -> {
				BusinessPostDto postDto = businessPostMapper.convertToDto(post, BusinessPostDto.class);
				postDto.setSmeInfo(smeInfo);
				postsDto.add(postDto);
			});

		} catch (CustomException e) {
			throw e;
		}
		return responseMaker.successResponse(postsDto, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	// Update Manually Count If Some Count Manage Miss-Behavior Happen

	@Autowired
	private AuthenticationFacade authenticationFacade;

	@Autowired
	private SMEBusinessPostRepository businessPostRepo;

	@GetMapping("update-counts")
	public ResponseEntity<CustomHttpResponse> updateCounts() {
		Set<BusinessPost> posts = businessPostRepo.getSmeUuidBy();
		for (BusinessPost post : posts) {
			countManageService.updatePostsCount(post.getSmeUuid(), authenticationFacade.getJwtToken());
		}
		return responseMaker.successResponse("Success", HttpStatus.OK);
	}
}
