package com.gloqr.controller;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.aop.CheckAndUpdate;
import com.gloqr.aop.PublishCheckAndUpdate;
import com.gloqr.constants.Roles;
import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.BusinessPostDto;
import com.gloqr.entity.BusinessPost;
import com.gloqr.mapper.BusinessPostMapper;
import com.gloqr.model.PublishData;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.model.http.response.ResponseMessages;
import com.gloqr.security.context.holder.AuthenticationFacade;
import com.gloqr.security.context.holder.UserDetails;
import com.gloqr.service.BusinessPostService;
import com.gloqr.service.CountManageService;
import com.gloqr.service.SMEService;
import com.gloqr.util.FinalResponsePrepare;
import com.gloqr.util.PaginationUtils;
import com.gloqr.vo.BusinessPostVo;

@RestController
@RequestMapping(UrlMapping.ROOT_API)
@CrossOrigin("*")
@SuppressWarnings("rawtypes")
public class BusinessPostController {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private BusinessPostService businessPostService;

	@Autowired
	private BusinessPostMapper businessPostMapper;

	@Autowired
	private SMEService smeService;

	@Autowired
	private CountManageService countManageService;

	@Autowired
	private AuthenticationFacade authenticationFaced;

	@Autowired
	private FinalResponsePrepare finalResponsePrepare;

	@Autowired
	private PaginationUtils paginationUtils;

	@PostMapping(UrlMapping.BUSINESS_POST)
	@PreAuthorize(Roles.SME_ADMIN)
	@CheckAndUpdate
	public ResponseEntity<CustomHttpResponse<BusinessPostDto>> createBusinessPost(Authentication authentication,
			@Valid @RequestBody BusinessPostDto businessPostDto,
			@RequestParam(required = false) boolean publishedPost) {

		final UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = userDetails.getSmeId();
		log.info("Request for Create Business-Post by smeId: {} and publishedPost: {}", loggedInSmeId, publishedPost);
		BusinessPost businessPost = null;
		BusinessPostDto postDto = null;

		try {
			businessPostDto.setSmeUuid(loggedInSmeId);
			businessPost = businessPostService
					.createPost(businessPostMapper.convertToEntity(businessPostDto, BusinessPost.class));

			postDto = businessPostMapper.convertToDto(businessPost, BusinessPostDto.class);
			countManageService.updatePostsCount(loggedInSmeId, authenticationFaced.getJwtToken());

			if (publishedPost) {
				return ResponseEntity.ok().build();
			}

			postDto.setSmeInfo(smeService.getSME(businessPost.getSmeUuid()));

		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(postDto, ResponseMessages.POST_CREATED, HttpStatus.CREATED);

	}

	@PutMapping(UrlMapping.BUSINESS_POST)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> updateBusinessPost(Authentication authentication,
			@RequestBody BusinessPostDto businessPostDto) {

		final UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = userDetails.getSmeId();
		log.info("Request for Update Business-Post by smeId: {}", loggedInSmeId);
		try {
			businessPostService.updatePost(businessPostMapper.convertToEntity(businessPostDto, BusinessPost.class),
					loggedInSmeId);
			countManageService.updatePostsCount(loggedInSmeId, authenticationFaced.getJwtToken());
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.POST_UPDATED, HttpStatus.OK);
	}

	@DeleteMapping(UrlMapping.SINGLE_POST)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> deleteBusinessPost(Authentication authentication,
			@PathVariable String businessPostId) {
		final UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = userDetails.getSmeId();
		log.info("Request for Delete Business-Post by smeId: {}", loggedInSmeId);
		try {
			businessPostService.deleteBusinessPost(loggedInSmeId, businessPostId);
			countManageService.updatePostsCount(loggedInSmeId, authenticationFaced.getJwtToken());
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.POST_DELETED, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.SINGLE_POST)
	public ResponseEntity<CustomHttpResponse<BusinessPostDto>> getPost(@PathVariable String businessPostId) {
		BusinessPostDto postDto = null;
		try {
			BusinessPost post = businessPostService.getSinglePost(businessPostId);
			postDto = businessPostMapper.convertToDto(post, BusinessPostDto.class);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(postDto, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.SME_ADMIN_POSTS)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse<List<BusinessPostDto>>> getPendingOrRejectedPosts(
			Authentication authentication) {

		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		List<BusinessPostDto> postDtos = null;
		try {
			List<BusinessPost> posts = businessPostService.getPendingOrRejectedPosts(userDetails.getSmeId());
			postDtos = posts.stream().map(post -> businessPostMapper.convertToDto(post, BusinessPostDto.class))
					.collect(Collectors.toList());

		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(postDtos, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.BUSINESS_POSTS)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse<List<BusinessPostVo>>> getLoggedInSMEsPosts(Authentication authentication,
			@RequestParam(required = false) Integer page) {

		if (page == null || page <= 0)
			page = 1;

		int size = paginationUtils.getPageSize();

		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		List<BusinessPostVo> postVos = null;
		try {
			List<BusinessPost> posts = businessPostService.getTimelinePosts(userDetails.getSmeId(), page, size);
			postVos = finalResponsePrepare.prepareResponse(authentication, posts);

		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(postVos, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.SME_POSTS)
	public ResponseEntity<CustomHttpResponse<List<BusinessPostVo>>> getPostsForViewMode(Authentication authentication,
			@PathVariable String smeId, @RequestParam(required = false) Integer page) {
		if (page == null || page <= 0)
			page = 1;
		int size = paginationUtils.getPageSize();

		List<BusinessPostVo> postVos = null;
		try {

			List<BusinessPost> posts = businessPostService.getPostsForViewMode(authentication, smeId, page, size);
			postVos = finalResponsePrepare.prepareResponse(authentication, posts);

		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(postVos, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@PutMapping(UrlMapping.MODIFY_STATUS)
	@PreAuthorize(Roles.SME_ADMIN)
	@PublishCheckAndUpdate
	public ResponseEntity<CustomHttpResponse> updatePostStatus(Authentication authentication,
			@RequestBody List<PublishData> datas) {

		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		try {
			businessPostService.updateStatus(datas);
			countManageService.updatePostsCount(userDetails.getSmeId(), authenticationFaced.getJwtToken());
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.POST_UPDATED, HttpStatus.OK);
	}

}
