package com.gloqr.vo;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.gloqr.constants.Privacy;
import com.gloqr.dto.SMEDto;
import com.gloqr.entity.File;

@JsonInclude(value = Include.NON_NULL)
public class BusinessPostVo {

	private Date creationDate;

	private String businessPostId;

	private SMEDto smeInfo;

	private Privacy privacy;

	private String title;

	private String description;

	private List<File> files;

	private int likesCount;

	private boolean liked;

	private List<SMEDto> taggedWith;

	public String getBusinessPostId() {
		return businessPostId;
	}

	public void setBusinessPostId(String businessPostId) {
		this.businessPostId = businessPostId;
	}

	public SMEDto getSmeInfo() {
		return smeInfo;
	}

	public void setSmeInfo(SMEDto smeInfo) {
		this.smeInfo = smeInfo;
	}

	public Privacy getPrivacy() {
		return privacy;
	}

	public void setPrivacy(Privacy privacy) {
		this.privacy = privacy;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<File> getFiles() {
		return files;
	}

	public void setFiles(List<File> files) {
		this.files = files;
	}

	public int getLikesCount() {
		return likesCount;
	}

	public void setLikesCount(int likesCount) {
		this.likesCount = likesCount;
	}

	public boolean isLiked() {
		return liked;
	}

	public void setLiked(boolean liked) {
		this.liked = liked;
	}

	public List<SMEDto> getTaggedWith() {
		return taggedWith;
	}

	public void setTaggedWith(List<SMEDto> taggedWith) {
		this.taggedWith = taggedWith;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

}
