package com.gloqr.repository;

import java.util.Map;

import com.gloqr.entity.Pricing;
import com.gloqr.entity.PricingPlan;
import com.gloqr.entity.UserPricing;
import com.gloqr.pricing.PlanName;
import com.gloqr.pricing.dto.PricingPlanDTO;
import com.gloqr.pricing.dto.UnitCostDTO;
import com.gloqr.pricing.dto.UserPricingDTO;

public interface PricingDao {

	PricingPlanDTO addNewPricingPlan(PricingPlan pricingPlan);

	PricingPlanDTO getPricingPlan(PlanName planName);

	Map<String, Object> getPricingTableData();

	UserPricingDTO saveUserPricing(UserPricing userPricing);

	UserPricingDTO getUserPricing(String sUuid);

	Pricing getPricing(String pricingUuid);

	Pricing savePricing(Pricing pricing);
	
	UnitCostDTO getUnitCosting();
}
