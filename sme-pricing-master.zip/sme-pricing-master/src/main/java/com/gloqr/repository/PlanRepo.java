package com.gloqr.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gloqr.entity.PricingPlan;
import com.gloqr.pricing.PlanName;

@Repository
public interface PlanRepo extends JpaRepository<PricingPlan, Long> {

	Optional<PricingPlan> findByPlanName(PlanName planName);
	
}
