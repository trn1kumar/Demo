package com.gloqr.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.entity.UserPricing;

public interface UserPricingRepo extends JpaRepository<UserPricing, Long> {

	Optional<UserPricing> findBySUuid(String sUuid);

	boolean existsBySUuidAndActiveTrue(String sUuid);

	List<UserPricing> findByMonthlyCreditedDateAndMonthBiAddedLessThan(Date date, int lessThan);
}
