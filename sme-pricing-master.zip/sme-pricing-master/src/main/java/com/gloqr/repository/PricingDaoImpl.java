package com.gloqr.repository;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.entity.Pricing;
import com.gloqr.entity.PricingPlan;
import com.gloqr.entity.UserPricing;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.Mapper;
import com.gloqr.pricing.PlanName;
import com.gloqr.pricing.dto.PricingPlanDTO;
import com.gloqr.pricing.dto.UnitCostDTO;
import com.gloqr.pricing.dto.UserPricingDTO;
import com.gloqr.util.CalculateUtil;

@Repository
public class PricingDaoImpl implements PricingDao {

	@Autowired
	private PlanRepo planRepo;

	@Autowired
	private PricingRepo pricingRepo;

	@Autowired
	private Mapper mapper;

	@Autowired
	private CalculateUtil calculateUtil;

	@Autowired
	private UserPricingRepo userPricingRepo;

	@Value("${pricing.table.uuid}")
	private String pricingUuid;

	@Override
	@CachePut(value = "plan", key = "#pricingPlan.getPlanName()")
	public PricingPlanDTO addNewPricingPlan(PricingPlan pricingPlan) {

		try {
			return mapper.convertToDto(planRepo.save(pricingPlan), PricingPlanDTO.class);
		} catch (Exception e) {
			throw new CustomException("Error while saving new pricing plan " + pricingPlan.getPlanName().getName(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	@Cacheable(value = "plan", key = "#planName")
	public PricingPlanDTO getPricingPlan(PlanName planName) {
		Optional<PricingPlan> optional = planRepo.findByPlanName(planName);

		if (optional.isPresent()) {
			PricingPlanDTO dto = mapper.convertToDto(optional.get(), PricingPlanDTO.class);
			if (getPricing(pricingUuid).isOffer()) {
				dto.setPlanCost(calculateUtil.calculateDiscount(dto.getPlanCost(), dto.getDiscount()));
			}
			return dto;
		} else {
			throw new CustomException("Pricing Plan not found " + planName, HttpStatus.NOT_FOUND);
		}

	}

	@Override
	@Caching(put = { @CachePut(value = "pricing", key = "#pricing.getPricingUuid()") }, evict = {
			@CacheEvict(value = { "plan", "pricingTable" }, allEntries = true) })
	public Pricing savePricing(Pricing pricing) {

		try {
			return pricingRepo.save(pricing);
		} catch (Exception e) {
			throw new CustomException("Error while saving Pricing ", HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@Override
	@Cacheable(value = "pricing", key = "#pricingUuid")
	public Pricing getPricing(String pricingUuid) {

		Pricing pricing = pricingRepo.findByPricingUuidAndActiveTrue(pricingUuid);

		if (pricing != null) {
			return pricing;
		} else {
			throw new CustomException("Pricing details not found", HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@Override
	@Cacheable(value = "pricingTable", key = "#root.methodName")
	public Map<String, Object> getPricingTableData() {
		Map<String, Object> map = new LinkedHashMap<>();
		Pricing pricing = getPricing(pricingUuid);
		map.put("offer", pricing.isOffer());
		if (pricing.isOffer()) {
			map.put("offerStartDate", pricing.getOfferStartDate());
			map.put("offerEndDate", pricing.getOfferEndDate());
		}

		PlanName[] planNames = PlanName.values();
		for (PlanName planName : planNames) {
			Optional<PricingPlan> optional = planRepo.findByPlanName(planName);
			if (optional.isPresent()) {
				PricingPlanDTO dto = mapper.convertToDto(optional.get(), PricingPlanDTO.class);
				if (pricing.isOffer() && !dto.getPlanName().equals(PlanName.FREE_BUSINESS)) {
					dto.setDiscountedCost(calculateUtil.calculateDiscount(dto.getPlanCost(), dto.getDiscount()));
				}
				map.put(planName.toString().toLowerCase(), dto);
			}
		}
		return map;
	}

	@Override
	@CachePut(value = "userPricing", key = "#userPricing.getsUuid()")
	public UserPricingDTO saveUserPricing(UserPricing userPricing) {

		try {
			return mapper.convertToDto(userPricingRepo.save(userPricing), UserPricingDTO.class);
		} catch (Exception e) {
			throw new CustomException("Error while saving User Pricing", HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@Override
	@Cacheable(value = "userPricing", key = "#sUuid")
	public UserPricingDTO getUserPricing(String sUuid) {
		Optional<UserPricing> optional = userPricingRepo.findBySUuid(sUuid);

		if (optional.isPresent()) {
			return mapper.convertToDto(optional.get(), UserPricingDTO.class);
		} else {
			throw new CustomException("Pricing Details not found for user " + sUuid, HttpStatus.NOT_FOUND);
		}

	}

	@Override
	@Cacheable(value = "unitCosting")
	public UnitCostDTO getUnitCosting() {

		return mapper.convertToDto(getPricing(pricingUuid), UnitCostDTO.class);
	}

}
