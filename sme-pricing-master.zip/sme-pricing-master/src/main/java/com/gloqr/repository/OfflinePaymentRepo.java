package com.gloqr.repository;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gloqr.entity.OfflinePaymentDetails;
import com.gloqr.payment.PaymentUtility;

@Repository
public interface OfflinePaymentRepo extends JpaRepository<OfflinePaymentDetails, Long> {

	List<OfflinePaymentDetails> findByUserUUID(String userUUID);

	OfflinePaymentDetails findFirstByUserUUIDAndPaymentUtilityAndRejectedFalseAndVerifiedFalse(String userUUID,
			PaymentUtility paymentUtility, Sort sort);

	OfflinePaymentDetails findByOfflinePaymentUuidAndVerifiedFalseAndRejectedFalse(String offlinePaymentUuid);

}
