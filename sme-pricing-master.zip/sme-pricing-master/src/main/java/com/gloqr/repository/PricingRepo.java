package com.gloqr.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.entity.Pricing;

public interface PricingRepo extends JpaRepository<Pricing, Long> {

	Pricing findByPricingUuidAndActiveTrue(String pricingUuid);

}
