package com.gloqr.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gloqr.entity.PaymentOrder;
import com.gloqr.payment.PaymentStatus;
import com.gloqr.payment.PaymentUtility;

@Repository
public interface PaymentOrderRepo extends JpaRepository<PaymentOrder, Long> {
	Optional<PaymentOrder> findByOrderID(String orderId);

	PaymentOrder findByUserUUIDAndPaymentStatusAndPaymentUtility(String userUUID, PaymentStatus paymentStatus,
			PaymentUtility paymentUtility);

	List<PaymentOrder> findByUserUUIDAndPaymentStatusAndPaymentUtilityNotIn(String userUUID,
			PaymentStatus paymentStatus, PaymentUtility paymentUtility);

}
