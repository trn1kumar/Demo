package com.gloqr.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.gloqr.entity.PaymentDetails;
import com.gloqr.entity.PaymentOrder;
import com.gloqr.entity.UserPricing;
import com.gloqr.exception.CustomException;
import com.gloqr.payment.PaymentStatus;
import com.gloqr.pricing.PricingPlanMaster;
import com.razorpay.Payment;

@Component
public class Mapper {
	public <T> T convertToEntity(Object srcObj, Class<T> targetClass) {
		T entity = null;

		try {
			entity = new ModelMapper().map(srcObj, targetClass);
		} catch (Exception e) {
			throw new CustomException("Error while converting DTO to Entity", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return entity;
	}

	public <T> T convertToDto(Object srcObj, Class<T> targetClass) {
		T dto = null;

		try {
			dto = new ModelMapper().map(srcObj, targetClass);
		} catch (Exception e) {
			throw new CustomException("Error while converting Entity to DTO", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return dto;
	}

	public UserPricing convertUpgradedPlanToEntity(PricingPlanMaster pricingPlan, UserPricing userPricing) {

		try {
			userPricing.setBiReadCredits(pricingPlan.getBiReadCredits());
			userPricing.setBusinessPosts(pricingPlan.getBusinessPosts());
			userPricing.setConnections(pricingPlan.getConnections());
			userPricing.setImageStorageSize(pricingPlan.getImageStorageSize());
			userPricing.setJobPostings(pricingPlan.getJobPostings());
			userPricing.setListings(pricingPlan.getListings());
		} catch (CustomException e) {
			throw new CustomException("Error while upgrading plan", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return userPricing;
	}

	public PaymentOrder convertToPaymentOrder(Payment payment, PaymentOrder paymentOrder) {
		
		paymentOrder.setPaymentStatus(PaymentStatus.CAPTURED);
		paymentOrder.setPaymentID(payment.get("id"));
		paymentOrder.setPaymentDetails(new PaymentDetails());
		paymentOrder.getPaymentDetails().setPaymentMethod(payment.get("method"));
		paymentOrder.getPaymentDetails().setCurrency(payment.get("currency"));
		paymentOrder.getPaymentDetails().setPaymentCreatedAt(payment.get("created_at"));
		paymentOrder.getPaymentDetails().setUserEmail(payment.get("email"));
		paymentOrder.getPaymentDetails().setUserMobile(payment.get("contact"));

		if (!payment.get("bank").equals(null)) {
			paymentOrder.getPaymentDetails().setBank(payment.get("bank"));
		}

		if (!payment.get("wallet").equals(null)) {
			paymentOrder.getPaymentDetails().setWallet(payment.get("wallet"));
		}
		if (!payment.get("vpa").equals(null)) {
			paymentOrder.getPaymentDetails().setVpa(payment.get("vpa"));
		}
		
		return paymentOrder;
	}
}
