package com.gloqr.exception;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.gloqr.dto.CustomHttpResponse;
import com.gloqr.util.ResponseMaker;

@RestControllerAdvice
public class GlobleExceptionHandler extends ResponseEntityExceptionHandler {
	Logger log = LogManager.getLogger();
	@Autowired
	private ResponseMaker responseMaker;

	@ExceptionHandler(CustomException.class)
	public ResponseEntity<CustomHttpResponse<Object>> customExceptionHandler(CustomException e) {

		return responseMaker.errorResponse(e.getMessage(), e.getStatus());
	}

	@ExceptionHandler(NoCreditException.class)
	public ResponseEntity<CustomHttpResponse<Object>> noCreditExceptionHandler(NoCreditException e) {

		return responseMaker.noCreditsResponse(e.geCreditType());
	}

	@ExceptionHandler(NullPointerException.class)
	public ResponseEntity<Object> nullPointerHandler(NullPointerException e) {
		String msg = "Something went wrong...Please try again later";
		log.error(e);
		return new ResponseEntity<>(responseMaker.errorResponse(msg, HttpStatus.INTERNAL_SERVER_ERROR), HttpStatus.OK);
	}

	@ExceptionHandler(MaxUploadSizeExceededException.class)
	public ResponseEntity<CustomHttpResponse<Object>> maxSizeHandler(MaxUploadSizeExceededException e) {

		return responseMaker.errorResponse("Maximum upload size exceeded..Max 300KB size permitted",
				HttpStatus.BAD_REQUEST);
	}

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		List<String> errors = errorslist(ex.getBindingResult());

		return new ResponseEntity<>(new ValidationErrors(errors), HttpStatus.BAD_REQUEST);
	}

	private List<String> errorslist(Errors errors) {
		List<String> validErrors = new ArrayList<>();
		for (ObjectError objectError : errors.getAllErrors()) {
			validErrors.add(objectError.getDefaultMessage());
		}
		return validErrors;
	}
}