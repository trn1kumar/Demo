package com.gloqr.controller;

import java.io.IOException;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.gloqr.constants.Constants;
import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.CustomHttpResponse;
import com.gloqr.entity.OfflinePaymentDetails;
import com.gloqr.exception.CustomException;
import com.gloqr.payment.dto.CapturePayment;
import com.gloqr.payment.dto.CreatePayment;
import com.gloqr.payment.dto.CreditsCost;
import com.gloqr.payment.dto.OfflinePaymentResponse;
import com.gloqr.payment.dto.PaymentDetailsDTO;
import com.gloqr.payment.dto.PaymentRequest;
import com.gloqr.payment.dto.VerifyPayment;
import com.gloqr.pricing.CreditType;
import com.gloqr.service.PaymentService;
import com.gloqr.util.RequestParser;
import com.gloqr.util.ResponseMaker;

@RestController
@RequestMapping(UrlMapping.BASE_URL)
public class PaymentController {

	@Autowired
	private PaymentService paymentService;

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private RequestParser requestParser;

	@PreAuthorize(Constants.ROLE_SME_AND_USER)
	@PostMapping(UrlMapping.OFFLINE_PAYMENT)
	public ResponseEntity<CustomHttpResponse<OfflinePaymentResponse>> createOfflinePayment(
			MultipartHttpServletRequest request, @FormDataParam("file") MultipartFile file) throws IOException {

		OfflinePaymentDetails offlinePaymentDetails = requestParser.parseJsonData(request, "offlinePaymentData",
				OfflinePaymentDetails.class);

		if (StringUtils.isBlank(offlinePaymentDetails.getUserUUID()) || offlinePaymentDetails.getPlanName() == null
				|| offlinePaymentDetails.getPaymentUtility() == null) {
			throw new CustomException("Please provide correct data", HttpStatus.BAD_REQUEST);
		}

		return responseMaker.successResponse(
				paymentService.createOfflinePayment(offlinePaymentDetails, file, requestParser.getHeader()),
				HttpStatus.CREATED);
	}

	@PostMapping(UrlMapping.CREATE_PAYMENT)
	@PreAuthorize(Constants.ROLE_SME_AND_USER)
	public ResponseEntity<CustomHttpResponse<CreatePayment>> createPayment(@RequestBody @Valid PaymentRequest request) {

		String tokenUserUUID = requestParser.getUserUUID();

		if (tokenUserUUID.equals(request.getUserUUID())) {
			return responseMaker.successResponse(paymentService.createPayment(request), HttpStatus.CREATED);
		} else {
			throw new CustomException("Invalid token...UserUUID not matched", HttpStatus.BAD_REQUEST);
		}

	}

	@PostMapping(UrlMapping.CAPTURE_PAYMENT)
	@PreAuthorize(Constants.ROLE_SME_AND_USER)
	public ResponseEntity<CustomHttpResponse<String>> capturePayment(
			@RequestBody @Valid CapturePayment capturePayment) {

		paymentService.capturePayment(capturePayment);

		return responseMaker.successResponse("Payment Succesfully Captured", HttpStatus.CREATED);

	}

	@GetMapping(UrlMapping.CREDITS_COST)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<CreditsCost>> calculatePayment(
			@RequestParam(value = "credits", defaultValue = "1") long credits,
			@RequestParam(value = "type") CreditType creditType) {

		if (credits == 0) {
			credits = 1;
		}

		return responseMaker.successResponse(paymentService.calculateCreditsCost(credits, creditType), HttpStatus.OK);
	}

	@PutMapping(UrlMapping.VERIFY_OFFLINE_PAYMENT)
	@PreAuthorize(Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<String>> verifyOfflinePayment(
			@RequestBody @Valid VerifyPayment verifyPayment) {

		verifyPayment.setModifierID(requestParser.getLoginID());
		verifyPayment.setModifierName(requestParser.getUserName());
		paymentService.verifyOfflinePayment(verifyPayment, requestParser.getHeader());

		return responseMaker.successResponse(
				"Pricing Plan Upgraded successfully for SME :: " + verifyPayment.getsUuid(), HttpStatus.CREATED);
	}

	@GetMapping(UrlMapping.PAYMENT_DETAILS)
	@PreAuthorize(Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<PaymentDetailsDTO>> getPaymentDetails(
			@RequestParam(value = "u") String userUUID, @RequestParam(value = "s") String sUuid) {

		return responseMaker.successResponse(paymentService.getPaymentDetails(userUUID, sUuid), HttpStatus.OK);
	}

	@GetMapping(UrlMapping.CHECK_PAYMENT_COMPLETED)
	@PreAuthorize(Constants.ROLE_USER)
	public ResponseEntity<CustomHttpResponse<String>> isPaymentCompleted(@RequestParam(value = "u") String userUUID) {

		paymentService.isUserPaymentCompleted(userUUID);

		return responseMaker.successResponse("Please select plan to continue", HttpStatus.OK);
	}

}
