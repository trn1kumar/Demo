package com.gloqr.controller;

import java.util.Map;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.Constants;
import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.CustomHttpResponse;
import com.gloqr.exception.CustomException;
import com.gloqr.exception.NoCreditException;
import com.gloqr.payment.dto.PaymentRequest;
import com.gloqr.pricing.CreditType;
import com.gloqr.pricing.dto.CreditsCheckResponse;
import com.gloqr.pricing.dto.PricingDTO;
import com.gloqr.pricing.dto.PricingPlanDTO;
import com.gloqr.pricing.dto.PricingRequest;
import com.gloqr.pricing.dto.UserDTO;
import com.gloqr.pricing.dto.UserPricingDTO;
import com.gloqr.service.PricingService;
import com.gloqr.util.RequestParser;
import com.gloqr.util.ResponseMaker;

@RestController
@RequestMapping(UrlMapping.BASE_URL)
public class PricingController {

	@Autowired
	private PricingService pricingService;

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private RequestParser requestParser;

	@PostMapping(UrlMapping.NEW_PLAN)
	@PreAuthorize(Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<String>> addNewPackage(@RequestBody @Valid PricingPlanDTO planDTO) {
		pricingService.addNewPricingPlan(planDTO);
		return responseMaker.successResponse("Package Added Successfully", HttpStatus.OK);
	}

	@GetMapping(UrlMapping.PRICING_PLANS)
	public ResponseEntity<CustomHttpResponse<Map<String, Object>>> getPricing() {
		return responseMaker.successResponse(pricingService.getPricingTableData(), HttpStatus.OK);
	}

	@PostMapping(UrlMapping.NEW_USER)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> createNewUser(@RequestBody @Valid UserDTO userDTO) {
		String userUUID = requestParser.getUserUUID();
		String sUuid = requestParser.getSuuid();

		if (userUUID.equals(userDTO.getUuid()) && sUuid.equals(userDTO.getsUuid())) {
			pricingService.createNewUser(sUuid, userUUID);
		} else {
			throw new CustomException("UserUUID or SME UUID not matched with token", HttpStatus.BAD_REQUEST);
		}

		return responseMaker.successResponse("New User Added Successfully", HttpStatus.OK);
	}

	@GetMapping(UrlMapping.USER_PRICING)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<UserPricingDTO>> getUserPricing() {

		return responseMaker.successResponse(pricingService.getUserPricingDetails(requestParser.getSuuid()),
				HttpStatus.OK);
	}

	@GetMapping(UrlMapping.USER_CREDITS)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<CreditsCheckResponse>> checkCredits(
			@RequestParam(value = "type") CreditType creditType) {

		long credits = pricingService.checkCredits(requestParser.getSuuid(), creditType);

		if (credits > 0) {
			return responseMaker.successResponse(new CreditsCheckResponse(credits, creditType), HttpStatus.OK);
		} else {
			throw new NoCreditException(creditType);
		}

	}

	@PutMapping(UrlMapping.USER_CREDITS)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> updateCredits(@RequestBody @Valid PricingRequest request) {

		request.setsUuid(requestParser.getSuuid());
		request.setUserUUID(requestParser.getUserUUID());

		pricingService.updateCredits(request);

		return responseMaker.successResponse("Successfully " + request.getAction().getValue(), HttpStatus.OK);
	}

	@PutMapping(UrlMapping.ADMIN_UPDATE_CREDITS)
	@PreAuthorize(Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<String>> adminUpdateCredits(@RequestBody @Valid PricingRequest request) {

		if (StringUtils.isNotBlank(request.getsUuid()) && StringUtils.isNotBlank(request.getUserUUID())) {
			request.setSource("Gloqr Admin");
			request.setUsedFor("Rejected By Gloqr Admin");
			pricingService.updateCredits(request);
		} else {
			throw new CustomException("User ID and SME ID cannot be null or empty", HttpStatus.BAD_REQUEST);
		}

		return responseMaker.successResponse("Successfully " + request.getAction().getValue(), HttpStatus.OK);
	}

	@PostMapping(UrlMapping.PLAN_COST)
	@PreAuthorize(Constants.ROLE_SME_AND_USER)
	public ResponseEntity<CustomHttpResponse<Map<String, Object>>> planPurchase(@RequestBody PaymentRequest request) {

		return responseMaker.successResponse(pricingService.planPurchase(request, requestParser.isSME()),
				HttpStatus.OK);
	}

	@PutMapping(UrlMapping.PRICING)
	@PreAuthorize(Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<String>> updatePricing(@RequestBody @Valid PricingDTO pricingDTO) {

		pricingService.updatePricing(pricingDTO);

		return responseMaker.successResponse("Pricing Successfuly Updated..", HttpStatus.OK);
	}

}
