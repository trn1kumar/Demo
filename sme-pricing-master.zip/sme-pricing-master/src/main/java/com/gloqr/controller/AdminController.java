package com.gloqr.controller;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.CustomHttpResponse;
import com.gloqr.exception.CustomException;
import com.gloqr.exception.NoCreditException;
import com.gloqr.pricing.CreditType;
import com.gloqr.pricing.dto.CreditsCheckResponse;
import com.gloqr.pricing.dto.PricingRequest;
import com.gloqr.service.PricingService;
import com.gloqr.util.ResponseMaker;

@RestController
@RequestMapping(UrlMapping.BASE_URL)
public class AdminController {

	@Autowired
	private PricingService pricingService;

	@Autowired
	private ResponseMaker responseMaker;

	@Value(value = "${internal.secret.key}")
	private String secretKey;

	@GetMapping(UrlMapping.INTERNAL_ADMIN_CREDITS)
	public ResponseEntity<CustomHttpResponse<CreditsCheckResponse>> checkCredits(
			@RequestParam(value = "type") CreditType creditType, @RequestParam(value = "s") String sUuid,
			@RequestParam(value = "key") String key) {

		if (!key.equals(secretKey)) {
			throw new CustomException("Forbidden", HttpStatus.FORBIDDEN);
		}

		long credits = pricingService.checkCredits(sUuid, creditType);

		if (credits > 0) {
			return responseMaker.successResponse(new CreditsCheckResponse(credits, creditType), HttpStatus.OK);
		} else {
			throw new NoCreditException(creditType);
		}

	}

	@PutMapping(UrlMapping.INTERNAL_ADMIN_CREDITS)
	public ResponseEntity<CustomHttpResponse<String>> adminUpdateCredits(@RequestBody @Valid PricingRequest request,
			@RequestParam(value = "key") String key) {

		if (!key.equals(secretKey)) {
			throw new CustomException("Forbidden", HttpStatus.FORBIDDEN);
		}

		if (StringUtils.isNotBlank(request.getsUuid()) && StringUtils.isNotBlank(request.getUserUUID())) {
			request.setSource("Gloqr Admin");
			pricingService.updateCredits(request);
		} else {
			throw new CustomException("User ID and SME ID cannot be null or empty", HttpStatus.BAD_REQUEST);
		}

		return responseMaker.successResponse("Successfully " + request.getAction().getValue(), HttpStatus.OK);
	}

}
