package com.gloqr.endpoints;

import javax.ws.rs.client.Client;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.gloqr.dto.CustomHttpResponse;
import com.gloqr.pricing.dto.UserDTO;

public class UserEndpoint {

	private Client client;
	private String userEndpointURL;
	private String getUserDetailsPath;

	public UserEndpoint(Client client, String userEndpointURL, String getUserDetailsPath) {
		super();
		this.client = client;
		this.userEndpointURL = userEndpointURL;
		this.getUserDetailsPath = getUserDetailsPath;
	}

	Logger logger = LogManager.getLogger(UserEndpoint.class.getName());

	public UserDTO getUserDetails(String userUUID) {
		CustomHttpResponse<UserDTO> userDTO = null;
		try {
			Response response = client.target(userEndpointURL).path(getUserDetailsPath.replace("{userUUID}", userUUID))
					.request(MediaType.APPLICATION_JSON).get();

			logger.info(response.toString());

			if (response.getStatus() == 200) {
				userDTO = response.readEntity(new GenericType<CustomHttpResponse<UserDTO>>() {
				});
				return userDTO.getData();
			} else {
				logger.info("Error while getting Details from User Module for user id " + userUUID);
			}
		} catch (Exception e) {
			logger.info(e.toString());
		}

		return null;
	}
}
