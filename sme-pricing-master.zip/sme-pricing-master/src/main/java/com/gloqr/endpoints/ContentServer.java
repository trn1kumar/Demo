package com.gloqr.endpoints;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.glassfish.jersey.media.multipart.MultiPart;
import org.glassfish.jersey.media.multipart.file.FileDataBodyPart;
import org.springframework.http.HttpStatus;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.dto.FileUploadResponse;
import com.gloqr.exception.CustomException;

public class ContentServer {
	Logger logger = LogManager.getLogger();

	private Client client;
	private String contentServerEndPoint;
	private String uploadFile;
	private String deleteFile;

	public ContentServer(Client client, String contentServerEndPoint, String uploadFile, String deleteFile) {
		super();
		this.client = client;
		this.contentServerEndPoint = contentServerEndPoint;
		this.uploadFile = uploadFile;
		this.deleteFile = deleteFile;
	}

	public FileUploadResponse sendSingleFile(MultipartFile file, String imageName, String fileLocation)
			throws IOException {

		Response response = null;

		WebTarget webTarget = client.target(contentServerEndPoint).path(this.uploadFile).path(fileLocation);
		File tempFile = convert(file, imageName);

		try (MultiPart multiPart = new MultiPart()) {

			multiPart.setMediaType(MediaType.MULTIPART_FORM_DATA_TYPE);
			FileDataBodyPart fileDataBodyPart = new FileDataBodyPart("files", tempFile,
					MediaType.APPLICATION_OCTET_STREAM_TYPE);
			multiPart.bodyPart(fileDataBodyPart);

			response = webTarget.request(MediaType.APPLICATION_JSON_TYPE)
					.post(Entity.entity(multiPart, multiPart.getMediaType()));
			cleanUp(tempFile.toPath());
		} catch (Exception e) {
			cleanUp(tempFile.toPath());
			throw new CustomException(e.getMessage(), HttpStatus.BAD_REQUEST);
		}

		logger.info(response.toString());

		if (response.getStatus() != HttpStatus.OK.value()) {
			throw new CustomException("Error occured while uploading file to content server", HttpStatus.CONFLICT);
		}

		return response.readEntity(FileUploadResponse.class);

	}

	public void deleteFileFromContentServer(String fileLocation) {

		Response response = null;
		try {
			response = client.target(contentServerEndPoint).path(deleteFile).path(fileLocation)
					.request(MediaType.APPLICATION_JSON).delete();
		} catch (Exception e) {
			throw new CustomException("Error while deleting Service Image from ContentServer",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

		logger.info(response.toString());

		Integer responseCode = response.getStatus();

		if (responseCode != HttpStatus.OK.value()) {
			throw new CustomException("Error occured while deleting image from contentserver", HttpStatus.CONFLICT);
		}

	}

	public File convert(MultipartFile file, String name) throws IOException {

		File convFile = new File(name);
		if (convFile.createNewFile()) {
			try (FileOutputStream fos = new FileOutputStream(convFile);) {
				fos.write(file.getBytes());
			} catch (Exception e) {
				logger.info("Error while converting file");
				throw e;
			}
		}
		return convFile;
	}

	public void cleanUp(Path path) throws IOException {
		Files.delete(path);
	}
}
