package com.gloqr.payment.dto;

import javax.validation.constraints.NotBlank;

public class CapturePayment {

	@NotBlank(message = "{payment.id}")
	private String razorpayPaymentID;
	private String razorpayOrderID;
	private String razorpaySignature;

	public String getRazorpayPaymentID() {
		return razorpayPaymentID;
	}

	public String getRazorpayOrderID() {
		return razorpayOrderID;
	}

	public String getRazorpaySignature() {
		return razorpaySignature;
	}

	public void setRazorpayPaymentID(String razorpayPaymentID) {
		this.razorpayPaymentID = razorpayPaymentID;
	}

	public void setRazorpayOrderID(String razorpayOrderID) {
		this.razorpayOrderID = razorpayOrderID;
	}

	public void setRazorpaySignature(String razorpaySignature) {
		this.razorpaySignature = razorpaySignature;
	}

	@Override
	public String toString() {
		return "CapturePayment [razorpayPaymentID=" + razorpayPaymentID + ", razorpayOrderID=" + razorpayOrderID
				+ ", razorpaySignature=" + razorpaySignature + "]";
	}

}
