package com.gloqr.payment;

public enum OfflinePaymentBy {

	CHEQUE,
	BANKTRANSFER;
}
