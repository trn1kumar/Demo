package com.gloqr.payment.dto;

public class CreatePayment {

	private String key;
	private Double amount;
	private String name;
	private String description;
	private Prefill prefill;
	private String orderID;

	public CreatePayment(String key, String name) {
		super();
		this.key = key;
		this.name = name;
	}

	public String getKey() {
		return key;
	}

	public Double getAmount() {
		return amount;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	public Prefill getPrefill() {
		return prefill;
	}

	public String getOrderID() {
		return orderID;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setPrefill(Prefill prefill) {
		this.prefill = prefill;
	}

	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}

}
