package com.gloqr.payment.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.gloqr.entity.OfflinePaymentDetails;
import com.gloqr.entity.PaymentOrder;
import com.gloqr.payment.PaymentMode;
import com.gloqr.pricing.PlanName;

@JsonInclude(Include.NON_NULL)
public class PaymentDetailsDTO {

	private PlanName currentPlanName;
	private List<PaymentOrder> onlineDetails;
	private List<OfflinePaymentDetails> offlineDetails;
	private PaymentMode paymentMode;
	String planDisplayName;

	public String getPlanDisplayName() {
		return currentPlanName.getName();
	}

	public PlanName getCurrentPlanName() {
		return currentPlanName;
	}

	public void setCurrentPlanName(PlanName currentPlanName) {
		this.currentPlanName = currentPlanName;
	}

	public List<PaymentOrder> getOnlineDetails() {
		return onlineDetails;
	}

	public void setOnlineDetails(List<PaymentOrder> onlineDetails) {
		this.onlineDetails = onlineDetails;
	}

	public List<OfflinePaymentDetails> getOfflineDetails() {
		return offlineDetails;
	}

	public void setOfflineDetails(List<OfflinePaymentDetails> offlineDetails) {
		this.offlineDetails = offlineDetails;
	}

	public PaymentMode getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(PaymentMode paymentMode) {
		this.paymentMode = paymentMode;
	}

}
