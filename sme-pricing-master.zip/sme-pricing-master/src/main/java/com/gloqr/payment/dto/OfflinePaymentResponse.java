package com.gloqr.payment.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.gloqr.entity.OfflinePaymentDetails;
@JsonInclude(Include.NON_NULL)
public class OfflinePaymentResponse {

	private int code;
	private OfflinePaymentDetails details;
	private String message;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public OfflinePaymentDetails getDetails() {
		return details;
	}

	public void setDetails(OfflinePaymentDetails details) {
		this.details = details;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
