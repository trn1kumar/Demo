package com.gloqr.payment;

public enum PaymentStatus {

	ATTEMPTED,AUTHORIZED,CAPTURED,REFUNDED,FAILED;
	
}
