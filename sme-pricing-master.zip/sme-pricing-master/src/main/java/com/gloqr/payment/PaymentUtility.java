package com.gloqr.payment;

public enum PaymentUtility {

	UPGRADE_PACKAGE,
	NEW_PACKAGE,
	BUSINESS_CREDITS;
	
}
