package com.gloqr.payment;

public enum PaymentMode {

	ONLINE,OFFLINE,STARTED_AS_FREE
}
