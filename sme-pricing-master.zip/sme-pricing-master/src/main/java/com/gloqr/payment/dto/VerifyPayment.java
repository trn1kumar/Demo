package com.gloqr.payment.dto;

import javax.validation.constraints.NotNull;

public class VerifyPayment {

	@NotNull(message = "{offline.payment.uuid}")
	private String offlinePaymentUuid;
	@NotNull(message = "{sUuid}")
	private String sUuid;
	private boolean verified;
	private String rejectReason;
	private String modifierName;
	private String modifierID;

	public String getModifierName() {
		return modifierName;
	}

	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

	public String getModifierID() {
		return modifierID;
	}

	public void setModifierID(String modifierID) {
		this.modifierID = modifierID;
	}

	public String getsUuid() {
		return sUuid;
	}

	public String getOfflinePaymentUuid() {
		return offlinePaymentUuid;
	}

	public boolean isVerified() {
		return verified;
	}

	public String getRejectReason() {
		return rejectReason;
	}

}
