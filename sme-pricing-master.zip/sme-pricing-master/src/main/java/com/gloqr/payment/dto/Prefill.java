package com.gloqr.payment.dto;

import com.gloqr.pricing.dto.UserDTO;

public class Prefill {

	private String name;
	private String email;
	private Long contact;

	public Prefill(UserDTO userDTO) {
		super();
		this.name = userDTO.getUserFullName();
		if (userDTO.getUserMobile() != null) {
			this.contact = userDTO.getUserMobile();
		}
		if (userDTO.getUserEmail() != null) {
			this.email = userDTO.getUserEmail();
		}
	}

	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}

	public Long getContact() {
		return contact;
	}
}
