package com.gloqr.payment.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.gloqr.payment.PaymentUtility;
import com.gloqr.pricing.CreditType;
import com.gloqr.pricing.PlanName;

public class PaymentRequest {

	@NotBlank(message = "{userUUID}")
	private String userUUID;
	private String sUuid;
	private CreditType creditType;
	private long credits;
	@NotNull(message = "{payment.utility}")
	private PaymentUtility paymentUtility;
	private PlanName planName;

	public String getUserUUID() {
		return userUUID;
	}

	public String getsUuid() {
		return sUuid;
	}

	public CreditType getCreditType() {
		return creditType;
	}

	public long getCredits() {
		return credits;
	}

	public PaymentUtility getPaymentUtility() {
		return paymentUtility;
	}

	public PlanName getPlanName() {
		return planName;
	}

	@Override
	public String toString() {
		return "PaymentRequest [userUUID=" + userUUID + ", sUuid=" + sUuid + ", creditType=" + creditType + ", credits="
				+ credits + ", paymentUtility=" + paymentUtility + ", planName=" + planName + "]";
	}

}
