package com.gloqr.payment.dto;

import com.gloqr.pricing.CreditType;

public class CreditsCost {

	private long credits;
	private double unitCost;
	private double basePrice;
	private double totalPrice;
	private double addedGST;
	private CreditType creditType;
	String typeDisplayName;

	public CreditsCost(long credits, double unitCost, double basePrice, double totalPrice, double addedGST,
			CreditType creditType) {
		super();
		this.credits = credits;
		this.unitCost = unitCost;
		this.basePrice = basePrice;
		this.totalPrice = totalPrice;
		this.addedGST = addedGST;
		this.creditType = creditType;
	}

	public long getCredits() {
		return credits;
	}

	public double getUnitCost() {
		return unitCost;
	}

	public double getBasePrice() {
		return basePrice;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public double getAddedGST() {
		return addedGST;
	}

	public CreditType getCreditType() {
		return creditType;
	}

	public String getTypeDisplayName() {
		return creditType.getValue();
	}
}
