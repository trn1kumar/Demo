package com.gloqr.pricing;

public abstract class PricingPlanDecorator implements PricingPlanMaster {

	protected PricingPlanMaster pricingPlan;

	public PricingPlanDecorator(PricingPlanMaster pricingPlan) {
		super();
		this.pricingPlan = pricingPlan;
	}

}
