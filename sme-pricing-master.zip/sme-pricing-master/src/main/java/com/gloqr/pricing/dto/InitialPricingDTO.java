package com.gloqr.pricing.dto;

import java.io.Serializable;

public class InitialPricingDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private long listings;
	private long connections;
	private long biReadCredits;
	private long imageStorageSize;
	private long jobPostings;
	private long businessPosts;

	public long getListings() {
		return listings;
	}

	public long getConnections() {
		return connections;
	}

	public long getBiReadCredits() {
		return biReadCredits;
	}

	public long getImageStorageSize() {
		return imageStorageSize;
	}

	public long getJobPostings() {
		return jobPostings;
	}

	public long getBusinessPosts() {
		return businessPosts;
	}

	public void setListings(long listings) {
		this.listings = listings;
	}

	public void setConnections(long connections) {
		this.connections = connections;
	}

	public void setBiReadCredits(long biReadCredits) {
		this.biReadCredits = biReadCredits;
	}

	public void setImageStorageSize(long imageStorageSize) {
		this.imageStorageSize = imageStorageSize;
	}

	public void setJobPostings(long jobPostings) {
		this.jobPostings = jobPostings;
	}

	public void setBusinessPosts(long businessPosts) {
		this.businessPosts = businessPosts;
	}

}
