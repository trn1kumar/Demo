package com.gloqr.pricing.dto;

import java.util.Date;

import javax.validation.constraints.NotBlank;

public class PricingDTO extends UnitCostDTO {

	private static final long serialVersionUID = 1L;

	@NotBlank(message = "{pricing.plan}")
	private String pricingUuid;
	private Date offerEndDate;
	private Date offerStartDate;
	private boolean offer;
	private double gst;
	private int monthlyCreditPeriod;
	private String merchantName;
	private String accountName;
	private long accountNumber;
	private String bankName;
	private String bankIFSCCode;

	public String getPricingUuid() {
		return pricingUuid;
	}

	public Date getOfferEndDate() {
		return offerEndDate;
	}

	public Date getOfferStartDate() {
		return offerStartDate;
	}

	public boolean isOffer() {
		return offer;
	}

	public double getGst() {
		return gst;
	}

	public int getMonthlyCreditPeriod() {
		return monthlyCreditPeriod;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public String getAccountName() {
		return accountName;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public String getBankName() {
		return bankName;
	}

	public String getBankIFSCCode() {
		return bankIFSCCode;
	}

}
