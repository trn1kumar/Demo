package com.gloqr.pricing.dto;

import java.io.Serializable;

public class UnitCostDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private double listingCost;
	private double connectionCost;
	private double biReadCost;
	private double storageCost;
	private double jobPostCost;
	private double businessPostCost;

	public double getListingCost() {
		return listingCost;
	}

	public double getConnectionCost() {
		return connectionCost;
	}

	public double getBiReadCost() {
		return biReadCost;
	}

	public double getStorageCost() {
		return storageCost;
	}

	public double getJobPostCost() {
		return jobPostCost;
	}

	public double getBusinessPostCost() {
		return businessPostCost;
	}

	public void setListingCost(double listingCost) {
		this.listingCost = listingCost;
	}

	public void setConnectionCost(double connectionCost) {
		this.connectionCost = connectionCost;
	}

	public void setBiReadCost(double biReadCost) {
		this.biReadCost = biReadCost;
	}

	public void setStorageCost(double storageCost) {
		this.storageCost = storageCost;
	}

	public void setJobPostCost(double jobPostCost) {
		this.jobPostCost = jobPostCost;
	}

	public void setBusinessPostCost(double businessPostCost) {
		this.businessPostCost = businessPostCost;
	}

}
