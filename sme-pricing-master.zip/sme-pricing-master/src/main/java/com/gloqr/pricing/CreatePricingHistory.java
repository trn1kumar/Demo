package com.gloqr.pricing;

import com.gloqr.pricing.dto.PricingRequest;

public class CreatePricingHistory implements PricingHistory {

	private long currentCredits;
	private PricingRequest request;

	public CreatePricingHistory(PricingRequest request, long currentCredits) {
		super();
		this.currentCredits = currentCredits;
		this.request = request;
	}

	@Override
	public String getUserUUID() {
		return request.getUserUUID();
	}

	@Override
	public String getsUuid() {
		return request.getsUuid();
	}

	@Override
	public String getSource() {
		if (request.getSource() != null) {
			return request.getSource();
		}
		return "User";
	}

	@Override
	public String getType() {
		return request.getCreditType().getValue();
	}

	@Override
	public long getCurrentCredits() {
		if (request.getAction().equals(Action.DEBIT)) {
			return this.currentCredits - request.getCredits();
		}
		return this.currentCredits + request.getCredits();
	}

	@Override
	public long getPreviousCredits() {
		return currentCredits;
	}

	@Override
	public long getCredit() {
		if (request.getAction().equals(Action.CREDIT)) {
			return request.getCredits();
		}
		return 0;
	}

	@Override
	public long getDebit() {
		if (request.getAction().equals(Action.DEBIT)) {
			return request.getCredits();
		}
		return 0;
	}

	@Override
	public String getUsedFor() {
		return request.getUsedFor();
	}

}
