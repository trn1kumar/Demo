package com.gloqr.pricing;

public interface PricingPlanMaster {
	
	long getListings();

	long getConnections();

	long getBiReadCredits();

	long getImageStorageSize();

	long getJobPostings();

	long getBusinessPosts();
}
