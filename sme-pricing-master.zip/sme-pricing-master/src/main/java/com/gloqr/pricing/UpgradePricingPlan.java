package com.gloqr.pricing;

import com.gloqr.entity.UserPricing;

public class UpgradePricingPlan extends PricingPlanDecorator {

	UserPricing userPricing = null;

	public UpgradePricingPlan(PricingPlanMaster pricingPlan, UserPricing userPricing) {
		super(pricingPlan);
		this.userPricing = userPricing;
	}

	@Override
	public long getListings() {
		long listings = pricingPlan.getListings();
		userPricing.getInitialPricing().setListings(userPricing.getInitialPricing().getListings() + listings);
		return userPricing.getListings() + listings;
	}

	@Override
	public long getConnections() {
		long connections = pricingPlan.getConnections();
		userPricing.getInitialPricing().setConnections(userPricing.getInitialPricing().getConnections() + connections);
		return userPricing.getConnections() + connections;
	}

	@Override
	public long getBiReadCredits() {
		long biReadCredits = pricingPlan.getBiReadCredits() / 12;
		userPricing.getInitialPricing()
				.setBiReadCredits(userPricing.getInitialPricing().getBiReadCredits() + biReadCredits);
		return userPricing.getBiReadCredits() + biReadCredits;
	}

	@Override
	public long getImageStorageSize() {
		long imageStorage = pricingPlan.getImageStorageSize();
		userPricing.getInitialPricing()
				.setImageStorageSize(userPricing.getInitialPricing().getImageStorageSize() + imageStorage);
		return userPricing.getImageStorageSize() + imageStorage;
	}

	@Override
	public long getJobPostings() {
		long jobPostings = pricingPlan.getJobPostings();
		userPricing.getInitialPricing().setJobPostings(userPricing.getInitialPricing().getJobPostings() + jobPostings);
		return userPricing.getJobPostings() + jobPostings;
	}

	@Override
	public long getBusinessPosts() {
		long businessPost = pricingPlan.getBusinessPosts();
		userPricing.getInitialPricing()
				.setBusinessPosts(userPricing.getInitialPricing().getBusinessPosts() + businessPost);
		return userPricing.getBusinessPosts() + businessPost;
	}

}
