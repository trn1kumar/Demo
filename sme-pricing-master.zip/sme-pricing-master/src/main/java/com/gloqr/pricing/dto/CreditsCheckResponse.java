package com.gloqr.pricing.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.gloqr.pricing.CreditType;

@JsonInclude(Include.NON_NULL)
public class CreditsCheckResponse {

	private long credits;
	String displayName;
	private CreditType creditType;

	public CreditsCheckResponse(long credits, CreditType creditType) {
		super();
		this.credits = credits;
		this.creditType = creditType;
	}

	public long getCredits() {
		return credits;
	}

	public String getDisplayName() {
		return creditType.getValue();
	}

	public CreditType getCreditType() {
		return creditType;
	}

	public void setCredits(long credits) {
		this.credits = credits;
	}

	public void setCreditType(CreditType creditType) {
		this.creditType = creditType;
	}

}
