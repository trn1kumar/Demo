package com.gloqr.pricing;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.gloqr.entity.UserPricing;
import com.gloqr.entity.UserPricingHistory;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.Mapper;
import com.gloqr.pricing.dto.PricingRequest;
import com.gloqr.repository.PricingDao;
import com.gloqr.repository.PricingHistoryRepo;
import com.gloqr.util.CalculateUtil;

@Component
public class CreditsAction {

	@Autowired
	private PricingHistoryRepo historyRepo;

	@Autowired
	private PricingDao pricingDao;

	@Autowired
	private Mapper mapper;
	
	@Autowired
	private CalculateUtil calculate;

	public void credit(PricingRequest request, UserPricing userPricing) {

		UserPricingHistory userPricingHistory = null;
		PricingHistory pricingHistory = null;

		switch (request.getCreditType()) {

		case PRODUCT_SERVICE_LISTING:
			pricingHistory = createPricingHistory(request, userPricing.getListings());
			userPricing.setListings(pricingHistory.getCurrentCredits());
			if (request.isPurchase()) {
				userPricing.getInitialPricing()
						.setListings(userPricing.getInitialPricing().getListings() + request.getCredits());
			}
			check(userPricing.getListings(), userPricing.getInitialPricing().getListings());

			break;

		case BUSINESS_INTEREST_VIEW:
			pricingHistory = createPricingHistory(request, userPricing.getBiReadCredits());
			userPricing.setBiReadCredits(pricingHistory.getCurrentCredits());
			if (request.isPurchase()) {
				userPricing.getInitialPricing()
						.setBiReadCredits(userPricing.getInitialPricing().getBiReadCredits() + request.getCredits());
			}
			check(userPricing.getBiReadCredits(), userPricing.getInitialPricing().getBiReadCredits());
			break;

		case CIRCLE_CONNECTION:
			pricingHistory = createPricingHistory(request, userPricing.getConnections());
			userPricing.setConnections(pricingHistory.getCurrentCredits());
			if (request.isPurchase()) {
				userPricing.getInitialPricing()
						.setConnections(userPricing.getInitialPricing().getConnections() + request.getCredits());
			}
			check(userPricing.getConnections(), userPricing.getInitialPricing().getConnections());

			break;

		case BUSINESS_POST:
			pricingHistory = createPricingHistory(request, userPricing.getBusinessPosts());
			userPricing.setBusinessPosts(pricingHistory.getCurrentCredits());
			if (request.isPurchase()) {
				userPricing.getInitialPricing()
						.setBusinessPosts(userPricing.getInitialPricing().getBusinessPosts() + request.getCredits());
			}
			check(userPricing.getBusinessPosts(), userPricing.getInitialPricing().getBusinessPosts());
			break;

		case JOB_POSTING:
			pricingHistory = createPricingHistory(request, userPricing.getJobPostings());
			userPricing.setJobPostings(pricingHistory.getCurrentCredits());
			if (request.isPurchase()) {
				userPricing.getInitialPricing()
						.setJobPostings(userPricing.getInitialPricing().getJobPostings() + request.getCredits());
			}
			check(userPricing.getJobPostings(), userPricing.getInitialPricing().getJobPostings());
			break;

		case IMAGE_STORAGE:
			if (request.isPurchase()) {
				request.setCredits(calculate.mbToBytes(request.getCredits()));
			}
			pricingHistory = createPricingHistory(request, userPricing.getImageStorageSize());
			userPricing.setImageStorageSize(pricingHistory.getCurrentCredits());
			if (request.isPurchase()) {
				userPricing.getInitialPricing().setImageStorageSize(
						userPricing.getInitialPricing().getImageStorageSize() + request.getCredits());
			}
			check(userPricing.getImageStorageSize(), userPricing.getInitialPricing().getImageStorageSize());
			break;

		}

		userPricingHistory = mapper.convertToDto(pricingHistory, UserPricingHistory.class);
		save(userPricing, userPricingHistory);
	}

	public void debit(PricingRequest request, UserPricing userPricing) {

		UserPricingHistory userPricingHistory = null;
		PricingHistory pricingHistory = null;

		switch (request.getCreditType()) {

		case PRODUCT_SERVICE_LISTING:
			checkCreditsAvailable(userPricing.getListings(), request);
			pricingHistory = createPricingHistory(request, userPricing.getListings());
			userPricing.setListings(pricingHistory.getCurrentCredits());

			break;

		case BUSINESS_INTEREST_VIEW:
			checkCreditsAvailable(userPricing.getBiReadCredits(), request);
			pricingHistory = createPricingHistory(request, userPricing.getBiReadCredits());
			userPricing.setBiReadCredits(pricingHistory.getCurrentCredits());

			break;

		case CIRCLE_CONNECTION:
			checkCreditsAvailable(userPricing.getConnections(), request);
			pricingHistory = createPricingHistory(request, userPricing.getConnections());
			userPricing.setConnections(pricingHistory.getCurrentCredits());

			break;

		case BUSINESS_POST:
			checkCreditsAvailable(userPricing.getBusinessPosts(), request);
			pricingHistory = createPricingHistory(request, userPricing.getBusinessPosts());
			userPricing.setBusinessPosts(pricingHistory.getCurrentCredits());

			break;

		case JOB_POSTING:
			checkCreditsAvailable(userPricing.getJobPostings(), request);
			pricingHistory = createPricingHistory(request, userPricing.getJobPostings());
			userPricing.setJobPostings(pricingHistory.getCurrentCredits());

			break;

		case IMAGE_STORAGE:
			checkCreditsAvailable(userPricing.getImageStorageSize(), request);
			pricingHistory = createPricingHistory(request, userPricing.getImageStorageSize());
			userPricing.setImageStorageSize(pricingHistory.getCurrentCredits());

			break;

		}
		userPricingHistory = mapper.convertToDto(pricingHistory, UserPricingHistory.class);
		save(userPricing, userPricingHistory);
	}

	public void save(UserPricing userPricing, UserPricingHistory userPricingHistory) {
		try {
			pricingDao.saveUserPricing(userPricing);
			historyRepo.save(userPricingHistory);
		} catch (Exception e) {
			throw new CustomException("Error while Saving Updated Credits for id " + userPricing.getsUuid(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	private PricingHistory createPricingHistory(PricingRequest request, long currentCredits) {
		return new CreatePricingHistory(request, currentCredits);
	}

	private void check(long currentCredits, long initialCredits) {
		if (currentCredits > initialCredits) {
			throw new CustomException("Something went wrong..Current Credits greater than Initial Credits",
					HttpStatus.BAD_REQUEST);
		}
	}

	private void checkCreditsAvailable(long currentCredits, PricingRequest request) {
		if (currentCredits <= 0) {
			throw new CustomException("No credits left for " + request.getCreditType().getValue(),
					HttpStatus.PAYMENT_REQUIRED);
		}
		if (request.getCredits() > currentCredits) {
			throw new CustomException(
					"Something went wrong..Credits requested for Debit is greater than current Credits ",
					HttpStatus.BAD_REQUEST);
		}
	}
}
