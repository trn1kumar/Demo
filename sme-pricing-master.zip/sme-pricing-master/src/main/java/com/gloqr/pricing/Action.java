package com.gloqr.pricing;

public enum Action {
	CREDIT("Credited"), DEBIT("Debited");

	private final String value;

	private Action(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}
