package com.gloqr.pricing;

public enum PlanName {
	// Do not change the sequence of plans
	FREE_BUSINESS("Free Business"),
	SMALL_BUSINESS("Small Business"),
	MEDIUM_BUSINESS("Medium Business"),
	BIG_BUSINESS("Big Business");
	
	private final String name;
	
	PlanName(String name){
		this.name = name;
	}
	
	public String getName() {
		return this.name;
	}
	
}
