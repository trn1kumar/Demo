package com.gloqr.pricing.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.gloqr.pricing.PlanName;

@JsonInclude(Include.NON_NULL)
public class UserPricingDTO extends ComponentsDTO {

	private static final long serialVersionUID = 1L;

	private PlanName planName;
	String planDisplayName;
	private Date expirationDate;
	private Date monthlyCreditedDate;
	private String userUUID;
	private String sUuid;
	private InitialPricingDTO initialPricing;
	private UnitCostDTO unitCost;
	private long monthlyCredit;

	public long getMonthlyCredit() {
		return monthlyCredit;
	}

	public void setMonthlyCredit(long monthlyCredit) {
		this.monthlyCredit = monthlyCredit;
	}

	public UnitCostDTO getUnitCost() {
		return unitCost;
	}

	public void setUnitCost(UnitCostDTO unitCost) {
		this.unitCost = unitCost;
	}

	public PlanName getPlanName() {
		return planName;
	}

	public String getPlanDisplayName() {
		return planName.getName();
	}

	public Date getExpirationDate() {
		return expirationDate;
	}

	public Date getMonthlyCreditedDate() {
		return monthlyCreditedDate;
	}

	public String getUserUUID() {
		return userUUID;
	}

	public String getsUuid() {
		return sUuid;
	}

	public InitialPricingDTO getInitialPricing() {
		return initialPricing;
	}

	public void setPlanName(PlanName planName) {
		this.planName = planName;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	public void setMonthlyCreditedDate(Date monthlyCreditedDate) {
		this.monthlyCreditedDate = monthlyCreditedDate;
	}

	public void setUserUUID(String userUUID) {
		this.userUUID = userUUID;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public void setInitialPricing(InitialPricingDTO initialPricing) {
		this.initialPricing = initialPricing;
	}

}
