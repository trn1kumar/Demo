package com.gloqr.pricing;

public interface PricingHistory {

	String getUserUUID();

	String getsUuid();

	String getSource();

	String getType();

	long getCurrentCredits();

	long getPreviousCredits();

	long getCredit();

	long getDebit();

	String getUsedFor();

}
