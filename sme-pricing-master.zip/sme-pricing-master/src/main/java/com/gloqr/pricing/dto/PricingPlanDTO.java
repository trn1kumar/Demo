package com.gloqr.pricing.dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.gloqr.pricing.PlanName;

@JsonInclude(Include.NON_NULL)
public class PricingPlanDTO extends ComponentsDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@NotNull(message = "{pricing.plan}")
	private PlanName planName;
	private double discount;
	private String planUuid;
	private double discountedCost;
	private double planCost;
	private boolean active;
	String planDisplayName;
	
	public String getPlanDisplayName() {
		return this.planName.getName();
	}

	public double getPlanCost() {
		return planCost;
	}

	public void setPlanCost(double planCost) {
		this.planCost = planCost;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public PlanName getPlanName() {
		return planName;
	}

	public double getDiscount() {
		return discount;
	}

	public String getPlanUuid() {
		return planUuid;
	}

	public double getDiscountedCost() {
		return discountedCost;
	}

	public void setDiscountedCost(double discountedCost) {
		this.discountedCost = discountedCost;
	}

	public void setPlanUuid(String planUuid) {
		this.planUuid = planUuid;
	}

	public void setPlanName(PlanName planName) {
		this.planName = planName;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

}
