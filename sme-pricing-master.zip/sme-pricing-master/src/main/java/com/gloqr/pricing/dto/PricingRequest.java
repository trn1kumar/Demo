package com.gloqr.pricing.dto;

import javax.validation.constraints.NotNull;

import com.gloqr.pricing.Action;
import com.gloqr.pricing.CreditType;

public class PricingRequest {

	@NotNull(message = "{action}")
	private Action action;
	@NotNull(message = "{credit.type}")
	private CreditType creditType;
	private String sUuid;
	private String userUUID;
	private long credits;
	private String source;
	private boolean purchase;
	private String usedFor;

	public PricingRequest(Action action, CreditType creditType, long credits, boolean purchase) {
		super();
		this.action = action;
		this.creditType = creditType;
		this.credits = credits;
		this.purchase = purchase;
	}

	public Action getAction() {
		return action;
	}

	public String getsUuid() {
		return sUuid;
	}

	public String getUserUUID() {
		return userUUID;
	}

	public CreditType getCreditType() {
		return creditType;
	}

	public long getCredits() {
		return credits;
	}

	public String getSource() {
		return source;
	}

	public boolean isPurchase() {
		return purchase;
	}

	public String getUsedFor() {
		return usedFor;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public void setUsedFor(String usedFor) {
		this.usedFor = usedFor;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public void setUserUUID(String userUUID) {
		this.userUUID = userUUID;
	}
	
	public void setCredits(long credits) {
		this.credits = credits;
	}

	@Override
	public String toString() {
		return "PricingRequest [action=" + action + ", creditType=" + creditType + ", sUuid=" + sUuid + ", userUUID="
				+ userUUID + ", credits=" + credits + ", usedFor=" + usedFor + "]";
	}

}
