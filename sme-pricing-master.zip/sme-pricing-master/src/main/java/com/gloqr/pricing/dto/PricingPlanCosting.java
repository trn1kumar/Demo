package com.gloqr.pricing.dto;

import com.gloqr.pricing.PlanName;

public class PricingPlanCosting {

	private double planCost;
	private double gstAmount;
	private double gst;
	private double totalPayableAmount;
	private PlanName planName;
	String planDisplayName;
	private String accountName;
	private long accountNumber;
	private String bankName;
	private String bankIFSCCode;
	private PricingPlanDTO pricingPlan;

	public PricingPlanDTO getPricingPlan() {
		return pricingPlan;
	}

	public void setPricingPlan(PricingPlanDTO pricingPlan) {
		this.pricingPlan = pricingPlan;
	}

	public double getPlanCost() {
		return planCost;
	}

	public double getGstAmount() {
		return gstAmount;
	}

	public double getGst() {
		return gst;
	}

	public double getTotalPayableAmount() {
		return totalPayableAmount;
	}

	public PlanName getPlanName() {
		return planName;
	}

	public String getPlanDisplayName() {
		return planName.getName();
	}

	public String getAccountName() {
		return accountName;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public String getBankName() {
		return bankName;
	}

	public String getBankIFSCCode() {
		return bankIFSCCode;
	}

	public void setPlanCost(double planCost) {
		this.planCost = planCost;
	}

	public void setGstAmount(double gstAmount) {
		this.gstAmount = gstAmount;
	}

	public void setGst(double gst) {
		this.gst = gst;
	}

	public void setTotalPayableAmount(double totalPayableAmount) {
		this.totalPayableAmount = totalPayableAmount;
	}

	public void setPlanName(PlanName planName) {
		this.planName = planName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public void setBankIFSCCode(String bankIFSCCode) {
		this.bankIFSCCode = bankIFSCCode;
	}

}
