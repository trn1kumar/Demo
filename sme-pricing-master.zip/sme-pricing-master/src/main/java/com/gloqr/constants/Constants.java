package com.gloqr.constants;

public class Constants {

	private Constants() {
		super();
	}

	// Role Constants
	public static final String ROLE_SME = "hasAnyRole('SME-ADMIN')";
	public static final String ROLE_USER = "hasAnyRole('USER')";
	public static final String ROLE_SME_AND_USER = "hasAnyRole('SME-ADMIN','USER')";
	public static final String ROLE_GLOQR_ADMIN = "hasAnyRole('GLOQR-SUPER-ADMIN')";

	// Content Server File Path
	public static final String FILE_LOCATION = "users/{userUUID}/payment";

	public static final String CREATED_AT = "createdAt";

}
