package com.gloqr.constants;

public class UrlMapping {

	private UrlMapping() {
		super();
	}

	public static final String COMPANY = "Gloqr";

	public static final String BASE_URL = "api";

	// Pricing Controller
	public static final String PRICING = "pricing";
	public static final String PRICING_PLANS = "pricing/plans";
	public static final String NEW_PLAN = PRICING + "/plan";
	public static final String NEW_USER = PRICING + "/new-user";
	public static final String USER_PRICING = PRICING + "/user";
	public static final String USER_CREDITS = PRICING + "/credits";
	public static final String ADMIN_UPDATE_CREDITS = PRICING + "/admin/credits";
	public static final String PLAN_COST = PRICING + "/plan-cost";

	// Payment Controller
	public static final String PAYMENT = "payment";
	public static final String CREATE_PAYMENT = PAYMENT + "/make";
	public static final String OFFLINE_PAYMENT = PAYMENT + "/offline";
	public static final String CAPTURE_PAYMENT = PAYMENT + "/capture";
	public static final String CREDITS_COST = PAYMENT + "/credits-cost";
	public static final String PAYMENT_DETAILS = PAYMENT + "/details";
	public static final String VERIFY_OFFLINE_PAYMENT = PAYMENT + "/verify";
	public static final String CHECK_PAYMENT_COMPLETED = PAYMENT + "/check";

	// Admin Controller
	public static final String INTERNAL_ADMIN_CREDITS = PRICING + "/internal-admin/credits";
}
