package com.gloqr.config;

import javax.annotation.Resource;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.gloqr.endpoints.ContentServer;
import com.gloqr.endpoints.NotificationEndPoint;
import com.gloqr.endpoints.SmeEndpoint;
import com.gloqr.endpoints.UserEndpoint;

@Configuration
@PropertySource(value = { "file:${location}/sme_pricing_${env}.properties" })
public class PricingConfig {

	@Resource
	private Environment environment;

	@Bean
	public ClientConfig clientConfig() {
		ClientConfig configuration = new ClientConfig();
		configuration.property(ClientProperties.CONNECT_TIMEOUT, 10000);
		configuration.property(ClientProperties.READ_TIMEOUT, 60000);

		return configuration;
	}

	@Bean
	public ContentServer contentServerConfig() {
		Client client = ClientBuilder.newBuilder().register(MultiPartFeature.class).build();
		String contentServerEndPoint = environment.getRequiredProperty("contentserver.endpoint");
		String uploadFile = environment.getRequiredProperty("uploadsfile.endpoint.path");
		String deleteFile = environment.getRequiredProperty("deletefile.endpoint.path");

		return new ContentServer(client, contentServerEndPoint, uploadFile, deleteFile);
	}

	@Bean
	public UserEndpoint userEndpointConfig() {
		Client client = ClientBuilder.newClient(clientConfig());
		String userEndpointPath = environment.getRequiredProperty("user.endpoint");
		String getUserDetailsPath = environment.getRequiredProperty("getuser.path");

		return new UserEndpoint(client, userEndpointPath, getUserDetailsPath);
	}

	@Bean
	public NotificationEndPoint notificationConfiguration() {
		Client client = ClientBuilder.newClient(clientConfig());
		String notificationEndPoint = environment.getRequiredProperty("notification.endpoint");
		String emailEndPointPath = environment.getRequiredProperty("email.endpoint.path");
		String smsEndPointPath = environment.getRequiredProperty("sms.endpoint.path");

		return new NotificationEndPoint(client, notificationEndPoint, emailEndPointPath, smsEndPointPath);
	}

	@Bean
	public SmeEndpoint smeConfig() {
		Client client = ClientBuilder.newClient(clientConfig());
		String enpoint = environment.getRequiredProperty("sme.endpoint");
		String userDetailsPath = environment.getRequiredProperty("sme.detail");
		String countPath = environment.getRequiredProperty("count.path");

		return new SmeEndpoint(client, enpoint, userDetailsPath, countPath);
	}

	@Bean
	public TemplateCommonUrl templatePropertiesConfig() {

		String websiteUrl = environment.getRequiredProperty("website.url");
		String contentServerUrl = environment.getRequiredProperty("content.server.cdn.path");

		return new TemplateCommonUrl(websiteUrl, contentServerUrl);
	}

	@Bean(name = "taskExecutor")
	public TaskExecutor workExecutor() {
		ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
		threadPoolTaskExecutor.setThreadNamePrefix("Async-Thread");

		threadPoolTaskExecutor.setCorePoolSize(5);
		threadPoolTaskExecutor.setMaxPoolSize(10);
		threadPoolTaskExecutor.setQueueCapacity(600);
		threadPoolTaskExecutor.afterPropertiesSet();

		return threadPoolTaskExecutor;
	}
}
