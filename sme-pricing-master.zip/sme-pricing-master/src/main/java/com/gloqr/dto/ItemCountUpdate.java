package com.gloqr.dto;

public class ItemCountUpdate {

	private static final String ITEM_TYPE = "PRICING";
	private long activePendingCount;

	public ItemCountUpdate(long activePendingCount) {
		super();
		this.activePendingCount = activePendingCount;
	}

	public long getActivePendingCount() {
		return activePendingCount;
	}

	public void setActivePendingCount(long activePendingCount) {
		this.activePendingCount = activePendingCount;
	}

	public String getItemType() {
		return ITEM_TYPE;
	}

	@Override
	public String toString() {
		return "ItemCountUpdate [activePendingCount=" + activePendingCount + "]";
	}

}
