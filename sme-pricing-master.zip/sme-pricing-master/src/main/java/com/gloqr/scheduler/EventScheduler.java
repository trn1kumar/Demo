package com.gloqr.scheduler;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.gloqr.constants.UrlMapping;
import com.gloqr.entity.UserPricing;
import com.gloqr.entity.UserPricingHistory;
import com.gloqr.pricing.CreditType;
import com.gloqr.repository.PricingDao;
import com.gloqr.repository.PricingHistoryRepo;
import com.gloqr.repository.UserPricingRepo;
import com.gloqr.security.CORSFilter;
import com.gloqr.service.NotificationService;
import com.gloqr.util.DateUtil;

@Component
public class EventScheduler {

	Logger logger = LogManager.getLogger(CORSFilter.class.getName());

	@Autowired
	private UserPricingRepo userPricingRepo;

	@Autowired
	private PricingHistoryRepo pricingHistoryRepo;

	@Autowired
	private DateUtil dateUtil;

	@Autowired
	private PricingDao pricingDao;

	@Autowired
	private NotificationService notificationService;

	@Scheduled(cron = "0 0 0 * * ?")
	public void scheduledTaskEveryDay() {

		List<UserPricing> userPricings = null;

		logger.info("Started Scheduling Process for Credit Business Interest Read Credits");

		userPricings = userPricingRepo.findByMonthlyCreditedDateAndMonthBiAddedLessThan(new Date(), 12);

		if (userPricings != null && !(userPricings.isEmpty())) {

			logger.info(userPricings.size() + " Records found for updating credits");

			userPricings.stream().filter(u -> u.isActive()).forEach(userPricing -> {
				if (dateUtil.isExpired(userPricing.getExpirationDate())) {
					logger.warn("SME id :: " + userPricing.getsUuid() + " plan is Expired");
					// TODO
				} else {
					this.updateBiReadCredits(userPricing);
				}
			});

		} else {
			logger.info("No Records found for Adding Monthly Business Interest Read Credits");
		}

	}

	@Transactional
	void updateBiReadCredits(UserPricing userPricing) {
		logger.info(
				"Updating Credit of SME uuid " + userPricing.getsUuid() + " For Package " + userPricing.getPlanName());

		long credits = pricingDao.getPricingPlan(userPricing.getPlanName()).getBiReadCredits() / 12;

		userPricing.setMonthlyCreditedDate(dateUtil.getMonthlyCreditDate());
		userPricing.getInitialPricing().setBiReadCredits(userPricing.getInitialPricing().getBiReadCredits() + credits);
		userPricing.setBiReadCredits(userPricing.getBiReadCredits() + credits);
		userPricing.setMonthBiAdded(userPricing.getMonthBiAdded() + 1);
		try {
			userPricingRepo.save(userPricing);
			pricingHistoryRepo.save(createPricingHistory(userPricing, credits));

			logger.info("Updated Credits Successfully & Created Audit Entry to User Pricing History");
			notificationService.sendMonthlyBiAddedNotification(credits, userPricing.getsUuid());
		} catch (Exception e) {
			logger.error("Error while Saving User Pricing or User Pricing History");
		}

	}

	UserPricingHistory createPricingHistory(UserPricing userPricing, long credit) {
		UserPricingHistory history = new UserPricingHistory();

		history.setCredit(credit);
		history.setCurrentCredits(userPricing.getBiReadCredits() + credit);
		history.setPreviousCredits(userPricing.getBiReadCredits());
		history.setSource(UrlMapping.COMPANY);
		history.setsUuid(userPricing.getsUuid());
		history.setType(CreditType.BUSINESS_INTEREST_VIEW.getValue());
		history.setUserUUID(UrlMapping.COMPANY);
		history.setUsedFor("Monthly addition of Business Interest Read");

		return history;
	}
}