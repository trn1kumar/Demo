package com.gloqr.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gloqr.payment.PaymentStatus;
import com.gloqr.payment.PaymentUtility;
import com.gloqr.pricing.CreditType;
import com.gloqr.pricing.PlanName;

@Entity
@Table(name = "Payment_Order")
public class PaymentOrder extends Audit {

	private static final long serialVersionUID = 1L;

	public PaymentOrder() {
		super();
	}

	public PaymentOrder(String userUUID, String transactionID, PaymentUtility paymentUtility) {
		super();
		this.userUUID = userUUID;
		this.transactionID = transactionID;
		this.paymentUtility = paymentUtility;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@JsonIgnore
	private Long paymentOrderID;

	@Column(name = "User_UUID", nullable = false, updatable = false)
	private String userUUID;

	@Column(name = "SUUID")
	private String sUuid;

	@Column(name = "Payment_ID")
	private String paymentID;

	@Column(name = "Order_ID", nullable = false, updatable = false, unique = true)
	private String orderID;

	@Column(name = "Transaction_ID", nullable = false, updatable = false, unique = true)
	private String transactionID;

	@Column(name = "Amount", nullable = false, updatable = false, columnDefinition = "DOUBLE(9,2) UNSIGNED")
	private Double amount;

	@Column(name = "Credits", updatable = false)
	private Long credits;

	@Column(name = "Payment_Utility", nullable = false, updatable = false)
	@Enumerated(EnumType.STRING)
	private PaymentUtility paymentUtility;

	@Column(name = "CreditType")
	@Enumerated(EnumType.STRING)
	private CreditType creditType;

	@Column(name = "PlanName")
	@Enumerated(EnumType.STRING)
	private PlanName planName;

	@Column(name = "Payment_Status", nullable = false)
	@Enumerated(EnumType.STRING)
	private PaymentStatus paymentStatus = PaymentStatus.ATTEMPTED;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "Payment_Details_ID")
	private PaymentDetails paymentDetails;

	@Transient
	String planDisplayName;

	public String getPlanDisplayName() {
		if (planName != null) {
			return planName.getName();
		}
		return planDisplayName;
	}

	public Long getPaymentOrderID() {
		return paymentOrderID;
	}

	public String getUserUUID() {
		return userUUID;
	}

	public String getsUuid() {
		return sUuid;
	}

	public String getPaymentID() {
		return paymentID;
	}

	public String getOrderID() {
		return orderID;
	}

	public String getTransactionID() {
		return transactionID;
	}

	public Double getAmount() {
		return amount;
	}

	public Long getCredits() {
		return credits;
	}

	public PaymentUtility getPaymentUtility() {
		return paymentUtility;
	}

	public CreditType getCreditType() {
		return creditType;
	}

	public PlanName getPlanName() {
		return planName;
	}

	public PaymentStatus getPaymentStatus() {
		return paymentStatus;
	}

	public PaymentDetails getPaymentDetails() {
		return paymentDetails;
	}

	public void setPaymentOrderID(Long paymentOrderID) {
		this.paymentOrderID = paymentOrderID;
	}

	public void setUserUUID(String userUUID) {
		this.userUUID = userUUID;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public void setPaymentID(String paymentID) {
		this.paymentID = paymentID;
	}

	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}

	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public void setCredits(Long credits) {
		this.credits = credits;
	}

	public void setPaymentUtility(PaymentUtility paymentUtility) {
		this.paymentUtility = paymentUtility;
	}

	public void setCreditType(CreditType creditType) {
		this.creditType = creditType;
	}

	public void setPlanName(PlanName planName) {
		this.planName = planName;
	}

	public void setPaymentStatus(PaymentStatus paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public void setPaymentDetails(PaymentDetails paymentDetails) {
		this.paymentDetails = paymentDetails;
	}

}
