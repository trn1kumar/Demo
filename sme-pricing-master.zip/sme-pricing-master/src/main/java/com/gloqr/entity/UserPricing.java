package com.gloqr.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.gloqr.pricing.PlanName;

@Entity
@Table(name = "User_Pricing_Details")
public class UserPricing extends Components {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long pricingDetailsID;

	@Column(name = "User_UUID", nullable = false, updatable = false)
	private String userUUID;

	@Column(name = "SME_UUID", unique = true, nullable = false, updatable = false)
	private String sUuid;

	@Column(name = "active", nullable = false)
	private boolean active;

	@Column(name = "Plan_Name", nullable = false)
	@Enumerated(EnumType.STRING)
	private PlanName planName;

	@Column(name = "Plan_Cost", columnDefinition = "DOUBLE(9,2) UNSIGNED")
	private double planCost;

	@Column(name = "Expiration_Date")
	private Date expirationDate;

	@Column(name = "Monthly_Credited_Date", nullable = false)
	@Temporal(TemporalType.DATE)
	private Date monthlyCreditedDate;

	@Column(name = "Month_Bi_Added")
	private int monthBiAdded;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "Initial_Pricing_ID", nullable = false)
	private UserInitialPricing initialPricing;

	public PlanName getPlanName() {
		return planName;
	}

	public double getPlanCost() {
		return planCost;
	}

	public Long getPricingDetailsID() {
		return pricingDetailsID;
	}

	public String getUserUUID() {
		return userUUID;
	}

	public String getsUuid() {
		return sUuid;
	}

	public boolean isActive() {
		return active;
	}

	public Date getExpirationDate() {
		return expirationDate;
	}

	public Date getMonthlyCreditedDate() {
		return monthlyCreditedDate;
	}

	public int getMonthBiAdded() {
		return monthBiAdded;
	}

	public UserInitialPricing getInitialPricing() {
		return initialPricing;
	}

	public void setPricingDetailsID(Long pricingDetailsID) {
		this.pricingDetailsID = pricingDetailsID;
	}

	public void setUserUUID(String userUUID) {
		this.userUUID = userUUID;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setPlanName(PlanName planName) {
		this.planName = planName;
	}

	public void setPlanCost(double planCost) {
		this.planCost = planCost;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	public void setMonthlyCreditedDate(Date monthlyCreditedDate) {
		this.monthlyCreditedDate = monthlyCreditedDate;
	}

	public void setMonthBiAdded(int monthBiAdded) {
		this.monthBiAdded = monthBiAdded;
	}

	public void setInitialPricing(UserInitialPricing initialPricing) {
		this.initialPricing = initialPricing;
	}

}
