package com.gloqr.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.gloqr.pricing.PricingPlanMaster;

@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
public abstract class Components extends Audit implements Serializable, PricingPlanMaster {

	private static final long serialVersionUID = 1L;

	@Column(name = "Listings", nullable = false, columnDefinition = "BIGINT(20) UNSIGNED")
	private long listings;

	@Column(name = "Connections", nullable = false, columnDefinition = "BIGINT(20) UNSIGNED")
	private long connections;

	@Column(name = "BI_Read_Credits", nullable = false, columnDefinition = "BIGINT(20) UNSIGNED")
	private long biReadCredits;

	@Column(name = "Image_Storage_Size", nullable = false, columnDefinition = "BIGINT(20) UNSIGNED")
	private long imageStorageSize;

	@Column(name = "Job_Postings", nullable = false, columnDefinition = "BIGINT(20) UNSIGNED")
	private long jobPostings;

	@Column(name = "Business_Posts", nullable = false, columnDefinition = "BIGINT(20) UNSIGNED")
	private long businessPosts;

	@Override
	public long getListings() {
		return listings;
	}

	@Override
	public long getConnections() {
		return connections;
	}

	@Override
	public long getBiReadCredits() {
		return biReadCredits;
	}

	@Override
	public long getImageStorageSize() {
		return imageStorageSize;
	}

	@Override
	public long getJobPostings() {
		return jobPostings;
	}

	@Override
	public long getBusinessPosts() {
		return businessPosts;
	}

	public void setListings(long listings) {
		this.listings = listings;
	}

	public void setConnections(long connections) {
		this.connections = connections;
	}

	public void setBiReadCredits(long biReadCredits) {
		this.biReadCredits = biReadCredits;
	}

	public void setImageStorageSize(long imageStorageSize) {
		this.imageStorageSize = imageStorageSize;
	}

	public void setJobPostings(long jobPostings) {
		this.jobPostings = jobPostings;
	}

	public void setBusinessPosts(long businessPosts) {
		this.businessPosts = businessPosts;
	}

}
