package com.gloqr.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "Pricing")
public class Pricing extends UnitCost {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long pricingId;

	@Column(name = "Pricing_UUID", nullable = false, unique = true)
	private String pricingUuid;

	@Column(name = "Active", updatable = false)
	private boolean active;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "Offer_End_Date")
	private Date offerEndDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "Offer_Start_Date")
	private Date offerStartDate;

	@Column(name = "Offer")
	private boolean offer;

	@Column(name = "GST", columnDefinition = "DOUBLE(9,2) UNSIGNED")
	private double gst;

	@Column(name = "Monthly_Credit_Period", nullable = false)
	private int monthlyCreditPeriod;

	@Column(name = "Merchant_Name", nullable = false)
	private String merchantName;

	@Column(name = "Account_Name", nullable = false)
	private String accountName;

	@Column(name = "Account_Number", nullable = false)
	private long accountNumber;

	@Column(name = "Bank_Name", nullable = false)
	private String bankName;

	@Column(name = "Bank_IFSC", nullable = false)
	private String bankIFSCCode;

	public String getPricingUuid() {
		return pricingUuid;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public Long getPricingId() {
		return pricingId;
	}

	public boolean isActive() {
		return active;
	}

	public Date getOfferEndDate() {
		return offerEndDate;
	}

	public Date getOfferStartDate() {
		return offerStartDate;
	}

	public boolean isOffer() {
		return offer;
	}

	public double getGst() {
		return gst;
	}

	public int getMonthlyCreditPeriod() {
		return monthlyCreditPeriod;
	}

	public String getAccountName() {
		return accountName;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public String getBankName() {
		return bankName;
	}

	public String getBankIFSCCode() {
		return bankIFSCCode;
	}

	public void setOfferEndDate(Date offerEndDate) {
		this.offerEndDate = offerEndDate;
	}

	public void setOfferStartDate(Date offerStartDate) {
		this.offerStartDate = offerStartDate;
	}

	public void setOffer(boolean offer) {
		this.offer = offer;
	}

}
