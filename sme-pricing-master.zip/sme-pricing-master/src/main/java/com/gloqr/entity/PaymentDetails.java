package com.gloqr.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "Payment_Details")
public class PaymentDetails implements Serializable{

	private static final long serialVersionUID = -4083335771302191235L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@JsonIgnore
	private Long paymentDetailsID;

	@Column(name = "PaymentCreatedAt", nullable = false, updatable = false)
	private Date paymentCreatedAt;

	@Column(name = "Currency", nullable = false, updatable = false)
	private String currency;

	@Column(name = "Payment_Method", nullable = false, updatable = false)
	private String paymentMethod;
	
	@Column(name = "User_Mobile", nullable = false, updatable = false)
	private String userMobile;

	@Column(name = "User_Email", nullable = false, updatable = false)
	private String userEmail;

	@Column(name = "Bank")
	private String bank;

	@Column(name = "Wallet")
	private String wallet;

	@Column(name = "VPA")
	private String vpa;

	public String getUserMobile() {
		return userMobile;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public Long getPaymentDetailsID() {
		return paymentDetailsID;
	}

	public Date getPaymentCreatedAt() {
		return paymentCreatedAt;
	}

	public String getCurrency() {
		return currency;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public String getBank() {
		return bank;
	}

	public String getWallet() {
		return wallet;
	}

	public String getVpa() {
		return vpa;
	}

	public void setPaymentDetailsID(Long paymentDetailsID) {
		this.paymentDetailsID = paymentDetailsID;
	}

	public void setPaymentCreatedAt(Date paymentCreatedAt) {
		this.paymentCreatedAt = paymentCreatedAt;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public void setWallet(String wallet) {
		this.wallet = wallet;
	}

	public void setVpa(String vpa) {
		this.vpa = vpa;
	}

}
