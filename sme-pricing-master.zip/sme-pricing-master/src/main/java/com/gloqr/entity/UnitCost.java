package com.gloqr.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
public abstract class UnitCost implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "Listing_Cost", columnDefinition = "DOUBLE(9,2) UNSIGNED")
	private double listingCost;

	@Column(name = "Connection_Cost", columnDefinition = "DOUBLE(9,2) UNSIGNED")
	private double connectionCost;

	@Column(name = "Bi_Read_Cost", columnDefinition = "DOUBLE(9,2) UNSIGNED")
	private double biReadCost;

	@Column(name = "Storage_Cost", columnDefinition = "DOUBLE(9,2) UNSIGNED")
	private double storageCost;

	@Column(name = "Job_Post_Cost", columnDefinition = "DOUBLE(9,2) UNSIGNED")
	private double jobPostCost;

	@Column(name = "Businee_Post_Cost", columnDefinition = "DOUBLE(9,2) UNSIGNED")
	private double businessPostCost;

	public double getListingCost() {
		return listingCost;
	}

	public double getConnectionCost() {
		return connectionCost;
	}

	public double getBiReadCost() {
		return biReadCost;
	}

	public double getStorageCost() {
		return storageCost;
	}

	public double getJobPostCost() {
		return jobPostCost;
	}

	public double getBusinessPostCost() {
		return businessPostCost;
	}
}
