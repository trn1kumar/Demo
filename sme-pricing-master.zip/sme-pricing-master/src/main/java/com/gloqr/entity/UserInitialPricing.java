package com.gloqr.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "User_Initial_Pricing")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler", "createdAt", "updatedAt" })
public class UserInitialPricing extends Components {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long initialPricingID;

	@JsonIgnore
	public Long getInitialPricingID() {
		return initialPricingID;
	}

}
