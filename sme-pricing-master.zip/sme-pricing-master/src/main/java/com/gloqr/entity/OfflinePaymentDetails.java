package com.gloqr.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gloqr.payment.OfflinePaymentBy;
import com.gloqr.payment.PaymentUtility;
import com.gloqr.pricing.PlanName;

@Entity
@Table(name = "Offline_Payment_Details")
public class OfflinePaymentDetails extends Audit {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@JsonIgnore
	private Long offlinePaymentID;

	@Column(name = "Offline_Payment_UUID", nullable = false, unique = true)
	private String offlinePaymentUuid;

	@Column(name = "User_UUID", nullable = false, updatable = false)
	private String userUUID;

	@Column(name = "Selected_Package", nullable = false, updatable = false)
	@Enumerated(EnumType.STRING)
	private PlanName planName;

	@Column(name = "Payment_Utility", nullable = false, updatable = false)
	@Enumerated(EnumType.STRING)
	private PaymentUtility paymentUtility;

	@Column(name = "Bank_Name")
	private String bankName;

	@Column(name = "Branch_Name")
	private String branchName;

	@Column(name = "Transaction_Date")
	private Date transactionDate;

	@Column(name = "Amount", columnDefinition = "DOUBLE(9,2) UNSIGNED")
	private Double amount;

	@Column(name = "PlanCost", columnDefinition = "DOUBLE(9,2) UNSIGNED")
	private Double planCost;

	@Column(name = "Transaction_Number")
	private String transactionNumber;

	@Column(name = "Verified")
	private boolean verified;

	@Column(name = "Rejected")
	private boolean rejected;

	@Column(name = "Reject_Reason")
	private String rejectReason;

	@Column(name = "Payment_Mode")
	@Enumerated(EnumType.STRING)
	private OfflinePaymentBy paymentMode;

	@Column(name = "File_Location")
	private String fileLocation;

	@Column(name = "Message", length = 500)
	private String message;

	@Column(name = "Modifier_Name")
	private String modifierName;

	@Column(name = "Modifier_ID")
	private String modifierID;

	@Transient
	String planDisplayName;

	@Transient
	boolean action;

	public boolean isAction() {
		return action;
	}

	public void setAction(boolean action) {
		this.action = action;
	}

	public String getModifierName() {
		return modifierName;
	}

	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

	public String getModifierID() {
		return modifierID;
	}

	public void setModifierID(String modifierID) {
		this.modifierID = modifierID;
	}

	public String getPlanDisplayName() {
		return planName.getName();
	}

	public String getOfflinePaymentUuid() {
		return offlinePaymentUuid;
	}

	public void setOfflinePaymentUuid(String offlinePaymentUuid) {
		this.offlinePaymentUuid = offlinePaymentUuid;
	}

	public boolean isRejected() {
		return rejected;
	}

	public void setRejected(boolean rejected) {
		this.rejected = rejected;
	}

	public String getRejectReason() {
		return rejectReason;
	}

	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}

	public Long getOfflinePaymentID() {
		return offlinePaymentID;
	}

	public String getUserUUID() {
		return userUUID;
	}

	public PlanName getPlanName() {
		return planName;
	}

	public PaymentUtility getPaymentUtility() {
		return paymentUtility;
	}

	public String getBankName() {
		return bankName;
	}

	public String getBranchName() {
		return branchName;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public Double getAmount() {
		return amount;
	}

	public Double getPlanCost() {
		return planCost;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public boolean isVerified() {
		return verified;
	}

	public OfflinePaymentBy getPaymentMode() {
		return paymentMode;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public String getMessage() {
		return message;
	}

	public void setOfflinePaymentID(Long offlinePaymentID) {
		this.offlinePaymentID = offlinePaymentID;
	}

	public void setUserUUID(String userUUID) {
		this.userUUID = userUUID;
	}

	public void setPlanName(PlanName planName) {
		this.planName = planName;
	}

	public void setPaymentUtility(PaymentUtility paymentUtility) {
		this.paymentUtility = paymentUtility;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public void setPlanCost(Double planCost) {
		this.planCost = planCost;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public void setVerified(boolean verified) {
		this.verified = verified;
	}

	public void setPaymentMode(OfflinePaymentBy paymentMode) {
		this.paymentMode = paymentMode;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "OfflinePaymentDetails [offlinePaymentID=" + offlinePaymentID + ", offlinePaymentUuid="
				+ offlinePaymentUuid + ", userUUID=" + userUUID + ", planName=" + planName + ", paymentUtility="
				+ paymentUtility + ", bankName=" + bankName + ", branchName=" + branchName + ", transactionDate="
				+ transactionDate + ", amount=" + amount + ", planCost=" + planCost + ", transactionNumber="
				+ transactionNumber + ", verified=" + verified + ", rejected=" + rejected + ", rejectReason="
				+ rejectReason + ", paymentMode=" + paymentMode + ", fileLocation=" + fileLocation + ", message="
				+ message + "]";
	}

}
