package com.gloqr.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.gloqr.pricing.PricingHistory;

@Entity
@Table(name = "User_Pricing_History")
public class UserPricingHistory extends Audit implements PricingHistory {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long pricingHistoryID;

	@Column(name = "User_UUID", nullable = false, updatable = false)
	private String userUUID;

	@Column(name = "SME_UUID", nullable = false, updatable = false)
	private String sUuid;

	@Column(name = "Previous_Credits", nullable = false, columnDefinition = "BIGINT(20) UNSIGNED")
	private long previousCredits;

	@Column(name = "Current_Credits", nullable = false, columnDefinition = "BIGINT(20) UNSIGNED")
	private long currentCredits;

	@Column(name = "Credit", columnDefinition = "BIGINT(20) UNSIGNED")
	private long credit;

	@Column(name = "Debit", columnDefinition = "BIGINT(20) UNSIGNED")
	private long debit;

	@Column(name = "Type", nullable = false)
	private String type;

	@Column(name = "Source", nullable = false)
	private String source;

	@Column(name = "Used_For")
	private String usedFor;

	public Long getPricingHistoryID() {
		return pricingHistoryID;
	}

	@Override
	public String getUserUUID() {
		return userUUID;
	}

	@Override
	public String getsUuid() {
		return sUuid;
	}

	@Override
	public long getPreviousCredits() {
		return previousCredits;
	}

	@Override
	public long getCurrentCredits() {
		return currentCredits;
	}

	@Override
	public long getCredit() {
		return credit;
	}

	@Override
	public long getDebit() {
		return debit;
	}

	@Override
	public String getType() {
		return type;
	}

	@Override
	public String getSource() {
		return source;
	}

	@Override
	public String getUsedFor() {
		return usedFor;
	}

	public void setPricingHistoryID(Long pricingHistoryID) {
		this.pricingHistoryID = pricingHistoryID;
	}

	public void setUserUUID(String userUUID) {
		this.userUUID = userUUID;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public void setPreviousCredits(long previousCredits) {
		this.previousCredits = previousCredits;
	}

	public void setCurrentCredits(long currentCredits) {
		this.currentCredits = currentCredits;
	}

	public void setCredit(long credit) {
		this.credit = credit;
	}

	public void setDebit(long debit) {
		this.debit = debit;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public void setUsedFor(String usedFor) {
		this.usedFor = usedFor;
	}

}
