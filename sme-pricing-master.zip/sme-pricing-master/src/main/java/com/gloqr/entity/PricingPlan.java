package com.gloqr.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.gloqr.pricing.PlanName;

@Entity
@Table(name = "Pricing_Plans")
public class PricingPlan extends Components {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long pricingPlanId;

	@Column(name = "Plan_UUID", nullable = false, unique = true, updatable = false)
	private String planUuid;

	@Column(name = "Plan_Name", nullable = false, unique = true, updatable = false)
	@Enumerated(EnumType.STRING)
	private PlanName planName;

	@Column(name = "Plan_Cost", columnDefinition = "DOUBLE(9,2) UNSIGNED")
	private double planCost;

	@Column(name = "Discount", columnDefinition = "DOUBLE(9,2) UNSIGNED")
	private double discount;

	@Column(name = "active", nullable = false)
	private boolean active;

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public PlanName getPlanName() {
		return planName;
	}

	public double getPlanCost() {
		return planCost;
	}

	public double getDiscount() {
		return discount;
	}

	public Long getPricingPlanId() {
		return pricingPlanId;
	}

	public String getPlanUuid() {
		return planUuid;
	}

	public void setPlanUuid(String planUuid) {
		this.planUuid = planUuid;
	}

	public void setPricingPlanId(Long pricingPlanId) {
		this.pricingPlanId = pricingPlanId;
	}

	public void setPlanName(PlanName planName) {
		this.planName = planName;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public void setPlanCost(double planCost) {
		this.planCost = planCost;
	}

}
