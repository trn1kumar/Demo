package com.gloqr.util;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.gloqr.exception.CustomException;
import com.gloqr.security.JWTConstants;
import com.gloqr.security.JwtTokenUtil;
import com.google.gson.Gson;

import io.jsonwebtoken.Claims;

@Component
public class RequestParser {

	@Autowired
	private HttpServletRequest httpRequest;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	protected Claims getClaims() {
		String header = httpRequest.getHeader(JWTConstants.HEADER_STRING);
		String authToken = header.replace(JWTConstants.TOKEN_PREFIX, "");
		return jwtTokenUtil.getAllClaimsFromToken(authToken);
	}

	public String getUserUUID() {
		String userUUID = (String) getClaims().get(JWTConstants.USER_ID);
		if (StringUtils.isNotBlank(userUUID)) {
			return userUUID;
		} else {
			throw new CustomException("UserUUID cannot be null or empty", HttpStatus.BAD_REQUEST);
		}
	}

	public String getSuuid() {
		String sUuid = (String) getClaims().get(JWTConstants.SME_ID);
		if (StringUtils.isNotBlank(sUuid)) {
			return sUuid;
		} else {
			throw new CustomException("sUuid cannot be null or empty", HttpStatus.BAD_REQUEST);
		}
	}

	public boolean isSME() {
		return StringUtils.isNotBlank((String) getClaims().get(JWTConstants.SME_ID));
	}

	public String getUserName() {
		return (String) getClaims().get(JWTConstants.USER_NAME);
	}

	public String getLoginID() {
		return (String) getClaims().get(JWTConstants.LOGIN_ID);
	}

	public String getHeader() {
		return httpRequest.getHeader(JWTConstants.HEADER_STRING);
	}

	public <T> T parseJsonData(MultipartHttpServletRequest request, String parseKey, Class<T> parseClass) {
		try {
			return new Gson().fromJson(request.getParameter(parseKey), parseClass);
		} catch (Exception e) {
			throw new CustomException("failed to parse JSON data", HttpStatus.NOT_ACCEPTABLE);
		}
	}

}
