package com.gloqr.util;

import org.springframework.stereotype.Component;

@Component
public class CalculateUtil {
	long bytes = 1048576;

	public long mbToBytes(long credits) {
		return bytes * credits;
	}

	public double calculateDiscount(double cost, double discount) {
		double d = (cost * discount) / 100;
		return (cost - d);
	}

	public double calculateGST(double cost, double gstPercent) {
		return (cost * gstPercent) / 100;
	}
}
