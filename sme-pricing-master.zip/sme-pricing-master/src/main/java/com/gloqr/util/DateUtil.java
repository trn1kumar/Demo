package com.gloqr.util;

import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.gloqr.repository.PricingDao;

@Component
public class DateUtil {

	@Autowired
	private PricingDao pricingDao;

	@Value("${pricing.table.uuid}")
	private String pricingUuid;

	public boolean isExpired(Date expiryDate) {
		return expiryDate != null && (new Date().compareTo(expiryDate) >= 0);
	}

	public Date getMonthlyCreditDate() {
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.DATE, pricingDao.getPricing(pricingUuid).getMonthlyCreditPeriod());

		return cal.getTime();
	}

	public Date getExpirationDate() {
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		cal.add(Calendar.DATE, 365);

		return cal.getTime();
	}

	public Date getOfferEndDate(Date offerEndDate) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(offerEndDate);
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);

		return cal.getTime();
	}
}
