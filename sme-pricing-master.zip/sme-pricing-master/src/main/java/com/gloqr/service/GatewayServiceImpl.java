package com.gloqr.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.razorpay.Order;
import com.razorpay.Payment;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;

@Service
public class GatewayServiceImpl implements GatewayService {

	@Value("${razorpay.key.id}")
	private String keyID;

	@Value("${razorpay.key.secret}")
	private String keySecret;

	Logger logger = LogManager.getLogger();

	@Override
	public String createOrderID(double amount) throws RazorpayException {
		RazorpayClient razorpay = new RazorpayClient(keyID, keySecret);
		String orderID = null;

		logger.info("Getting Order_ID for amount " + amount);

		try {
			JSONObject orderRequest = new JSONObject();
			orderRequest.put("amount", Math.round(amount * Double.valueOf(100)));
			orderRequest.put("currency", "INR");
			orderRequest.put("payment_capture", false);

			Order order = razorpay.Orders.create(orderRequest);
			orderID = order.get("id");

			logger.info(order.toJson());
		} catch (RazorpayException e) {
			logger.info(e.getMessage());
			throw e;
		}
		return orderID;
	}

	@Override
	public Payment capturePayment(double amount, String razorpayPaymentID) throws RazorpayException {
		RazorpayClient razorpay = new RazorpayClient(keyID, keySecret);
		JSONObject captureRequest = new JSONObject();
		Payment payment = null;

		logger.info("Capturing Payment for Razorpay_Payment_Id " + razorpayPaymentID + " and " + "amount " + amount);

		try {
			captureRequest.put("amount", Math.round(amount * Double.valueOf(100)));
			payment = razorpay.Payments.capture(razorpayPaymentID, captureRequest);

			logger.info(payment.toJson());
		} catch (RazorpayException e) {
			logger.info(e.getMessage());
			throw e;
		}
		return payment;
	}

}
