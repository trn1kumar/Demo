package com.gloqr.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.entity.PaymentOrder;
import com.gloqr.entity.Pricing;
import com.gloqr.entity.PricingPlan;
import com.gloqr.entity.UserInitialPricing;
import com.gloqr.entity.UserPricing;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.Mapper;
import com.gloqr.payment.PaymentStatus;
import com.gloqr.payment.PaymentUtility;
import com.gloqr.payment.dto.PaymentRequest;
import com.gloqr.pricing.CreditType;
import com.gloqr.pricing.CreditsAction;
import com.gloqr.pricing.PlanName;
import com.gloqr.pricing.PricingPlanMaster;
import com.gloqr.pricing.UpgradePricingPlan;
import com.gloqr.pricing.dto.PricingDTO;
import com.gloqr.pricing.dto.PricingPlanCosting;
import com.gloqr.pricing.dto.PricingPlanDTO;
import com.gloqr.pricing.dto.PricingRequest;
import com.gloqr.pricing.dto.UserPricingDTO;
import com.gloqr.repository.PaymentOrderRepo;
import com.gloqr.repository.PlanRepo;
import com.gloqr.repository.PricingDao;
import com.gloqr.repository.UserPricingRepo;
import com.gloqr.util.CalculateUtil;
import com.gloqr.util.CustomGenerator;
import com.gloqr.util.DateUtil;

@Service
public class PricingServiceImpl implements PricingService {

	Logger logger = LogManager.getLogger();

	@Autowired
	private PricingDao pricingDao;

	@Autowired
	private Mapper mapper;

	@Autowired
	private CustomGenerator generator;

	@Autowired
	private DateUtil dateUtil;

	@Autowired
	private UserPricingRepo userPricingRepo;

	@Autowired
	private CreditsAction action;

	@Autowired
	private CalculateUtil calculateUtil;

	@Autowired
	private PlanRepo planRepo;

	@Autowired
	private PaymentOrderRepo paymentOrderRepo;

	@Value("${pricing.table.uuid}")
	private String pricingUuid;

	private String smeNotFound = "SME not found with id :: ";

	@Autowired
	private PaymentService paymentService;

	@Autowired
	private PaymentOrderRepo paymentRepo;

	@Override
	public void addNewPricingPlan(PricingPlanDTO planDTO) {
		planDTO.setPlanUuid(generator.generateUUID());
		pricingDao.addNewPricingPlan(mapper.convertToEntity(planDTO, PricingPlan.class));
	}

	@Override
	public Map<String, Object> getPricingTableData() {
		return pricingDao.getPricingTableData();
	}

	@Override
	@Transactional
	public void createNewUser(String sUuid, String userUUID) {
		PlanName planName = PlanName.FREE_BUSINESS;

		if (userPricingRepo.existsBySUuidAndActiveTrue(sUuid)) {
			throw new CustomException("SME already Exists with id :: " + sUuid, HttpStatus.BAD_REQUEST);
		}

		logger.info("Creating New entry in Pricing for SME ID " + sUuid + " and " + userUUID);

		PaymentOrder paymentOrder = paymentOrderRepo.findByUserUUIDAndPaymentStatusAndPaymentUtility(userUUID,
				PaymentStatus.CAPTURED, PaymentUtility.NEW_PACKAGE);

		if (paymentOrder != null) {
			planName = paymentOrder.getPlanName();
			paymentOrder.setsUuid(sUuid);
			paymentRepo.save(paymentOrder);
		}

		PricingPlanDTO pricingPlan = pricingDao.getPricingPlan(planName);

		UserPricing userPricing = mapper.convertToEntity(pricingPlan, UserPricing.class);

		userPricing.setInitialPricing(mapper.convertToEntity(pricingPlan, UserInitialPricing.class));
		userPricing.setBiReadCredits(pricingPlan.getBiReadCredits() / 12);
		userPricing.getInitialPricing().setBiReadCredits(pricingPlan.getBiReadCredits() / 12);
		userPricing.setMonthlyCreditedDate(dateUtil.getMonthlyCreditDate());
		userPricing.setMonthBiAdded(1);
		userPricing.setsUuid(sUuid);
		userPricing.setUserUUID(userUUID);

		if (!planName.equals(PlanName.FREE_BUSINESS)) {
			userPricing.setExpirationDate(dateUtil.getExpirationDate());
		}

		pricingDao.saveUserPricing(userPricing);
	}

	@Override
	public UserPricingDTO getUserPricingDetails(String sUuid) {
		logger.info("Getting Business Credits Details of SME id :: " + sUuid);
		UserPricingDTO dto = pricingDao.getUserPricing(sUuid);
		dto.setUnitCost(pricingDao.getUnitCosting());
		dto.setMonthlyCredit(pricingDao.getPricingPlan(dto.getPlanName()).getBiReadCredits() / 12);
		return dto;
	}

	@Override
	public long checkCredits(String sUuid, CreditType creditType) {
		logger.info("Checking " + creditType.getValue() + " Credits of SME id :: " + sUuid);
		long credits = 0;

		UserPricingDTO userPricing = pricingDao.getUserPricing(sUuid);

		switch (creditType) {
		case PRODUCT_SERVICE_LISTING:
			credits = userPricing.getListings();
			break;

		case BUSINESS_INTEREST_VIEW:
			credits = userPricing.getBiReadCredits();
			break;

		case CIRCLE_CONNECTION:
			credits = userPricing.getConnections();
			break;

		case BUSINESS_POST:
			credits = userPricing.getBusinessPosts();
			break;

		case JOB_POSTING:
			credits = userPricing.getJobPostings();
			break;

		case IMAGE_STORAGE:
			credits = userPricing.getImageStorageSize();
			break;

		}
		logger.info(credits + " Credits left");
		return credits;
	}

	@Override
	@Transactional
	public void updateCredits(PricingRequest request) {
		UserPricing userPricing = getUserPricing(request.getsUuid());

		logger.info("Updating " + request.getCredits() + " " + request.getCreditType().getValue()
				+ " Credits of SME id :: ", request.getsUuid());

		switch (request.getAction()) {
		case CREDIT:
			action.credit(request, userPricing);
			break;

		case DEBIT:
			action.debit(request, userPricing);
			break;

		default:
			throw new CustomException("Please select correct Action", HttpStatus.BAD_REQUEST);
		}

		logger.info("Credits Updated Successfully");
	}

	@Override
	public PricingPlanCosting getPricingPlanCost(PlanName planName) {

		if (planName.equals(PlanName.FREE_BUSINESS)) {
			throw new CustomException("Please select correct plan", HttpStatus.BAD_REQUEST);
		}

		Pricing pricing = pricingDao.getPricing(pricingUuid);
		PricingPlanCosting planCosting = mapper.convertToDto(pricing, PricingPlanCosting.class);

		double planCost = pricingDao.getPricingPlan(planName).getPlanCost();
		double gstAmount = calculateUtil.calculateGST(planCost, pricing.getGst());

		planCosting.setPricingPlan(pricingDao.getPricingPlan(planName));
		planCosting.setPlanCost(planCost);
		planCosting.setGstAmount(gstAmount);
		planCosting.setPlanName(planName);
		planCosting.setTotalPayableAmount(planCost + gstAmount);

		return planCosting;
	}

	@Override
	public Map<String, Object> planPurchase(PaymentRequest request, boolean isSme) {

		Map<String, Object> map = new HashMap<>();

		if (isSme) {
			UserPricingDTO userPricing = this.getUserPricingDetails(request.getsUuid());
			this.checkPlanState(userPricing.getPlanName(), request.getPlanName());
			map.put("userPricing", userPricing);
		} else {
			paymentService.isUserPaymentCompleted(request.getUserUUID());
		}

		map.put("planCosting", this.getPricingPlanCost(request.getPlanName()));

		return map;
	}

	@Override
	@Transactional
	public UserPricingDTO upgradeUserPricingPlan(String sUuid, PlanName planName) {

		if (planName.equals(PlanName.FREE_BUSINESS)) {
			throw new CustomException("Please select correct plan", HttpStatus.BAD_REQUEST);
		}

		UserPricing userPricing = getUserPricing(sUuid);

		this.checkPlanState(userPricing.getPlanName(), planName);

		logger.info("Going to Upgrade Plan to " + planName + " for SME id " + sUuid);

		Optional<PricingPlan> optional = planRepo.findByPlanName(planName);
		if (optional.isPresent()) {
			PricingPlanMaster pricingPlan = new UpgradePricingPlan(optional.get(), userPricing);
			userPricing = mapper.convertUpgradedPlanToEntity(pricingPlan, userPricing);

			userPricing.setPlanName(optional.get().getPlanName());
			userPricing.setPlanCost(optional.get().getPlanCost());
			userPricing.setMonthBiAdded(1);
			userPricing.setMonthlyCreditedDate(dateUtil.getMonthlyCreditDate());
			userPricing.setExpirationDate(dateUtil.getExpirationDate());
		}

		return pricingDao.saveUserPricing(userPricing);
	}

	private UserPricing getUserPricing(String sUuid) {
		Optional<UserPricing> optional = userPricingRepo.findBySUuid(sUuid);

		if (optional.isPresent()) {
			return optional.get();
		} else {
			throw new CustomException(smeNotFound + sUuid, HttpStatus.NOT_FOUND);
		}
	}

	private void checkPlanState(PlanName existingPlan, PlanName requestedPlan) {
		if (existingPlan.ordinal() >= requestedPlan.ordinal()) {
			throw new CustomException("You are not allowed to upgrade plan at this momemnt", HttpStatus.NOT_ACCEPTABLE);
		}
	}

	@Override
	public void updatePricing(PricingDTO pricingDTO) {

		Pricing pricing = pricingDao.getPricing(pricingDTO.getPricingUuid());
		pricing.setOffer(pricingDTO.isOffer());

		if (pricingDTO.getOfferEndDate() != null) {
			pricing.setOfferEndDate(dateUtil.getOfferEndDate(pricingDTO.getOfferEndDate()));
		}
		if (pricingDTO.getOfferStartDate() != null) {
			pricing.setOfferStartDate(dateUtil.getOfferEndDate(pricingDTO.getOfferStartDate()));
		}

		pricingDao.savePricing(pricing);
	}

}
