package com.gloqr.service;

import com.gloqr.pricing.dto.UserDTO;

public interface NotificationService {

	void sendVerifiedNotification(UserDTO userDTO);

	void sendRejectedNotification(UserDTO userDTO);

	void sendMonthlyBiAddedNotification(long credits, String sUuid);

	void updateCountInSmeModule(String userUuid, long count, String token);
}
