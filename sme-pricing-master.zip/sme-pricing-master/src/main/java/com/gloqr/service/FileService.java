package com.gloqr.service;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

import com.gloqr.dto.FileUploadResponse;

public interface FileService {

	// Single file upload
	FileUploadResponse sendSingleFile(MultipartFile file, String fileLocation) throws IOException;

	// Delete single file from Content Server
	void deleteFile(String fileLocation) throws IOException;
}
