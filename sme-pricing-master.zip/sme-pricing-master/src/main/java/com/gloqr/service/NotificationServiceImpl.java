package com.gloqr.service;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.gloqr.config.TemplateCommonUrl;
import com.gloqr.dto.ItemCountUpdate;
import com.gloqr.dto.SMEInfoDto;
import com.gloqr.endpoints.NotificationEndPoint;
import com.gloqr.endpoints.SmeEndpoint;
import com.gloqr.notification.EmailEvent;
import com.gloqr.notification.SmsEvent;
import com.gloqr.pricing.dto.UserDTO;

@Service
public class NotificationServiceImpl implements NotificationService {

	@Autowired
	private NotificationEndPoint notification;

	@Autowired
	private SmeEndpoint smeEndpoint;

	@Autowired
	private TemplateEngine templateEngine;

	@Autowired
	private TemplateCommonUrl commonUrl;

	@Value("${email.subject.success}")
	private String emailSubjectSuccess;

	@Value("${email.message.success}")
	private String emailMessageSuccess;

	@Value("${email.subject.reject}")
	private String emailSubjectReject;

	@Value("${email.message.reject}")
	private String emailMessageReject;

	@Value("${monthly.bi.subject}")
	private String monthlySubject;

	@Value("${monthly.bi.message}")
	private String monthlyMessage;

	@Override
	@Async
	public void sendMonthlyBiAddedNotification(long credits, String sUuid) {
		SMEInfoDto smeInfo = smeEndpoint.getSmeInfo(sUuid);

		if (smeInfo != null) {

			if (StringUtils.isNotBlank(smeInfo.getContactEmail())) {

				Context context = new Context();
				context.setVariable("urls", commonUrl);
				context.setVariable("credits", String.valueOf(credits));
				context.setVariable("smeName", smeInfo.getSmeName());

				String mailPage = templateEngine.process("monthly-bi-added", context);
				notification.sendEmail(new EmailEvent(smeInfo.getContactEmail(),
						monthlySubject.replace("{value}", String.valueOf(credits)), mailPage));
			}

			String msg = monthlyMessage.replace("{value}", String.valueOf(credits)).replace("{sme}",
					smeInfo.getSmeName());

			if (smeInfo.getContactPhone() != null) {
				notification.sendSMS(new SmsEvent(String.valueOf(smeInfo.getContactPhone()), msg));
			}

		}

	}

	@Override
	@Async
	public void sendVerifiedNotification(UserDTO userDTO) {

		if (StringUtils.isNotBlank(userDTO.getUserEmail())) {
			Context context = getContext(userDTO);
			String mailPage = templateEngine.process("offline-verified", context);
			notification.sendEmail(new EmailEvent(userDTO.getUserEmail(), emailSubjectSuccess, mailPage));
		}

		if (userDTO.getUserMobile() != null) {
			notification.sendSMS(new SmsEvent(String.valueOf(userDTO.getUserMobile()), emailMessageSuccess
					.replace("{userName}", userDTO.getUserFullName()).replace("{PLAN_NAME}", userDTO.getPlanName())));
		}
	}

	@Override
	@Async
	public void sendRejectedNotification(UserDTO userDTO) {

		if (StringUtils.isNotBlank(userDTO.getUserEmail())) {
			Context context = getContext(userDTO);
			String mailPage = templateEngine.process("offline-rejected", context);
			notification.sendEmail(new EmailEvent(userDTO.getUserEmail(), emailSubjectReject, mailPage));
		}

		if (userDTO.getUserMobile() != null) {
			notification.sendSMS(new SmsEvent(String.valueOf(userDTO.getUserMobile()),
					emailMessageReject.replace("{userName}", userDTO.getUserFullName())));
		}
	}

	private Context getContext(UserDTO userDto) {
		Context context = new Context();
		context.setVariable("urls", commonUrl);
		context.setVariable("userName", userDto.getUserFullName());
		context.setVariable("planName", userDto.getPlanName());

		return context;
	}

	@Override
	@Async
	public void updateCountInSmeModule(String userUuid, long count, String token) {
		smeEndpoint.countUpdate(userUuid, new ItemCountUpdate(count), token);
	}

}
