package com.gloqr.service;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.constants.Constants;
import com.gloqr.endpoints.UserEndpoint;
import com.gloqr.entity.OfflinePaymentDetails;
import com.gloqr.entity.PaymentOrder;
import com.gloqr.entity.Pricing;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.Mapper;
import com.gloqr.payment.PaymentMode;
import com.gloqr.payment.PaymentStatus;
import com.gloqr.payment.PaymentUtility;
import com.gloqr.payment.dto.CapturePayment;
import com.gloqr.payment.dto.CreatePayment;
import com.gloqr.payment.dto.CreditsCost;
import com.gloqr.payment.dto.OfflinePaymentResponse;
import com.gloqr.payment.dto.PaymentDetailsDTO;
import com.gloqr.payment.dto.PaymentRequest;
import com.gloqr.payment.dto.Prefill;
import com.gloqr.payment.dto.VerifyPayment;
import com.gloqr.pricing.Action;
import com.gloqr.pricing.CreditType;
import com.gloqr.pricing.PlanName;
import com.gloqr.pricing.dto.PricingRequest;
import com.gloqr.pricing.dto.UserDTO;
import com.gloqr.pricing.dto.UserPricingDTO;
import com.gloqr.repository.OfflinePaymentRepo;
import com.gloqr.repository.PaymentOrderRepo;
import com.gloqr.repository.PricingDao;
import com.gloqr.util.CalculateUtil;
import com.gloqr.util.CustomGenerator;
import com.gloqr.util.FileUtil;
import com.razorpay.Payment;
import com.razorpay.RazorpayException;

@Service
public class PaymentServiceImpl implements PaymentService {
	Logger logger = LogManager.getLogger();

	@Autowired
	private Mapper mapper;

	@Autowired
	private FileService fileService;

	@Autowired
	private FileUtil fileUtil;

	@Autowired
	private OfflinePaymentRepo offlinePaymentRepo;

	@Autowired
	private GatewayService gatewayService;

	@Autowired
	private PricingService pricingService;

	@Autowired
	private PricingDao pricingDao;

	@Autowired
	private PaymentOrderRepo paymentOrderRepo;

	@Autowired
	private UserEndpoint userEndpoint;

	@Autowired
	private CalculateUtil calculateUtil;

	@Autowired
	private CustomGenerator generator;

	@Value("${razorpay.key.id}")
	private String keyID;

	@Value("${pricing.table.uuid}")
	private String pricingUuid;

	@Value("${offline.payment.complete}")
	private String offlinePaymentCompleted;

	@Value("${offline.payment.waiting}")
	private String offlinePaymentWaiting;

	@Value("${online.payment.completed}")
	private String onlinePaymentCompleted;

	private String planName = "{PLAN_NAME}";

	@Autowired
	private NotificationService notification;

	@Override
	public OfflinePaymentResponse createOfflinePayment(OfflinePaymentDetails offlinePaymentDetails, MultipartFile file,
			String token) throws IOException {
		logger.info("Saving offline payment details fot user " + offlinePaymentDetails.toString());
		OfflinePaymentResponse response = new OfflinePaymentResponse();

		OfflinePaymentDetails o = offlinePaymentRepo
				.findFirstByUserUUIDAndPaymentUtilityAndRejectedFalseAndVerifiedFalse(
						offlinePaymentDetails.getUserUUID(), offlinePaymentDetails.getPaymentUtility(),
						new Sort(Sort.Direction.DESC, Constants.CREATED_AT));

		if (o != null) {

			response.setCode(106);
			response.setDetails(o);
			response.setMessage(offlinePaymentWaiting);

		} else {
			response.setCode(HttpStatus.CREATED.value());
			response.setMessage(
					offlinePaymentCompleted.replace(planName, offlinePaymentDetails.getPlanName().getName()));

			if (file != null) {
				fileUtil.checkFileFormat(file);
				offlinePaymentDetails.setFileLocation(fileService
						.sendSingleFile(file,
								Constants.FILE_LOCATION.replace("{userUUID}", offlinePaymentDetails.getUserUUID()))
						.getFileLocation());
			}

			offlinePaymentDetails.getUserUUID();
			offlinePaymentDetails.setOfflinePaymentUuid(generator.generateUUID());
			try {
				offlinePaymentRepo.save(offlinePaymentDetails);
				// ASYNC Call
				notification.updateCountInSmeModule(offlinePaymentDetails.getUserUUID(), 1, token);
			} catch (Exception e) {
				throw new CustomException("Error while saving offline payment", HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		return response;
	}

	@Override
	@Transactional
	public CreatePayment createPayment(PaymentRequest request) {

		logger.info("Creating Payment Order for request :: " + request.toString());

		CreatePayment createPayment = new CreatePayment(keyID, pricingDao.getPricing(pricingUuid).getMerchantName());

		PaymentOrder paymentOrder = new PaymentOrder(request.getUserUUID(), "txn_" + generator.generateUUID(),
				request.getPaymentUtility());

		switch (request.getPaymentUtility()) {

		case NEW_PACKAGE:
			checkPlanName(request.getPlanName());
			createPayment.setDescription(request.getPlanName().getName());
			common(paymentOrder, request);

			break;

		case BUSINESS_CREDITS:
			paymentOrder.setCreditType(request.getCreditType());
			paymentOrder.setCredits(request.getCredits());
			double totalPrice = calculateCreditsCost(request.getCredits(), request.getCreditType()).getTotalPrice();
			if (totalPrice > 500000) {
				throw new CustomException("Amount limit exceeded", HttpStatus.NOT_ACCEPTABLE);
			}
			paymentOrder.setAmount(totalPrice);
			paymentOrder.setsUuid(request.getsUuid());
			createPayment.setDescription(
					"(x" + request.getCredits() + ") " + request.getCreditType().getValue() + " Credits");

			break;

		case UPGRADE_PACKAGE:
			checkPlanName(request.getPlanName());
			createPayment.setDescription(request.getPlanName().getName());
			common(paymentOrder, request);
			paymentOrder.setsUuid(request.getsUuid());

			break;

		default:
			throw new CustomException("Please select correct utility type", HttpStatus.BAD_REQUEST);
		}

		createPayment.setAmount(paymentOrder.getAmount() * Double.valueOf(100));
		createPayment.setOrderID(generateOrderID(paymentOrder.getAmount()));
		paymentOrder.setOrderID(createPayment.getOrderID());

		UserDTO userDTO = userEndpoint.getUserDetails(request.getUserUUID());
		if (userDTO != null) {
			createPayment.setPrefill(new Prefill(userDTO));
		}

		savePaymentOrder(paymentOrder);

		return createPayment;
	}

	private void common(PaymentOrder paymentOrder, PaymentRequest request) {
		paymentOrder.setAmount(pricingService.getPricingPlanCost(request.getPlanName()).getTotalPayableAmount());
		paymentOrder.setPlanName(request.getPlanName());
	}

	private void checkPlanName(PlanName planName) {
		if (planName == null) {
			throw new CustomException("PlanName cannot be null", HttpStatus.BAD_REQUEST);
		}
	}

	@Override
	@Transactional
	public void capturePayment(CapturePayment capturePayment) {
		logger.info("Capturing payment for :: " + capturePayment.toString());

		PaymentOrder paymentOrder = getPaymentOrderByOrderID(capturePayment.getRazorpayOrderID());
		Payment payment = capturePayment(paymentOrder.getAmount(), capturePayment.getRazorpayPaymentID());

		paymentOrder = mapper.convertToPaymentOrder(payment, paymentOrder);

		savePaymentOrder(paymentOrder);

		switch (paymentOrder.getPaymentUtility()) {

		case BUSINESS_CREDITS:
			PricingRequest pricingRequest = new PricingRequest(Action.CREDIT, paymentOrder.getCreditType(),
					paymentOrder.getCredits(), true);

			pricingRequest.setsUuid(paymentOrder.getsUuid());
			pricingRequest.setUserUUID(paymentOrder.getUserUUID());
			pricingRequest.setUsedFor("Purchased by SME through Online Payment");

			pricingService.updateCredits(pricingRequest);
			break;

		case UPGRADE_PACKAGE:
			pricingService.upgradeUserPricingPlan(paymentOrder.getsUuid(), paymentOrder.getPlanName());
			break;

		default:
			break;
		}

		logger.info("Payment Captured Successfully");
	}

	@Override
	public CreditsCost calculateCreditsCost(long credits, CreditType creditType) {

		Pricing pricing = pricingDao.getPricing(pricingUuid);
		Double cost = null;

		switch (creditType) {
		case PRODUCT_SERVICE_LISTING:
			cost = pricing.getListingCost();
			break;

		case BUSINESS_INTEREST_VIEW:
			cost = pricing.getBiReadCost();
			break;

		case CIRCLE_CONNECTION:
			cost = pricing.getConnectionCost();
			break;

		case BUSINESS_POST:
			cost = pricing.getBusinessPostCost();
			break;

		case JOB_POSTING:
			cost = pricing.getJobPostCost();
			break;

		case IMAGE_STORAGE:
			cost = pricing.getStorageCost();
			break;

		}
		double basePrice = cost * credits;
		double addedGST = calculateUtil.calculateGST(basePrice, pricing.getGst());

		return new CreditsCost(credits, cost, basePrice, basePrice + addedGST, addedGST, creditType);
	}

	@Override
	public boolean isUserPaymentCompleted(String userUUID) {

		PaymentOrder payment = paymentOrderRepo.findByUserUUIDAndPaymentStatusAndPaymentUtility(userUUID,
				PaymentStatus.CAPTURED, PaymentUtility.NEW_PACKAGE);

		if (payment != null) {
			throw new CustomException(onlinePaymentCompleted.replace(planName, payment.getPlanName().getName()),
					HttpStatus.ALREADY_REPORTED);
		}

		return false;
	}

	@Override
	public void verifyOfflinePayment(VerifyPayment verifyPayment, String token) {

		OfflinePaymentDetails details = offlinePaymentRepo
				.findByOfflinePaymentUuidAndVerifiedFalseAndRejectedFalse(verifyPayment.getOfflinePaymentUuid());

		if (details != null) {
			UserDTO userDto = userEndpoint.getUserDetails(details.getUserUUID());
			userDto.setPlanName(details.getPlanName().getName());

			if (verifyPayment.isVerified()) {
				details.setVerified(true);
				pricingService.upgradeUserPricingPlan(verifyPayment.getsUuid(), details.getPlanName());
				userDto.setVerified(true);
			} else {
				details.setRejected(true);
				details.setRejectReason(verifyPayment.getRejectReason());
			}
			details.setModifierID(verifyPayment.getModifierID());
			details.setModifierName(verifyPayment.getModifierName());
			offlinePaymentRepo.save(details);

			// ASYNC Call
			notification.updateCountInSmeModule(details.getUserUUID(), 0, token);
			if (verifyPayment.isVerified()) {
				notification.sendVerifiedNotification(userDto);
			} else {
				notification.sendRejectedNotification(userDto);
			}

		} else {
			throw new CustomException(
					"Offline Payment Details not found for uuid :: " + verifyPayment.getOfflinePaymentUuid(),
					HttpStatus.BAD_REQUEST);
		}

	}

	@Override
	public PaymentDetailsDTO getPaymentDetails(String userUUID, String sUuid) {
		PaymentDetailsDTO paymentDetails = new PaymentDetailsDTO();
		List<PaymentOrder> paymentOrder = null;
		List<OfflinePaymentDetails> offlinePaymentDetails = null;
		UserPricingDTO userPricing = null;

		userPricing = pricingDao.getUserPricing(sUuid);
		paymentDetails.setCurrentPlanName(userPricing.getPlanName());

		offlinePaymentDetails = offlinePaymentRepo.findByUserUUID(userUUID);

		if (offlinePaymentDetails != null) {
			Collections.reverse(offlinePaymentDetails);
			for (OfflinePaymentDetails o : offlinePaymentDetails) {
				if (!o.isVerified() && !o.isRejected()
						&& userPricing.getPlanName().ordinal() < o.getPlanName().ordinal()) {
					o.setAction(true);
					break;
				}
			}
			paymentDetails.setPaymentMode(PaymentMode.OFFLINE);
			paymentDetails.setOfflineDetails(offlinePaymentDetails);
		}

		paymentOrder = paymentOrderRepo.findByUserUUIDAndPaymentStatusAndPaymentUtilityNotIn(userUUID,
				PaymentStatus.CAPTURED, PaymentUtility.BUSINESS_CREDITS);

		if (paymentOrder != null) {
			Collections.reverse(paymentOrder);
			paymentDetails.setPaymentMode(PaymentMode.ONLINE);
			paymentDetails.setOnlineDetails(paymentOrder);
		}

		return paymentDetails;
	}

	private String generateOrderID(Double amount) {
		String orderID = null;
		try {
			orderID = gatewayService.createOrderID(amount);
		} catch (RazorpayException e) {
			logger.error("Error while generating orderId from Gateway :: " + e.getMessage());
			throw new CustomException("Internal Error..try again later", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return orderID;
	}

	private PaymentOrder getPaymentOrderByOrderID(String orderID) {
		Optional<PaymentOrder> paymentOrder = null;

		paymentOrder = paymentOrderRepo.findByOrderID(orderID);
		if (paymentOrder.isPresent()) {
			return paymentOrder.get();
		} else {
			throw new CustomException("Payment Order Not Found for Order ID :: " + orderID, HttpStatus.NOT_FOUND);
		}

	}

	private Payment capturePayment(double amount, String razorpayPaymentID) {
		try {
			return gatewayService.capturePayment(amount, razorpayPaymentID);
		} catch (RazorpayException e) {
			logger.error("Error while Capturing payment from gateway :: " + e.getMessage());
			throw new CustomException("Error while Capturing payment", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private void savePaymentOrder(PaymentOrder paymentOrder) {
		try {
			paymentOrderRepo.save(paymentOrder);
			logger.info("Completed Saving Payment Order");
		} catch (Exception e) {
			logger.error("Error while Saving Payment Order");
			throw new CustomException("Error while saving payment order", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
