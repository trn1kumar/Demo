package com.gloqr.service;

import com.razorpay.Payment;
import com.razorpay.RazorpayException;

public interface GatewayService {

	/* get order_id from razorpay api */
	String createOrderID(double amount) throws RazorpayException;

	/* capture successfull authorize payment */
	Payment capturePayment(double amount, String razorpayPaymentID) throws RazorpayException;
}
