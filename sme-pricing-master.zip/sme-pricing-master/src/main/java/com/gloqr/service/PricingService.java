package com.gloqr.service;

import java.util.Map;

import com.gloqr.payment.dto.PaymentRequest;
import com.gloqr.pricing.CreditType;
import com.gloqr.pricing.PlanName;
import com.gloqr.pricing.dto.PricingDTO;
import com.gloqr.pricing.dto.PricingPlanCosting;
import com.gloqr.pricing.dto.PricingPlanDTO;
import com.gloqr.pricing.dto.PricingRequest;
import com.gloqr.pricing.dto.UserPricingDTO;

public interface PricingService {

	void addNewPricingPlan(PricingPlanDTO planDTO);

	Map<String, Object> getPricingTableData();

	void createNewUser(String sUuid, String userUUID);

	UserPricingDTO getUserPricingDetails(String sUuid);

	long checkCredits(String sUuid, CreditType creditType);

	void updateCredits(PricingRequest request);

	PricingPlanCosting getPricingPlanCost(PlanName planName);

	UserPricingDTO upgradeUserPricingPlan(String sUuid, PlanName planName);

	void updatePricing(PricingDTO pricingDTO);

	Map<String, Object> planPurchase(PaymentRequest request, boolean isSme);
}
