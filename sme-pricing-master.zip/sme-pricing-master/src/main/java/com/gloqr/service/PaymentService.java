package com.gloqr.service;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

import com.gloqr.entity.OfflinePaymentDetails;
import com.gloqr.payment.dto.CapturePayment;
import com.gloqr.payment.dto.CreatePayment;
import com.gloqr.payment.dto.CreditsCost;
import com.gloqr.payment.dto.OfflinePaymentResponse;
import com.gloqr.payment.dto.PaymentDetailsDTO;
import com.gloqr.payment.dto.PaymentRequest;
import com.gloqr.payment.dto.VerifyPayment;
import com.gloqr.pricing.CreditType;

public interface PaymentService {

	OfflinePaymentResponse createOfflinePayment(OfflinePaymentDetails offlinePaymentDetails, MultipartFile file,
			String token) throws IOException;

	CreatePayment createPayment(PaymentRequest request);

	CreditsCost calculateCreditsCost(long credits, CreditType creditType);

	boolean isUserPaymentCompleted(String userUUID);

	void verifyOfflinePayment(VerifyPayment verifyPayment, String token);

	void capturePayment(CapturePayment capturePayment);

	PaymentDetailsDTO getPaymentDetails(String userUUID, String sUuid);

}
