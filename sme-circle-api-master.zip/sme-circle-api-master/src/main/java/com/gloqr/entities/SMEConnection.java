package com.gloqr.entities;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.gloqr.constants.CircleState;

@Document(collection = "sme_connection")
public class SMEConnection extends CircleStatusInfo {

	@Id
	private String connectionUuid;

	@Field(value = "sme_id")
	private String smeId;

	public SMEConnection() {
		super();
	}

	public SMEConnection(String smeId, CircleState circleState, String statusUpdatedBy) {
		super(circleState, statusUpdatedBy);
		this.smeId = smeId;
	}

	public String getSmeId() {
		return smeId;
	}

	public void setSmeId(String smeId) {
		this.smeId = smeId;
	}

	public String getConnectionUuid() {
		return connectionUuid;
	}

	public void setConnectionUuid(String connectionUuid) {
		this.connectionUuid = connectionUuid;
	}

	@Override
	public String toString() {
		return "SMEConnection [connectionUuid=" + connectionUuid + ", smeId=" + smeId + "]";
	}

}
