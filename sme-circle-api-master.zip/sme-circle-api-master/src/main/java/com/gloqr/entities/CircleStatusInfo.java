package com.gloqr.entities;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.gloqr.audit.Auditable;
import com.gloqr.constants.CircleState;

@Document
public class CircleStatusInfo extends Auditable {

	@Field(value = "status")
	private CircleState circleState;

	@Field(value = "status_updated_by")
	private String statusUpdatedBy;

	public CircleStatusInfo() {
		super();
	}

	public CircleStatusInfo(CircleState circleState) {
		super();
		this.circleState = circleState;
	}

	public CircleStatusInfo(CircleState circleState, String statusUpdatedBy) {
		super();
		this.circleState = circleState;
		this.statusUpdatedBy = statusUpdatedBy;
	}

	public CircleState getCircleState() {
		return circleState;
	}

	public void setCircleState(CircleState circleState) {
		this.circleState = circleState;
	}

	public String getStatusUpdatedBy() {
		return statusUpdatedBy;
	}

	public void setStatusUpdatedBy(String statusUpdatedBy) {
		this.statusUpdatedBy = statusUpdatedBy;
	}

}
