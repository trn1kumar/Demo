package com.gloqr.entities;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.gloqr.constants.CircleState;

@Document(collection = "sme_receive_request")
public class ReceiveRequest extends CircleStatusInfo {

	@Id
	private String receiveReqUuid;

	@Field(value = "from_sme_id")
	private String fromSmeId;

	public ReceiveRequest() {
		super();
	}

	public ReceiveRequest(String fromSmeId, CircleState circleState) {
		super(circleState);
		this.fromSmeId = fromSmeId;
	}

	public String getFromSmeId() {
		return fromSmeId;
	}

	public void setFromSmeId(String fromSmeId) {
		this.fromSmeId = fromSmeId;
	}

	public String getReceiveReqUuid() {
		return receiveReqUuid;
	}

	public void setReceiveReqUuid(String receiveReqUuid) {
		this.receiveReqUuid = receiveReqUuid;
	}

	@Override
	public String toString() {
		return "ReceiveRequest [receiveReqUuid=" + receiveReqUuid + ", fromSmeId=" + fromSmeId + "]";
	}

}
