package com.gloqr.dto;

public class CountAndData {

	private int seeMoreCount;
	private Object data;

	public CountAndData() {
		super();
	}

	public CountAndData(Object data) {
		super();
		this.data = data;
	}

	public CountAndData(int seeMoreCount) {
		super();
		this.seeMoreCount = seeMoreCount;
	}

	public CountAndData(int seeMoreCount, Object data) {
		super();
		this.seeMoreCount = seeMoreCount;
		this.data = data;
	}

	public int getSeeMoreCount() {
		return seeMoreCount;
	}

	public void setSeeMoreCount(int seeMoreCount) {
		this.seeMoreCount = seeMoreCount;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

}
