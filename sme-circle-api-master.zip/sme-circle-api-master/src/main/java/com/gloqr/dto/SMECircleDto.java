package com.gloqr.dto;

import java.util.List;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.gloqr.constants.CirclePrivacy;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SMECircleDto {

	@NotBlank(message = "smeId requried")
	private String smeId;

	private CirclePrivacy circlePrivacy;

	private int sendReqCount;
	private int receivedReqCount;
	private int connectionCount;

	private List<SMEDto> sendRequests;

	private List<SMEDto> receiveRequests;

	private List<SMEDto> myConnetions;

	public SMECircleDto() {
		super();
	}

	public SMECircleDto(CirclePrivacy circlePrivacy) {
		super();
		this.circlePrivacy = circlePrivacy;
	}

	public List<SMEDto> getSendRequests() {
		return sendRequests;
	}

	public void setSendRequests(List<SMEDto> sendRequests) {
		this.sendRequests = sendRequests;
	}

	public List<SMEDto> getReceiveRequests() {
		return receiveRequests;
	}

	public void setReceiveRequests(List<SMEDto> receiveRequests) {
		this.receiveRequests = receiveRequests;
	}

	public List<SMEDto> getMyConnetions() {
		return myConnetions;
	}

	public void setMyConnetions(List<SMEDto> myConnetions) {
		this.myConnetions = myConnetions;
	}

	public int getSendReqCount() {
		return sendReqCount;
	}

	public void setSendReqCount(int sendReqCount) {
		this.sendReqCount = sendReqCount;
	}

	public int getReceivedReqCount() {
		return receivedReqCount;
	}

	public void setReceivedReqCount(int receivedReqCount) {
		this.receivedReqCount = receivedReqCount;
	}

	public int getConnectionCount() {
		return connectionCount;
	}

	public void setConnectionCount(int connectionCount) {
		this.connectionCount = connectionCount;
	}

	public String getSmeId() {
		return smeId;
	}

	public void setSmeId(String smeId) {
		this.smeId = smeId;
	}

	public CirclePrivacy getCirclePrivacy() {
		return circlePrivacy;
	}

	public void setCirclePrivacy(CirclePrivacy circlePrivacy) {
		this.circlePrivacy = circlePrivacy;
	}

}
