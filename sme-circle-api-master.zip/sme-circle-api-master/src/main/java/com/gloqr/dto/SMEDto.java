package com.gloqr.dto;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.gloqr.vo.ConnectionVo;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SMEDto extends ConnectionVo {

	private String smeName;

	private String contactEmail;

	private String contactPhone;

	private String logoImage;

	private AddressDto smeAddress;

	private Date creationDate;

	private String status;

	private int mutualConnectionCount;

	/*
	 * @JsonIgnoreProperties annotation for ignore recursion call when fetching
	 * sme's own mutual connection.
	 */
	@JsonIgnoreProperties("mutualConnections")
	private List<SMEDto> mutualConnections;

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

	public String getSmeName() {
		return smeName;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getLogoImage() {
		return logoImage;
	}

	public void setLogoImage(String logoImage) {
		this.logoImage = logoImage;
	}

	public List<SMEDto> getMutualConnections() {
		return mutualConnections;
	}

	public void setMutualConnections(List<SMEDto> mutualConnections) {
		this.mutualConnections = mutualConnections;
	}

	public AddressDto getSmeAddress() {
		return smeAddress;
	}

	public void setSmeAddress(AddressDto smeAddress) {
		this.smeAddress = smeAddress;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public int getMutualConnectionCount() {
		return mutualConnectionCount;
	}

	public void setMutualConnectionCount(int mutualConnectionCount) {
		this.mutualConnectionCount = mutualConnectionCount;
	}

	@Override
	public String toString() {
		return "SMEDto [smeName=" + smeName + ", logoImage=" + logoImage + ", smeAddress=" + smeAddress
				+ ", getsUuid()=" + getsUuid() + "]";
	}
}
