package com.gloqr.dao;

import com.gloqr.entities.SMECircle;

public interface SMECircleDao {

	public SMECircle saveOrUpdateSMECricle(SMECircle smeCircle);

	public SMECircle getSMECricle(String smeId);
}
