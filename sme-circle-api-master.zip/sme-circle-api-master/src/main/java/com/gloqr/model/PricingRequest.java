package com.gloqr.model;

import com.gloqr.constants.CreditType;

public class PricingRequest {

	private String userUUID;
	private String sUuid;
	private CreditType creditType;
	private String action;
	private long credits;

	public PricingRequest() {
		super();
	}

	public PricingRequest(String userUUID, String sUuid, CreditType creditType, String action, long credits) {
		super();
		this.userUUID = userUUID;
		this.sUuid = sUuid;
		this.creditType = creditType;
		this.action = action;
		this.credits = credits;
	}

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getUserUUID() {
		return userUUID;
	}

	public void setUserUUID(String userUUID) {
		this.userUUID = userUUID;
	}

	public CreditType getType() {
		return creditType;
	}

	public void setCreditType(CreditType creditType) {
		this.creditType = creditType;
	}

	public long getCredits() {
		return credits;
	}

	public void setCredits(long credits) {
		this.credits = credits;
	}

	@Override
	public String toString() {
		return "PricingRequest [userUUID=" + userUUID + ", sUuid=" + sUuid + ", type=" + creditType + ", action=" + action
				+ ", credits=" + credits + "]";
	}

}
