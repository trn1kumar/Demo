package com.gloqr.model;

import com.gloqr.constants.CreditType;

public class CreditsCheckResponse {

	private int credits;
	private String displayName;
	private CreditType creditType;

	public CreditsCheckResponse() {
		super();
	}

	public int getCredits() {
		return credits;
	}

	public void setCredits(int credits) {
		this.credits = credits;
	}

	public String getDisplayName() {
		return creditType.getValue();
	}

	public CreditType getCreditType() {
		return creditType;
	}

	public void setCreditType(CreditType creditType) {
		this.creditType = creditType;
	}

	@Override
	public String toString() {
		return "CreditsCheckResponse [credits=" + credits + ", displayName=" + displayName + ", creditType="
				+ creditType + "]";
	}

}
