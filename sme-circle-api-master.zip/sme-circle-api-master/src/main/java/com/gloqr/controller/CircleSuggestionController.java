package com.gloqr.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.Roles;
import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.SMEDto;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.security.context.holder.UserDetails;
import com.gloqr.service.SuggestSmeService;
import com.gloqr.util.PaginationUtils;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.ROOT_API)
public class CircleSuggestionController {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private SuggestSmeService suggestionService;

	@Autowired
	private PaginationUtils paginationUtils;

	@PreAuthorize(Roles.SME_ADMIN)
	@GetMapping(UrlMapping.GET_SUGGESTIONS)
	public ResponseEntity<CustomHttpResponse<List<SMEDto>>> getSuggestions(Authentication authentication,
			@RequestParam(required = false) Integer page, @RequestParam(required = false) Integer size) {

		if (page == null || page <= 0)
			page = 1;

		if (size == null) {
			size = paginationUtils.getPageSize();
		}

		final UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = user.getSmeId();
		log.info("Featching Suggestions for smeId:-  {}", loggedInSmeId);
		List<SMEDto> smes = null;

		try {
			smes = suggestionService.getSuggestions(loggedInSmeId, page, size);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(smes, "Success", HttpStatus.OK);

	}
}
