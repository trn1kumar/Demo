package com.gloqr.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.Roles;
import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.SMEDto;
import com.gloqr.dto.SMEFilterAndResultResponse;
import com.gloqr.exception.CustomException;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.security.context.holder.UserDetails;
import com.gloqr.service.SMEService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.ROOT_API)
public class SMEController {

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private SMEService smeService;

	@PreAuthorize(Roles.SME_ADMIN)
	@GetMapping(UrlMapping.TOP_SMES)
	public ResponseEntity<CustomHttpResponse<List<SMEDto>>> getTopSmes(Authentication authentication) {

		UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSme = user.getSmeId();
		List<SMEDto> smes = null;
		try {
			smes = smeService.topSmes(loggedInSme);
		} catch (CustomException e) {
			throw e;
		}

		return responseMaker.successResponse(smes, "Success", HttpStatus.OK);

	}

	@GetMapping(UrlMapping.SMES)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse<SMEFilterAndResultResponse>> getAllSmes(
			@RequestParam(required = false) Set<String> categoriesFilterParam,
			@RequestParam(required = false) Set<String> citiesFilterParam, @RequestParam(required = false) Integer page,
			Authentication authentication) {
		SMEFilterAndResultResponse filterAndResult = null;
		try {
			UserDetails user = (UserDetails) authentication.getPrincipal();
			final String loggedInSmeId = user.getSmeId();
			filterAndResult = smeService.getAllSmes(loggedInSmeId, categoriesFilterParam, citiesFilterParam,
					page);

		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(filterAndResult, "Success", HttpStatus.OK);

	}

	@GetMapping(UrlMapping.SEARCH_RESULT)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse<SMEFilterAndResultResponse>> getSearchedResults(
			@RequestParam(value = "searchText") String searchText,
			@RequestParam(required = false) Set<String> categoriesFilterParam,
			@RequestParam(required = false) Set<String> citiesFilterParam,
			@RequestParam(value = "page", defaultValue = "1") int page, Authentication authentication) {
		SMEFilterAndResultResponse smeFilterAndResultResponse = null;

		try {
			UserDetails user = (UserDetails) authentication.getPrincipal();
			final String loggedInSmeId = user.getSmeId();
			smeFilterAndResultResponse = smeService.getSearchedResults(loggedInSmeId, searchText, categoriesFilterParam,
					citiesFilterParam, page);

		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(smeFilterAndResultResponse, "Success", HttpStatus.OK);

	}
}
