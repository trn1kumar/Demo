package com.gloqr.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.Roles;
import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.CountAndData;
import com.gloqr.dto.SMECircleDto;
import com.gloqr.dto.SMEDto;
import com.gloqr.entities.SMECircle;
import com.gloqr.entities.SMEConnection;
import com.gloqr.exception.CustomException;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.security.context.holder.UserDetails;
import com.gloqr.service.MutualConnectionService;
import com.gloqr.service.SMECircleService;
import com.gloqr.service.SMEService;
import com.gloqr.service.SMEStatusCheckService;
import com.gloqr.vo.ConnectionVo;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.ROOT_API)
@SuppressWarnings("rawtypes")
public class CircleController {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private SMECircleService circleService;

	@Autowired
	private SMEService smeService;

	@Autowired
	private MutualConnectionService mutualConnectionService;

	@Autowired
	private SMEStatusCheckService smeStatusCheckService;

	@PreAuthorize(Roles.SME_ADMIN)
	@PostMapping(UrlMapping.CIRCLE)
	public ResponseEntity<CustomHttpResponse> circle(Authentication authentication) {
		final UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = user.getSmeId();
		final String loggedInUserId = user.getUserId();

		log.info("Request for creating CIRCLE by userId: {} and smeId: {}", loggedInUserId, loggedInSmeId);

		try {
			if (loggedInUserId == null || loggedInSmeId == null) {
				throw new CustomException("either 'userId' or 'smeId' is null.required both.", HttpStatus.BAD_REQUEST);
			}
			circleService.saveOrUpdateSMECricle(new SMECircle(loggedInSmeId, loggedInUserId));
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse("Circle created Successfully", HttpStatus.CREATED);

	}

	@PreAuthorize(Roles.SME_ADMIN)
	@PostMapping(UrlMapping.SEND_REQ)
	public ResponseEntity<CustomHttpResponse> sendRequest(Authentication authentication,
			@RequestBody SMECircleDto sme) {
		final UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = user.getSmeId();
		final String loggedInUserId = user.getUserId();
		final String smeId = sme.getSmeId();
		log.info("Sending Circle Request by smeId: {} to smeId: {}", loggedInSmeId, smeId);
		try {
			circleService.sendRequest(loggedInSmeId, loggedInUserId, smeId);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse("Request Sent Successfully", HttpStatus.OK);
	}

	@PreAuthorize(Roles.SME_ADMIN)
	@PostMapping(UrlMapping.ACCEPT_REQUEST)
	public ResponseEntity<CustomHttpResponse> acceptReceivedRequest(Authentication authentication,
			@RequestBody ConnectionVo connectionVo) {
		final UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = user.getSmeId();
		final String receivedReqId = connectionVo.getReceiveReqUuid();
		log.info("Accepting Received Request by smeId: {} and receivedReqId: {}", loggedInSmeId, receivedReqId);

		try {
			circleService.makeConnection(loggedInSmeId, receivedReqId);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse("Request Accepted Successfully", HttpStatus.OK);
	}

	@PreAuthorize(Roles.SME_ADMIN)
	@PostMapping(UrlMapping.REJECT_REQUEST)
	public ResponseEntity<CustomHttpResponse> rejectReceivedRequest(Authentication authentication,
			@RequestBody ConnectionVo connectionVo) {

		final UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = user.getSmeId();
		final String receivedReqId = connectionVo.getReceiveReqUuid();
		log.info("Rejecting Received Request by smeId: {} and receivedReqId: {}", loggedInSmeId, receivedReqId);

		try {
			circleService.rejectReceivedRequest(loggedInSmeId, receivedReqId);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse("Request Rejected Successfully", HttpStatus.OK);
	}

	@PreAuthorize(Roles.SME_ADMIN)
	@PostMapping(UrlMapping.CANCEL_REQUEST)
	public ResponseEntity<CustomHttpResponse> cancelSentRequest(Authentication authentication,
			@RequestBody ConnectionVo connectionVo) {
		final UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = user.getSmeId();
		final String sentReqId = connectionVo.getSendReqUuid();
		log.info("Canceling Sent Request by smeId: {} and sentReqId: {}", loggedInSmeId, sentReqId);
		try {
			circleService.cancelSentRequest(loggedInSmeId, sentReqId);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse("Request Canceled Successfully", HttpStatus.OK);

	}

	@PreAuthorize(Roles.SME_ADMIN)
	@PostMapping(UrlMapping.REMOVE_CONNECTION)
	public ResponseEntity<CustomHttpResponse> removeBusinessCircleConnection(Authentication authentication,
			@RequestBody ConnectionVo connectionVo) {
		final UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = user.getSmeId();
		final String connectionId = connectionVo.getConnectionUuid();
		log.info("Removing connection from cricle  by smeId: {} and connectionId: {}", loggedInSmeId, connectionId);
		try {
			circleService.removeConnection(loggedInSmeId, connectionId);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse("Request Removed Successfully", HttpStatus.OK);

	}

	@PreAuthorize(Roles.SME_ADMIN)
	@GetMapping(UrlMapping.GET_RECEIVED_REQUEST)
	public ResponseEntity<CustomHttpResponse<List<SMEDto>>> getReceivedReqs(Authentication authentication) {
		final UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = user.getSmeId();

		List<SMEDto> smesInfo = null;
		try {
			smesInfo = circleService.getAllReceivedRequest(loggedInSmeId);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(smesInfo, "Success", HttpStatus.OK);

	}

	@PreAuthorize(Roles.SME_ADMIN)
	@GetMapping(UrlMapping.GET_SENT_REQUEST)
	public ResponseEntity<CustomHttpResponse<List<SMEDto>>> getSentReqs(Authentication authentication) {
		final UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = user.getSmeId();

		List<SMEDto> smesInfo = null;
		try {
			smesInfo = circleService.getAllSentRequest(loggedInSmeId);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(smesInfo, "Success", HttpStatus.OK);

	}

	@PreAuthorize(Roles.SME_ADMIN)
	@GetMapping(UrlMapping.GET_COUNTS)
	public ResponseEntity<CustomHttpResponse<SMECircleDto>> getBusinessCircleCounts(Authentication authentication) {
		final UserDetails user = (UserDetails) authentication.getPrincipal();
		final String loggedInSmeId = user.getSmeId();

		return responseMaker.successResponse(circleService.getCounts(loggedInSmeId), "Success", HttpStatus.OK);

	}

	@SuppressWarnings("unchecked")
	@PreAuthorize(Roles.SME_ADMIN)
	@GetMapping(UrlMapping.GET_CONNECTION)
	public ResponseEntity<CustomHttpResponse<Object>> getCircleConnections(Authentication authentication,
			boolean isBusinessPostServiceRequest) {

		List<SMEDto> smesInfo = new ArrayList<>();
		CountAndData countAndData = null;

		try {
			UserDetails userDetails = (UserDetails) authentication.getPrincipal();
			countAndData = circleService.getSMEConnections(userDetails.getSmeId());

			if (isBusinessPostServiceRequest) {
				return responseMaker.successResponse((List<SMEConnection>) countAndData.getData(), "Success",
						HttpStatus.OK);
			}

			List<SMEConnection> conns = (List<SMEConnection>) countAndData.getData();
			List<String> connIds = conns.stream().map(SMEConnection::getSmeId).collect(Collectors.toList());
			Map<String, SMEDto> smeDetailsMap = smeService.getSpecificSmesDetails(connIds);
			mutualConnectionService.findMutualConnection(smeDetailsMap, conns);
			conns.forEach(conn -> {
				SMEDto sme = smeDetailsMap.get(conn.getSmeId());
				sme.setConnectionUuid(conn.getConnectionUuid());
				smesInfo.add(sme);
			});
			countAndData.setData(smesInfo);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(countAndData, "Success", HttpStatus.OK);

	}

	@SuppressWarnings("unchecked")
	@PreAuthorize(Roles.SME_ADMIN)
	@GetMapping(UrlMapping.GET_SME_CONNECTION)
	public ResponseEntity<CustomHttpResponse<List<SMEDto>>> getCircleConnectionsForViewMode(
			Authentication authentication, @PathVariable String smeId) {

		List<SMEDto> smesInfo = null;
		CountAndData countAndData = null;
		SMECircle loggedInSmeCircle = null;

		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String loggedInSmeId = userDetails.getSmeId();

		log.info("SME:- {} View's SME {}'s Connections", loggedInSmeId, smeId);
		try {
			countAndData = circleService.getSMEConnections(loggedInSmeId, smeId);

			List<SMEConnection> conns = (List<SMEConnection>) countAndData.getData();
			List<String> connIds = conns.stream().map(SMEConnection::getSmeId).collect(Collectors.toList());
			Map<String, SMEDto> smeDetailsMap = smeService.getSpecificSmesDetails(connIds);
			smesInfo = conns.stream().map(conn -> smeDetailsMap.get(conn.getSmeId())).collect(Collectors.toList());

			try {
				loggedInSmeCircle = circleService.getBusinessCircle(loggedInSmeId);
				if (loggedInSmeCircle.getMyConnections() != null && !loggedInSmeCircle.getMyConnections().isEmpty())
					mutualConnectionService.findMutualConnection(smesInfo, loggedInSmeCircle.getMyConnections());

			} catch (CustomException e) {
				log.warn("Exception:: message:- {}", e.getErrorMessage());

			}
			smeStatusCheckService.checkStatus(loggedInSmeCircle, smesInfo, userDetails.getSmeId());

		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(smesInfo, "Success", HttpStatus.OK);

	}

	@PreAuthorize(Roles.SME_ADMIN)
	@PutMapping(UrlMapping.CIRCLE_PRIVACY)
	public ResponseEntity<CustomHttpResponse> changeCirclePrivacy(Authentication authentication,
			@RequestBody SMECircleDto circleDto) {
		try {
			final UserDetails user = (UserDetails) authentication.getPrincipal();
			final String loggedInSmeId = user.getSmeId();
			log.info("Changing Circle Privay to {} by smeId: {}", circleDto.getCirclePrivacy(), loggedInSmeId);
			circleService.changeCirclePrivacy(loggedInSmeId, circleDto.getCirclePrivacy());
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse("Circle Privacy Changed Successfully", HttpStatus.OK);
	}

	@PreAuthorize(Roles.SME_ADMIN)
	@GetMapping(UrlMapping.CIRCLE_PRIVACY)
	public ResponseEntity<CustomHttpResponse<SMECircleDto>> getCirclePrivacy(Authentication authentication) {
		SMECircleDto circleDto = null;
		try {
			final UserDetails user = (UserDetails) authentication.getPrincipal();
			final String loggedInSmeId = user.getSmeId();
			circleDto = circleService.getCirclePrivacy(loggedInSmeId);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(circleDto, "Success", HttpStatus.OK);
	}

}
