package com.gloqr.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.gloqr.configuration.TemplateCommonUrls;
import com.gloqr.configuration.TemplateProperties;
import com.gloqr.constants.NotificationConstants;
import com.gloqr.dto.AddressDto;
import com.gloqr.dto.SMEDto;
import com.gloqr.entities.SMEConnection;
import com.gloqr.exception.CustomException;
import com.gloqr.model.notification.EmailEvent;
import com.gloqr.model.notification.SchedulerJobInfo;
import com.gloqr.model.notification.SmsEvent;
import com.gloqr.rest.endpoint.NotificationEndPoint;
import com.google.gson.Gson;

@Service
@Async("taskExecutor")
public class NotificationServiceImpl extends NotificationConstants implements NotificationService {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	@Lazy
	private SMECircleService circleService;

	@Autowired
	private SMEService smeService;

	@Autowired
	private MutualConnectionService mutualConnectionService;

	@Autowired
	private NotificationEndPoint notificationEndpoint;

	@Autowired
	private TemplateEngine templateEngine;

	@Autowired
	private TemplateProperties templateProperties;

	@Autowired
	private TemplateCommonUrls templateCommonUrls;

	private static final String SMENAME = "{smename}";
	private static final String ADDRESS = "{address}";
	private static final String SUUID = "{sUuid}";
	private static final String MUTUAL_CONN_COUNT = "{mutual-connection-count}";

	private void scheduleNewJob(String jobName, JobSubGroup schedulerSubGroup, SmsEvent smsEvent, EmailEvent emailEvent,
			String circleNotifiJobDataJsonString) {
		SchedulerJobInfo schedulerJobInfo = new SchedulerJobInfo();
		schedulerJobInfo.setJobGroup(JobGroup.CIRCLE_NOTIFICATION);
		schedulerJobInfo.setJobSubGroup(schedulerSubGroup);
		schedulerJobInfo.setJobName(jobName);
		schedulerJobInfo.setRemindNotifiJobDataJsonString(circleNotifiJobDataJsonString);
		schedulerJobInfo.setSmsEvent(smsEvent);
		schedulerJobInfo.setEmailEvent(emailEvent);

		notificationEndpoint.scheduleJob(schedulerJobInfo);
	}

	// Send Direct Notification Without Scheduling
	private void sendNotifications(List<Object> events) {
		events.parallelStream().forEach(e -> notificationEndpoint.sendNotification(e));
	}

	@Override
	public void unscheduleJob(String jobName) {
		try {
			notificationEndpoint.unscheduleJob(jobName);
		} catch (Exception e) {
			log.error("can't unscheduleJob ." + jobName, e);
		}
	}

	@Override
	public void scheduleReqReceivedNotification(SMEDto reqSenderSmeDeatils,
			List<SMEConnection> reqSenderSmesConnections, SMEDto reqReceiverSmeDeatils,
			List<SMEConnection> reqReceiverSmesConnections) {
		try {
			Map<String, Object> data = new HashMap<>();
			SmsEvent smsEvent = null;
			EmailEvent emailEvent = null;
			int mutualConnsCount = 0;
			int circleConnsCount = 0;
			String mobileNum = reqReceiverSmeDeatils.getContactPhone();
			String email = reqReceiverSmeDeatils.getContactEmail();
			String sUuid = reqReceiverSmeDeatils.getsUuid();
			checkMobileOrEmailAvailable(mobileNum, email);
			if (reqSenderSmesConnections != null && reqReceiverSmesConnections != null) {
				// filter only connected connections
				reqSenderSmesConnections = circleService.filterListByCircleState(SMEConnection.class,
						reqSenderSmesConnections);
				reqReceiverSmesConnections = circleService.filterListByCircleState(SMEConnection.class,
						reqReceiverSmesConnections);
				mutualConnsCount = mutualConnectionService
						.getMutualConnection(reqSenderSmesConnections, reqReceiverSmesConnections).size();
			}

			if (reqSenderSmesConnections != null) {
				reqSenderSmesConnections = circleService.filterListByCircleState(SMEConnection.class,
						reqSenderSmesConnections);
				circleConnsCount = reqSenderSmesConnections.size();
			}

			String reqSenderSmeName = reqSenderSmeDeatils.getSmeName();
			AddressDto address = reqSenderSmeDeatils.getSmeAddress();
			String smeAddress = "(" + address.getLocality() + ", " + address.getCity() + ")";

			if (mobileNum != null) {
				smsEvent = createPendingReqNotificationSmsEvent(reqSenderSmeName, smeAddress, mutualConnsCount,
						mobileNum, sUuid);
			}

			if (email != null) {
				emailEvent = createPendingReqNotificationEmailEvent(reqReceiverSmeDeatils, reqSenderSmeDeatils,
						smeAddress, mutualConnsCount, circleConnsCount, email, data);
			}

			data.put("reqReceiverSmeName", reqReceiverSmeDeatils.getSmeName());
			data.put("reqReceiverSmeId", reqReceiverSmeDeatils.getsUuid());

			scheduleNewJob(RECEIVED_INVITE_JOB_NAME_PREFIX + reqReceiverSmeDeatils.getReceiveReqUuid(),
					JobSubGroup.CIRCLE_INVITE_RECEIVED, smsEvent, emailEvent, new Gson().toJson(data));
		} catch (Exception e) {
			log.error("can't scheduleJob for Request Received Notification.", e);
		}

	}

	private SmsEvent createPendingReqNotificationSmsEvent(String reqSenderSmeName, String smeAddress,
			int mutualConnsCount, String mobileNum, String sUuid) {

		String smsMsg = templateProperties.getPendingReqSmsMsg().replace(SMENAME, reqSenderSmeName)
				.replace(ADDRESS, smeAddress).replace(MUTUAL_CONN_COUNT, String.valueOf(mutualConnsCount))
				.replace(SUUID, sUuid);

		return new SmsEvent(mobileNum, smsMsg);

	}

	private EmailEvent createPendingReqNotificationEmailEvent(SMEDto reqReceiverSmeDeatils, SMEDto reqSenderSmeDeatils,
			String smeAddress, int mutualConnsCount, int circleConnsCount, String email, Map<String, Object> data) {
		String emailSubject = templateProperties.getPendingReqEmailSub()
				.replace(SMENAME, reqSenderSmeDeatils.getSmeName()).replace(ADDRESS, smeAddress);
		Context context = new Context();

		data.put("urls", templateCommonUrls);
		data.put("smeDetailsUrl", templateProperties.getSmeDetailsUrl());
		data.put("pendingReqUrl", templateProperties.getPendingReqUrl());
		data.put("smeDetails", reqSenderSmeDeatils);
		data.put("reqReceiverSmeId", reqReceiverSmeDeatils.getsUuid());
		data.put("reqReceiverSmeName", reqReceiverSmeDeatils.getSmeName());
		data.put("mutualConnsCount", mutualConnsCount);
		data.put("circleConnsCount", circleConnsCount);

		context.setVariables(data);

		String eventMessage = templateEngine.process(RECEIVED_INVITE_NOTIFI_TEMPLATE, context);

		return new EmailEvent(email, emailSubject, eventMessage);
	}

	@Override
	public void sendReqAcceptedNotification(String reqSentUuid, String reqAcceptedSmeId,
			List<SMEConnection> reqAcceptedSmesConns, String reqSenderSmeId, List<SMEConnection> reqSenderSmesConns) {

		try

		{
			SmsEvent smsEvent = null;
			EmailEvent emailEvent = null;
			int mutualConnsCount = 0;
			int circleConnsCount = 0;

			List<String> smeIds = Arrays.asList(reqSenderSmeId, reqAcceptedSmeId);

			Map<String, SMEDto> smesMap = smeService.getSpecificSmesDetails(smeIds);
			smeService.checkAllSmeIsPresent(smesMap, smeIds);
			SMEDto reqSenderSmeDeatils = smesMap.get(reqSenderSmeId);
			SMEDto reqAcceptedSmeDeatils = smesMap.get(reqAcceptedSmeId);

			String mobileNum = reqSenderSmeDeatils.getContactPhone();
			String email = reqSenderSmeDeatils.getContactEmail();
			checkMobileOrEmailAvailable(mobileNum, email);

			// filter only connected connections
			reqSenderSmesConns = circleService.filterListByCircleState(SMEConnection.class, reqSenderSmesConns);
			reqAcceptedSmesConns = circleService.filterListByCircleState(SMEConnection.class, reqAcceptedSmesConns);
			mutualConnsCount = mutualConnectionService.getMutualConnection(reqSenderSmesConns, reqAcceptedSmesConns)
					.size();

			circleConnsCount = reqAcceptedSmesConns.size();

			AddressDto address = reqAcceptedSmeDeatils.getSmeAddress();
			String smeAddress = "(" + address.getLocality() + ", " + address.getCity() + ")";

			if (mobileNum != null) {
				smsEvent = createReqAcceptedNotificationSmsEvent(reqAcceptedSmeDeatils.getSmeName(), smeAddress,
						mobileNum, reqSenderSmeDeatils.getsUuid());
			}

			if (email != null) {
				emailEvent = createReqAcceptedNotificationEmailEvent(reqSenderSmeDeatils, reqAcceptedSmeDeatils,
						smeAddress, mutualConnsCount, circleConnsCount, email);
			}

			List<Object> events = new ArrayList<>();
			events.add(emailEvent);
			events.add(smsEvent);

			sendNotifications(events);
		} catch (Exception e) {
			log.error("can't send notifications events.", e);
		}

	}

	private SmsEvent createReqAcceptedNotificationSmsEvent(String reqAcceptedSmeName, String smeAddress,
			String mobileNum, String reqSenderSmeId) {
		String smsMsg = templateProperties.getAcceptedReqSmsMsg().replace(SMENAME, reqAcceptedSmeName)
				.replace(ADDRESS, smeAddress).replace(SUUID, reqSenderSmeId);

		return new SmsEvent(mobileNum, smsMsg);

	}

	private EmailEvent createReqAcceptedNotificationEmailEvent(SMEDto reqSenderSmeDeatils, SMEDto reqAcceptedSmeDeatils,
			String smeAddress, int mutualConnsCount, int circleConnsCount, String email) {

		String reqAcceptedSmeName = reqAcceptedSmeDeatils.getSmeName();

		String emailSubject = templateProperties.getAcceptedReqEmailSub().replace(SMENAME, reqAcceptedSmeName)
				.replace(ADDRESS, smeAddress);

		Context context = new Context();
		context.setVariable("urls", templateCommonUrls);
		context.setVariable("smeDetailsUrl", templateProperties.getSmeDetailsUrl());
		context.setVariable("circleUrl", templateProperties.getMyConnectionUrl());
		context.setVariable("reqAcceptedSmeDeatils", reqAcceptedSmeDeatils);
		context.setVariable("reqSenderSmeName", reqSenderSmeDeatils.getSmeName());
		context.setVariable("reqSenderSmeUuid", reqSenderSmeDeatils.getsUuid());
		context.setVariable("mutualConnsCount", mutualConnsCount);
		context.setVariable("circleConnsCount", circleConnsCount);
		String eventMessage = templateEngine.process(ACCEPTED_INVITE_NOTIFI_TEMPLATE, context);
		return new EmailEvent(email, emailSubject, eventMessage);
	}

	private void checkMobileOrEmailAvailable(String mobileNum, String email) {
		if (mobileNum == null && email == null) {
			throw new CustomException("'mobile no' and 'email' both are null.required either 'mobile no' or 'email'.",
					HttpStatus.BAD_REQUEST);
		}
	}

}
