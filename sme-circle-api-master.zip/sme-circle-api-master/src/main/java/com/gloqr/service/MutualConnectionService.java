package com.gloqr.service;

import java.util.List;
import java.util.Map;

import com.gloqr.dto.SMEDto;
import com.gloqr.entities.SMEConnection;

public interface MutualConnectionService {

	public List<String> getMutualConnection(List<SMEConnection> connectionsList1, List<SMEConnection> connectionsList2);

	public void findMutualConnection(Map<String, SMEDto> connectionDetailsMap, List<SMEConnection> circleConnections);

	public List<SMEDto> findMutualConnection(List<SMEDto> smes, List<SMEConnection> circleConnections);

}
