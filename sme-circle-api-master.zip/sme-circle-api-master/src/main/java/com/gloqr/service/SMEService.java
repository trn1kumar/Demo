package com.gloqr.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.gloqr.dto.SMEDto;
import com.gloqr.dto.SMEFilterAndResultResponse;

public interface SMEService {

	public SMEDto getSME(String smeId);

	public List<SMEDto> topSmes(String loggedInSmeId);

	public SMEFilterAndResultResponse getAllSmes(String loggedInSmeId, Set<String> categoriesFilterParam,
			Set<String> citiesFilterParam, Integer page);

	public Map<String, SMEDto> getSpecificSmesDetails(List<String> smeIds);

	public void checkAllSmeIsPresent(Map<String, SMEDto> smesMap, List<String> smeIds);

	public List<SMEDto> getCircleSuggestions(String smeId, Set<String> excludedSmeIds, int page, int size);

	public SMEFilterAndResultResponse getSearchedResults(String loggedInSmeId, String searchText,
			Set<String> categoriesFilterParam, Set<String> citiesFilterParam, int page);

}
