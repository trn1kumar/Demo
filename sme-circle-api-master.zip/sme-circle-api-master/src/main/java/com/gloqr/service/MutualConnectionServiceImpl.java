package com.gloqr.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.dto.SMEDto;
import com.gloqr.entities.SMEConnection;
import com.gloqr.exception.CustomException;

@Service
public class MutualConnectionServiceImpl implements MutualConnectionService {

	@Autowired
	private SMEService smeService;

	@Autowired
	private SMECircleService circleService;

	@Override
	public List<String> getMutualConnection(List<SMEConnection> connectionsList1,
			List<SMEConnection> connectionsList2) {

		List<String> mutualConnectionsIds = new ArrayList<>();
		connectionsList1.parallelStream().forEach(connection -> {
			String connectionId = connection.getSmeId();
			Optional<SMEConnection> opt = connectionsList2.parallelStream()
					.filter(smeConnection -> connectionId.equals(smeConnection.getSmeId())).findFirst();

			if (opt.isPresent()) {
				mutualConnectionsIds.add(opt.get().getSmeId());
			}

		});

		return mutualConnectionsIds;
	}

	@Override
	public void findMutualConnection(Map<String, SMEDto> connectionDetailsMap, List<SMEConnection> connections) {
		// get mutual connection of own's connections

		List<String> mutualConnectionsIds = null;

		if (connections == null) {
			throw new CustomException("'connections' parameter can not be null for findMutualConnection()",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

		for (SMEDto sme : connectionDetailsMap.values()) {
			try {

				List<SMEConnection> connectionsList2 = circleService.getAllConnections(sme.getsUuid(), null);
				mutualConnectionsIds = getMutualConnection(connections, connectionsList2);
				if (mutualConnectionsIds != null && !mutualConnectionsIds.isEmpty()) {
					List<SMEDto> mutualConnSmeDetails = new ArrayList<>();
					/*
					 * getting smes details from already fetched connections details i.e
					 * 'connectionDetailsMap', here json recursion exception will occurred for
					 * 'mutualConnections' field of 'SMEDto' class.solved this error by
					 * '@JsonIgnoreProperties' annotating on 'mutualConnections' field.
					 */
					mutualConnectionsIds.parallelStream()
							.forEach(mutualConnId -> mutualConnSmeDetails.add(connectionDetailsMap.get(mutualConnId)));
					sme.setMutualConnectionCount(mutualConnSmeDetails.size());
					sme.setMutualConnections(mutualConnSmeDetails);
				}

			} catch (CustomException e) {

			}
		}
	}

	@Override
	public List<SMEDto> findMutualConnection(List<SMEDto> smes, List<SMEConnection> circleConnections) {

		/*
		 * get mutual connection of sent requests and received requests and suggestions
		 */

		List<String> mutualConnectionsIds = null;

		if (circleConnections != null) {
			for (SMEDto sme : smes) {
				try {
					List<SMEConnection> connectionsList2 = circleService.getAllConnections(sme.getsUuid(), null);
					mutualConnectionsIds = getMutualConnection(circleConnections, connectionsList2);
					if (mutualConnectionsIds != null && !mutualConnectionsIds.isEmpty()) {
						Map<String, SMEDto> map = smeService.getSpecificSmesDetails(mutualConnectionsIds);
						List<SMEDto> smeDetails = new ArrayList<>(map.values());
						sme.setMutualConnectionCount(smeDetails.size());
						sme.setMutualConnections(smeDetails);
					}

				} catch (CustomException e) {

				}
			}
		}

		return smes;
	}

}
