package com.gloqr.service;

import java.util.List;

import com.gloqr.dto.SMEDto;

public interface SuggestSmeService {

	public List<SMEDto> getSuggestions(String loggedInSmeId, int page, int size);
}
