
package com.gloqr.service;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.constants.CirclePrivacy;
import com.gloqr.constants.CircleState;
import com.gloqr.constants.NotificationConstants;
import com.gloqr.dao.ConnectionDao;
import com.gloqr.dao.ReceiveRequestDao;
import com.gloqr.dao.SMECircleDao;
import com.gloqr.dao.SendRequestDao;
import com.gloqr.dto.CountAndData;
import com.gloqr.dto.SMECircleDto;
import com.gloqr.dto.SMEDto;
import com.gloqr.entities.ReceiveRequest;
import com.gloqr.entities.SMECircle;
import com.gloqr.entities.SMEConnection;
import com.gloqr.entities.SendRequest;
import com.gloqr.exception.CustomException;
import com.gloqr.repositories.SMECircleRepository;
import com.gloqr.rest.endpoint.PricingEndpoint;

@Service
public class SMECircleServiceImpl implements SMECircleService {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private SMECircleRepository circleRepository;

	@Autowired
	private SMECircleDao circleDao;

	@Autowired
	private SendRequestDao sendRequestDao;

	@Autowired
	private ReceiveRequestDao receiveRequestDao;

	@Autowired
	private ConnectionDao connectionDao;

	@Autowired
	private SMEService smeService;

	@Autowired
	private PricingEndpoint pricingEndpoint;

	@Autowired
	private MutualConnectionService mutualConnectionService;

	@Autowired
	private NotificationService notificationService;

	@Override
	public void saveOrUpdateSMECricle(SMECircle smeCircle) {
		circleDao.saveOrUpdateSMECricle(smeCircle);
	}

	@Override
	public void sendRequest(final String reqSenderSmeId, final String reqSenderUserId, final String reqReceiverSmeId) {

		SMECircle existCircle = null;
		List<SMEConnection> senderSmesConnections = null;

		List<String> smeIds = new ArrayList<>();
		if (reqSenderSmeId.equals(reqReceiverSmeId)) {
			throw new CustomException("Request Send Failed.Sending Request to Self", HttpStatus.BAD_REQUEST);
		}
		smeIds.add(reqSenderSmeId);
		smeIds.add(reqReceiverSmeId);
		Map<String, SMEDto> smesMap = smeService.getSpecificSmesDetails(smeIds);
		smeService.checkAllSmeIsPresent(smesMap, smeIds);
		log.info("Adding {} smeId into {} sme's Send Requests list", reqReceiverSmeId, reqSenderSmeId);
		try {

			// Get Exist Circle
			existCircle = circleDao.getSMECricle(reqSenderSmeId);

		} catch (CustomException e) {

			// if Circle not found then create new circle and add send request

			SMECircle circle = new SMECircle(reqSenderSmeId, reqSenderUserId);
			circle.setSendRequests(Arrays.asList(new SendRequest(reqReceiverSmeId, CircleState.PENDING)));

			this.saveOrUpdateSMECricle(circle);
		}

		// otherwise add send request into existing list
		if (existCircle != null) {
			this.checkSendRequestCriteria(existCircle, reqReceiverSmeId);

			List<SendRequest> requests = existCircle.getSendRequests();

			SendRequest sendReq = new SendRequest(reqReceiverSmeId, CircleState.PENDING);
			if (requests != null)
				requests.add(sendReq);
			else
				existCircle.setSendRequests(Arrays.asList(sendReq));

			this.saveOrUpdateSMECricle(existCircle);
			senderSmesConnections = existCircle.getMyConnections();

		}
		log.info("Added");
		addReceiveRequest(reqSenderSmeId, senderSmesConnections, reqReceiverSmeId, smesMap);

	}

	private void addReceiveRequest(String reqSenderSmeId, List<SMEConnection> senderSmesConnections,
			String reqReceiverSmeId, Map<String, SMEDto> smesDetails) {
		log.info("Adding {} smeId into {} sme's Receive Requests list", reqSenderSmeId, reqReceiverSmeId);

		SMECircle reqReceiverSmeCircle = null;
		List<SMEConnection> receiverSmesConnections = null;
		ReceiveRequest receivedReq = new ReceiveRequest(reqSenderSmeId, CircleState.PENDING);
		try {

			/*
			 * Get Exist Circle and add receive request
			 */
			reqReceiverSmeCircle = circleDao.getSMECricle(reqReceiverSmeId);

			List<ReceiveRequest> requests = reqReceiverSmeCircle.getReceiveRequests();
			if (requests != null)
				requests.add(receivedReq);
			else {
				reqReceiverSmeCircle.setReceiveRequests(Arrays.asList(receivedReq));
			}

			this.saveOrUpdateSMECricle(reqReceiverSmeCircle);
			receiverSmesConnections = reqReceiverSmeCircle.getMyConnections();

		} catch (CustomException e) {
			/*
			 * @else create new circle and add receive request
			 */
			this.saveOrUpdateSMECricle(new SMECircle(reqReceiverSmeId, Arrays.asList(receivedReq)));
		}
		log.info("Added");

		SMEDto reqSenderSmeDeatils = smesDetails.get(reqSenderSmeId);
		SMEDto reqReceiverSmeDeatils = smesDetails.get(reqReceiverSmeId);
		reqReceiverSmeDeatils.setReceiveReqUuid(receivedReq.getReceiveReqUuid());

		notificationService.scheduleReqReceivedNotification(reqSenderSmeDeatils, senderSmesConnections,
				reqReceiverSmeDeatils, receiverSmesConnections);

	}

	@Override
	public void makeConnection(final String reqReceiverSmeId, final String receivedReqId) {

		int credits = pricingEndpoint.checkCredits(reqReceiverSmeId);
		/*
		 * @ Get Business Circle of sme
		 */

		SMECircle circle = circleDao.getSMECricle(reqReceiverSmeId);

		List<SMEConnection> loggedInSmesConns = circle.getMyConnections();
		if (loggedInSmesConns != null && !loggedInSmesConns.isEmpty()) {
			long connectionsCount = loggedInSmesConns.stream()
					.filter(conn -> conn.getCircleState().equals(CircleState.CONNECTED)).count();
			if (credits <= connectionsCount) {
				throw new CustomException("You dont have left credits for accept connection",
						HttpStatus.PAYMENT_REQUIRED);
			}
		}

		// Check Accepting Request are valid or not
		if (circle.getReceiveRequests() != null && !circle.getReceiveRequests().isEmpty()) {
			Optional<ReceiveRequest> receivedReqOpt = circle.getReceiveRequests().parallelStream()
					.filter(req -> req.getReceiveReqUuid().equals(receivedReqId)
							&& req.getCircleState().equals(CircleState.PENDING))
					.findFirst();

			if (!receivedReqOpt.isPresent()) {
				throw new CustomException("Accepting Invalid Request.Given Request not found in Received Requests",
						HttpStatus.BAD_REQUEST);
			}

			// change State of request into ACCEPTED
			ReceiveRequest receiveRequest = receivedReqOpt.get();
			String reqSenderSmeId = receiveRequest.getFromSmeId();

			log.info("Updating Circle State: {} for ReceiveRequestUuid: {} (smeId:{} )" + " by: {}",
					CircleState.ACCEPTED, receivedReqId, reqSenderSmeId, reqReceiverSmeId);
			receiveRequest.setCircleState(CircleState.ACCEPTED);
			receiveRequest.setStatusUpdatedBy(reqReceiverSmeId);

			/*
			 * if it's connections is not null then add new connection in existing
			 * connections
			 */
			log.info("Adding NEW Connection into {} SME's Connections", reqReceiverSmeId);
			if (loggedInSmesConns != null && !loggedInSmesConns.isEmpty()) {
				loggedInSmesConns.add(new SMEConnection(reqSenderSmeId, CircleState.CONNECTED, reqReceiverSmeId));
			} else {
				// otherwise create new connections object and add connection in it
				circle.setMyConnections(
						Arrays.asList(new SMEConnection(reqSenderSmeId, CircleState.CONNECTED, reqReceiverSmeId)));
			}

			// update connections list of SME
			log.info("Updating Circle of Receiver SME: {}", reqReceiverSmeId);
			this.saveOrUpdateSMECricle(circle);

			// get updated connections list
			loggedInSmesConns = circle.getMyConnections();
			this.addConnectionIntoSenderSME(reqReceiverSmeId, loggedInSmesConns, reqSenderSmeId);
			notificationService.unscheduleJob(NotificationConstants.RECEIVED_INVITE_JOB_NAME_PREFIX + receivedReqId);

		} else {
			throw new CustomException("Accepting Invalid Request.Given Request not found in Received Requests",
					HttpStatus.BAD_REQUEST);
		}

	}

	private void addConnectionIntoSenderSME(String reqAcceptedSmeId, List<SMEConnection> reqAcceptedSmesConns,
			String reqSenderSmeId) {

		String reqSentUuid = null;

		/*
		 * edit connection of request sent sme
		 */

		log.info("Getting Send Requests of SME: {}", reqSenderSmeId);
		SMECircle circle = circleDao.getSMECricle(reqSenderSmeId);

		List<SendRequest> requests = circle.getSendRequests();

		Optional<SendRequest> sentReqOpt = requests.parallelStream()
				.filter(request -> request.getToSmeId().equals(reqAcceptedSmeId)
						&& request.getCircleState().equals(CircleState.PENDING))
				.findFirst();

		if (sentReqOpt.isPresent()) {
			SendRequest sentReq = sentReqOpt.get();
			log.info("Updating Circle State:  {} for sme: {} and sentRequestUuid: {}", CircleState.ACCEPTED,
					sentReq.getToSmeId(), sentReq.getSendReqUuid());
			reqSentUuid = sentReq.getSendReqUuid();
			// change State of request into ACCEPTED
			sentReq.setCircleState(CircleState.ACCEPTED);
			sentReq.setStatusUpdatedBy(reqAcceptedSmeId);
		}

		log.info("Adding NEW Connection into {} SME's Connections", reqSenderSmeId);

		// if it's connection is not null then add new connection in existing connection
		if (circle.getMyConnections() != null && !circle.getMyConnections().isEmpty()) {
			circle.getMyConnections().add(new SMEConnection(reqAcceptedSmeId, CircleState.CONNECTED, reqAcceptedSmeId));
		} else {
			// otherwise create new connection and add connection in it
			circle.setMyConnections(
					Arrays.asList(new SMEConnection(reqAcceptedSmeId, CircleState.CONNECTED, reqAcceptedSmeId)));
		}

		// update connections list of SME
		log.info("Updating Circle of Sender SME: {}", reqSenderSmeId);
		this.saveOrUpdateSMECricle(circle);

		// get updated connections list
		List<SMEConnection> reqSenderSmesConns = circle.getMyConnections();
		notificationService.sendReqAcceptedNotification(reqSentUuid, reqAcceptedSmeId, reqAcceptedSmesConns,
				reqSenderSmeId, reqSenderSmesConns);

	}

	@Override
	public void rejectReceivedRequest(final String reqReceiverSmeId, final String receivedReqId) {

		/*
		 * @Get ReceivedRequest by SmeId and update it by request rejected
		 */

		ReceiveRequest receiveRequest = receiveRequestDao.getReceivedRequest(receivedReqId);
		receiveRequest.setCircleState(CircleState.REJECTED);
		receiveRequest.setStatusUpdatedBy(reqReceiverSmeId);
		log.info("Updating Circle State:  {} for ReceiveRequestId: {} (smeId:{} )" + " by: {}", CircleState.REJECTED,
				receivedReqId, receiveRequest.getFromSmeId(), reqReceiverSmeId);
		receiveRequestDao.saveReceivedReq(receiveRequest);

		/*
		 * @Get SentRequest of SenderSmeId and update it by request rejected
		 */

		log.info("Getting Sent Requests of SME: {}", receiveRequest.getFromSmeId());
		SMECircle circle1 = this.getBusinessCircle(receiveRequest.getFromSmeId());
		List<SendRequest> sentRequests = circle1.getSendRequests();
		sentRequests.parallelStream().forEach(sentRequest -> {

			if (sentRequest.getToSmeId().equals(reqReceiverSmeId)
					&& sentRequest.getCircleState().equals(CircleState.PENDING)) {
				log.info("Updating Circle State:  {} for SME: {} and SentRequestUuid: ", CircleState.REJECTED,
						sentRequest.getToSmeId(), sentRequest.getSendReqUuid());
				sentRequest.setCircleState(CircleState.REJECTED);
				sentRequest.setStatusUpdatedBy(reqReceiverSmeId);
				sendRequestDao.save(sentRequest);
			}

		});

		notificationService.unscheduleJob(NotificationConstants.RECEIVED_INVITE_JOB_NAME_PREFIX + receivedReqId);

	}

	@Override
	public void cancelSentRequest(final String reqSenderSmeId, final String sentReqId) {

		/*
		 * Get SendRequest by SmeId and update it by request CANCELED
		 */
		SendRequest sentRequest = sendRequestDao.getSentRequest(sentReqId);
		sentRequest.setCircleState(CircleState.CANCELED);
		sentRequest.setStatusUpdatedBy(reqSenderSmeId);
		log.info("Updating Circle State:  {} for sentRequestUuid: {} (smeId:{} )" + " by: {}", CircleState.CANCELED,
				sentReqId, sentRequest.getToSmeId(), reqSenderSmeId);

		sendRequestDao.save(sentRequest);

		/*
		 * @Get Received Request of Request Receiver SmeId and update it by request
		 * CANCELED
		 */
		log.info("Getting Receive Requests of SME: {}", sentRequest.getToSmeId());
		SMECircle smeCircle = this.getBusinessCircle(sentRequest.getToSmeId());
		List<ReceiveRequest> receiveRequests = smeCircle.getReceiveRequests();
		receiveRequests.parallelStream().forEach(req -> {

			if (req.getFromSmeId().equals(reqSenderSmeId) && req.getCircleState().equals(CircleState.PENDING)) {
				log.info("Updating Circle State:  {} for SME: {} and ReceiveRequestUuid: ", CircleState.CANCELED,
						req.getFromSmeId(), req.getReceiveReqUuid());

				req.setCircleState(CircleState.CANCELED);
				req.setStatusUpdatedBy(reqSenderSmeId);
				receiveRequestDao.saveReceivedReq(req);
				notificationService
						.unscheduleJob(NotificationConstants.RECEIVED_INVITE_JOB_NAME_PREFIX + req.getReceiveReqUuid());
			}
		});
	}

	@Override
	public void removeConnection(final String loggedInSmeId, final String connectionId) {

		/*
		 * @Get MyConnection by SmeId and update it by connection removed
		 */

		SMEConnection myConnection = connectionDao.getConnection(connectionId);
		myConnection.setCircleState(CircleState.DISCONNECTED);
		myConnection.setStatusUpdatedBy(loggedInSmeId);
		log.info("Updating Circle State:  {} for connectionUuid: {} (smeId:{} )" + " by: {}", CircleState.DISCONNECTED,
				connectionId, myConnection.getSmeId(), loggedInSmeId);

		connectionDao.saveConnection(myConnection);

		/*
		 * @Get MyConnection of connectedSmeId and update it by connection removed
		 */
		log.info("Getting Connections of SME: {}", myConnection.getSmeId());
		SMECircle myCircle = this.getBusinessCircle(myConnection.getSmeId());
		List<SMEConnection> connections = myCircle.getMyConnections();
		connections.parallelStream().forEach(conn -> {
			if (conn.getSmeId().equals(loggedInSmeId) && conn.getCircleState().equals(CircleState.CONNECTED)) {
				log.info("Updating Circle State:  {} for SME: {} and connectionUuid: ", CircleState.DISCONNECTED,
						conn.getSmeId(), conn.getConnectionUuid());

				conn.setCircleState(CircleState.DISCONNECTED);
				conn.setStatusUpdatedBy(loggedInSmeId);
				connectionDao.saveConnection(conn);
			}
		});

		log.info("Disconnected both SME: {} and {}", loggedInSmeId, myConnection.getSmeId());
	}

	@Override
	public SMECircle getBusinessCircle(String smeId) {

		List<SendRequest> filteredList = null;
		List<ReceiveRequest> filteredList1 = null;
		List<SMEConnection> filteredList2 = null;

		Optional<SMECircle> circle = circleRepository.findBySmeId(smeId);
		if (circle.isPresent()) {
			SMECircle cir = circle.get();

			if (cir.getSendRequests() != null && !cir.getSendRequests().isEmpty()) {
				filteredList = filterListByCircleState(SendRequest.class, cir.getSendRequests());
				Collections.reverse(filteredList);
			}

			if (cir.getReceiveRequests() != null && !cir.getReceiveRequests().isEmpty()) {
				filteredList1 = filterListByCircleState(ReceiveRequest.class, cir.getReceiveRequests());
				Collections.reverse(filteredList1);
			}

			if (cir.getMyConnections() != null && !cir.getMyConnections().isEmpty()) {
				filteredList2 = filterListByCircleState(SMEConnection.class, cir.getMyConnections());
			}

			cir.setSendRequests(filteredList);
			cir.setReceiveRequests(filteredList1);
			cir.setMyConnections(filteredList2);

			return cir;
		} else {
			throw new CustomException("BusinessCircle Not Found For :: " + smeId, HttpStatus.NOT_FOUND);
		}

	}

	@SuppressWarnings("unchecked")
	public <T> List<T> filterListByCircleState(Class<T> t, List<T> lists) {

		if (t.isAssignableFrom(SMEConnection.class)) {
			return (List<T>) ((List<SMEConnection>) lists).stream()
					.filter(conn -> conn.getCircleState().equals(CircleState.CONNECTED)).collect(Collectors.toList());
		} else if (t.isAssignableFrom(SendRequest.class)) {
			return (List<T>) ((List<SendRequest>) lists).stream()
					.filter(req -> req.getCircleState().equals(CircleState.PENDING)).collect(Collectors.toList());
		} else if (t.isAssignableFrom(ReceiveRequest.class)) {
			return (List<T>) ((List<ReceiveRequest>) lists).stream()
					.filter(req -> req.getCircleState().equals(CircleState.PENDING)).collect(Collectors.toList());
		} else {
			throw new CustomException(
					"Invalid isAssignableFrom class selection for filtering lists. Allowed only 'SMEConnection, SendRequest and ReceiveRequest' classes",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@Override
	public List<SMEConnection> getAllConnections(String smeId, String circleViewerSmeId) {
		SMECircle circle = this.getBusinessCircle(smeId);
		List<SMEConnection> connections = circle.getMyConnections();
		if (!(connections != null && !connections.isEmpty()))
			throw new CustomException("There is No Connection in " + smeId + "'s Circle", HttpStatus.NOT_FOUND);

		if (circleViewerSmeId != null) {
			if (circle.getCirclePrivacy().equals(CirclePrivacy.PRIVATE))
				throw new CustomException("This Circle is Private", 600, HttpStatus.FORBIDDEN);
			else if (circle.getCirclePrivacy().equals(CirclePrivacy.CIRCLE)
					&& connections.stream().noneMatch(conn -> conn.getSmeId().equals(circleViewerSmeId)))
				throw new CustomException("You are not Authorized to View this Circle", 600, HttpStatus.FORBIDDEN);
		}

		return connections;
	}

	@Override
	public CountAndData getSMEConnections(String smeId) {
		List<SMEConnection> connections = this.getAllConnections(smeId, null);
		return getOpenConnections(smeId, connections);
	}

	@Override
	public CountAndData getSMEConnections(String loggedInSmeId, String smeId) {
		List<SMEConnection> connections = this.getAllConnections(smeId, loggedInSmeId);
		return getOpenConnections(smeId, connections);
	}

	private CountAndData getOpenConnections(String smeId, List<SMEConnection> connections) {
		int circleCredits = pricingEndpoint.checkCredits(smeId);
		int connectionsCount = connections.size();
		int diffInBothCount = connectionsCount - circleCredits;

		List<SMEConnection> modifiedList = new ArrayList<>();

		if (diffInBothCount < 0) {
			return new CountAndData(connections);

		} else {
			for (int i = 0; i < circleCredits; i++) {
				modifiedList.add(connections.get(i));
			}
			return new CountAndData(diffInBothCount, modifiedList);
		}
	}

	@Override
	public List<SMEDto> getAllReceivedRequest(String smeId) {

		List<SMEDto> smesInfo = new ArrayList<>();
		SMECircle circle = this.getBusinessCircle(smeId);
		List<ReceiveRequest> receivedReqs = circle.getReceiveRequests();

		if (receivedReqs != null && !receivedReqs.isEmpty()) {
			List<String> receivedReqIds = receivedReqs.stream().map(ReceiveRequest::getFromSmeId)
					.collect(Collectors.toList());
			Map<String, SMEDto> smeDetailsMap = smeService.getSpecificSmesDetails(receivedReqIds);
			receivedReqs.forEach(req -> {
				SMEDto sme = smeDetailsMap.get(req.getFromSmeId());
				sme.setCreationDate(req.getCreationDate());
				sme.setReceiveReqUuid(req.getReceiveReqUuid());
				smesInfo.add(sme);

			});

			mutualConnectionService.findMutualConnection(smesInfo, circle.getMyConnections());
			return smesInfo;
		} else {
			throw new CustomException("No pending received request available for " + smeId, HttpStatus.NOT_FOUND);
		}

	}

	@Override
	public List<SMEDto> getAllSentRequest(String smeId) {
		List<SMEDto> smesInfo = new ArrayList<>();
		SMECircle circle = this.getBusinessCircle(smeId);
		List<SendRequest> sentRequests = circle.getSendRequests();
		if (sentRequests != null && !sentRequests.isEmpty()) {
			List<String> sendReqIds = sentRequests.stream().map(SendRequest::getToSmeId).collect(Collectors.toList());
			Map<String, SMEDto> smeDetailsMap = smeService.getSpecificSmesDetails(sendReqIds);

			sentRequests.forEach(req -> {
				SMEDto sme = smeDetailsMap.get(req.getToSmeId());
				sme.setCreationDate(req.getCreationDate());
				sme.setSendReqUuid(req.getSendReqUuid());
				smesInfo.add(sme);
			});

			mutualConnectionService.findMutualConnection(smesInfo, circle.getMyConnections());
			return smesInfo;
		} else {
			throw new CustomException("No sent request available for " + smeId, HttpStatus.FOUND);
		}

	}


	@Override
	public void changeCirclePrivacy(String smeId, CirclePrivacy newPrivacy) {

		SMECircle circle = circleDao.getSMECricle(smeId);
		circle.setCirclePrivacy(newPrivacy);
		circleDao.saveOrUpdateSMECricle(circle);
	}

	@Override
	public SMECircleDto getCounts(String smeId) {
		SMECircle smeCircle = this.getBusinessCircle(smeId);
		SMECircleDto circleDto = new SMECircleDto();
		if (smeCircle.getMyConnections() != null)
			circleDto.setConnectionCount(smeCircle.getMyConnections().size());
		if (smeCircle.getSendRequests() != null)
			circleDto.setSendReqCount(smeCircle.getSendRequests().size());
		if (smeCircle.getReceiveRequests() != null)
			circleDto.setReceivedReqCount(smeCircle.getReceiveRequests().size());
		return circleDto;
	}

	@Override
	public SMECircleDto getCirclePrivacy(String smeId) {
		SMECircle circle = circleDao.getSMECricle(smeId);
		return new SMECircleDto(circle.getCirclePrivacy());
	}

	private void checkSendRequestCriteria(SMECircle existCircle, String sendReqId) {

		try {
			List<SendRequest> requests = existCircle.getSendRequests();
			if (requests != null)
				requests.forEach(req -> {
					if (req.getToSmeId().equals(sendReqId) && req.getCircleState().equals(CircleState.PENDING)) {
						throw new CustomException("Request already sent to given SME", HttpStatus.BAD_REQUEST);
					}
				});

			List<SMEConnection> connections = existCircle.getMyConnections();
			if (connections != null)
				connections.forEach(con -> {
					if (con.getSmeId().equals(sendReqId) && con.getCircleState().equals(CircleState.CONNECTED)) {
						throw new CustomException("This SME is Already Connected.", HttpStatus.BAD_REQUEST);
					}
				});

			List<ReceiveRequest> receivedReq = existCircle.getReceiveRequests();
			if (receivedReq != null)
				receivedReq.forEach(req -> {
					if (req.getFromSmeId().equals(sendReqId) && req.getCircleState().equals(CircleState.PENDING)) {
						throw new CustomException("This SME is Already in Received Request List",
								HttpStatus.BAD_REQUEST);
					}
				});
		} catch (UndeclaredThrowableException e) {
			handleUndeclaredThrowableException(e.getCause());
		}

	}

	private CustomException handleUndeclaredThrowableException(Throwable unwrap) {
		for (;;) {

			if (unwrap instanceof InvocationTargetException) {
				unwrap = ((InvocationTargetException) unwrap).getTargetException();
			}

			if (unwrap instanceof CustomException) {
				throw (CustomException) unwrap;
			}
			break;
		}
		throw new CustomException("Exception while handling UndeclaredThrowableException ",
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
