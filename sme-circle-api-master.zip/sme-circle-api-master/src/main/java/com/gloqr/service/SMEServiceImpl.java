package com.gloqr.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.dto.SMEDto;
import com.gloqr.dto.SMEFilterAndResultResponse;
import com.gloqr.entities.SMECircle;
import com.gloqr.exception.CustomException;
import com.gloqr.rest.endpoint.SmeEndPoint;

@Service
public class SMEServiceImpl implements SMEService {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private SmeEndPoint smeEndPoint;

	@Autowired
	private SMEStatusCheckService smeStatusCheckService;

	@Autowired
	private SMECircleServiceImpl circleService;

	@Override
	public List<SMEDto> getCircleSuggestions(String smeId, Set<String> excludedSmeIds, int page, int size) {
		List<SMEDto> suggestedSmes = smeEndPoint.getCircleSuggestions(excludedSmeIds, page, size);
		if (suggestedSmes != null && !suggestedSmes.isEmpty())
			return suggestedSmes;
		else
			throw new CustomException("No More Suggestions Found for SME :: " + smeId, HttpStatus.NOT_FOUND);
	}

	@Override
	public SMEFilterAndResultResponse getSearchedResults(String loggedInSmeId, String searchText,
			Set<String> categoriesFilterParam, Set<String> citiesFilterParam, int page) {
		SMECircle smeCircle = getBusinessCircle(loggedInSmeId);
		SMEFilterAndResultResponse filterAndResult = smeEndPoint.getSearchedResults(searchText, categoriesFilterParam,
				citiesFilterParam, page);

		smeStatusCheckService.checkStatus(smeCircle, filterAndResult.getResult(), loggedInSmeId);
		return filterAndResult;
	}

	@Override
	public SMEDto getSME(String smeId) {
		return smeEndPoint.getSME(smeId);
	}

	@Override
	public List<SMEDto> topSmes(String loggedInSmeId) {

		List<SMEDto> smes = null;
		SMECircle smeCircle = getBusinessCircle(loggedInSmeId);

		try {
			smes = smeEndPoint.getTopSME();
		} catch (CustomException e) {
			throw e;
		}
		smeStatusCheckService.checkStatus(smeCircle, smes, loggedInSmeId);

		return smes;
	}

	// SME's for Filter Page
	@Override
	public SMEFilterAndResultResponse getAllSmes(String loggedInSmeId, Set<String> categoriesFilterParam,
			Set<String> citiesFilterParam, Integer page) {
		SMECircle smeCircle = getBusinessCircle(loggedInSmeId);

		SMEFilterAndResultResponse filterAndResult = this.getAllSME(categoriesFilterParam, citiesFilterParam, page);
		smeStatusCheckService.checkStatus(smeCircle, filterAndResult.getResult(), loggedInSmeId);

		return filterAndResult;
	}

	private SMEFilterAndResultResponse getAllSME(Set<String> categoriesFilterParam, Set<String> citiesFilterParam,
			Integer page) {
		SMEFilterAndResultResponse filterAndResult = null;
		try {
			filterAndResult = smeEndPoint.getAllSME(categoriesFilterParam, citiesFilterParam, page);
			if (filterAndResult == null) {
				throw new CustomException("SMEFilterAndResultResponse is Empty", HttpStatus.NOT_FOUND);
			}
		} catch (CustomException e) {
			throw e;
		}

		return filterAndResult;
	}

	@Override
	public Map<String, SMEDto> getSpecificSmesDetails(List<String> smeIds) {
		return smeEndPoint.getSpecificSMEs(smeIds);
	}

	private SMECircle getBusinessCircle(String smeId) {
		SMECircle smeCircle = null;

		try {
			smeCircle = circleService.getBusinessCircle(smeId);
		} catch (CustomException e) {
			log.warn("Exception:: message: {}", e.getErrorMessage());
		}

		return smeCircle;
	}

	@Override
	public void checkAllSmeIsPresent(Map<String, SMEDto> smesMap, List<String> smeIds) {

		smeIds.parallelStream().forEach(smeId -> {
			if (!smesMap.containsKey(smeId)) {
				throw new CustomException("Given SME is in deactive mode or not found with smeId: " + smeId,
						HttpStatus.NOT_FOUND);
			}
		});

	}

}
