package com.gloqr.service;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.constants.CircleModuleConstants.CircleStatus;
import com.gloqr.dto.SMEDto;
import com.gloqr.entities.ReceiveRequest;
import com.gloqr.entities.SMECircle;
import com.gloqr.entities.SMEConnection;
import com.gloqr.entities.SendRequest;
import com.gloqr.exception.CustomException;

@Service
public class SMEStatusCheckServiceImpl implements SMEStatusCheckService {

	@Override
	public void checkStatus(SMECircle myCircle, List<SMEDto> smes, String loggedInSme) {

		Thread t1 = new Thread(() -> {
			List<SMEConnection> connections = myCircle.getMyConnections();
			if (connections != null && !connections.isEmpty()) {
				this.setStatusOfMyConnectedSmes(connections, smes);
			}
		}, "connectionsStatusCheckingThread");

		Thread t2 = new Thread(() -> {
			List<SendRequest> sentReqs = myCircle.getSendRequests();
			if (sentReqs != null && !sentReqs.isEmpty()) {
				this.setStatusOfSentReqSmes(sentReqs, smes);
			}
		}, "sentReqsStatusCheckingThread");

		Thread t3 = new Thread(() -> {
			List<ReceiveRequest> recievedReqs = myCircle.getReceiveRequests();
			if (recievedReqs != null && !recievedReqs.isEmpty()) {
				this.setStatusOfRecievedReqSmes(recievedReqs, smes);
			}
		}, "recievedReqsStatusCheckingThread");

		if (myCircle != null) {
			t1.start();
			t2.start();
			t3.start();

			try {
				t1.join();
				t2.join();
				t3.join();
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				throw new CustomException("Exception in checkStatus() { }" + e.getMessage(),
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		}

		smes.parallelStream().forEach(sme -> {
			if (sme.getsUuid().equals(loggedInSme)) {
				sme.setStatus(CircleStatus.OWNER);
			}
			if (sme.getStatus() == null) {
				sme.setStatus(CircleStatus.NEW);
			}
		});

	}

	private void setStatusOfMyConnectedSmes(List<SMEConnection> myConns, List<SMEDto> smes) {

		myConns.parallelStream().forEach(myConn -> smes.parallelStream().forEach(sme -> {
			if (myConn.getSmeId().equals(sme.getsUuid())) {
				sme.setStatus(CircleStatus.CONNECTED);
			}
		}));

	}

	private void setStatusOfSentReqSmes(List<SendRequest> sentReqs, List<SMEDto> smes) {
		sentReqs.parallelStream().forEach(sentReq -> smes.parallelStream().forEach(sme -> {
			if (sentReq.getToSmeId().equals(sme.getsUuid())) {
				sme.setStatus(CircleStatus.SENT_REQ);
			}
		}));
	}

	private void setStatusOfRecievedReqSmes(List<ReceiveRequest> recieveReqs, List<SMEDto> smes) {
		recieveReqs.parallelStream().forEach(recieveReq -> smes.parallelStream().forEach(sme -> {
			if (recieveReq.getFromSmeId().equals(sme.getsUuid())) {
				sme.setStatus(CircleStatus.RECIEVED_REQ);
			}
		}));
	}
}
