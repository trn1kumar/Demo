package com.gloqr.service;

import java.util.List;

import com.gloqr.constants.CirclePrivacy;
import com.gloqr.dto.CountAndData;
import com.gloqr.dto.SMECircleDto;
import com.gloqr.dto.SMEDto;
import com.gloqr.entities.SMECircle;
import com.gloqr.entities.SMEConnection;

public interface SMECircleService {

	public void saveOrUpdateSMECricle(SMECircle circle);

	public void sendRequest(final String loggedInSmeId, final String loggedInUserId, final String reqReceiverSmeId);

	public void makeConnection(final String loggedInSmeId, final String receivedReqId);

	public void rejectReceivedRequest(final String loggedInSmeId, final String receivedReqId);

	public void cancelSentRequest(final String loggedInSmeId, final String sentReqId);

	public void removeConnection(final String loggedInSmeId, final String connectionId);

	public SMECircle getBusinessCircle(String loggedInSmeId);

	public List<SMEDto> getAllReceivedRequest(String loggedInSmeId);

	public List<SMEDto> getAllSentRequest(String loggedInSmeId);

	public List<SMEConnection> getAllConnections(String smeId, String circleViewerSmeId);

	public void changeCirclePrivacy(String loggedInSmeId, CirclePrivacy newPrivacy);

	public CountAndData getSMEConnections(String loggedInSmeId);

	public SMECircleDto getCounts(String loggedInSmeId);

	public <T> List<T> filterListByCircleState(Class<T> t, List<T> lists);

	public SMECircleDto getCirclePrivacy(String loggedInSmeId);

	public CountAndData getSMEConnections(String loggedInSmeId, String smeId);

}
