package com.gloqr.service;

import java.util.List;

import com.gloqr.dto.SMEDto;
import com.gloqr.entities.SMEConnection;

public interface NotificationService {

	void scheduleReqReceivedNotification(SMEDto reqSenderSmeDeatils, List<SMEConnection> reqSenderSmesConnections,
			SMEDto reqReceiverSmeDeatils, List<SMEConnection> reqReceiverSmesConnections);

	void unscheduleJob(String jobName);

	void sendReqAcceptedNotification(String reqSentUuid, String reqAcceptedSmeId,
			List<SMEConnection> reqAcceptedSmesConns, String reqSenderSmeId, List<SMEConnection> reqSenderSmesConns);

}
