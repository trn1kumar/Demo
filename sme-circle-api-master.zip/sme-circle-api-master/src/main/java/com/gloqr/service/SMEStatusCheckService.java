package com.gloqr.service;

import java.util.List;

import com.gloqr.dto.SMEDto;
import com.gloqr.entities.SMECircle;

public interface SMEStatusCheckService {

	public void checkStatus(SMECircle myCircle, List<SMEDto> smes,String smeId);

}
