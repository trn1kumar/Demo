package com.gloqr.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.dto.SMEDto;
import com.gloqr.entities.ReceiveRequest;
import com.gloqr.entities.SMECircle;
import com.gloqr.entities.SMEConnection;
import com.gloqr.entities.SendRequest;
import com.gloqr.exception.CustomException;

@Service
public class SuggestSmeServiceImpl implements SuggestSmeService {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private SMECircleService circleService;

	@Autowired
	private SMEService smeService;

	@Autowired
	private MutualConnectionService mutualConnectionService;

	@Override
	public List<SMEDto> getSuggestions(String smeId, int page, int size) {

		SMECircle smeCircle = null;
		Set<String> excludedSmeIds = new HashSet<>();

		List<SMEDto> smes = null;

		try {
			smeCircle = circleService.getBusinessCircle(smeId);
		} catch (CustomException e) {
			log.error("Exception In getBusinessCircle():: Message:- {}", e.getErrorMessage());
		}

		if (smeCircle != null) {
			addExcludedSmeIds(smeCircle, excludedSmeIds);
			smes = smeService.getCircleSuggestions(smeId, excludedSmeIds, page, size);
			List<SMEConnection> connections = smeCircle.getMyConnections();
			mutualConnectionService.findMutualConnection(smes, connections);
		} else {
			smes = smeService.getCircleSuggestions(smeId, excludedSmeIds, page, size);
		}

		return smes;

	}

	private Set<String> addExcludedSmeIds(SMECircle smeCircle, Set<String> excludedSmeIds) {
		if (smeCircle.getMyConnections() != null && !smeCircle.getMyConnections().isEmpty()) {
			for (SMEConnection conn : smeCircle.getMyConnections()) {
				excludedSmeIds.add(conn.getSmeId());
			}
		}

		if (smeCircle.getSendRequests() != null && !smeCircle.getSendRequests().isEmpty()) {
			for (SendRequest req : smeCircle.getSendRequests()) {
				excludedSmeIds.add(req.getToSmeId());
			}
		}

		if (smeCircle.getReceiveRequests() != null && !smeCircle.getReceiveRequests().isEmpty()) {
			for (ReceiveRequest req : smeCircle.getReceiveRequests()) {
				excludedSmeIds.add(req.getFromSmeId());
			}
		}
		return excludedSmeIds;
	}
}
