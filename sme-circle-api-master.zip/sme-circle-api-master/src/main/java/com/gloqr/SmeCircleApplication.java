package com.gloqr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableMongoAuditing
@EnableAsync
@PropertySource(value = { "file:${location}/sme_circle.properties" })
public class SmeCircleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmeCircleApplication.class, args);
	}
}
