package com.gloqr.security.configuration;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.gloqr.exception.CustomException;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;

@Component
public class JwtTokenUtil {

	public Claims getJwtClaims(String jwtToken) {
		try {

			final JwtParser jwtParser = Jwts.parser().setSigningKey(JwtConstants.SIGNING_KEY);

			final Jws<?> claimsJws = jwtParser.parseClaimsJws(jwtToken);

			return (Claims) claimsJws.getBody();
		} catch (ExpiredJwtException e) {
			throw new CustomException("The JwtToken is expired and not valid anymore", HttpStatus.FORBIDDEN, e);
		} catch (SignatureException e) {
			throw new CustomException("Invalid JwtToken Signature. Message: " + e.getMessage(), HttpStatus.FORBIDDEN,
					e);
		} catch (MalformedJwtException e) {
			throw new CustomException("Invalid JwtToken Format. Message: " + e.getMessage(), HttpStatus.FORBIDDEN, e);
		} catch (Exception e) {
			throw new CustomException("an error occured during parsing JwtToken. Message: " + e.getMessage(),
					HttpStatus.FORBIDDEN, e);
		}

	}

}
