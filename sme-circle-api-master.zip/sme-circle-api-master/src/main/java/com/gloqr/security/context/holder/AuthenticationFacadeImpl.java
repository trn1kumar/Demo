package com.gloqr.security.context.holder;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.gloqr.security.configuration.JwtConstants;

@Component
public class AuthenticationFacadeImpl implements AuthenticationFacade {

	@Override
	public Authentication getAuthentication() {
		return SecurityContextHolder.getContext().getAuthentication();
	}

	@Override
	public String getJwtToken() {
		HttpServletRequest curRequest = this.getCurrentServletRequest();
		return curRequest.getHeader(JwtConstants.HEADER_STRING);
	}

}
