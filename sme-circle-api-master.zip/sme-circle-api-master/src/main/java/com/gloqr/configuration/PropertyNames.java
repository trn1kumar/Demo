package com.gloqr.configuration;

public class PropertyNames {

	private PropertyNames() {
		throw new IllegalStateException("PropertyNames class.can't initiate");
	}

	//NOTIFICATIONS
	public static final String PENDING_REQ_NOTIFI_SMS_MSG = "${notify.sms-msg.pending-req}";
	public static final String PENDING_REQ_NOTIFI_EMAIL_SUB = "${notify.email-subject.pending-req}";
	public static final String ACCEPTED_REQ_NOTIFI_SMS_MSG = "${notify.sms-msg.accepted-req}";
	public static final String ACCEPTED_REQ_NOTIFI_EMAIL_SUB = "${notify.email-subject.accepted-req}";
	public static final String SME_DETAILS_URL = "${sme.details.localized-url}";
	public static final String MY_CONNECTION_URL = "${my-connections.localized-url}";
	public static final String PENDING_REQ_URL = "${pending-req.localized-url}";

	// PAGINATIONS
	public static final String NORMAL_PAGE_SIZE = "${normal-page-size}";
	public static final String MOBILE_PAGE_SIZE = "${mobile-page-size}";
	public static final String TABLET_PAGE_SIZE = "${tablet-page-size}";

}
