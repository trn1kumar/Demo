package com.gloqr.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TemplateProperties {

	@Value(PropertyNames.PENDING_REQ_NOTIFI_SMS_MSG)
	private String pendingReqSmsMsg;

	@Value(PropertyNames.PENDING_REQ_NOTIFI_EMAIL_SUB)
	private String pendingReqEmailSub;

	@Value(PropertyNames.ACCEPTED_REQ_NOTIFI_SMS_MSG)
	private String acceptedReqSmsMsg;

	@Value(PropertyNames.ACCEPTED_REQ_NOTIFI_EMAIL_SUB)
	private String acceptedReqEmailSub;

	@Value(PropertyNames.SME_DETAILS_URL)
	private String smeDetailsUrl;

	@Value(PropertyNames.PENDING_REQ_URL)
	private String pendingReqUrl;

	@Value(PropertyNames.MY_CONNECTION_URL)
	private String myConnectionUrl;

	public String getMyConnectionUrl() {
		return myConnectionUrl;
	}

	public void setMyConnectionUrl(String myConnectionUrl) {
		this.myConnectionUrl = myConnectionUrl;
	}

	public String getPendingReqSmsMsg() {
		return pendingReqSmsMsg;
	}

	public void setPendingReqSmsMsg(String pendingReqSmsMsg) {
		this.pendingReqSmsMsg = pendingReqSmsMsg;
	}

	public String getPendingReqEmailSub() {
		return pendingReqEmailSub;
	}

	public void setPendingReqEmailSub(String pendingReqEmailSub) {
		this.pendingReqEmailSub = pendingReqEmailSub;
	}

	public String getAcceptedReqSmsMsg() {
		return acceptedReqSmsMsg;
	}

	public void setAcceptedReqSmsMsg(String acceptedReqSmsMsg) {
		this.acceptedReqSmsMsg = acceptedReqSmsMsg;
	}

	public String getAcceptedReqEmailSub() {
		return acceptedReqEmailSub;
	}

	public void setAcceptedReqEmailSub(String acceptedReqEmailSub) {
		this.acceptedReqEmailSub = acceptedReqEmailSub;
	}

	public String getSmeDetailsUrl() {
		return smeDetailsUrl;
	}

	public void setSmeDetailsUrl(String smeDetailsUrl) {
		this.smeDetailsUrl = smeDetailsUrl;
	}

	public String getPendingReqUrl() {
		return pendingReqUrl;
	}

	public void setPendingReqUrl(String pendingReqUrl) {
		this.pendingReqUrl = pendingReqUrl;
	}




}
