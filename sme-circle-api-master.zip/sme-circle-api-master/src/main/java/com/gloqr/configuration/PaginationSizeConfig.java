package com.gloqr.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PaginationSizeConfig {

	@Value(PropertyNames.NORMAL_PAGE_SIZE)
	private int normalPageSize;

	@Value(PropertyNames.MOBILE_PAGE_SIZE)
	private int mobilePageSize;

	@Value(PropertyNames.TABLET_PAGE_SIZE)
	private int tabletPageSize;

	public int getNormalPageSize() {
		return normalPageSize;
	}

	public void setNormalPageSize(int normalPageSize) {
		this.normalPageSize = normalPageSize;
	}

	public int getMobilePageSize() {
		return mobilePageSize;
	}

	public void setMobilePageSize(int mobilePageSize) {
		this.mobilePageSize = mobilePageSize;
	}

	public int getTabletPageSize() {
		return tabletPageSize;
	}

	public void setTabletPageSize(int tabletPageSize) {
		this.tabletPageSize = tabletPageSize;
	}

}
