package com.gloqr.configuration;

public class TemplateCommonUrls {

	private String websiteUrl;

	private String contentServerUrl;

	private String gloqrLogoPath;

	private String fbLogoPath;

	private String linkedinLogoPath;

	private String twitterLogoPath;

	private String instaLogoPath;

	private String ytLogoPath;

	public TemplateCommonUrls(String websiteUrl, String contentServerUrl, String gloqrLogoPath, String fbLogoPath,
			String linkedinLogoPath, String twitterLogoPath, String instaLogoPath, String ytLogoPath) {
		super();
		this.websiteUrl = websiteUrl;
		this.contentServerUrl = contentServerUrl;
		this.gloqrLogoPath = gloqrLogoPath;
		this.fbLogoPath = fbLogoPath;
		this.linkedinLogoPath = linkedinLogoPath;
		this.twitterLogoPath = twitterLogoPath;
		this.instaLogoPath = instaLogoPath;
		this.ytLogoPath = ytLogoPath;
	}

	public String getWebsiteUrl() {
		return websiteUrl;
	}

	public String getContentServerUrl() {
		return contentServerUrl;
	}

	public String getGloqrLogoPath() {
		return gloqrLogoPath;
	}

	public String getFbLogoPath() {
		return fbLogoPath;
	}

	public String getLinkedinLogoPath() {
		return linkedinLogoPath;
	}

	public String getTwitterLogoPath() {
		return twitterLogoPath;
	}

	public String getInstaLogoPath() {
		return instaLogoPath;
	}

	public String getYtLogoPath() {
		return ytLogoPath;
	}

}
