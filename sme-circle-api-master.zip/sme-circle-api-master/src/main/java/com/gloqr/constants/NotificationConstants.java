package com.gloqr.constants;

public class NotificationConstants {

	public static final String RECEIVED_INVITE_JOB_NAME_PREFIX = "CircleInvite_Received_";
	public static final String RECEIVED_INVITE_NOTIFI_TEMPLATE = "CircleInviteReceived";
	public static final String ACCEPTED_INVITE_NOTIFI_TEMPLATE = "CircleInviteAccepted";

	public enum JobSubGroup {
		CIRCLE_INVITE_RECEIVED
	}

	public enum JobGroup {
		CIRCLE_NOTIFICATION
	}

}
