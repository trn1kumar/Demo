package com.gloqr.constants;

public enum CirclePrivacy {
	CIRCLE, PUBLIC, PRIVATE
}
