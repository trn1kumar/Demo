package com.gloqr.constants;

public class Roles {

	private Roles() {
		throw new IllegalStateException("Constants class.could not initiate");
	}

	// Roles
	public static final String SME_ADMIN = "hasAnyRole('SME-ADMIN')";
	public static final String SME_ADMIN_AND_USER = "hasAnyRole('USER','SME-ADMIN')";
}
