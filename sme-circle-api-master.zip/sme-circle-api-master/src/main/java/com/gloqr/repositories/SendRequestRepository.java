package com.gloqr.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.gloqr.constants.CircleState;
import com.gloqr.entities.SendRequest;

public interface SendRequestRepository extends MongoRepository<SendRequest, Long> {

	public SendRequest findBySendReqUuidAndCircleState(String sendReqUuid, CircleState circleState);

}
