package com.gloqr.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mobile.device.Device;
import org.springframework.mobile.device.DeviceUtils;
import org.springframework.stereotype.Component;

import com.gloqr.configuration.PaginationSizeConfig;
import com.gloqr.security.context.holder.IContextHolder;

@Component
public class PaginationUtils implements IContextHolder {

	@Autowired
	private PaginationSizeConfig pageSizeConfig;

	public int getPageSize() {

		int pageSize = pageSizeConfig.getNormalPageSize();

		Device device = DeviceUtils.getCurrentDevice(this.getCurrentServletRequest());

		if (device.isMobile())
			pageSize = pageSizeConfig.getMobilePageSize();
		if (device.isTablet())
			pageSize = pageSizeConfig.getTabletPageSize();

		return pageSize;
	}
}
