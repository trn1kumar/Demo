package com.gloqr.rest.endpoint;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.client.Client;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.gloqr.dto.SMEDto;
import com.gloqr.dto.SMEFilterAndResultResponse;
import com.gloqr.exception.CustomException;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.security.configuration.JwtConstants;
import com.gloqr.security.context.holder.AuthenticationFacade;

public class SmeEndPoint {

	private static final Logger log = LogManager.getLogger();

	private Client client;
	private String endPointUri;
	private String listTopSme;
	private String listAllSME;
	private String specificSMEsPath;
	private String smeVoPath;
	private String suggestionsSmes;
	private String searchedSmes;

	@Autowired
	private AuthenticationFacade authenticationFacade;

	private static final String IDS = "smeIds";
	private static final String SME_ACTIVE = "activeStatus";

	public SmeEndPoint(Client client, String endPointUri, String listTopSme, String listAllSME, String smeVoPath,
			String specificSMEsPath, String suggestionsSmes, String searchedSmes) {
		this.client = client;
		this.endPointUri = endPointUri;
		this.listTopSme = listTopSme;
		this.listAllSME = listAllSME;
		this.smeVoPath = smeVoPath;
		this.specificSMEsPath = specificSMEsPath;
		this.suggestionsSmes = suggestionsSmes;
		this.searchedSmes = searchedSmes;
	}

	public List<SMEDto> getCircleSuggestions(Set<String> excludedSmeIds, int page, int size) {
		Response response = null;
		CustomHttpResponse<List<SMEDto>> customResponse = null;
		log.info("Getting Suggested SME details.");
		log.info("Connecting to SME Module....  {method=GET, uri: {}{} }", endPointUri, suggestionsSmes);

		try {
			Object[] excludedSmeIds1 = excludedSmeIds.stream().toArray(String[]::new);
			response = client.target(endPointUri).path(suggestionsSmes).queryParam("excludeSmeUuids", excludedSmeIds1)
					.queryParam("page", page).queryParam("size", size).request(MediaType.APPLICATION_JSON)
					.header(JwtConstants.HEADER_STRING, authenticationFacade.getJwtToken()).get();
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);
		Integer statusCode = response.getStatus();

		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}
		try {
			customResponse = response.readEntity(new GenericType<CustomHttpResponse<List<SMEDto>>>() {
			});
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}
		if (customResponse.isError()) {
			throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
		}

		return customResponse.getData();
	}

	public SMEFilterAndResultResponse getSearchedResults(String searchText, Set<String> categoriesFilterParam,
			Set<String> citiesFilterParam, int page) {
		Response response = null;
		CustomHttpResponse<SMEFilterAndResultResponse> customResponse = null;

		Object[] categoryParams = null;
		Object[] cityParams = null;

		if (categoriesFilterParam != null)
			categoryParams = categoriesFilterParam.stream().toArray(String[]::new);
		if (citiesFilterParam != null)
			cityParams = citiesFilterParam.stream().toArray(String[]::new);
		try {
			response = client.target(endPointUri).path(searchedSmes).queryParam("searchText", searchText)
					.queryParam("categoriesFilterParam", categoryParams).queryParam("citiesFilterParam", cityParams)
					.queryParam("page", page).request(MediaType.APPLICATION_JSON).get();
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);
		Integer statusCode = response.getStatus();

		if (statusCode == HttpStatus.OK.value()) {
			try {
				customResponse = response.readEntity(new GenericType<CustomHttpResponse<SMEFilterAndResultResponse>>() {
				});
			} catch (Exception e) {
				throwEntityResponseReadException(e);
			}
			if (customResponse.isError()) {
				throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
			}

		} else {
			throwInvalidResponseException(statusCode);
		}

		return customResponse.getData();
	}

	public List<SMEDto> getTopSME() {

		Response response = null;
		CustomHttpResponse<List<SMEDto>> customResponse = null;
		log.info("Getting TOP SME details.");
		log.info("Connecting to SME Module...  {method=GET, uri: {}{} }", endPointUri, listTopSme);

		try {
			response = client.target(endPointUri).path(listTopSme).request(MediaType.APPLICATION_JSON).get();
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);
		Integer statusCode = response.getStatus();

		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}
		try {
			customResponse = response.readEntity(new GenericType<CustomHttpResponse<List<SMEDto>>>() {
			});
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}
		if (customResponse.isError()) {
			throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
		}

		return customResponse.getData();
	}

	public SMEDto getSME(String smeId) {

		log.info("Getting SME details.  smeId:-{}", smeId);
		log.info("Connecting to SME Module...  {method=GET, uri: {}{} }", endPointUri,
				smeVoPath.replace("{smeId}", smeId));

		Response response = null;
		CustomHttpResponse<SMEDto> customResponse = null;

		try {
			response = client.target(endPointUri).path(smeVoPath.replace("{smeId}", smeId))
					.request(MediaType.APPLICATION_JSON).get();
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);

		Integer statusCode = response.getStatus();
		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}
		try {
			customResponse = response.readEntity(new GenericType<CustomHttpResponse<SMEDto>>() {
			});
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}
		if (customResponse.isError()) {
			throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
		}

		return customResponse.getData();

	}

	public Map<String, SMEDto> getSpecificSMEs(List<String> smeIds) {

		Response response = null;
		CustomHttpResponse<Map<String, SMEDto>> customResponse = null;
		String active = "true";

		log.info("Getting SMEs details...");
		log.info("Connecting to SME Module...  method=GET ,uri= {}{} ,params=[{}:{} , {}:{}]", endPointUri,
				specificSMEsPath, IDS, smeIds, SME_ACTIVE, active);

		try {
			Object[] smeIdParams = smeIds.stream().toArray(String[]::new);

			response = client.target(endPointUri).path(specificSMEsPath).queryParam(IDS, smeIdParams)
					.queryParam(SME_ACTIVE, active).request(MediaType.APPLICATION_JSON).get();
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);

		Integer statusCode = response.getStatus();
		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}
		try {
			customResponse = response.readEntity(new GenericType<CustomHttpResponse<Map<String, SMEDto>>>() {
			});
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}
		if (customResponse.isError()) {
			throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
		}

		return customResponse.getData();

	}

	public SMEFilterAndResultResponse getAllSME(Set<String> categoriesFilterParam, Set<String> citiesFilterParam,
			Integer page) {

		Response response = null;
		CustomHttpResponse<SMEFilterAndResultResponse> customResponse = null;

		Object[] categoryParams = null;
		Object[] cityParams = null;

		if (categoriesFilterParam != null)
			categoryParams = categoriesFilterParam.stream().toArray(String[]::new);
		if (citiesFilterParam != null)
			cityParams = citiesFilterParam.stream().toArray(String[]::new);
		try {
			response = client.target(endPointUri).path(listAllSME).queryParam("categoriesFilterParam", categoryParams)
					.queryParam("citiesFilterParam", cityParams).queryParam("page", page)
					.request(MediaType.APPLICATION_JSON).get();
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);
		Integer statusCode = response.getStatus();

		if (statusCode == HttpStatus.OK.value()) {
			try {
				customResponse = response.readEntity(new GenericType<CustomHttpResponse<SMEFilterAndResultResponse>>() {
				});
			} catch (Exception e) {
				throwEntityResponseReadException(e);
			}
			if (customResponse.isError()) {
				throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
			}

		} else {
			throwInvalidResponseException(statusCode);
		}

		return customResponse.getData();
	}

	private void throwEntityResponseReadException(Exception e) {
		throw new CustomException("Exception at read response from SME Module. Message: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private void throwInvalidResponseException(int statusCode) {
		throw new CustomException("Invalid Response from SME Module: ", HttpStatus.resolve(statusCode));
	}

	private void throwConnectionRefusedException(Exception e) {
		throw new CustomException("Couldn't Connect to SME module, Exception: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private void logResponse(Response response) {
		log.info("Response From SME Module : " + response);
	}

}
