package com.gloqr.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.component.validation.MultipartFileValidation;
import com.gloqr.constants.Roles;
import com.gloqr.constants.SMEMasterConstants;
import com.gloqr.constants.UrlMapping;
import com.gloqr.entities.Image;
import com.gloqr.exception.CustomException;
import com.gloqr.model.File;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.model.http.response.ResponseMessages;
import com.gloqr.rest.endpoint.ContentServerEndpoint;
import com.gloqr.rest.endpoint.PricingEndpoint;
import com.gloqr.security.context.holder.UserDetails;
import com.gloqr.service.FileService;
import com.gloqr.service.SMEService;

@RestController
@CrossOrigin(origins = "*")
@SuppressWarnings({ "unused", "rawtypes" })
@RequestMapping(UrlMapping.ROOT_API)
public class FileController {

	private static final Logger logger = LogManager.getLogger();

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private SMEService smeService;

	@Autowired
	private ContentServerEndpoint contentServerEndpoint;

	@Autowired
	private MultipartFileValidation multipartFileValidation;

	@Autowired
	private FileService fileService;

	@Autowired
	private PricingEndpoint pricingEndpoint;

	@PostMapping(UrlMapping.SAVE_IMAGES)
	@PreAuthorize(Roles.SME_ADMIN_AND_GLOQR_ADMIN)
	public ResponseEntity<?> uploadImages(Authentication authentication,
			@RequestParam(value = "images") MultipartFile[] files, @RequestParam String entityType,
			@RequestParam(required = false) String smeUuid) {

		List<Image> images = null;
		String fileLocation = null;

		UserDetails userDetails = (UserDetails) authentication.getPrincipal();

		if (smeUuid == null)
			smeUuid = userDetails.getSmeId();

		if (!(smeUuid != null && !smeUuid.equals("undefined")))
			throw new CustomException("value of 'smeUuid' param:- " + smeUuid + " is not valid",
					HttpStatus.BAD_REQUEST);

		String userId = userDetails.getUserId();

		logger.info("request for upload image by user:- {} and smeId:- {} and entityType:- {}", userId, smeUuid,
				entityType);

		List<MultipartFile> listFiles = Arrays.asList(files);

		switch (entityType) {

		case SMEMasterConstants.SLIDER_IMAGES:
			fileLocation = SMEMasterConstants.SME_HOME_SLIDER.replace("{sUuid}", smeUuid);
			break;

		case SMEMasterConstants.COMPANY_LOGO:
			multipartFileValidation.checkValidation(files, SMEMasterConstants.COMPANY_LOGO);
			images = fileService.sendFilesToContentServer(listFiles,
					SMEMasterConstants.SME.replace("{sUuid}", smeUuid));
			return responseMaker.successResponse(images.get(0).getImageLocation(), ResponseMessages.SUCCESS,
					HttpStatus.OK);

		case SMEMasterConstants.CERTIFICATES:
			multipartFileValidation.checkValidation(files, SMEMasterConstants.CERTIFICATES);
			fileLocation = SMEMasterConstants.SME_CERTIFICATE.replace("{sUuid}", smeUuid);
			break;
		case SMEMasterConstants.GALLERIES:
			multipartFileValidation.checkValidation(files, SMEMasterConstants.GALLERIES);
			fileLocation = SMEMasterConstants.SME_GALLERY.replace("{sUuid}", smeUuid);
			break;
		case SMEMasterConstants.INFRASTRUCTURES:
			multipartFileValidation.checkValidation(files, SMEMasterConstants.INFRASTRUCTURES);
			fileLocation = SMEMasterConstants.SME_INFRASTRUCTURE.replace("{sUuid}", smeUuid);
			break;
		case SMEMasterConstants.TEAMS:
			multipartFileValidation.checkValidation(files, SMEMasterConstants.TEAMS);
			fileLocation = SMEMasterConstants.SME_MANAGEMENT_TEAM.replace("{sUuid}", smeUuid);
			break;
		default:
			throw new CustomException("Invalid choice selection. Exception in uploadImages() { }. ",
					HttpStatus.BAD_REQUEST);
		}

		if (fileLocation != null)
			images = fileService.saveAndSendFilesToContentServer(listFiles, fileLocation);

		return responseMaker.successResponse(images, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@PostMapping(UrlMapping.CHANGE_LOGO_IMAGE)
	@PreAuthorize(Roles.SME_ADMIN_AND_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse> changeLogoImage(Authentication authentication,
			@FormDataParam(value = "logoImage") MultipartFile logoImage,
			@RequestParam(required = false) String smeUuid) {

		List<Image> images = null;
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();

		if (userDetails.getSmeId() != null)
			smeUuid = userDetails.getSmeId();
		else if (smeUuid == null)
			throw new CustomException("Required String Parameter 'smeUuid' not present",
					HttpStatus.INTERNAL_SERVER_ERROR);

		String userId = userDetails.getUserId();
		logger.info("request for change logo image by user:- {} and smeId:- {}", userId, smeUuid);
		try {
			MultipartFile[] imgs = { logoImage };
			multipartFileValidation.checkValidation(imgs, SMEMasterConstants.COMPANY_LOGO);
			images = fileService.sendFilesToContentServer(Arrays.asList(logoImage),
					SMEMasterConstants.SME.replace("{sUuid}", smeUuid));

			String existImageLocation = smeService.changeLogoImage(smeUuid, images.get(0).getImageLocation());

			if (!StringUtils.isEmpty(existImageLocation)) {
				fileService.deleteFileFromContentServer(existImageLocation);
			}

		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@PostMapping(UrlMapping.UPLOAD_HOME_SLIDER_IMAGE)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> updateHomeSliderImage(Authentication authentication,
			@RequestBody List<Image> images) {
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeId = userDetails.getSmeId();
		String userId = userDetails.getUserId();
		logger.info("request for upload slider images by user:- {} and smeId:- {}", userId, smeId);

		smeService.saveOrUpdateSliderImages(userDetails.getSmeId(), images);

		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@PutMapping(UrlMapping.UPDATE_BUSINESS_POST_IMAGE)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> updateImagesByBusinessPostFalse(@RequestBody List<File> files) {
		Set<String> imageLocations = files.stream().map(File::getFileLocation).collect(Collectors.toSet());
		fileService.updateImagesByBusinessPostFalse(imageLocations);
		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.OK);
	}

}
