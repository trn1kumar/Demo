package com.gloqr.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.Roles;
import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.count.EditModeItemsCount;
import com.gloqr.dto.count.ViewModeItemsCount;
import com.gloqr.entities.SMEItemsCount;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.SMEMapper;
import com.gloqr.model.ItemsCountUpdate;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.model.http.response.ResponseMessages;
import com.gloqr.security.context.holder.UserDetails;
import com.gloqr.service.CountManageService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.ROOT_API)
@SuppressWarnings("rawtypes")
public class CountManageController {

	private static final Logger logger = LogManager.getLogger();

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private CountManageService countManageService;

	@Autowired
	private SMEMapper mapper;

	@GetMapping(UrlMapping.SME_ITEMS_COUNT)
	public ResponseEntity<CustomHttpResponse<Object>> getSmeItemsCount(Authentication authentication,
			@RequestParam(required = false) String smeUuid,
			@RequestParam(value = "editMode", required = false) boolean editMode) {

		EditModeItemsCount editModeCounts = null;
		ViewModeItemsCount viewModeCounts = null;

		if (editMode) {
			if (authentication != null) {
				UserDetails userDetails = (UserDetails) authentication.getPrincipal();
				String smeId = userDetails.getSmeId();
				SMEItemsCount counts = countManageService.getItemsCount(smeId);
				editModeCounts = mapper.convertToDto(counts, EditModeItemsCount.class);
				return responseMaker.successResponse(editModeCounts, ResponseMessages.SUCCESS, HttpStatus.OK);
			} else {
				throw new CustomException("Access Denied.", HttpStatus.FORBIDDEN);
			}
		} else {
			if (smeUuid != null) {
				SMEItemsCount counts = countManageService.getItemsCount(smeUuid);
				viewModeCounts = mapper.convertToDto(counts, ViewModeItemsCount.class);
				return responseMaker.successResponse(viewModeCounts, ResponseMessages.SUCCESS, HttpStatus.OK);
			} else {
				throw new CustomException("Required String parameter 'smeUuid' is not present", HttpStatus.BAD_REQUEST);
			}

		}

	}

	@PutMapping(UrlMapping.SME_ITEMS_COUNT)
	@PreAuthorize(Roles.SME_ADMIN_AND_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse> updateSmeItemsCount(@RequestParam(required = false) String userUuid,
			@RequestParam(required = false) String smeUuid, @RequestBody ItemsCountUpdate itemsCountUpdate) {
		logger.info("request for update items count by sme:- {}", smeUuid);
		try {
			if (userUuid == null && smeUuid == null)
				throw new CustomException(
						"Both 'userId' and 'smeUuid' can not be null. Required eighter 'userId' or 'smeUuid'.",
						HttpStatus.BAD_REQUEST);

			countManageService.updateItemsCount(userUuid, smeUuid, itemsCountUpdate);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@PutMapping(UrlMapping.SME_ITEMS1_COUNT)
	public ResponseEntity<CustomHttpResponse> updateBiCount(@RequestBody List<ItemsCountUpdate> itemCounts,
			@RequestParam String key) {

		try {

			if (!key.equals("InJvbGUiOiJST0xFX1N"))
				throw new CustomException("Provided Secure Key is Invalid.", HttpStatus.FORBIDDEN);

			for (ItemsCountUpdate countUpdate : itemCounts) {
				if (countUpdate.getSmeUuid() == null)
					throw new CustomException("'smeUuid' can not be null.", HttpStatus.BAD_REQUEST);
				countManageService.updateItemsCount(null, countUpdate.getSmeUuid(), countUpdate);
			}

		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.OK);

	}
}
