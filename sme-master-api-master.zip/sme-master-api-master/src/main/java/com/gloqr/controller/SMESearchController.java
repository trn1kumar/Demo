package com.gloqr.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.FilterResponse;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.model.http.response.ResponseMessages;
import com.gloqr.service.SMESearchService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.ROOT_API)
public class SMESearchController {

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private SMESearchService smeSearchService;

	@GetMapping(UrlMapping.SEARCH_SUGGEST)
	public ResponseEntity<CustomHttpResponse<List<String>>> getAutoSuggestedResults(
			@RequestParam(value = "searchText") String searchText,
			@RequestParam(value = "maxResult", defaultValue = "10") int maxResult) {
		List<String> searchedSmes = smeSearchService.getSearchSuggestions(searchText, maxResult);
		return responseMaker.successResponse(searchedSmes, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.SEARCH_RESULT)
	public ResponseEntity<CustomHttpResponse<FilterResponse>> getSearchedResults(
			@RequestParam(value = "searchText") String searchText,
			@RequestParam(required = false) Set<String> categoriesFilterParam,
			@RequestParam(required = false) Set<String> citiesFilterParam,
			@RequestParam(value = "page", defaultValue = "1") int page) {

		FilterResponse searchedSmesResponse = smeSearchService.getSearchResults(searchText, categoriesFilterParam,
				citiesFilterParam, page);

		return responseMaker.successResponse(searchedSmesResponse, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

}
