package com.gloqr.controller;

import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.ItemType;
import com.gloqr.constants.Roles;
import com.gloqr.constants.UrlMapping;
import com.gloqr.model.SMEItemUpdate;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.model.http.response.ResponseMessages;
import com.gloqr.security.context.holder.UserDetails;
import com.gloqr.service.CountManageService;
import com.gloqr.service.ItemsPublishService;

@RestController
@CrossOrigin("*")
@SuppressWarnings("rawtypes")
@RequestMapping(UrlMapping.ROOT_API)
public class ItemsPublishController {

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private ItemsPublishService publishService;

	@Autowired
	private CountManageService countManageService;

	private Logger logger = LogManager.getLogger();

	@PutMapping(UrlMapping.MODIFY_ITEMS_STATUS)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> activeOrDeactiveSMEEntities(Authentication authentication,
			@RequestBody Set<SMEItemUpdate> smeItemsUpdate, @RequestParam ItemType itemType) {

		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeId = userDetails.getSmeId();
		String userId = userDetails.getUserId();
		logger.info("request for change status for itemType {},  with user:-{} and smeId:-{}", itemType, userId, smeId);

		switch (itemType) {
		case CERTIFICATE:
			publishService.updateCerificatesStatus(smeItemsUpdate, smeId);
			countManageService.updateItemsCount(smeId, ItemType.CERTIFICATE);
			break;

		case INFRASTRUCTURE:
			publishService.updateInfrasStatus(smeItemsUpdate, smeId);
			countManageService.updateItemsCount(smeId, ItemType.INFRASTRUCTURE);
			break;

		case GALLERY:
			publishService.updateGalleriesStatus(smeItemsUpdate, smeId);
			countManageService.updateItemsCount(smeId, ItemType.GALLERY);
			break;

		case TEAM:
			publishService.updateManagementTeamsStatus(smeItemsUpdate, smeId);
			countManageService.updateItemsCount(smeId, ItemType.TEAM);
			break;
		default:
			break;
		}
		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.OK);
	}

}
