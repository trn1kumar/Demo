package com.gloqr.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.Roles;
import com.gloqr.constants.UrlMapping;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.security.context.holder.UserDetails;
import com.gloqr.service.CircleService;
import com.gloqr.vo.SMEInformationVo;

@RestController
@RequestMapping(UrlMapping.ROOT_API)
public class CircleController {

	private static final Logger logger = LogManager.getLogger();

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private CircleService circleService;

	@GetMapping(UrlMapping.CIRCLE_SUGGESTIONS)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse<List<SMEInformationVo>>> getCircleSuggestions(
			Authentication authentication, @RequestParam(required = false) Set<String> excludeSmeUuids,
			@RequestParam Integer page, @RequestParam Integer size) {
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeUuid = userDetails.getSmeId();

		logger.info("Request for get Circle Suggestions by smeUuid:: {}", smeUuid);
		List<SMEInformationVo> suggestionVos = null;
		try {
			excludeSmeUuids = excludeSmeUuids == null ? new HashSet<>() : excludeSmeUuids;
			suggestionVos = circleService.getCircleSuggestions(smeUuid, excludeSmeUuids, page, size);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(suggestionVos, "Fetched New Suggestions.", HttpStatus.OK);
	}
}
