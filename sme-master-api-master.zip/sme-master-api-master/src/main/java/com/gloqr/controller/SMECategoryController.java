package com.gloqr.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.UrlMapping;
import com.gloqr.entities.SMECategory;
import com.gloqr.mapper.SMEMapper;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.model.http.response.ResponseMessages;
import com.gloqr.service.SMECategoryService;
import com.gloqr.vo.SMECategoryVo;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.ROOT_API)
public class SMECategoryController {

	@Autowired
	private SMEMapper mapper;

	@Autowired
	private SMECategoryService smeCategoryService;

	@Autowired
	private ResponseMaker responseMaker;

	@GetMapping(UrlMapping.CATEGORIES)
	public ResponseEntity<CustomHttpResponse<List<SMECategoryVo>>> getCategories() {
		List<SMECategory> categories = null;
		List<SMECategoryVo> categoriesDto = new ArrayList<>();
		try {
			categories = smeCategoryService.getAllCategories();
			categories.forEach(category -> {
				final int smeCount = category.getSmes().size();
				SMECategoryVo categoryDto = mapper.convertToDto(category, SMECategoryVo.class);
				categoryDto.setTotalSmesCount(smeCount);
				categoriesDto.add(categoryDto);
			});
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(categoriesDto, ResponseMessages.SUCCESS, HttpStatus.OK);
	}
}
