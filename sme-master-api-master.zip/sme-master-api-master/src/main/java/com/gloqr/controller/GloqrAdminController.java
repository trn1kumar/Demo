package com.gloqr.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.ItemType;
import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.CertificateDto;
import com.gloqr.dto.GLoqrSMEDto;
import com.gloqr.dto.GalleryDto;
import com.gloqr.dto.InfrastructureDto;
import com.gloqr.dto.ManagementTeamDto;
import com.gloqr.entities.SMEInformation;
import com.gloqr.mapper.SMEMapper;
import com.gloqr.model.SMEItemUpdate;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.model.http.response.ResponseMessages;
import com.gloqr.repository.SMEInformationRepository;
import com.gloqr.rest.endpoint.ContentServerEndpoint;
import com.gloqr.service.CountManageService;
import com.gloqr.service.GloqrAdminService;
import com.gloqr.vo.GloqrAdmin;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.GLOQR_ADMIN_API)
@SuppressWarnings("rawtypes")
public class GloqrAdminController {

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private GloqrAdminService gloqrAdminService;

	@Autowired
	private ContentServerEndpoint contentServerEndpoint;

	@Autowired
	private SMEMapper mapper;

	private static final Logger logger = LogManager.getLogger();

	@GetMapping(UrlMapping.SMES)
	public ResponseEntity<CustomHttpResponse<GloqrAdmin>> getSMEs(@RequestParam(required = false) Integer page,
			@RequestParam boolean verified) {
		logger.info("request for get smes, verified:: {}.", verified);
		GloqrAdmin smesData = null;
		try {
			if (page == null || page < 0)
				page = 0;
			smesData = gloqrAdminService.getSMEs(page, verified);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(smesData, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@PutMapping(UrlMapping.VERIFY_SME)
	public ResponseEntity<CustomHttpResponse> verifySME(@RequestBody GLoqrSMEDto smeDto) {
		logger.info("request for active sme {}", smeDto.getsUuid());
		try {
			gloqrAdminService.changeVerifyStatus(smeDto.getsUuid(), smeDto.getSmeCategory());

		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@PutMapping(UrlMapping.MODIFY_ITEM_STATE)
	public ResponseEntity<CustomHttpResponse> modifySMEItemsState(@RequestBody List<SMEItemUpdate> smeItemUpdates,
			@RequestParam ItemType itemType) {
		try {
			gloqrAdminService.modifySMEItemsState(smeItemUpdates, itemType);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@PutMapping(UrlMapping.UPDATE_IMAGES)
	public ResponseEntity<CustomHttpResponse> updateImages(@RequestParam String itemType,
			@RequestBody SMEItemUpdate itemUpdate) {
		try {
			List<String> deleteImgLocations = gloqrAdminService.updateImages(itemType, itemUpdate);
			if (deleteImgLocations != null && !deleteImgLocations.isEmpty())
				contentServerEndpoint.deleteFilesFromContentServer(deleteImgLocations);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.GET_SME_ITEMS)
	public ResponseEntity<CustomHttpResponse<List<Object>>> getSMEItems(@RequestParam String smeUuid,
			@RequestParam ItemType itemType) {
		logger.info("request for get data by smeId {} and itemType {}", smeUuid, itemType);

		List<Object> entities = new ArrayList<>();

		try {
			switch (itemType) {
			case CERTIFICATE:
				gloqrAdminService.getStatePendingAndActiveTrueCertificates(smeUuid)
						.forEach(certificate -> entities.add(mapper.convertToDto(certificate, CertificateDto.class)));
				break;

			case INFRASTRUCTURE:
				gloqrAdminService.getStatePendingAndActiveTrueInfrastructures(smeUuid)
						.forEach(infra -> entities.add(mapper.convertToDto(infra, InfrastructureDto.class)));
				break;

			case TEAM:
				gloqrAdminService.getStatePendingAndActiveTrueManagementTeams(smeUuid).forEach(team -> {
					ManagementTeamDto teamDto = mapper.convertToDto(team, ManagementTeamDto.class);
					if (team.getProfileImage() != null)
						teamDto.setProfileImageUrl(team.getProfileImage().getImageLocation());
					entities.add(teamDto);
				});
				break;

			case GALLERY:
				gloqrAdminService.getStatePendingAndActiveTrueGalleries(smeUuid)
						.forEach(gallery -> entities.add(mapper.convertToDto(gallery, GalleryDto.class)));
				break;

			default:
				break;
			}

		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(entities, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.SME)
	public ResponseEntity<CustomHttpResponse<GLoqrSMEDto>> getSME(@PathVariable String smeUuid) {

		logger.info("request get sme {} detail", smeUuid);
		GLoqrSMEDto smeDto = null;
		try {

			SMEInformation sme = gloqrAdminService.getSME(smeUuid);
			smeDto = mapper.convertToDto(sme, GLoqrSMEDto.class);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(smeDto, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	// Update Manually Count If Some Count Manage Miss-Behavior Happen

	@Autowired
	private CountManageService countManageService;

	@Autowired
	private SMEInformationRepository repository;

	@PutMapping("/update-items-count")
	public void manageItemsCount() {
		logger.info("Updating SME Items Count...");
		List<String> smeIds = repository.getSMEIDs();
		for (String smeId : smeIds) {
			countManageService.updateItemsCount(smeId, ItemType.CERTIFICATE);
			countManageService.updateItemsCount(smeId, ItemType.GALLERY);
			countManageService.updateItemsCount(smeId, ItemType.TEAM);
			countManageService.updateItemsCount(smeId, ItemType.INFRASTRUCTURE);
		}
	}

}
