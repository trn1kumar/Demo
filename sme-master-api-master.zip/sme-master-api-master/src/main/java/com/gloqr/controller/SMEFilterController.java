package com.gloqr.controller;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.FilterDto;
import com.gloqr.dto.FilterResponse;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.model.http.response.ResponseMessages;
import com.gloqr.service.filter.MainFilterService;

@RestController
@RequestMapping(UrlMapping.ROOT_API)
@CrossOrigin("*")
public class SMEFilterController {

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private MainFilterService mainFilterService;

	@GetMapping(UrlMapping.GET_SMES)
	public ResponseEntity<CustomHttpResponse<FilterResponse>> getSmesWithFilter(
			@RequestParam(required = false) Set<String> categoriesFilterParam,
			@RequestParam(required = false) Set<String> citiesFilterParam,
			@RequestParam(required = false) Integer page) {

		FilterResponse filterAndResult = null;

		try {
			if (page == null || page < 0)
				page = 0;

			filterAndResult = mainFilterService.applyFilter(null, categoriesFilterParam, citiesFilterParam, page);

		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(filterAndResult, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.MENU_BAR_FILTER)
	public ResponseEntity<CustomHttpResponse<FilterDto>> getMenuBarFilter() {
		FilterDto filter = mainFilterService.getInitialFilter();
		return responseMaker.successResponse(filter, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

}
