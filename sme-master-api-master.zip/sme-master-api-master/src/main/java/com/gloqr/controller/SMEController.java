
package com.gloqr.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.ItemType;
import com.gloqr.constants.Roles;
import com.gloqr.constants.SMEMasterConstants;
import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.AddressDto;
import com.gloqr.dto.CertificateDto;
import com.gloqr.dto.GalleryDto;
import com.gloqr.dto.InfrastructureDto;
import com.gloqr.dto.ManagementTeamDto;
import com.gloqr.dto.SMECategoryDto;
import com.gloqr.dto.SMEDetailDto;
import com.gloqr.dto.SMEInformationDto;
import com.gloqr.dto.count.EditModeItemsPercentage;
import com.gloqr.entities.Address;
import com.gloqr.entities.Certificate;
import com.gloqr.entities.Gallery;
import com.gloqr.entities.Infrastructure;
import com.gloqr.entities.ManagementTeam;
import com.gloqr.entities.SMECategory;
import com.gloqr.entities.SMEInformation;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.SMEMapper;
import com.gloqr.model.AuthToken;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.model.http.response.ResponseMessages;
import com.gloqr.security.context.holder.UserDetails;
import com.gloqr.service.CountManageService;
import com.gloqr.service.NotificationService;
import com.gloqr.service.SMEService;
import com.gloqr.vo.SMEInformationVo;
import com.gloqr.vo.SmeSubEntitiesCount;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.ROOT_API)
@SuppressWarnings("rawtypes")
public class SMEController {

	private static final Logger logger = LogManager.getLogger();

	@Autowired
	private SMEService smeService;

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private SMEMapper mapper;

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private CountManageService countManageService;

	@PostMapping(UrlMapping.SAVE_SME)
	@PreAuthorize(Roles.USER)
	public ResponseEntity<CustomHttpResponse<AuthToken>> saveFirstStepSmeDetails(Authentication authentication,
			@Valid @RequestBody SMECategoryDto categoryDto) {

		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String userId = userDetails.getUserId();
		logger.info("request for first step sme reg. by user:- {}", userId);
		AuthToken refreshSMEToken = null;

		try {
			SMEInformationDto sme = categoryDto.getSmes().get(0);
			if (sme.getSmeAddress() == null)
				throw new CustomException("sme address obj can't be null", HttpStatus.BAD_REQUEST);
			sme.setUuid(userId);
			SMECategory smeCategory = mapper.convertToEntity(categoryDto, SMECategory.class);
			refreshSMEToken = smeService.saveSme(smeCategory);
			sme.setsUuid(refreshSMEToken.getsUuid());
			logger.info("sme created for user:-{} and smeId is {}", userId, refreshSMEToken.getsUuid());
			notificationService.sendWelcomeNotification(sme);
		} catch (Exception e) {

			logger.error("sme first step reg.process failed.exception {}.", e.getMessage());
			throw e;
		}

		return responseMaker.successResponse(refreshSMEToken, "sme first step registration details saved sucessfully.",
				HttpStatus.CREATED);

	}

	@PatchMapping(UrlMapping.SAVE_SME)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> saveSecondStepSmeDetails(Authentication authentication,
			@Valid @RequestBody SMEDetailDto smeDetailDto) {
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeId = userDetails.getSmeId();
		String userId = userDetails.getUserId();
		try {
			logger.info("request for second step sme reg. by user:-{} and smeId:-{}", userId, smeId);
			SMEInformation sme = mapper.convertToEntity(smeDetailDto, SMEInformation.class);
			sme.setsUuid(smeId);
			smeService.saveSMEDetails(sme);

		} catch (Exception e) {
			logger.error("sme second step reg.process failed.exception {}.", e.getMessage());
			throw e;
		}

		return responseMaker.successResponse("sme second step registration details saved sucessfully.", HttpStatus.OK);
	}

	@PutMapping(UrlMapping.SAVE_SME)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> updateSme(Authentication authentication,
			@Valid @RequestBody SMEInformationDto smeDto) {

		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeId = userDetails.getSmeId();
		String userId = userDetails.getUserId();
		logger.info("request for update sme details by user:-{} and smeId:-{}", userId, smeId);

		try {
			smeDto.setsUuid(smeId);
			smeService.updateSme(mapper.convertToDto(smeDto, SMEInformation.class));
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse("SME Details Updated Successfully", HttpStatus.OK);

	}

	@PutMapping(UrlMapping.MODIFY_ADDRESS)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> updateAddress(Authentication authentication,
			@Valid @RequestBody AddressDto addressDto) {
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeId = userDetails.getSmeId();
		String userId = userDetails.getUserId();
		logger.info("request for update sme address by user:-{} and smeId:-{}", userId, smeId);

		try {
			Address address = mapper.convertToEntity(addressDto, Address.class);
			smeService.updateSmeAddress(smeId, address);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@PostMapping(UrlMapping.SAVE_INFRASTRUCTURE)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> saveInfrastructure(Authentication authentication,
			@Valid @RequestBody InfrastructureDto infrastructureDto) {
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeId = userDetails.getSmeId();
		String userId = userDetails.getUserId();
		logger.info("request for add new infrastructure by user:-{} and smeId:-{}", userId, smeId);
		try {
			Infrastructure infrastructure = mapper.convertToEntity(infrastructureDto, Infrastructure.class);
			smeService.saveInfrastructure(infrastructure, smeId);
			countManageService.updateItemsCount(smeId, ItemType.INFRASTRUCTURE);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.CREATED);

	}

	@PostMapping(UrlMapping.SAVE_TEAM)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> saveManagementTeams(Authentication authentication,
			@Valid @RequestBody ManagementTeamDto managementTeamDto) {
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeId = userDetails.getSmeId();
		String userId = userDetails.getUserId();
		logger.info("request for add new management team by user:-{} and smeId:-{}", userId, smeId);
		List<ManagementTeam> teams = null;
		try {
			ManagementTeam team = mapper.convertToEntity(managementTeamDto, ManagementTeam.class);
			teams = new ArrayList<>();
			teams.add(team);
			smeService.saveManagementTeams(teams, smeId);
			countManageService.updateItemsCount(smeId, ItemType.TEAM);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.CREATED);

	}

	@PostMapping(UrlMapping.SAVE_CERTIFICATE)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> saveCertificate(Authentication authentication,
			@Valid @RequestBody CertificateDto certificateDto) {
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeId = userDetails.getSmeId();
		String userId = userDetails.getUserId();
		logger.info("request for add new certificate by user:-{} and smeId:-{}", userId, smeId);
		List<Certificate> certificates = new ArrayList<>();

		try {
			Certificate certificate = mapper.convertToEntity(certificateDto, Certificate.class);
			certificates.add(certificate);
			smeService.saveCertificates(certificates, smeId);
			countManageService.updateItemsCount(smeId, ItemType.CERTIFICATE);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.CREATED);

	}

	@PostMapping(UrlMapping.SAVE_GALLERY)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> saveGallery(Authentication authentication,
			@Valid @RequestBody GalleryDto galleryDto) {

		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeId = userDetails.getSmeId();
		String userId = userDetails.getUserId();
		logger.info("request for add new gallery by user:-{} and smeId:-{}", userId, smeId);

		List<Gallery> galleryList = new ArrayList<>();
		try {

			Gallery gallery = mapper.convertToEntity(galleryDto, Gallery.class);
			galleryList.add(gallery);
			smeService.saveGalleries(galleryList, smeId);
			countManageService.updateItemsCount(smeId, ItemType.GALLERY);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.CREATED);

	}

	@PutMapping(UrlMapping.UPDATE_INFRASTRUCTURE)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> updateInfrastructure(Authentication authentication,
			@Valid @RequestBody InfrastructureDto infrastructureDto) {
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeId = userDetails.getSmeId();
		String userId = userDetails.getUserId();
		logger.info("request for update infrastructure by user:-{} and smeId:-{}", userId, smeId);
		try {
			Infrastructure infrastructure = mapper.convertToEntity(infrastructureDto, Infrastructure.class);
			smeService.updateInfrastructure(infrastructure, smeId);
			countManageService.updateItemsCount(smeId, ItemType.INFRASTRUCTURE);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.CREATED);

	}

	@PutMapping(UrlMapping.UPDATE_TEAM)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> updateManagementTeam(Authentication authentication,
			@Valid @RequestBody ManagementTeamDto managementTeamDto) {
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeId = userDetails.getSmeId();
		String userId = userDetails.getUserId();
		logger.info("request for update management team by user:-{} and smeId:-{}", userId, smeId);
		try {
			ManagementTeam team = mapper.convertToEntity(managementTeamDto, ManagementTeam.class);
			smeService.updateManagementTeam(team, smeId);
			countManageService.updateItemsCount(smeId, ItemType.TEAM);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.CREATED);

	}

	@PutMapping(UrlMapping.UPDATE_CERTIFICATE)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> updateCertificate(Authentication authentication,
			@Valid @RequestBody CertificateDto certificateDto) {
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeId = userDetails.getSmeId();
		String userId = userDetails.getUserId();
		logger.info("request for update certificate by user:-{} and smeId:-{}", userId, smeId);

		try {
			Certificate certificate = mapper.convertToEntity(certificateDto, Certificate.class);
			smeService.updateCertificate(certificate, smeId);
			countManageService.updateItemsCount(smeId, ItemType.CERTIFICATE);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@PutMapping(UrlMapping.UPDATE_GALLERY)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> updateGallery(Authentication authentication,
			@Valid @RequestBody GalleryDto galleryDto) {

		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeId = userDetails.getSmeId();
		String userId = userDetails.getUserId();
		logger.info("request for update gallery by user:-{} and smeId:-{}", userId, smeId);

		try {

			Gallery gallery = mapper.convertToEntity(galleryDto, Gallery.class);
			smeService.updateGallery(gallery, smeId);
			countManageService.updateItemsCount(smeId, ItemType.GALLERY);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.CREATED);

	}

	@GetMapping(UrlMapping.GET_INFRASTRUCTURES)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse<List<InfrastructureDto>>> getInfrastructures(Authentication authentication,
			@RequestParam(required = false) String status) {

		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeId = userDetails.getSmeId();
		String userId = userDetails.getUserId();
		logger.info("request for get infrastructures by user:-{} and smeId:-{} and status:-{}", userId, smeId, status);
		List<Infrastructure> infrastructures = null;
		List<InfrastructureDto> infrastructuresDto = null;
		try {
			infrastructures = smeService.getAllInfrastructure(smeId, status);
			infrastructuresDto = mapper.convertToDtos(infrastructures, InfrastructureDto.class);

		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(infrastructuresDto, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.GET_TEAMS)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse<List<ManagementTeamDto>>> getTeams(Authentication authentication,
			@RequestParam(required = false) String status) {

		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeId = userDetails.getSmeId();
		String userId = userDetails.getUserId();
		logger.info("request for get management teams by user:-{} and smeId:-{} and status:-{}", userId, smeId, status);

		List<ManagementTeam> teams = null;
		List<ManagementTeamDto> teamsDto = new ArrayList<>();
		try {
			teams = smeService.getAllManagementTeam(smeId, status);

			teams.forEach(team -> {
				ManagementTeamDto teamDto = mapper.convertToDto(team, ManagementTeamDto.class);
				if (team.getProfileImage() != null)
					teamDto.setProfileImageUrl(team.getProfileImage().getImageLocation());
				teamsDto.add(teamDto);

			});
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(teamsDto, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.GET_CERTIFICATES)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse<List<CertificateDto>>> getCertificates(Authentication authentication,
			@RequestParam(required = false) String status) {
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeId = userDetails.getSmeId();
		String userId = userDetails.getUserId();
		logger.info("request for get certificates by user:-{} and smeId:-{} and status:-{}", userId, smeId, status);

		List<Certificate> certificates = null;
		List<CertificateDto> certificatesDto = null;

		try {
			certificates = smeService.getAllCertificate(smeId, status);
			certificatesDto = mapper.convertToDtos(certificates, CertificateDto.class);

		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(certificatesDto, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.GET_GALLERIES)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse<List<GalleryDto>>> getGalleries(Authentication authentication,
			@RequestParam(required = false) String status) {

		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeId = userDetails.getSmeId();
		String userId = userDetails.getUserId();
		logger.info("request for get galleries by user:-{} and smeId:-{} and status:-{}", userId, smeId, status);

		List<Gallery> galleries = null;
		List<GalleryDto> galleriesDto = null;
		try {
			galleries = smeService.getAllGalleries(smeId, status);
			galleriesDto = mapper.convertToDtos(galleries, GalleryDto.class);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(galleriesDto, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.GET_APPROVED_INFRASTRUCTURES)
	public ResponseEntity<CustomHttpResponse<List<InfrastructureDto>>> getApprovedInfrastructures(
			@PathVariable String smeUuid) {
		logger.info("request for get approved infrastructures of sme:-{}", smeUuid);

		List<Infrastructure> infrastructures = null;
		List<InfrastructureDto> infrastructuresDto = null;
		try {
			infrastructures = smeService.getActiveAndApprovedInfras(smeUuid);
			infrastructuresDto = mapper.convertToDtos(infrastructures, InfrastructureDto.class);

		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(infrastructuresDto, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.GET_APPROVED_CERTIFICATES)
	public ResponseEntity<CustomHttpResponse<List<CertificateDto>>> getApprovedCertificates(
			@PathVariable String smeUuid) {

		logger.info("request for get approved certificates of sme:-{}", smeUuid);
		List<Certificate> certificates = null;
		List<CertificateDto> certificatesDto = null;

		try {
			certificates = smeService.getActiveAndApprovedCertificates(smeUuid);
			certificatesDto = mapper.convertToDtos(certificates, CertificateDto.class);

		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(certificatesDto, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.GET_APPROVED_TEAMS)
	public ResponseEntity<CustomHttpResponse<List<ManagementTeamDto>>> getApprovedTeams(@PathVariable String smeUuid) {
		logger.info("request for get approved management teams of sme:-{}", smeUuid);
		List<ManagementTeam> teams = null;
		List<ManagementTeamDto> teamsDto = new ArrayList<>();
		try {
			teams = smeService.getActiveAndApprovedManagementTeams(smeUuid);
			teams.forEach(team -> {
				ManagementTeamDto teamDto = mapper.convertToDto(team, ManagementTeamDto.class);
				if (team.getProfileImage() != null)
					teamDto.setProfileImageUrl(team.getProfileImage().getImageLocation());
				teamsDto.add(teamDto);

			});
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(teamsDto, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.GET_APPROVED_GALLERIES)
	public ResponseEntity<CustomHttpResponse<List<GalleryDto>>> getApprovedGalleries(@PathVariable String smeUuid) {
		logger.info("request for get approved galleries of sme:-{}", smeUuid);
		List<Gallery> galleries = null;
		List<GalleryDto> galleriesDto = new ArrayList<>();
		try {
			galleries = smeService.getActiveAndApprovedGalleries(smeUuid);
			galleriesDto = mapper.convertToDtos(galleries, GalleryDto.class);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(galleriesDto, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.GET_INFRASTRUCTURE)
	public ResponseEntity<CustomHttpResponse<InfrastructureDto>> getInfrastructure(@PathVariable String infraUuid) {
		logger.info("request for get infrastructure by id:-{}", infraUuid);

		Infrastructure infrastructure = null;
		InfrastructureDto infrastructureDto = null;
		try {
			infrastructure = smeService.getInfrastructure(infraUuid);
			infrastructureDto = mapper.convertToDto(infrastructure, InfrastructureDto.class);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(infrastructureDto, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.GET_CERTIFICATE)
	public ResponseEntity<CustomHttpResponse<CertificateDto>> getCertificate(@PathVariable String crtiUuid) {
		logger.info("request for get certificate by id:-{}", crtiUuid);

		Certificate certificate = null;
		CertificateDto certificateDto = null;
		try {
			certificate = smeService.getCertificate(crtiUuid);
			certificateDto = mapper.convertToDto(certificate, CertificateDto.class);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(certificateDto, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.GET_TEAM)
	public ResponseEntity<CustomHttpResponse<ManagementTeamDto>> getManagementTeam(@PathVariable String teamUuid) {
		logger.info("request for get Management team by id:-{}", teamUuid);

		ManagementTeam team = null;
		ManagementTeamDto teamDto = null;
		try {
			team = smeService.getManagementTeam(teamUuid);
			teamDto = mapper.convertToDto(team, ManagementTeamDto.class);
			if (team.getProfileImage() != null)
				teamDto.setProfileImageUrl(team.getProfileImage().getImageLocation());
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(teamDto, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.GET_GALLERY)
	public ResponseEntity<CustomHttpResponse<GalleryDto>> getGallery(@PathVariable String galleryUuid) {
		logger.info("request for get gallery by id:-{}", galleryUuid);

		Gallery gallery = null;
		GalleryDto galleryDto = null;
		try {
			gallery = smeService.getGallery(galleryUuid);
			galleryDto = mapper.convertToDto(gallery, GalleryDto.class);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(galleryDto, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@DeleteMapping(UrlMapping.DELETE_INFRASTRUCTURE)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> deleteInfrastructure(Authentication authentication,
			@PathVariable String infraUuid) {
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeId = userDetails.getSmeId();
		String userId = userDetails.getUserId();

		logger.info("request for Delete Infrastructure by userId:-{} and smeId:-{} and infraId:-{}", userId, smeId,
				infraUuid);
		try {
			smeService.deleteInfra(smeId, infraUuid);
			countManageService.updateItemsCount(smeId, ItemType.INFRASTRUCTURE);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@DeleteMapping(UrlMapping.DELETE_CERTIFICATE)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> deleteCertificate(Authentication authentication,
			@PathVariable String crtiUuid) {
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeId = userDetails.getSmeId();
		String userId = userDetails.getUserId();

		logger.info("request for Delete Certificate by userId:-{} and smeId:-{} and infraId:-{}", userId, smeId,
				crtiUuid);
		try {
			smeService.deleteCertificate(smeId, crtiUuid);
			countManageService.updateItemsCount(smeId, ItemType.CERTIFICATE);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@DeleteMapping(UrlMapping.DELETE_TEAM)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> deleteTeam(Authentication authentication, @PathVariable String teamUuid) {
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeId = userDetails.getSmeId();
		String userId = userDetails.getUserId();

		logger.info("request for Delete Management team by userId:-{} and smeId:-{} and infraId:-{}", userId, smeId,
				teamUuid);
		try {
			smeService.deleteTeam(smeId, teamUuid);
			countManageService.updateItemsCount(smeId, ItemType.TEAM);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@DeleteMapping(UrlMapping.DELETE_GALLERY)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> deleteGallery(Authentication authentication,
			@PathVariable String galleryUuid) {
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeId = userDetails.getSmeId();
		String userId = userDetails.getUserId();

		logger.info("request for Delete Gallery by userId:-{} and smeId:-{} and infraId:-{}", userId, smeId,
				galleryUuid);

		try {
			smeService.deleteGallery(smeId, galleryUuid);
			countManageService.updateItemsCount(smeId, ItemType.GALLERY);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.GET_SME)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse<SMEInformationDto>> getSmeInfoForEditMode(Authentication authentication) {
		SMEInformationDto informationDto = null;
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();
		String smeId = userDetails.getSmeId();
		String userId = userDetails.getUserId();
		logger.info("request for get sme for edit mode by userId:- {} and smeId:- {}", userId, smeId);
		try {
			informationDto = mapper.convertToDto(smeService.getSME(smeId, SMEMasterConstants.BOTH),
					SMEInformationDto.class);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(informationDto, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.GET_SME_VIEWMODE)
	public ResponseEntity<CustomHttpResponse<SMEInformationDto>> getSmeInfoForViewMode(@PathVariable String smeUuid) {
		logger.info("request for get active sme for view mode by smeId:- {}", smeUuid);

		SMEInformationDto informationDto = null;

		try {
			informationDto = mapper.convertToDto(smeService.getSME(smeUuid, SMEMasterConstants.ACTIVE),
					SMEInformationDto.class);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(informationDto, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.GET_TOP_SMES)
	public ResponseEntity<CustomHttpResponse<List<SMEInformationVo>>> getTopSME() {
		List<SMEInformationVo> smelist = null;
		try {
			smelist = smeService.getTopSmes();
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(smelist, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.SPECIFIC_SMES)
	public ResponseEntity<CustomHttpResponse<Map<String, SMEInformationVo>>> getSMEs(@RequestParam Set<String> smeIds,
			@RequestParam(required = false) boolean activeStatus) {
		logger.info("request for smes with ids:- {} and active status:- {}", smeIds, activeStatus);
		Map<String, SMEInformationVo> smes = new HashMap<>();

		List<SMEInformation> smelist = null;
		try {
			if (activeStatus) {
				smelist = smeService.getSpecificSMEs(smeIds, SMEMasterConstants.ACTIVE);
			} else {
				smelist = smeService.getSpecificSMEs(smeIds, SMEMasterConstants.BOTH);
			}

			smes = smelist.stream().map(mapper::convertToVo)
					.collect(Collectors.toMap(SMEInformationVo::getsUuid, sme -> sme));
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(smes, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.GET_SMEVO)
	public ResponseEntity<CustomHttpResponse<SMEInformationVo>> getSmeVo(@PathVariable String smeUuid) {

		logger.info("request for get sme vo with smeUuid:- {}", smeUuid);

		SMEInformationVo smeVo = null;
		try {
			smeVo = mapper.convertToVo(smeService.getSME(smeUuid, SMEMasterConstants.BOTH));
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(smeVo, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.VALIDATE_GSTIN)
	public ResponseEntity<CustomHttpResponse> checkGSTINNumberPresent(@PathVariable String gstin) {
		logger.info("request for validate {} gstin number.", gstin);

		if (smeService.isGSTINNumberExist(gstin))
			throw new CustomException("GSTIN Number Already Present", HttpStatus.BAD_REQUEST);
		else
			return responseMaker.successResponse("Given GSTIN number not used.", HttpStatus.OK);

	}

	@GetMapping(UrlMapping.SME_OBJECT_COUNT)
	public ResponseEntity<CustomHttpResponse<SmeSubEntitiesCount>> getSMEItemsCount(@PathVariable String smeUuid,
			@RequestParam(value = "viewMode", required = false) boolean viewMode) {

		logger.info("request for get sme items count for sme {} and viewMode {}", smeUuid, viewMode);
		SmeSubEntitiesCount countData = null;
		try {
			countData = smeService.getCounts(smeUuid, viewMode);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(countData, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.SME_OBJECT_PERCENTAGE)
	@PreAuthorize(Roles.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse<EditModeItemsPercentage>> getSmeItemsCountWithPercentage(
			Authentication authentication) {
		EditModeItemsPercentage editModeItemsPercentage = null;
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();

		String smeUuid = userDetails.getSmeId();
		try {
			editModeItemsPercentage = smeService.getPercentageCounts(smeUuid);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(editModeItemsPercentage, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

}
