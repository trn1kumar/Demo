package com.gloqr;

import javax.validation.Valid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.PropertySource;

@SpringBootApplication
@Valid
@EnableCaching
@PropertySource(value = { "file:${location}/sme_master.properties" })
public class SmeInformationMasterApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmeInformationMasterApplication.class, args);
	}

}
