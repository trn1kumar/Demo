package com.gloqr.constants;

public enum TurnOverUnit {
	CRORES, LAKHS
}
