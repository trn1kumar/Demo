package com.gloqr.constants;

public final class SMEMasterConstants {

	private SMEMasterConstants() {
		throw new IllegalStateException("SMEMasterConstants class.can't initiate");
	}

	public static final String COMPANY_LOGO = "logoImage";
	public static final String SLIDER_IMAGES = "sliderImages";
	public static final String CERTIFICATES = "certificates";
	public static final String INFRASTRUCTURES = "infrastructures";
	public static final String GALLERIES = "galleries";
	public static final String TEAMS = "teams";

	public static final String NEW_SMES = "new";
	public static final String EXISTING_SMES = "existing";

	// status constant
	public static final String ACTIVE = "active";
	public static final String DEACTIVE = "deactive";
	public static final String BOTH = "both";

	// SMEFileDirectory
	public static final String SME = "sme/{sUuid}/logo";
	public static final String SME_HOME_SLIDER = "sme/{sUuid}/sliders";
	public static final String SME_INFRASTRUCTURE = "sme/{sUuid}/infrastructures";
	public static final String SME_MANAGEMENT_TEAM = "sme/{sUuid}/teams";
	public static final String SME_CERTIFICATE = "sme/{sUuid}/certificates";
	public static final String SME_GALLERY = "sme/{sUuid}/galleries";

	public static class BooleanFlag {
		private BooleanFlag() {
			throw new IllegalStateException("BooleanFlag class.can't initiate");
		}

		public static final boolean FALSE = false;
		public static final boolean TRUE = true;
	}

}
