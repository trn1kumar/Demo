package com.gloqr.constants;

public class FilterConstant {

	private FilterConstant() {
		throw new IllegalStateException("FilterConstant class.can't initiate");
	}

	public class FacetConstant {
		private FacetConstant() {
			throw new IllegalStateException("FacetConstant class.can't initiate");
		}

		public static final String CATEGORY_FACET = "categoryFacet";
		public static final String CITY_FACET = "cityFacet";

		public static final String CATEGORY_FACET_REQ = "categoryFacetingReq";
		public static final String CITY_FACET_REQ = "cityFacetingReq";
	}

	public class SearchFields {
		private SearchFields() {
			throw new IllegalStateException("SearchFields class.can't initiate");
		}

		public static final String CATEGORY = "smeCategory.categoryName";
		public static final String CITY = "smeAddress.city";

		public static final String CREATION_DATE = "creationDate";
		public static final String ACTIVE = "active";
		public static final String SME_NAME = "smeName";
		public static final String VERIFIED = "verified";

		public static final String CERTIFICATES_COUNT = "itemsCount.activePendingCertificates";
		public static final String INFRAS_COUNT = "itemsCount.activePendingInfras";
		public static final String TEAMS_COUNT = "itemsCount.activePendingTeams";
		public static final String GALLERIES_COUNT = "itemsCount.activePendingGalleries";
		public static final String PRODUCTS_COUNT = "itemsCount.activePendingProducts";
		public static final String SERVICES_COUNT = "itemsCount.activePendingServices";
		public static final String BPOSTS_COUNT = "itemsCount.activePendingBusinessPosts";
		public static final String VACANCIES_COUNT = "itemsCount.activePendingVacancies";
		public static final String PAYMENT_VERIFICATION_PENDING = "itemsCount.pendingOfflinePaymentVerification";

	}

}
