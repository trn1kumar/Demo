package com.gloqr.constants;

public final class UrlMapping {
	public static final String ROOT_API = "/api/smes";
	public static final String GLOQR_ADMIN_API = ROOT_API + "/gloqr-admin";

	private UrlMapping() {
		throw new IllegalStateException("UrlMapping class.can't initiate");
	}

	/* SMEControllerUrls */

	// add
	public static final String SAVE_SME = "/sme";
	public static final String SAVE_INFRASTRUCTURE = "/infrastructures";
	public static final String SAVE_TEAM = "/teams";
	public static final String SAVE_CERTIFICATE = "/certificates";
	public static final String SAVE_GALLERY = "/galleries";

	// update
	public static final String MODIFY_ADDRESS = "/address";
	public static final String UPDATE_INFRASTRUCTURE = "/infrastructures";
	public static final String UPDATE_CERTIFICATE = "/certificates";
	public static final String UPDATE_GALLERY = "/galleries";
	public static final String UPDATE_TEAM = "/teams";
	public static final String SME_ITEMS_COUNT = "/items/count";
	public static final String SME_ITEMS1_COUNT = "/items1/count";

	// get multiple for edit mode
	public static final String GET_INFRASTRUCTURES = "/infrastructures";
	public static final String GET_CERTIFICATES = "/certificates";
	public static final String GET_TEAMS = "/teams";
	public static final String GET_GALLERIES = "/galleries";

	// get multiple for view mode
	public static final String GET_APPROVED_INFRASTRUCTURES = "/{smeUuid}/infrastructures";
	public static final String GET_APPROVED_CERTIFICATES = "/{smeUuid}/certificates";
	public static final String GET_APPROVED_TEAMS = "/{smeUuid}/teams";
	public static final String GET_APPROVED_GALLERIES = "/{smeUuid}/galleries";

	// get single
	public static final String GET_INFRASTRUCTURE = "/infrastructure/{infraUuid}";
	public static final String GET_TEAM = "/team/{teamUuid}";
	public static final String GET_CERTIFICATE = "/certificate/{crtiUuid}";
	public static final String GET_GALLERY = "/gallery/{galleryUuid}";

	// delete single
	public static final String DELETE_INFRASTRUCTURE = "/infrastructure/{infraUuid}";
	public static final String DELETE_CERTIFICATE = "/certificate/{crtiUuid}";
	public static final String DELETE_TEAM = "/team/{teamUuid}";
	public static final String DELETE_GALLERY = "/gallery/{galleryUuid}";

	// get sme details
	public static final String GET_SMEVO = "/{smeUuid}/vo";
	public static final String GET_SME_VIEWMODE = "/{smeUuid}";
	public static final String GET_SME = "/sme";
	public static final String GET_TOP_SMES = "/top";
	public static final String SPECIFIC_SMES = "/list";
	public static final String SME_OBJECT_COUNT = "/{smeUuid}/sme/count";
	public static final String SME_OBJECT_PERCENTAGE = "/sme/percentage";

	public static final String VALIDATE_GSTIN = "/{gstin}/validate";

	// SMEFilterController
	public static final String GET_SMES = "/fetch";
	public static final String MENU_BAR_FILTER = "/menu/filter";

	// SMESearchController
	public static final String SEARCH_SUGGEST = "/search-suggest";
	public static final String SEARCH_RESULT = "/search/res";

	// Gloqr AdminControllerUrls
	public static final String SMES = "/smes-list";
	public static final String SME = "/{smeUuid}/sme";
	public static final String GET_SME_ITEMS = "/items";
	public static final String VERIFY_SME = "/verify";
	public static final String MODIFY_ITEM_STATE = "/items/state";
	public static final String UPDATE_IMAGES = "/images";

	// SMECategoryControllerUrls
	public static final String CATEGORY = "/category";
	public static final String CATEGORIES = "/categories";

	// SMESearchControllerUrls
	public static final String SERACH_SME = "/search/sme";
	public static final String AUTO_SUGGEST_SEARCH = "/search/auto-suggest";

	// FileControllerUrls
	public static final String SAVE_IMAGES = "/images";
	public static final String CHANGE_LOGO_IMAGE = "/change/logo-image";
	public static final String UPLOAD_HOME_SLIDER_IMAGE = "/upload/slider-image";
	public static final String UPDATE_BUSINESS_POST_IMAGE = "/images";

	// SMEDataPublishControllerUrls
	public static final String MODIFY_ITEMS_STATUS = "/sme/modify-status-of-sub-entities";
	
	//CircleController
	public static final String CIRCLE_SUGGESTIONS = "/circle/suggestions";
}
