package com.gloqr.constants;

public class Roles {

	private Roles() {
		throw new IllegalStateException("Roles class.can't initiate");
	}

	// RoleAccess
	public static final String SME_ADMIN = "hasAnyRole('SME-ADMIN')";
	
	public static final String GLOQR_ADMIN = "GLOQR-SUPER-ADMIN";
	public static final String USER = "hasAnyRole('USER')";
	public static final String SME_ADMIN_AND_USER = "hasAnyRole('USER','SME-ADMIN')";
	public static final String SME_ADMIN_AND_GLOQR_ADMIN = "hasAnyRole('SME-ADMIN','GLOQR-SUPER-ADMIN')";
	public static final String ALL_ROLES = "hasAnyRole('USER','GLOQR-SUPER-ADMIN','SME-ADMIN')";
}
