package com.gloqr.constants;

public class NotificationConstants {

	public static final String SME_APPROVED_TEMPLATES = "SMEApproved";
	public static final String SME_WELCOME_TEMPLATES = "SMEWelcome";
	public static final String CERTIFICATES_VERIFI_TEMPLATES = "CertificateVerificationReport";
	public static final String INFRAS_VERIFI_TEMPLATES = "InfrasVerificationReport";
	public static final String TEAMS_VERIFI_TEMPLATES = "TeamsVerificationReport";
	public static final String GALLERIES_VERIFI_TEMPLATES = "GalleriesVerificationReport";
}
