package com.gloqr.constants;

public enum RegisteredType {

	PUBLIC, PRIVATE, PROPRIETORSHIP, PARTNERSHIP, OTHER
}
