package com.gloqr.constants;

public class PropertyNames {

	private PropertyNames() {
		throw new IllegalStateException("PropertyNames class.can't initiate");
	}

	// PAGINATION PROPERTY-NAMES
	public static final String TOP_SMES_PAGE_SIZE = "${top-smes-page-size}";
	public static final String GLOQR_ADMIN_SMES_PAGE_SIZE = "${gloqr-admin-smes-page-size}";
	public static final String NORMAL_PAGE_SIZE = "${normal-page-size}";
	public static final String MOBILE_PAGE_SIZE = "${mobile-page-size}";
	public static final String TABLET_PAGE_SIZE = "${tablet-page-size}";

	// NOTIFICATIONS PROPERTY-NAMES
	public static final String WELCOME_NOTIFI_EMAIL_SUB = "${notify.welcome.email-subject}";
	public static final String WELCOME_NOTIFI_SMS_MSG = "${notify.welcome.smsMsg}";
	public static final String APPROVED_NOTIFI_EMAIL_SUB = "${notify.approved-sme.email-subject}";
	public static final String APPROVED_NOTIFI_SMS_MSG = "${notify.approved-sme.smsMsg}";

	public static final String CERTIFICATES_VERIFI_EMAIL_SUB = "${notify.certificates-verifi.email-subject}";
	public static final String INFRAS_VERIFI_EMAIL_SUB = "${notify.infras-verifi.email-subject}";
	public static final String TEAMS_VERIFI_EMAIL_SUB = "${notify.teams-verifi.email-subject}";
	public static final String GALLERIES_VERIFI_EMAIL_SUB = "${notify.galleries-verifi.email-subject}";

	public static final String BASE_URL = "${base-url}";
	public static final String SME_HOME_PAGE_URL = "${sme.home-url}";
	public static final String CONTENT_SERVER_URL = "${content-server.localized-url}";

	public static final String ADMIN_RESULT_PAGE_SIZE = "${admin-result-page-size}";
}
