package com.gloqr.constants;

public enum ItemStatus {
	ACTIVE, DEACTIVE
}
