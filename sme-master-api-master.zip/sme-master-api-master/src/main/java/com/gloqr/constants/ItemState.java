package com.gloqr.constants;

public enum ItemState {
	PENDING, APPROVED, REJECTED
}
