package com.gloqr.constants;

public enum SMEType {
	TRADER, MANUFACTURE,PROVIDER
}
