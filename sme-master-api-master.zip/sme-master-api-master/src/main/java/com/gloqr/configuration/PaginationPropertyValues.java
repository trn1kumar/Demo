package com.gloqr.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.gloqr.constants.PropertyNames;

@Configuration
public class PaginationPropertyValues {

	@Value(PropertyNames.TOP_SMES_PAGE_SIZE)
	private int topSmesPageSize;
	
	@Value(PropertyNames.GLOQR_ADMIN_SMES_PAGE_SIZE)
	private int gloqrAdminSmesPageSize;

	@Value(PropertyNames.NORMAL_PAGE_SIZE)
	private int normalPageSize;

	@Value(PropertyNames.MOBILE_PAGE_SIZE)
	private int mobilePageSize;

	@Value(PropertyNames.TABLET_PAGE_SIZE)
	private int tabletPageSize;

	public int getNormalPageSize() {
		return normalPageSize;
	}

	public void setNormalPageSize(int normalPageSize) {
		this.normalPageSize = normalPageSize;
	}

	public int getMobilePageSize() {
		return mobilePageSize;
	}

	public void setMobilePageSize(int mobilePageSize) {
		this.mobilePageSize = mobilePageSize;
	}

	public int getTabletPageSize() {
		return tabletPageSize;
	}

	public void setTabletPageSize(int tabletPageSize) {
		this.tabletPageSize = tabletPageSize;
	}

	public int getTopSmesPageSize() {
		return topSmesPageSize;
	}

	public void setTopSmesPageSize(int topSmesPageSize) {
		this.topSmesPageSize = topSmesPageSize;
	}

	public int getGloqrAdminSmesPageSize() {
		return gloqrAdminSmesPageSize;
	}

	public void setGloqrAdminSmesPageSize(int gloqrAdminSmesPageSize) {
		this.gloqrAdminSmesPageSize = gloqrAdminSmesPageSize;
	}

}
