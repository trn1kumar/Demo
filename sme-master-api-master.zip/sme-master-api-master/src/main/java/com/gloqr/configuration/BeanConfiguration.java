package com.gloqr.configuration;

import javax.annotation.Resource;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.gloqr.rest.endpoint.BusinessPostEndpoint;
import com.gloqr.rest.endpoint.CircleEndpoint;
import com.gloqr.rest.endpoint.ContentServerEndpoint;
import com.gloqr.rest.endpoint.NotificationEndPoint;
import com.gloqr.rest.endpoint.PricingEndpoint;
import com.gloqr.rest.endpoint.UserEndpoint;

@Configuration

@EnableAsync
public class BeanConfiguration {

	private static final Logger log = LogManager.getLogger();

	@Resource
	private Environment environment;

	@Bean
	public ClientConfig clientConfig() {
		ClientConfig configuration = new ClientConfig();
		configuration.property(ClientProperties.CONNECT_TIMEOUT, 10000);
		configuration.property(ClientProperties.READ_TIMEOUT, 30000);

		return configuration;
	}

	@Bean(name = "taskExecutor")
	public TaskExecutor workExecutor() {
		int poolsize = 0;
		int maxPoolSize = 0;
		int capacity = 0;

		ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
		threadPoolTaskExecutor.setThreadNamePrefix(environment.getRequiredProperty("thread.name.prefix"));
		try {
			poolsize = Integer.parseInt(environment.getRequiredProperty("pool.size"));
			maxPoolSize = Integer.parseInt(environment.getRequiredProperty("max.pool.size"));
			capacity = Integer.parseInt(environment.getRequiredProperty("queue.capacity"));
		} catch (NumberFormatException e) {
			log.info(("Problem Occurred to read thread property " + e.getLocalizedMessage()
					+ " from application properties.make sure that provided property is integer"));
			System.exit(0);
		}
		threadPoolTaskExecutor.setCorePoolSize(poolsize);
		threadPoolTaskExecutor.setMaxPoolSize(maxPoolSize);
		threadPoolTaskExecutor.setQueueCapacity(capacity);
		threadPoolTaskExecutor.afterPropertiesSet();
		log.info("ThreadPoolTaskExecutor set");
		return threadPoolTaskExecutor;
	}

	@Bean
	public UserEndpoint userEndpoint() {
		Client client = ClientBuilder.newClient(clientConfig());
		String endpoint = environment.getRequiredProperty("user.endpoint");
		String changeTypePath = environment.getRequiredProperty("changetype.path");
		return new UserEndpoint(client, endpoint, changeTypePath);

	}

	@Bean
	public CircleEndpoint circleEndpoint() {
		Client client = ClientBuilder.newClient(clientConfig());
		String endpoint = environment.getRequiredProperty("circle.endpoint");
		String createCircle = environment.getRequiredProperty("create.circle");
		return new CircleEndpoint(client, endpoint, createCircle);

	}

	@Bean
	public BusinessPostEndpoint businessPostEndpoint() {
		Client client = ClientBuilder.newClient(clientConfig());
		String endpoint = environment.getRequiredProperty("business-post.endpoint");
		String createFeed = environment.getRequiredProperty("post.path");
		String updateStatus = environment.getRequiredProperty("update.status.path");
		return new BusinessPostEndpoint(client, endpoint, createFeed, updateStatus);

	}

	@Bean
	public ContentServerEndpoint contentConfiguration() {
		Client client = ClientBuilder.newBuilder().register(MultiPartFeature.class).build();

		String contentServerEndPoint = environment.getRequiredProperty("contentserver.endpoint");
		String uploadMultipleFile = environment.getRequiredProperty("uploadsfiles.endpoint.path");
		String deleteFile = environment.getRequiredProperty("deletefile.endpoint.path");
		String deleteFiles = environment.getRequiredProperty("deletefiles.endpoint.path");

		return new ContentServerEndpoint(client, contentServerEndPoint, uploadMultipleFile, deleteFile, deleteFiles);
	}

	@Bean
	public PricingEndpoint pricingEndpoint() {
		Client client = ClientBuilder.newClient(clientConfig());
		String pricingEndpoint = environment.getRequiredProperty("pricing.endpoint");
		String checkCreditsPath = environment.getRequiredProperty("user.credits");
		String selectPkg = environment.getRequiredProperty("select.pkg.path");

		return new PricingEndpoint(client, pricingEndpoint, checkCreditsPath, selectPkg);
	}

	@Bean
	public NotificationEndPoint notificationConfiguration() {
		Client client = ClientBuilder.newClient(clientConfig());
		String notificationEndPoint = environment.getRequiredProperty("notification.endpoint");
		String smsEndPointPath = environment.getRequiredProperty("sms.endpoint.path");
		String emailEndPointPath = environment.getRequiredProperty("email.endpoint.path");

		return new NotificationEndPoint(client, notificationEndPoint, smsEndPointPath, emailEndPointPath);
	}

}
