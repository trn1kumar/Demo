package com.gloqr.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.gloqr.constants.PropertyNames;

@Configuration
public class NotificationPropertyValues {

	@Value(PropertyNames.WELCOME_NOTIFI_SMS_MSG)
	private String welcomeSmsMsg;

	@Value(PropertyNames.WELCOME_NOTIFI_EMAIL_SUB)
	private String welcomeEmailSubject;

	@Value(PropertyNames.APPROVED_NOTIFI_EMAIL_SUB)
	private String smeApprovedEmailSubject;

	@Value(PropertyNames.APPROVED_NOTIFI_SMS_MSG)
	private String smeApprovedSmsMsg;

	@Value(PropertyNames.CERTIFICATES_VERIFI_EMAIL_SUB)
	private String certificatesVerifiEmailSub;

	@Value(PropertyNames.TEAMS_VERIFI_EMAIL_SUB)
	private String teamsVerifiEmailSub;

	@Value(PropertyNames.INFRAS_VERIFI_EMAIL_SUB)
	private String infrasVerifiEmailSub;

	@Value(PropertyNames.GALLERIES_VERIFI_EMAIL_SUB)
	private String galleriesVerifiEmailSub;

	@Value(PropertyNames.BASE_URL)
	private String baseUrl;

	@Value(PropertyNames.CONTENT_SERVER_URL)
	private String contentServerUrl;

	@Value(PropertyNames.SME_HOME_PAGE_URL)
	private String smeHomePageUrl;

	public String getWelcomeSmsMsg() {
		return welcomeSmsMsg;
	}

	public void setWelcomeSmsMsg(String welcomeSmsMsg) {
		this.welcomeSmsMsg = welcomeSmsMsg;
	}

	public String getWelcomeEmailSubject() {
		return welcomeEmailSubject;
	}

	public void setWelcomeEmailSubject(String welcomeEmailSubject) {
		this.welcomeEmailSubject = welcomeEmailSubject;
	}

	public String getSmeApprovedEmailSubject() {
		return smeApprovedEmailSubject;
	}

	public void setSmeApprovedEmailSubject(String smeApprovedEmailSubject) {
		this.smeApprovedEmailSubject = smeApprovedEmailSubject;
	}

	public String getSmeApprovedSmsMsg() {
		return smeApprovedSmsMsg;
	}

	public void setSmeApprovedSmsMsg(String smeApprovedSmsMsg) {
		this.smeApprovedSmsMsg = smeApprovedSmsMsg;
	}

	public String getCertificatesVerifiEmailSub() {
		return certificatesVerifiEmailSub;
	}

	public void setCertificatesVerifiEmailSub(String certificatesVerifiEmailSub) {
		this.certificatesVerifiEmailSub = certificatesVerifiEmailSub;
	}

	public String getTeamsVerifiEmailSub() {
		return teamsVerifiEmailSub;
	}

	public void setTeamsVerifiEmailSub(String teamsVerifiEmailSub) {
		this.teamsVerifiEmailSub = teamsVerifiEmailSub;
	}

	public String getInfrasVerifiEmailSub() {
		return infrasVerifiEmailSub;
	}

	public void setInfrasVerifiEmailSub(String infrasVerifiEmailSub) {
		this.infrasVerifiEmailSub = infrasVerifiEmailSub;
	}

	public String getGalleriesVerifiEmailSub() {
		return galleriesVerifiEmailSub;
	}

	public void setGalleriesVerifiEmailSub(String galleriesVerifiEmailSub) {
		this.galleriesVerifiEmailSub = galleriesVerifiEmailSub;
	}

	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	public String getContentServerUrl() {
		return contentServerUrl;
	}

	public void setContentServerUrl(String contentServerUrl) {
		this.contentServerUrl = contentServerUrl;
	}

	public String getSmeHomePageUrl() {
		return smeHomePageUrl;
	}

	public void setSmeHomePageUrl(String smeHomePageUrl) {
		this.smeHomePageUrl = smeHomePageUrl;
	}

}
