package com.gloqr.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mobile.device.Device;
import org.springframework.mobile.device.DeviceUtils;
import org.springframework.stereotype.Component;

import com.gloqr.configuration.PaginationPropertyValues;
import com.gloqr.security.context.holder.ContextHolder;

@Component
public class PaginationUtil {

	@Autowired
	private PaginationPropertyValues propertyValues;

	public int getPageSize() {

		int pageSize = propertyValues.getNormalPageSize();

		Device device = DeviceUtils.getCurrentDevice(ContextHolder.getCurrentServletRequest());

		if (device.isMobile())
			pageSize = propertyValues.getMobilePageSize();
		if (device.isTablet())
			pageSize = propertyValues.getTabletPageSize();

		return pageSize;
	}

	public int getTopSmesPageSize() {
		return propertyValues.getTopSmesPageSize();
	}

	public int getGloqrAdminSmesPageSize() {
		return propertyValues.getGloqrAdminSmesPageSize();
	}
}
