package com.gloqr.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Service;

@Service
public class CacheServiceImpl implements CacheService {

	private static final Logger log = LogManager.getLogger();

	@Override
	@Caching(evict = { @CacheEvict(value = { "smes" }, allEntries = true) })
	public void evictSmesCache() {
		log.info("Evicted 'smes' Cache");
	}

}
