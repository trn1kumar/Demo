package com.gloqr.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;

import org.apache.lucene.search.Query;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.DatabaseRetrievalMethod;
import org.hibernate.search.query.ObjectLookupMethod;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.constants.FilterConstant.SearchFields;
import com.gloqr.dto.FilterResponse;
import com.gloqr.entities.SMEInformation;
import com.gloqr.service.filter.MainFilterService;

@Service
@SuppressWarnings("unchecked")
public class SMESearchServiceImpl implements SMESearchService {

	@Autowired
	private EntityManager entityManager;

	@Autowired
	private MainFilterService mainFilterService;

	@Override
	public List<String> getSearchSuggestions(String searchText, int maxResult) {

		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(SMEInformation.class).get();

		Query lucenceQuery = queryBuilder.bool()
				.must(queryBuilder.simpleQueryString().onField(SearchFields.SME_NAME).withAndAsDefaultOperator()
						.matching(searchText).createQuery())
				.must(queryBuilder.keyword().onField(SearchFields.ACTIVE).matching(true).createQuery()).createQuery();

		FullTextQuery fullTextQuery = fullTextEntityManager.createFullTextQuery(lucenceQuery, SMEInformation.class);
		fullTextQuery.setFirstResult(0);
		fullTextQuery.setMaxResults(maxResult);
		fullTextQuery.initializeObjectsWith(ObjectLookupMethod.SECOND_LEVEL_CACHE, DatabaseRetrievalMethod.QUERY);

		fullTextQuery.setProjection(SearchFields.SME_NAME);

		List<Object> results = fullTextQuery.getResultList();
		List<String> suggestions = new ArrayList<>();
		for (int i = 0; i < results.size(); i++) {
			String value = ((Object[]) results.get(i))[0].toString();
			if (!suggestions.contains(value))
				suggestions.add(value);
		}
		return suggestions;
	}

	public FilterResponse getSearchResults(String searchText, Set<String> categoriesFilterParam,
			Set<String> citiesFilterParam, int page) {

		return mainFilterService.applyFilter(searchText, categoriesFilterParam, citiesFilterParam, page);
	}

}
