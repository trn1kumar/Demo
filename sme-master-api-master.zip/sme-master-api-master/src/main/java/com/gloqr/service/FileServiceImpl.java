package com.gloqr.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.dao.ImageDao;
import com.gloqr.entities.Image;
import com.gloqr.exception.CustomException;
import com.gloqr.model.UploadFileResponse;
import com.gloqr.rest.endpoint.ContentServerEndpoint;
import com.gloqr.util.RandomAlphaNumCharGenerator;
import com.gloqr.util.UuidUtil;

@Service
public class FileServiceImpl implements FileService {

	@Autowired
	private ContentServerEndpoint contentServerEndpoint;

	@Autowired
	private ImageDao imageDao;

	Logger logger = LogManager.getLogger();

	@Override
	public List<Image> saveAndSendFilesToContentServer(List<MultipartFile> files, String fileLocation) {

		List<Image> images = this.sendFilesToContentServer(files, fileLocation);
		imageDao.saveMultipleImages(images);
		return images;

	}

	@Override
	public List<Image> sendFilesToContentServer(List<MultipartFile> files, String fileLocation) {

		List<Image> images = null;

		List<String> names = new ArrayList<>();
		files.forEach(file -> names.add(RandomAlphaNumCharGenerator.randomNumber(1000) + file.getOriginalFilename()));

		List<UploadFileResponse> fileDetails = null;
		try {
			fileDetails = contentServerEndpoint.sendFilesToContentServer(files, names, fileLocation);
		} catch (IOException e) {
			throw new CustomException("IOException in sendFilesToContentServer () {  }. message:  " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

		images = new ArrayList<>();
		for (UploadFileResponse fileDetail : fileDetails) {
			images.add(new Image(UuidUtil.getUuid(), fileDetail.getFileName(), fileDetail.getFileLocation(),
					fileDetail.getFileLocation(), fileDetail.getFileLocation(), false, fileDetail.getSize()));
		}

		return images;

	}

	@Override
	public void deleteFileFromContentServer(String fileLocation) {
		try {
			contentServerEndpoint.deleteFileFromContentServer(fileLocation);
		} catch (Exception e) {
			logger.error("deletion failed.Exception {}", e.getMessage());
		}
	}

	@Override
	public void updateImagesByBusinessPostFalse(Set<String> imageLocations) {
		imageDao.updateImagesByBusinessPostFalse(imageLocations);
	}

}
