package com.gloqr.service;

import java.util.List;
import java.util.Set;

import com.gloqr.constants.ItemType;
import com.gloqr.dto.count.EditModeItemsPercentage;
import com.gloqr.entities.Address;
import com.gloqr.entities.Certificate;
import com.gloqr.entities.Gallery;
import com.gloqr.entities.Image;
import com.gloqr.entities.Infrastructure;
import com.gloqr.entities.ManagementTeam;
import com.gloqr.entities.SMECategory;
import com.gloqr.entities.SMEInformation;
import com.gloqr.model.AuthToken;
import com.gloqr.vo.SMEInformationVo;
import com.gloqr.vo.SmeSubEntitiesCount;

public interface SMEService {

	// save
	public AuthToken saveSme(SMECategory smeCategory);

	public SMEInformation saveSMEDetails(SMEInformation sme);

	// add entities into sme
	public void saveInfrastructure(Infrastructure infrastructure, String smeId);

	public void saveCertificates(List<Certificate> certificates, String smeId);

	public void saveGalleries(List<Gallery> galleryList, String smeId);

	public void saveManagementTeams(List<ManagementTeam> managementTeam, String smeId);

	// update
	public SMEInformation updateSme(SMEInformation sme);

	public Address updateSmeAddress(String smeId, Address address);

	public void updateInfrastructure(Infrastructure infrastructure, String smeId);

	public void updateCertificate(Certificate certificate, String smeId);

	public void updateManagementTeam(ManagementTeam team, String smeId);

	public void updateGallery(Gallery gallery, String smeId);

	// modify image
	public void saveOrUpdateSliderImages(String smeId, List<Image> images);

	public String changeLogoImage(String smeId, String newImageLocation);

	// save multiple entities
	public void saveMultipleInfras(List<Infrastructure> infras);

	public void saveMultipleCertificates(List<Certificate> certificates);

	public void saveMultipleTeams(List<ManagementTeam> teams);

	public void saveMultipleGalleries(List<Gallery> galleries);

	// get data of particular sme
	public List<Infrastructure> getAllInfrastructure(String smeId, String status);

	public List<Certificate> getAllCertificate(String smeId, String status);

	public List<ManagementTeam> getAllManagementTeam(String smeId, String status);

	public List<Gallery> getAllGalleries(String smeId, String status);

	// get approved data of particular sme
	public List<Infrastructure> getActiveAndApprovedInfras(String smeId);

	public List<Certificate> getActiveAndApprovedCertificates(String smeId);

	public List<ManagementTeam> getActiveAndApprovedManagementTeams(String smeId);

	public List<Gallery> getActiveAndApprovedGalleries(String smeId);

	// get single data
	public Infrastructure getInfrastructure(String infraUuid);

	public Certificate getCertificate(String crtiUuid);

	public ManagementTeam getManagementTeam(String teamUuid);

	public Gallery getGallery(String galleryUuid);

	// get sme

	public SMEInformation getSME(String smeId, String status);

	public List<SMEInformationVo> getTopSmes();

	public List<SMEInformation> getSpecificSMEs(Set<String> smeIds, String status);

	// delete sme data
	public void deleteInfra(String smeUuid, String infraUuid);

	public void deleteCertificate(String smeUuid, String crtiUuid);

	public void deleteTeam(String smeUuid, String teamUuid);

	public void deleteGallery(String smeUuid, String galleryUuid);

	// check GSTIN number is valid
	public boolean isGSTINNumberExist(String gstin);

	// sme sub entites count
	public SmeSubEntitiesCount getCounts(String smeId, boolean viewMode);

	// get sme by its subObjects
	public SMEInformation getActiveSmeByItemId(String itemId, ItemType itemType);

	
	public EditModeItemsPercentage getPercentageCounts(String smeId);
}
