package com.gloqr.service;

import com.gloqr.constants.ItemType;
import com.gloqr.entities.SMEItemsCount;
import com.gloqr.model.ItemsCountUpdate;

public interface CountManageService {

	void updateItemsCount(String userUuid, String smeUuid, ItemsCountUpdate itemsCountUpdate);

	void updateItemsCount(String smeId, ItemType itemType);

	SMEItemsCount getItemsCount(String smeUuid);

}
