package com.gloqr.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.gloqr.constants.ItemType;
import com.gloqr.dao.SMEDao;
import com.gloqr.entities.SMEInformation;
import com.gloqr.entities.SMEItemsCount;
import com.gloqr.model.ItemsCountUpdate;

@Service
public class CountManageServiceImpl implements CountManageService {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private SMEDao smeDao;

	@Autowired
	private CacheService cacheService;

	@Override
	public SMEItemsCount getItemsCount(String smeUuid) {
		return smeDao.getSmeItemsCount(smeUuid);
	}

	private SMEInformation getItemsCount(String userUuid, String smeUuid) {

		SMEInformation sme = null;
		if (userUuid != null) {
			sme = smeDao.getSMEByUserUuid(userUuid);
		} else {
			sme = smeDao.getSMEWithOutCache(smeUuid);
		}

		SMEItemsCount itemsCount = sme.getItemsCount();
		if (itemsCount == null) {
			itemsCount = new SMEItemsCount();
			sme.setItemsCount(itemsCount);
		}
		// for update SME Document index for hibernate/facet search
		itemsCount.setSmeInformation(sme);
		return sme;
	}

	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class, propagation = Propagation.REQUIRES_NEW)
	public void updateItemsCount(String smeUuid, ItemType itemType) {

		SMEInformation sme = getItemsCount(null, smeUuid);
		SMEItemsCount itemsCount = sme.getItemsCount();

		switch (itemType) {
		case CERTIFICATE:
			ItemsCountUpdate countUpdate = smeDao.getCounts(smeUuid, itemType);
			log.info("Updating CERTIFICATE'S ItemCounts :: {}", countUpdate);
			itemsCount.setTotalCertificates(countUpdate.getTotalCount());
			itemsCount.setActivePendingCertificates(countUpdate.getActivePendingCount());
			itemsCount.setActiveApprovedCertificates(countUpdate.getActiveApprovedCount());
			break;
		case INFRASTRUCTURE:
			ItemsCountUpdate countUpdate1 = smeDao.getCounts(smeUuid, itemType);
			log.info("Updating INFRASTRUCTURE'S Counts :: {}", countUpdate1);
			itemsCount.setTotalInfras(countUpdate1.getTotalCount());
			itemsCount.setActivePendingInfras(countUpdate1.getActivePendingCount());
			itemsCount.setActiveApprovedInfras(countUpdate1.getActiveApprovedCount());
			break;
		case TEAM:
			ItemsCountUpdate countUpdate3 = smeDao.getCounts(smeUuid, itemType);
			log.info("Updating TEAM'S Cunts :: {}", countUpdate3);
			itemsCount.setTotalTeams(countUpdate3.getTotalCount());
			itemsCount.setActivePendingTeams(countUpdate3.getActivePendingCount());
			itemsCount.setActiveApprovedTeams(countUpdate3.getActiveApprovedCount());
			break;
		case GALLERY:
			ItemsCountUpdate countUpdate4 = smeDao.getCounts(smeUuid, itemType);
			log.info("Updating GALLERIES ItemCounts :: {}", countUpdate4);
			itemsCount.setTotalGalleries(countUpdate4.getTotalCount());
			itemsCount.setActivePendingGalleries(countUpdate4.getActivePendingCount());
			itemsCount.setActiveApprovedGalleries(countUpdate4.getActiveApprovedCount());
			break;

		default:
			break;
		}

		smeDao.saveSMEWithOutCacheModify(sme);

	}

	@Override
	public void updateItemsCount(String userUuid, String smeUuid, ItemsCountUpdate countUpdate) {

		log.info("Updating ItemsCount From API:: {}", countUpdate);

		SMEInformation sme = getItemsCount(userUuid, smeUuid);
		SMEItemsCount itemsCount = sme.getItemsCount();

		switch (countUpdate.getItemType()) {
		case BUSINESS_POST:
			itemsCount.setTotalBusinessPosts(countUpdate.getTotalCount());
			itemsCount.setActivePendingBusinessPosts(countUpdate.getActivePendingCount());
			itemsCount.setActiveApprovedBusinessPosts(countUpdate.getActiveApprovedCount());
			break;
		case PRODUCT:
			itemsCount.setTotalProducts(countUpdate.getTotalCount());
			itemsCount.setActivePendingProducts(countUpdate.getActivePendingCount());
			itemsCount.setActiveApprovedProducts(countUpdate.getActiveApprovedCount());
			break;
		case SERVICE:
			itemsCount.setTotalServices(countUpdate.getTotalCount());
			itemsCount.setActivePendingServices(countUpdate.getActivePendingCount());
			itemsCount.setActiveApprovedServices(countUpdate.getActiveApprovedCount());
			break;
		case VACANCY:
			itemsCount.setTotalVacancies(countUpdate.getTotalCount());
			itemsCount.setActivePendingVacancies(countUpdate.getActivePendingCount());
			itemsCount.setActiveApprovedVacancies(countUpdate.getActiveApprovedCount());
			break;

		case PRICING:
			itemsCount.setPendingOfflinePaymentVerification(countUpdate.getActivePendingCount());
			break;

		case BI:
			itemsCount.setBiCounts(countUpdate.getTotalCount());
			cacheService.evictSmesCache();
			break;

		default:
			break;
		}

		smeDao.saveSMEWithOutCacheModify(sme);
	}

}
