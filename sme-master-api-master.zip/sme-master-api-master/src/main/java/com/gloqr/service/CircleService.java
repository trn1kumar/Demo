package com.gloqr.service;

import java.util.List;
import java.util.Set;

import com.gloqr.vo.SMEInformationVo;

public interface CircleService {

	List<SMEInformationVo> getCircleSuggestions(String smeUuid, Set<String> excludeSmeUuids, Integer page,
			Integer size);

}
