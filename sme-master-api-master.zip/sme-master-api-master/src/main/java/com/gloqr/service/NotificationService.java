package com.gloqr.service;

import java.util.List;

import com.gloqr.constants.ItemType;
import com.gloqr.dto.SMEInformationDto;
import com.gloqr.entities.SMEInformation;

public interface NotificationService {

	void sendWelcomeNotification(SMEInformationDto sme);

	void sendSmeApprovedNotifi(SMEInformation sme);

	void sendVerificationsSummaryNotification(SMEInformation sme, List<?> smeItems, ItemType itemType);

}
