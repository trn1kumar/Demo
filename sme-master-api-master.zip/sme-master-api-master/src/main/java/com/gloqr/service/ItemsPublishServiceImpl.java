package com.gloqr.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.constants.ItemStatus;
import com.gloqr.dao.CertificateDao;
import com.gloqr.dao.GalleryDao;
import com.gloqr.dao.InfrastructureDao;
import com.gloqr.dao.ManagementTeamDao;
import com.gloqr.dao.SMEDao;
import com.gloqr.entities.Infrastructure;
import com.gloqr.exception.CustomException;
import com.gloqr.model.SMEItemUpdate;

@Service
public class ItemsPublishServiceImpl implements ItemsPublishService {

	@Autowired
	private SMEService smeService;

	@Autowired
	private SMEDao smeDao;

	@Autowired
	private GalleryDao galleryDao;

	@Autowired
	private BusinessPostService businessPostService;

	@Autowired
	private CertificateDao certificateDao;

	@Autowired
	private ManagementTeamDao teamDao;

	@Autowired
	private InfrastructureDao infrastructureDao;

	@Override
	public void updateInfrasStatus(Set<SMEItemUpdate> items, String smeUuid) {
		List<SMEItemUpdate> businessPostedInfras = new ArrayList<>();
		List<String> notUpdatedEntities = new ArrayList<>();
		List<Infrastructure> saveForBatchUpdate = new ArrayList<>();
		Infrastructure existInfra = null;

		for (SMEItemUpdate item : items) {
			boolean status = false;
			String id = item.getId();
			if (item.getSmeAction().equals(ItemStatus.ACTIVE))
				status = true;

			if (smeDao.isSMEHasGivenInfrastructure(smeUuid, id)) {
				existInfra = smeService.getInfrastructure(id);
				if (!(status && existInfra.isActive())) {
					existInfra.setActive(status);
					if (existInfra.isBusinessPost() && !existInfra.isBusinessPostAlreadyActivated() && status) {
						businessPostedInfras.add(item);
						existInfra.setBusinessPostAlreadyActivated(true);
					}
					saveForBatchUpdate.add(existInfra);
				} else {
					notUpdatedEntities.add(id);
				}

			} else {
				notUpdatedEntities.add(id);
			}
		}

		this.actions(businessPostedInfras, saveForBatchUpdate, notUpdatedEntities);

	}

	private void actions(List<SMEItemUpdate> businessPostedInfras, List<Infrastructure> saveForBatchUpdate,
			List<String> notUpdatedEntities) {

		if (!businessPostedInfras.isEmpty()) {
			businessPostService.acitveBusinessPosts(businessPostedInfras);
		}

		if (!saveForBatchUpdate.isEmpty()) {
			infrastructureDao.saveInfras(saveForBatchUpdate);
		}

		if (!notUpdatedEntities.isEmpty()) {
			statusUpdationFailedException(notUpdatedEntities);
		}
	}

	@Override
	public void updateCerificatesStatus(Set<SMEItemUpdate> items, String smeUuid) {
		List<String> notUpdatedEntities = new ArrayList<>();

		for (SMEItemUpdate item : items) {
			String id = item.getId();
			boolean status = false;
			if (item.getSmeAction().equals(ItemStatus.ACTIVE))
				status = true;

			if (smeDao.isSMEHasGivenCertificate(smeUuid, id))
				certificateDao.updateCertificateStatus(id, status);
			else
				notUpdatedEntities.add(id);

		}
		if (!notUpdatedEntities.isEmpty()) {
			statusUpdationFailedException(notUpdatedEntities);
		}
	}

	@Override
	public void updateManagementTeamsStatus(Set<SMEItemUpdate> items, String smeUuid) {

		List<String> notUpdatedEntities = new ArrayList<>();

		for (SMEItemUpdate item : items) {
			String id = item.getId();
			boolean status = false;
			if (item.getSmeAction().equals(ItemStatus.ACTIVE))
				status = true;
			if (smeDao.isSMEHasGivenTeam(smeUuid, id))
				teamDao.updateTeamStatus(id, status);
			else
				notUpdatedEntities.add(id);

		}
		if (!notUpdatedEntities.isEmpty()) {
			statusUpdationFailedException(notUpdatedEntities);
		}
	}

	@Override
	public void updateGalleriesStatus(Set<SMEItemUpdate> items, String smeUuid) {

		List<String> notUpdatedEntities = new ArrayList<>();

		for (SMEItemUpdate item : items) {
			String id = item.getId();
			boolean status = false;
			if (item.getSmeAction().equals(ItemStatus.ACTIVE))
				status = true;
			if (smeDao.isSMEHasGivenGallery(smeUuid, id))
				galleryDao.updateGalleryStatus(id, status);
			else
				notUpdatedEntities.add(id);

		}
		if (!notUpdatedEntities.isEmpty()) {
			statusUpdationFailedException(notUpdatedEntities);
		}

	}

	private void statusUpdationFailedException(List<String> notUpdatedEntities) {
		throw new CustomException("Status updation failed for  " + notUpdatedEntities, HttpStatus.NOT_FOUND);
	}

}
