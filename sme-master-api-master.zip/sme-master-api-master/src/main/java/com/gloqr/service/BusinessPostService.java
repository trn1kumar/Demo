package com.gloqr.service;

import java.util.List;

import com.gloqr.entities.Infrastructure;
import com.gloqr.model.SMEItemUpdate;

public interface BusinessPostService {
	
	public void createBusinessPost(String sUuid,Infrastructure infra);

	public void acitveBusinessPosts(List<SMEItemUpdate> businessPostedInfras);
	
}
