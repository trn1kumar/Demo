package com.gloqr.service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.dao.SMEDao;
import com.gloqr.entities.Address;
import com.gloqr.entities.SMEInformation;
import com.gloqr.mapper.SMEMapper;
import com.gloqr.vo.SMEInformationVo;

@Service
public class CircleServiceImpl implements CircleService {

	@Autowired
	private SMEMapper mapper;

	@Autowired
	private SMEDao smeDao;

	@Override
	public List<SMEInformationVo> getCircleSuggestions(String smeUuid, Set<String> excludeSmeUuids, Integer page,
			Integer size) {
		SMEInformation loggedInSME = smeDao.getSME(smeUuid);
		Address smeAddress = loggedInSME.getSmeAddress();

		excludeSmeUuids.add(smeUuid);
		List<SMEInformation> suggestions = smeDao.getCircleSuggestions(excludeSmeUuids, smeAddress.getLocality(),
				smeAddress.getCity(), page, size);

		return suggestions.parallelStream().map(sme -> mapper.convertToVo(sme)).collect(Collectors.toList());
	}

}
