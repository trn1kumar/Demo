package com.gloqr.service;

import java.util.List;

import com.gloqr.constants.ItemType;
import com.gloqr.entities.Certificate;
import com.gloqr.entities.Gallery;
import com.gloqr.entities.Infrastructure;
import com.gloqr.entities.ManagementTeam;
import com.gloqr.entities.SMEInformation;
import com.gloqr.model.SMEItemUpdate;
import com.gloqr.vo.SMECategoryVo;
import com.gloqr.vo.GloqrAdmin;

public interface GloqrAdminService {

	public GloqrAdmin getSMEs(int page, boolean verified);

	public SMEInformation changeVerifyStatus(String smeUuid, SMECategoryVo categoryVo);

	public void modifySMEItemsState(List<SMEItemUpdate> sneItemUpdates, ItemType itemType);

	public List<Infrastructure> getStatePendingAndActiveTrueInfrastructures(String smeUuid);

	public List<Certificate> getStatePendingAndActiveTrueCertificates(String smeUuid);

	public List<ManagementTeam> getStatePendingAndActiveTrueManagementTeams(String smeUuid);

	public List<Gallery> getStatePendingAndActiveTrueGalleries(String smeUuid);

	public SMEInformation getSME(String smeUuid);

	public List<String> updateImages(String itemType, SMEItemUpdate itemUpdate);

}
