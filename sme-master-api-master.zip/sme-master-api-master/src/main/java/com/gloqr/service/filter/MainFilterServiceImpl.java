package com.gloqr.service.filter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;

import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.hibernate.search.query.engine.spi.FacetManager;
import org.hibernate.search.query.facet.Facet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.gloqr.component.filter.FacetManagerComponent;
import com.gloqr.constants.FilterConstant.FacetConstant;
import com.gloqr.dto.FilterDto;
import com.gloqr.dto.FilterResponse;
import com.gloqr.entities.SMEInformation;
import com.gloqr.model.filter.CategoryFilter;
import com.gloqr.model.filter.CityFilter;
import com.gloqr.util.PaginationUtil;

@Service
public class MainFilterServiceImpl implements MainFilterService {

	@Autowired
	@Qualifier("cityFilter")
	private FilterService cityFilterService;

	@Autowired
	@Qualifier("categoryFilter")
	private FilterService categoryFilterService;

	@Autowired
	@Qualifier("activeSMEFilter")
	private FilterService activeSMEFilterService;

	@Autowired
	@Qualifier("combineFilter")
	private FilterService combineFilterService;

	@Autowired
	private EntityManager entityManager;

	@Autowired
	private FacetManagerComponent facetManagerComponent;

	@Autowired
	private PaginationUtil paginationUtil;

	@Override
	public FilterResponse applyFilter(String searchText, Set<String> categoriesFilterParam,
			Set<String> citiesFilterParam, int page) {

		int maxResult = 0;
		int size = paginationUtil.getPageSize();

		/*
		 * maxResult '20' for sme search result for combine search i.e product and
		 * service, here page always less then 0 '.
		 */
		if (page < 0) {
			maxResult = 20;
			page = 0;
		} else {
			maxResult = size;
		}
		if (page >= 1) {
			--page;
		}

		int firstResult = page * size;

		FilterResponse filterResponse = null;

		if (categoriesFilterParam == null && citiesFilterParam == null) {
			filterResponse = activeSMEFilterService.filter(searchText, null, null, firstResult, maxResult);
		}

		if (categoriesFilterParam != null && citiesFilterParam != null) {
			filterResponse = combineFilterService.filter(searchText, categoriesFilterParam, citiesFilterParam,
					firstResult, maxResult);
		}
		if (categoriesFilterParam != null && citiesFilterParam == null) {
			filterResponse = categoryFilterService.filter(searchText, categoriesFilterParam, null, firstResult,
					maxResult);
		}
		if (categoriesFilterParam == null && citiesFilterParam != null) {
			filterResponse = cityFilterService.filter(searchText, null, citiesFilterParam, firstResult, maxResult);
		}

		return filterResponse;

	}

	@Override
	public FilterDto getInitialFilter() {
		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(SMEInformation.class).get();
		FacetManager facetManager = facetManagerComponent.getFacetManagerForActiveSME(fullTextEntityManager,
				queryBuilder, null);

		List<Facet> cityFacets = facetManager.getFacets(FacetConstant.CITY_FACET);
		List<Facet> categoryFacets = facetManager.getFacets(FacetConstant.CATEGORY_FACET);

		Map<String, Object> filters = getFilter(null, categoryFacets, null, cityFacets);
		return new FilterDto(filters);
	}

	@Override
	public Map<String, Object> getFilter(Set<String> categoriesFilterParam, List<Facet> categoryFacets,
			Set<String> citiesFilterParam, List<Facet> cityFacets) {
		Map<String, Object> filters = new HashMap<>();

		List<CategoryFilter> categoriesFilter = new ArrayList<>();
		categoryFacets.forEach(f -> {
			CategoryFilter categoryFilter = new CategoryFilter(f.getValue(), f.getCount());
			if (categoriesFilterParam != null && categoriesFilterParam.contains(f.getValue()))
				categoryFilter.setSelected(true);
			categoriesFilter.add(categoryFilter);
		});

		List<CityFilter> citiesFilter = new ArrayList<>();
		cityFacets.forEach(f -> {
			CityFilter cityFilter = new CityFilter(f.getValue(), f.getCount());
			if (citiesFilterParam != null && citiesFilterParam.contains(f.getValue()))
				cityFilter.setSelected(true);
			citiesFilter.add(cityFilter);
		});

		// for sort by selected fields
		Collections.sort(categoriesFilter);
		Collections.sort(citiesFilter);
		filters.put("Category", categoriesFilter);
		filters.put("City", citiesFilter);
		return filters;
	}

}
