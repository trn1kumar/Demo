package com.gloqr.service.filter;

import java.util.Set;

import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.query.dsl.QueryBuilder;

import com.gloqr.dto.FilterResponse;

public interface FilterService {

	public FilterResponse filter(String searchText, Set<String> categoriesFilterParam, Set<String> citiesFilterParam,
			int firstResult, int maxResult);

	public FullTextQuery createFullTextQuery(FullTextEntityManager fullTextEntityManager, QueryBuilder queryBuilder,
			String searchText, Set<String> categoriesFilterParam, Set<String> citiesFilterParam);

}
