package com.gloqr.service;

import java.util.List;
import java.util.Set;

import com.gloqr.dto.FilterResponse;

public interface SMESearchService {

	public List<String> getSearchSuggestions(String searchText, int maxResult);

	public FilterResponse getSearchResults(String searchText, Set<String> categoriesFilterParam,
			Set<String> citiesFilterParam, int page);
}
