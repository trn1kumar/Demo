package com.gloqr.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.dao.SMECatogoryDao;
import com.gloqr.entities.SMECategory;

@Service
public class SMECategoryServiceImpl implements SMECategoryService {

	@Autowired
	private SMECatogoryDao smeCatogoryDao;

	@Override
	public void saveCategory(SMECategory category) {
		smeCatogoryDao.saveCategory(category);
	}

	@Override
	public SMECategory getCategory(String categoryUuid) {
		return smeCatogoryDao.getCategoryByUuid(categoryUuid);

	}

	@Override
	public SMECategory getCategoryByUrl(String categoryUrl) {
		return smeCatogoryDao.getCategoryByUrl(categoryUrl);
	}

	@Override
	public List<SMECategory> getAllCategories() {
		return smeCatogoryDao.getSMECategories();
	}

}
