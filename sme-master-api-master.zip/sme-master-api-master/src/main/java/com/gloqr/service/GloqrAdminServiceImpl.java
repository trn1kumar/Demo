package com.gloqr.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Sort;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.DatabaseRetrievalMethod;
import org.hibernate.search.query.ObjectLookupMethod;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gloqr.constants.FilterConstant.SearchFields;
import com.gloqr.constants.ItemState;
import com.gloqr.constants.ItemType;
import com.gloqr.constants.SMEMasterConstants;
import com.gloqr.constants.SMEMasterConstants.BooleanFlag;
import com.gloqr.dao.ImageDao;
import com.gloqr.dao.SMEDao;
import com.gloqr.dto.ImageDto;
import com.gloqr.entities.Certificate;
import com.gloqr.entities.Gallery;
import com.gloqr.entities.Image;
import com.gloqr.entities.Infrastructure;
import com.gloqr.entities.ManagementTeam;
import com.gloqr.entities.SMECategory;
import com.gloqr.entities.SMEInformation;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.SMEMapper;
import com.gloqr.model.SMEItemUpdate;
import com.gloqr.util.PaginationUtil;
import com.gloqr.vo.GloqrAdmin;
import com.gloqr.vo.GloqrSMEVo;
import com.gloqr.vo.SMECategoryVo;

@Service
public class GloqrAdminServiceImpl implements GloqrAdminService {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private SMEService smeService;

	@Autowired
	private SMEMapper mapper;

	@Autowired
	private SMEDao smeDao;

	@Autowired
	private ImageDao imageDao;

	@Autowired
	private SMECategoryService smeCategoryService;

	@Autowired
	private EntityManager entityManager;

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private CountManageService countManageService;

	@Autowired
	private PaginationUtil paginationUtil;

	public static final String DATE_FORMAT = "E, dd MMM yyyy HH:mm:ss";

	@Override
	public GloqrAdmin getSMEs(int page, boolean verified) {

		FullTextQuery fullTextQuery = null;

		if (page < 0)
			page = 0;

		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(SMEInformation.class).get();

		if (verified)
			fullTextQuery = getFullTextQueryForExistingSmes(fullTextEntityManager, queryBuilder);
		else
			fullTextQuery = getFullTextQueryForNewSmes(fullTextEntityManager, queryBuilder);

		fullTextQuery.initializeObjectsWith(ObjectLookupMethod.SECOND_LEVEL_CACHE, DatabaseRetrievalMethod.QUERY);

		fullTextQuery.setFirstResult(page * paginationUtil.getGloqrAdminSmesPageSize());
		fullTextQuery.setMaxResults(paginationUtil.getGloqrAdminSmesPageSize());
		Sort sort = queryBuilder.sort().byField(SearchFields.CREATION_DATE).desc().createSort();
		fullTextQuery.setSort(sort);

		@SuppressWarnings("unchecked")
		List<SMEInformation> smeList = fullTextQuery.getResultList();
		List<GloqrSMEVo> smes = smeList.parallelStream().map(sme -> mapper.convertToDto(sme, GloqrSMEVo.class))
				.collect(Collectors.toList());

		return new GloqrAdmin(fullTextQuery.getResultSize(), smes);

	}

	private FullTextQuery getFullTextQueryForNewSmes(FullTextEntityManager fullTextEntityManager,
			QueryBuilder queryBuilder) {
		Query luceneQuery = queryBuilder.keyword().onField(SearchFields.VERIFIED).matching(false).createQuery();
		return fullTextEntityManager.createFullTextQuery(luceneQuery, SMEInformation.class);
	}

	private FullTextQuery getFullTextQueryForExistingSmes(FullTextEntityManager fullTextEntityManager,
			QueryBuilder queryBuilder) {

		Query query = queryBuilder.bool()
				.must(queryBuilder.keyword().onField(SearchFields.VERIFIED).matching(true).createQuery())
				.must(queryBuilder.range().onField(SearchFields.CERTIFICATES_COUNT).andField(SearchFields.INFRAS_COUNT)
						.andField(SearchFields.TEAMS_COUNT).andField(SearchFields.GALLERIES_COUNT)
						.andField(SearchFields.PRODUCTS_COUNT).andField(SearchFields.SERVICES_COUNT)
						.andField(SearchFields.BPOSTS_COUNT).andField(SearchFields.VACANCIES_COUNT)
						.andField(SearchFields.PAYMENT_VERIFICATION_PENDING).above(1).createQuery())
				.createQuery();
		return fullTextEntityManager.createFullTextQuery(query, SMEInformation.class);
	}

	@Override
	public SMEInformation changeVerifyStatus(String smeUuid, SMECategoryVo categoryVo) {

		SMEInformation sme = smeService.getSME(smeUuid, SMEMasterConstants.BOTH);
		if (categoryVo != null) {
			SMECategory existCategory = smeCategoryService.getCategory(categoryVo.getCategoryUuid());
			sme.setSmeCategory(existCategory);
		}
		sme.setActive(true);
		sme.setVerified(true);
		smeDao.saveSMEWithCacheModify(sme);
		notificationService.sendSmeApprovedNotifi(sme);
		return sme;
	}

	@Override
	public void modifySMEItemsState(List<SMEItemUpdate> sneItemUpdates, ItemType itemType) {
		switch (itemType) {
		case CERTIFICATE:
			approveOrRejectCertificates(sneItemUpdates);
			break;
		case INFRASTRUCTURE:
			approveOrRejectInfrastrutures(sneItemUpdates);
			break;
		case TEAM:
			approveOrRejectManagementTeams(sneItemUpdates);
			break;
		case GALLERY:
			approveOrRejectGalleries(sneItemUpdates);
			break;
		default:
			break;
		}
	}

	private void approveOrRejectCertificates(List<SMEItemUpdate> sneItemUpdates) {
		SMEItemUpdate smeItemUpdate = sneItemUpdates.get(0);
		SMEInformation sme = smeService.getActiveSmeByItemId(smeItemUpdate.getId(), ItemType.CERTIFICATE);

		List<Certificate> batchUpdate = new ArrayList<>();
		for (SMEItemUpdate itemUpdate : sneItemUpdates) {
			this.changeCertificatesState(itemUpdate, batchUpdate);
		}
		if (!batchUpdate.isEmpty()) {
			smeService.saveMultipleCertificates(batchUpdate);
		} else {
			this.throwNotValidDataForChangeStateException();
		}

		notificationService.sendVerificationsSummaryNotification(sme, batchUpdate, ItemType.CERTIFICATE);
		countManageService.updateItemsCount(sme.getsUuid(), ItemType.CERTIFICATE);

	}

	private void changeCertificatesState(SMEItemUpdate itemUpdate, List<Certificate> batchUpdate) {
		String certificateId = itemUpdate.getId();
		ItemState state = itemUpdate.getState();
		try {

			Certificate certificate = smeService.getCertificate(certificateId);
			if (certificate.isActive() && certificate.getItemState().equals(ItemState.PENDING)) {
				certificate.setItemState(state);
				if (state.equals(ItemState.REJECTED)) {
					certificate.setActive(BooleanFlag.FALSE);
				}
				if (itemUpdate.getFeedbackMessage() != null) {
					String dateAndAction = "[ Date:-" + new SimpleDateFormat(DATE_FORMAT).format(new Date())
							+ " Action:-" + state + " ] ";
					itemUpdate.setFeedbackMessage(dateAndAction.concat(itemUpdate.getFeedbackMessage()));

					if (certificate.getFeedbackMessage() != null) {
						certificate.setFeedbackMessage(
								certificate.getFeedbackMessage().concat(".| " + itemUpdate.getFeedbackMessage()));
					} else {
						certificate.setFeedbackMessage(itemUpdate.getFeedbackMessage());
					}

				}
				batchUpdate.add(certificate);
			}
		} catch (CustomException e) {
			log.error("Exception:: message:- {}", e.getErrorMessage());
		}
	}

	private void approveOrRejectManagementTeams(List<SMEItemUpdate> sneItemUpdates) {
		SMEItemUpdate smeItemUpdate = sneItemUpdates.get(0);
		SMEInformation sme = smeService.getActiveSmeByItemId(smeItemUpdate.getId(), ItemType.TEAM);
		List<ManagementTeam> batchUpdate = new ArrayList<>();
		for (SMEItemUpdate itemUpdate : sneItemUpdates) {
			this.changeTeamsState(itemUpdate, batchUpdate);
		}
		if (!batchUpdate.isEmpty()) {
			smeService.saveMultipleTeams(batchUpdate);
		} else {
			this.throwNotValidDataForChangeStateException();
		}
		notificationService.sendVerificationsSummaryNotification(sme, batchUpdate, ItemType.TEAM);
		countManageService.updateItemsCount(sme.getsUuid(), ItemType.TEAM);
	}

	private void changeTeamsState(SMEItemUpdate itemUpdate, List<ManagementTeam> batchUpdate) {

		String teamId = itemUpdate.getId();
		ItemState state = itemUpdate.getState();
		try {
			ManagementTeam team = smeService.getManagementTeam(teamId);
			if (team.isActive() && team.getItemState().equals(ItemState.PENDING)) {
				team.setItemState(state);
				if (state.equals(ItemState.REJECTED)) {
					team.setActive(BooleanFlag.FALSE);
				}
				if (itemUpdate.getFeedbackMessage() != null) {
					String dateAndAction = "[ Date:-" + new SimpleDateFormat(DATE_FORMAT).format(new Date())
							+ " Action:-" + state + " ] ";
					itemUpdate.setFeedbackMessage(dateAndAction.concat(itemUpdate.getFeedbackMessage()));

					if (team.getFeedbackMessage() != null) {
						team.setFeedbackMessage(
								team.getFeedbackMessage().concat("| " + itemUpdate.getFeedbackMessage()));
					} else {
						team.setFeedbackMessage(itemUpdate.getFeedbackMessage());
					}

				}
				batchUpdate.add(team);
			}

		} catch (CustomException e) {
			log.error("Exception:: message:- {}", e.getErrorMessage());
		}
	}

	private void approveOrRejectInfrastrutures(List<SMEItemUpdate> sneItemUpdates) {
		SMEItemUpdate smeItemUpdate = sneItemUpdates.get(0);
		SMEInformation sme = smeService.getActiveSmeByItemId(smeItemUpdate.getId(), ItemType.INFRASTRUCTURE);

		List<Infrastructure> batchUpdate = new ArrayList<>();

		for (SMEItemUpdate itemUpdate : sneItemUpdates) {
			this.changeInfrasState(itemUpdate, batchUpdate);
		}
		if (!batchUpdate.isEmpty()) {
			smeService.saveMultipleInfras(batchUpdate);
		} else {
			this.throwNotValidDataForChangeStateException();
		}
		notificationService.sendVerificationsSummaryNotification(sme, batchUpdate, ItemType.INFRASTRUCTURE);
		countManageService.updateItemsCount(sme.getsUuid(), ItemType.INFRASTRUCTURE);

	}

	private void changeInfrasState(SMEItemUpdate itemUpdate, List<Infrastructure> batchUpdate) {

		String infraId = itemUpdate.getId();
		ItemState state = itemUpdate.getState();
		try {
			Infrastructure infra = smeService.getInfrastructure(infraId);
			if (infra.isActive() && infra.getItemState().equals(ItemState.PENDING)) {
				infra.setItemState(state);
				if (state.equals(ItemState.REJECTED)) {
					infra.setActive(BooleanFlag.FALSE);
				}
				if (itemUpdate.getFeedbackMessage() != null) {
					String dateAndAction = "[ Date:-" + new SimpleDateFormat(DATE_FORMAT).format(new Date())
							+ " Action:-" + state + " ] ";
					itemUpdate.setFeedbackMessage(dateAndAction.concat(itemUpdate.getFeedbackMessage()));

					if (infra.getFeedbackMessage() != null) {
						infra.setFeedbackMessage(
								infra.getFeedbackMessage().concat("| " + itemUpdate.getFeedbackMessage()));
					} else {
						infra.setFeedbackMessage(itemUpdate.getFeedbackMessage());
					}

				}
				batchUpdate.add(infra);
			}

		} catch (CustomException e) {
			log.error("Exception:: message:- {}", e.getErrorMessage());
		}
	}

	private void approveOrRejectGalleries(List<SMEItemUpdate> sneItemUpdates) {
		SMEItemUpdate smeItemUpdate = sneItemUpdates.get(0);
		SMEInformation sme = smeService.getActiveSmeByItemId(smeItemUpdate.getId(), ItemType.GALLERY);

		List<Gallery> batchUpdate = new ArrayList<>();
		for (SMEItemUpdate itemUpdate : sneItemUpdates) {
			this.changeGalleriesState(itemUpdate, batchUpdate);
		}

		if (!batchUpdate.isEmpty()) {
			smeService.saveMultipleGalleries(batchUpdate);
		} else {
			this.throwNotValidDataForChangeStateException();
		}

		notificationService.sendVerificationsSummaryNotification(sme, batchUpdate, ItemType.GALLERY);
		countManageService.updateItemsCount(sme.getsUuid(), ItemType.GALLERY);
	}

	private void changeGalleriesState(SMEItemUpdate itemUpdate, List<Gallery> batchUpdate) {
		try {
			ItemState state = itemUpdate.getState();
			String galleryId = itemUpdate.getId();
			Gallery gallery = smeService.getGallery(galleryId);
			if (gallery.isActive() && gallery.getItemState().equals(ItemState.PENDING)) {
				gallery.setItemState(state);
				if (state.equals(ItemState.REJECTED)) {
					gallery.setActive(BooleanFlag.FALSE);
				}
				if (itemUpdate.getFeedbackMessage() != null) {
					String dateAndAction = "[ Date:-" + new SimpleDateFormat(DATE_FORMAT).format(new Date())
							+ " Action:-" + state + " ] ";
					itemUpdate.setFeedbackMessage(dateAndAction.concat(itemUpdate.getFeedbackMessage()));

					if (gallery.getFeedbackMessage() != null) {
						gallery.setFeedbackMessage(
								gallery.getFeedbackMessage().concat("| " + itemUpdate.getFeedbackMessage()));
					} else {
						gallery.setFeedbackMessage(itemUpdate.getFeedbackMessage());
					}

				}
				batchUpdate.add(gallery);
			}

		} catch (CustomException e) {
			log.error("Exception:: message:- {}", e.getErrorMessage());
		}
	}

	@Override
	public List<Infrastructure> getStatePendingAndActiveTrueInfrastructures(String smeUuid) {
		List<Infrastructure> infras = null;
		if (smeDao.isSMEExist(smeUuid)) {
			infras = smeDao.getInfrasBySmeUuidAndStateAndActive(smeUuid, ItemState.PENDING, BooleanFlag.TRUE);
		} else {
			this.throwSmeNotFoundException(smeUuid);
		}

		return infras;
	}

	@Override
	public List<Certificate> getStatePendingAndActiveTrueCertificates(String smeUuid) {
		List<Certificate> certificates = null;
		if (smeDao.isSMEExist(smeUuid)) {
			certificates = smeDao.getCertificatesBySmeUuidAndStateAndActive(smeUuid, ItemState.PENDING,
					BooleanFlag.TRUE);
		} else {
			this.throwSmeNotFoundException(smeUuid);
		}

		return certificates;
	}

	@Override
	public List<ManagementTeam> getStatePendingAndActiveTrueManagementTeams(String smeUuid) {
		List<ManagementTeam> teams = null;
		if (smeDao.isSMEExist(smeUuid)) {
			teams = smeDao.getTeamsBySmeUuidAndStateAndActive(smeUuid, ItemState.PENDING, BooleanFlag.TRUE);
		} else {
			this.throwSmeNotFoundException(smeUuid);
		}

		return teams;
	}

	@Override
	public List<Gallery> getStatePendingAndActiveTrueGalleries(String smeUuid) {
		List<Gallery> galleries = null;
		if (smeDao.isSMEExist(smeUuid)) {
			galleries = smeDao.getGalleriesBySmeUuidAndStateAndActive(smeUuid, ItemState.PENDING, BooleanFlag.TRUE);
		} else {
			this.throwSmeNotFoundException(smeUuid);
		}

		return galleries;
	}

	private void throwSmeNotFoundException(String smeUuid) {
		throw new CustomException("SME not present with id " + smeUuid, HttpStatus.NOT_FOUND);
	}

	private void throwNotValidDataForChangeStateException() {
		throw new CustomException("No valid data selection for change state", HttpStatus.BAD_REQUEST);
	}

	@Override
	public SMEInformation getSME(String smeUuid) {
		return smeDao.getSMEWithOutCache(smeUuid);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public List<String> updateImages(String itemType, SMEItemUpdate itemUpdate) {
		List<String> deleteContentServerImgs = null;
		List<ImageDto> imgDtos = itemUpdate.getImages();

		if (!(imgDtos != null && !imgDtos.isEmpty()))
			throw new CustomException("Images can't be null or empty", HttpStatus.BAD_REQUEST);

		if (itemType != null && itemType.equals(SMEMasterConstants.SLIDER_IMAGES)) {
			SMEInformation sme = smeDao.getSMEWithOutCache(itemUpdate.getId());
			deleteContentServerImgs = manageImages(sme.getHomeSliderImages(), imgDtos);
			smeDao.saveSMEWithCacheModify(sme);
		} else if (itemType != null && itemType.equals("other")) {
			Set<String> imageUuids = imgDtos.stream().map(ImageDto::getImgUuid).collect(Collectors.toSet());
			List<Image> existImgs = imageDao.getMultipleImagesIn(imageUuids);
			deleteContentServerImgs = manageImages(existImgs, imgDtos);
			imageDao.saveMultipleImages(existImgs);
		}

		return deleteContentServerImgs;
	}

	private List<String> manageImages(List<Image> existImgs, List<ImageDto> imgDtos) {

		List<String> deleteContentServerImgs = new ArrayList<>();

		for (Image existImg : existImgs) {

			Optional<ImageDto> imgDtoOpt = imgDtos.parallelStream()
					.filter(imgDto -> existImg.getImgUuid().equals(imgDto.getImgUuid())).findFirst();

			if (imgDtoOpt.isPresent()) {
				ImageDto imgDto = imgDtoOpt.get();

				if (imgDto.getImageLocationOne() != null) {
					if (isLocationUpdated(existImg.getImageLocation(), existImg.getImageLocationOne(),
							imgDto.getImageLocationOne(), deleteContentServerImgs))
						existImg.setImageLocationOne(imgDto.getImageLocationOne());
				} else {
					if (existImg.getImageLocationOne() != null
							&& !existImg.getImageLocation().equals(existImg.getImageLocationOne()))
						deleteContentServerImgs.add(existImg.getImageLocationOne());
					existImg.setImageLocationOne(existImg.getImageLocation());
				}

				if (imgDto.getImageLocationTwo() != null) {
					if (isLocationUpdated(existImg.getImageLocation(), existImg.getImageLocationTwo(),
							imgDto.getImageLocationTwo(), deleteContentServerImgs))
						existImg.setImageLocationTwo(imgDto.getImageLocationTwo());

				} else {
					if (existImg.getImageLocationTwo() != null
							&& !existImg.getImageLocation().equals(existImg.getImageLocationTwo()))
						deleteContentServerImgs.add(existImg.getImageLocationTwo());
					existImg.setImageLocationTwo(existImg.getImageLocation());
				}
			}

		}

		return deleteContentServerImgs;

	}

	private boolean isLocationUpdated(String existLocation, String existLocation1, String newLocation,
			List<String> deleteContentServerImgs) {
		if (!(newLocation.equals(existLocation) || newLocation.equals(existLocation1))) {

			if (!existLocation.equals(existLocation1)) {
				deleteContentServerImgs.add(existLocation1);
			}
			imageDao.deleteByImageLocation(newLocation);
			return true;
		}
		return false;
	}

}
