package com.gloqr.service;

import java.util.Set;

import org.springframework.transaction.annotation.Transactional;

import com.gloqr.model.SMEItemUpdate;

@Transactional(rollbackFor = Exception.class)
public interface ItemsPublishService {

	void updateCerificatesStatus(Set<SMEItemUpdate> subEntities, String smeUuid);

	void updateManagementTeamsStatus(Set<SMEItemUpdate> subEntities, String smeUuid);

	void updateInfrasStatus(Set<SMEItemUpdate> subEntities, String smeUuid);

	public void updateGalleriesStatus(Set<SMEItemUpdate> subEntities, String smeUuid);

}
