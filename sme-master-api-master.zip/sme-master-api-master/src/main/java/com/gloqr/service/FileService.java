package com.gloqr.service;

import java.util.List;
import java.util.Set;

import org.springframework.web.multipart.MultipartFile;

import com.gloqr.entities.Image;

public interface FileService {

	// send file to content server
	public List<Image> sendFilesToContentServer(List<MultipartFile> files, String fileLocation);

	public List<Image> saveAndSendFilesToContentServer(List<MultipartFile> files, String fileLocation);

	public void deleteFileFromContentServer(String fileLocation);

	public void updateImagesByBusinessPostFalse(Set<String> imageLocations);

}
