package com.gloqr.service;

import com.gloqr.model.AuthToken;

public interface UserService {

	public AuthToken updateUserTypeAndGetNewToken(String uuid, String sUuid);
}
