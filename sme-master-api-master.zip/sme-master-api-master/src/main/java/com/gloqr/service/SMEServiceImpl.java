package com.gloqr.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gloqr.constants.CreditType;
import com.gloqr.constants.ItemState;
import com.gloqr.constants.ItemType;
import com.gloqr.constants.SMEMasterConstants;
import com.gloqr.constants.SMEMasterConstants.BooleanFlag;
import com.gloqr.dao.CertificateDao;
import com.gloqr.dao.GalleryDao;
import com.gloqr.dao.ImageDao;
import com.gloqr.dao.InfrastructureDao;
import com.gloqr.dao.ManagementTeamDao;
import com.gloqr.dao.SMEDao;
import com.gloqr.dto.count.EditModeItemsPercentage;
import com.gloqr.entities.Address;
import com.gloqr.entities.Certificate;
import com.gloqr.entities.Gallery;
import com.gloqr.entities.Image;
import com.gloqr.entities.Infrastructure;
import com.gloqr.entities.ManagementTeam;
import com.gloqr.entities.SMECategory;
import com.gloqr.entities.SMEInformation;
import com.gloqr.entities.SMEItemsCount;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.SMEMapper;
import com.gloqr.model.AuthToken;
import com.gloqr.model.PricingRequest;
import com.gloqr.rest.endpoint.PricingEndpoint;
import com.gloqr.util.CopyValuesUtil;
import com.gloqr.util.UuidUtil;
import com.gloqr.vo.SMEInformationVo;
import com.gloqr.vo.SmeSubEntitiesCount;

@Service(value = "smeService")
public class SMEServiceImpl implements SMEService {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private SMEDao smeDao;

	@Autowired
	private SMEMapper mapper;

	@Autowired
	private InfrastructureDao infrastructureDao;

	@Autowired
	private CertificateDao certificateDao;

	@Autowired
	private ManagementTeamDao teamDao;

	@Autowired
	private GalleryDao galleryDao;

	@Autowired
	private UserService userService;

	@Autowired
	private SMECategoryService smeCategoryService;

	@Autowired
	private BusinessPostService businessPostService;

	@Autowired
	private PricingEndpoint pricingEndpoint;

	@Autowired
	private ImageDao imageDao;

	private static final String DEBIT = "DEBIT";
	private static final String CREDIT = "CREDIT";

	@Override
	@Transactional(rollbackFor = Exception.class, readOnly = false)
	public AuthToken saveSme(SMECategory smeCategory) {

		SMEInformation sme = null;
		AuthToken refreshSMEToken = null;

		// save first step details
		sme = smeCategory.getSmes().get(0);
		if (smeDao.isSMEExistByUuid(sme.getUuid()))
			throw new CustomException("Existing SME Found Related to User " + sme.getUuid(), HttpStatus.BAD_REQUEST);

		if (this.isGSTINNumberExist(sme.getGstin()))
			throw new CustomException("GSTIN Number Already Present", HttpStatus.BAD_REQUEST);

		// set universal uuid and save
		sme.setsUuid(UuidUtil.getUuid(sme.getSmeName()));
		sme.getSmeAddress().setAddrsUuid(UuidUtil.getUuid());
		sme.getSmeAddress().setSmeInformation(sme);
		if (smeCategory.getCategoryUuid() != null) {
			SMECategory existCategory = smeCategoryService.getCategory(smeCategory.getCategoryUuid());
			sme.setSmeCategory(existCategory);
		} else {
			sme.setSmeCategory(null);
		}
		sme.setItemsCount(new SMEItemsCount());

		smeDao.saveSMEWithOutCacheModify(sme);

		refreshSMEToken = userService.updateUserTypeAndGetNewToken(sme.getUuid(), sme.getsUuid());
		refreshSMEToken.setsUuid(sme.getsUuid());

		return refreshSMEToken;
	}

	@Override
	@Transactional(rollbackFor = Exception.class, readOnly = false)
	public SMEInformation saveSMEDetails(SMEInformation sme) {

		// save second step details
		SMEInformation smeInfo = smeDao.getSMEWithOutCache(sme.getsUuid());
		/*
		 * set boolean value explicitly. other values automatically copy by
		 * copyNonNullProperties() method
		 */
		sme.setAcceptedTermsCondition(smeInfo.isAcceptedTermsCondition());
		CopyValuesUtil.copyNonNullProperties(sme, smeInfo);
		return smeDao.saveSMEWithCacheModify(smeInfo);
	}

	@Override
	@Transactional(rollbackFor = Exception.class, readOnly = false)
	public SMEInformation updateSme(SMEInformation sme) {

		if (sme.getsUuid() != null) {
			SMEInformation existSme = smeDao.getSMEWithOutCache(sme.getsUuid());
			sme.setSmeId(existSme.getSmeId());
			sme.setUuid(existSme.getUuid());
			sme.setSmeCategory(existSme.getSmeCategory());
			sme.setYearOfEstablishment(existSme.getYearOfEstablishment());
			sme.setOtherCategory(existSme.getOtherCategory());
			sme.setHomeSliderImages(existSme.getHomeSliderImages());
			sme.setActive(existSme.isActive());
			sme.setSmeAddress(existSme.getSmeAddress());
			sme.setItemsCount(existSme.getItemsCount());
			sme.setVerified(existSme.isVerified());
			sme.setLogoImage(existSme.getLogoImage());
			sme.setAcceptedTermsCondition(existSme.isAcceptedTermsCondition());
			if (sme.getTurnOver() != null && existSme.getTurnOver() != null) {
				sme.getTurnOver().setTrunOverId(existSme.getTurnOver().getTrunOverId());
			} else if (sme.getTurnOver() == null) {
				smeDao.deleteTurnOver(existSme.getTurnOver());
			}

			sme = smeDao.saveSMEWithCacheModify(sme);
		} else {
			throw new CustomException("sme id can not be null.Updation failed.", HttpStatus.BAD_REQUEST);
		}

		return sme;
	}

	@Override
	public Address updateSmeAddress(String smeUuid, Address address) {
		if (address.getAddrsUuid() != null) {

			SMEInformation sme = this.getSME(smeUuid, SMEMasterConstants.BOTH);
			Address existAddress = sme.getSmeAddress();
			if (existAddress.getAddrsUuid().equals(address.getAddrsUuid())) {
				address.setAddressId(existAddress.getAddressId());
				sme.setSmeAddress(address);
				// for update SME Document index for hibernate/facet search
				address.setSmeInformation(sme);
				smeDao.saveSMEWithCacheModify(sme);
			} else {
				throwUnauthorizedException("address", smeUuid);
			}

		} else {
			throw new CustomException("Address Id can not be null", HttpStatus.BAD_REQUEST);
		}
		return address;
	}

	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public void saveOrUpdateSliderImages(String smeUuid, List<Image> images) {
		PricingRequest pricingRequest = null;

		SMEInformation sme = smeDao.getSME(smeUuid);
		List<Image> existImages = sme.getHomeSliderImages();
		if (images != null && !images.isEmpty())
			images = imageDao.getImages(images);
		else
			sme.setHomeSliderImages(null);

		pricingRequest = this.manageImages(sme, existImages, images);
		smeDao.saveSMEWithCacheModify(sme);

		if (pricingRequest != null) {
			pricingRequest.setUsedFor("Sliders image modification");
			pricingEndpoint.updateCredits(pricingRequest);
		}

	}

	@Override
	@Caching(evict = { @CacheEvict(value = { "smes" }, allEntries = true),
			@CacheEvict(value = "smedetails", key = "#smeUuid") })
	public String changeLogoImage(String smeUuid, String newImageLocation) {

		String existImageLocation = smeDao.getExistImageLocation(smeUuid);
		smeDao.updateSMELogoImgLocation(smeUuid, newImageLocation);
		return existImageLocation;
	}

	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public void saveInfrastructure(Infrastructure infrastructure, String smeUuid) {

		long totalFileSize = 0;

		infrastructure.setItemState(ItemState.PENDING);
		infrastructure.setInfraUuid(UuidUtil.getUuid(infrastructure.getMachineName()));
		if (infrastructure.getImages() != null) {
			List<Image> imgs = imageDao.getImages(infrastructure.getImages());
			totalFileSize = getImagesTotalSize(imgs);

			if (pricingEndpoint.checkCredits(CreditType.IMAGE_STORAGE) < totalFileSize) {
				pricingEndpoint.noCreditsLeftException(CreditType.IMAGE_STORAGE);
			}
			infrastructure.setImages(imgs);
		}

		SMEInformation existSme = smeDao.getSMEWithOutCache(smeUuid);
		existSme.getInfrastructures().add(infrastructure);
		smeDao.saveSMEWithOutCacheModify(existSme);

		if (infrastructure.isBusinessPost()) {
			try {

				businessPostService.createBusinessPost(smeUuid, infrastructure);
				// business post image true updated with in transaction
				if (infrastructure.getImages() != null) {
					infrastructure.getImages().forEach(img -> img.setBusinessPostImage(true));
				}
				if (infrastructure.isActive()) {
					infrastructureDao.updateBusinessPostAlreadyActivatedByTrue(infrastructure.getInfraUuid());
				}

			} catch (Exception e) {
				log.log(Level.ERROR, e);
				infrastructureDao.updateBusinessPostByFalse(infrastructure.getInfraUuid());

			}

		}

		if (totalFileSize > 0)
			pricingEndpoint.updateCredits(CreditType.IMAGE_STORAGE, totalFileSize, DEBIT, "Infrastructure Added");

	}

	@Override
	@Transactional(rollbackFor = Exception.class, readOnly = false)
	public void updateInfrastructure(Infrastructure infrastructure, String smeUuid) {

		List<Image> updatedImages = null;
		List<Image> existImages = null;
		PricingRequest pricingRequest = null;
		if (infrastructure.getInfraUuid() == null) {
			throw new CustomException("infrastructure uuid can not be null.updation failed", HttpStatus.BAD_REQUEST);
		}

		if (!smeDao.isSMEHasGivenInfrastructure(smeUuid, infrastructure.getInfraUuid())) {
			throwUnauthorizedException("infrastructure", smeUuid);
		}

		Infrastructure existInfra = this.getInfrastructure(infrastructure.getInfraUuid());
		if (existInfra.isActive()) {
			throw new CustomException("Infrastructure is in Active Status. couldn't update", HttpStatus.BAD_REQUEST);
		}

		infrastructure.setId(existInfra.getId());
		infrastructure.setBusinessPost(existInfra.isBusinessPost());
		infrastructure.setBusinessPostAlreadyActivated(existInfra.isBusinessPostAlreadyActivated());
		infrastructure.setItemState(ItemState.PENDING);
		infrastructure.setFeedbackMessage(existInfra.getFeedbackMessage());
		infrastructure.setInfraModified(true);
		if (infrastructure.getImages() != null && !infrastructure.getImages().isEmpty())
			updatedImages = imageDao.getImages(infrastructure.getImages());
		existImages = existInfra.getImages();

		pricingRequest = this.manageImages(infrastructure, existImages, updatedImages);

		infrastructureDao.saveInfrastructure(infrastructure);
		if (pricingRequest != null) {
			pricingRequest.setUsedFor("Infrastructure image updation");
			pricingEndpoint.updateCredits(pricingRequest);
		}

	}

	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public void saveManagementTeams(List<ManagementTeam> teams, String smeUuid) {

		long totalImageSize = 0;

		for (ManagementTeam manageTeam : teams) {
			manageTeam.setItemState(ItemState.PENDING);
			manageTeam.setTeamUuid(UuidUtil.getUuid(manageTeam.getFullName()));
			if (manageTeam.getProfileImageUrl() != null) {
				Image image = imageDao.getImageByImageLocation(manageTeam.getProfileImageUrl());
				totalImageSize += image.getSize();
				image.setActive(true);
				manageTeam.setProfileImage(image);
			}

		}
		if (totalImageSize > 0 && pricingEndpoint.checkCredits(CreditType.IMAGE_STORAGE) < totalImageSize) {
			pricingEndpoint.noCreditsLeftException(CreditType.IMAGE_STORAGE);
		}

		SMEInformation existSme = smeDao.getSMEWithOutCache(smeUuid);
		existSme.getManagementTeams().addAll(teams);

		smeDao.saveSMEWithOutCacheModify(existSme);

		if (totalImageSize > 0) {
			pricingEndpoint.updateCredits(CreditType.IMAGE_STORAGE, totalImageSize, DEBIT, "Management Team Added");
		}

	}

	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public void updateManagementTeam(ManagementTeam team, String smeUuid) {

		PricingRequest pricingRequest = null;
		Image newImage = null;
		long existImageSize = 0;
		long newImageSize = 0;
		int existImageCount = 0;
		int newImageCount = 0;
		if (team.getTeamUuid() == null) {
			throw new CustomException("management team uuid can not be null.updation failed", HttpStatus.BAD_REQUEST);
		}

		if (!smeDao.isSMEHasGivenTeam(smeUuid, team.getTeamUuid())) {
			throwUnauthorizedException("management team", smeUuid);
		}

		ManagementTeam existTeam = this.getManagementTeam(team.getTeamUuid());
		if (existTeam.isActive()) {
			throw new CustomException("Management Team in Active Status. couldn't update", HttpStatus.BAD_REQUEST);
		}

		Image existImage = existTeam.getProfileImage();
		String newProfileImgUrl = team.getProfileImageUrl();

		if (!newProfileImgUrl.equals(existImage.getImageLocation())) {
			// manage new image
			newImage = imageDao.getImageByImageLocation(newProfileImgUrl);
			newImageSize = newImage.getSize();
			newImage.setActive(true);
			++newImageCount;

			// manage exist image
			existImage.setActive(false);
			imageDao.saveImage(existImage);
			existImageSize = existImage.getSize();
			++existImageCount;
			team.setProfileImage(newImage);

			pricingRequest = getPricingRequestObj(newImageCount, existImageCount, existImageSize, newImageSize);
		} else {
			team.setProfileImage(existImage);
		}

		team.setTeamId(existTeam.getTeamId());
		team.setItemState(ItemState.PENDING);
		team.setFeedbackMessage(existTeam.getFeedbackMessage());
		team.setTeamModified(true);
		teamDao.saveTeam(team);

		if (pricingRequest != null) {
			pricingRequest.setUsedFor("Team Updated");
			pricingEndpoint.updateCredits(pricingRequest);
		}

	}

	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public void saveCertificates(List<Certificate> certificates, String smeUuid) {

		long totalFileSize = 0;

		for (Certificate newCertificate : certificates) {

			newCertificate.setItemState(ItemState.PENDING);
			newCertificate.setCrtiUuid(UuidUtil.getUuid());
			if (newCertificate.getImages() != null) {
				List<Image> imgs = imageDao.getImages(newCertificate.getImages());
				totalFileSize += getImagesTotalSize(imgs);
				newCertificate.setImages(imgs);
			}

		}

		if (totalFileSize > 0 && pricingEndpoint.checkCredits(CreditType.IMAGE_STORAGE) < totalFileSize) {
			pricingEndpoint.noCreditsLeftException(CreditType.IMAGE_STORAGE);
		}

		SMEInformation existSme = smeDao.getSMEWithOutCache(smeUuid);
		existSme.getCertificates().addAll(certificates);
		smeDao.saveSMEWithOutCacheModify(existSme);

		if (totalFileSize > 0) {
			pricingEndpoint.updateCredits(CreditType.IMAGE_STORAGE, totalFileSize, DEBIT, "Certificate Added");
		}

	}

	@Override
	public void updateCertificate(Certificate certificate, String smeUuid) {

		List<Image> updatedImages = null;
		List<Image> existImages = null;
		PricingRequest pricingRequest = null;
		if (certificate.getCrtiUuid() == null) {
			throw new CustomException("certificate uuid can not be null.updation failed", HttpStatus.BAD_REQUEST);
		}

		if (!smeDao.isSMEHasGivenCertificate(smeUuid, certificate.getCrtiUuid())) {
			throwUnauthorizedException("certificate", smeUuid);
		}

		Certificate existCertificate = this.getCertificate(certificate.getCrtiUuid());

		if (existCertificate.isActive()) {
			throw new CustomException("Certificate in Active Status. couldn't update", HttpStatus.BAD_REQUEST);
		}

		certificate.setId(existCertificate.getId());
		certificate.setItemState(ItemState.PENDING);
		certificate.setCertificateModified(true);
		certificate.setFeedbackMessage(existCertificate.getFeedbackMessage());

		if (certificate.getImages() != null && !certificate.getImages().isEmpty())
			updatedImages = imageDao.getImages(certificate.getImages());
		existImages = existCertificate.getImages();
		pricingRequest = this.manageImages(certificate, existImages, updatedImages);
		certificateDao.saveCertificate(certificate);
		if (pricingRequest != null) {
			pricingRequest.setUsedFor("Certificate images modification");
			pricingEndpoint.updateCredits(pricingRequest);
		}

	}

	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public void saveGalleries(List<Gallery> galleryList, String smeUuid) {

		long totalFileSize = 0;
		for (Gallery newGallery : galleryList) {
			newGallery.setItemState(ItemState.PENDING);
			newGallery.setGalleryUuid(UuidUtil.getUuid());
			if (newGallery.getImages() != null) {
				List<Image> imgs = imageDao.getImages(newGallery.getImages());
				totalFileSize += getImagesTotalSize(imgs);
				newGallery.setImages(imgs);
			}
		}
		if (totalFileSize > 0 && pricingEndpoint.checkCredits(CreditType.IMAGE_STORAGE) < totalFileSize) {
			pricingEndpoint.noCreditsLeftException(CreditType.IMAGE_STORAGE);
		}

		SMEInformation existSme = smeDao.getSMEWithOutCache(smeUuid);
		existSme.getGalleries().addAll(galleryList);

		smeDao.saveSMEWithOutCacheModify(existSme);

		if (totalFileSize > 0) {
			pricingEndpoint.updateCredits(CreditType.IMAGE_STORAGE, totalFileSize, DEBIT, "Gallery Added");
		}

	}

	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public void updateGallery(Gallery gallery, String smeUuid) {

		List<Image> updatedImages = null;
		List<Image> existImages = null;
		PricingRequest pricingRequest = null;
		if (gallery.getGalleryUuid() == null) {
			throw new CustomException("gallery uuid can not be null.updation failed", HttpStatus.BAD_REQUEST);
		}

		if (!smeDao.isSMEHasGivenGallery(smeUuid, gallery.getGalleryUuid())) {
			throwUnauthorizedException("gallery", smeUuid);
		}

		Gallery existGallery = this.getGallery(gallery.getGalleryUuid());
		if (existGallery.isActive()) {
			throw new CustomException("Gallery in Active Status. couldn't update", HttpStatus.BAD_REQUEST);
		}

		gallery.setGalleryId(existGallery.getGalleryId());
		gallery.setItemState(ItemState.PENDING);
		gallery.setGalleryModified(true);
		gallery.setFeedbackMessage(existGallery.getFeedbackMessage());

		if (gallery.getImages() != null && !gallery.getImages().isEmpty())
			updatedImages = imageDao.getImages(gallery.getImages());
		existImages = existGallery.getImages();
		pricingRequest = this.manageImages(gallery, existImages, updatedImages);

		galleryDao.saveGallery(gallery);

		if (pricingRequest != null) {
			pricingRequest.setUsedFor("Gallery image modification");
			pricingEndpoint.updateCredits(pricingRequest);
		}

	}

	public Address getSmeAddress(String smeUuid) {
		SMEInformation info = this.getSME(smeUuid, SMEMasterConstants.BOTH);
		if (info.getSmeAddress() != null)
			return info.getSmeAddress();
		else
			throw new CustomException("SME " + smeUuid + " Don't have any address", HttpStatus.NO_CONTENT);
	}

	@Override
	public List<Infrastructure> getAllInfrastructure(String smeUuid, String status) {

		List<Infrastructure> infras = null;

		if (status == null) {
			infras = smeDao.getInfrastructures(smeUuid);
		} else {
			switch (status) {
			case SMEMasterConstants.ACTIVE:
				infras = smeDao.getInfrastructuresByActive(smeUuid, true);
				break;
			case SMEMasterConstants.DEACTIVE:
				infras = smeDao.getInfrastructuresByActive(smeUuid, false);
				break;
			default:
				throw new CustomException(
						"Exception in :: getAllInfrastructure()." + status + " is invalid status choice",
						HttpStatus.BAD_REQUEST);

			}

		}
		return infras;

	}

	@Override
	public List<Certificate> getAllCertificate(String smeUuid, String status) {
		List<Certificate> certificates = null;

		if (status == null) {
			certificates = smeDao.getCertificates(smeUuid);
		} else {

			switch (status) {
			case SMEMasterConstants.ACTIVE:
				certificates = smeDao.getCertificatesByActive(smeUuid, true);
				break;

			case SMEMasterConstants.DEACTIVE:
				certificates = smeDao.getCertificatesByActive(smeUuid, false);
				break;
			default:
				throw new CustomException("Exception in :: getAllCertificate().Invalid status selection",
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		return certificates;

	}

	@Override
	public List<ManagementTeam> getAllManagementTeam(String smeUuid, String status) {

		List<ManagementTeam> teams = null;

		if (status == null) {
			teams = smeDao.getManagementTeams(smeUuid);

		} else {
			switch (status) {
			case SMEMasterConstants.ACTIVE:
				teams = smeDao.getManagementTeamsByActive(smeUuid, true);
				break;
			case SMEMasterConstants.DEACTIVE:
				teams = smeDao.getManagementTeamsByActive(smeUuid, false);
				break;
			default:
				throw new CustomException("Exception in :: getAllManagementTeam().Invalid status selection",
						HttpStatus.BAD_REQUEST);
			}

		}
		return teams;

	}

	@Override
	public List<Gallery> getAllGalleries(String smeUuid, String status) {

		List<Gallery> galleries = null;

		if (status == null) {
			galleries = smeDao.getGalleries(smeUuid);
		} else {
			switch (status) {
			case SMEMasterConstants.ACTIVE:
				galleries = smeDao.getGalleriesByActive(smeUuid, true);
				break;
			case SMEMasterConstants.DEACTIVE:
				galleries = smeDao.getGalleriesByActive(smeUuid, false);
				break;
			default:
				throw new CustomException("Exception in :: getAllGalleries().Invalid status selection",
						HttpStatus.BAD_REQUEST);
			}
		}
		return galleries;

	}

	@Override
	public SMEInformation getSME(String smeUuid, String status) {
		SMEInformation sme = smeDao.getSME(smeUuid);

		switch (status) {
		case SMEMasterConstants.ACTIVE:
			if (!sme.isActive())
				throw new CustomException("Active sme not found for id " + smeUuid, HttpStatus.NOT_FOUND);
			break;
		case SMEMasterConstants.DEACTIVE:
			if (sme.isActive())
				throw new CustomException("Deactive sme not found for id " + smeUuid, HttpStatus.NOT_FOUND);
			break;
		case SMEMasterConstants.BOTH:
			return sme;
		default:
			throw new CustomException("Invalid choice for get SME by status " + status, HttpStatus.NOT_FOUND);
		}
		return sme;

	}

	@Override
	@Cacheable(value = "smes")
	public List<SMEInformationVo> getTopSmes() {
		return smeDao.getTopSmes().stream().map(mapper::convertToVo).collect(Collectors.toList());
	}

	@Override
	public List<SMEInformation> getSpecificSMEs(Set<String> smeUuids, String smeActiveStatus) {
		List<SMEInformation> smes = new ArrayList<>();

		smeUuids.forEach(smeUuid -> {
			try {
				smes.add(getSME(smeUuid, smeActiveStatus));
			} catch (CustomException e) {
				log.error(e.getErrorMessage());
			}
		});

		if (!smes.isEmpty())
			return smes;
		else
			throw new CustomException("None of SME Present in given Ids:  " + smeUuids, HttpStatus.NOT_FOUND);
	}

	@Override
	public SMEInformation getActiveSmeByItemId(String itemId, ItemType itemType) {
		return smeDao.findActiveSmeByItemId(itemId, itemType);
	}

	@Override
	public ManagementTeam getManagementTeam(String teamUuid) {
		return teamDao.getManagementTeam(teamUuid);

	}

	@Override
	public Infrastructure getInfrastructure(String infraUuid) {
		return infrastructureDao.getInfraByUuid(infraUuid);
	}

	@Override
	public Certificate getCertificate(String crtiUuid) {
		return certificateDao.getCertificate(crtiUuid);
	}

	@Override
	public Gallery getGallery(String galleryUuid) {
		return galleryDao.getGallery(galleryUuid);
	}

	@Override
	@Transactional(rollbackFor = Exception.class, readOnly = false)
	public void deleteInfra(String smeUuid, String infraUuid) {

		PricingRequest pricingRequest = null;

		if (!smeDao.isSMEHasGivenInfrastructure(smeUuid, infraUuid)) {
			throwUnauthorizedException("infrastructure", smeUuid);
		}

		Infrastructure infra = infrastructureDao.getInfraByUuid(infraUuid);

		if (infra.getImages() != null && !infra.getImages().isEmpty()) {
			pricingRequest = this.manageImages(null, infra.getImages(), null);
		}
		infrastructureDao.deleteInfra(infra);
		if (pricingRequest != null) {
			pricingRequest.setUsedFor("Image Credits Returns for Deleted Infra:: " + infraUuid);
			pricingEndpoint.updateCredits(pricingRequest);
		}

	}

	@Override
	@Transactional(rollbackFor = Exception.class, readOnly = false)
	public void deleteCertificate(String smeUuid, String crtiUuid) {
		PricingRequest pricingRequest = null;

		if (!smeDao.isSMEHasGivenCertificate(smeUuid, crtiUuid)) {
			throwUnauthorizedException("certificate", smeUuid);
		}

		Certificate certificate = this.getCertificate(crtiUuid);
		if (certificate.getImages() != null && !certificate.getImages().isEmpty()) {
			pricingRequest = this.manageImages(null, certificate.getImages(), null);
		}
		certificateDao.deleteCertificate(certificate);

		if (pricingRequest != null) {
			pricingRequest.setUsedFor("Image Credits Returns for Deleted Certificate:: " + crtiUuid);
			pricingEndpoint.updateCredits(pricingRequest);
		}

	}

	@Override
	@Transactional(rollbackFor = Exception.class, readOnly = false)
	public void deleteTeam(String smeUuid, String teamUuid) {
		PricingRequest pricingRequest = null;
		if (!smeDao.isSMEHasGivenTeam(smeUuid, teamUuid)) {
			throwUnauthorizedException("management team", smeUuid);
		}

		ManagementTeam team = this.getManagementTeam(teamUuid);

		if (team.getProfileImage() != null) {
			pricingRequest = this.manageImages(null, Arrays.asList(team.getProfileImage()), null);
		}
		teamDao.deleteTeam(team);

		if (pricingRequest != null) {
			pricingRequest.setUsedFor("Image Credits Returns for Deleted Team :: " + teamUuid);
			pricingEndpoint.updateCredits(pricingRequest);
		}
	}

	@Override
	@Transactional(rollbackFor = Exception.class, readOnly = false)
	public void deleteGallery(String smeUuid, String galleryUuid) {
		PricingRequest pricingRequest = null;

		if (!smeDao.isSMEHasGivenGallery(smeUuid, galleryUuid)) {
			throwUnauthorizedException("gallery", smeUuid);
		}

		Gallery gallery = this.getGallery(galleryUuid);

		if (gallery.getImages() != null && !gallery.getImages().isEmpty()) {
			pricingRequest = this.manageImages(null, gallery.getImages(), null);
		}
		galleryDao.deleteGallery(gallery);

		if (pricingRequest != null) {
			pricingRequest.setUsedFor("Image Credits Returns for Deleted Gallery :: " + galleryUuid);
			pricingEndpoint.updateCredits(pricingRequest);
		}
	}

	@Override
	public boolean isGSTINNumberExist(String gstin) {
		return smeDao.isGSTINNumberExist(gstin);
	}

	@Override
	public List<Infrastructure> getActiveAndApprovedInfras(String smeUuid) {
		return smeDao.getInfrasBySmeUuidAndStateAndActive(smeUuid, ItemState.APPROVED, BooleanFlag.TRUE);

	}

	@Override
	public List<Certificate> getActiveAndApprovedCertificates(String smeUuid) {
		return smeDao.getCertificatesBySmeUuidAndStateAndActive(smeUuid, ItemState.APPROVED, BooleanFlag.TRUE);
	}

	@Override
	public List<ManagementTeam> getActiveAndApprovedManagementTeams(String smeUuid) {
		return smeDao.getTeamsBySmeUuidAndStateAndActive(smeUuid, ItemState.APPROVED, BooleanFlag.TRUE);
	}

	@Override
	public List<Gallery> getActiveAndApprovedGalleries(String smeUuid) {
		return smeDao.getGalleriesBySmeUuidAndStateAndActive(smeUuid, ItemState.APPROVED, BooleanFlag.TRUE);

	}

	@Override
	public void saveMultipleInfras(List<Infrastructure> infras) {
		infrastructureDao.saveInfras(infras);
	}

	@Override
	public void saveMultipleCertificates(List<Certificate> certificates) {
		certificateDao.saveCertificates(certificates);
	}

	@Override
	public void saveMultipleTeams(List<ManagementTeam> teams) {
		teamDao.saveTeams(teams);
	}

	@Override
	public void saveMultipleGalleries(List<Gallery> galleries) {
		galleryDao.saveGalleries(galleries);

	}

	@Override
	public SmeSubEntitiesCount getCounts(String smeUuid, boolean viewMode) {

		int infrasCount = countOfInfrastructures(smeUuid, viewMode);
		int certificatesCount = countOfCertificates(smeUuid, viewMode);
		int teamsCount = countOfTeams(smeUuid, viewMode);
		int galleries = countOfGalleries(smeUuid, viewMode);
		return new SmeSubEntitiesCount(infrasCount, certificatesCount, teamsCount, galleries);
	}

	public int countOfInfrastructures(String smeUuid, boolean viewMode) {
		int infraCount;
		if (viewMode) {
			infraCount = smeDao.infrasCountBySmeIdAndActiveAndState(smeUuid, true, ItemState.APPROVED);
		} else {
			infraCount = smeDao.infrasCountBySmeId(smeUuid);
		}
		return infraCount;
	}

	public int countOfCertificates(String smeUuid, boolean viewMode) {
		int count;
		if (viewMode) {

			count = smeDao.certificatesCountBySmeIdAndActiveAndState(smeUuid, true, ItemState.APPROVED);
		} else {
			count = smeDao.certificatesCountBySmeId(smeUuid);
		}

		return count;
	}

	public int countOfTeams(String smeUuid, boolean viewMode) {
		int teamCount;

		if (viewMode) {
			teamCount = smeDao.teamsCountBySmeIdAndActiveAndState(smeUuid, true, ItemState.APPROVED);
		} else {
			teamCount = smeDao.teamsCountBySmeId(smeUuid);
		}
		return teamCount;
	}

	public int countOfGalleries(String smeUuid, boolean viewMode) {
		int galleryCount;
		if (viewMode) {
			galleryCount = smeDao.galleriesCountBySmeIdAndActiveAndState(smeUuid, true, ItemState.APPROVED);

		} else {
			galleryCount = smeDao.galleriesCountBySmeId(smeUuid);
		}
		return galleryCount;
	}

	private long getImagesTotalSize(List<Image> imgs) {
		return imgs.stream().mapToLong(Image::getSize).sum();
	}

	private <T> PricingRequest manageImages(T t, List<Image> existImages, List<Image> updatedImages) {

		PricingRequest pricingRequest = null;
		if (updatedImages != null && !updatedImages.isEmpty()) {

			if (existImages != null && !existImages.isEmpty()) {
				pricingRequest = this.manageNewAndDeletedImagesAndImageCredits(existImages, updatedImages);
				imageDao.deactiveMultipleImages(existImages);
			} else {
				long newImagesSize = getImagesTotalSize(updatedImages);
				if (pricingEndpoint.checkCredits(CreditType.IMAGE_STORAGE) < newImagesSize) {
					pricingEndpoint.noCreditsLeftException(CreditType.IMAGE_STORAGE);
				}
				log.info("new image size: {} and action: {}", newImagesSize, DEBIT);
				pricingRequest = new PricingRequest(CreditType.IMAGE_STORAGE, newImagesSize, DEBIT);

			}
			if (t instanceof Infrastructure) {
				Infrastructure infrastructure = (Infrastructure) t;
				infrastructure.setImages(updatedImages);
			} else if (t instanceof Certificate) {
				Certificate certificate = (Certificate) t;
				certificate.setImages(updatedImages);
			} else if (t instanceof Gallery) {
				Gallery gallery = (Gallery) t;
				gallery.setImages(updatedImages);
			} else if (t instanceof SMEInformation) {
				SMEInformation sme = (SMEInformation) t;
				sme.setHomeSliderImages(updatedImages);
			}

		} else {
			imageDao.deactiveMultipleImages(existImages);
			long deletedImagesSize = getImagesTotalSize(existImages);
			log.info("deleted image size: {} and action: {}", deletedImagesSize, CREDIT);
			pricingRequest = new PricingRequest(CreditType.IMAGE_STORAGE, deletedImagesSize, CREDIT);
		}
		return pricingRequest;
	}

	private PricingRequest manageNewAndDeletedImagesAndImageCredits(List<Image> existImages,
			List<Image> updatedImages) {

		int newImagesSize = 0;
		int newImagesCount = 0;
		for (Image updateImg : updatedImages) {
			boolean bool = true;
			Iterator<Image> iterator = existImages.iterator();
			while (iterator.hasNext()) {
				Image existImg = iterator.next();
				if (existImg.getImgUuid().equals(updateImg.getImgUuid())) {
					updateImg.setImageId(existImg.getImageId());
					updateImg.setActive(existImg.isActive());
					iterator.remove();
					bool = false;
					break;
				}
			}
			if (bool) {
				updateImg.setActive(true);
				++newImagesCount;
				newImagesSize += updateImg.getSize();
			}

		}

		long deletedImagesSize = getImagesTotalSize(existImages);

		return getPricingRequestObj(newImagesCount, existImages.size(), deletedImagesSize, newImagesSize);

	}

	private PricingRequest getPricingRequestObj(int newImagesCount, int deletedImagesCount, long deletedImagesSize,
			long newImagesSize) {

		PricingRequest pricingRequest = null;
		String action = null;

		long finalImageStorageSize = deletedImagesSize - newImagesSize;

		if (finalImageStorageSize > 0) {
			action = CREDIT;
			pricingRequest = new PricingRequest(CreditType.IMAGE_STORAGE, finalImageStorageSize, action);
		} else if (finalImageStorageSize < 0) {
			finalImageStorageSize = Math.abs(finalImageStorageSize);
			action = DEBIT;
			if (pricingEndpoint.checkCredits(CreditType.IMAGE_STORAGE) < finalImageStorageSize) {
				pricingEndpoint.noCreditsLeftException(CreditType.IMAGE_STORAGE);
			}
			pricingRequest = new PricingRequest(CreditType.IMAGE_STORAGE, finalImageStorageSize, action);
		}

		log.info(
				"new images: [total {}. size: {} ] and deleted images: [total {}. size: {} ]. final Images size: {} and action: {}",
				newImagesCount, newImagesSize, deletedImagesCount, deletedImagesSize, finalImageStorageSize, action);

		return pricingRequest;

	}

	private void throwUnauthorizedException(String entityType, String smeUuid) {
		throw new CustomException("Unauthorized permission. given " + entityType + " is not related to sme:-" + smeUuid,
				HttpStatus.UNAUTHORIZED);
	}

	@Override
	public EditModeItemsPercentage getPercentageCounts(String smeId) {

		SMEItemsCount itemsCounts = smeDao.getSmeItemsCount(smeId);

		EditModeItemsPercentage editModeItemsPercentage = new EditModeItemsPercentage();

		float productPercentage = ((itemsCounts.getActivePendingProducts()+itemsCounts.getActiveApprovedProducts()) * 100) / 3;
		productPercentage = productPercentage >= 100 ? 100 : productPercentage;
		float servicePercentage = ((itemsCounts.getActivePendingServices()+itemsCounts.getActiveApprovedServices()) * 100) / 3;
		servicePercentage = servicePercentage >= 100 ? 100 : servicePercentage;
		float certificatePercentage = ((itemsCounts.getActivePendingCertificates()+itemsCounts.getActiveApprovedCertificates()) * 100) / 2;
		certificatePercentage = certificatePercentage >= 100 ? 100 : certificatePercentage;
		float infraPercentage = ((itemsCounts.getActivePendingInfras()+itemsCounts.getActiveApprovedInfras()) * 100) / 2;
		infraPercentage = infraPercentage >= 100 ? 100 : infraPercentage;
		float galleryPercentage = ((itemsCounts.getActivePendingGalleries()+itemsCounts.getActiveApprovedGalleries()) * 100) / 2;
		galleryPercentage = galleryPercentage >= 100 ? 100 : galleryPercentage;
		float teamPercentage = ((itemsCounts.getActivePendingTeams()+itemsCounts.getActiveApprovedTeams()) * 100) / 2;
		teamPercentage = teamPercentage >= 100 ? 100 : teamPercentage;
		float jobsPercentage = ((itemsCounts.getActivePendingVacancies()+itemsCounts.getActiveApprovedVacancies()) * 100) / 2;
		jobsPercentage = jobsPercentage >= 100 ? 100 : jobsPercentage;
		float socialPostPercentage = ((itemsCounts.getActivePendingBusinessPosts()+itemsCounts.getActiveApprovedBusinessPosts()) * 100) / 2;
		socialPostPercentage = socialPostPercentage >= 100 ? 100 : socialPostPercentage;
		
		
		editModeItemsPercentage.setProductPercentage(productPercentage);
		editModeItemsPercentage.setServicePercentage(servicePercentage);
		editModeItemsPercentage.setCertificatePercentage(certificatePercentage);
		editModeItemsPercentage.setInfraPercentage(infraPercentage);
		editModeItemsPercentage.setGalleryPercentage(galleryPercentage);
		editModeItemsPercentage.setTeamPercentage(teamPercentage);
		editModeItemsPercentage.setJobsPercentage(jobsPercentage);
		editModeItemsPercentage.setSocialPostPercentage(socialPostPercentage);
		
		float overAllPercentage = (productPercentage + servicePercentage + certificatePercentage + infraPercentage
				+ galleryPercentage + teamPercentage + jobsPercentage + socialPostPercentage) / 8;
		editModeItemsPercentage.setOverAllPercentage(overAllPercentage);

		return editModeItemsPercentage;
	}

}
