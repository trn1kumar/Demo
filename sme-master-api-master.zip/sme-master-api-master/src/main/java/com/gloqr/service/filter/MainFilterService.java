package com.gloqr.service.filter;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.search.query.facet.Facet;

import com.gloqr.dto.FilterDto;
import com.gloqr.dto.FilterResponse;

public interface MainFilterService {

	public Map<String, Object> getFilter(Set<String> categoriesFilterParam, List<Facet> categoryFacets,
			Set<String> citiesFilterParam, List<Facet> cityFacets);

	public FilterResponse applyFilter(String searchText, Set<String> categoriesFilterParam,
			Set<String> citiesFilterParam, int page);

	public FilterDto getInitialFilter();

}
