package com.gloqr.service;

public interface CacheService {

	void evictSmesCache();

}
