package com.gloqr.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.gloqr.configuration.NotificationPropertyValues;
import com.gloqr.constants.ItemState;
import com.gloqr.constants.ItemType;
import com.gloqr.constants.NotificationConstants;
import com.gloqr.dto.SMEInformationDto;
import com.gloqr.entities.Certificate;
import com.gloqr.entities.Gallery;
import com.gloqr.entities.Infrastructure;
import com.gloqr.entities.ManagementTeam;
import com.gloqr.entities.SMEInformation;
import com.gloqr.exception.CustomException;
import com.gloqr.model.notification.EmailEvent;
import com.gloqr.model.notification.SmsEvent;
import com.gloqr.rest.endpoint.NotificationEndPoint;

@Service
@Async("taskExecutor")
public class NotificationServiceImpl extends NotificationConstants implements NotificationService {

	private static final Logger log = LogManager.getLogger();
	private static final String DATE_FORMATE = "yyyy-MM-dd 'at' hh:mm:ss a";

	@Autowired
	private TemplateEngine templateEngine;

	@Autowired
	private NotificationPropertyValues propertyValues;

	@Autowired
	private NotificationEndPoint notificationEndpoint;

	@Override
	public void sendWelcomeNotification(SMEInformationDto smeDetails) {

		SmsEvent smsEvent = null;
		EmailEvent emailEvent = null;
		String mobileNumber = smeDetails.getContactPhone();
		String emailId = smeDetails.getContactEmail();
		String smeName = smeDetails.getSmeName();
		String sUuid = smeDetails.getsUuid();

		checkMobileOrEmailAvailable(mobileNumber, emailId);
		if (mobileNumber != null) {
			String smsMsg = propertyValues.getWelcomeSmsMsg().replace("{smeName}", smeName).replace("{sUuid}", sUuid);
			smsEvent = new SmsEvent(mobileNumber, smsMsg);
			smsEvent.setMobileNo(mobileNumber);
		}

		if (emailId != null) {
			Context context = new Context();
			context.setVariable("homeUrl", propertyValues.getBaseUrl());
			context.setVariable("smeHomePageUrl", propertyValues.getSmeHomePageUrl());
			context.setVariable("contentServerUrl", propertyValues.getContentServerUrl());
			context.setVariable("smeDetails", smeDetails);
			String mailPage = templateEngine.process(SME_WELCOME_TEMPLATES, context);
			emailEvent = new EmailEvent(emailId, propertyValues.getWelcomeEmailSubject(), mailPage);
		}
		sendNotifications(smsEvent, emailEvent);

	}

	private void sendNotifications(SmsEvent smsEvent, EmailEvent emailEvent) {

		List<Object> events = new ArrayList<>();

		if (smsEvent != null)
			events.add(smsEvent);
		if (emailEvent != null)
			events.add(emailEvent);

		try {
			events.parallelStream().forEach(e -> notificationEndpoint.sendNotification(e));
		} catch (Exception e) {
			log.error("failed to send notifications.Exception:- " + e.getMessage());
		}
	}

	@Override
	public void sendSmeApprovedNotifi(SMEInformation sme) {
		try {
			EmailEvent emailEvent = null;
			SmsEvent smsEvent = null;
			String emailId = sme.getContactEmail();
			String mobileNum = sme.getContactPhone();
			checkMobileOrEmailAvailable(mobileNum, emailId);
			if (emailId != null) {
				String mailSub = propertyValues.getSmeApprovedEmailSubject().replace("{smeName}", sme.getSmeName());
				Context context = new Context();
				context.setVariable("smeName", sme.getSmeName());
				context.setVariable("homeUrl", propertyValues.getBaseUrl());
				context.setVariable("smeHomePageUrl", propertyValues.getSmeHomePageUrl());
				context.setVariable("contentServerUrl", propertyValues.getContentServerUrl());
				String mailPage = templateEngine.process(SME_APPROVED_TEMPLATES, context);
				emailEvent = new EmailEvent(emailId, mailSub, mailPage);

			}
			if (mobileNum != null) {
				String smsMsg = propertyValues.getSmeApprovedSmsMsg().replace("{smeName}", sme.getSmeName())
						.replace("{sUuid}", sme.getsUuid());
				smsEvent = new SmsEvent(mobileNum, smsMsg);
			}

			sendNotifications(smsEvent, emailEvent);
		} catch (Exception e) {
			log.error("can't send sme approved notification. Exception:- {}", e.getMessage());
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public void sendVerificationsSummaryNotification(SMEInformation sme, List<?> smeItems, ItemType itemType) {

		try {
			EmailEvent emailEvent = null;
			String emailId = sme.getContactEmail();
			checkMobileOrEmailAvailable(null, emailId);

			switch (itemType) {
			case CERTIFICATE:
				emailEvent = getCertificatesVerifiEmailEvent(sme, (List<Certificate>) smeItems);
				break;
			case INFRASTRUCTURE:
				emailEvent = getInfrasVerifiEmailEvent(sme, (List<Infrastructure>) smeItems);
				break;
			case TEAM:
				emailEvent = getTeamsVerifiEmailEvent(sme, (List<ManagementTeam>) smeItems);
				break;
			case GALLERY:
				emailEvent = getGalleriesVerifiEmailEvent(sme, (List<Gallery>) smeItems);
				break;
			default:
				break;
			}

			sendNotifications(null, emailEvent);
		} catch (Exception e) {
			log.error("can't send verification notification for itemType {}. Exception:- {}", itemType, e.getMessage());
		}
	}

	private EmailEvent getCertificatesVerifiEmailEvent(SMEInformation sme, List<Certificate> certificates) {

		SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMATE);
		Date date = new Date();

		List<Certificate> approvedCertificates = new ArrayList<>();
		List<Certificate> rejectedCertificates = new ArrayList<>();

		certificates.parallelStream().forEach(cert -> {
			if (cert.getItemState().equals(ItemState.APPROVED))
				approvedCertificates.add(cert);
			else if (cert.getItemState().equals(ItemState.REJECTED))
				rejectedCertificates.add(cert);
		});

		Context context = new Context();
		context.setVariable("smeName", sme.getSmeName());
		context.setVariable("approvedCertificates", approvedCertificates);
		context.setVariable("rejectedCertificates", rejectedCertificates);
		context.setVariable("totalApproved", approvedCertificates.size());
		context.setVariable("totalRejected", rejectedCertificates.size());
		context.setVariable("approvedDateTime", formatter.format(date));
		context.setVariable("homeUrl", propertyValues.getBaseUrl());
		context.setVariable("contentServerUrl", propertyValues.getContentServerUrl());
		String mailPage = templateEngine.process(CERTIFICATES_VERIFI_TEMPLATES, context);
		String emailSub = propertyValues.getCertificatesVerifiEmailSub();
		return new EmailEvent(sme.getContactEmail(), emailSub, mailPage);
	}

	private EmailEvent getInfrasVerifiEmailEvent(SMEInformation sme, List<Infrastructure> infras) {

		SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMATE);
		Date date = new Date();

		List<Infrastructure> approvedInfras = new ArrayList<>();
		List<Infrastructure> rejectedInfras = new ArrayList<>();

		infras.parallelStream().forEach(infra -> {
			if (infra.getItemState().equals(ItemState.APPROVED))
				approvedInfras.add(infra);
			else if (infra.getItemState().equals(ItemState.REJECTED))
				rejectedInfras.add(infra);

		});

		Context context = new Context();
		context.setVariable("smeName", sme.getSmeName());
		context.setVariable("approvedInfras", approvedInfras);
		context.setVariable("rejectedInfras", rejectedInfras);
		context.setVariable("totalApproved", approvedInfras.size());
		context.setVariable("totalRejected", rejectedInfras.size());
		context.setVariable("approvedDateTime", formatter.format(date));
		context.setVariable("homeUrl", propertyValues.getBaseUrl());
		context.setVariable("contentServerUrl", propertyValues.getContentServerUrl());

		String mailPage = templateEngine.process(INFRAS_VERIFI_TEMPLATES, context);
		String emailSub = propertyValues.getInfrasVerifiEmailSub();

		return new EmailEvent(sme.getContactEmail(), emailSub, mailPage);
	}

	private EmailEvent getGalleriesVerifiEmailEvent(SMEInformation sme, List<Gallery> galleries) {

		SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMATE);
		Date date = new Date();

		List<Gallery> approvedgalleries = new ArrayList<>();
		List<Gallery> rejectedGalleries = new ArrayList<>();

		galleries.parallelStream().forEach(gallery -> {
			if (gallery.getItemState().equals(ItemState.APPROVED))
				approvedgalleries.add(gallery);
			else if (gallery.getItemState().equals(ItemState.REJECTED))
				rejectedGalleries.add(gallery);

		});

		Context context = new Context();
		context.setVariable("smeName", sme.getSmeName());
		context.setVariable("approvedgalleries", approvedgalleries);
		context.setVariable("rejectedGalleries", rejectedGalleries);
		context.setVariable("totalApproved", approvedgalleries.size());
		context.setVariable("totalRejected", rejectedGalleries.size());
		context.setVariable("approvedDateTime", formatter.format(date));
		context.setVariable("homeUrl", propertyValues.getBaseUrl());
		context.setVariable("contentServerUrl", propertyValues.getContentServerUrl());

		String mailPage = templateEngine.process(GALLERIES_VERIFI_TEMPLATES, context);
		String emailSub = propertyValues.getGalleriesVerifiEmailSub();
		return new EmailEvent(sme.getContactEmail(), emailSub, mailPage);
	}

	private EmailEvent getTeamsVerifiEmailEvent(SMEInformation sme, List<ManagementTeam> teams) {

		SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMATE);
		Date date = new Date();

		List<ManagementTeam> approvedTeams = new ArrayList<>();
		List<ManagementTeam> rejectedTeams = new ArrayList<>();

		teams.parallelStream().forEach(team -> {
			if (team.getItemState().equals(ItemState.APPROVED))
				approvedTeams.add(team);
			else if (team.getItemState().equals(ItemState.REJECTED))
				rejectedTeams.add(team);

		});

		Context context = new Context();
		context.setVariable("smeName", sme.getSmeName());
		context.setVariable("approvedTeams", approvedTeams);
		context.setVariable("rejectedTeams", rejectedTeams);
		context.setVariable("totalApproved", approvedTeams.size());
		context.setVariable("totalRejected", rejectedTeams.size());
		context.setVariable("approvedDateTime", formatter.format(date));
		context.setVariable("homeUrl", propertyValues.getBaseUrl());
		context.setVariable("contentServerUrl", propertyValues.getContentServerUrl());

		String mailPage = templateEngine.process(TEAMS_VERIFI_TEMPLATES, context);
		String emailSub = propertyValues.getTeamsVerifiEmailSub();
		return new EmailEvent(sme.getContactEmail(), emailSub, mailPage);
	}

	private void checkMobileOrEmailAvailable(String mobileNum, String emailId) {
		if (mobileNum == null && emailId == null) {
			throw new CustomException("mobile no. and email both are null.required either mobile no or email.",
					HttpStatus.BAD_REQUEST);
		}
	}

}
