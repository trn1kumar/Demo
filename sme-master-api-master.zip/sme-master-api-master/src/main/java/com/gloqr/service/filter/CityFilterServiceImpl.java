package com.gloqr.service.filter;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;

import org.apache.lucene.search.BooleanClause.Occur;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Query;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.DatabaseRetrievalMethod;
import org.hibernate.search.query.ObjectLookupMethod;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.hibernate.search.query.engine.spi.FacetManager;
import org.hibernate.search.query.facet.Facet;
import org.hibernate.search.query.facet.FacetingRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.component.filter.FacetManagerComponent;
import com.gloqr.constants.FilterConstant.FacetConstant;
import com.gloqr.constants.FilterConstant.SearchFields;
import com.gloqr.dto.FilterResponse;
import com.gloqr.entities.SMEInformation;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.SMEMapper;
import com.gloqr.vo.SMEInformationVo;

@Service(value = "cityFilter")
public class CityFilterServiceImpl implements FilterService {

	@Autowired
	private EntityManager entityManager;

	@Autowired
	private FacetManagerComponent facetManagerComponent;

	@Autowired
	private SMEMapper mapper;

	@Autowired
	private MainFilterService mainFilterService;

	@SuppressWarnings("unchecked")
	@Override
	public FilterResponse filter(String searchText, Set<String> categoriesFilterParam, Set<String> citiesFilterParam,
			int firstResult, int maxResult) {
		// 'categoriesFilterParam' should be null for Filter by City

		if (citiesFilterParam == null) {
			throw new CustomException(" 'citiesFilterParam ' is null for filter by city.", HttpStatus.BAD_REQUEST);
		}

		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(SMEInformation.class).overridesForField(SearchFields.SME_NAME, "customanalyzer").get();

		FullTextQuery fullTextQuery = createFullTextQuery(fullTextEntityManager, queryBuilder, searchText, null,
				citiesFilterParam);

		fullTextQuery.setFirstResult(firstResult).setMaxResults(maxResult);

		FacetManager categoryFacetManager = fullTextQuery.getFacetManager();
		FacetingRequest categoryFacetingRequest = facetManagerComponent.getFacetingRequests(queryBuilder)
				.get(FacetConstant.CATEGORY_FACET_REQ);
		categoryFacetManager.enableFaceting(categoryFacetingRequest);

		FacetManager mainFacetManager = facetManagerComponent.getFacetManagerForActiveSME(fullTextEntityManager,
				queryBuilder, searchText);
		List<Facet> cityFacets = mainFacetManager.getFacets(FacetConstant.CITY_FACET);
		List<Facet> categoryFacets = categoryFacetManager.getFacets(FacetConstant.CATEGORY_FACET);

		List<SMEInformation> smes = fullTextQuery.getResultList();

		if (smes.isEmpty())
			throw new CustomException("No More SME's Available", HttpStatus.NOT_FOUND);

		List<SMEInformationVo> result = mapper.convertToDtos(smes, SMEInformationVo.class);
		Map<String, Object> filters = mainFilterService.getFilter(null, categoryFacets, citiesFilterParam, cityFacets);

		return new FilterResponse(filters, result, fullTextQuery.getResultSize());

	}

	@Override
	public FullTextQuery createFullTextQuery(FullTextEntityManager fullTextEntityManager, QueryBuilder queryBuilder,
			String searchText, Set<String> categoriesFilterParam, Set<String> citiesFilterParam) {
		if (citiesFilterParam == null) {
			throw new CustomException(" 'citiesFilterParam' is null for createFullTextQuery for filter by City.",
					HttpStatus.BAD_REQUEST);
		}

		List<Query> queryList = null;

		if (searchText != null)
			queryList = getQueriesWithSearchText(citiesFilterParam, queryBuilder, searchText);
		else
			queryList = getQueriesWithOutSearchText(citiesFilterParam, queryBuilder);

		BooleanQuery.Builder booleanQuery = new BooleanQuery.Builder();
		queryList.forEach(q -> booleanQuery.add(q, Occur.SHOULD));

		FullTextQuery fullTextQuery = fullTextEntityManager.createFullTextQuery(booleanQuery.build(),
				SMEInformation.class);
		fullTextQuery.initializeObjectsWith(ObjectLookupMethod.SECOND_LEVEL_CACHE, DatabaseRetrievalMethod.QUERY);
		return fullTextQuery;
	}

	private List<Query> getQueriesWithSearchText(Set<String> citiesFilterParam, QueryBuilder queryBuilder,
			String searchText) {
		List<Query> queryList = new LinkedList<>();
		citiesFilterParam.forEach(city -> {

			Query query = queryBuilder.bool()
					.must(queryBuilder.keyword().onField(SearchFields.CITY).matching(city).createQuery())
					.must(queryBuilder.keyword().onField(SearchFields.ACTIVE).matching(true).createQuery())
					.must(queryBuilder.simpleQueryString().onField(SearchFields.SME_NAME).withAndAsDefaultOperator()
							.matching(searchText).createQuery())
					.createQuery();

			queryList.add(query);
		});
		return queryList;
	}

	private List<Query> getQueriesWithOutSearchText(Set<String> citiesFilterParam, QueryBuilder queryBuilder) {
		List<Query> queryList = new LinkedList<>();
		citiesFilterParam.forEach(city -> {

			Query query = queryBuilder.bool()
					.must(queryBuilder.keyword().onField(SearchFields.CITY).matching(city).createQuery())
					.must(queryBuilder.keyword().onField(SearchFields.ACTIVE).matching(true).createQuery())
					.createQuery();

			queryList.add(query);
		});
		return queryList;
	}

}
