package com.gloqr.service;

import java.util.List;

import com.gloqr.entities.SMECategory;

public interface SMECategoryService {

	public void saveCategory(SMECategory category);
	public SMECategory getCategory(String categoryUuid);
	public List<SMECategory> getAllCategories();
	public SMECategory getCategoryByUrl(String categoryUrl);

}
