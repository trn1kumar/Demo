package com.gloqr.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.entities.Infrastructure;
import com.gloqr.model.PublishFeed;
import com.gloqr.model.SMEItemUpdate;
import com.gloqr.rest.endpoint.BusinessPostEndpoint;

@Service
public class BusinessPostServiceImpl implements BusinessPostService {

	@Autowired
	BusinessPostEndpoint businessPostEndPoint;

	@Override
	public void createBusinessPost(String sUuid, Infrastructure infra) {

		PublishFeed feed = new PublishFeed(sUuid, infra.getInfraUuid(), infra.getMachineName(), infra.getDescription(),
				infra.getImages());

		if (infra.isActive())
			feed.setActive(true);

		businessPostEndPoint.createFeed(feed);

	}

	@Override
	public void acitveBusinessPosts(List<SMEItemUpdate> businessPostedInfras) {
		businessPostEndPoint.acitveBusinessPosts(businessPostedInfras);
	}

}
