package com.gloqr.service.filter;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;

import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Query;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.DatabaseRetrievalMethod;
import org.hibernate.search.query.ObjectLookupMethod;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.hibernate.search.query.engine.spi.FacetManager;
import org.hibernate.search.query.facet.Facet;
import org.hibernate.search.query.facet.FacetingRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.component.filter.FacetManagerComponent;
import com.gloqr.constants.FilterConstant.FacetConstant;
import com.gloqr.constants.FilterConstant.SearchFields;
import com.gloqr.dto.FilterResponse;
import com.gloqr.entities.SMEInformation;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.SMEMapper;
import com.gloqr.vo.SMEInformationVo;

@Service("combineFilter")
public class CombineFilterServiceImpl implements FilterService {

	@Autowired
	@Qualifier("cityFilter")
	private FilterService cityFilterService;

	@Autowired
	@Qualifier("categoryFilter")
	private FilterService categoryFilterService;

	@Autowired
	private FacetManagerComponent facetManagerComponent;

	@Autowired
	private EntityManager entityManager;

	@Autowired
	private SMEMapper mapper;

	@Autowired
	private MainFilterService mainFilterService;

	@SuppressWarnings("unchecked")
	@Override
	public FilterResponse filter(String searchText, Set<String> categoriesFilterParam, Set<String> citiesFilterParam,
			int firstResult, int maxResult) {

		if (categoriesFilterParam == null || citiesFilterParam == null) {
			throw new CustomException(
					" 'categoriesFilterParam' or 'citiesFilterParam ' is not null for combine filter.",
					HttpStatus.BAD_REQUEST);
		}

		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(SMEInformation.class).overridesForField(SearchFields.SME_NAME, "customanalyzer").get();

		FullTextQuery fullTextQuery = createFullTextQuery(fullTextEntityManager, queryBuilder, searchText,
				categoriesFilterParam, citiesFilterParam);

		fullTextQuery.setFirstResult(firstResult).setMaxResults(maxResult);

		List<Facet> cityFacets = getCityFacet(fullTextEntityManager, queryBuilder, searchText, categoriesFilterParam);
		List<Facet> categoryFacets = getCategoryFacet(fullTextEntityManager, queryBuilder, searchText,
				citiesFilterParam);

		List<SMEInformation> smes = fullTextQuery.getResultList();
		if (smes.isEmpty())
			throw new CustomException("No More SME's Available", HttpStatus.NOT_FOUND);

		List<SMEInformationVo> result = mapper.convertToDtos(smes, SMEInformationVo.class);
		Map<String, Object> filters = mainFilterService.getFilter(categoriesFilterParam, categoryFacets,
				citiesFilterParam, cityFacets);

		return new FilterResponse(filters, result, fullTextQuery.getResultSize());

	}

	@Override
	public FullTextQuery createFullTextQuery(FullTextEntityManager fullTextEntityManager, QueryBuilder queryBuilder,
			String searchText, Set<String> categoriesFilterParam, Set<String> citiesFilterParam) {

		List<Query> queryList = null;

		if (searchText != null)
			queryList = getQueriesWithSearchText(categoriesFilterParam, citiesFilterParam, queryBuilder, searchText);
		else
			queryList = getQueriesWithOutSearchText(categoriesFilterParam, citiesFilterParam, queryBuilder);

		BooleanQuery.Builder booleanQuery = new BooleanQuery.Builder();
		queryList.forEach(q -> booleanQuery.add(q, BooleanClause.Occur.SHOULD));
		FullTextQuery fullTextQuery = fullTextEntityManager.createFullTextQuery(booleanQuery.build(),
				SMEInformation.class);

		fullTextQuery.initializeObjectsWith(ObjectLookupMethod.SECOND_LEVEL_CACHE, DatabaseRetrievalMethod.QUERY);
		return fullTextQuery;
	}

	private List<Facet> getCityFacet(FullTextEntityManager fullTextEntityManager, QueryBuilder queryBuilder,
			String searchText, Set<String> categoriesFilterParam) {

		// get city facet according to category filter param

		FullTextQuery fullTextQuery = categoryFilterService.createFullTextQuery(fullTextEntityManager, queryBuilder,
				searchText, categoriesFilterParam, null);
		FacetManager facetManager = fullTextQuery.getFacetManager();
		Map<String, FacetingRequest> facetingRequests = facetManagerComponent.getFacetingRequests(queryBuilder);
		facetManager.enableFaceting(facetingRequests.get(FacetConstant.CITY_FACET_REQ));
		return facetManager.getFacets(FacetConstant.CITY_FACET);

	}

	private List<Facet> getCategoryFacet(FullTextEntityManager fullTextEntityManager, QueryBuilder queryBuilder,
			String searchText, Set<String> citiesFilterParam) {

		// get category facet according to city filter param

		FullTextQuery fullTextQuery = cityFilterService.createFullTextQuery(fullTextEntityManager, queryBuilder,
				searchText, null, citiesFilterParam);

		FacetManager facetManager = fullTextQuery.getFacetManager();
		Map<String, FacetingRequest> facetingRequests = facetManagerComponent.getFacetingRequests(queryBuilder);
		facetManager.enableFaceting(facetingRequests.get(FacetConstant.CATEGORY_FACET_REQ));
		return facetManager.getFacets(FacetConstant.CATEGORY_FACET);

	}

	private List<Query> getQueriesWithSearchText(Set<String> categoriesFilterParam, Set<String> citiesFilterParam,
			QueryBuilder queryBuilder, String searchText) {
		List<Query> queryList = new LinkedList<>();
		categoriesFilterParam.forEach(category -> citiesFilterParam.forEach(city -> {
			Query query = queryBuilder.bool()
					.must(queryBuilder.keyword().onFields(SearchFields.CITY).matching(city).createQuery())
					.must(queryBuilder.keyword().onFields(SearchFields.CATEGORY).matching(category).createQuery())
					.must(queryBuilder.keyword().onField(SearchFields.ACTIVE).matching(true).createQuery())
					.must(queryBuilder.simpleQueryString().onField(SearchFields.SME_NAME).withAndAsDefaultOperator()
							.matching(searchText).createQuery())
					.createQuery();

			queryList.add(query);
		}));
		return queryList;
	}

	private List<Query> getQueriesWithOutSearchText(Set<String> categoriesFilterParam, Set<String> citiesFilterParam,
			QueryBuilder queryBuilder) {
		List<Query> queryList = new LinkedList<>();
		categoriesFilterParam.forEach(category -> citiesFilterParam.forEach(city -> {
			Query query = queryBuilder.bool()
					.must(queryBuilder.keyword().onFields(SearchFields.CITY).matching(city).createQuery())
					.must(queryBuilder.keyword().onFields(SearchFields.CATEGORY).matching(category).createQuery())
					.must(queryBuilder.keyword().onField(SearchFields.ACTIVE).matching(true).createQuery())
					.createQuery();

			queryList.add(query);
		}));
		return queryList;
	}

}
