package com.gloqr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.model.AuthToken;
import com.gloqr.rest.endpoint.UserEndpoint;
import com.gloqr.rest.endpoint.UserEndpoint.User;
import com.gloqr.rest.endpoint.UserEndpoint.UserType;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserEndpoint userEndpoint;

	@Override
	public AuthToken updateUserTypeAndGetNewToken(String uuid, String sUuid) {
		User user = userEndpoint.new User(uuid, sUuid, UserType.SME);
		return userEndpoint.changeUserTypeAndGetToken(user);
	}

}
