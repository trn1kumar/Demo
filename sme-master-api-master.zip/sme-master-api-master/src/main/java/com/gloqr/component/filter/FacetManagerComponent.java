package com.gloqr.component.filter;

import java.util.HashMap;
import java.util.Map;

import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.hibernate.search.query.engine.spi.FacetManager;
import org.hibernate.search.query.facet.FacetingRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.gloqr.constants.FilterConstant.FacetConstant;
import com.gloqr.constants.FilterConstant.SearchFields;
import com.gloqr.service.filter.FilterService;

@Component
public class FacetManagerComponent {

	@Autowired
	@Qualifier("activeSMEFilter")
	private FilterService filterService;

	public FacetManager getFacetManagerForActiveSME(final FullTextEntityManager fullTextEntityManager,
			final QueryBuilder queryBuilder, final String searchText) {

		FullTextQuery fullTextQuery = filterService.createFullTextQuery(fullTextEntityManager, queryBuilder, searchText,
				null, null);
		FacetManager facetManager = fullTextQuery.getFacetManager();

		Map<String, FacetingRequest> facetingRequests = getFacetingRequests(queryBuilder);
		facetManager.enableFaceting(facetingRequests.get(FacetConstant.CATEGORY_FACET_REQ));
		facetManager.enableFaceting(facetingRequests.get(FacetConstant.CITY_FACET_REQ));

		return facetManager;
	}

	public Map<String, FacetingRequest> getFacetingRequests(final QueryBuilder queryBuilder) {
		FacetingRequest categoryFacetingRequest = queryBuilder.facet().name(FacetConstant.CATEGORY_FACET)
				.onField(SearchFields.CATEGORY).discrete().includeZeroCounts(false).createFacetingRequest();

		FacetingRequest cityFacetingRequest = queryBuilder.facet().name(FacetConstant.CITY_FACET)
				.onField(SearchFields.CITY).discrete().includeZeroCounts(false).createFacetingRequest();

		Map<String, FacetingRequest> facetingRequests = new HashMap<>();
		facetingRequests.put(FacetConstant.CATEGORY_FACET_REQ, categoryFacetingRequest);
		facetingRequests.put(FacetConstant.CITY_FACET_REQ, cityFacetingRequest);
		return facetingRequests;
	}
}
