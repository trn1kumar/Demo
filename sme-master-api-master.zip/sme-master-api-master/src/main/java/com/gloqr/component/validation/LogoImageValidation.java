package com.gloqr.component.validation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.gloqr.exception.CustomValidation;
import com.gloqr.exception.ValidationErrors;

public class LogoImageValidation {

	public static void checkValidation(MultipartFile multipartFile) {
		ValidationErrors validationError = new ValidationErrors();

		List<String> errors = new ArrayList<>();
		try {
			if (multipartFile == null)
				errors.add("Please select at least one Image");
			else {
				String imageName = multipartFile.getOriginalFilename();
				if (multipartFile.isEmpty() || multipartFile.getSize() == 0) {
					errors.add("Error for Image Name= " + imageName + " ,Please select a valid Image");
				} else {
					if (multipartFile.getSize() > 307200) {
						errors.add("Error for Image Name= " + imageName + " ,Image Size must be Max 300KB");
					}
					if (!(multipartFile.getContentType().equalsIgnoreCase("image/jpg")
							|| multipartFile.getContentType().equalsIgnoreCase("image/jpeg")
							|| multipartFile.getContentType().equalsIgnoreCase("image/png"))) {
						errors.add("Error for Image Name= " + imageName + " ,jpg/png Image types are only supported");
					} /*else {
						try {
							image = ImageIO.read(multipartFile.getInputStream());
						} catch (IOException e1) {
							e1.printStackTrace();
						}
						Integer width = image.getWidth();
						Integer height = image.getHeight();

						if (width < 256 || height < 256) {
							errors.add("Error for Image Name= " + imageName + " ,Image ( Width= " + width
									+ "px and Heigth =" + height
									+ "px ) are not a valid resolution.Please select Image Resolution grether then ( Width= 256px and Height= 256px )");
						}
					}*/
				}
			}
			if (!errors.isEmpty()) {
				validationError.setErrors(errors);
				throw new CustomValidation(validationError);
			}
		} catch (CustomValidation e) {
			throw e;
		} 

	}
}
