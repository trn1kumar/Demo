package com.gloqr.component.validation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.gloqr.exception.CustomValidation;
import com.gloqr.exception.ValidationErrors;

public class CertificateImagesValidation {

	public static void checkValidation(MultipartFile[] multipartFiles) {

		ValidationErrors validationError = new ValidationErrors();
		List<String> errors = new ArrayList<>();
		try {
			if (multipartFiles != null && multipartFiles.length > 0) {
				if (multipartFiles.length > 5) {
					errors.add("Please upload only five Images");
				} else {
					for (MultipartFile multipartFile : multipartFiles) {
						String imageName = multipartFile.getOriginalFilename();
						if (multipartFile.isEmpty() || multipartFile.getSize() == 0) {
							errors.add("Error for Image Name= " + imageName + " ,Please select a valid Image");
						} else {
							if (multipartFile.getSize() > 307200) {
								errors.add("Error for Image Name= " + imageName + " ,Image Size must be Max 300 KB");
							}
							if (!(multipartFile.getContentType().equalsIgnoreCase("image/jpg")
									|| multipartFile.getContentType().equalsIgnoreCase("image/jpeg")
									|| multipartFile.getContentType().equalsIgnoreCase("image/png"))) {
								errors.add("Error for Image Name= " + imageName
										+ " ,jpg/png Image types are only supported");
							}
						}
					}
				}
			} else {
				errors.add("Please select at least one Image");
			}

			if (!errors.isEmpty()) {
				validationError.setErrors(errors);
				throw new CustomValidation(validationError);
			}
		} catch (CustomValidation e) {
			throw e;
		}

	}
}
