package com.gloqr.component.validation;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.constants.SMEMasterConstants;
import com.gloqr.exception.CustomException;

@Component
public class MultipartFileValidationImpl implements MultipartFileValidation {

	public void checkValidation(MultipartFile[] multipartFiles, String validationFor) {

		switch (validationFor) {
		case SMEMasterConstants.COMPANY_LOGO:
			LogoImageValidation.checkValidation(multipartFiles[0]);
			break;

		case SMEMasterConstants.TEAMS:
			ManagementTeamImagesValidation.checkValidation(multipartFiles);
			break;

		case SMEMasterConstants.GALLERIES:
			GalleryImagesValidation.checkValidation(multipartFiles);
			break;

		case SMEMasterConstants.CERTIFICATES:
			CertificateImagesValidation.checkValidation(multipartFiles);
			break;
		case SMEMasterConstants.INFRASTRUCTURES:
			InfrastructureImagesValidation.checkValidation(multipartFiles);
			break;
		default:
			throw new CustomException("Invalid choice for validation selection", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
