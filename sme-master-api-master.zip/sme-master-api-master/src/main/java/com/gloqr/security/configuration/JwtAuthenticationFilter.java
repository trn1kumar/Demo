package com.gloqr.security.configuration;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.stream.Collectors;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import com.gloqr.security.context.holder.UserDetails;

import io.jsonwebtoken.Claims;

public class JwtAuthenticationFilter extends OncePerRequestFilter {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		String header = request.getHeader(JwtConstants.HEADER_STRING);

		if (header != null) {

			log.info("Validating Token:- {}", header);
			final String authToken = header.replace(JwtConstants.TOKEN_PREFIX, "");
			final Claims claims = jwtTokenUtil.getJwtClaims(authToken);
			log.info("Validated");

			String subject = claims.getSubject();
			String smeId = (String) claims.get(JwtConstants.SME_ID);
			String userId = (String) claims.get(JwtConstants.USER_ID);
			String userName = (String) claims.get(JwtConstants.FIRST_NAME);
			String userType = (String) claims.get(JwtConstants.USER_TYPE);

			final Collection<? extends GrantedAuthority> authorities = Arrays
					.stream(claims.get(JwtConstants.AUTHORITIES_KEY).toString().split(","))
					.map(SimpleGrantedAuthority::new).collect(Collectors.toList());

			UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
					new UserDetails(subject, smeId, userId, userName, userType), "", authorities);

			logger.info("authenticated user " + subject + ", setting security context");
			SecurityContextHolder.getContext().setAuthentication(authentication);

		}
		filterChain.doFilter(request, response);

	}

}
