package com.gloqr.security.context.holder;

public class UserDetails {

	private String subject ;
	private String smeId ;
	private String userId ;
	private String userName ;
	private String userType ;
	
	
	public UserDetails(String subject, String smeId, String userId, String userName, String userType) {
		super();
		this.subject = subject;
		this.smeId = smeId;
		this.userId = userId;
		this.userName = userName;
		this.userType = userType;
	}
	public String getSubject() {
		return subject;
	}
	public String getSmeId() {
		return smeId;
	}
	public String getUserId() {
		return userId;
	}
	public String getUserName() {
		return userName;
	}
	public String getUserType() {
		return userType;
	}
	
}
