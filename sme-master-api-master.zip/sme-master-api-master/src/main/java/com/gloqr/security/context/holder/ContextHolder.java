package com.gloqr.security.context.holder;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.gloqr.exception.CustomException;

public class ContextHolder {

	private ContextHolder() {
		throw new CustomException("ContextHolder class. Can't Initiate", HttpStatus.INTERNAL_SERVER_ERROR);
	}

	public static HttpServletRequest getCurrentServletRequest() {
		return ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
	}
}
