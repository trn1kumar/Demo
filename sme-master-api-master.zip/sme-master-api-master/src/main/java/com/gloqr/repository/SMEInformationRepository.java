package com.gloqr.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.gloqr.constants.ItemState;
import com.gloqr.entities.Certificate;
import com.gloqr.entities.Gallery;
import com.gloqr.entities.Infrastructure;
import com.gloqr.entities.ManagementTeam;
import com.gloqr.entities.SMEInformation;
import com.gloqr.entities.SMEItemsCount;
import com.gloqr.model.ItemsCountUpdate;

public interface SMEInformationRepository extends JpaRepository<SMEInformation, Long> {

	SMEInformation findBySUuid(String sUuid);

	SMEInformation findByUuid(String userId);

	List<SMEInformation> findByActiveTrue(Pageable pageable);

	boolean existsBySUuid(String sUuid);

	@Modifying
	@Transactional
	@Query("update SMEInformation s set s.logoImage=:imageLocation where s.sUuid= :sUuid")
	void updateSmeLogo(@Param("sUuid") String sUuid, @Param("imageLocation") String imageLocation);

	boolean existsByGstin(String gstin);

	boolean existsByUuid(String uuid);

	List<SMEInformation> findByActive(boolean active);

	SMEInformation findBySUuidAndActiveTrue(String sUuid);

	SMEInformation findBySUuidAndActiveFalse(String sUuid);

	@Query("select s.logoImage from SMEInformation s where s.sUuid=:smeUuid")
	String getImageLocation(@Param("smeUuid") String sUuid);

	@Query("select c from SMEInformation s JOIN s.certificates c where s.sUuid=:smeUuid")
	List<Certificate> getCertificates(@Param("smeUuid") String smeUuid);

	@Query("select c from SMEInformation s JOIN s.certificates c where s.sUuid=:smeUuid AND c.itemState=:state AND c.active=:active")
	List<Certificate> getCertificatesByStateAndActive(@Param("smeUuid") String smeUuid, @Param("state") ItemState state,
			@Param("active") boolean active);

	@Query("select c from SMEInformation s JOIN s.certificates c where s.sUuid=:smeUuid AND c.active=:active")
	List<Certificate> getCertificatesByActive(@Param("smeUuid") String smeUuid, @Param("active") boolean active);

	@Query("select i from SMEInformation s JOIN s.infrastructures i where s.sUuid=:smeUuid")
	List<Infrastructure> getInfrastructures(@Param("smeUuid") String smeUuid);

	@Query("select i from SMEInformation s JOIN s.infrastructures i where s.sUuid=:smeUuid AND i.itemState=:state AND i.active=:active")
	List<Infrastructure> getInfrastructuresByStateAndActive(@Param("smeUuid") String smeUuid,
			@Param("state") ItemState state, @Param("active") boolean active);

	@Query("select i from SMEInformation s JOIN s.infrastructures i where s.sUuid=:smeUuid AND i.active=:active")
	List<Infrastructure> getInfrastructuresByActive(@Param("smeUuid") String smeUuid, @Param("active") boolean active);

	@Query("select t from SMEInformation s JOIN s.managementTeams t where s.sUuid=:smeUuid")
	List<ManagementTeam> getManagementTeams(@Param("smeUuid") String smeUuid);

	@Query("select t from SMEInformation s JOIN s.managementTeams t where s.sUuid=:smeUuid AND t.itemState=:state AND t.active=:active")
	List<ManagementTeam> getManagementTeamsByStateAndActive(@Param("smeUuid") String smeUuid,
			@Param("state") ItemState state, @Param("active") boolean active);

	@Query("select t from SMEInformation s JOIN s.managementTeams t where s.sUuid=:smeUuid AND t.active=:active")
	List<ManagementTeam> getManagementTeamsByActive(@Param("smeUuid") String smeUuid, @Param("active") boolean active);

	@Query("select g from SMEInformation s JOIN s.galleries g where s.sUuid=:smeUuid")
	List<Gallery> getGalleries(@Param("smeUuid") String smeUuid);

	@Query("select g from SMEInformation s JOIN s.galleries g where s.sUuid=:smeUuid AND g.itemState=:state AND g.active=:active")
	List<Gallery> getGalleriesByStateAndActive(@Param("smeUuid") String smeUuid, @Param("state") ItemState state,
			@Param("active") boolean active);

	@Query("select g from SMEInformation s JOIN s.galleries g where s.sUuid=:smeUuid AND g.active=:active")
	List<Gallery> getGalleriesByActive(@Param("smeUuid") String smeUuid, @Param("active") boolean active);

	// Count of Infras
	@Query("select COUNT(i) from SMEInformation s JOIN s.infrastructures i where s.sUuid=:smeUuid")
	int infrasCountBySmeId(@Param("smeUuid") String smeUuid);

	@Query("select COUNT(i) from SMEInformation s JOIN s.infrastructures i where s.sUuid=:smeUuid AND i.active=:active AND i.itemState=:state")
	int infrasCountBySmeIdAndActiveAndState(@Param("smeUuid") String smeUuid, @Param("active") Boolean active,
			@Param("state") ItemState state);

	// Count of Certificates
	@Query("select COUNT(c) from SMEInformation s JOIN s.certificates c where s.sUuid=:smeUuid")
	int certificatesCountBySmeId(@Param("smeUuid") String smeUuid);

	@Query("select COUNT(c) from SMEInformation s JOIN s.certificates c where s.sUuid=:smeUuid AND c.active=:active AND c.itemState=:state")
	int certificatesCountBySmeIdAndActiveAndState(@Param("smeUuid") String smeUuid, @Param("active") Boolean active,
			@Param("state") ItemState state);

	// Count of Teams
	@Query("select COUNT(t) from SMEInformation s JOIN s.managementTeams t where s.sUuid=:smeUuid")
	int teamsCountBySmeId(@Param("smeUuid") String smeUuid);

	@Query("select COUNT(t) from SMEInformation s JOIN s.managementTeams t where s.sUuid=:smeUuid AND t.active=:active AND t.itemState=:state")
	int teamsCountBySmeIdAndActiveAndState(@Param("smeUuid") String smeUuid, @Param("active") Boolean active,
			@Param("state") ItemState state);

	// Count of Galleries
	@Query("select COUNT(g) from SMEInformation s JOIN s.galleries g where s.sUuid=:smeUuid")
	int galleriesCountBySmeId(@Param("smeUuid") String smeUuid);

	@Query("select COUNT(g) from SMEInformation s JOIN s.galleries g where s.sUuid=:smeUuid AND g.active=:active AND g.itemState=:state")
	int galleriesCountBySmeIdAndActiveAndState(@Param("smeUuid") String smeUuid, @Param("active") Boolean active,
			@Param("state") ItemState state);

	// check given smeId has a validate data
	@Query("select case when (count(i) > 0)  then true else false end  from SMEInformation s JOIN s.infrastructures i where s.sUuid=:smeUuid AND i.infraUuid=:infraUuid")
	boolean isSMEHasGivenInfrastructure(@Param("smeUuid") String smeUuid, @Param("infraUuid") String infraUuid);

	@Query("select case when (count(c) > 0)  then true else false end  from SMEInformation s JOIN s.certificates c where s.sUuid=:smeUuid AND c.crtiUuid=:crtiUuid")
	boolean isSMEHasGivenCertificate(@Param("smeUuid") String smeUuid, @Param("crtiUuid") String crtiUuid);

	@Query("select case when (count(t) > 0)  then true else false end  from SMEInformation s JOIN s.managementTeams t where s.sUuid=:smeUuid AND t.teamUuid=:teamUuid")
	boolean isSMEHasGivenTeam(@Param("smeUuid") String smeUuid, @Param("teamUuid") String teamUuid);

	@Query("select case when (count(g) > 0)  then true else false end  from SMEInformation s JOIN s.galleries g where s.sUuid=:smeUuid AND g.galleryUuid=:galleryUuid")
	boolean isSMEHasGivenGallery(@Param("smeUuid") String smeUuid, @Param("galleryUuid") String teamUuid);

	// find sme by sub objects (need to find by child entity with bidirectional
	// mapping)
	@Query("select new com.gloqr.entities.SMEInformation(s.sUuid,s.smeName,s.contactEmail) from SMEInformation s JOIN s.infrastructures i where s.active=true AND i.infraUuid=:infraUuid")
	SMEInformation findActiveTrueSMEByInfraUuid(@Param("infraUuid") String infraUuid);

	@Query("select new com.gloqr.entities.SMEInformation(s.sUuid,s.smeName,s.contactEmail) from SMEInformation s JOIN s.certificates c where s.active=true AND c.crtiUuid=:crtiUuid")
	SMEInformation findActiveTrueSMEByCrtiUuid(@Param("crtiUuid") String crtiUuid);

	@Query("select new com.gloqr.entities.SMEInformation(s.sUuid,s.smeName,s.contactEmail) from SMEInformation s JOIN s.managementTeams t where s.active=true AND t.teamUuid=:teamUuid")
	SMEInformation findActiveTrueSMEByTeamUuid(@Param("teamUuid") String teamUuid);

	@Query("select new com.gloqr.entities.SMEInformation(s.sUuid,s.smeName,s.contactEmail) from SMEInformation s JOIN s.galleries g where s.active=true AND g.galleryUuid=:galleryUuid")
	SMEInformation findActiveTrueSMEByGalleryUuid(@Param("galleryUuid") String teamUuid);

	@Query("SELECT new com.gloqr.model.ItemsCountUpdate(COUNT(c),COUNT(CASE WHEN c.active=1 AND c.itemState='APPROVED' THEN 1 END) ,COUNT(CASE WHEN c.active=1 AND c.itemState='PENDING' THEN 1 END)) FROM SMEInformation s JOIN s.certificates c where s.sUuid=:smeUuid")
	ItemsCountUpdate getCertifiacteCounts(@Param("smeUuid") String smeUuid);

	@Query("SELECT new com.gloqr.model.ItemsCountUpdate(COUNT(i),COUNT(CASE WHEN i.active=1 AND i.itemState='APPROVED' THEN 1 END) ,COUNT(CASE WHEN i.active=1 AND i.itemState='PENDING' THEN 1 END)) FROM SMEInformation s JOIN s.infrastructures i where s.sUuid=:smeUuid")
	ItemsCountUpdate getInfraCounts(@Param("smeUuid") String smeUuid);

	@Query("SELECT new com.gloqr.model.ItemsCountUpdate(COUNT(t),COUNT(CASE WHEN t.active=1 AND t.itemState='APPROVED' THEN 1 END) ,COUNT(CASE WHEN t.active=1 AND t.itemState='PENDING' THEN 1 END)) FROM SMEInformation s JOIN s.managementTeams t where s.sUuid=:smeUuid")
	ItemsCountUpdate getTeamCounts(@Param("smeUuid") String smeUuid);

	@Query("SELECT new com.gloqr.model.ItemsCountUpdate(COUNT(g),COUNT(CASE WHEN g.active=1 AND g.itemState='APPROVED' THEN 1 END) ,COUNT(CASE WHEN g.active=1 AND g.itemState='PENDING' THEN 1 END)) FROM SMEInformation s JOIN s.galleries g where s.sUuid=:smeUuid")
	ItemsCountUpdate getGalleryCounts(@Param("smeUuid") String smeUuid);

	@Query("SELECT s.sUuid from SMEInformation s")
	List<String> getSMEIDs();

	@Query("SELECT c from SMEInformation s JOIN s.itemsCount c where s.sUuid=:smeUuid")
	SMEItemsCount getSmeItemsCount(@Param("smeUuid") String smeUuid);

	// Circle Suggestions
	@Query("SELECT s from SMEInformation s JOIN s.smeAddress a where s.sUuid NOT IN :excludeSmeUuids AND s.active=1 ORDER BY CASE WHEN a.locality=:area THEN 1 WHEN a.city=:city THEN 2 ELSE a.city END ASC")
	List<SMEInformation> getCircleSuggestions(@Param("excludeSmeUuids") Set<String> excludeSmeUuids,
			@Param("area") String area, @Param("city") String city, Pageable pageable);

}
