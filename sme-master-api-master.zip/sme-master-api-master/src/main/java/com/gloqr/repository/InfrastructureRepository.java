package com.gloqr.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gloqr.constants.ItemState;
import com.gloqr.entities.Infrastructure;

public interface InfrastructureRepository extends JpaRepository<Infrastructure, Long> {
	public Infrastructure findByInfraUuid(String infraUuid);

	boolean existsByInfraUuid(String infraUuid);

	@Modifying
	@Transactional
	@Query("update Infrastructure i set i.active= :active where i.infraUuid= :infraUuid")
	public void updateStatus(@Param("infraUuid") String infraUuid, @Param("active") boolean active);

	public boolean existsByInfraUuidAndItemState(String id, ItemState rejected);

	@Query("SELECT i FROM Infrastructure i where i.infraUuid IN :infraIds")
	public List<Infrastructure> findByInfrasUuIdIn(@Param("infraIds") List<String> infraIds);

	@Modifying
	@Transactional
	@Query("update Infrastructure i set i.businessPostAlreadyActivated=true where i.infraUuid= :infraUuid")
	public void updateBusinessPostAlreadyActivatedByTrue(@Param("infraUuid") String infraUuid);

	@Modifying
	@Transactional
	@Query("update Infrastructure i set i.businessPost=false where i.infraUuid= :infraUuid")
	public void updateBusinessPostByFalse(@Param("infraUuid") String infraUuid);

}
