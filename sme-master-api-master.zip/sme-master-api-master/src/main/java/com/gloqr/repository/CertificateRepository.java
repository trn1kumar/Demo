package com.gloqr.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gloqr.constants.ItemState;
import com.gloqr.entities.Certificate;
import com.gloqr.entities.Image;

public interface CertificateRepository extends JpaRepository<Certificate, Long> {

	Certificate findByCrtiUuid(String crtiUuid);

	boolean existsByCrtiUuid(String crtiUuid);

	@Modifying
	@Transactional
	@Query("update Certificate c set c.active= :active where c.crtiUuid= :crtiUuid")
	public void updateStatus(@Param("crtiUuid") String crtiUuid, @Param("active") boolean active);

	boolean existsByCrtiUuidAndItemState(String id, ItemState rejected);

	@Query("Select c.images from Certificate c where c.crtiUuid= :certificateId")
	List<Image> getImages(@Param("certificateId") String certificateId);

}
