package com.gloqr.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.gloqr.entities.Image;

public interface ImageRepository extends JpaRepository<Image, Long> {
	Image findByImgUuid(String imgUuid);

	Image findByImageLocation(String imageLocation);

	List<Image> findByImgUuidIn(Set<String> imgIds);

	@Transactional
	@Modifying
	@Query("update Image i set i.active= :status where i.imgUuid IN :ids")
	void updateMultipleImagesStatus(@Param("ids") Set<String> imgIds, @Param("status") boolean status);

	@Transactional
	@Modifying
	@Query("update Image i set i.businessPostImage= false where i.imageLocation IN :imageLocations")
	void updateImagesByBusinessPostFalse(@Param("imageLocations") Set<String> imageLocations);

	void deleteByImageLocation(String imageLocation);

}
