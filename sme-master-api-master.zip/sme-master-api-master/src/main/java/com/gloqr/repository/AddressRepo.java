package com.gloqr.repository;

import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gloqr.entities.Address;

public interface AddressRepo extends JpaRepository<Address, Long> {

	/*@Query("Select DISTINCT a.city from Address a JOIN a.sme s JOIN s.smeCategory c where c.categoryUrl=:categoryUrl")
	public Set<String> getCities(@Param("categoryUrl") String categoryUrl);

	@Query("Select COUNT (a.city) from Address a JOIN a.sme s JOIN s.smeCategory c where a.city=:city AND c.categoryUrl=:categoryUrl")
	public Long countByCity(@Param("city") String city, @Param("categoryUrl") String categoryUrl);*/
	
	@Query("Select DISTINCT a.city from Address a")
	public Set<String> getCitiesOfSMEActiveTrue();

	@Query("Select COUNT (a.city) from Address a where a.city=:city")
	public Long countByCityOfSMEActiveTrue(@Param("city") String city);
	
	

}
