package com.gloqr.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gloqr.entities.TurnOver;

@Repository
public interface TurnOverRepo extends JpaRepository<TurnOver, Long>{

}
