package com.gloqr.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.gloqr.entities.SMECategory;

public interface SMECategoryRepository extends JpaRepository<SMECategory, Long> {

	SMECategory findByCategoryUuid(String categoryUuid);

	SMECategory findByCategoryUrl(String categoryUrl);
}
