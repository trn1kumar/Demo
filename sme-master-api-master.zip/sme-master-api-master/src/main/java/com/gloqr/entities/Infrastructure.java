package com.gloqr.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.gloqr.audit.Auditable;
import com.gloqr.constants.ItemState;

@Entity
@Table(name = "sme_infrastructure")
public class Infrastructure extends Auditable<String> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 651771935293529105L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "infrastructure_id")
	private Long id;

	@Column(name = "infra_uuid")
	private String infraUuid;

	@Column(name = "machine_name")
	private String machineName;

	@Column(name = "manufacturer")
	private String manufacturer;

	@Column(name = "model_name")
	private String modelName;

	@Column(name = "itemState", length = 15)
	@Enumerated(EnumType.STRING)
	private ItemState itemState;

	@Column(columnDefinition = "TEXT")
	private String feedbackMessage;

	@Column(name = "is_modified")
	private boolean infraModified;

	@Column(name = "is_business_post")
	private boolean businessPost;

	@Column(name = "is_business_post_activated")
	private boolean businessPostAlreadyActivated;

	@Column(name = "isActive")
	private boolean active;

	@OneToMany(cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.DETACH }, fetch = FetchType.LAZY)
	@JoinColumn(name = "infrastructure_id")
	private List<Image> images;

	@Column(name = "machine_description", length = 500)
	private String description;

	@Column(name = "machine_quantity", length = 50)
	private String quantity;

	@Column(name = "machine_capacity", length = 50)
	private String capacity;

	public Infrastructure() {
		super();
	}

	public Infrastructure(String infraUuid, String machineName, String description, List<Image> images) {
		this.infraUuid = infraUuid;
		this.machineName = machineName;
		this.description = description;
		this.images = images;
	}

	public ItemState getItemState() {
		return itemState;
	}

	public void setItemState(ItemState itemState) {
		this.itemState = itemState;
	}

	public boolean isInfraModified() {
		return infraModified;
	}

	public boolean isBusinessPostAlreadyActivated() {
		return businessPostAlreadyActivated;
	}

	public void setBusinessPostAlreadyActivated(boolean businessPostAlreadyActivated) {
		this.businessPostAlreadyActivated = businessPostAlreadyActivated;
	}

	public void setInfraModified(boolean infraModified) {
		this.infraModified = infraModified;
	}

	public String getFeedbackMessage() {
		return feedbackMessage;
	}

	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMachineName() {
		return machineName;
	}

	public boolean isActive() {
		return active;
	}

	public boolean isBusinessPost() {
		return businessPost;
	}

	public void setBusinessPost(boolean businessPost) {
		this.businessPost = businessPost;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setMachineName(String machineName) {
		this.machineName = machineName;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getCapacity() {
		return capacity;
	}

	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}

	public String getInfraUuid() {
		return infraUuid;
	}

	public void setInfraUuid(String infraUuid) {
		this.infraUuid = infraUuid;
	}

	public List<Image> getImages() {
		return images;
	}

	public void setImages(List<Image> images) {
		this.images = images;
	}

}