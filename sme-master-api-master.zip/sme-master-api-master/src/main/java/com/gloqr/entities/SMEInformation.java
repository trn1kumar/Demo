package com.gloqr.entities;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.apache.lucene.analysis.core.LowerCaseFilterFactory;
import org.apache.lucene.analysis.ngram.EdgeNGramFilterFactory;
import org.apache.lucene.analysis.snowball.SnowballPorterFilterFactory;
import org.apache.lucene.analysis.standard.StandardTokenizerFactory;
import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Analyzer;
import org.hibernate.search.annotations.AnalyzerDef;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;
import org.hibernate.search.annotations.Parameter;
import org.hibernate.search.annotations.Store;
import org.hibernate.search.annotations.TokenFilterDef;
import org.hibernate.search.annotations.TokenizerDef;

import com.gloqr.audit.Auditable;
import com.gloqr.constants.RegisteredType;
import com.gloqr.constants.SMEType;

@Entity
@Table(name = "sme")
@AnalyzerDef(name = "edgecustomanalyzer1", tokenizer = @TokenizerDef(factory = StandardTokenizerFactory.class), filters = {
		@TokenFilterDef(factory = LowerCaseFilterFactory.class),
		@TokenFilterDef(factory = SnowballPorterFilterFactory.class, params = {
				@Parameter(name = "language", value = "English") }),
		@TokenFilterDef(factory = EdgeNGramFilterFactory.class, params = {
				@Parameter(name = "maxGramSize", value = "25"), @Parameter(name = "minGramSize", value = "1") }) })

@AnalyzerDef(name = "customanalyzer", tokenizer = @TokenizerDef(factory = StandardTokenizerFactory.class), filters = {
		@TokenFilterDef(factory = LowerCaseFilterFactory.class),
		@TokenFilterDef(factory = SnowballPorterFilterFactory.class, params = {
				@Parameter(name = "language", value = "English") })

})
@Indexed
public class SMEInformation extends Auditable<String> {

	private static final long serialVersionUID = 8901118944757791531L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "sme_id")
	@DocumentId
	private Long smeId;

	@Column(name = "user_id", unique = true, updatable = false)
	private String uuid;

	@Column(name = "sUuid", unique = true, updatable = false)
	private String sUuid;

	@Column(name = "sme_name")
	@Field(index = Index.YES, store = Store.YES, analyze = Analyze.YES)
	@Analyzer(definition = "edgecustomanalyzer1")
	private String smeName;

	@Column(name = "one_line_statement")
	private String oneLineStatement;

	@Column(name = "company_description", length = 1000)
	private String companyDescription;

	@Column(name = "contact_person")
	private String contactPerson;

	@Column(name = "contact_email")
	private String contactEmail;

	@Column(name = "contact_phone")
	private String contactPhone;

	@Column(name = "sme_type")
	@Enumerated(EnumType.STRING)
	private SMEType smeType;

	@Column(name = "registered_type")
	@Enumerated(EnumType.STRING)
	private RegisteredType registeredType;

	@Column(name = "year_of_establishment")
	private Date yearOfEstablishment;

	@Column(name = "number_of_employees")
	private Integer numberOfEmployees;

	@Column(name = "gstin", unique = true)
	private String gstin;

	@Column(name = "logo_image")
	private String logoImage;

	@Column(name = "latitude")
	private double latitude;

	@Column(name = "longitude")
	private double longitude;

	@Column(name = "google_map_link")
	private String googlemapLink;

	@Column(name = "accepted_terms_condition")
	private boolean acceptedTermsCondition;

	@Column(name = "sme_active")
	@Field(index = Index.YES, store = Store.NO, analyze = Analyze.NO)
	private boolean active;

	@Column(name = "is_verified")
	@Field(index = Index.YES, store = Store.NO, analyze = Analyze.NO)
	private boolean verified;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "trun_over_id")
	private TurnOver turnOver;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "category_id")
	@IndexedEmbedded(includeEmbeddedObjectId = true)
	private SMECategory smeCategory;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "other_category_id")
	private OtherCategory otherCategory;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "sme_address_id", nullable = false)
	@IndexedEmbedded
	private Address smeAddress;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "items_count_id", nullable = false, updatable = false)
	@IndexedEmbedded
	private SMEItemsCount itemsCount;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "sme_id")
	private List<Image> homeSliderImages;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "sme_id", nullable = false)
	private List<ManagementTeam> managementTeams;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "sme_id", nullable = false)
	private List<Infrastructure> infrastructures;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "sme_id", nullable = false)
	private List<Certificate> certificates;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "sme_id", nullable = false)
	private List<Gallery> galleries;

	public SMEInformation() {
		super();
	}

	public SMEInformation(String sUuid, String smeName, String contactEmail) {
		super();
		this.sUuid = sUuid;
		this.smeName = smeName;
		this.contactEmail = contactEmail;
	}

	public Long getSmeId() {
		return smeId;
	}

	public void setSmeId(Long smeId) {
		this.smeId = smeId;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public String getSmeName() {
		return smeName;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public String getOneLineStatement() {
		return oneLineStatement;
	}

	public void setOneLineStatement(String oneLineStatement) {
		this.oneLineStatement = oneLineStatement;
	}

	public String getCompanyDescription() {
		return companyDescription;
	}

	public void setCompanyDescription(String companyDescription) {
		this.companyDescription = companyDescription;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

	public SMEType getSmeType() {
		return smeType;
	}

	public void setSmeType(SMEType smeType) {
		this.smeType = smeType;
	}

	public RegisteredType getRegisteredType() {
		return registeredType;
	}

	public void setRegisteredType(RegisteredType registeredType) {
		this.registeredType = registeredType;
	}

	public Date getYearOfEstablishment() {
		return yearOfEstablishment;
	}

	public void setYearOfEstablishment(Date yearOfEstablishment) {
		this.yearOfEstablishment = yearOfEstablishment;
	}

	public Integer getNumberOfEmployees() {
		return numberOfEmployees;
	}

	public void setNumberOfEmployees(Integer numberOfEmployees) {
		this.numberOfEmployees = numberOfEmployees;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getLogoImage() {
		return logoImage;
	}

	public void setLogoImage(String logoImage) {
		this.logoImage = logoImage;
	}

	public String getGooglemapLink() {
		return googlemapLink;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public void setGooglemapLink(String googlemapLink) {
		this.googlemapLink = googlemapLink;
	}

	public boolean isAcceptedTermsCondition() {
		return acceptedTermsCondition;
	}

	public void setAcceptedTermsCondition(boolean acceptedTermsCondition) {
		this.acceptedTermsCondition = acceptedTermsCondition;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public TurnOver getTurnOver() {
		return turnOver;
	}

	public void setTurnOver(TurnOver turnOver) {
		this.turnOver = turnOver;
	}

	public SMECategory getSmeCategory() {
		return smeCategory;
	}

	public void setSmeCategory(SMECategory smeCategory) {
		this.smeCategory = smeCategory;
	}

	public Address getSmeAddress() {
		return smeAddress;
	}

	public void setSmeAddress(Address smeAddress) {
		this.smeAddress = smeAddress;
	}

	public List<Image> getHomeSliderImages() {
		return homeSliderImages;
	}

	public void setHomeSliderImages(List<Image> homeSliderImages) {
		this.homeSliderImages = homeSliderImages;
	}

	public List<ManagementTeam> getManagementTeams() {
		return managementTeams;
	}

	public void setManagementTeams(List<ManagementTeam> managementTeams) {
		this.managementTeams = managementTeams;
	}

	public List<Infrastructure> getInfrastructures() {
		return infrastructures;
	}

	public void setInfrastructures(List<Infrastructure> infrastructures) {
		this.infrastructures = infrastructures;
	}

	public List<Certificate> getCertificates() {
		return certificates;
	}

	public void setCertificates(List<Certificate> certificates) {
		this.certificates = certificates;
	}

	public List<Gallery> getGalleries() {
		return galleries;
	}

	public void setGalleries(List<Gallery> galleries) {
		this.galleries = galleries;
	}

	public OtherCategory getOtherCategory() {
		return otherCategory;
	}

	public void setOtherCategory(OtherCategory otherCategory) {
		this.otherCategory = otherCategory;
	}

	public boolean isVerified() {
		return verified;
	}

	public void setVerified(boolean verified) {
		this.verified = verified;
	}

	public SMEItemsCount getItemsCount() {
		return itemsCount;
	}

	public void setItemsCount(SMEItemsCount itemsCount) {
		this.itemsCount = itemsCount;
	}

}
