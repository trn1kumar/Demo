package com.gloqr.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.gloqr.audit.Auditable;
import com.gloqr.constants.ItemState;

@Entity
@Table(name = "sme_gallery")
public class Gallery extends Auditable<String> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5067609350479704331L;

	@Id
	@GeneratedValue
	@Column(name = "galleryId")
	private Long galleryId;

	@Column(name = "gallery_uuid", updatable = false, unique = true)
	private String galleryUuid;

	@Column(name = "galleryTitle", length = 150)
	private String galleryTitle;

	@Column(name = "description", length = 1000)
	private String description;

	@Column(name = "itemState", length = 15)
	@Enumerated(EnumType.STRING)
	private ItemState itemState;

	@Column(columnDefinition = "TEXT")
	private String feedbackMessage;

	@Column(name = "is_modified")
	private boolean galleryModified;

	@Column(name = "isActive")
	private boolean active;

	@OneToMany(cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.DETACH }, fetch = FetchType.LAZY)
	@JoinColumn(name = "galleryId")
	private List<Image> images;

	public String getFeedbackMessage() {
		return feedbackMessage;
	}

	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}

	public boolean isGalleryModified() {
		return galleryModified;
	}

	public void setGalleryModified(boolean galleryModified) {
		this.galleryModified = galleryModified;
	}

	public ItemState getItemState() {
		return itemState;
	}

	public void setItemState(ItemState itemState) {
		this.itemState = itemState;
	}

	public String getGalleryTitle() {
		return galleryTitle;
	}

	public void setGalleryTitle(String galleryTitle) {
		this.galleryTitle = galleryTitle;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Long getGalleryId() {
		return galleryId;
	}

	public void setGalleryId(Long galleryId) {
		this.galleryId = galleryId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<Image> getImages() {
		return images;
	}

	public void setImages(List<Image> images) {
		this.images = images;
	}

	public String getGalleryUuid() {
		return galleryUuid;
	}

	public void setGalleryUuid(String galleryUuid) {
		this.galleryUuid = galleryUuid;
	}

}
