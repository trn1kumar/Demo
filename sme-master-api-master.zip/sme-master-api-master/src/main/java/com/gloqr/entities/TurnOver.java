package com.gloqr.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gloqr.constants.TurnOverUnit;

@Entity
@Table(name = "sme_turn_over")
public class TurnOver implements Serializable {

	private static final long serialVersionUID = 533140415654612655L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "trun_over_id")
	@JsonIgnore
	private Long trunOverId;

	@Column(name = "totalTurnOver")
	@Min(message="{min.turnOver}", value = 0)
	private float totalTurnOver;

	@Column(name = "unit")
	@Enumerated(EnumType.STRING)
	private TurnOverUnit turnOverUnit;

	public Long getTrunOverId() {
		return trunOverId;
	}

	public void setTrunOverId(Long trunOverId) {
		this.trunOverId = trunOverId;
	}

	public float getTotalTurnOver() {
		return totalTurnOver;
	}

	public void setTotalTurnOver(float totalTurnOver) {
		this.totalTurnOver = totalTurnOver;
	}

	public TurnOverUnit getTurnOverUnit() {
		return turnOverUnit;
	}

	public void setTurnOverUnit(TurnOverUnit turnOverUnit) {
		this.turnOverUnit = turnOverUnit;
	}


}
