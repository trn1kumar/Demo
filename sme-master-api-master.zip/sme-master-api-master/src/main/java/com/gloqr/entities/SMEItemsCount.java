package com.gloqr.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;

@Entity
@Table(name = "sme_items_count")
public class SMEItemsCount implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6698343616595186914L;
	
	

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "items_count_id")
	@DocumentId
	private Long itemsCountId;
	
	@OneToOne(mappedBy = "itemsCount", fetch = FetchType.LAZY)
	@ContainedIn
	private SMEInformation smeInformation;

	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	private int totalCertificates;
	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	@Field(index = Index.YES, analyze = Analyze.NO)
	private int activePendingCertificates;
	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	private int activeApprovedCertificates;

	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	private int totalInfras;
	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	@Field(index = Index.YES, analyze = Analyze.NO)
	private int activePendingInfras;
	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	private int activeApprovedInfras;

	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	private int totalTeams;
	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	@Field(index = Index.YES, analyze = Analyze.NO)
	private int activePendingTeams;
	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	private int activeApprovedTeams;

	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	private int totalGalleries;
	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	@Field(index = Index.YES, analyze = Analyze.NO)
	private int activePendingGalleries;
	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	private int activeApprovedGalleries;

	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	private int totalVacancies;
	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	@Field(index = Index.YES, analyze = Analyze.NO)
	private int activePendingVacancies;
	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	private int activeApprovedVacancies;

	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	private int totalProducts;
	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	@Field(index = Index.YES, analyze = Analyze.NO)
	private int activePendingProducts;
	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	private int activeApprovedProducts;

	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	private int totalServices;
	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	@Field(index = Index.YES, analyze = Analyze.NO)
	private int activePendingServices;
	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	private int activeApprovedServices;

	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	private int totalBusinessPosts;
	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	@Field(index = Index.YES, analyze = Analyze.NO)
	private int activePendingBusinessPosts;
	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	private int activeApprovedBusinessPosts;
	
	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	
	@Field(index = Index.YES, analyze = Analyze.NO)
	private int pendingOfflinePaymentVerification;
	
	@Column(columnDefinition = "BIGINT(20) UNSIGNED")
	private int biCounts;

	public Long getItemsCountId() {
		return itemsCountId;
	}

	public void setItemsCountId(Long itemsCountId) {
		this.itemsCountId = itemsCountId;
	}

	public int getTotalCertificates() {
		return totalCertificates;
	}

	public void setTotalCertificates(int totalCertificates) {
		this.totalCertificates = totalCertificates;
	}

	public int getActivePendingCertificates() {
		return activePendingCertificates;
	}

	public void setActivePendingCertificates(int activePendingCertificates) {
		this.activePendingCertificates = activePendingCertificates;
	}

	public int getActiveApprovedCertificates() {
		return activeApprovedCertificates;
	}

	public void setActiveApprovedCertificates(int activeApprovedCertificates) {
		this.activeApprovedCertificates = activeApprovedCertificates;
	}

	public int getTotalInfras() {
		return totalInfras;
	}

	public void setTotalInfras(int totalInfras) {
		this.totalInfras = totalInfras;
	}

	public int getActivePendingInfras() {
		return activePendingInfras;
	}

	public void setActivePendingInfras(int activePendingInfras) {
		this.activePendingInfras = activePendingInfras;
	}

	public int getActiveApprovedInfras() {
		return activeApprovedInfras;
	}

	public void setActiveApprovedInfras(int activeApprovedInfras) {
		this.activeApprovedInfras = activeApprovedInfras;
	}

	public int getTotalTeams() {
		return totalTeams;
	}

	public void setTotalTeams(int totalTeams) {
		this.totalTeams = totalTeams;
	}

	public int getActivePendingTeams() {
		return activePendingTeams;
	}

	public void setActivePendingTeams(int activePendingTeams) {
		this.activePendingTeams = activePendingTeams;
	}

	public int getActiveApprovedTeams() {
		return activeApprovedTeams;
	}

	public void setActiveApprovedTeams(int activeApprovedTeams) {
		this.activeApprovedTeams = activeApprovedTeams;
	}

	public int getTotalGalleries() {
		return totalGalleries;
	}

	public void setTotalGalleries(int totalGalleries) {
		this.totalGalleries = totalGalleries;
	}

	public int getActivePendingGalleries() {
		return activePendingGalleries;
	}

	public void setActivePendingGalleries(int activePendingGalleries) {
		this.activePendingGalleries = activePendingGalleries;
	}

	public int getActiveApprovedGalleries() {
		return activeApprovedGalleries;
	}

	public void setActiveApprovedGalleries(int activeApprovedGalleries) {
		this.activeApprovedGalleries = activeApprovedGalleries;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public int getTotalVacancies() {
		return totalVacancies;
	}

	public void setTotalVacancies(int totalVacancies) {
		this.totalVacancies = totalVacancies;
	}

	public int getActivePendingVacancies() {
		return activePendingVacancies;
	}

	public void setActivePendingVacancies(int activePendingVacancies) {
		this.activePendingVacancies = activePendingVacancies;
	}

	public int getActiveApprovedVacancies() {
		return activeApprovedVacancies;
	}

	public void setActiveApprovedVacancies(int activeApprovedVacancies) {
		this.activeApprovedVacancies = activeApprovedVacancies;
	}

	public int getTotalProducts() {
		return totalProducts;
	}

	public void setTotalProducts(int totalProducts) {
		this.totalProducts = totalProducts;
	}

	public int getActivePendingProducts() {
		return activePendingProducts;
	}

	public void setActivePendingProducts(int activePendingProducts) {
		this.activePendingProducts = activePendingProducts;
	}

	public int getActiveApprovedProducts() {
		return activeApprovedProducts;
	}

	public void setActiveApprovedProducts(int activeApprovedProducts) {
		this.activeApprovedProducts = activeApprovedProducts;
	}

	public int getActivePendingServices() {
		return activePendingServices;
	}

	public void setActivePendingServices(int activePendingServices) {
		this.activePendingServices = activePendingServices;
	}

	public int getActiveApprovedServices() {
		return activeApprovedServices;
	}

	public void setActiveApprovedServices(int activeApprovedServices) {
		this.activeApprovedServices = activeApprovedServices;
	}

	public int getTotalBusinessPosts() {
		return totalBusinessPosts;
	}

	public void setTotalBusinessPosts(int totalBusinessPosts) {
		this.totalBusinessPosts = totalBusinessPosts;
	}

	public int getActivePendingBusinessPosts() {
		return activePendingBusinessPosts;
	}

	public void setActivePendingBusinessPosts(int activePendingBusinessPosts) {
		this.activePendingBusinessPosts = activePendingBusinessPosts;
	}

	public int getTotalServices() {
		return totalServices;
	}

	public void setTotalServices(int totalServices) {
		this.totalServices = totalServices;
	}

	public int getActiveApprovedBusinessPosts() {
		return activeApprovedBusinessPosts;
	}

	public void setActiveApprovedBusinessPosts(int activeApprovedBusinessPosts) {
		this.activeApprovedBusinessPosts = activeApprovedBusinessPosts;
	}

	public SMEInformation getSmeInformation() {
		return smeInformation;
	}

	public void setSmeInformation(SMEInformation smeInformation) {
		this.smeInformation = smeInformation;
	}

	public int getPendingOfflinePaymentVerification() {
		return pendingOfflinePaymentVerification;
	}

	public void setPendingOfflinePaymentVerification(int pendingOfflinePaymentVerification) {
		this.pendingOfflinePaymentVerification = pendingOfflinePaymentVerification;
	}

	public int getBiCounts() {
		return biCounts;
	}

	public void setBiCounts(int biCounts) {
		this.biCounts = biCounts;
	}

}
