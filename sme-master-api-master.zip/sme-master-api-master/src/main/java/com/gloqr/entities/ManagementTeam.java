package com.gloqr.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.gloqr.audit.Auditable;
import com.gloqr.constants.ItemState;

@Entity
@Table(name = "sme_mangement_team")
public class ManagementTeam extends Auditable<String> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3766699367822961501L;

	@Id
	@GeneratedValue
	@Column(name = "management_team_id")
	private Long teamId;

	@Column(name = "team_uuid", updatable = false, unique = true)
	private String teamUuid;

	@Column(name = "Full_Name", length = 100)
	private String fullName;

	@Column(name = "Designation", length = 100)
	private String designation;

	@Column(name = "Experience")
	private Long experience;

	@Column(name = "mail_id")
	private String mail;

	@Column(name = "Profile_Description", length = 500)
	private String profileDesc;

	@Column(name = "itemState", length = 15)
	@Enumerated(EnumType.STRING)
	private ItemState itemState;

	@Column(columnDefinition = "TEXT")
	private String feedbackMessage;

	@Column(name = "is_modified")
	private boolean teamModified;

	@Column(name = "isActive")
	private boolean active;

	@Column(name = "Facebook_Link")
	private String fbLink;

	@Column(name = "LinkedIn_Link")
	private String linkedinLink;

	@Column(name = "Twitter_Link")
	private String twitterLink;

	@OneToOne(cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.DETACH }, fetch = FetchType.EAGER)
	@JoinColumn(name = "image_id")
	private Image profileImage;

	@Transient
	private String profileImageUrl;

	public boolean isTeamModified() {
		return teamModified;
	}

	public void setTeamModified(boolean teamModified) {
		this.teamModified = teamModified;
	}

	public Long getTeamId() {
		return teamId;
	}

	public void setTeamId(Long teamId) {
		this.teamId = teamId;
	}

	public ItemState getItemState() {
		return itemState;
	}

	public String getFeedbackMessage() {
		return feedbackMessage;
	}

	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}

	public void setItemState(ItemState itemState) {
		this.itemState = itemState;
	}

	public boolean isActive() {
		return active;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Long getExperience() {
		return experience;
	}

	public void setExperience(Long experience) {
		this.experience = experience;
	}

	public String getProfileDesc() {
		return profileDesc;
	}

	public void setProfileDesc(String profileDesc) {
		this.profileDesc = profileDesc;
	}

	public String getFbLink() {
		return fbLink;
	}

	public void setFbLink(String fbLink) {
		this.fbLink = fbLink;
	}

	public String getLinkedinLink() {
		return linkedinLink;
	}

	public void setLinkedinLink(String linkedinLink) {
		this.linkedinLink = linkedinLink;
	}

	public String getTwitterLink() {
		return twitterLink;
	}

	public void setTwitterLink(String twitterLink) {
		this.twitterLink = twitterLink;
	}

	public String getTeamUuid() {
		return teamUuid;
	}

	public void setTeamUuid(String teamUuid) {
		this.teamUuid = teamUuid;
	}

	public Image getProfileImage() {
		return profileImage;
	}

	public void setProfileImage(Image profileImage) {
		this.profileImage = profileImage;
	}

	public String getProfileImageUrl() {
		return profileImageUrl;
	}

	public void setProfileImageUrl(String profileImageUrl) {
		this.profileImageUrl = profileImageUrl;
	}

}
