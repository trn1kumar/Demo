package com.gloqr.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.gloqr.audit.Auditable;
import com.gloqr.constants.ItemState;

@Entity
@Table(name = "sme_certificate")
public class Certificate extends Auditable<String> implements Serializable {

	private static final long serialVersionUID = -7779573333961493163L;

	@Id
	@GeneratedValue
	@Column(name = "certificate_id")
	private Long id;

	@Column(name = "certificate_uuid")
	private String crtiUuid;

	@Column(name = "certificate_type")
	private String certificateType;

	@Column(name = "certificate_description", length = 1000)
	private String certificateDesc;

	@Column(columnDefinition = "TEXT")
	private String feedbackMessage;

	@Column(name = "isActive")
	private boolean active;

	@Column(name = "itemState", length = 15)
	@Enumerated(EnumType.STRING)
	private ItemState itemState;

	@Column(name = "is_modified")
	private boolean certificateModified;

	@OneToMany(cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.DETACH }, fetch = FetchType.LAZY)
	@JoinColumn(name = "certificate_id")
	private List<Image> images;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCertificateType() {
		return certificateType;
	}

	public void setCertificateType(String certificateType) {
		this.certificateType = certificateType;
	}

	public String getFeedbackMessage() {
		return feedbackMessage;
	}

	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}

	public ItemState getItemState() {
		return itemState;
	}

	public void setItemState(ItemState itemState) {
		this.itemState = itemState;
	}

	public String getCertificateDesc() {
		return certificateDesc;
	}

	public void setCertificateDesc(String certificateDesc) {
		this.certificateDesc = certificateDesc;
	}

	public List<Image> getImages() {
		return images;
	}

	public void setImages(List<Image> images) {
		this.images = images;
	}

	public String getCrtiUuid() {
		return crtiUuid;
	}

	public void setCrtiUuid(String crtiUuid) {
		this.crtiUuid = crtiUuid;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean isCertificateModified() {
		return certificateModified;
	}

	public void setCertificateModified(boolean certificateModified) {
		this.certificateModified = certificateModified;
	}

}
