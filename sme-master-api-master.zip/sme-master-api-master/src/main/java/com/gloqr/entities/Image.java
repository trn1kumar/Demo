package com.gloqr.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gloqr.audit.DateAuditable;

@Entity
@Table(name = "sme_image")
public class Image extends DateAuditable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8918714585209211288L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	@JsonIgnore
	private Long imageId;

	@Column(name = "img_uuid", unique = true, updatable = false)
	private String imgUuid;

	@Column(name = "image_name")
	@JsonIgnore
	private String imageName;

	@Column(name = "image_location", unique = true, nullable = false)
	private String imageLocation;

	@Column(name = "image_location_one")
	private String imageLocationOne;

	@Column(name = "image_location_two")
	private String imageLocationTwo;

	@Column(name = "business_post_image")
	@JsonIgnore
	private boolean businessPostImage;

	@Column(name = "is_active")
	@JsonIgnore
	private boolean active;

	@Column(name = "image_size")
	@JsonIgnore
	private long size;

	public Image(String imgUuid, String imageName, String imageLocation,String imageLocationOne,String imageLocationTwo, boolean isActive, long size) {
		this.imgUuid = imgUuid;
		this.imageName = imageName;
		this.imageLocation = imageLocation;
		this.imageLocationOne=imageLocationOne;
		this.imageLocationTwo=imageLocationTwo;
		this.active = isActive;
		this.size = size;
	}

	public Image() {

	}

	public long getSize() {
		return size;
	}

	public void setSize(long size) {
		this.size = size;
	}

	public Long getImageId() {
		return imageId;
	}

	public void setImageId(Long imageId) {
		this.imageId = imageId;
	}

	public String getImgUuid() {
		return imgUuid;
	}

	public void setImgUuid(String imgUuid) {
		this.imgUuid = imgUuid;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public String getImageLocation() {
		return imageLocation;
	}

	public void setImageLocation(String imageLocation) {
		this.imageLocation = imageLocation;
	}

	public String getImageLocationOne() {
		return imageLocationOne;
	}

	public void setImageLocationOne(String imageLocationOne) {
		this.imageLocationOne = imageLocationOne;
	}

	public String getImageLocationTwo() {
		return imageLocationTwo;
	}

	public void setImageLocationTwo(String imageLocationTwo) {
		this.imageLocationTwo = imageLocationTwo;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean isActive) {
		this.active = isActive;
	}

	public boolean isBusinessPostImage() {
		return businessPostImage;
	}

	public void setBusinessPostImage(boolean businessPostImage) {
		this.businessPostImage = businessPostImage;
	}

}
