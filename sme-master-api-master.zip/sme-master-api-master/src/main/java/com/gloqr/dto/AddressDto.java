package com.gloqr.dto;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_DEFAULT)
public class AddressDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5102470276383735903L;

	private String addrsUuid;

	@NotBlank(message = "{notblank.street}")
	private String street;

	@NotBlank(message = "{notblank.locality}")
	@Pattern(regexp = "^[a-zA-Z? ]+$", message = "{pattern.locality}")
	private String locality;

	@NotBlank(message = "{notblank.city}")
	@Pattern(regexp = "^[a-zA-Z? ]+$", message = "{pattern.city}")
	private String city;

	@NotBlank(message = "{notblank.state}")
	@Pattern(regexp = "^[a-zA-Z? ]+$", message = "{pattern.state}")
	private String state;

	@NotBlank(message = "{notblank.country}")
	@Pattern(regexp = "^[a-zA-Z? ]+$", message = "{pattern.country}")
	private String country;

	// @Min(value = 6, message = "{size.pincode}")
	// @Max(value = 6, message = "{size.pincode}")
	private int pincode;

	public String getAddrsUuid() {
		return addrsUuid;
	}

	public String getStreet() {
		return street;
	}

	public String getLocality() {
		return locality;
	}

	public String getCity() {
		return city;
	}

	public String getState() {
		return state;
	}

	public String getCountry() {
		return country;
	}

	public int getPincode() {
		return pincode;
	}

	public void setAddrsUuid(String addrsUuid) {
		this.addrsUuid = addrsUuid;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

}
