package com.gloqr.dto.count;

public class EditModeItemsCount {

	private int totalCertificates;

	private int totalInfras;

	private int totalTeams;

	private int totalGalleries;

	private int totalVacancies;

	private int totalProducts;

	private int totalServices;

	private int totalBusinessPosts;

	public int getTotalCertificates() {
		return totalCertificates;
	}

	public void setTotalCertificates(int totalCertificates) {
		this.totalCertificates = totalCertificates;
	}

	public int getTotalInfras() {
		return totalInfras;
	}

	public void setTotalInfras(int totalInfras) {
		this.totalInfras = totalInfras;
	}

	public int getTotalTeams() {
		return totalTeams;
	}

	public void setTotalTeams(int totalTeams) {
		this.totalTeams = totalTeams;
	}

	public int getTotalGalleries() {
		return totalGalleries;
	}

	public void setTotalGalleries(int totalGalleries) {
		this.totalGalleries = totalGalleries;
	}

	public int getTotalVacancies() {
		return totalVacancies;
	}

	public void setTotalVacancies(int totalVacancies) {
		this.totalVacancies = totalVacancies;
	}

	public int getTotalProducts() {
		return totalProducts;
	}

	public void setTotalProducts(int totalProducts) {
		this.totalProducts = totalProducts;
	}

	public int getTotalServices() {
		return totalServices;
	}

	public void setTotalServices(int totalServices) {
		this.totalServices = totalServices;
	}

	public int getTotalBusinessPosts() {
		return totalBusinessPosts;
	}

	public void setTotalBusinessPosts(int totalBusinessPosts) {
		this.totalBusinessPosts = totalBusinessPosts;
	}

}
