package com.gloqr.dto;

import java.util.Map;

public class FilterDto {
	private Map<String, Object> filters = null;

	public FilterDto(Map<String, Object> filters) {
		this.filters = filters;
	}

	public Map<String, Object> getFilters() {
		return filters;
	}

	public void setFilters(Map<String, Object> filters) {
		this.filters = filters;
	}

}
