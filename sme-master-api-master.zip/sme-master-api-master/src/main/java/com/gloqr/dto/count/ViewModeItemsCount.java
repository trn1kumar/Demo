package com.gloqr.dto.count;

public class ViewModeItemsCount {

	private int activeApprovedCertificates;

	private int activeApprovedInfras;

	private int activeApprovedTeams;

	private int activeApprovedGalleries;

	private int activeApprovedVacancies;

	private int activeApprovedProducts;

	private int activeApprovedServices;

	private int activeApprovedBusinessPosts;

	public int getActiveApprovedCertificates() {
		return activeApprovedCertificates;
	}

	public void setActiveApprovedCertificates(int activeApprovedCertificates) {
		this.activeApprovedCertificates = activeApprovedCertificates;
	}

	public int getActiveApprovedInfras() {
		return activeApprovedInfras;
	}

	public void setActiveApprovedInfras(int activeApprovedInfras) {
		this.activeApprovedInfras = activeApprovedInfras;
	}

	public int getActiveApprovedTeams() {
		return activeApprovedTeams;
	}

	public void setActiveApprovedTeams(int activeApprovedTeams) {
		this.activeApprovedTeams = activeApprovedTeams;
	}

	public int getActiveApprovedGalleries() {
		return activeApprovedGalleries;
	}

	public void setActiveApprovedGalleries(int activeApprovedGalleries) {
		this.activeApprovedGalleries = activeApprovedGalleries;
	}

	public int getActiveApprovedVacancies() {
		return activeApprovedVacancies;
	}

	public void setActiveApprovedVacancies(int activeApprovedVacancies) {
		this.activeApprovedVacancies = activeApprovedVacancies;
	}

	public int getActiveApprovedProducts() {
		return activeApprovedProducts;
	}

	public void setActiveApprovedProducts(int activeApprovedProducts) {
		this.activeApprovedProducts = activeApprovedProducts;
	}

	public int getActiveApprovedServices() {
		return activeApprovedServices;
	}

	public void setActiveApprovedServices(int activeApprovedServices) {
		this.activeApprovedServices = activeApprovedServices;
	}

	public int getActiveApprovedBusinessPosts() {
		return activeApprovedBusinessPosts;
	}

	public void setActiveApprovedBusinessPosts(int activeApprovedBusinessPosts) {
		this.activeApprovedBusinessPosts = activeApprovedBusinessPosts;
	}

}
