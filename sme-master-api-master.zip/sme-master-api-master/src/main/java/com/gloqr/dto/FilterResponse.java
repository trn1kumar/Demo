package com.gloqr.dto;

import java.util.List;
import java.util.Map;

import com.gloqr.vo.SMEInformationVo;

public class FilterResponse extends FilterDto {

	private List<SMEInformationVo> result = null;
	private int totalSmesCount;

	public FilterResponse(Map<String, Object> filters, List<SMEInformationVo> result, int totalSmesCount) {
		super(filters);
		this.result = result;
		this.setTotalSmesCount(totalSmesCount);
	}

	public List<SMEInformationVo> getResult() {
		return result;
	}

	public void setResult(List<SMEInformationVo> result) {
		this.result = result;
	}

	public int getTotalSmesCount() {
		return totalSmesCount;
	}

	public void setTotalSmesCount(int totalSmesCount) {
		this.totalSmesCount = totalSmesCount;
	}

}
