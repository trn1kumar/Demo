package com.gloqr.dto;

import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.gloqr.audit.DateAuditable;
import com.gloqr.constants.ItemState;
import com.gloqr.entities.Image;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CertificateDto extends DateAuditable {

	private static final long serialVersionUID = 6016876920769242907L;

	private String crtiUuid;

	@Size(min = 3, max = 50, message = "{size.certificateType}")
	@NotBlank(message = "{notblank.certificateType}")
	private String certificateType;

	@Size(min = 20, max = 500, message = "{size.certificateDesc}")
	private String certificateDesc;

	private ItemState itemState;

	private boolean certificateModified;

	private boolean active;

	private String feedbackMessage;

	private List<Image> images;

	public String getCertificateType() {
		return certificateType;
	}

	public void setCertificateType(String certificateType) {
		this.certificateType = certificateType;
	}

	public String getCertificateDesc() {
		return certificateDesc;
	}

	public void setCertificateDesc(String certificateDesc) {
		this.certificateDesc = certificateDesc;
	}

	public String getCrtiUuid() {
		return crtiUuid;
	}

	public void setCrtiUuid(String crtiUuid) {
		this.crtiUuid = crtiUuid;
	}

	public List<Image> getImages() {
		return images;
	}

	public void setImages(List<Image> images) {
		this.images = images;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public ItemState getItemState() {
		return itemState;
	}

	public void setItemState(ItemState itemState) {
		this.itemState = itemState;
	}

	public boolean isCertificateModified() {
		return certificateModified;
	}

	public void setCertificateModified(boolean certificateModified) {
		this.certificateModified = certificateModified;
	}

	public String getFeedbackMessage() {
		return feedbackMessage;
	}

	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}

}
