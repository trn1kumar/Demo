package com.gloqr.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.gloqr.audit.DateAuditable;
import com.gloqr.constants.ItemState;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ManagementTeamDto extends DateAuditable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7564802349077513760L;

	private String teamUuid;

	@Pattern(regexp = "^[a-zA-Z.? ]+$", message = "{pattern.fullName}")
	@Size(min = 1, max = 100, message = "{size.fullName}")
	@NotBlank(message = "{notblank.fullName}")
	private String fullName;

	@Pattern(regexp = "^[a-zA-Z&? ]+$", message = "{pattern.designation}")
	@Size(min = 1, max = 100, message = "{size.designation}")
	@NotBlank(message = "{notblank.designation}")
	private String designation;

	@Min(value = 0, message = "{min.experience}")
	private Long experience;

	@Size(min = 10, max = 500, message = "{size.profileDesc}")
	@NotBlank(message = "{notblank.profileDesc}")
	private String profileDesc;

	private ItemState itemState;

	private boolean active;

	private boolean teamModified;

	private String feedbackMessage;

	@NotBlank(message = "{profile image required}")
	private String profileImageUrl;

	@Email(message = "{mail.team}")
	private String mail;

	private String fbLink;
	
	private String linkedinLink;

	private String twitterLink;

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Long getExperience() {
		return experience;
	}

	public void setExperience(Long experience) {
		this.experience = experience;
	}

	public String getProfileDesc() {
		return profileDesc;
	}

	public void setProfileDesc(String profileDesc) {
		this.profileDesc = profileDesc;
	}

	public String getFbLink() {
		return fbLink;
	}

	public void setFbLink(String fbLink) {
		this.fbLink = fbLink;
	}

	public String getLinkedinLink() {
		return linkedinLink;
	}

	public void setLinkedinLink(String linkedinLink) {
		this.linkedinLink = linkedinLink;
	}

	public String getTwitterLink() {
		return twitterLink;
	}

	public void setTwitterLink(String twitterLink) {
		this.twitterLink = twitterLink;
	}

	public String getTeamUuid() {
		return teamUuid;
	}

	public void setTeamUuid(String teamUuid) {
		this.teamUuid = teamUuid;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public ItemState getItemState() {
		return itemState;
	}

	public void setItemState(ItemState itemState) {
		this.itemState = itemState;
	}

	public boolean isTeamModified() {
		return teamModified;
	}

	public void setTeamModified(boolean teamModified) {
		this.teamModified = teamModified;
	}

	public String getFeedbackMessage() {
		return feedbackMessage;
	}

	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}

	public String getProfileImageUrl() {
		return profileImageUrl;
	}

	public void setProfileImageUrl(String profileImageUrl) {
		this.profileImageUrl = profileImageUrl;
	}

}
