package com.gloqr.dto;

import java.sql.Date;

import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import com.gloqr.constants.RegisteredType;
import com.gloqr.entities.TurnOver;

public class SMEDetailDto {

	@Size(min = 10, max = 1000, message = "Company Description can have min 10 and max 1000 characters")
	private String companyDescription;

	private RegisteredType registeredType;

	private String logoImage;

	private Date yearOfEstablishment;

	@Min(value = 0, message = "Number oF Employee Should not be less then 0")
	private Integer numberOfEmployees;

	private TurnOver turnOver;

	private String latitude;

	private String longitude;

	private String googlemapLink;

	public String getCompanyDescription() {
		return companyDescription;
	}

	public Date getYearOfEstablishment() {
		return yearOfEstablishment;
	}

	public Integer getNumberOfEmployees() {
		return numberOfEmployees;
	}

	public String getLatitude() {
		return latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public String getGooglemapLink() {
		return googlemapLink;
	}

	public void setCompanyDescription(String companyDescription) {
		this.companyDescription = companyDescription;
	}

	public void setYearOfEstablishment(Date yearOfEstablishment) {
		this.yearOfEstablishment = yearOfEstablishment;
	}

	public void setNumberOfEmployees(Integer numberOfEmployees) {
		this.numberOfEmployees = numberOfEmployees;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public void setGooglemapLink(String googlemapLink) {
		this.googlemapLink = googlemapLink;
	}

	public TurnOver getTurnOver() {
		return turnOver;
	}

	public void setTurnOver(TurnOver turnOver) {
		this.turnOver = turnOver;
	}

	public String getLogoImage() {
		return logoImage;
	}

	public void setLogoImage(String logoImage) {
		this.logoImage = logoImage;
	}

	public RegisteredType getRegisteredType() {
		return registeredType;
	}

	public void setRegisteredType(RegisteredType registeredType) {
		this.registeredType = registeredType;
	}

}
