package com.gloqr.dto.count;

public class GloqrAdminItemsCount {

	private int activePendingCertificates;

	private int activePendingInfras;

	private int activePendingTeams;

	private int activePendingGalleries;

	private int activePendingVacancies;

	private int activePendingProducts;

	private int activePendingServices;

	private int activePendingBusinessPosts;
	
	private int pendingOfflinePaymentVerification;

	public int getActivePendingCertificates() {
		return activePendingCertificates;
	}

	public void setActivePendingCertificates(int activePendingCertificates) {
		this.activePendingCertificates = activePendingCertificates;
	}

	public int getActivePendingInfras() {
		return activePendingInfras;
	}

	public void setActivePendingInfras(int activePendingInfras) {
		this.activePendingInfras = activePendingInfras;
	}

	public int getActivePendingTeams() {
		return activePendingTeams;
	}

	public void setActivePendingTeams(int activePendingTeams) {
		this.activePendingTeams = activePendingTeams;
	}

	public int getActivePendingGalleries() {
		return activePendingGalleries;
	}

	public void setActivePendingGalleries(int activePendingGalleries) {
		this.activePendingGalleries = activePendingGalleries;
	}

	public int getActivePendingVacancies() {
		return activePendingVacancies;
	}

	public void setActivePendingVacancies(int activePendingVacancies) {
		this.activePendingVacancies = activePendingVacancies;
	}

	public int getActivePendingProducts() {
		return activePendingProducts;
	}

	public void setActivePendingProducts(int activePendingProducts) {
		this.activePendingProducts = activePendingProducts;
	}

	public int getActivePendingServices() {
		return activePendingServices;
	}

	public void setActivePendingServices(int activePendingServices) {
		this.activePendingServices = activePendingServices;
	}

	public int getActivePendingBusinessPosts() {
		return activePendingBusinessPosts;
	}

	public void setActivePendingBusinessPosts(int activePendingBusinessPosts) {
		this.activePendingBusinessPosts = activePendingBusinessPosts;
	}

	public int getPendingOfflinePaymentVerification() {
		return pendingOfflinePaymentVerification;
	}

	public void setPendingOfflinePaymentVerification(int pendingOfflinePaymentVerification) {
		this.pendingOfflinePaymentVerification = pendingOfflinePaymentVerification;
	}

}
