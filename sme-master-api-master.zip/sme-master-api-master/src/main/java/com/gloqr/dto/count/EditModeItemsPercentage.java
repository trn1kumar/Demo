package com.gloqr.dto.count;

public class EditModeItemsPercentage {

	private float productPercentage;
	
	private float servicePercentage;

	private float certificatePercentage;

	private float infraPercentage;
	
	private float galleryPercentage;
	
	private float teamPercentage;
	
	private float jobsPercentage;
	
	private float socialPostPercentage;

	private float overAllPercentage;
	
	public float getOverAllPercentage() {
		return overAllPercentage;
	}

	public void setOverAllPercentage(float overAllPercentage) {
		this.overAllPercentage = overAllPercentage;
	}

	public float getProductPercentage() {
		return productPercentage;
	}

	public void setProductPercentage(float productPercentage) {
		this.productPercentage = productPercentage;
	}

	public float getServicePercentage() {
		return servicePercentage;
	}

	public void setServicePercentage(float servicePercentage) {
		this.servicePercentage = servicePercentage;
	}

	public float getCertificatePercentage() {
		return certificatePercentage;
	}

	public void setCertificatePercentage(float certificatePercentage) {
		this.certificatePercentage = certificatePercentage;
	}

	public float getInfraPercentage() {
		return infraPercentage;
	}

	public void setInfraPercentage(float infraPercentage) {
		this.infraPercentage = infraPercentage;
	}

	public float getGalleryPercentage() {
		return galleryPercentage;
	}

	public void setGalleryPercentage(float galleryPercentage) {
		this.galleryPercentage = galleryPercentage;
	}

	public float getTeamPercentage() {
		return teamPercentage;
	}

	public void setTeamPercentage(float teamPercentage) {
		this.teamPercentage = teamPercentage;
	}

	public float getJobsPercentage() {
		return jobsPercentage;
	}

	public void setJobsPercentage(float jobsPercentage) {
		this.jobsPercentage = jobsPercentage;
	}

	public float getSocialPostPercentage() {
		return socialPostPercentage;
	}

	public void setSocialPostPercentage(float socialPostPercentage) {
		this.socialPostPercentage = socialPostPercentage;
	}



}
