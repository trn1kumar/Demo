package com.gloqr.dto;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.gloqr.audit.DateAuditable;
import com.gloqr.constants.RegisteredType;
import com.gloqr.constants.SMEType;
import com.gloqr.entities.Image;
import com.gloqr.entities.OtherCategory;
import com.gloqr.entities.TurnOver;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class SMEInformationDto extends DateAuditable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2923046079235703521L;

	@Size(min = 2, max = 50, message = "{size.smeName}")
	@NotBlank(message = "{notblank.smeName}")
	private String smeName;

	private String sUuid;

	private String uuid;

	private SMEType smeType;

	private String oneLineStatement;

	private boolean acceptedTermsCondition;

	@Size(min = 10, max = 1000, message = "{size.companyDescription}")
	private String companyDescription;

	@Pattern(regexp = "^[a-zA-Z.? ]+$", message = "{pattern.contactPerson}")
	@NotBlank(message = "{notblank.contactPerson}")
	private String contactPerson;

	@Email(message = "{email.contactEmail}")
	@NotBlank(message = "{notblank.contactEmail}")
	private String contactEmail;

	@Size(min = 10, max = 10, message = "{size.contactPhone}")
	@Pattern(regexp = "^[0-9]+$", message = "{pattern.contactPhone}")
	@NotBlank(message = "{notblank.contactPhone}")
	private String contactPhone;

	private RegisteredType registeredType;

	private Date yearOfEstablishment;

	@Min(value = 0, message = "{min.numberOfEmployees}")
	private Integer numberOfEmployees;

	private TurnOver turnOver;

	@NotBlank(message = "{notblank.gstin}")
	@Size(min = 15, max = 15, message = "{size.gstin}")
	@Pattern(regexp = "[0-9]{2}[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9A-Za-z]{1}[Z]{1}[0-9a-zA-Z]{1}", message = "{pattern.gstin}")
	private String gstin;

	@Valid
	private AddressDto smeAddress;

	private List<Image> homeSliderImages;

	private String logoImage;

	private double latitude;

	private double longitude;

	private String googlemapLink;
	
	private OtherCategory otherCategory;

	public String getSmeName() {
		return smeName;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public String getOneLineStatement() {
		return oneLineStatement;
	}

	public void setOneLineStatement(String oneLineStatement) {
		this.oneLineStatement = oneLineStatement;
	}

	public String getCompanyDescription() {
		return companyDescription;
	}

	public void setCompanyDescription(String companyDescription) {
		this.companyDescription = companyDescription;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

	public RegisteredType getRegisteredType() {
		return registeredType;
	}

	public void setRegisteredType(RegisteredType registeredType) {
		this.registeredType = registeredType;
	}

	public Date getYearOfEstablishment() {
		return yearOfEstablishment;
	}

	public void setYearOfEstablishment(Date yearOfEstablishment) {
		this.yearOfEstablishment = yearOfEstablishment;
	}

	public Integer getNumberOfEmployees() {
		return numberOfEmployees;
	}

	public void setNumberOfEmployees(Integer numberOfEmployees) {
		this.numberOfEmployees = numberOfEmployees;
	}

	public TurnOver getTurnOver() {
		return turnOver;
	}

	public void setTurnOver(TurnOver turnOver) {
		this.turnOver = turnOver;
	}

	public SMEType getSmeType() {
		return smeType;
	}

	public void setSmeType(SMEType smeType) {
		this.smeType = smeType;
	}

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getLogoImage() {
		return logoImage;
	}

	public void setLogoImage(String logoImage) {
		this.logoImage = logoImage;
	}

	public String getGooglemapLink() {
		return googlemapLink;
	}

	public void setGooglemapLink(String googlemapLink) {
		this.googlemapLink = googlemapLink;
	}

	public AddressDto getSmeAddress() {
		return smeAddress;
	}

	public void setSmeAddress(AddressDto smeAddress) {
		this.smeAddress = smeAddress;
	}

	public boolean isAcceptedTermsCondition() {
		return acceptedTermsCondition;
	}

	public void setAcceptedTermsCondition(boolean acceptedTermsCondition) {
		this.acceptedTermsCondition = acceptedTermsCondition;
	}

	public List<Image> getHomeSliderImages() {
		return homeSliderImages;
	}

	public void setHomeSliderImages(List<Image> homeSliderImages) {
		this.homeSliderImages = homeSliderImages;
	}

	public OtherCategory getOtherCategory() {
		return otherCategory;
	}

	public void setOtherCategory(OtherCategory otherCategory) {
		this.otherCategory = otherCategory;
	}
	
	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
}
