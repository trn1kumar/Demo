package com.gloqr.dto;

import com.gloqr.vo.SMECategoryVo;

public class GLoqrSMEDto extends SMEInformationDto {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5569947923459451310L;
	private SMECategoryVo smeCategory;
	private boolean active;
	private boolean verified;

	public SMECategoryVo getSmeCategory() {
		return smeCategory;
	}

	public void setSmeCategory(SMECategoryVo smeCategory) {
		this.smeCategory = smeCategory;
	}

	public boolean isVerified() {
		return verified;
	}

	public void setVerified(boolean verified) {
		this.verified = verified;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

}
