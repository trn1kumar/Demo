package com.gloqr.dto;

public class ImageDto {

	private String imgUuid;
	private String imageName;
	private String imageLocation;
	private String imageLocationOne;
	private String imageLocationTwo;

	public String getImgUuid() {
		return imgUuid;
	}

	public void setImgUuid(String imgUuid) {
		this.imgUuid = imgUuid;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public String getImageLocation() {
		return imageLocation;
	}

	public void setImageLocation(String imageLocation) {
		this.imageLocation = imageLocation;
	}

	public String getImageLocationOne() {
		return imageLocationOne;
	}

	public void setImageLocationOne(String imageLocationOne) {
		this.imageLocationOne = imageLocationOne;
	}

	public String getImageLocationTwo() {
		return imageLocationTwo;
	}

	public void setImageLocationTwo(String imageLocationTwo) {
		this.imageLocationTwo = imageLocationTwo;
	}

}
