package com.gloqr.dto;

import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.gloqr.audit.DateAuditable;
import com.gloqr.constants.ItemState;
import com.gloqr.entities.Image;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class GalleryDto extends DateAuditable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7665822823007952141L;

	private String galleryUuid;

	@NotBlank(message = "{notblank.galleryTitle}")
	@Size(min = 3, max = 50, message = "{size.galleryTitle}")
	private String galleryTitle;

	@NotBlank(message = "{notblank.description}")
	@Size(min = 3, max = 500, message = "{size.description}")
	private String description;

	private ItemState itemState;
	private boolean active;

	private List<Image> images;
	
	private String feedbackMessage;

	private boolean galleryModified;


	public String getGalleryUuid() {
		return galleryUuid;
	}

	public void setGalleryUuid(String galleryUuid) {
		this.galleryUuid = galleryUuid;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<Image> getImages() {
		return images;
	}

	public void setImages(List<Image> images) {
		this.images = images;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getGalleryTitle() {
		return galleryTitle;
	}

	public void setGalleryTitle(String galleryTitle) {
		this.galleryTitle = galleryTitle;
	}

	public ItemState getItemState() {
		return itemState;
	}

	public void setItemState(ItemState itemState) {
		this.itemState = itemState;
	}

	public boolean isGalleryModified() {
		return galleryModified;
	}

	public void setGalleryModified(boolean galleryModified) {
		this.galleryModified = galleryModified;
	}

	public String getFeedbackMessage() {
		return feedbackMessage;
	}

	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}

}
