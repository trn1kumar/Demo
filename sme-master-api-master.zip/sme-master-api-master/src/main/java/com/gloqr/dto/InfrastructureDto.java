package com.gloqr.dto;

import java.util.List;

import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.gloqr.audit.DateAuditable;
import com.gloqr.constants.ItemState;
import com.gloqr.entities.Image;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class InfrastructureDto extends DateAuditable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8864611226853210980L;

	private String infraUuid;

	@Size(min = 3, max = 50, message = "{size.machineName}")
	private String machineName;

	private String manufacturer;

	private String modelName;

	private ItemState itemState ;

	private boolean active;

	private boolean businessPost;
	
	private String feedbackMessage;

	private List<Image> images;

	@Size(min = 3, max = 2000, message = "{size.description}")
	private String description;

	private String quantity;

	private String capacity;

	private boolean infraModified;


	public String getMachineName() {
		return machineName;
	}

	public void setMachineName(String machineName) {
		this.machineName = machineName;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getCapacity() {
		return capacity;
	}

	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}

	public List<Image> getImages() {
		return images;
	}

	public void setImages(List<Image> images) {
		this.images = images;
	}

	public String getInfraUuid() {
		return infraUuid;
	}

	public void setInfraUuid(String infraUuid) {
		this.infraUuid = infraUuid;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean isBusinessPost() {
		return businessPost;
	}

	public void setBusinessPost(boolean businessPost) {
		this.businessPost = businessPost;
	}

	public ItemState getItemState() {
		return itemState;
	}

	public void setItemState(ItemState itemState) {
		this.itemState = itemState;
	}

	public boolean isInfraModified() {
		return infraModified;
	}

	public void setInfraModified(boolean infraModified) {
		this.infraModified = infraModified;
	}

	public String getFeedbackMessage() {
		return feedbackMessage;
	}

	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}


}