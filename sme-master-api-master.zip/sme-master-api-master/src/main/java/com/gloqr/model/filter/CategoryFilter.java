package com.gloqr.model.filter;

public class CategoryFilter implements Comparable<CategoryFilter> {

	private String categoryName;
	private int totalSmesCount;
	private boolean selected;

	public CategoryFilter(String categoryName, int totalSmesCount) {
		super();
		this.categoryName = categoryName;
		this.totalSmesCount = totalSmesCount;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public int getTotalSmesCount() {
		return totalSmesCount;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public void setTotalSmesCount(int totalSmesCount) {
		this.totalSmesCount = totalSmesCount;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((categoryName == null) ? 0 : categoryName.hashCode());
		result = prime * result + (selected ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CategoryFilter other = (CategoryFilter) obj;
		if (categoryName == null) {
			if (other.categoryName != null)
				return false;
		} else if (!categoryName.equals(other.categoryName)) {
			return false;
		}
		if (selected != other.selected) {
			return false;
		}
		return true;
	}

	@Override
	public int compareTo(CategoryFilter o) {
		/*
		 * object 'o' is comparing with object 'this' for getting selected results first
		 * (i.e descending order).
		 */
		return Boolean.compare(o.isSelected(), this.isSelected());
	}

}
