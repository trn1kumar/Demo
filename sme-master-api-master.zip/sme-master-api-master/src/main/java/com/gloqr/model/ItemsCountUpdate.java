package com.gloqr.model;

import com.gloqr.constants.ItemType;

public class ItemsCountUpdate {
	
	private String smeUuid;

	private ItemType itemType;
	private int totalCount;
	private int activeApprovedCount;
	private int activePendingCount;

	public ItemsCountUpdate(long totalCount, long activeApprovedCount, long activePendingCount) {
		super();
		this.totalCount = (int) totalCount;
		this.activeApprovedCount = (int) activeApprovedCount;
		this.activePendingCount = (int) activePendingCount;
	}

	public ItemType getItemType() {
		return itemType;
	}

	public void setItemType(ItemType itemType) {
		this.itemType = itemType;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public int getActiveApprovedCount() {
		return activeApprovedCount;
	}

	public void setActiveApprovedCount(int activeApprovedCount) {
		this.activeApprovedCount = activeApprovedCount;
	}

	public int getActivePendingCount() {
		return activePendingCount;
	}

	public void setActivePendingCount(int activePendingCount) {
		this.activePendingCount = activePendingCount;
	}

	@Override
	public String toString() {
		return "ItemsCountUpdate [itemType=" + itemType + ", totalCount=" + totalCount + ", activeApprovedCount="
				+ activeApprovedCount + ", pendingApprovedCount=" + activePendingCount + "]";
	}

	public String getSmeUuid() {
		return smeUuid;
	}

	public void setSmeUuid(String smeUuid) {
		this.smeUuid = smeUuid;
	}

}
