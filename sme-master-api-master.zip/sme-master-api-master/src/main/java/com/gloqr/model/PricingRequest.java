package com.gloqr.model;

import com.gloqr.constants.CreditType;

public class PricingRequest {

	private CreditType creditType;
	private String action;
	private long credits;
	private String usedFor;

	public PricingRequest() {
		super();
	}

	public PricingRequest(CreditType creditType, long credits, String action) {
		super();
		this.creditType = creditType;
		this.action = action;
		this.credits = credits;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public CreditType getCreditType() {
		return creditType;
	}

	public void setCreditType(CreditType creditType) {
		this.creditType = creditType;
	}

	public long getCredits() {
		return credits;
	}

	public void setCredits(long credits) {
		this.credits = credits;
	}

	public String getUsedFor() {
		return usedFor;
	}

	public void setUsedFor(String usedFor) {
		this.usedFor = usedFor;
	}

	@Override
	public String toString() {
		return "PricingRequest [creditType=" + creditType + ", action=" + action + ", credits=" + credits + "]";
	}
	
	

}
