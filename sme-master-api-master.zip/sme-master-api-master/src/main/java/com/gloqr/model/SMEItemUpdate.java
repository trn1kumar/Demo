package com.gloqr.model;

import java.util.List;

import com.gloqr.constants.ItemState;
import com.gloqr.constants.ItemStatus;
import com.gloqr.dto.ImageDto;

public class SMEItemUpdate {

	private String id;

	// for approve/reject item by gloqr admin
	private ItemState state;

	// for update item images by gloqr admin
	private List<ImageDto> images;

	private String feedbackMessage;

	// for active/de-active item by sme admin
	private ItemStatus smeAction;

	public String getFeedbackMessage() {
		return feedbackMessage;
	}

	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public ItemState getState() {
		return state;
	}

	public void setState(ItemState state) {
		this.state = state;
	}

	public ItemStatus getSmeAction() {
		return smeAction;
	}

	public void setSmeAction(ItemStatus smeAction) {
		this.smeAction = smeAction;
	}

	public List<ImageDto> getImages() {
		return images;
	}

	public void setImages(List<ImageDto> images) {
		this.images = images;
	}

}
