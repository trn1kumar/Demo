package com.gloqr.model;

import java.util.ArrayList;
import java.util.List;

import com.gloqr.entities.Image;

public class PublishFeed {

	private String smeUuid;
	private String publishFeedId;
	private String title;
	private String description;
	private List<File> files;
	private boolean active;
	private static final String POSTTYPE = "INFRA";
	private static final String PRIVACY = "PUBLIC";

	public PublishFeed() {
		super();
	}

	public PublishFeed(String smeUuid, String infraUuid, String machineName, String description, List<Image> files) {
		this.smeUuid = smeUuid;
		this.publishFeedId = infraUuid;
		this.title = machineName;
		this.description = description;

		if (files != null && !files.isEmpty()) {
			List<File> newFiles = new ArrayList<>();
			files.forEach(file -> newFiles.add(new File(file.getImageLocation())));
			this.setFiles(newFiles);
		}

	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPublishFeedId() {
		return publishFeedId;
	}

	public void setPublishFeedId(String publishFeedId) {
		this.publishFeedId = publishFeedId;
	}

	public List<File> getFiles() {
		return files;
	}

	public void setFiles(List<File> files) {
		this.files = files;
	}

	public String getSmeUuid() {
		return smeUuid;
	}

	public void setSmeUuid(String smeUuid) {
		this.smeUuid = smeUuid;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getPostType() {
		return POSTTYPE;
	}

	public String getPrivacy() {
		return PRIVACY;
	}

	@Override
	public String toString() {
		return "PublishFeed [smeUuid=" + smeUuid + ", publishFeedId=" + publishFeedId + ", title=" + title + "]";
	}

}
