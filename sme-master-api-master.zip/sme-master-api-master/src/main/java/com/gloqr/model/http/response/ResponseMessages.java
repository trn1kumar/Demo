package com.gloqr.model.http.response;

public class ResponseMessages {
	private ResponseMessages() {

	}

	public static final String SUCCESS = "Success";
}
