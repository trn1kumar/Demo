package com.gloqr.model.filter;

public class CityFilter implements Comparable<CityFilter> {
	private String city;
	private int totalSmesCount;
	private boolean selected;

	public CityFilter(String city, int totalSmesCount) {
		super();
		this.city = city;
		this.totalSmesCount = totalSmesCount;
	}

	public String getCity() {
		return city;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getTotalSmesCount() {
		return totalSmesCount;
	}

	public void setTotalSmesCount(int totalSmesCount) {
		this.totalSmesCount = totalSmesCount;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + (selected ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CityFilter other = (CityFilter) obj;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city)) {
			return false;
		}
		if (selected != other.selected) {
			return false;
		}
		return true;
	}

	@Override
	public int compareTo(CityFilter o) {
		// object 'o' is comparing with object 'this' for getting selected results
		// first (i.e descending order).
		return Boolean.compare(o.isSelected(), this.isSelected());
	}

}
