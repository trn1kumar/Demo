package com.gloqr.model.notification;

public class EmailEvent {

	private String emailId;
	private String subject;
	private String eventMessage;

	public EmailEvent() {
		super();
	}

	public EmailEvent(String emailId, String subject, String eventMessage) {
		super();
		this.emailId = emailId;
		this.subject = subject;
		this.eventMessage = eventMessage;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getEventMessage() {
		return eventMessage;
	}

	public void setEventMessage(String eventMessage) {
		this.eventMessage = eventMessage;
	}

	@Override
	public String toString() {
		return "EmailEvent [emailId=" + emailId + ", subject=" + subject + "]";
	}

}
