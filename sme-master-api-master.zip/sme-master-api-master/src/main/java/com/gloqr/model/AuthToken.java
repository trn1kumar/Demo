package com.gloqr.model;

public class AuthToken {

	private String sUuid;
	
	private String token;

	public AuthToken() {

	}

	public AuthToken(String token) {
		this.token = token;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	@Override
	public String toString() {
		return "AuthToken [sUuid=" + sUuid + ", token=" + token + "]";
	}
	
}
