package com.gloqr.dao;

import java.util.List;

import com.gloqr.entities.Infrastructure;

public interface InfrastructureDao {
	public void saveInfras(List<Infrastructure> infrastructures);

	public List<Infrastructure> getInfrastructuresByInfraUuidsIn(List<String> infraIds);

	public Infrastructure saveInfrastructure(Infrastructure infra);

	public Infrastructure getInfraByUuid(String infraUuid);

	public void deleteInfra(Infrastructure i);

	public void updateBusinessPostAlreadyActivatedByTrue(String infraUuid);

	public void updateBusinessPostByFalse(String infraUuid);
}
