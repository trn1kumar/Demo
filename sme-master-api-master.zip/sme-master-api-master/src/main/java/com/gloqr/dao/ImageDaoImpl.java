package com.gloqr.dao;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.gloqr.entities.Image;
import com.gloqr.exception.CustomException;
import com.gloqr.repository.ImageRepository;

@Repository
public class ImageDaoImpl implements ImageDao {

	@Autowired
	private ImageRepository imageRepository;

	@Override
	public void saveImage(Image existImage) {
		try {
			imageRepository.save(existImage);
		} catch (Exception e) {
			throw new CustomException("Exception in saveImage () { }. message: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public void saveMultipleImages(List<Image> images) {
		try {
			imageRepository.saveAll(images);
		} catch (Exception e) {
			throw new CustomException("Exception in saveMultipleImages () { }. message: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@Override
	public Image getImageByUuid(String imgUuid) {
		Image image = imageRepository.findByImgUuid(imgUuid);
		if (image == null) {
			throw new CustomException("Image not found ", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return image;
	}

	@Override
	public Image getImageByImageLocation(String imageLocation) {
		Image image = imageRepository.findByImageLocation(imageLocation);
		if (image == null) {
			throw new CustomException("Image not found ", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return image;
	}
	
	@Override
	public List<Image> getImages(List<Image> tmpImgs) {
		Set<String> imgIds = tmpImgs.stream().map(Image::getImgUuid).collect(Collectors.toSet());
		List<Image> dbImgs = getMultipleImagesIn(imgIds);
		dbImgs.forEach(img -> img.setActive(true));
		return dbImgs;
	}

	@Override
	public List<Image> getMultipleImagesIn(Set<String> imgIds) {
		List<Image> imgs = imageRepository.findByImgUuidIn(imgIds);
		if (imgs.isEmpty()) {
			throw new CustomException("Image not found ", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return imgs;
	}

	@Override
	public void deleteMultipleImages(List<Image> existImages) {
		try {
			imageRepository.deleteInBatch(existImages);
		} catch (Exception e) {
			throw new CustomException("Exception in deleteMultipleImages () { }. message: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public void deactiveMultipleImages(List<Image> images) {
		if (images != null && !images.isEmpty()) {
			Set<String> imgIds = images.stream().map(Image::getImgUuid).collect(Collectors.toSet());
			imageRepository.updateMultipleImagesStatus(imgIds, false);
		}
	}

	@Override
	public void updateImagesByBusinessPostFalse(Set<String> imageLocations) {
		imageRepository.updateImagesByBusinessPostFalse(imageLocations);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public void deleteByImageLocation(String imageLocation) {
		imageRepository.deleteByImageLocation(imageLocation);
	}

}
