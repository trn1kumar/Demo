package com.gloqr.dao;

import java.util.List;

import com.gloqr.entities.Gallery;

public interface GalleryDao {

	Gallery getGallery(String galleryUuid);

	void saveGallery(Gallery gallery);

	void deleteGallery(Gallery gallery);

	void saveGalleries(List<Gallery> galleries);

	void updateGalleryStatus(String id, boolean status);

}
