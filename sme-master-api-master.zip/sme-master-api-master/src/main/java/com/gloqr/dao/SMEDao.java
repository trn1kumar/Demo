package com.gloqr.dao;

import java.util.List;
import java.util.Set;

import com.gloqr.constants.ItemState;
import com.gloqr.constants.ItemType;
import com.gloqr.entities.Certificate;
import com.gloqr.entities.Gallery;
import com.gloqr.entities.Infrastructure;
import com.gloqr.entities.ManagementTeam;
import com.gloqr.entities.SMEInformation;
import com.gloqr.entities.SMEItemsCount;
import com.gloqr.entities.TurnOver;
import com.gloqr.model.ItemsCountUpdate;

public interface SMEDao {

	public SMEInformation saveSMEWithCacheModify(SMEInformation sme);

	public SMEInformation saveSMEWithOutCacheModify(SMEInformation sme);

	public SMEInformation getSME(String smeUuid);

	public SMEInformation getSMEWithOutCache(String smeUuid);

	public boolean isSMEExist(String smeUuid);

	public List<Infrastructure> getInfrasBySmeUuidAndStateAndActive(String smeUuid, ItemState state, boolean active);

	public List<Certificate> getCertificatesBySmeUuidAndStateAndActive(String smeUuid, ItemState state, boolean active);

	public List<ManagementTeam> getTeamsBySmeUuidAndStateAndActive(String smeUuid, ItemState state, boolean active);

	public List<Gallery> getGalleriesBySmeUuidAndStateAndActive(String smeUuid, ItemState state, boolean active);

	public String getExistImageLocation(String smeUuid);

	public void deleteTurnOver(TurnOver turnOver);

	public List<Infrastructure> getInfrastructures(String smeUuid);

	// Authorization
	public boolean isSMEHasGivenInfrastructure(String smeUuid, String infraUuid);

	public boolean isSMEHasGivenCertificate(String smeUuid, String crtiUuid);

	public boolean isSMEHasGivenTeam(String smeUuid, String teamUuid);

	public boolean isSMEHasGivenGallery(String smeUuid, String galleryUuid);

	public List<Infrastructure> getInfrastructuresByActive(String smeUuid, boolean active);

	public List<SMEInformation> getSMEsByActive(boolean active);

	public boolean isSMEExistByUuid(String uuid);

	public void updateSMELogoImgLocation(String smeUuid, String newImageLocation);

	public List<Certificate> getCertificates(String smeUuid);

	public List<Certificate> getCertificatesByActive(String smeUuid, boolean active);

	public List<ManagementTeam> getManagementTeams(String smeUuid);

	public List<ManagementTeam> getManagementTeamsByActive(String smeUuid, boolean active);

	public List<Gallery> getGalleries(String smeUuid);

	public List<Gallery> getGalleriesByActive(String smeUuid, boolean active);

	public boolean isGSTINNumberExist(String gstin);

	public List<SMEInformation> getTopSmes();

	public int infrasCountBySmeIdAndActiveAndState(String smeUuid, boolean active, ItemState state);

	public int infrasCountBySmeId(String smeUuid);

	public int certificatesCountBySmeIdAndActiveAndState(String smeUuid, boolean active, ItemState state);

	public int certificatesCountBySmeId(String smeUuid);

	public int teamsCountBySmeIdAndActiveAndState(String smeUuid, boolean active, ItemState state);

	public int teamsCountBySmeId(String smeUuid);

	public int galleriesCountBySmeIdAndActiveAndState(String smeUuid, boolean active, ItemState state);

	public int galleriesCountBySmeId(String smeUuid);

	// get sme by its sub objects
	public SMEInformation findActiveSmeByItemId(String itemId, ItemType itemType);

	public SMEInformation getSMEByUserUuid(String userId);

	public void saveItemsCount(SMEItemsCount itemsCount);

	public ItemsCountUpdate getCounts(String smeUuid, ItemType itemType);

	public SMEItemsCount getSmeItemsCount(String smeUuid);

	public List<SMEInformation> getCircleSuggestions(Set<String> excludeSmeUuids, String area, String city,Integer page, Integer size);

}
