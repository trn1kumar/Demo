package com.gloqr.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.entities.ManagementTeam;
import com.gloqr.exception.CustomException;
import com.gloqr.repository.ManagementTeamRepository;

@Repository
public class ManagementTeamDaoImpl implements ManagementTeamDao {

	@Autowired
	ManagementTeamRepository teamRepo;

	@Override
	public ManagementTeam saveTeam(ManagementTeam team) {
		try {
			teamRepo.save(team);
		} catch (Exception e) {
			throw new CustomException("Exception while save team. " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR,
					e);
		}
		return team;
	}

	@Override
	public void saveTeams(List<ManagementTeam> teams) {
		try {
			teamRepo.saveAll(teams);
		} catch (Exception e) {
			throw new CustomException("Exception in save teams. " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR,
					e);
		}

	}

	@Override
	public void updateTeamStatus(String id, boolean status) {
		try {
			teamRepo.updateStatus(id, status);
		} catch (Exception e) {
			throw new CustomException("Exception while update  team status. message:- " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

	}

	@Override
	public ManagementTeam getManagementTeam(String teamUuid) {
		ManagementTeam team = teamRepo.findByTeamUuid(teamUuid);
		if (team == null) {
			throw new CustomException("Team not found with id " + teamUuid, HttpStatus.NOT_FOUND);
		}
		return team;
	}

	@Override
	public void deleteTeam(ManagementTeam team) {
		try {
			teamRepo.delete(team);
		} catch (Exception e) {
			throw new CustomException("Exception while delete team. message:- " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
	}

}
