package com.gloqr.dao;

import java.util.List;

import com.gloqr.entities.Certificate;
import com.gloqr.entities.Image;

public interface CertificateDao {

	public Certificate saveCertificate(Certificate certificate);

	public void saveCertificates(List<Certificate> certificates);

	public void updateCertificateStatus(String id, boolean status);

	public List<Image> getCertificateImages(String certificateId);

	public Certificate getCertificate(String certificateId);

	public void deleteCertificate(Certificate certificate);

}
