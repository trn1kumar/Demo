package com.gloqr.dao;

import java.util.List;

import com.gloqr.entities.SMECategory;

public interface SMECatogoryDao {

	public List<SMECategory> getSMECategories();

	public void saveCategory(SMECategory category);

	public SMECategory getCategoryByUuid(String categoryUuid);

	public SMECategory getCategoryByUrl(String categoryUrl);

}
