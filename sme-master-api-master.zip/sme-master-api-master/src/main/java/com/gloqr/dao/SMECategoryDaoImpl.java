package com.gloqr.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.entities.SMECategory;
import com.gloqr.exception.CustomException;
import com.gloqr.repository.SMECategoryRepository;

@Repository
public class SMECategoryDaoImpl implements SMECatogoryDao {

	@Autowired
	SMECategoryRepository smeCatRepo;

	@Override
	public void saveCategory(SMECategory category) {
		try {
			smeCatRepo.save(category);
		} catch (Exception e) {
			throw new CustomException("Exception in  saveCategory(){}. message:- " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

	}

	@Override
	public SMECategory getCategoryByUuid(String categoryUuid) {
		SMECategory category = smeCatRepo.findByCategoryUuid(categoryUuid);
		if (category == null)
			throw new CustomException("category not found by " + categoryUuid, HttpStatus.NOT_FOUND);
		return category;
	}

	@Override
	public SMECategory getCategoryByUrl(String categoryUrl) {

		SMECategory category = smeCatRepo.findByCategoryUrl(categoryUrl);
		if (category == null)
			throw new CustomException("category not found by " + categoryUrl, HttpStatus.NOT_FOUND);
		return category;
	}

	@Override
	public List<SMECategory> getSMECategories() {
		List<SMECategory> categories = smeCatRepo.findAll();
		if (!categories.isEmpty())
			return categories;
		else
			throw new CustomException("No Categories Available", HttpStatus.NOT_FOUND);
	}

}
