package com.gloqr.dao;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.constants.ItemState;
import com.gloqr.constants.ItemType;
import com.gloqr.entities.Certificate;
import com.gloqr.entities.Gallery;
import com.gloqr.entities.Infrastructure;
import com.gloqr.entities.ManagementTeam;
import com.gloqr.entities.SMEInformation;
import com.gloqr.entities.SMEItemsCount;
import com.gloqr.entities.TurnOver;
import com.gloqr.exception.CustomException;
import com.gloqr.model.ItemsCountUpdate;
import com.gloqr.repository.SMEInformationRepository;
import com.gloqr.repository.SMEItemsCountRepo;
import com.gloqr.repository.TurnOverRepo;
import com.gloqr.util.PaginationUtil;

@Repository
public class SMEDaoImpl implements SMEDao {

	@Autowired
	private SMEInformationRepository smeRepo;

	@Autowired
	private TurnOverRepo turnOverRepo;

	@Autowired
	private SMEItemsCountRepo itemsCountRepo;

	@Autowired
	private PaginationUtil paginationUtil;

	@Override
	@Caching(put = { @CachePut(value = "smedetails", key = "#sme.getsUuid()") }, evict = {
			@CacheEvict(value = { "smes" }, allEntries = true) })
	public SMEInformation saveSMEWithCacheModify(SMEInformation sme) {
		try {
			sme = smeRepo.save(sme);
		} catch (Exception e) {
			throw new CustomException("Exception in saveSMEWithOutCacheModify( ){ }.  message: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
		return sme;
	}

	@Override
	public SMEInformation saveSMEWithOutCacheModify(SMEInformation sme) {
		// Because of method within same class, cache not modifying
		return this.saveSMEWithCacheModify(sme);
	}

	@Override
	@Cacheable(value = "smedetails", key = "#smeUuid")
	public SMEInformation getSME(String smeUuid) {
		SMEInformation sme = smeRepo.findBySUuid(smeUuid);
		if (sme == null) {
			throw new CustomException("sme not found with id:: " + smeUuid, HttpStatus.NOT_FOUND);
		}

		return sme;

	}

	@Override
	public void saveItemsCount(SMEItemsCount itemsCount) {
		try {
			itemsCountRepo.save(itemsCount);
		} catch (Exception e) {
			throw new CustomException("Exception in saveItemsCount( ){ }.  message: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
	}

	@Override
	public SMEInformation getSMEByUserUuid(String userId) {
		SMEInformation sme = smeRepo.findByUuid(userId);
		if (sme == null) {
			throw new CustomException("sme not found with userId :: " + userId, HttpStatus.NOT_FOUND);
		}

		return sme;
	}

	@Override
	public SMEInformation getSMEWithOutCache(String smeUuid) {
		// Because of method within same class, cache will be ignore
		return this.getSME(smeUuid);
	}

	@Override
	public String getExistImageLocation(String smeUuid) {
		return smeRepo.getImageLocation(smeUuid);
	}

	public boolean isSMEExist(String smeUuid) {
		return smeRepo.existsBySUuid(smeUuid);
	}

	@Override
	public List<Infrastructure> getInfrasBySmeUuidAndStateAndActive(String smeUuid, ItemState state, boolean active) {
		List<Infrastructure> infras = smeRepo.getInfrastructuresByStateAndActive(smeUuid, state, active);
		if (infras != null && !infras.isEmpty()) {
			return infras;
		} else {
			throw new CustomException("No Infrastructures Available for  " + smeUuid, HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public List<Certificate> getCertificatesBySmeUuidAndStateAndActive(String smeUuid, ItemState state,
			boolean active) {
		List<Certificate> certificates = smeRepo.getCertificatesByStateAndActive(smeUuid, state, active);
		if (certificates != null && !certificates.isEmpty()) {
			return certificates;
		} else {
			throw new CustomException("No Certificates Available for  " + smeUuid, HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public List<ManagementTeam> getTeamsBySmeUuidAndStateAndActive(String smeUuid, ItemState state, boolean active) {
		List<ManagementTeam> teams = smeRepo.getManagementTeamsByStateAndActive(smeUuid, state, active);
		if (teams != null && !teams.isEmpty()) {
			return teams;
		} else {
			throw new CustomException("No Teams Available for  " + smeUuid, HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public List<Gallery> getGalleriesBySmeUuidAndStateAndActive(String smeUuid, ItemState state, boolean active) {
		List<Gallery> galleries = smeRepo.getGalleriesByStateAndActive(smeUuid, state, active);
		if (galleries != null && !galleries.isEmpty()) {
			return galleries;
		} else {
			throw new CustomException("No Galleries Available for  " + smeUuid, HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public void deleteTurnOver(TurnOver turnOver) {
		try {
			turnOverRepo.delete(turnOver);
		} catch (Exception e) {
			throw new CustomException("Exception in deleteTurnOver ( ){ }. message:- " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public boolean isSMEHasGivenInfrastructure(String smeUuid, String infraUuid) {
		return smeRepo.isSMEHasGivenInfrastructure(smeUuid, infraUuid);
	}

	@Override
	public boolean isSMEHasGivenCertificate(String smeUuid, String crtiUuid) {
		return smeRepo.isSMEHasGivenCertificate(smeUuid, crtiUuid);
	}

	@Override
	public boolean isSMEHasGivenTeam(String smeUuid, String teamUuid) {
		return smeRepo.isSMEHasGivenTeam(smeUuid, teamUuid);
	}

	@Override
	public boolean isSMEHasGivenGallery(String smeUuid, String galleryUuid) {
		return smeRepo.isSMEHasGivenGallery(smeUuid, galleryUuid);
	}

	@Override
	public List<Infrastructure> getInfrastructures(String smeUuid) {
		List<Infrastructure> infras = smeRepo.getInfrastructures(smeUuid);
		if (infras != null && !infras.isEmpty()) {
			return infras;
		} else {
			throw new CustomException("infrastructures not available for sme " + smeUuid, HttpStatus.NOT_FOUND);

		}
	}

	@Override
	public List<Infrastructure> getInfrastructuresByActive(String smeUuid, boolean active) {
		List<Infrastructure> infras = smeRepo.getInfrastructuresByActive(smeUuid, active);
		if (infras != null && !infras.isEmpty()) {
			return infras;
		} else {
			throw new CustomException("infrastructures not available for sme  " + smeUuid + ". and active: " + active,
					HttpStatus.NOT_FOUND);

		}
	}

	@Override
	public List<SMEInformation> getSMEsByActive(boolean active) {

		List<SMEInformation> smes = smeRepo.findByActive(active);
		if (smes != null && !smes.isEmpty()) {
			return smes;
		} else {
			throw new CustomException("No smes found with active " + active + " status", HttpStatus.OK);
		}

	}

	@Override
	public boolean isSMEExistByUuid(String uuid) {
		return smeRepo.existsByUuid(uuid);
	}

	@Override
	public void updateSMELogoImgLocation(String smeUuid, String newImageLocation) {
		smeRepo.updateSmeLogo(smeUuid, newImageLocation);
	}

	@Override
	public List<Certificate> getCertificates(String smeUuid) {
		List<Certificate> certificates = smeRepo.getCertificates(smeUuid);
		if (certificates != null && !certificates.isEmpty()) {
			return certificates;

		} else {
			throw new CustomException("certificates not available for sme " + smeUuid, HttpStatus.NOT_FOUND);

		}
	}

	@Override
	public List<Certificate> getCertificatesByActive(String smeUuid, boolean active) {
		List<Certificate> certificates = smeRepo.getCertificatesByActive(smeUuid, active);
		if (certificates != null && !certificates.isEmpty()) {
			return certificates;

		} else {
			throw new CustomException("certificates not available for sme " + smeUuid + ". and active: " + active,
					HttpStatus.NOT_FOUND);

		}
	}

	@Override
	public List<ManagementTeam> getManagementTeams(String smeUuid) {
		List<ManagementTeam> teams = smeRepo.getManagementTeams(smeUuid);
		if (teams != null && !teams.isEmpty()) {
			return teams;
		} else {
			throw new CustomException("management teams not available for sme " + smeUuid, HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public List<ManagementTeam> getManagementTeamsByActive(String smeUuid, boolean active) {
		List<ManagementTeam> teams = smeRepo.getManagementTeamsByActive(smeUuid, active);
		if (teams != null && !teams.isEmpty()) {
			return teams;
		} else {
			throw new CustomException("management teams not available for sme " + smeUuid + ". and active: " + active,
					HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public List<Gallery> getGalleries(String smeUuid) {
		List<Gallery> galleries = smeRepo.getGalleries(smeUuid);
		if (galleries != null && !galleries.isEmpty()) {
			return galleries;

		} else {
			throw new CustomException("galleries not available for sme " + smeUuid, HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public List<Gallery> getGalleriesByActive(String smeUuid, boolean active) {
		List<Gallery> galleries = smeRepo.getGalleriesByActive(smeUuid, active);
		if (galleries != null && !galleries.isEmpty()) {
			return galleries;

		} else {
			throw new CustomException("galleries not available for sme " + smeUuid + ". and active: " + active,
					HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public boolean isGSTINNumberExist(String gstin) {
		return smeRepo.existsByGstin(gstin);
	}

	@Override
	public List<SMEInformation> getTopSmes() {
		int size = paginationUtil.getTopSmesPageSize();

		List<SMEInformation> smes = smeRepo.findByActiveTrue(PageRequest.of(0, size, Sort.Direction.DESC,
				"itemsCount.biCounts", "itemsCount.activeApprovedProducts", "itemsCount.activeApprovedServices",
				"itemsCount.activeApprovedBusinessPosts", "itemsCount.activeApprovedVacancies",
				"itemsCount.activeApprovedTeams", "itemsCount.activeApprovedInfras",
				"itemsCount.activeApprovedCertificates", "itemsCount.activeApprovedGalleries"));
		if (smes != null && !smes.isEmpty())
			return smes;

		else
			throw new CustomException("No SME's Available", HttpStatus.NOT_FOUND);
	}

	@Override
	public SMEInformation findActiveSmeByItemId(String itemId, ItemType itemType) {
		SMEInformation sme = null;
		switch (itemType) {
		case CERTIFICATE:
			sme = smeRepo.findActiveTrueSMEByCrtiUuid(itemId);
			break;
		case INFRASTRUCTURE:
			sme = smeRepo.findActiveTrueSMEByInfraUuid(itemId);
			break;
		case TEAM:
			sme = smeRepo.findActiveTrueSMEByTeamUuid(itemId);
			break;
		case GALLERY:
			sme = smeRepo.findActiveTrueSMEByGalleryUuid(itemId);
			break;
		default:
			break;
		}

		if (sme != null) {
			return sme;
		} else {
			throw new CustomException("SME is in eigther deactive mode or not found, with itemType:-  " + itemType
					+ " and itemId:- " + itemId, HttpStatus.NOT_FOUND);
		}

	}

	@Override
	public int infrasCountBySmeIdAndActiveAndState(String smeUuid, boolean active, ItemState state) {
		return smeRepo.infrasCountBySmeIdAndActiveAndState(smeUuid, active, state);
	}

	@Override
	public int infrasCountBySmeId(String smeUuid) {
		return smeRepo.infrasCountBySmeId(smeUuid);
	}

	@Override
	public int certificatesCountBySmeIdAndActiveAndState(String smeUuid, boolean active, ItemState state) {
		return smeRepo.certificatesCountBySmeIdAndActiveAndState(smeUuid, active, state);
	}

	@Override
	public int certificatesCountBySmeId(String smeUuid) {
		return smeRepo.certificatesCountBySmeId(smeUuid);
	}

	@Override
	public int teamsCountBySmeIdAndActiveAndState(String smeUuid, boolean active, ItemState state) {
		return smeRepo.teamsCountBySmeIdAndActiveAndState(smeUuid, active, state);
	}

	@Override
	public int teamsCountBySmeId(String smeUuid) {
		return smeRepo.teamsCountBySmeId(smeUuid);
	}

	@Override
	public int galleriesCountBySmeIdAndActiveAndState(String smeUuid, boolean active, ItemState state) {
		return smeRepo.galleriesCountBySmeIdAndActiveAndState(smeUuid, active, state);
	}

	@Override
	public int galleriesCountBySmeId(String smeUuid) {
		return smeRepo.galleriesCountBySmeId(smeUuid);
	}

	@Override
	public ItemsCountUpdate getCounts(String smeUuid, ItemType itemType) {
		ItemsCountUpdate countUpdate = null;
		switch (itemType) {
		case CERTIFICATE:
			countUpdate = smeRepo.getCertifiacteCounts(smeUuid);
			break;
		case INFRASTRUCTURE:
			countUpdate = smeRepo.getInfraCounts(smeUuid);
			break;
		case TEAM:
			countUpdate = smeRepo.getTeamCounts(smeUuid);
			break;
		case GALLERY:
			countUpdate = smeRepo.getGalleryCounts(smeUuid);
			break;

		default:
			break;
		}

		if (countUpdate == null) {
			throw new CustomException("ItemsCountUpdate is NULL", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return countUpdate;
	}

	@Override
	public SMEItemsCount getSmeItemsCount(String smeUuid) {
		return smeRepo.getSmeItemsCount(smeUuid);
	}

	@Override
	public List<SMEInformation> getCircleSuggestions(Set<String> excludeSmeUuids, String area, String city,
			Integer page, Integer size) {
		if (page <= 0)
			page = 1;
		return smeRepo.getCircleSuggestions(excludeSmeUuids, area, city, PageRequest.of(--page, size));
	}

}
