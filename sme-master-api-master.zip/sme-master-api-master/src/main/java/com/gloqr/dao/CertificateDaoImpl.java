package com.gloqr.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.entities.Certificate;
import com.gloqr.entities.Image;
import com.gloqr.exception.CustomException;
import com.gloqr.repository.CertificateRepository;

@Repository
public class CertificateDaoImpl implements CertificateDao {

	@Autowired
	CertificateRepository certificateRepository;

	@Override
	public Certificate saveCertificate(Certificate certificate) {
		try {
			return certificateRepository.save(certificate);
		} catch (Exception e) {
			throw new CustomException("Exception while save certificate. " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
	}

	@Override
	public void saveCertificates(List<Certificate> certificates) {
		try {
			certificateRepository.saveAll(certificates);
		} catch (Exception e) {
			throw new CustomException("Exception while save certificates. " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

	}

	@Override
	public void updateCertificateStatus(String certiUuid, boolean status) {
		try {
			certificateRepository.updateStatus(certiUuid, status);
		} catch (Exception e) {
			throw new CustomException("Exception while update certificate status. " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

	}

	@Override
	public List<Image> getCertificateImages(String certificateId) {
		List<Image> images = certificateRepository.getImages(certificateId);
		if (images != null && !images.isEmpty())
			return images;
		else
			throw new CustomException("Images not available", HttpStatus.NOT_FOUND);
	}

	@Override
	public Certificate getCertificate(String crtiUuid) {
		Certificate certificate = certificateRepository.findByCrtiUuid(crtiUuid);
		if (certificate != null)
			return certificate;
		else
			throw new CustomException("certificate not found with id " + crtiUuid, HttpStatus.NOT_FOUND);
	}

	@Override
	public void deleteCertificate(Certificate certificate) {
		try {
			certificateRepository.delete(certificate);
		} catch (Exception e) {
			throw new CustomException("Exception while delete Certificate. " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
	}

}
