package com.gloqr.dao;

import java.util.List;
import java.util.Set;

import com.gloqr.entities.Image;

public interface ImageDao {

	public void saveImage(Image existImage);

	public void saveMultipleImages(List<Image> images);

	public Image getImageByUuid(String imgUuid);

	public Image getImageByImageLocation(String profileImageUrl);

	void deleteMultipleImages(List<Image> existImages);

	void deactiveMultipleImages(List<Image> existImages);

	public List<Image> getImages(List<Image> tmpImgs);

	public List<Image> getMultipleImagesIn(Set<String> imagesUuids);

	void updateImagesByBusinessPostFalse(Set<String> imageLocations);

	public void deleteByImageLocation(String imageLocationOne);

}
