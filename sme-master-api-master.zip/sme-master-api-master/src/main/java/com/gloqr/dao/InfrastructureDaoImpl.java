package com.gloqr.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.entities.Infrastructure;
import com.gloqr.exception.CustomException;
import com.gloqr.repository.InfrastructureRepository;

@Repository
public class InfrastructureDaoImpl implements InfrastructureDao {

	@Autowired
	InfrastructureRepository infraRepo;

	@Override
	public Infrastructure saveInfrastructure(Infrastructure infra) {
		try {
			infraRepo.save(infra);
		} catch (Exception e) {
			throw new CustomException("Exception in saveInfrastructure() { }. message: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
		return infra;
	}

	@Override
	public void saveInfras(List<Infrastructure> infrastructures) {

		try {
			infraRepo.saveAll(infrastructures);
		} catch (Exception e) {
			throw new CustomException("Exception in saveAll() { }. message: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
	}

	@Override
	public List<Infrastructure> getInfrastructuresByInfraUuidsIn(List<String> infraIds) {
		return infraRepo.findByInfrasUuIdIn(infraIds);
	}

	@Override
	public Infrastructure getInfraByUuid(String infraUuid) {
		Infrastructure infrastructure = infraRepo.findByInfraUuid(infraUuid);
		if (infrastructure == null) {
			throw new CustomException("infrastructure not found with id " + infraUuid, HttpStatus.NOT_FOUND);
		}
		return infrastructure;
	}

	@Override
	public void deleteInfra(Infrastructure infra) {
		try {
			infraRepo.delete(infra);
		} catch (Exception e) {
			throw new CustomException("Exception while delete Infrastructure. message:- " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
	}

	@Override
	public void updateBusinessPostAlreadyActivatedByTrue(String infraUuid) {
		infraRepo.updateBusinessPostAlreadyActivatedByTrue(infraUuid);
	}

	@Override
	public void updateBusinessPostByFalse(String infraUuid) {
		infraRepo.updateBusinessPostByFalse(infraUuid);

	}

}
