package com.gloqr.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.entities.Gallery;
import com.gloqr.exception.CustomException;
import com.gloqr.repository.GalleryRepository;

@Repository
public class GalleryDaoImpl implements GalleryDao {

	@Autowired
	GalleryRepository galleryRepo;

	@Override
	public void saveGallery(Gallery gallery) {
		try {
			galleryRepo.save(gallery);
		} catch (Exception e) {
			throw new CustomException("Exception while save gallery. message:- " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

	}

	@Override
	public void saveGalleries(List<Gallery> galleries) {
		try {
			galleryRepo.saveAll(galleries);
		} catch (Exception e) {
			throw new CustomException("Exception while save multiple galleries.  message: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

	}

	@Override
	public Gallery getGallery(String galleryUuid) {
		Gallery gallery = galleryRepo.findByGalleryUuid(galleryUuid);
		if (gallery == null) {
			throw new CustomException("gallery not found with id " + galleryUuid, HttpStatus.NOT_FOUND);
		}
		return gallery;
	}

	@Override
	public void deleteGallery(Gallery gallery) {
		try {
			galleryRepo.delete(gallery);
		} catch (Exception e) {
			throw new CustomException("Exception while delete gallery. message:- " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
	}

	@Override
	public void updateGalleryStatus(String id, boolean status) {
		try {
			galleryRepo.updateStatus(id, status);
		} catch (Exception e) {
			throw new CustomException("Exception while update gallery status. message:- " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

	}

}
