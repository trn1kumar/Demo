package com.gloqr.dao;

import java.util.List;

import com.gloqr.entities.ManagementTeam;

public interface ManagementTeamDao {

	ManagementTeam saveTeam(ManagementTeam team);

	void saveTeams(List<ManagementTeam> teams);

	ManagementTeam getManagementTeam(String teamUuid);

	void updateTeamStatus(String id, boolean status);

	void deleteTeam(ManagementTeam team);

}
