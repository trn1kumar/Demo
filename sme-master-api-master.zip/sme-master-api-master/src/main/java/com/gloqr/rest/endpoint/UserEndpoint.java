package com.gloqr.rest.endpoint;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.gloqr.exception.CustomException;
import com.gloqr.model.AuthToken;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.security.configuration.JwtConstants;
import com.gloqr.security.context.holder.AuthenticationFacade;

public class UserEndpoint {

	private Client client;
	private String endPointUri;
	private String changeType;

	@Autowired
	PricingEndpoint pricingEndpoint;

	@Autowired
	CircleEndpoint circleEndpoint;

	@Autowired
	AuthenticationFacade authenticationFacade;

	Logger log = LogManager.getLogger();

	public UserEndpoint(Client client, String endPointUri, String changeType) {
		super();
		this.client = client;
		this.endPointUri = endPointUri;
		this.changeType = changeType;
	}

	public AuthToken changeUserTypeAndGetToken(User user) {

		AuthToken refreshAuthToken = null;
		String currentAuthToken = authenticationFacade.getJwtToken();

		// change user type and get refresh auth token for SME
		refreshAuthToken = this.callUserEndpoint(user, currentAuthToken);
		try {
			// select pricing package and create circle
			this.createSMECircleAndSelectPricingPkg(user, refreshAuthToken.getToken());
		} catch (Exception e) {
			// if exception occurred at user module side then rollback usertype into NORMAL
			user.setsUuid(null);
			user.setNewUserType(UserType.NORMAL);
			log.error("Exception in SME Registration process. Rollback user type into " + user.getNewUserType());
			this.callUserEndpoint(user, "Bearer " + refreshAuthToken.getToken());
			throw e;
		}

		return refreshAuthToken;

	}

	private AuthToken callUserEndpoint(User user, String token) {

		CustomHttpResponse<AuthToken> userEndpointResponse = null;
		Response response = null;

		log.info("Going to change user type into {} and get refresh SME Token:", user.getNewUserType());
		log.info("Connecting to Authentication-Server...{method=PUT ,uri={}{} ,body={} }", endPointUri, changeType,
				user);

		try {
			response = client.target(endPointUri).path(changeType).request(MediaType.APPLICATION_JSON)
					.header(JwtConstants.HEADER_STRING, token).put(Entity.entity(user, MediaType.APPLICATION_JSON));

		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);

		Integer statusCode = response.getStatus();

		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}

		try {
			userEndpointResponse = response.readEntity(new GenericType<CustomHttpResponse<AuthToken>>() {
			});
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}

		if (userEndpointResponse.isError()) {
			throw new CustomException(userEndpointResponse.getMessage(), userEndpointResponse.getStatus());
		}
		return userEndpointResponse.getData();
	}

	private void createSMECircleAndSelectPricingPkg(User user, String authToken) {
		try {
			circleEndpoint.createCircle(user, authToken);
		} catch (Exception e) {
			log.warn("Circle not Created for user. " + user, e);
		}
		pricingEndpoint.selectPkg(user, authToken);

	}

	public class User {
		private String uuid;
		private String sUuid;
		private UserType newUserType;

		public User(String uuid, String sUuid, UserType newUserType) {
			this.uuid = uuid;
			this.sUuid = sUuid;
			this.newUserType = newUserType;
		}

		public String getUuid() {
			return uuid;
		}

		public void setUuid(String uuid) {
			this.uuid = uuid;
		}

		public String getsUuid() {
			return sUuid;
		}

		public void setsUuid(String sUuid) {
			this.sUuid = sUuid;
		}

		public UserType getNewUserType() {
			return newUserType;
		}

		public void setNewUserType(UserType newUserType) {
			this.newUserType = newUserType;
		}

		@Override
		public String toString() {
			return "User [uuid=" + uuid + ", sUuid=" + sUuid + ", newUserType=" + newUserType + "]";
		}

	}

	public enum UserType {
		NORMAL, SME, SMEFACE
	}

	private void throwEntityResponseReadException(Exception e) {
		throw new CustomException("Exception at read response from Authentication-Server. Message: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	private void throwInvalidResponseException(int statusCode) {
		throw new CustomException("Invalid Response from Authentication-Server. HttpCode:- " + statusCode,
				HttpStatus.resolve(statusCode));
	}

	private void throwConnectionRefusedException(Exception e) {
		throw new CustomException("Couldn't Connect to Authentication-Server, Exception: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	private void logResponse(Response response) {
		log.info("Response From Authentication-Server : " + response);
	}

}
