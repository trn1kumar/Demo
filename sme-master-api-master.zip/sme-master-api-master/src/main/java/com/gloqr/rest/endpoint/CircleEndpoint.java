package com.gloqr.rest.endpoint;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;

import com.gloqr.exception.CustomException;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.rest.endpoint.UserEndpoint.User;
import com.gloqr.security.configuration.JwtConstants;

public class CircleEndpoint {

	private Client client;
	private String endPointUri;
	private String createCircle;
	Logger log = LogManager.getLogger(CircleEndpoint.class.getName());

	public CircleEndpoint(Client client, String endPointUri, String createCircle) {
		super();
		this.client = client;
		this.endPointUri = endPointUri;
		this.createCircle = createCircle;
	}

	public void createCircle(User user, String token) {
		Response response = null;
		CustomHttpResponse<?> customResponse = null;
		log.info("Creating circle for user" + user.toString());
		log.info("Connecting to Circle Module... {method:POST ,URI: {}{} }", endPointUri, createCircle);
		try {

			response = client.target(endPointUri).path(createCircle).request(MediaType.APPLICATION_JSON)
					.header(JwtConstants.HEADER_STRING, "Bearer " + token)
					.post(Entity.entity("", MediaType.APPLICATION_JSON));

		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}
		logResponse(response);
		Integer statusCode = response.getStatus();

		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}
		try {
			customResponse = response.readEntity(new GenericType<CustomHttpResponse<?>>() {
			});
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}
		if (customResponse.isError()) {
			throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
		}
	}

	private void throwEntityResponseReadException(Exception e) {
		throw new CustomException("Exception at read response from Circle Module. Message: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	private void throwInvalidResponseException(int statusCode) {
		throw new CustomException("Invalid Response from Circle Module: ", HttpStatus.resolve(statusCode));
	}

	private void throwConnectionRefusedException(Exception e) {
		throw new CustomException("Couldn't Connect to Circle module, Exception: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	private void logResponse(Response response) {
		log.info("Response From Circle Module : " + response);
	}

	@Override
	public String toString() {
		return "CircleEndpoint [circleEndpoint=" + endPointUri + ", createCircle=" + createCircle + "]";
	}

}
