package com.gloqr.rest.endpoint;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.gloqr.constants.CreditType;
import com.gloqr.exception.CustomException;
import com.gloqr.exception.NoCreditException;
import com.gloqr.model.CreditsCheckResponse;
import com.gloqr.model.PricingRequest;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.rest.endpoint.UserEndpoint.User;
import com.gloqr.security.configuration.JwtConstants;
import com.gloqr.security.context.holder.AuthenticationFacade;

public class PricingEndpoint {

	Logger logger = LogManager.getLogger();
	private Client client;
	private String endPointUri;
	private String checkCreditsPath;
	private String selectPkgPath;

	@Autowired
	AuthenticationFacade authenticationFacade;

	public PricingEndpoint(Client client, String endPointUri, String checkCreditsPath, String selectPkgPath) {
		super();
		this.client = client;
		this.endPointUri = endPointUri;
		this.checkCreditsPath = checkCreditsPath;
		this.selectPkgPath = selectPkgPath;
	}

	@SuppressWarnings("rawtypes")
	public void selectPkg(User user, String token) {

		Response response = null;
		CustomHttpResponse httpResponse = null;
		logger.info("Selecting Package...");
		logger.info("Connecting to Pricing Module...{method=POST  ,uri: {}{}  ,body={} }", endPointUri, selectPkgPath,
				user);

		try {

			response = client.target(endPointUri).path(selectPkgPath).request(MediaType.APPLICATION_JSON)
					.header(JwtConstants.HEADER_STRING, "Bearer " + token)
					.post(Entity.entity(user, MediaType.APPLICATION_JSON));
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);
		Integer statusCode = response.getStatus();
		if (statusCode != HttpStatus.OK.value()) {
			invalidResponseException(statusCode);
		}
		try {
			httpResponse = response.readEntity(new GenericType<CustomHttpResponse>() {
			});
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}

		if (httpResponse.isError()) {
			throw new CustomException(httpResponse.getMessage(), httpResponse.getStatus());
		}

	}

	public void updateCredits(CreditType creditType, long totalFileSize, String action, String usedFor) {
		PricingRequest pricingRequest = null;
		pricingRequest = new PricingRequest();
		pricingRequest.setAction(action);
		pricingRequest.setCredits(totalFileSize);
		pricingRequest.setUsedFor(usedFor);
		pricingRequest.setCreditType(creditType);
		this.updateCredits(pricingRequest);
	}

	public long checkCredits(CreditType creditType) {

		logger.info("Checking available credits ");
		logger.info("Connecting to Pricing Module...  {method=GET ,uri= {}{} ,param= type:{} }", "GET", endPointUri,
				checkCreditsPath, creditType.toString());
		Response response = null;
		CustomHttpResponse<CreditsCheckResponse> httpResponse = null;
		try {
			response = client.target(endPointUri).path(checkCreditsPath).queryParam("type", creditType.toString())
					.request(MediaType.APPLICATION_JSON)
					.header(JwtConstants.HEADER_STRING, authenticationFacade.getJwtToken()).get();

		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);
		Integer statusCode = response.getStatus();
		if (statusCode != HttpStatus.OK.value()) {
			invalidResponseException(statusCode);
		}

		try {
			httpResponse = response.readEntity(new GenericType<CustomHttpResponse<CreditsCheckResponse>>() {
			});

		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}

		if (httpResponse.isError() && httpResponse.getCode() == HttpStatus.PAYMENT_REQUIRED.value()) {
			throw new NoCreditException(creditType);
		} else if (httpResponse.isError()) {
			throw new CustomException(httpResponse.getMessage(), httpResponse.getStatus());
		}
		logger.info("Available credits :  " + httpResponse.getData().getCredits());
		return httpResponse.getData().getCredits();
	}

	public void updateCredits(final PricingRequest pricingRequest) {
		logger.info("Updating Credits...");
		logger.info("Connecting to Pricing Module...  {method=PUT ,uri= {}{} ,body= {} }", endPointUri,
				checkCreditsPath, pricingRequest);

		CustomHttpResponse<?> httpResponse = null;
		Response response = null;
		try {
			response = client.target(endPointUri).path(checkCreditsPath).request(MediaType.APPLICATION_JSON)
					.header(JwtConstants.HEADER_STRING, authenticationFacade.getJwtToken())
					.put(Entity.entity(pricingRequest, MediaType.APPLICATION_JSON));

		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);
		Integer statusCode = response.getStatus();
		if (statusCode != HttpStatus.OK.value()) {
			invalidResponseException(statusCode);
		}

		try {
			httpResponse = response.readEntity(new GenericType<CustomHttpResponse<?>>() {
			});

			if (httpResponse.isError() && httpResponse.getCode() == HttpStatus.PAYMENT_REQUIRED.value()) {
				throw new NoCreditException(pricingRequest.getCreditType());
			}

		} catch (NoCreditException e) {
			throw e;
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}
	}

	private void throwConnectionRefusedException(Exception e) {
		throw new CustomException("Couldn't Connect to Pricing module, Exception: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	private void throwEntityResponseReadException(Exception e) {
		throw new CustomException("Exception at read response from Pricing Module. Message: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	public void noCreditsLeftException(CreditType creditType) {
		throw new NoCreditException(creditType);
	}

	public void invalidResponseException(int statusCode) {
		throw new CustomException("Invalid Response from Pricing endpoint ", HttpStatus.resolve(statusCode));
	}

	private void logResponse(Response response) {
		logger.info("Response From Pricing Module : " + response.toString());
	}

}
