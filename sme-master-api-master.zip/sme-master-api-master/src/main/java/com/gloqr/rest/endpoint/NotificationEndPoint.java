package com.gloqr.rest.endpoint;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.scheduling.annotation.Async;

import com.gloqr.model.notification.EmailEvent;
import com.gloqr.model.notification.SmsEvent;

public class NotificationEndPoint {

	private Client client;
	private String endPointUri;
	private String smsEndPointPath;
	private String emailEndPointPath;

	private Logger log = LogManager.getLogger();

	public NotificationEndPoint(Client client, String endPointUri, String smsEndPointPath, String emailEndPointPath) {
		this.client = client;
		this.endPointUri = endPointUri;
		this.smsEndPointPath = smsEndPointPath;
		this.emailEndPointPath = emailEndPointPath;
	}

	@Async(value = "taskExecutor")
	public <T> void sendNotification(T t) {
		if (t instanceof SmsEvent) {
			log.info("Sending SMS {method=POST ,uri={}{} ,body={} }", endPointUri, smsEndPointPath, t);
			SmsEvent sms = (SmsEvent) t;
			Response response = client.target(endPointUri).path(smsEndPointPath).request(MediaType.APPLICATION_JSON)
					.post(Entity.entity(sms, MediaType.APPLICATION_JSON));
			log.info(response);

		} else if (t instanceof EmailEvent) {
			log.info("Sending Email {method=POST ,uri={}{} ,body={} }", endPointUri, emailEndPointPath, t);
			EmailEvent email = (EmailEvent) t;
			Response response = client.target(endPointUri).path(emailEndPointPath).request(MediaType.APPLICATION_JSON)
					.post(Entity.entity(email, MediaType.APPLICATION_JSON));
			log.info(response);
		}
	}

}
