package com.gloqr.rest.endpoint;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.gloqr.exception.CustomException;
import com.gloqr.model.PublishFeed;
import com.gloqr.model.SMEItemUpdate;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.security.configuration.JwtConstants;
import com.gloqr.security.context.holder.AuthenticationFacade;

public class BusinessPostEndpoint {

	private Client client;
	private String endPointUri;
	private String createFeed;
	private String updateStatus;

	@Autowired
	private AuthenticationFacade authenticationFacade;

	private static final Logger log = LogManager.getLogger(BusinessPostEndpoint.class);

	public BusinessPostEndpoint(Client client, String endPointUri, String createFeed, String updateStatus) {
		super();
		this.client = client;
		this.endPointUri = endPointUri;
		this.createFeed = createFeed;
		this.updateStatus = updateStatus;
	}

	public void createFeed(PublishFeed feed) {

		log.info("Creating Post..");
		log.info("Connecting to Business-Post module... {method=POST ,uri={}{} ,params=publishedPost:true ,body={} }",
				endPointUri, createFeed, feed);

		Response response = null;

		try {
			response = client.target(endPointUri).path(createFeed).queryParam("publishedPost", true)
					.request(MediaType.APPLICATION_JSON)
					.header(JwtConstants.HEADER_STRING, authenticationFacade.getJwtToken())
					.post(Entity.entity(feed, MediaType.APPLICATION_JSON));
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);

		Integer statusCode = response.getStatus();

		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}

	}

	public void acitveBusinessPosts(List<SMEItemUpdate> publishData) {
		Response response = null;
		CustomHttpResponse<?> customResponse = null;

		log.info("updating business post status.");
		log.info("Connecting to Business-Post module... {method=PUT ,uri={}{} ,body='publishDataObj' }", endPointUri,
				updateStatus);
		try {
			response = client.target(endPointUri).path(updateStatus).request(MediaType.APPLICATION_JSON)
					.header(JwtConstants.HEADER_STRING, authenticationFacade.getJwtToken())
					.put(Entity.entity(publishData, MediaType.APPLICATION_JSON));
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}
		logResponse(response);
		Integer statusCode = response.getStatus();

		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}
		try {
			customResponse = response.readEntity(new GenericType<CustomHttpResponse<?>>() {
			});
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}
		if (customResponse.isError()) {
			throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
		}

	}

	private void throwConnectionRefusedException(Exception e) {
		throw new CustomException("Couldn't Connect to Business post module, Exception: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private void throwEntityResponseReadException(Exception e) {
		throw new CustomException("Exception at read response from Business post Module. Message: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	private void throwInvalidResponseException(int statusCode) {
		throw new CustomException("Invalid Response from Business post Module: ", HttpStatus.resolve(statusCode));
	}

	private void logResponse(Response response) {
		log.info("Response From Business post Module API: " + response);
	}

	@Override
	public String toString() {
		return "BusinessPostEndpoint [businessPostEndpoint=" + endPointUri + ", createFeed=" + createFeed
				+ ", updateStatus=" + updateStatus + "]";
	}

}
