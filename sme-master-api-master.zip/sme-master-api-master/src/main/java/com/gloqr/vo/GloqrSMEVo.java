package com.gloqr.vo;

import java.util.Date;

import com.gloqr.dto.count.GloqrAdminItemsCount;

public class GloqrSMEVo extends SMEInformationVo {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6574317257967376687L;
	private Date creationDate;
	private String uuid;
	private GloqrAdminItemsCount itemsCount;

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public GloqrAdminItemsCount getItemsCount() {
		return itemsCount;
	}

	public void setItemsCount(GloqrAdminItemsCount itemsCount) {
		this.itemsCount = itemsCount;
	}

}
