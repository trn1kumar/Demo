package com.gloqr.vo;

import java.io.Serializable;

public class SMECategoryVo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -253349600000578984L;
	private String categoryUuid;
	private String categoryUrl;
	private String categoryName;
	private int totalSmesCount;

	public String getCategoryUuid() {
		return categoryUuid;
	}

	public String getCategoryUrl() {
		return categoryUrl;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryUuid(String categoryUuid) {
		this.categoryUuid = categoryUuid;
	}

	public void setCategoryUrl(String categoryUrl) {
		this.categoryUrl = categoryUrl;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public int getTotalSmesCount() {
		return totalSmesCount;
	}

	public void setTotalSmesCount(int totalSmesCount) {
		this.totalSmesCount = totalSmesCount;
	}

}
