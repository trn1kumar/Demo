package com.gloqr.vo;

public class SmeSubEntitiesCount {

	int infrasCount;
	int certificatesCount;
	int teamsCount;
	int galleriesCount;

	public SmeSubEntitiesCount(int infrasCount, int certificatesCount, int teamsCount, int galleriesCount) {
		super();
		this.infrasCount = infrasCount;
		this.certificatesCount = certificatesCount;
		this.teamsCount = teamsCount;
		this.galleriesCount = galleriesCount;
	}

	public int getInfrasCount() {
		return infrasCount;
	}

	public int getCertificatesCount() {
		return certificatesCount;
	}

	public int getTeamsCount() {
		return teamsCount;
	}

	public int getGalleriesCount() {
		return galleriesCount;
	}

}
