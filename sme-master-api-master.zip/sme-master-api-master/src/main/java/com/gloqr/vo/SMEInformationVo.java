package com.gloqr.vo;

import java.io.Serializable;

public class SMEInformationVo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 680159891882421795L;

	private String smeName;

	private String sUuid;

	private String logoImage;

	private String contactEmail;

	private String contactPhone;

	private AddressVo smeAddress;

	public String getSmeName() {
		return smeName;
	}

	public String getsUuid() {
		return sUuid;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public AddressVo getSmeAddress() {
		return smeAddress;
	}

	public void setSmeAddress(AddressVo smeAddress) {
		this.smeAddress = smeAddress;
	}

	public String getLogoImage() {
		return logoImage;
	}

	public void setLogoImage(String logoImage) {
		this.logoImage = logoImage;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

}
