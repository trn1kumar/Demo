package com.gloqr.vo;

import java.util.List;

public class GloqrAdmin {

	private int totalSmes;
	private List<GloqrSMEVo> smes;

	public GloqrAdmin(int totalSmes, List<GloqrSMEVo> smes) {
		super();
		this.totalSmes = totalSmes;
		this.smes = smes;
	}

	public int getTotalSmes() {
		return totalSmes;
	}

	public void setTotalSmes(int totalSmes) {
		this.totalSmes = totalSmes;
	}

	public List<GloqrSMEVo> getSmes() {
		return smes;
	}

	public void setSmes(List<GloqrSMEVo> smes) {
		this.smes = smes;
	}

}
