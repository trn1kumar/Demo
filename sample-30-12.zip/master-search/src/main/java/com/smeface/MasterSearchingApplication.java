package com.smeface;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MasterSearchingApplication {

	public static void main(String[] args) {
		SpringApplication.run(MasterSearchingApplication.class, args);
	}
}
