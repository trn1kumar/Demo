package com.smeface.constant;

public class Provider {
	public static final String SME = "SME";
	public static final String SERVICES = "Services";
	public static final String PRODUCTS = "Products";
	public static final String ALL = "All";

}
