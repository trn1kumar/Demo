package com.smeface.vo;

public class ImageVo {

	private String fileLocation;

	private Boolean mainImage;

	public Boolean getMainImage() {
		return mainImage;
	}

	public void setMainImage(Boolean mainImage) {
		this.mainImage = mainImage;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

}
