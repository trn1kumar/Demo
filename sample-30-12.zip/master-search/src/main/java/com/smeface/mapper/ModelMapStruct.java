package com.smeface.mapper;

import org.mapstruct.Mapper;

import com.smeface.product.entity.Product;
import com.smeface.vo.ProductVo;

@Mapper
public interface ModelMapStruct {

	ProductVo sourceToDestination(Product product);
	
	Product destinationToSource(ProductVo productDTO);
}
