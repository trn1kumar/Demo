/*package com.smeface.mapper;

import com.smeface.dto.ProductDTO;
import com.smeface.masterentity.Product;

public class ModelMapStructImpl implements ModelMapStruct	{

	@Override
	public ProductDTO sourceToDestination(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product destinationToSource(ProductDTO productDTO) {
		// TODO Auto-generated method stub
		return null;
	}

}
*/