package com.smeface.aspectlogger;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.context.annotation.Configuration;

@Aspect
@Configuration
public class CentralLoggingHandler {

	private Logger logger = LogManager.getLogger(CentralLoggingHandler.class);

	@Before("execution(* com.smeface.controller.*.*(..))")
	public void before(JoinPoint joinPoint) {

		logger.info(" Check-in for method access ");
		logger.info(" Allowed execution for {}", joinPoint);
	}

	@AfterReturning(value = "execution(* com.smeface.controller.*.*(..))", returning = "result")
	public void afterReturning(JoinPoint joinPoint, Object result) {
		logger.info("returned with value {}", result);
	}

	@After(value = "execution(* com.smeface.controller.*.*(..))")
	public void after(JoinPoint joinPoint) {
		logger.info("after method {}", joinPoint);
	}

}
