package com.smeface.product.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PRODUCT_IMAGE")
public class Image implements Serializable {

	private static final long serialVersionUID = 1315943170614217448L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	@Column(name = "IMAGE_NAME")
	private String imageName;

	@Column(name = "main_image")
	private Boolean mainImage;

	@Column(name = "image_location")
	private String fileLocation;

	@Column(name = "is_active")
	private Boolean active;

	public Image(String imageName, boolean active) {
		this.imageName = imageName;
		this.active = active;
	}

	public Image(String imageName, String fileLocation, boolean active) {
		this.imageName = imageName;
		this.fileLocation = fileLocation;
		this.active = active;
	}

	public Image() {

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Boolean isMainImage() {
		return mainImage;
	}

	public void setMainImage(Boolean mainImage) {
		this.mainImage = mainImage;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public Boolean isActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

	public Boolean getMainImage() {
		return mainImage;
	}

	public Boolean getActive() {
		return active;
	}

}
