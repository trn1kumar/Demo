
package com.smeface.product.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyJoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.apache.lucene.analysis.core.LowerCaseFilterFactory;
import org.apache.lucene.analysis.ngram.EdgeNGramFilterFactory;
import org.apache.lucene.analysis.pattern.PatternReplaceFilterFactory;
import org.apache.lucene.analysis.snowball.SnowballPorterFilterFactory;
import org.apache.lucene.analysis.standard.StandardTokenizerFactory;
import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Analyzer;
import org.hibernate.search.annotations.AnalyzerDef;
import org.hibernate.search.annotations.AnalyzerDefs;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;
import org.hibernate.search.annotations.Parameter;
import org.hibernate.search.annotations.Store;
import org.hibernate.search.annotations.TokenFilterDef;
import org.hibernate.search.annotations.TokenizerDef;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@Entity
@Table(name = "PRODUCT_MASTER")
@AnalyzerDefs({
		@AnalyzerDef(name = "customanalyzer", tokenizer = @TokenizerDef(factory = StandardTokenizerFactory.class), filters = {

				@TokenFilterDef(factory = LowerCaseFilterFactory.class),
				@TokenFilterDef(factory = PatternReplaceFilterFactory.class, params = {
						@Parameter(name = "pattern", value = "([^a-zA-Z0-9\\.])"),
						@Parameter(name = "replacement", value = " "), @Parameter(name = "replace", value = "all") }),
				@TokenFilterDef(factory = SnowballPorterFilterFactory.class, params = {
						@Parameter(name = "language", value = "English") }), }),

		@AnalyzerDef(name = "edgecustomanalyzer1", tokenizer = @TokenizerDef( factory = StandardTokenizerFactory.class),
		filters = {
				
				@TokenFilterDef(factory = LowerCaseFilterFactory.class),
				@TokenFilterDef(factory = SnowballPorterFilterFactory.class, params = {
						@Parameter(name = "language", value = "English")}),
				@TokenFilterDef(factory = EdgeNGramFilterFactory.class, params = {
						@Parameter(name = "maxGramSize", value = "8"),
						@Parameter(name = "minGramSize", value = "3")
					})
})

})

@Indexed
public class Product implements Serializable {

	private static final long serialVersionUID = -2617048936115496520L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PRODUCT_ID")
	private Long id;

	@Column(name = "UUID", unique = true)
	private String uuid;

	@Column(name = "PRODUCT_NAME")
	public String productName;

	@Column(name = "PRODUCT_DISPLAY_NAME")
	@Size(min = 2, max = 100)
	@NotNull(message = "Product name cannot be left empty")
	@Field(index = Index.YES, store = Store.NO, analyze = Analyze.YES, analyzer = @Analyzer(definition = "edgecustomanalyzer1"))
	private String productDisplayName;
	
	@Column(name = "Price")
	@NotNull(message = "Product price cannot be null")
	@Field(index = Index.YES, store = Store.YES, analyze = Analyze.YES)
	@Analyzer(definition = "customanalyzer")
	private Double price;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "fksubcategory_id")
	@JsonIgnoreProperties("product")
	@IndexedEmbedded
	private SubCategory subCategory;

	@Column(name = "categoryUUID")
	private String categoryUUID;

	@Transient
	private boolean status;

	@Column(name = "WEIGHT")
	private Double weight;

	@Column(name = "DISCOUNT")
	private Double discount;

	@Column(name = "DISCOUNTED_PRICE")
	private Double discountedPrice;

	@Column(name = "SmeName")
	@Field(index = Index.YES, store = Store.YES, analyze = Analyze.YES)
	@Analyzer(definition = "customanalyzer")
	private String smeName;

	@Column(name = "SME_ID")
	private String sUuid;

	@Column(name = "SHORT_DESCRIPTION")
	@Size(min = 1, max = 1000)
	@NotNull(message = "Description cannot be null")
	@Valid
	private String description;

	@Size(min = 5, max = 5000)
	@Column(name = "LONG_DESCRIPTION")
	private String longDesc;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "productId")
	@JsonIgnoreProperties
	private List<Image> images;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_DATE")
	@LastModifiedDate
	private Date updateDate = new Date();

	@Column(name = "STOCK")
	private Integer stock;

	@Column(name = "ISACTIVE")
	@Field(index = Index.YES, store = Store.NO, analyze = Analyze.YES, analyzer = @Analyzer(definition = "edgecustomanalyzer1"))
	public Boolean isActive;

	@Column(name = "LOCATION")
	private String location;

	@ElementCollection(targetClass = String.class)
	@CollectionTable(name = "SlaveSpecificationValue")
	@MapKeyJoinColumn(name = "key")
	@Column(name = "value")
	private Map<String, String> specifications;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATION_DATE", updatable = false)
	@CreatedDate
	private Date creationDate = new Date();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public boolean getStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getCategoryUUID() {
		return categoryUUID;
	}

	public void setCategoryUUID(String categoryUUID) {
		this.categoryUUID = categoryUUID;
	}

	public SubCategory getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(SubCategory sub_Category) {
		this.subCategory = sub_Category;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public Double getDiscount() {
		return discount;
	}

	public void setDiscount(Double discount) {
		this.discount = discount;
	}

	public Double getDiscountedPrice() {
		return discountedPrice;
	}

	public void setDiscountedPrice(Double discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public String getProductDisplayName() {
		return productDisplayName;
	}

	public void setProductDisplayName(String productDisplayName) {
		this.productDisplayName = productDisplayName;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double d) {
		this.price = d;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getSmeName() {
		return smeName;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public String getShortDesc() {
		return description;
	}

	public void setShortDesc(String shortDesc) {
		this.description = shortDesc;
	}

	public String getLongDesc() {
		return longDesc;
	}

	public void setLongDesc(String longDesc) {
		this.longDesc = longDesc;
	}

	public List<Image> getImages() {
		return images;
	}

	public void setImages(List<Image> images) {
		this.images = images;
	}

	public Integer getStock() {
		return stock;
	}

	public void setStock(Integer stock) {
		this.stock = stock;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Map<String, String> getSpecifications() {
		return specifications;
	}

	public void setSpecifications(Map<String, String> specifications) {
		this.specifications = specifications;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + productName + ", price=" + price + ", weight=" + weight + ", cartDesc="
				+ /* cartDesc */ ", shortDesc=" + description + ", longDesc=" + longDesc + ", imageIDl="/* + images */
				+ ", categoryID=" /* + category */ + ", updateDate=" + updateDate + ", stock=" + stock + ", status="
				+ ", location=" + location + ", creationDate=" + creationDate + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((creationDate == null) ? 0 : creationDate.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((images == null) ? 0 : images.hashCode());
		result = prime * result + ((isActive == null) ? 0 : isActive.hashCode());
		result = prime * result + ((location == null) ? 0 : location.hashCode());
		result = prime * result + ((longDesc == null) ? 0 : longDesc.hashCode());
		result = prime * result + ((price == null) ? 0 : price.hashCode());
		result = prime * result + ((productDisplayName == null) ? 0 : productDisplayName.hashCode());
		result = prime * result + ((productName == null) ? 0 : productName.hashCode());
		result = prime * result + ((sUuid == null) ? 0 : sUuid.hashCode());
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((smeName == null) ? 0 : smeName.hashCode());
		result = prime * result + ((stock == null) ? 0 : stock.hashCode());
		result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
		result = prime * result + ((uuid == null) ? 0 : uuid.hashCode());
		result = prime * result + ((weight == null) ? 0 : weight.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (creationDate == null) {
			if (other.creationDate != null)
				return false;
		} else if (!creationDate.equals(other.creationDate))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (images == null) {
			if (other.images != null)
				return false;
		} else if (!images.equals(other.images))
			return false;
		if (isActive == null) {
			if (other.isActive != null)
				return false;
		} else if (!isActive.equals(other.isActive))
			return false;
		if (location == null) {
			if (other.location != null)
				return false;
		} else if (!location.equals(other.location))
			return false;
		if (longDesc == null) {
			if (other.longDesc != null)
				return false;
		} else if (!longDesc.equals(other.longDesc))
			return false;
		if (price == null) {
			if (other.price != null)
				return false;
		} else if (!price.equals(other.price))
			return false;
		if (productDisplayName == null) {
			if (other.productDisplayName != null)
				return false;
		} else if (!productDisplayName.equals(other.productDisplayName))
			return false;
		if (productName == null) {
			if (other.productName != null)
				return false;
		} else if (!productName.equals(other.productName))
			return false;
		if (sUuid == null) {
			if (other.sUuid != null)
				return false;
		} else if (!sUuid.equals(other.sUuid))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (smeName == null) {
			if (other.smeName != null)
				return false;
		} else if (!smeName.equals(other.smeName))
			return false;
		if (stock == null) {
			if (other.stock != null)
				return false;
		} else if (!stock.equals(other.stock))
			return false;
		if (updateDate == null) {
			if (other.updateDate != null)
				return false;
		} else if (!updateDate.equals(other.updateDate))
			return false;
		if (uuid == null) {
			if (other.uuid != null)
				return false;
		} else if (!uuid.equals(other.uuid))
			return false;
		if (weight == null) {
			if (other.weight != null)
				return false;
		} else if (!weight.equals(other.weight))
			return false;
		return true;
	}

}
