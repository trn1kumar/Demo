package com.smeface.service1;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;

import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Query;
import org.hibernate.search.exception.EmptyQueryException;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.smeface.constant.Provider;
import com.smeface.exception.CustomException;
import com.smeface.masterentity.Filter;
import com.smeface.masterentity.SMEInformation;
import com.smeface.masterentity.SearchRequest;
import com.smeface.product.entity.Product;
import com.smeface.service.entity.SMEService;

@Service
public class GenericSearchImpl implements SearchService {

	@Autowired
	private EntityManager entityManager;

	@Override
	public HashMap<String, List<? extends Object>> getSearchResult(SearchRequest searchRequest) {
		HashMap<String, List<? extends Object>> resultList = new HashMap<>();

		try {

			switch (searchRequest.getSearchEntity()) {
			case Provider.PRODUCTS:
				List<Product> products = this.getProductsResult(searchRequest);
				resultList.put("Products", products);
				return resultList;

			case Provider.SERVICES:
				List<SMEService> services = this.getMEServiceResult(searchRequest);
				resultList.put("Services", services);
				return resultList;
			case Provider.SME:
				List<SMEInformation> smeInformations = this.getSMEInformationResult(searchRequest);
				resultList.put("SME", smeInformations);
				return resultList;
			case Provider.ALL:
				HashMap<String, List<? extends Object>> masterResultList = new HashMap<>();
				masterResultList.put("Products", this.getProductsResult(searchRequest));
				masterResultList.put("Services", this.getMEServiceResult(searchRequest));
				masterResultList.put("SME", this.getSMEInformationResult(searchRequest));
				return masterResultList;

			default:
				throw new CustomException("Invalid search Entity : " + searchRequest.getSearchEntity(),
						HttpStatus.NO_CONTENT);
			}

		} catch (EmptyQueryException e) {
			new CustomException("Not Found", HttpStatus.NOT_FOUND);
		}
		return null;

	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public <T> List<T> getAutoSuggestion(SearchRequest searchRequest) {
		List<T> allSuggestion = new ArrayList<>();

		try {
			switch (searchRequest.getSearchEntity()) {
			case Provider.PRODUCTS:
				List<T> productsList = new ArrayList<>();

				productsList = (List<T>) this.getProductsResult(searchRequest);
				for (T a : productsList) {

					if (a instanceof Product) {
						Filter filter = new Filter();
						filter.setResultName(((Product) a).getProductDisplayName());
						filter.setProvider(Provider.PRODUCTS);
						allSuggestion.add((T) filter);

					}
				}
				return allSuggestion;

			case Provider.SERVICES:
				List<T> services = new ArrayList<>();

				services = (List<T>) this.getMEServiceResult(searchRequest);
				for (T a : services) {

					if (a instanceof SMEService) {
						Filter filter = new Filter();
						filter.setResultName(((SMEService) a).getServiceDisplayName());
						filter.setProvider(Provider.SERVICES);
						allSuggestion.add((T) filter);

					}
				}
				return allSuggestion;

			case Provider.SME:
				List<T> smes = new ArrayList<>();

				smes = (List<T>) this.getSMEInformationResult(searchRequest);
				for (T a : smes) {

					if (a instanceof SMEInformation) {
						Filter filter = new Filter();
						filter.setResultName(((SMEInformation) a).getSmeName());
						filter.setProvider(Provider.SME);
						allSuggestion.add((T) filter);

					}
				}
				return allSuggestion;
			case Provider.ALL:
				List<T> masterList = new ArrayList<>();
				masterList.addAll((Collection<? extends T>) this.getProductsResult(searchRequest));
				for (T a : masterList) {

					if (a instanceof Product) {
						Filter filter = new Filter();
						filter.setResultName(((Product) a).getProductDisplayName());
						filter.setProvider(Provider.PRODUCTS);
						allSuggestion.add((T) filter);

					}
				}
				masterList.clear();
				masterList.addAll((Collection<? extends T>) this.getMEServiceResult(searchRequest));
				for (T a : masterList) {

					if (a instanceof SMEService) {
						Filter filter = new Filter();
						filter.setResultName(((SMEService) a).getServiceDisplayName());
						filter.setProvider(Provider.SERVICES);
						allSuggestion.add((T) filter);

					}
				}
				masterList.clear();
				masterList.addAll((Collection<? extends T>) this.getSMEInformationResult(searchRequest));
				for (T a : masterList) {

					if (a instanceof SMEInformation) {
						Filter filter = new Filter();
						filter.setResultName(((SMEInformation) a).getSmeName());
						filter.setProvider(Provider.SME);
						allSuggestion.add((T) filter);

					}
				}
				return allSuggestion;
			default:
				throw new CustomException("Invalid search Entity : " + searchRequest.getSearchEntity(),
						HttpStatus.NO_CONTENT);

			}

		} catch (EmptyQueryException e) {
			new CustomException("Not Found", HttpStatus.NOT_FOUND);
		}

		return allSuggestion;
	}

	@Override
	public List<String> getFilter(SearchRequest searchRequest, HashMap<String, List<? extends Object>> response) {
		try {

			List<String> filters = new ArrayList<>();
			switch (searchRequest.getSearchEntity()) {
			case "Products":
				List<? extends Object> products = null;
				products = response.get("Products");
				products.stream().forEach(a -> {

					filters.add(((Product) a).getSmeName());

				});
				return filters;

			case "Services":
				List<? extends Object> services = null;
				services = response.get("Services");
				services.stream().forEach(a -> {

					filters.add(((SMEService) a).getSmeName());

				});
				return filters;

			case "SME":
				List<? extends Object> smes = null;
				smes = response.get("Services");
				smes.stream().forEach(a -> {

					filters.add(((SMEInformation) a).getSmeType());

				});
				return filters;
			case "All":
				return filters;
			default:
				throw new CustomException("Invalid search Entity : " + searchRequest.getSearchEntity(),
						HttpStatus.NO_CONTENT);

			}
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Product> getProductsResult(SearchRequest searchRequest) {

		List<Product> productsList = new ArrayList<>();
		searchRequest.setIsActive(true);
		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);
		QueryBuilder productQueryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(Product.class).get();
		Query luceneQuery = productQueryBuilder.keyword().onField("productDisplayName")
				.matching(searchRequest.getSearchText()).createQuery();
		Query luceneQuery1 = productQueryBuilder.keyword().onField("isActive").matching(searchRequest.getIsActive())
				.createQuery();

		BooleanQuery.Builder booleanQuery = new BooleanQuery.Builder();

		booleanQuery.add(luceneQuery, BooleanClause.Occur.MUST);
		booleanQuery.add(luceneQuery1, BooleanClause.Occur.MUST);
		FullTextQuery query = fullTextEntityManager.createFullTextQuery(booleanQuery.build(), Product.class);
		productsList = query.getResultList();
		return productsList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SMEInformation> getSMEInformationResult(SearchRequest searchRequest) {
		List<SMEInformation> smeInformations = new ArrayList<>();
		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);
		QueryBuilder smeQueryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(SMEInformation.class).get();
		Query smeQuery = smeQueryBuilder.keyword().onField("smeName").matching(searchRequest.getSearchText())
				.createQuery();
		FullTextQuery sme = fullTextEntityManager.createFullTextQuery(smeQuery, SMEInformation.class);
		smeInformations = sme.getResultList();
		return smeInformations;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SMEService> getMEServiceResult(SearchRequest searchRequest) {
		List<SMEService> smeServices = new ArrayList<>();
		searchRequest.setIsActive(true);
		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);
		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(SMEService.class).get();

		Query serviceQuery = queryBuilder.keyword().onField("serviceDisplayName")
				.matching(searchRequest.getSearchText()).createQuery();
		Query luceneQuery1 = queryBuilder.keyword().onField("active").matching(searchRequest.getIsActive())
				.createQuery();
		BooleanQuery.Builder booleanQuery = new BooleanQuery.Builder();

		booleanQuery.add(serviceQuery, BooleanClause.Occur.MUST);
		booleanQuery.add(luceneQuery1, BooleanClause.Occur.MUST);

		FullTextQuery queryResult = fullTextEntityManager.createFullTextQuery(booleanQuery.build(), SMEService.class);
		smeServices = queryResult.getResultList();
		return smeServices;
	}

}
