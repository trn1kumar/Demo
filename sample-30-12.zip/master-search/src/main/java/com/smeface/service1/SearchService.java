package com.smeface.service1;

import java.util.HashMap;
import java.util.List;

import com.smeface.masterentity.SMEInformation;
import com.smeface.masterentity.SearchRequest;
import com.smeface.product.entity.Product;
import com.smeface.service.entity.SMEService;

public interface SearchService {

	HashMap<String,List<? extends Object>> getSearchResult(SearchRequest searchRequest);

	<T> List<T> getAutoSuggestion(SearchRequest searchRequest);

	List<String> getFilter(SearchRequest searchRequest, HashMap<String, List<? extends Object>> response);
	
	List<Product> getProductsResult(SearchRequest searchRequest);
	
	List<SMEInformation> getSMEInformationResult(SearchRequest searchRequest);
	
	List<SMEService> getMEServiceResult(SearchRequest searchRequest);

}