package com.smeface.controller;

import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smeface.exception.CustomException;
import com.smeface.masterentity.SearchRequest;
import com.smeface.service1.GenericSearchImpl;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = "/smeface/search")
public class SearchController {

	@Autowired
	private GenericSearchImpl genericSearchImpl;

	@PostMapping(value = "/", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> ResultList(@RequestBody SearchRequest request, @RequestParam(value ="search", required=false)String search) {

		try {
		
				HashMap<String,Object> responseEntity = new HashMap<>();
				responseEntity.put("Result", genericSearchImpl.getSearchResult(request));
				responseEntity.put("Filter",
						genericSearchImpl.getFilter(request, genericSearchImpl.getSearchResult(request)).stream().distinct()
								.collect(Collectors.toList()));

				return new ResponseEntity<HashMap<String,Object>>(responseEntity, HttpStatus.OK);
			
			
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

	}
	@PostMapping(value = "/auto-suggest", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> autosuggest(@RequestBody SearchRequest request, @RequestParam(value ="search", required=false)String search){
		
		List<String> ts=genericSearchImpl.getAutoSuggestion(request);
		return new ResponseEntity<List<String>>(ts, HttpStatus.OK);
		
	}
}
