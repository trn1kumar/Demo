package com.smeface.exception;

import com.smeface.product.entity.Product;

public class NotEnoughBusinessInterestsInStockException extends Exception {

	
	private static final long serialVersionUID = 997858487817953530L;
	 private static final String DEFAULT_MESSAGE = "Not enough products in stock";

	    public NotEnoughBusinessInterestsInStockException() {
	        super(DEFAULT_MESSAGE);
	    }

	    public NotEnoughBusinessInterestsInStockException(Product product) {
	        super(String.format("Not enough %s products in stock. Only %d left", product.getProductName(), product.getStock()));
	    }

}
