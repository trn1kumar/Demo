package com.smeface.exception;

import java.util.List;

public class ValidationErrors extends ExceptionResponse {

	private List<String> errors;

	public List<String> getErrors() {
		return errors;
	}
	public void setErrors(List<String> errors) {
		this.errors = errors;
	}
}
