package com.smeface.service.entity;

import javax.validation.constraints.NotNull;

public class PriceDetailsResponse {

	@NotNull(message = "Price cannot be NULL")
	private Double price;
	private String pricePer;

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getPricePer() {
		return pricePer;
	}

	public void setPricePer(String pricePer) {
		this.pricePer = pricePer;
	}

}
