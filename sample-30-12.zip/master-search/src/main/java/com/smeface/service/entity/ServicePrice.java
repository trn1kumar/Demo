package com.smeface.service.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Service_Price")
public class ServicePrice extends Audit{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Service_Price_ID")
	private Long priceID;
	
	@Column(name = "Service_Price" , nullable = false)
	private Double price;
	
	@Column(name = "Service_Price_Per")
	private String pricePer;

	public Long getPriceID() {
		return priceID;
	}

	public void setPriceID(Long priceID) {
		this.priceID = priceID;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getPricePer() {
		return pricePer;
	}

	public void setPricePer(String pricePer) {
		this.pricePer = pricePer;
	}

}
