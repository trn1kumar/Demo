package com.smeface.service;

import java.util.List;

import com.smeface.masterentity.SMEInformation;
import com.smeface.masterentity.SearchRequest;
import com.smeface.product.entity.Product;
import com.smeface.service.entity.SMEService;

public interface SearchService {
	List<Product> getSearchResult(String searchText);
	List<String> getAutoSuggestion(String searchText);
	
	List<Product> getProductResultBySme(String searchText);
	
	List<SMEService> getServiceByServiceName(String searchText);
	List<SMEService> getServiceOfSme(String searchText);
	
	List<SMEInformation> getSME(String searchText);
	
	List<String> getFilter(SearchRequest searchRequest, List<?> response);
	
}