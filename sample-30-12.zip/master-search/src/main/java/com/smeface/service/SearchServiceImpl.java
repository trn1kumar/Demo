package com.smeface.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;

import org.apache.lucene.search.Query;
import org.hibernate.search.exception.EmptyQueryException;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.smeface.exception.CustomException;
import com.smeface.masterentity.SMEInformation;
import com.smeface.masterentity.SearchRequest;
import com.smeface.product.entity.Product;
import com.smeface.service.entity.SMEService;

@Service
public class SearchServiceImpl implements SearchService {

	@Autowired
	private EntityManager entityManager;


	@SuppressWarnings("unchecked")
	@Override
	public List<Product> getSearchResult(String searchText) {
		List<Product> productList = null;

		try {
			FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

			QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
					.forEntity(Product.class).get();

			Query luceneQuery = queryBuilder.keyword().onField("productDisplayName").matching(searchText).createQuery();
			FullTextQuery query = fullTextEntityManager.createFullTextQuery(luceneQuery, Product.class);

			productList = query.getResultList();

		} catch (EmptyQueryException e) {
			new CustomException("Not Found", HttpStatus.NOT_FOUND);
		}

		return productList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getAutoSuggestion(String searchText) {
		List<Product> productList = null;
		List<String> list = null;
		try {
			FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

			QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
					.forEntity(Product.class).get();

			Query luceneQuery = queryBuilder.keyword().onField("productDisplayName").matching(searchText).createQuery();

			FullTextQuery query = fullTextEntityManager.createFullTextQuery(luceneQuery, Product.class);

			productList = query.getResultList();

			list = productList.stream().map(Product::getProductDisplayName).distinct().collect(Collectors.toList());

			list.forEach(System.out::println);

			if (productList.isEmpty() == true) {
				throw new CustomException("No result found for" + searchText, HttpStatus.NOT_FOUND);
			}

		} catch (EmptyQueryException e) {
			new CustomException("Not Found", HttpStatus.NOT_FOUND);
		}
		return list;
	}

	

	@SuppressWarnings("unchecked")
	@Override
	public List<Product> getProductResultBySme(String searchText) {
		List<Product> productList = null;

		try {
			FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

			QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
					.forEntity(Product.class).get();

			Query lucenceQuery = queryBuilder.bool()

					.should(queryBuilder.keyword().onField("smeName").ignoreFieldBridge().matching(searchText)
							.createQuery())
					.createQuery();

			FullTextQuery query = fullTextEntityManager.createFullTextQuery(lucenceQuery, Product.class);

			productList = query.getResultList();

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}

		return productList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SMEService> getServiceByServiceName(String searchText) {

		List<SMEService> services = null;

		try {
			FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

			QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
					.forEntity(SMEService.class).get();

			Query luceneQuery = queryBuilder.keyword().onField("serviceDisplayName").matching(searchText).createQuery();
			FullTextQuery query = fullTextEntityManager.createFullTextQuery(luceneQuery, SMEService.class);

			services = query.getResultList();

		} catch (EmptyQueryException e) {
			new CustomException("Not Found", HttpStatus.NOT_FOUND);
		}

		return services;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SMEService> getServiceOfSme(String searchText) {
		List<SMEService> smeServices = null;
		try {

			FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

			QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
					.forEntity(SMEService.class).get();

			Query luceneQuery = queryBuilder.keyword().onField("smeName").matching(searchText).createQuery();
			FullTextQuery query = fullTextEntityManager.createFullTextQuery(luceneQuery, SMEService.class);
			smeServices = query.getResultList();

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}
		return smeServices;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SMEInformation> getSME(String searchText) {

		List<SMEInformation> smeInformation = null;
		try {

			FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

			QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
					.forEntity(SMEInformation.class).get();

			Query luceneQuery = queryBuilder.keyword().onField("smeName").matching(searchText).createQuery();
			FullTextQuery query = fullTextEntityManager.createFullTextQuery(luceneQuery, SMEInformation.class);
			smeInformation = query.getResultList();

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}
		return smeInformation;
	}

	@Override
	public List<String> getFilter(SearchRequest searchRequest, List<?> response) {
		try {

			List<String> filter = new ArrayList<>();
			switch (searchRequest.getSearchEntity()) {
			case "Products":
				response.stream().forEach(a -> {
					if (a instanceof Product) {
						
						filter.add(((Product) a).getSmeName());
					}
				});
				return filter;

			case "Services":
				response.stream().forEach(a -> {
					if (a instanceof SMEService) {
						filter.add(((SMEService) a).getSmeName());
					}
				});
				return filter;

			case "SME":
				response.stream().forEach(a -> {
					if (a instanceof SMEInformation) {

						filter.add(((SMEInformation) a).getSmeType());

					}
				});
				return filter;

			default:
				throw new CustomException("Invalid search Entity : " + searchRequest.getSearchEntity(),
						HttpStatus.NO_CONTENT);

			}
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

	}

}
