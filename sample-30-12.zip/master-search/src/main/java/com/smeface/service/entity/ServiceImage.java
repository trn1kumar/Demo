package com.smeface.service.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name = "Service_Image")
public class ServiceImage extends Audit {

	private static final long serialVersionUID = 1L;

	public ServiceImage() {
		super();
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Image_ID")
	private Long imageID;

	@Column(name = "Main_Image")
	private Boolean mainImage;

	@Column(name = "Image_Location")
	private String fileLocation;

	public ServiceImage(String fileLocation) {
		super();
		this.fileLocation = fileLocation;
	}

	public Boolean isMainImage() {
		return mainImage;
	}

	public void setMainImage(Boolean mainImage) {
		this.mainImage = mainImage;
	}

	public Long getImageID() {
		return imageID;
	}

	public void setImageID(Long imageID) {
		this.imageID = imageID;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

}
