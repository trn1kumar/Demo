package com.smeface.service.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.lucene.analysis.core.LowerCaseFilterFactory;
import org.apache.lucene.analysis.ngram.EdgeNGramFilterFactory;
import org.apache.lucene.analysis.snowball.SnowballPorterFilterFactory;
import org.apache.lucene.analysis.standard.StandardTokenizerFactory;
import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Analyzer;
import org.hibernate.search.annotations.AnalyzerDef;
import org.hibernate.search.annotations.AnalyzerDefs;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.Parameter;
import org.hibernate.search.annotations.Store;
import org.hibernate.search.annotations.TokenFilterDef;
import org.hibernate.search.annotations.TokenizerDef;

@Entity
@Table(name = "SME_Service_Master")
@AnalyzerDefs({
		@AnalyzerDef(name = "servicecustomanalyzer", tokenizer = @TokenizerDef(factory = StandardTokenizerFactory.class), filters = {
				@TokenFilterDef(factory = LowerCaseFilterFactory.class),
				@TokenFilterDef(factory = SnowballPorterFilterFactory.class, params = {
						@Parameter(name = "language", value = "English") 
				}), 
		}),
		@AnalyzerDef(name = "edgecustomanalyzer2", tokenizer = @TokenizerDef( factory = StandardTokenizerFactory.class),
		filters = {
				
				@TokenFilterDef(factory = LowerCaseFilterFactory.class),
				@TokenFilterDef(factory = SnowballPorterFilterFactory.class, params = {
						@Parameter(name = "language", value = "English")}),
				@TokenFilterDef(factory = EdgeNGramFilterFactory.class, params = {
						@Parameter(name = "maxGramSize", value = "8"),
						@Parameter(name = "minGramSize", value = "3")
					})
})
})
@Indexed
public class SMEService extends Audit {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Service_ID")
	private Long smeServiceID;

	@Column(name = "Service_UUID", unique = true, nullable = false)
	private String serviceUUID;

	@Column(name = "Service_Url_Name")
	private String serviceUrlName;

	@Column(name = "Service_Display_Name", nullable = false , length = 200)
	@Field(index = Index.YES, store = Store.NO, analyze = Analyze.YES, analyzer = @Analyzer(definition = "edgecustomanalyzer2"))
	@Analyzer(definition = "servicecustomanalyzer")
	private String serviceDisplayName;

	@OneToOne(cascade = { CascadeType.PERSIST, CascadeType.REMOVE })
	@JoinColumn(name = "Price_ID")
	private ServicePrice priceDetails;

	@Column(name = "Discount", length = 2)
	private Integer discount;

	@Column(name = "Discounted_Price")
	private Double discountedPrice;

	@OneToMany(cascade = { CascadeType.PERSIST, CascadeType.REMOVE },fetch = FetchType.EAGER)
	@JoinColumn(name = "Service_ID")
	private List<ServiceImage> serviceImages;

	@Column(name = "Service_Description", length = 4000, nullable = false)
	private String serviceDescription;

	@Column(name = "Location")
	private String location;

	@Column(name = "SME_Name")
	private String smeName;

	@Column(name = "SME_UUID", nullable = false)
	private String sUuid;

	@Column(name = "is_Active")
	@Field(index = Index.YES, store = Store.NO, analyze = Analyze.YES, analyzer = @Analyzer(definition = "edgecustomanalyzer2"))
	private boolean active;

	
	@Transient
	private boolean status;

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	
	
	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Long getSmeServiceID() {
		return smeServiceID;
	}

	public void setSmeServiceID(Long smeServiceID) {
		this.smeServiceID = smeServiceID;
	}

	public String getServiceUUID() {
		return serviceUUID;
	}

	public void setServiceUUID(String serviceUUID) {
		this.serviceUUID = serviceUUID;
	}

	public String getServiceUrlName() {
		return serviceUrlName;
	}

	public void setServiceUrlName(String serviceUrlName) {
		this.serviceUrlName = serviceUrlName;
	}

	public String getServiceDisplayName() {
		return serviceDisplayName;
	}

	public void setServiceDisplayName(String serviceDisplayName) {
		this.serviceDisplayName = serviceDisplayName;
	}

	public ServicePrice getPriceDetails() {
		return priceDetails;
	}

	public void setPriceDetails(ServicePrice priceDetails) {
		this.priceDetails = priceDetails;
	}

	public String getServiceDescription() {
		return serviceDescription;
	}

	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getSmeName() {
		return smeName;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public List<ServiceImage> getServiceImages() {
		return serviceImages;
	}

	public void setServiceImages(List<ServiceImage> serviceImages) {
		this.serviceImages = serviceImages;
	}

	public Integer getDiscount() {
		return discount;
	}

	public void setDiscount(Integer discount) {
		this.discount = discount;
	}

	public Double getDiscountedPrice() {
		return discountedPrice;
	}

	public void setDiscountedPrice(Double discountedPrice) {
		this.discountedPrice = discountedPrice;
	}


}
