package com.smeface.masterentity;

public class SearchRequest {

	private String searchText;

	private String searchEntity;

	private String searchVariable;
	
	private Boolean isActive;

	public String getSearchText() {
		return searchText;
	}

	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}
	
	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getSearchEntity() {
		return searchEntity;
	}

	public void setSearchEntity(String searchEntity) {
		this.searchEntity = searchEntity;
	}

	public String getSearchVariable() {
		return searchVariable;
	}

	public void setSearchVariable(String searchVariable) {
		this.searchVariable = searchVariable;
	}

}
