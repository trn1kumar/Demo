package com.smeface.masterentity;

import java.util.Set;

public class Filter {

	private PriceFilter price;
	private Set<SmeFilter> smeFilter;
	private String resultName;
	private String provider;

	public Filter() {

	}

	public Set<SmeFilter> getSmeFilter() {
		return smeFilter;
	}

	public void setSmeFilter(Set<SmeFilter> smeFilter) {
		this.smeFilter = smeFilter;
	}
	
	public String getResultName() {
		return resultName;
	}

	public void setResultName(String resultName) {
		this.resultName = resultName;
	}

	public String getProvider() {
		return provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public PriceFilter getPrice() {
		return price;
	}

	public void setPrice(PriceFilter price) {
		this.price = price;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((price == null) ? 0 : price.hashCode());
		result = prime * result + ((smeFilter == null) ? 0 : smeFilter.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Filter other = (Filter) obj;
		if (price == null) {
			if (other.price != null)
				return false;
		} else if (!price.equals(other.price))
			return false;
		if (smeFilter == null) {
			if (other.smeFilter != null)
				return false;
		} else if (!smeFilter.equals(other.smeFilter))
			return false;
		return true;
	}

}
