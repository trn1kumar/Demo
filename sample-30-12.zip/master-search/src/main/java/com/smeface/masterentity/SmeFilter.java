package com.smeface.masterentity;

public class SmeFilter {

	private String smeName;
	private Boolean isSelected;
	private String sUUID;

	public String getsUUID() {
		return sUUID;
	}

	public void setsUUID(String sUUID) {
		this.sUUID = sUUID;
	}

	public String getSmeName() {
		return smeName;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public Boolean getIsSelected() {
		return isSelected;
	}

	public void setIsSelected(Boolean isSelected) {
		this.isSelected = isSelected;
	}

}
