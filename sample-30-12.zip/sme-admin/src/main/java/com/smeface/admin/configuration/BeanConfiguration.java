package com.smeface.admin.configuration;

import javax.annotation.Resource;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.smeface.admin.rest.endpoint.ContentServerEndpoint;
import com.smeface.admin.rest.endpoint.ProductEndPoint;
import com.smeface.admin.rest.endpoint.ServiceEndPoint;
import com.smeface.admin.rest.endpoint.SmeEndPoint;

@Configuration
@PropertySource(value = { "classpath:application.properties" })
public class BeanConfiguration {

	@Resource
	private Environment environment;

	@Bean
	public SmeEndPoint smeEndPointConfig() {
		Client client = ClientBuilder.newClient();
		String endPoint = environment.getRequiredProperty("sme.endpoint");
		String smesPath = environment.getRequiredProperty("smes.path");
		String searchSmes = environment.getRequiredProperty("search.smes");
		SmeEndPoint smeEndPoint = new SmeEndPoint(client, endPoint, smesPath,searchSmes);
		return smeEndPoint;
	}

	@Bean
	public ProductEndPoint productEndPointConfig() {
		Client client = ClientBuilder.newClient();
		String endPoint = environment.getRequiredProperty("product.endpoint");
		String productsPath = environment.getRequiredProperty("products.path");
		String searchSuggest = environment.getRequiredProperty("search.product.suggest");
		String searchResult = environment.getRequiredProperty("search.product.result");
		ProductEndPoint productEndPoint = new ProductEndPoint(client, endPoint, productsPath,searchSuggest,searchResult);
		return productEndPoint;

	}

	@Bean
	public ServiceEndPoint serviceEndPointConfig() {
		Client client = ClientBuilder.newClient();
		String endPoint = environment.getRequiredProperty("service.endpoint");
		String servicesPath = environment.getRequiredProperty("services.path");
		String searchSuggest= environment.getRequiredProperty("search.service.suggest");
		String searchResult= environment.getRequiredProperty("search.service.result");
		ServiceEndPoint serviceEndPoint = new ServiceEndPoint(client, endPoint, servicesPath,searchSuggest,searchResult);
		return serviceEndPoint;
	}
	
	@Bean
	public ContentServerEndpoint contentConfiguration() {
		Client client = ClientBuilder.newBuilder().register(MultiPartFeature.class).build();

		String endPoint = environment.getRequiredProperty("contentserver.endpoint");
		String uploadMultipleFiles = environment.getRequiredProperty("files.endpoint.path");
		String uploadMultipleFile = environment.getRequiredProperty("file.endpoint.path");
		String deleteFile = environment.getRequiredProperty("deletefiles.endpoint.path");
		ContentServerEndpoint contentServerEndpoint = new ContentServerEndpoint(client, endPoint,
				uploadMultipleFiles,uploadMultipleFile,deleteFile);
		return contentServerEndpoint;
	}
}
