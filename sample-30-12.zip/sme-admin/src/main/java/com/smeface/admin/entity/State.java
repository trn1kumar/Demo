package com.smeface.admin.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.search.annotations.IndexedEmbedded;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "state")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class State {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "state_id")
	@JsonIgnore
	private Long stateId;
	private String stateCode;
	private String stateName;
	private String formattedStateName;
	
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "country_id", nullable = false)
	@IndexedEmbedded(includeEmbeddedObjectId=true)
	private Country country;
	private boolean active;
	
	

	public State() {
		super();
	}

	public State(String stateCode, String stateName, String formattedStateName, Country country, boolean active) {
		super();
		this.stateCode = stateCode;
		this.stateName = stateName;
		this.formattedStateName = formattedStateName;
		this.country = country;
		this.active = active;
	}

	public Long getStateId() {
		return stateId;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateId(Long stateId) {
		this.stateId = stateId;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String getFormattedStateName() {
		return formattedStateName;
	}

	public void setFormattedStateName(String formattedStateName) {
		this.formattedStateName = formattedStateName;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

}
