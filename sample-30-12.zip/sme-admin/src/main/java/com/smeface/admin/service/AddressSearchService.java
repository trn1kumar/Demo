package com.smeface.admin.service;

import java.util.List;

import com.smeface.admin.entity.City;

public interface AddressSearchService {

	public List<City> getSearchResult(String searchText, Integer pincode);
}
