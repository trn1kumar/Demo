package com.smeface.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smeface.admin.entity.City;


public interface CityRepo extends JpaRepository<City, Long> {

	City findByCityCode(String cityCode);

}
