package com.smeface.admin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smeface.admin.service.SMEFaceMasterService;

@RequestMapping(value = "/smeface/admin")
@RestController
public class SMEFaceMasterController {

	@Autowired
	SMEFaceMasterService smefaceMasterService;

	@GetMapping("/homepage-data")
	public ResponseEntity<?> getSMEFaceHomePageData(@RequestParam(value = "u") String userID,
			@RequestParam(value = "s") String smeId) throws InterruptedException {

		return ResponseEntity.ok(smefaceMasterService.getData(userID, smeId));
	}
}
