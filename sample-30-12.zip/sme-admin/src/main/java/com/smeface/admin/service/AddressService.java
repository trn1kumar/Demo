package com.smeface.admin.service;

public interface AddressService {

}
