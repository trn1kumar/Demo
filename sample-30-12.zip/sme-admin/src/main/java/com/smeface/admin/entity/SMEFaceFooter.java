package com.smeface.admin.entity;

public class SMEFaceFooter {

}
