package com.smeface.admin.util;

import java.util.Random;

public class RandomNumber {
	
	public Integer numberGenerator() {
		Random random = new Random();
		int randomNumber = random.nextInt(100000);
		return randomNumber;
	}
	
}
