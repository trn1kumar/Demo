package com.smeface.admin.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.smeface.admin.aspectlogger.CentralLoggingHandler;
import com.smeface.admin.constant.Module;
import com.smeface.admin.dto.SearchResultDto;
import com.smeface.admin.exception.CustomException;
import com.smeface.admin.rest.endpoint.ProductEndPoint;
import com.smeface.admin.rest.endpoint.ServiceEndPoint;
import com.smeface.admin.rest.endpoint.SmeEndPoint;

@Service
public class SMEFaceMasterSearchServiceImpl implements SMEFaceMasterSearchService {

	@Autowired
	SmeEndPoint smeEndPoint;

	@Autowired
	ProductEndPoint productEndPoint;

	@Autowired
	ServiceEndPoint serviceEndPoint;

	@Value("${sme.max_result.search_in.individual.module}")
	private int smeMaxResult;
	@Value("${sme.max_result.search_in.all_module}")
	private int smeMaxResultInAllModule;
	
	private Logger log = LogManager.getLogger(SMEFaceMasterSearchServiceImpl.class);

	@Override
	public SearchResultDto getSearchedResult(String searchText, String searchModule) {

		SearchResultDto searchResult = new SearchResultDto();
		Map<String, List<? extends Object>> result = new HashMap<>();
		searchModule = searchModule.toLowerCase();
		switch (searchModule) {
		case Module.SME:
			result.put(Module.SME, smeEndPoint.getSearchedSmes(searchText, smeMaxResult));
			searchResult.setSearchedResult(result);
			break;
		case Module.PRODUCTS:
			result.put(Module.PRODUCTS, productEndPoint.getSearchedProducts(searchText));
			searchResult.setSearchedResult(result);
			break;
		case Module.SERVICES:
			result.put(Module.SERVICES, serviceEndPoint.getSearchedSerivces(searchText));
			searchResult.setSearchedResult(result);
			break;
		case Module.ALL:

			Thread serviceThread = new Thread(() -> {
				log.info("Started Excution for "+Thread.currentThread().getName());
				result.put(Module.SERVICES, serviceEndPoint.getSearchedSerivces(searchText));
				
			},"serviceThread");
			Thread productsThread = new Thread(() -> {
				log.info("Started Excution for "+Thread.currentThread().getName());
				result.put(Module.PRODUCTS, productEndPoint.getSearchedProducts(searchText));
			},"productThread");
			Thread smeThread = new Thread(() -> {
				log.info("Started Excution for "+Thread.currentThread().getName());
				result.put(Module.SME, smeEndPoint.getSearchedSmes(searchText, smeMaxResult));
			},"smeThread");

			serviceThread.start();
			productsThread.start();
			smeThread.start();
			

			try {
				smeThread.join(2000);
				serviceThread.join(2000);
				productsThread.join(2000);
				
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
			
			searchResult.setSearchedResult(result);

			break;
		default:
			throw new CustomException("Invalid Search Module : " + searchModule, HttpStatus.BAD_REQUEST);
		}

		return searchResult;

	}
}
