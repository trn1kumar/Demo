package com.smeface.admin.service;

import java.util.List;

import com.smeface.admin.dto.SMEFaceMaster;
import com.smeface.admin.dto.smes.SMEDto;
import com.smeface.admin.entity.products.SMEProduct;
import com.smeface.admin.entity.services.SMEService;

public interface SMEFaceMasterService {
	

	List<SMEProduct> getProducts(String userId, String smeId);

	List<SMEService> getServices(String userId, String smeId);

	List<SMEDto> getSMEs();

	SMEFaceMaster getData(String userID, String smeId) throws InterruptedException;
}
