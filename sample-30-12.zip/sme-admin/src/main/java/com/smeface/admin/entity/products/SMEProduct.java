package com.smeface.admin.entity.products;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.smeface.admin.dto.ImageDto;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SMEProduct {

	private String uuid;

	private String productDisplayName;

	private Double price;

	private String smeName;

	private String url;

	public Boolean isActive;

	private Boolean status;

	private String productName;

	private String sUuid;

	private List<ImageDto> images;

	private Double discount;

	private Double discountedPrice;
	
	private Date creationDate = new Date();
	
	private Date updateDate = new Date();

	public String getUuid() {
		return uuid;
	}

	public String getProductDisplayName() {
		return productDisplayName;
	}

	public Double getPrice() {
		return price;
	}

	public String getSmeName() {
		return smeName;
	}

	public String getUrl() {
		return url;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public Boolean getStatus() {
		return status;
	}

	public String getProductName() {
		return productName;
	}

	public String getsUuid() {
		return sUuid;
	}

	public List<ImageDto> getImages() {
		return images;
	}

	public Double getDiscount() {
		return discount;
	}

	public Double getDiscountedPrice() {
		return discountedPrice;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public void setProductDisplayName(String productDisplayName) {
		this.productDisplayName = productDisplayName;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public void setImages(List<ImageDto> images) {
		this.images = images;
	}

	public void setDiscount(Double discount) {
		this.discount = discount;
	}

	public void setDiscountedPrice(Double discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	
}
