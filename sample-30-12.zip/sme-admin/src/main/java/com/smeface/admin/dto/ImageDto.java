package com.smeface.admin.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class ImageDto {

	private String fileLocation;
	private boolean mainImage;

	public String getFileLocation() {
		return fileLocation;
	}

	public boolean isMainImage() {
		return mainImage;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

	public void setMainImage(boolean mainImage) {
		this.mainImage = mainImage;
	}
	
	
}
