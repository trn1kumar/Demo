package com.smeface.admin.rest.endpoint;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.http.HttpStatus;

import com.smeface.admin.dto.smes.SMEDto;
import com.smeface.admin.exception.CustomException;

public class SmeEndPoint {

	private Client client;
	private String smeEndPoint;
	private String smesPath;
	private String searchSmes;

	public SmeEndPoint(Client client, String smeEndPoint, String smesPath, String searchSmes) {
		super();
		this.client = client;
		this.smeEndPoint = smeEndPoint;
		this.smesPath = smesPath;
		this.searchSmes = searchSmes;
	}

	public List<SMEDto> getSmes() {
		try {
			Response response = client.target(smeEndPoint).path(smesPath).request(MediaType.APPLICATION_JSON).get();

			List<SMEDto> smes = null;
			Integer responseCode = response.getStatus();

			if (responseCode == HttpStatus.OK.value()) {
				smes = response.readEntity(new GenericType<List<SMEDto>>() {
				});

				return smes;

			} else if (responseCode == HttpStatus.NOT_FOUND.value()) {
				throw new CustomException("SME's Not Available", HttpStatus.NOT_FOUND);

			} else {
				throw new CustomException("Internal Exception occrurred while fetching SMEs,Invalid Response: "
						+ response.getStatusInfo().getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public List<SMEDto> getSearchedSmes(String searchText, int smeMaxResult) {
		try {
			Response response = client.target(smeEndPoint).path(smesPath).path(searchSmes)
					.queryParam("searchText", searchText).queryParam("maxResult", smeMaxResult)
					.request(MediaType.APPLICATION_JSON).get();

			List<SMEDto> smes = null;
			Integer responseCode = response.getStatus();

			if (responseCode == HttpStatus.OK.value()) {
				smes = response.readEntity(new GenericType<List<SMEDto>>() {
				});

				return smes;

			} else if (responseCode == HttpStatus.NOT_FOUND.value()) {
				throw new CustomException("SME's Not Available", HttpStatus.NOT_FOUND);

			} else {
				throw new CustomException("Internal Exception occrurred while fetching SMEs,Invalid Response: "
						+ response.getStatusInfo().getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			throw e;
		}
	}

}
