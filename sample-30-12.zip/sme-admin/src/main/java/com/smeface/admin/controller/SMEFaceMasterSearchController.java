package com.smeface.admin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smeface.admin.dto.SearchResultDto;
import com.smeface.admin.service.SMEFaceMasterSearchService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = "/smeface/admin")
public class SMEFaceMasterSearchController {

	@Autowired
	SMEFaceMasterSearchService smefaceMasterSearchService;

	@GetMapping("/search/auto-suggest")
	public ResponseEntity<?> getSearchResults(@RequestParam(value = "searchText") String searchText,
			@RequestParam(value = "searchModule") String searchModule) {

		SearchResultDto searchResult;

		searchResult = smefaceMasterSearchService.getSearchedResult(searchText, searchModule);

		return ResponseEntity.ok(searchResult);
	}
}
