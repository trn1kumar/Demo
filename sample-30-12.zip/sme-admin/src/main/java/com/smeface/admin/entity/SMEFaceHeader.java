/*package com.smeface.admin.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "smeface_header")
public class SMEFaceHeader {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long smefaceHeaderId;
	private String smefaceHeaderUuid;
	private String smefaceLogo;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "smeface_header_id")
	private List<Image> smefaceHomeSliders;

	public String getSmefaceLogo() {
		return smefaceLogo;
	}

	public void setSmefaceLogo(String smefaceLogo) {
		this.smefaceLogo = smefaceLogo;
	}

	public Long getSmefaceHeaderId() {
		return smefaceHeaderId;
	}

	public void setSmefaceHeaderId(Long smefaceHeaderId) {
		this.smefaceHeaderId = smefaceHeaderId;
	}

	public String getSmefaceHeaderUuid() {
		return smefaceHeaderUuid;
	}

	public void setSmefaceHeaderUuid(String smefaceHeaderUuid) {
		this.smefaceHeaderUuid = smefaceHeaderUuid;
	}

	public List<Image> getSmefaceHomeSliders() {
		return smefaceHomeSliders;
	}

	public void setSmefaceHomeSliders(List<Image> smefaceHomeSliders) {
		this.smefaceHomeSliders = smefaceHomeSliders;
	}
}
*/