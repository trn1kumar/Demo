package com.smeface.admin.rest.endpoint;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.glassfish.jersey.media.multipart.MultiPart;
import org.glassfish.jersey.media.multipart.file.FileDataBodyPart;
import org.springframework.http.HttpStatus;
import org.springframework.web.multipart.MultipartFile;

import com.smeface.admin.entity.UploadFileResponse;
import com.smeface.admin.exception.CustomException;

public class ContentServerEndpoint {

	private Client client;
	private String contentServerEndPoint;
	private String uploadMultipleFiles;
	private String uploadMultipleFile;
	private String deleteFile;

	Logger log = LogManager.getLogger(ContentServerEndpoint.class.getName());

	public ContentServerEndpoint(Client client, String contentServerEndPoint, String uploadMultipleFiles,
			String uploadMultipleFile, String deleteFile) {
		this.client = client;
		this.contentServerEndPoint = contentServerEndPoint;
		this.uploadMultipleFiles = uploadMultipleFiles;
		this.uploadMultipleFile = uploadMultipleFile;
		this.deleteFile = deleteFile;
	}

	public List<UploadFileResponse> sendFilesToContentServer(List<MultipartFile> multipartFile2, List<String> name,
			String fileLocation) throws IllegalArgumentException, IOException {

		WebTarget webTarget = client.target(contentServerEndPoint).path(uploadMultipleFiles).path(fileLocation);
		MultiPart multiPart = new MultiPart();
		multiPart.setMediaType(MediaType.MULTIPART_FORM_DATA_TYPE);
		int i = 0;
		List<File> files = new ArrayList<File>();
		for (MultipartFile file : multipartFile2) {
			File tmpFile = convert(file, name.get(i++));
			FileDataBodyPart fileDataBodyPart = new FileDataBodyPart("files", (tmpFile),
					MediaType.APPLICATION_OCTET_STREAM_TYPE);

			multiPart.bodyPart(fileDataBodyPart);
			files.add(tmpFile);

		}
		Response response = webTarget.request(MediaType.APPLICATION_JSON_TYPE)
				.post(Entity.entity(multiPart, multiPart.getMediaType()));
		for (File fl : files) {
			fl.delete();
		}
		List<UploadFileResponse> fileDetails = response.readEntity(new GenericType<List<UploadFileResponse>>() {
		});

		return fileDetails;

	}

	public UploadFileResponse sendFileToContentServer(MultipartFile multipartFile2, String name, String fileLocation)
			throws IllegalArgumentException, IOException {

		WebTarget webTarget = client.target(contentServerEndPoint).path(uploadMultipleFile).path(fileLocation);
		MultiPart multiPart = new MultiPart();
		multiPart.setMediaType(MediaType.MULTIPART_FORM_DATA_TYPE);

		File tmpFile = convert(multipartFile2, name);
		FileDataBodyPart fileDataBodyPart = new FileDataBodyPart("files", (tmpFile),
				MediaType.APPLICATION_OCTET_STREAM_TYPE);

		multiPart.bodyPart(fileDataBodyPart);

		Response response = webTarget.request(MediaType.APPLICATION_JSON_TYPE)
				.post(Entity.entity(multiPart, multiPart.getMediaType()));
		tmpFile.delete();
		UploadFileResponse fileDetails = response.readEntity(new GenericType<UploadFileResponse>() {
		});

		return fileDetails;

	}

	public File convert(MultipartFile file, String name) throws IOException {

		File convFile = new File(name);
		convFile.createNewFile();
		FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(file.getBytes());
		fos.close();
		return convFile;
	}

	public void deleteFileFromContentServer(String fileName) throws IOException {

		Client client = ClientBuilder.newClient();
		Response response = client.target(contentServerEndPoint).path(deleteFile).path(fileName)
				.request(MediaType.APPLICATION_JSON).delete();

		Integer responseCode = response.getStatus();

		if (responseCode != HttpStatus.OK.value()) {
			throw new CustomException("Error while deleting image from contentserver", HttpStatus.CONFLICT);
		}

	}

}
