package com.smeface.admin.rest.endpoint;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.http.HttpStatus;

import com.smeface.admin.dto.smes.SMEDto;
import com.smeface.admin.entity.products.SMEProduct;
import com.smeface.admin.exception.CustomException;

public class ProductEndPoint {

	private Client client;
	private String productEndPoint;
	private String productsPath;
	private String searchSuggest;
	private String searchResult;

	public ProductEndPoint(Client client, String productEndPoint, String productsPath,String searchSuggest,String searchResult) {
		super();
		this.client = client;
		this.productEndPoint = productEndPoint;
		this.productsPath = productsPath;
		this.searchSuggest=searchSuggest;
		this.searchResult=searchResult;
	}

	public List<SMEProduct> getProducts(String userId, String smeId) {
		try {
			Response response = client.target(productEndPoint).path(productsPath).queryParam("u", userId)
					.queryParam("s", smeId).request(MediaType.APPLICATION_JSON).get();

			List<SMEProduct> products = null;
			Integer responseCode = response.getStatus();

			if (responseCode == HttpStatus.OK.value()) {
				products = response.readEntity(new GenericType<List<SMEProduct>>() {
				});

				return products;

			} else if (responseCode == HttpStatus.NOT_FOUND.value()) {
				throw new CustomException("Products Not Available", HttpStatus.NOT_FOUND);

			} else {
				throw new CustomException("Internal Exception occrurred while fetching products,Invalid Response: "
						+ response.getStatusInfo().getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			throw e;
		}
	}
	
	public List<String> getSearchedProducts(String searchText) {
		try {
			Response response = client.target(productEndPoint).path(searchSuggest).queryParam("searchText", searchText)
					.request(MediaType.APPLICATION_JSON).get();

			List<String> suggestedResult = null;
			Integer responseCode = response.getStatus();

			if (responseCode == HttpStatus.OK.value()) {
				suggestedResult = response.readEntity(new GenericType<List<String>>() {
				});

				return suggestedResult;

			} else if (responseCode == HttpStatus.NOT_FOUND.value()) {
				throw new CustomException("No Result", HttpStatus.NOT_FOUND);

			} else {
				throw new CustomException("Internal Exception occrurred while fetching Suggested Result,Invalid Response: "
						+ response.getStatusInfo().getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			throw e;
		}
	}

}
