package com.smeface.admin.constant;

public interface Module {

	public String SME = "sme";
	public String SERVICES = "services";
	public String PRODUCTS = "products";
	public String ALL = "all";
}
