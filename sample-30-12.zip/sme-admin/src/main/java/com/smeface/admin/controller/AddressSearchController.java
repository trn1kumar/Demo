package com.smeface.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smeface.admin.entity.City;
import com.smeface.admin.service.AddressSearchService;

@RestController
@RequestMapping(value = "/smeface/admin")
@CrossOrigin("*")
public class AddressSearchController {

	@Autowired
	AddressSearchService searchService;

	@GetMapping(value = "/address/suggest")
	public ResponseEntity<?> addressSearch(@RequestParam(required = false) String searchText,
			@RequestParam(required = false) Integer pincode) {

		List<City> cities = null;
		try {
			cities = searchService.getSearchResult(searchText, pincode);
		} catch (Exception e) {
		}
		return ResponseEntity.ok(cities);
	}

}
