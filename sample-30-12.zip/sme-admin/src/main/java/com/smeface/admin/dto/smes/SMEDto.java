package com.smeface.admin.dto.smes;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SMEDto {

	private String smeName;
	private String sUuid;
	private String logoImage;
	private AddressDto smeAddress;

	public String getSmeName() {
		return smeName;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public String getLogoImage() {
		return logoImage;
	}

	public void setLogoImage(String logoImage) {
		this.logoImage = logoImage;
	}

	public AddressDto getSmeAddress() {
		return smeAddress;
	}

	public void setSmeAddress(AddressDto smeAddress) {
		this.smeAddress = smeAddress;
	}

}
