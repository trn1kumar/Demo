package com.smeface.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smeface.admin.entity.City;
import com.smeface.admin.entity.Country;
import com.smeface.admin.entity.State;
import com.smeface.admin.repository.CityRepo;
import com.smeface.admin.repository.CountryRepo;
import com.smeface.admin.repository.StateRepo;
import com.smeface.admin.service.AddressServiceImpl;

@RestController
@RequestMapping(value = "/smeface/admin")
public class AddressController {

	@Autowired
	AddressServiceImpl addressService;
	
	@Autowired
	CityRepo cityRepo;

	@Autowired
	StateRepo stateRepo;

	@Autowired
	CountryRepo countryRepo;

	@PostMapping("/cities")
	public ResponseEntity<?> addCity(@RequestBody List<City> cities) {
		addressService.saveCity(cities);
		return ResponseEntity.ok().build();
	}

	@PostMapping("/states")
	public ResponseEntity<?> addState(@RequestBody List<State> states) {
		addressService.saveState(states);
		return ResponseEntity.ok().build();
	}

	@PostMapping("/countries")
	public ResponseEntity<?> addCountry(@RequestBody List<Country> countries) {
		addressService.saveCountry(countries);
		return ResponseEntity.ok().build();
	}

	@GetMapping("/city")
	public ResponseEntity<?> getCity(@RequestParam String cityCode) {
		City city = addressService.getCity(cityCode);
		return ResponseEntity.ok(city);
	}

	@GetMapping("/state")
	public ResponseEntity<?> getState(@RequestParam String stateCode) {
		State state = addressService.getState(stateCode);
		return ResponseEntity.ok(state);
	}

	@GetMapping("/country")
	public ResponseEntity<?> getCountry(@RequestParam String countryCode) {
		Country country = addressService.getCountry(countryCode);
		return ResponseEntity.ok(country);
	}

	@GetMapping("/cities")
	public ResponseEntity<?> getCities() {
		return ResponseEntity.ok(addressService.getCities());
	}

	@GetMapping("/states")
	public ResponseEntity<?> GetStates() {
		return ResponseEntity.ok(addressService.getStates());
	}

	@GetMapping("/countries")
	public ResponseEntity<?> getCountries() {
		return ResponseEntity.ok(addressService.getCountries());
	}
	
	
}
