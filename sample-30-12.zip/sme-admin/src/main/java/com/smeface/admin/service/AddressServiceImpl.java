package com.smeface.admin.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.smeface.admin.entity.City;
import com.smeface.admin.entity.Country;
import com.smeface.admin.entity.State;
import com.smeface.admin.exception.CustomException;
import com.smeface.admin.repository.CityRepo;
import com.smeface.admin.repository.CountryRepo;
import com.smeface.admin.repository.StateRepo;

@Service
public class AddressServiceImpl {

	@Autowired
	CityRepo cityRepo;

	@Autowired
	StateRepo stateRepo;

	@Autowired
	CountryRepo countryRepo;

	public void saveCity(List<City> cities) {
		cities.forEach(city -> {
			State state = this.getState(city.getState().getStateCode());
			city.setState(state);
		});
		cityRepo.saveAll(cities);
	}

	public void saveState(List<State> states) {
		states.forEach(state -> {
			Country country = this.getCountry(state.getCountry().getCountryCode());
			state.setCountry(country);
		});
		stateRepo.saveAll(states);
	}

	public void saveCountry(List<Country> countries) {
		countryRepo.saveAll(countries);
	}

	public State getState(String stateCode) {
		return stateRepo.findByStateCode(stateCode);
	}

	public Country getCountry(String countryCode) {
		return countryRepo.findByCountryCode(countryCode);
	}

	public List<City> getCities() {
		List<City> cities = cityRepo.findAll();
		if (cities != null && cities.size() > 0) {
			cities.forEach(city -> city.setState(null));
			return cities;
		} else
			throw new CustomException("Cities Not Available", HttpStatus.NOT_FOUND);
	}

	public List<State> getStates() {
		List<State> states = stateRepo.findAll();
		if (states != null && states.size() > 0) {
			states.forEach(state -> state.setCountry(null));
			return states;
		} else
			throw new CustomException("States Not Available", HttpStatus.NOT_FOUND);
	}

	public List<Country> getCountries() {
		List<Country> countries = countryRepo.findAll();
		if (countries != null && countries.size() > 0)
			return countries;
		else
			throw new CustomException("Countries Not Available", HttpStatus.NOT_FOUND);
	}

	public City getCity(String cityCode) {
		City city = cityRepo.findByCityCode(cityCode);
		if (city == null)
			throw new CustomException("City Not Found for Code " + cityCode, HttpStatus.NOT_FOUND);
		return city;
	}

}
