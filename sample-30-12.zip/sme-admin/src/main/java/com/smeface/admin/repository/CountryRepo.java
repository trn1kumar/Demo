package com.smeface.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smeface.admin.entity.Country;


public interface CountryRepo extends JpaRepository<Country, Long>{

	Country findByCountryCode(String countryCode);


}
