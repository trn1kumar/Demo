package com.smeface.admin.service;

import java.util.List;
import java.util.Map;

import com.smeface.admin.dto.SearchResultDto;

public interface SMEFaceMasterSearchService {
	public SearchResultDto getSearchedResult(String searchText, String searchModule);

}
