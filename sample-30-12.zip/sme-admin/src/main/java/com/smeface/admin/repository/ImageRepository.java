package com.smeface.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.smeface.admin.entity.Image;


@Repository
public interface ImageRepository extends JpaRepository<Image, Long> {

	public List<Image> findByProvider(String provider);
}
