package com.smeface.admin.rest.endpoint;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.http.HttpStatus;

import com.smeface.admin.entity.services.SMEService;
import com.smeface.admin.exception.CustomException;

public class ServiceEndPoint {

	private Client client;
	private String serviceEndPoint;
	private String servicesPath;
	private String searchSuggest;
	private String searchResult;

	public ServiceEndPoint(Client client, String serviceEndPoint, String servicesPath,String searchSuggest,String searchResult) {
		super();
		this.client = client;
		this.serviceEndPoint = serviceEndPoint;
		this.servicesPath = servicesPath;
		this.searchSuggest=searchSuggest;
		this.searchResult=searchResult;
		
	}

	public List<SMEService> getSMEsServices(String userId, String smeId) {
		try {
			Response response = client.target(serviceEndPoint).path(servicesPath).queryParam("u", userId)
					.queryParam("s", smeId).request(MediaType.APPLICATION_JSON).get();

			List<SMEService> smeServices = null;
			Integer responseCode = response.getStatus();

			if (responseCode == HttpStatus.OK.value()) {
				smeServices = response.readEntity(new GenericType<List<SMEService>>() {
				});

				return smeServices;

			} else if (responseCode == HttpStatus.NOT_FOUND.value()) {
				throw new CustomException("Services Not Available", HttpStatus.NOT_FOUND);

			} else {
				throw new CustomException("Internal Exception occrurred while fetching Services,Invalid Response: "
						+ response.getStatusInfo().getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			throw e;
		}
	}
	
	public List<String> getSearchedSerivces(String searchText) {
		try {
			Response response = client.target(serviceEndPoint).path(searchSuggest).queryParam("searchText", searchText)
					.request(MediaType.APPLICATION_JSON).get();

			List<String> suggestedResult = null;
			Integer responseCode = response.getStatus();

			if (responseCode == HttpStatus.OK.value()) {
				suggestedResult = response.readEntity(new GenericType<List<String>>() {
				});

				return suggestedResult;

			} else if (responseCode == HttpStatus.NOT_FOUND.value()) {
				throw new CustomException("No Result from Service", HttpStatus.NOT_FOUND);

			} else {
				throw new CustomException("Internal Exception occrurred while fetching Suggested Result,Invalid Response: "
						+ response.getStatusInfo().getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			throw e;
		}
	}

}
