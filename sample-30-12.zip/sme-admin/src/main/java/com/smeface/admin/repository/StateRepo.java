package com.smeface.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smeface.admin.entity.State;


public interface StateRepo extends JpaRepository<State, Long>{

	State findByStateCode(String stateCode);


}
