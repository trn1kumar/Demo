package com.smeface;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmefaceAdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmefaceAdminApplication.class, args);
	}
}
