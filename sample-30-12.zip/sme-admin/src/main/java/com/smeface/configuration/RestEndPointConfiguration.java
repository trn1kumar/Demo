package com.smeface.configuration;

import javax.annotation.Resource;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.smeface.admin.rest.endpoint.ContentServerEndpoint;


@Configuration
@PropertySource(value = { "classpath:application.properties" })
public class RestEndPointConfiguration {

	@Resource
	private Environment environment;

	@Bean
	public ContentServerEndpoint contentConfiguration() {
		Client client = ClientBuilder.newBuilder().register(MultiPartFeature.class).build();

		String contentServerEndPoint = environment.getRequiredProperty("contentserver.endpoint");
		String uploadMultipleFiles = environment.getRequiredProperty("files.endpoint.path");
		String uploadMultipleFile = environment.getRequiredProperty("file.endpoint.path");
		
		String deleteFile = environment.getRequiredProperty("deletefiles.endpoint.path");
		ContentServerEndpoint notification = new ContentServerEndpoint(client, contentServerEndPoint,
				uploadMultipleFiles,uploadMultipleFile,deleteFile);
		return notification;
	}

}
