package com.smeface.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "User_Pricing_Details")
public class UserPricing extends Audit {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long pricingDetailsID;

	@Column(name = "Modified_By", nullable = false, updatable = false)
	private String userUUID;

	@Column(name = "SME_UUID", unique = true, nullable = false, updatable = false)
	private String sUuid;

	@Column(name = "Plan_Name", nullable = false)
	private String planName;

	@Column(name = "Plan_Cost", nullable = false)
	private double planCost;

	@Column(name = "Listings", nullable = false, columnDefinition = "BIGINT(20) UNSIGNED")
	private long listings;

	@Column(name = "Connections", nullable = false, columnDefinition = "BIGINT(20) UNSIGNED")
	private long connections;

	@Column(name = "BI_Read_Credits", nullable = false, columnDefinition = "BIGINT(20) UNSIGNED")
	private long biReadCredits;

	@Column(name = "Image_Storage_Size", nullable = false, columnDefinition = "BIGINT(20) UNSIGNED")
	private long imageStorageSize;

	@Column(name = "Job_Postings", nullable = false, columnDefinition = "BIGINT(20) UNSIGNED")
	private long jobPostings;

	@Column(name = "Business_Posts", nullable = false, columnDefinition = "BIGINT(20) UNSIGNED")
	private long businessPosts;

	@Column(name = "Expiration_Date")
	private Date expirationDate;
	
	@Column(name = "Monthly_Credited_Date")
	private Date monthlyCreditedDate;

	@Column(name = "is_Active", nullable = false)
	private boolean active;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "Initial_Pricing_ID", nullable = false)
	private UserInitialPricing initialPricing;

	public Long getPricingDetailsID() {
		return pricingDetailsID;
	}

	public void setPricingDetailsID(Long pricingDetailsID) {
		this.pricingDetailsID = pricingDetailsID;
	}

	public String getUserUUID() {
		return userUUID;
	}

	public void setUserUUID(String userUUID) {
		this.userUUID = userUUID;
	}

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public double getPlanCost() {
		return planCost;
	}

	public void setPlanCost(double planCost) {
		this.planCost = planCost;
	}

	public long getListings() {
		return listings;
	}

	public void setListings(long listings) {
		this.listings = listings;
	}

	public long getConnections() {
		return connections;
	}

	public void setConnections(long connections) {
		this.connections = connections;
	}

	public long getBiReadCredits() {
		return biReadCredits;
	}

	public void setBiReadCredits(long biReadCredits) {
		this.biReadCredits = biReadCredits;
	}

	public long getImageStorageSize() {
		return imageStorageSize;
	}

	public void setImageStorageSize(long imageStorageSize) {
		this.imageStorageSize = imageStorageSize;
	}

	public long getJobPostings() {
		return jobPostings;
	}

	public void setJobPostings(long jobPostings) {
		this.jobPostings = jobPostings;
	}

	public long getBusinessPosts() {
		return businessPosts;
	}

	public void setBusinessPosts(long businessPosts) {
		this.businessPosts = businessPosts;
	}

	public Date getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}
	
	public Date getMonthlyCreditedDate() {
		return monthlyCreditedDate;
	}

	public void setMonthlyCreditedDate(Date monthlyCreditedDate) {
		this.monthlyCreditedDate = monthlyCreditedDate;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public UserInitialPricing getInitialPricing() {
		return initialPricing;
	}

	public void setInitialPricing(UserInitialPricing initialPricing) {
		this.initialPricing = initialPricing;
	}
	
}
