package com.smeface.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "User_Pricing_History")
public class UserPricingHistory extends Audit {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long pricingHistoryID;

	@Column(name = "Modified_By", nullable = false, updatable = false)
	private String userUUID;

	@Column(name = "SME_UUID", nullable = false, updatable = false)
	private String sUuid;

	@Column(name = "Plan_Name", nullable = false)
	private String planName;

	@Column(name = "Previous_Credits", nullable = false, columnDefinition = "BIGINT(20) UNSIGNED")
	private long previousCredits;

	@Column(name = "Current_Credits", nullable = false, columnDefinition = "BIGINT(20) UNSIGNED")
	private long currentCredits;

	@Column(name = "Credit", columnDefinition = "BIGINT(20) UNSIGNED")
	private long credit;

	@Column(name = "Debit", columnDefinition = "BIGINT(20) UNSIGNED")
	private long debit;

	@Column(name = "Type", nullable = false)
	private String type;

	@Column(name = "Source", nullable = false)
	private String source;

	public Long getPricingHistoryID() {
		return pricingHistoryID;
	}

	public void setPricingHistoryID(Long pricingHistoryID) {
		this.pricingHistoryID = pricingHistoryID;
	}

	public String getUserUUID() {
		return userUUID;
	}

	public void setUserUUID(String userUUID) {
		this.userUUID = userUUID;
	}

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public long getPreviousCredits() {
		return previousCredits;
	}

	public void setPreviousCredits(long previousCredits) {
		this.previousCredits = previousCredits;
	}

	public long getCurrentCredits() {
		return currentCredits;
	}

	public void setCurrentCredits(long currentCredits) {
		this.currentCredits = currentCredits;
	}

	public long getCredit() {
		return credit;
	}

	public void setCredit(long credit) {
		this.credit = credit;
	}

	public long getDebit() {
		return debit;
	}

	public void setDebit(long debit) {
		this.debit = debit;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

}
