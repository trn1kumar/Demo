package com.smeface.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "User_Initial_Pricing")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class UserInitialPricing extends Audit {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long initialPricingID;

	@Column(name = "Listings", nullable = false, columnDefinition = "BIGINT(20) UNSIGNED")
	private long listings;

	@Column(name = "Connections", nullable = false, columnDefinition = "BIGINT(20) UNSIGNED")
	private long connections;

	@Column(name = "BI_Read_Credits", nullable = false, columnDefinition = "BIGINT(20) UNSIGNED")
	private long biReadCredits;

	@Column(name = "Image_Storage_Size", nullable = false, columnDefinition = "BIGINT(20) UNSIGNED")
	private long imageStorageSize;

	@Column(name = "Job_Postings", nullable = false, columnDefinition = "BIGINT(20) UNSIGNED")
	private long jobPostings;

	@Column(name = "Business_Posts", nullable = false, columnDefinition = "BIGINT(20) UNSIGNED")
	private long businessPosts;

	public Long getInitialPricingID() {
		return initialPricingID;
	}

	public void setInitialPricingID(Long initialPricingID) {
		this.initialPricingID = initialPricingID;
	}

	public long getListings() {
		return listings;
	}

	public void setListings(long listings) {
		this.listings = listings;
	}

	public long getConnections() {
		return connections;
	}

	public void setConnections(long connections) {
		this.connections = connections;
	}

	public long getBiReadCredits() {
		return biReadCredits;
	}

	public void setBiReadCredits(long biReadCredits) {
		this.biReadCredits = biReadCredits;
	}

	public long getImageStorageSize() {
		return imageStorageSize;
	}

	public void setImageStorageSize(long imageStorageSize) {
		this.imageStorageSize = imageStorageSize;
	}

	public long getJobPostings() {
		return jobPostings;
	}

	public void setJobPostings(long jobPostings) {
		this.jobPostings = jobPostings;
	}

	public long getBusinessPosts() {
		return businessPosts;
	}

	public void setBusinessPosts(long businessPosts) {
		this.businessPosts = businessPosts;
	}

}
