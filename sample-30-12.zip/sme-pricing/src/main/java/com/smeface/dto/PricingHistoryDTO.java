package com.smeface.dto;

import java.util.Date;

public class PricingHistoryDTO {

	private String userUUID;

	private String sUuid;

	private String planName;

	private long previousCredits;

	private long currentCredits;

	private long credit;

	private long debit;

	private String type;

	private String source;

	private Date createdAt;

	public String getUserUUID() {
		return userUUID;
	}

	public void setUserUUID(String userUUID) {
		this.userUUID = userUUID;
	}

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public long getPreviousCredits() {
		return previousCredits;
	}

	public void setPreviousCredits(long previousCredits) {
		this.previousCredits = previousCredits;
	}

	public long getCurrentCredits() {
		return currentCredits;
	}

	public void setCurrentCredits(long currentCredits) {
		this.currentCredits = currentCredits;
	}

	public long getCredit() {
		return credit;
	}

	public void setCredit(long credit) {
		this.credit = credit;
	}

	public long getDebit() {
		return debit;
	}

	public void setDebit(long debit) {
		this.debit = debit;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

}
