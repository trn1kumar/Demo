package com.smeface.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class UserInitialPricingDTO {

	private String planName;
	private long listings;
	private long connections;
	private long biReadCredits;
	private long imageStorageSize;
	private long jobPostings;
	private long businessPosts;
	private UserPricingDTO initialPricing;

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public long getListings() {
		return listings;
	}

	public void setListings(long listings) {
		this.listings = listings;
	}

	public long getConnections() {
		return connections;
	}

	public void setConnections(long connections) {
		this.connections = connections;
	}

	public long getBiReadCredits() {
		return biReadCredits;
	}

	public void setBiReadCredits(long biReadCredits) {
		this.biReadCredits = biReadCredits;
	}

	public long getImageStorageSize() {
		return imageStorageSize;
	}

	public void setImageStorageSize(long imageStorageSize) {
		this.imageStorageSize = imageStorageSize;
	}

	public long getJobPostings() {
		return jobPostings;
	}

	public void setJobPostings(long jobPostings) {
		this.jobPostings = jobPostings;
	}

	public long getBusinessPosts() {
		return businessPosts;
	}

	public void setBusinessPosts(long businessPosts) {
		this.businessPosts = businessPosts;
	}

	public UserPricingDTO getInitialPricing() {
		return initialPricing;
	}

	public void setInitialPricing(UserPricingDTO initialPricing) {
		this.initialPricing = initialPricing;
	}

}
