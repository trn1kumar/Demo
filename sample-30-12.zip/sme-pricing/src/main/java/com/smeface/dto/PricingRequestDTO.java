package com.smeface.dto;

import javax.validation.constraints.NotBlank;

public class PricingRequestDTO {

	private String sUuid;

	private String userUUID;

	private String plan;

	@NotBlank(message = "Type cannot be Empty or Null")
	private String type;

	@NotBlank(message = "Action cannot be Empty or Null")
	private String action;

	private long credits;

	private String source;

	public String getUserUUID() {
		return userUUID;
	}

	public void setUserUUID(String userUUID) {
		this.userUUID = userUUID;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public long getCredits() {
		return credits;
	}

	public void setCredits(long credits) {
		this.credits = credits;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public String getPlan() {
		return plan;
	}

	public void setPlan(String plan) {
		this.plan = plan;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
