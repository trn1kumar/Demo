package com.smeface.constants;

public enum Constants {

	LISTING("Product/Service Listing"),
	CONNECTION("Connection"),
	BI_READ("Business Interest View"),
	JOB_POST("Job Post"),
	BUSINESS_POST("Business Post"),
	IMAGE_STORAGE_SIZE("Image Storage Size"),
		
	CREDIT("Credited"),
	DEBIT("Debited");
	
	private final String value;

	private Constants(String value) {
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}
	
}
