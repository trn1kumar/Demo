package com.smeface.constants;

public enum Free {

	LISTINGS(10), 
	
	CONNECTIONS(25),
	
	ANNUAL_BI_READ_CREDITS(360), 
	
	IMAGE_STORAGE_SIZE(104857600),
	
	JOB_POSTINGS(5), 
	
	BUSINESS_POSTS(50);

	private final long credits;

	private Free(long credits) {
		this.credits = credits;
	}

	public long getCredits() {
		return this.credits;
	}

}
