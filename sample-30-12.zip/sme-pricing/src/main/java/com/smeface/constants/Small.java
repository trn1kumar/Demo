package com.smeface.constants;

public enum Small {

	LISTINGS(25),

	CONNECTIONS(50),

	ANNUAL_BI_READ_CREDITS(1200),

	IMAGE_STORAGE_SIZE(209715200),

	JOB_POSTINGS(10),

	BUSINESS_POSTS(360);
	
	private final long credits;

	private Small(long credits) {
		this.credits = credits;
	}

	public long getCredits() {
		return this.credits;
	}

}
