package com.smeface.constants;

public interface RequestMappingConstants {

	// Base URL
	String BASE_URL = "smeface/api/pricing";
	
	// Pricing Controller
	String GET_PRICING_DETAILS = "/";
	String CREATE_DEFAULT_PLAN = "/new-user";
	String CHECK_CREDITS = "/check";
	String GET_USER_DETAILS = "/pricing-details";
	String UPDATE_CREDITS = "/update-credits";
	String UPGRADE_PLAN = "/upgrade-plan";
	String USER_PRICING_HISTORY = "/pricing-history";

	// Role Constants
	String ROLE_ADMIN = "hasRole('ADMIN')";
}
