package com.smeface.constants;

public interface Costing {

	String FREE_PACKAGE = "Free Package";
	double FREE_PACKAGE_COST = 0;
	
	String SMALL_PACKAGE = "Small Business Package";
	double SMALL_PACKAGE_COST = 10000;
	
	String MEDIUM_PACKAGE = "Medium Business Package";
	double MEDIUM_PACKAGE_COST = 20000;
	
	String BIG_PACKAGE = "Big Business Package";
	double BIG_PACKAGE_COST = 30000;

	String SMEFACE = "SMEface";
}
