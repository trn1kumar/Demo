package com.smeface.constants;

public enum Medium {
	
	LISTINGS(100),

	CONNECTIONS(100),

	ANNUAL_BI_READ_CREDITS(3600),

	IMAGE_STORAGE_SIZE(314572800),

	JOB_POSTINGS(25),

	BUSINESS_POSTS(600);

	private final long credits;

	private Medium(long credits) {
		this.credits = credits;
	}

	public long getCredits() {
		return this.credits;
	}


}
