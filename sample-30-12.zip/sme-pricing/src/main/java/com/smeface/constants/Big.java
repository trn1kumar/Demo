package com.smeface.constants;

public enum Big {

	LISTINGS(500),

	CONNECTIONS(100),

	ANNUAL_BI_READ_CREDITS(7200),

	IMAGE_STORAGE_SIZE(1073741824),

	JOB_POSTINGS(100),

	BUSINESS_POSTS(1200);

	private final long credits;

	private Big(long credits) {
		this.credits = credits;
	}

	public long getCredits() {
		return this.credits;
	}

}
