package com.smeface.controller;

import java.util.HashMap;
import java.util.List;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smeface.constants.RequestMappingConstants;
import com.smeface.dto.CreditsCheckResponse;
import com.smeface.dto.PricingHistoryDTO;
import com.smeface.dto.PricingRequestDTO;
import com.smeface.dto.SuccessResponse;
import com.smeface.dto.UserPricingDTO;
import com.smeface.exception.CustomException;
import com.smeface.service.PricingService;
import com.smeface.util.PackageUtil;

@RestController
@RequestMapping(RequestMappingConstants.BASE_URL)
public class PricingController {

	@Autowired
	private PricingService pricingService;

	@Autowired
	private PackageUtil packageUtil;

	@GetMapping(RequestMappingConstants.GET_PRICING_DETAILS)
	public ResponseEntity<?> getPricingDetails() {
		HashMap<String, Object> pricingDetails = pricingService.getPricingDetails();
		return new ResponseEntity<HashMap<String, Object>>(pricingDetails, HttpStatus.OK);
	}

	@PreAuthorize(value = RequestMappingConstants.ROLE_ADMIN)
	@PostMapping(RequestMappingConstants.CREATE_DEFAULT_PLAN)
	public ResponseEntity<?> createDefaultPlan() {
		try {
			pricingService.generatePricingDetails(packageUtil.getUserUUID(), packageUtil.getSuuid());
		} catch (CustomException e) {
			throw e;
		}

		return new ResponseEntity<>(
				new SuccessResponse("Pricing entry for SME Successfully created!!", HttpStatus.CREATED.value()),
				HttpStatus.CREATED);
	}

	@PreAuthorize(value = RequestMappingConstants.ROLE_ADMIN)
	@GetMapping(RequestMappingConstants.CHECK_CREDITS)
	public ResponseEntity<?> checkCredits(@RequestParam(value = "type") String type) {

		try {
			String sUuid = packageUtil.getSuuid();

			long credits = pricingService.checkCredits(sUuid, type);
			if (credits > 0) {
				return new ResponseEntity<CreditsCheckResponse>(new CreditsCheckResponse(credits), HttpStatus.OK);
			} else {
				throw new CustomException("You dont have any credits left for " + type, HttpStatus.PAYMENT_REQUIRED);
			}

		} catch (CustomException e) {
			throw e;
		}

	}

	@PreAuthorize(value = RequestMappingConstants.ROLE_ADMIN)
	@GetMapping(RequestMappingConstants.GET_USER_DETAILS)
	public ResponseEntity<?> getUserPricingDetails(@RequestParam(value = "getData", required = false) String getData) {

		try {
			String sUuid = packageUtil.getSuuid();
			if (!StringUtils.isBlank(getData)) {
				return new ResponseEntity<Object>(pricingService.getUserPricingDetails(sUuid, true), HttpStatus.OK);
			}
			return new ResponseEntity<Object>(pricingService.getUserPricingDetails(sUuid, false), HttpStatus.OK);

		} catch (CustomException e) {
			throw e;
		}

	}

	@PreAuthorize(value = RequestMappingConstants.ROLE_ADMIN)
	@PutMapping(RequestMappingConstants.UPDATE_CREDITS)
	public ResponseEntity<?> updateCredits(@RequestBody @Valid PricingRequestDTO request) {

		try {
			request.setsUuid(packageUtil.getSuuid());
			request.setUserUUID(packageUtil.getUserUUID());
			pricingService.updateCredits(request);
		} catch (CustomException e) {
			throw e;
		}

		return new ResponseEntity<SuccessResponse>(
				new SuccessResponse("Successfully " + request.getAction(), HttpStatus.CREATED.value()),
				HttpStatus.CREATED);
	}

	@PreAuthorize(value = RequestMappingConstants.ROLE_ADMIN)
	@PutMapping(RequestMappingConstants.UPGRADE_PLAN)
	public ResponseEntity<?> upgradePlan(@RequestBody PricingRequestDTO request) {
		UserPricingDTO detailsDTO = null;
		try {
			if (StringUtils.isBlank(request.getPlan())) {
				throw new CustomException("plan cannot be NULL or EMPTY", HttpStatus.BAD_REQUEST);
			}
			request.setUserUUID(packageUtil.getUserUUID());
			request.setsUuid(packageUtil.getSuuid());
			detailsDTO = pricingService.upgradePlan(request.getsUuid(), request.getPlan());
		} catch (CustomException e) {
			throw e;
		}

		return new ResponseEntity<UserPricingDTO>(detailsDTO, HttpStatus.CREATED);
	}

	@PreAuthorize(value = RequestMappingConstants.ROLE_ADMIN)
	@GetMapping(RequestMappingConstants.USER_PRICING_HISTORY)
	public ResponseEntity<?> pricingHistory() {
		List<PricingHistoryDTO> response = null;
		try {
			String sUuid = packageUtil.getSuuid();
			response = pricingService.getUserPricingHistory(sUuid);
		} catch (CustomException e) {
			throw e;
		}

		return ResponseEntity.ok(response);
	}

}
