package com.smeface.exception;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice
public class GlobleExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(CustomException.class)
	public ResponseEntity<?> customExceptionHandler(CustomException e) {
		ExceptionResponse exceptionResponse = new ExceptionResponse();
		exceptionResponse.setMessage(e.getMessage());
		exceptionResponse.setStatus(e.getStatus());
		return new ResponseEntity<ExceptionResponse>(exceptionResponse, exceptionResponse.getStatus());
	}

	@ExceptionHandler(NullPointerException.class)
	public ResponseEntity<?> nullPointerException(NullPointerException e) {
		ExceptionResponse response = new ExceptionResponse();
		response.setMessage(e.getMessage());
		response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<ExceptionResponse>(response, response.getStatus());
	}
	
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		List<String> errors = this.errorslist(ex.getBindingResult());
		ValidationErrors response = new ValidationErrors();
		response.setMessage("Validation Errors");
		response.setStatus(HttpStatus.BAD_REQUEST);
		response.setErrors(errors);
		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
	}

	private List<String> errorslist(Errors errors) {
		List<String> validErrors = new ArrayList<String>();
		for (ObjectError objectError : errors.getAllErrors()) {
			validErrors.add(objectError.getDefaultMessage());
		}
		return validErrors;
	}
}
