package com.smeface.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smeface.constants.UrlMapping;
import com.smeface.constants.CircleModuleConstants.RoleAccess;
import com.smeface.dto.SMEDto;
import com.smeface.entity.SMECircle;
import com.smeface.exception.CustomException;
import com.smeface.service.SMECircleServiceImpl;
import com.smeface.service.SMEService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.ROOT_API)
public class SMEController {

	@Autowired
	SMEService smeService;

	@Autowired
	SMECircleServiceImpl circleService;

	@PreAuthorize(RoleAccess.ADMIN)
	@GetMapping(UrlMapping.SMEs)
	public ResponseEntity<?> getPlatformListedSmes(@PathVariable String smeId) {
		SMECircle myCircle = null;
		List<SMEDto> smes = null;
		try {
			try {
				myCircle = circleService.getBusinessCircle(smeId);
			} catch (CustomException e) {

			}
			smes = smeService.getPlatformListedSmes(myCircle, smeId);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}
		return new ResponseEntity<List<SMEDto>>(smes, HttpStatus.OK);
	}
}
