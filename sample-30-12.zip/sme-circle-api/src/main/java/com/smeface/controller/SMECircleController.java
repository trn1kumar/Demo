package com.smeface.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smeface.circle.vo.ConnectionVo;
import com.smeface.constants.CircleModuleConstants.CirclePrivacy;
import com.smeface.constants.CircleModuleConstants.RequestRaram;
import com.smeface.constants.CircleModuleConstants.RoleAccess;
import com.smeface.constants.UrlMapping;
import com.smeface.dto.CustomHttpResponse;
import com.smeface.dto.SMECircleDto;
import com.smeface.dto.SMEDto;
import com.smeface.entity.MyConnection;
import com.smeface.entity.ReceiveRequest;
import com.smeface.entity.SMECircle;
import com.smeface.entity.SendRequest;
import com.smeface.exception.CustomException;
import com.smeface.model.Privacy;
import com.smeface.service.MutualConnectionService;
import com.smeface.service.SMECircleService;
import com.smeface.service.SMEDetailServiceImpl;
import com.smeface.service.SMEService;
import com.smeface.service.SMEStatusCheckService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.ROOT_API)
public class SMECircleController {

	@Autowired
	SMECircleService circleService;

	@Autowired
	SMEDetailServiceImpl smeDetailService;

	@Autowired
	MutualConnectionService mutualConnectionService;

	@Autowired
	SMEService smeService;

	@Autowired
	SMEStatusCheckService smeStatusCheckService;

	@PreAuthorize(RoleAccess.ADMIN)
	@PostMapping(UrlMapping.CIRCLE)
	public ResponseEntity<?> circle(@RequestBody SMECircle circle) {
		try {
			circleService.saveOrUpdateSMECricle(circle);
		} catch (CustomException e) {
			throw e;
		} catch (Exception e) {
			throw e;
		}
		return new ResponseEntity<CustomHttpResponse>(
				new CustomHttpResponse("Circle Created Successfully", HttpStatus.CREATED), HttpStatus.CREATED);
	}

	@PreAuthorize(RoleAccess.ADMIN)
	@PostMapping(UrlMapping.SEND_REQ)
	public ResponseEntity<?> addRequest(@RequestBody SMECircle circle) {
		try {
			circleService.addSendRequest(circle);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return ResponseEntity.ok(new CustomHttpResponse("Request Sent Successfully", HttpStatus.OK));
	}

	@PreAuthorize(RoleAccess.ADMIN)
	@PostMapping(UrlMapping.ACCEPT_REQUEST)
	public ResponseEntity<?> acceptBusinessCircleReceivedRequest(@RequestBody ConnectionVo connectionVo) {
		try {
			circleService.acceptConnection(connectionVo);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ResponseEntity.ok(new CustomHttpResponse("Request Accepted Successfully", HttpStatus.OK));
	}

	@PreAuthorize(RoleAccess.ADMIN)
	@PostMapping(UrlMapping.REJECT_REQUEST)
	public ResponseEntity<?> rejectBusinessCircleReceivedRequest(@RequestBody ConnectionVo connectionVo) {
		try {
			circleService.rejectReceivedRequest(connectionVo);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ResponseEntity.ok(new CustomHttpResponse("Request rejected Successfully", HttpStatus.OK));
	}

	@PreAuthorize(RoleAccess.ADMIN)
	@PostMapping(UrlMapping.CANCEL_REQUEST)
	public ResponseEntity<?> cancelBusinessCircleSentRequest(@RequestBody ConnectionVo connectionVo) {

		try {
			circleService.cancelSentRequest(connectionVo);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ResponseEntity.ok(new CustomHttpResponse("Request Cancel Successfully", HttpStatus.OK));
	}

	@PreAuthorize(RoleAccess.ADMIN)
	@PostMapping(UrlMapping.REMOVE_CONNECTION)
	public ResponseEntity<?> removeBusinessCircleConnection(@RequestBody ConnectionVo connectionVo) {

		try {
			circleService.removeConnection(connectionVo);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ResponseEntity.ok(new CustomHttpResponse("Request Removed Successfully", HttpStatus.OK));
	}

	@PreAuthorize(RoleAccess.ADMIN)
	@GetMapping(UrlMapping.GET_RECEIVED_REQUEST)
	public ResponseEntity<?> getReceivedRequest(@PathVariable String smeId) {

		List<ReceiveRequest> receivedRequests = null;
		List<SMEDto> receivedRequestSmes = null;
		try {
			receivedRequests = circleService.getAllReceivedRequest(smeId);
			receivedRequestSmes = smeDetailService.getAllReceivedRequestSmes(receivedRequests);
			mutualConnectionService.findMutualConnection(receivedRequestSmes, null, smeId);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return new ResponseEntity<List<SMEDto>>(receivedRequestSmes, HttpStatus.OK);
	}

	@PreAuthorize(RoleAccess.ADMIN)
	@GetMapping(UrlMapping.GET_SENT_REQUEST)
	public ResponseEntity<?> getSentRequest(@PathVariable String smeId) {

		List<SendRequest> sentRequests = null;
		List<SMEDto> sentRequestSmes = null;
		try {
			sentRequests = circleService.getAllSentRequest(smeId);
			sentRequestSmes = smeDetailService.getAllSentRequestSmes(sentRequests);
			mutualConnectionService.findMutualConnection(sentRequestSmes, null, smeId);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<List<SMEDto>>(sentRequestSmes, HttpStatus.OK);
	}

	@PreAuthorize(RoleAccess.ADMIN)
	@GetMapping(UrlMapping.GET_CONNECTION)
	public ResponseEntity<?> getBusinessCircleConnection(
			@RequestParam(value = RequestRaram.connectionParamKey, required = false) String source,
			@PathVariable String smeId) {

		List<MyConnection> myCircleConnections = null;
		List<SMEDto> circleConnectedSmes = null;

		try {
			myCircleConnections = circleService.getAllConnections(smeId);
			if (source != null && source.equals(RequestRaram.connectionParamValue)) {
				return ResponseEntity.ok(myCircleConnections);
			}

			circleConnectedSmes = smeDetailService.getAllConnectedSmes(myCircleConnections);
			mutualConnectionService.findMutualConnection(circleConnectedSmes, myCircleConnections, null);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ResponseEntity.ok(circleConnectedSmes);
	}

	@PreAuthorize(RoleAccess.ADMIN_AND_USER)
	@GetMapping(UrlMapping.GET_SME_CONNECTION)
	public ResponseEntity<?> getSMEBusinessCircleConnection(@PathVariable String smeId,
			@PathVariable String loggedInSmeId) {

		List<MyConnection> smeCircleConnections = null;
		List<SMEDto> circleConnectedSmes = null;
		SMECircle loggedInSmeCircle = null;

		try {
			String privacy = circleService.getPrivacy(smeId);
			if (privacy.equals(CirclePrivacy.PRIVATE)) {
				throw new CustomException("This Circle is Private", HttpStatus.BAD_REQUEST);
			}
			smeCircleConnections = circleService.getAllConnections(smeId);
			if (privacy.equals(CirclePrivacy.MY_CIRCLE)) {
				boolean bool = smeCircleConnections.parallelStream()
						.anyMatch(conn -> conn.getMySmeConnectionId().equals(loggedInSmeId));
				if (!bool) {
					throw new CustomException("This Circle is Private", HttpStatus.BAD_REQUEST);
				}
			}
			circleConnectedSmes = smeDetailService.getAllConnectedSmes(smeCircleConnections);
			try {
				loggedInSmeCircle = circleService.getBusinessCircle(loggedInSmeId);
			} catch (CustomException e) {

			}
			if (loggedInSmeCircle.getMyConnections() != null && loggedInSmeCircle.getMyConnections().size() > 0)
				mutualConnectionService.findMutualConnection(circleConnectedSmes, loggedInSmeCircle.getMyConnections(),
						loggedInSmeId);
			smeStatusCheckService.checkStatus(loggedInSmeCircle, circleConnectedSmes, loggedInSmeId);

		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (IllegalArgumentException e) {
			throw new CustomException(e.getMessage(), HttpStatus.CONFLICT);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<List<SMEDto>>(circleConnectedSmes, HttpStatus.OK);
	}

	@PreAuthorize(RoleAccess.ADMIN)
	@GetMapping(UrlMapping.GET_BUSINESS_CIRCLE)
	public ResponseEntity<?> getBusinessCircle(@PathVariable String smeId) {

		SMECircle myCircle = null;
		SMECircleDto myCircleDto = null;
		try {
			myCircle = circleService.getBusinessCircle(smeId);
			myCircleDto = smeDetailService.getSMECircle(myCircle);

		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<SMECircleDto>(myCircleDto, HttpStatus.OK);
	}

	@PreAuthorize(RoleAccess.ADMIN)
	@GetMapping(UrlMapping.GET_RECEIVED_REQ_COUNT)
	public ResponseEntity<?> getReceivedRequestCount(@PathVariable String smeId) {

		Integer count = null;
		try {
			count = circleService.getCount(smeId);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<Integer>(count, HttpStatus.OK);
	}

	@PreAuthorize(RoleAccess.ADMIN)
	@GetMapping(UrlMapping.GET_PEOPLE_YOU_MAY_KNOW)
	public ResponseEntity<?> getPeopleYouMayKnow(@PathVariable String smeId) {

		List<SMEDto> smes = null;

		try {
			smes = circleService.getPeopleYouMayKnow(smeId);
			if (smes.size() <= 0) {
				throw new CustomException("No more SME's available for Business Circle", HttpStatus.NOT_FOUND);
			}
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<List<SMEDto>>(smes, HttpStatus.OK);
	}

	@PreAuthorize(RoleAccess.ADMIN)
	@PostMapping(UrlMapping.CHANGE_PRIVACY)
	public ResponseEntity<?> changeCirclePrivacy(@RequestBody Privacy circlePrivacy) {
		try {
			circleService.changeCirclePrivacy(circlePrivacy);
		} catch (CustomException e) {
			throw e;
		} catch (Exception e) {
			throw new CustomException("Privacy Can Not Changed Successfully", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return ResponseEntity.ok(new CustomHttpResponse("Circle Privacy Changed Successfully", HttpStatus.OK));
	}

}
