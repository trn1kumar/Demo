package com.smeface.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.smeface.common.audit.Auditable;
import com.smeface.constants.CircleModuleConstants.CirclePrivacy;

@Entity
@Table(name = "sme_circle")
public class SMECircle extends Auditable {

	@Id
	@Column(name = "SmeId", unique = true, updatable = false)
	private String sUuid;
	
	@Column(name = "uuid", unique = true, updatable = false)
	private String uuid;

	@Column(name = "circlePrivacy")
	private String circlePrivacy = CirclePrivacy.PUBLIC;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "SmeId", nullable = false)
	private List<SendRequest> sendRequests;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "SmeId", nullable = false)
	private List<ReceiveRequest> receiveRequests;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "SmeId", nullable = false)
	private List<MyConnection> myConnections;

	public SMECircle() {
		super();
	}

	public SMECircle(String sUuid, List<ReceiveRequest> receiveRequests) {
		super();
		this.sUuid = sUuid;
		this.receiveRequests = receiveRequests;
	}

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public List<SendRequest> getSendRequests() {
		return sendRequests;
	}

	public void setSendRequests(List<SendRequest> sendRequests) {
		this.sendRequests = sendRequests;
	}

	public List<ReceiveRequest> getReceiveRequests() {
		return receiveRequests;
	}

	public void setReceiveRequests(List<ReceiveRequest> receiveRequests) {
		this.receiveRequests = receiveRequests;
	}

	public List<MyConnection> getMyConnections() {
		return myConnections;
	}

	public void setMyConnections(List<MyConnection> myConnections) {
		this.myConnections = myConnections;
	}

	public String getCirclePrivacy() {
		return circlePrivacy;
	}

	public void setCirclePrivacy(String circlePrivacy) {
		this.circlePrivacy = circlePrivacy;
	}

}
