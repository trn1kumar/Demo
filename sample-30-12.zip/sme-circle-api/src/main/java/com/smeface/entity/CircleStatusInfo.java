package com.smeface.entity;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import com.smeface.common.audit.Auditable;

@MappedSuperclass
public class CircleStatusInfo extends Auditable {

	@Column(name = "status")
	private String status;

	@Column(name = "status_updated_by")
	private String statusUpdatedBy;

	public CircleStatusInfo() {
		super();
	}

	public CircleStatusInfo(String status) {
		super();
		this.status = status;
	}

	public CircleStatusInfo(String status, String statusUpdatedBy) {
		super();
		this.status = status;
		this.statusUpdatedBy = statusUpdatedBy;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusUpdatedBy() {
		return statusUpdatedBy;
	}

	public void setStatusUpdatedBy(String statusUpdatedBy) {
		this.statusUpdatedBy = statusUpdatedBy;
	}
	
}
