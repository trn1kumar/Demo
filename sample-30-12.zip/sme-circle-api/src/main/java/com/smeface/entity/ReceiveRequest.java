package com.smeface.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "sme_receive_request")
public class ReceiveRequest extends CircleStatusInfo{

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ReceiveRequestId")
	private Long receiveRequestId;
	
	@Column(name = "ReceiveReqUuid", unique = true, updatable = false)
	private String receiveReqUuid;

	@Column(name = "FromSmeId")
	private String fromSmeId;
	
	
	public ReceiveRequest() {
		super();
	}

	public ReceiveRequest(String receiveReqUuid,String fromSmeId, String status) {
		super(status);
		this.receiveReqUuid=receiveReqUuid;
		this.fromSmeId = fromSmeId;
	}

	public Long getReceiveRequestId() {
		return receiveRequestId;
	}

	public void setReceiveRequestId(Long receiveRequestId) {
		this.receiveRequestId = receiveRequestId;
	}

	public String getFromSmeId() {
		return fromSmeId;
	}

	public void setFromSmeId(String fromSmeId) {
		this.fromSmeId = fromSmeId;
	}

	public String getReceiveReqUuid() {
		return receiveReqUuid;
	}

	public void setReceiveReqUuid(String receiveReqUuid) {
		this.receiveReqUuid = receiveReqUuid;
	}
	
	

	

}
