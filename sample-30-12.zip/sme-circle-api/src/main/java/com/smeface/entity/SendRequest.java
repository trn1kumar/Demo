package com.smeface.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "sme_send_request")
public class SendRequest extends CircleStatusInfo{

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "SendRequestId")
	private Long sendRequestId;
	
	@Column(name = "SendReqUuid",unique=true,updatable=false)
	private String sendReqUuid;

	@Column(name = "to_sme_id")
	private String toSmeId;

	public Long getSendRequestId() {
		return sendRequestId;
	}

	public void setSendRequestId(Long sendRequestId) {
		this.sendRequestId = sendRequestId;
	}

	public String getToSmeId() {
		return toSmeId;
	}

	public void setToSmeId(String toSmeId) {
		this.toSmeId = toSmeId;
	}

	public String getSendReqUuid() {
		return sendReqUuid;
	}

	public void setSendReqUuid(String sendReqUuid) {
		this.sendReqUuid = sendReqUuid;
	}

	


}
