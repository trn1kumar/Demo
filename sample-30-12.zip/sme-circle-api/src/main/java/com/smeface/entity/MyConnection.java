package com.smeface.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "sme_connetion")
public class MyConnection extends CircleStatusInfo {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "connetionId")
	private Long connectionId;
	
	@Column(name = "connectionUuId",unique=true,updatable=false)
	private String connectionUuid;

	@Column(name = "mySmeConnectionIds")
	private String mySmeConnectionId;

	public MyConnection() {
		super();
	}

	public MyConnection(String connectionUuid,String mySmeConnectionId,String status,String statusUpdatedBy) {
		super(status,statusUpdatedBy);
		this.connectionUuid=connectionUuid;
		this.mySmeConnectionId = mySmeConnectionId;
	}

	public Long getConnectionId() {
		return connectionId;
	}

	public void setConnectionId(Long connectionId) {
		this.connectionId = connectionId;
	}

	public String getMySmeConnectionId() {
		return mySmeConnectionId;
	}

	public void setMySmeConnectionId(String mySmeConnectionId) {
		this.mySmeConnectionId = mySmeConnectionId;
	}

	public String getConnectionUuid() {
		return connectionUuid;
	}

	public void setConnectionUuid(String connectionUuid) {
		this.connectionUuid = connectionUuid;
	}



	
	


}
