package com.smeface.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;


@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SMEDto {

	private String smeName;

	private String sUuid;
	
	private String contactPerson;
	
	private String logoImage;
	
	private AddressDto smeAddress;
	
	private String receiveReqUuid;
	
	private String sendReqUuid;
	
	private String connectionUuid;
	
	private String daysAgoReqCreated;
	
	private String status;

	private Integer mutualConnectionCount;
	
	private List<SMEDto> mutualConnections;
	
	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}
	
	

	public String getReceiveReqUuid() {
		return receiveReqUuid;
	}

	public void setReceiveReqUuid(String receiveReqUuid) {
		this.receiveReqUuid = receiveReqUuid;
	}

	public String getSendReqUuid() {
		return sendReqUuid;
	}

	public void setSendReqUuid(String sendReqUuid) {
		this.sendReqUuid = sendReqUuid;
	}
	public String getDaysAgoReqCreated() {
		return daysAgoReqCreated;
	}

	public void setDaysAgoReqCreated(String daysAgoReqCreated) {
		this.daysAgoReqCreated = daysAgoReqCreated;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public String getSmeName() {
		return smeName;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public Integer getMutualConnectionCount() {
		return mutualConnectionCount;
	}

	public void setMutualConnectionCount(Integer mutualConnectionCount) {
		this.mutualConnectionCount = mutualConnectionCount;
	}

	public String getConnectionUuid() {
		return connectionUuid;
	}

	public void setConnectionUuid(String connectionUuid) {
		this.connectionUuid = connectionUuid;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getLogoImage() {
		return logoImage;
	}

	public void setLogoImage(String logoImage) {
		this.logoImage = logoImage;
	}

	public List<SMEDto> getMutualConnections() {
		return mutualConnections;
	}

	public void setMutualConnections(List<SMEDto> mutualConnections) {
		this.mutualConnections = mutualConnections;
	}

	@Override
	public String toString() {
		return "SMEDto [smeName=" + smeName + ", sUuid=" + sUuid + ", contactPerson=" + contactPerson + ", logoImage="
				+ logoImage + ", receiveReqUuid=" + receiveReqUuid + ", sendReqUuid=" + sendReqUuid
				+ ", connectionUuid=" + connectionUuid + ", status=" + status + ", mutualConnectionCount="
				+ mutualConnectionCount + ", mutualConnections=" + mutualConnections + "]";
	}

	public AddressDto getSmeAddress() {
		return smeAddress;
	}

	public void setSmeAddress(AddressDto smeAddress) {
		this.smeAddress = smeAddress;
	}

	





	
	
	


}
