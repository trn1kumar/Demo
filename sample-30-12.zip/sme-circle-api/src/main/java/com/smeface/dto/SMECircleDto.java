package com.smeface.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class SMECircleDto {
	
	
	private String sUuid;
	
	private List<SMEDto> sendRequests;
	
	private List<SMEDto> receiveRequests;
	
	private List<SMEDto> myConnetions;
	
	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public List<SMEDto> getSendRequests() {
		return sendRequests;
	}

	public void setSendRequests(List<SMEDto> sendRequests) {
		this.sendRequests = sendRequests;
	}

	public List<SMEDto> getReceiveRequests() {
		return receiveRequests;
	}

	public void setReceiveRequests(List<SMEDto> receiveRequests) {
		this.receiveRequests = receiveRequests;
	}

	public List<SMEDto> getMyConnetions() {
		return myConnetions;
	}

	public void setMyConnetions(List<SMEDto> myConnetions) {
		this.myConnetions = myConnetions;
	}

	

	
	
	
	
}
