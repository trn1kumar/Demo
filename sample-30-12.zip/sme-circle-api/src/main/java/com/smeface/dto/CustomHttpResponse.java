package com.smeface.dto;

import org.springframework.http.HttpStatus;

public class CustomHttpResponse {
	
	private String message;
	
	private HttpStatus code;

	public CustomHttpResponse(String message, HttpStatus code) {
		super();
		this.setMessage(message);
		this.setCode(code);
	}
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public HttpStatus getCode() {
		return code;
	}

	public void setCode(HttpStatus code) {
		this.code = code;
	}
	
	
	
}
