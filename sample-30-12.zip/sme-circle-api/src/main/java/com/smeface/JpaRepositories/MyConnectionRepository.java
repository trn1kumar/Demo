package com.smeface.JpaRepositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smeface.entity.MyConnection;

public interface MyConnectionRepository extends JpaRepository<MyConnection, Long>{
	public MyConnection findByConnectionUuidAndStatus(String connectionUuId,String status);
}
