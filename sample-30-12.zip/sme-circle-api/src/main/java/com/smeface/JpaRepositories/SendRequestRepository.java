package com.smeface.JpaRepositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smeface.entity.SendRequest;

public interface SendRequestRepository extends JpaRepository<SendRequest, Long>{
	
	public SendRequest findBySendReqUuidAndStatus(String sendReqUuid, String pending);

}
