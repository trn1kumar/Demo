package com.smeface.JpaRepositories;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.smeface.entity.SMECircle;

public interface SMECircleRepository extends JpaRepository<SMECircle, String> {

	Optional<SMECircle> findBySUuid(String smeId);

	@Modifying
	@Transactional
	@Query("update SMECircle c set c.circlePrivacy = :privacy where c.sUuid = :smeId")
	void changePrivacy(@Param("smeId") String smeId,@Param("privacy") String privacy);

	@Query("select circlePrivacy from SMECircle c where c.sUuid = :smeId")
	String getPriavcy(@Param("smeId") String smeId);

}
