package com.smeface.JpaRepositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smeface.entity.ReceiveRequest;

public interface ReceiveRequestRepository extends JpaRepository<ReceiveRequest, Long> {

	public ReceiveRequest findByReceiveReqUuidAndStatus(String receiveReqUuid,String status);

}
