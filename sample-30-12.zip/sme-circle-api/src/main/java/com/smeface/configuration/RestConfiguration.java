package com.smeface.configuration;

import javax.annotation.Resource;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.smeface.rest.endpoints.SmeInformationEndPoint;

@Configuration
@PropertySource(value = { "classpath:application.properties" })
public class RestConfiguration {

	@Resource
	private Environment environment;


	@Bean
	public SmeInformationEndPoint smeInformationConfiguration() {
		Client client = ClientBuilder.newClient();
		String smeInformationEndPoint = environment.getRequiredProperty("sme.endpoint");
		String listAllSme = environment.getRequiredProperty("list.all.sme.path");
		String listSme = environment.getRequiredProperty("list.sme.path");
		SmeInformationEndPoint smeInformation = new SmeInformationEndPoint(client, smeInformationEndPoint, listAllSme,listSme);
		return smeInformation;
	}

}
