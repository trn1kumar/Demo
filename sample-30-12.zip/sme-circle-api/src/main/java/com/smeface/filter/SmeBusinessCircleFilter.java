package com.smeface.filter;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.smeface.dto.SMEDto;
import com.smeface.entity.MyConnection;
import com.smeface.entity.ReceiveRequest;
import com.smeface.entity.SMECircle;
import com.smeface.entity.SendRequest;

@Component
public class SmeBusinessCircleFilter {

	public List<String> myCircles = null;

	/*
	 * @ filter My Circle
	 */
	public List<SMEDto> filterMyCircle(SMECircle myCircle, List<SMEDto> smes) {
		
		myCircles = new ArrayList<String>();
		
		if (myCircle.getMyConnections() != null && myCircle.getMyConnections().size() > 0) {
			for (MyConnection conn : myCircle.getMyConnections()) {
				myCircles.add(conn.getMySmeConnectionId());
			}
		}

		if (myCircle.getSendRequests() != null && myCircle.getSendRequests().size() > 0) {
			for (SendRequest req : myCircle.getSendRequests()) {
				myCircles.add(req.getToSmeId());

			}
		}

		if (myCircle.getReceiveRequests() != null && myCircle.getReceiveRequests().size() > 0) {
			for (ReceiveRequest req : myCircle.getReceiveRequests()) {
				myCircles.add(req.getFromSmeId());
			}
		}

		for (String smeUuid : myCircles) {
			smes = smes.parallelStream().filter(sme -> !sme.getsUuid().equals(smeUuid)).collect(Collectors.toList());
		} 

		myCircles=null;
		return smes;

	}

}
