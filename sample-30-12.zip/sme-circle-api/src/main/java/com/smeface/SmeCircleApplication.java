package com.smeface;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmeCircleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmeCircleApplication.class, args);
	}
}
