package com.smeface.service;

import java.util.List;

import com.smeface.dto.SMEDto;
import com.smeface.entity.MyConnection;
import com.smeface.entity.ReceiveRequest;
import com.smeface.entity.SMECircle;
import com.smeface.entity.SendRequest;

public interface SMEStatusCheckService {

	public void checkStatus(SMECircle myCircle, List<SMEDto> smes,String smeId);

	public void setStatusOfMyConnectedSmes(List<MyConnection> myConn, List<SMEDto> smes);

	public void setStatusOfSentReqSmes(List<SendRequest> sentReq, List<SMEDto> smes);

	public void setStatusOfRecievedReqSmes(List<ReceiveRequest> recieveReq, List<SMEDto> smes);
}
