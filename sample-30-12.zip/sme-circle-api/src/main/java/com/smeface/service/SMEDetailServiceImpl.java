package com.smeface.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smeface.dto.SMECircleDto;
import com.smeface.dto.SMEDto;
import com.smeface.entity.MyConnection;
import com.smeface.entity.ReceiveRequest;
import com.smeface.entity.SMECircle;
import com.smeface.entity.SendRequest;

@Service
public class SMEDetailServiceImpl {
	
	@Autowired
	SMEService smeService;
	
	
	public List<SMEDto> getAllReceivedRequestSmes(List<ReceiveRequest> requests) {
		List<SMEDto> receivedRequestSmes = new ArrayList<>();
		requests.stream().forEach(req -> {
			SMEDto sme = smeService.getSME(req.getFromSmeId());
			sme.setDaysAgoReqCreated(this.getDaysAgoCreatedReq(req.getCreationDate()));
			sme.setReceiveReqUuid(req.getReceiveReqUuid());
			receivedRequestSmes.add(sme);
		});

		return receivedRequestSmes;
	}

	
	public List<SMEDto> getAllSentRequestSmes(List<SendRequest> sentRequests) {
		List<SMEDto> sentRequestSmes = new ArrayList<>();
		sentRequests.stream().forEach(req -> {
			SMEDto sme = smeService.getSME(req.getToSmeId());
			sme.setDaysAgoReqCreated(this.getDaysAgoCreatedReq(req.getCreationDate()));
			sme.setSendReqUuid(req.getSendReqUuid());
			sentRequestSmes.add(sme);
		});
		return sentRequestSmes;
	}

	public List<SMEDto> getAllConnectedSmes(List<MyConnection> circleConnections) {
		List<SMEDto> circleConnectionSmes = new ArrayList<>();
		circleConnections.stream().forEach(conn -> {
			SMEDto sme = smeService.getSME(conn.getMySmeConnectionId());
			sme.setConnectionUuid(conn.getConnectionUuid());
			circleConnectionSmes.add(sme);
		});
		return circleConnectionSmes;
	}

	public SMECircleDto getSMECircle(SMECircle myCircle) {
		SMECircleDto circleDto = new SMECircleDto();
		circleDto.setsUuid(myCircle.getsUuid());
		if (myCircle.getSendRequests() != null && myCircle.getSendRequests().size() > 0) {
			circleDto.setSendRequests(this.getAllSentRequestSmes(myCircle.getSendRequests()));
		}
		if (myCircle.getReceiveRequests() != null && myCircle.getReceiveRequests().size() > 0) {
			circleDto.setReceiveRequests(this.getAllReceivedRequestSmes(myCircle.getReceiveRequests()));
		}
		if (myCircle.getMyConnections() != null && myCircle.getMyConnections().size() > 0) {
			circleDto.setMyConnetions(this.getAllConnectedSmes(myCircle.getMyConnections()));
		}
		return circleDto;
	}

	@SuppressWarnings("deprecation")
	public String getDaysAgoCreatedReq(Date date) {

		Date firstDate = null;
		Date secondDate = null;

		firstDate = date;
		secondDate = new Date();

		Long diffInMillies = Math.abs(secondDate.getTime() - firstDate.getTime());
		Long diffInMin = TimeUnit.MINUTES.convert(diffInMillies, TimeUnit.MILLISECONDS);
		if (diffInMin == 0)
			return "just now";
		else if (diffInMin < 60)
			return String.valueOf(diffInMin) + " minutes ago";

		Long diffInHours = TimeUnit.HOURS.convert(diffInMillies, TimeUnit.MILLISECONDS);
		if (diffInHours < 24)
			return String.valueOf(diffInHours) + " hours ago";

		Long diffInDays = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);

		if (diffInDays <= 7)
			return String.valueOf(diffInDays) + " days ago";

		if (diffInDays > 7 && diffInDays <= 14)
			return "1 week ago";
		if (diffInDays > 14 && diffInDays <= 21)
			return "2 weeks ago";
		if (diffInDays > 21 && diffInDays <= 28)
			return "3 weeks ago";
		else
			return firstDate.toLocaleString();
	}

}
