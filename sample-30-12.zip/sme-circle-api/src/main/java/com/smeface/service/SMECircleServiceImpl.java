
package com.smeface.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.smeface.JpaRepositories.MyConnectionRepository;
import com.smeface.JpaRepositories.ReceiveRequestRepository;
import com.smeface.JpaRepositories.SMECircleRepository;
import com.smeface.JpaRepositories.SendRequestRepository;
import com.smeface.circle.vo.ConnectionVo;
import com.smeface.constants.CircleModuleConstants.CirclePrivacy;
import com.smeface.constants.CircleModuleConstants.CircleStatus;
import com.smeface.dto.SMEDto;
import com.smeface.entity.MyConnection;
import com.smeface.entity.ReceiveRequest;
import com.smeface.entity.SMECircle;
import com.smeface.entity.SendRequest;
import com.smeface.exception.CustomException;
import com.smeface.filter.SmeBusinessCircleFilter;
import com.smeface.model.Privacy;
import com.smeface.util.CollectionUtil;
import com.smeface.util.UuidUtil;

@Service
public class SMECircleServiceImpl implements SMECircleService {

	@Autowired
	SMECircleRepository circleRepository;

	@Autowired
	ReceiveRequestRepository receiveRequestRepository;

	@Autowired
	SendRequestRepository sendRequestRepository;

	@Autowired
	MyConnectionRepository connectionRepository;

	@Autowired
	SMEService smeService;

	@Autowired
	CollectionUtil collectionUtil;

	@Autowired
	MutualConnectionService mutualConnectionService;

	@Autowired
	SmeBusinessCircleFilter smeBusinessCircleFilter;

	public void addSendRequest(SMECircle circle) {

		SMECircle existCircle = null;
		try {

			existCircle = this.getBusinessCircle(circle.getsUuid());

		} catch (CustomException e) {
		}
		if (existCircle != null) {

			List<SendRequest> requests = existCircle.getSendRequests();
			requests.forEach(req -> {
				if (req.getToSmeId().equals(circle.getSendRequests().get(0).getToSmeId())) {
					throw new CustomException("Request already sent.", HttpStatus.ALREADY_REPORTED);
				}
			});

			List<MyConnection> myConnections = existCircle.getMyConnections();
			myConnections.forEach(con -> {
				if (con.getMySmeConnectionId().equals(circle.getSendRequests().get(0).getToSmeId())) {
					throw new CustomException("This SME is Already Connected.", HttpStatus.ALREADY_REPORTED);
				}
			});

			circle.getSendRequests().forEach(newReq -> {
				newReq.setSendReqUuid(UuidUtil.getUuid());
				newReq.setStatus(CircleStatus.PENDING);
			});
			requests.addAll(circle.getSendRequests());

			this.saveOrUpdateSMECricle(existCircle);

			this.addReceiveRequest(circle);
		} else {
			circle.getSendRequests().forEach(newReq -> {
				newReq.setSendReqUuid(UuidUtil.getUuid());
				newReq.setStatus(CircleStatus.PENDING);
			});
			this.saveOrUpdateSMECricle(circle);

			this.addReceiveRequest(circle);
		}

	}

	private void addReceiveRequest(SMECircle circle) {
		SMECircle newCircle = null;
		List<ReceiveRequest> receiveRequests = null;

		/*
		 * @ find sme in circle table
		 */

		Optional<SMECircle> existCircleOpt = circleRepository.findBySUuid(circle.getSendRequests().get(0).getToSmeId());

		/*
		 * @if present add new receive request into existing receive request
		 */
		if (existCircleOpt.isPresent()) {
			SMECircle existCircle = existCircleOpt.get();
			List<ReceiveRequest> requests = existCircle.getReceiveRequests();
			requests.add(new ReceiveRequest(UuidUtil.getUuid(), circle.getsUuid(), CircleStatus.PENDING));

			this.saveOrUpdateSMECricle(existCircle);

		} else {

			/*
			 * @else create new circle and add receive request
			 */

			receiveRequests = new ArrayList<ReceiveRequest>();
			receiveRequests.add(new ReceiveRequest(UuidUtil.getUuid(), circle.getsUuid(), CircleStatus.PENDING));

			String smeId = circle.getSendRequests().get(0).getToSmeId();
			newCircle = new SMECircle(smeId, receiveRequests);

			this.saveOrUpdateSMECricle(newCircle);
		}
	}

	@Override
	public void saveOrUpdateSMECricle(SMECircle smeCircle) {
		try {
			circleRepository.save(smeCircle);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomException("Error while saving SMECircle", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public SMECircle getBusinessCircle(String smeId) {

		Optional<SMECircle> circle = circleRepository.findBySUuid(smeId);
		if (circle.isPresent()) {
			SMECircle cir = circle.get();
			List<SendRequest> filteredList = cir.getSendRequests().stream()
					.filter(req -> req.getStatus().equals(CircleStatus.PENDING)).collect(Collectors.toList());

			List<ReceiveRequest> filteredList1 = cir.getReceiveRequests().stream()
					.filter(req -> req.getStatus().equals(CircleStatus.PENDING)).collect(Collectors.toList());

			List<MyConnection> filteredList2 = cir.getMyConnections().stream()
					.filter(conn -> conn.getStatus().equals(CircleStatus.CONNECTED)).collect(Collectors.toList());

			// reverse for get latest record 1st
			collectionUtil.reverse(filteredList);
			collectionUtil.reverse(filteredList1);
			collectionUtil.reverse(filteredList2);

			cir.setSendRequests(filteredList);
			cir.setReceiveRequests(filteredList1);
			cir.setMyConnections(filteredList2);
			return cir;
		} else {
			throw new CustomException("BusinessCircle not found for " + smeId, HttpStatus.NOT_FOUND);
		}

	}

	@Override
	public List<MyConnection> getAllConnections(String smeId) {
		SMECircle circle = this.getBusinessCircle(smeId);
		List<MyConnection> myConnections = circle.getMyConnections();
		if (myConnections != null && myConnections.size() > 0) {
			return myConnections;
		} else {
			throw new CustomException("There is no connection in " + smeId + " business circle", HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public List<ReceiveRequest> getAllReceivedRequest(String smeId) {
		List<ReceiveRequest> requests = null;
		requests = this.getBusinessCircle(smeId).getReceiveRequests();
		if (requests != null && requests.size() > 0) {
			return requests;
		} else
			throw new CustomException("No pending received request available for " + smeId, HttpStatus.FOUND);

	}

	@Override
	public List<SendRequest> getAllSentRequest(String smeId) {
		List<SendRequest> requests = null;
		requests = this.getBusinessCircle(smeId).getSendRequests();
		if (requests != null && requests.size() > 0) {
			return requests;
		} else
			throw new CustomException("No sent request available for " + smeId, HttpStatus.FOUND);

	}

	@Override
	public void acceptConnection(ConnectionVo connectionVo) {
		List<MyConnection> myConnetions = null;
		List<MyConnection> myConnetions1 = null;

		/*
		 * @Get ReceivedRequest by SmeId and update it by request accepted
		 */

		ReceiveRequest receiveRequest = this.getReceivedRequest(connectionVo.getReceiveReqUuid());
		if (receiveRequest == null) {
			throw new CustomException("No ReceiveRequest Pending with " + connectionVo.getReceiveReqUuid(),
					HttpStatus.NOT_FOUND);
		}
		receiveRequest.setStatus(CircleStatus.ACCEPTED);
		receiveRequest.setStatusUpdatedBy(connectionVo.getsUuid());
		this.saveReceivedRequest(receiveRequest);

		/*
		 * @getBusinessCircle of sme
		 */

		SMECircle circle = this.getBusinessCircle(connectionVo.getsUuid());

		// if it's connection is not null then add new connection in existing connection
		if (circle.getMyConnections() != null && circle.getMyConnections().size() > 0) {
			circle.getMyConnections().add(new MyConnection(UuidUtil.getUuid(), receiveRequest.getFromSmeId(),
					CircleStatus.CONNECTED, connectionVo.getsUuid()));
		} else {
			// otherwise create new connection and add connection in it
			myConnetions = new ArrayList<MyConnection>();
			myConnetions.add(new MyConnection(UuidUtil.getUuid(), receiveRequest.getFromSmeId(), CircleStatus.CONNECTED,
					connectionVo.getsUuid()));
			circle.setMyConnections(myConnetions);
		}

		this.saveOrUpdateSMECricle(circle);

		/*
		 * edit connection of request sent sme
		 */
		myConnetions1 = new ArrayList<MyConnection>();
		SMECircle circle2 = this.getBusinessCircle(receiveRequest.getFromSmeId());

		List<SendRequest> requests = circle2.getSendRequests();
		requests.forEach(sendRequest -> {
			if (sendRequest.getToSmeId().equals(connectionVo.getsUuid())) {

				// edit send request with accepted
				sendRequest.setStatus(CircleStatus.ACCEPTED);
				sendRequest.setStatusUpdatedBy(connectionVo.getsUuid());
				this.saveSendRequest(sendRequest);
			}
		});

		// if it's connection is not null then add new connection in existing connection
		if (circle2.getMyConnections() != null && circle2.getMyConnections().size() > 0) {
			circle2.getMyConnections().add(new MyConnection(UuidUtil.getUuid(), connectionVo.getsUuid(),
					CircleStatus.CONNECTED, connectionVo.getsUuid()));
		} else {
			// otherwise create new connection and add connection in it
			myConnetions1 = new ArrayList<MyConnection>();
			myConnetions1.add(new MyConnection(UuidUtil.getUuid(), connectionVo.getsUuid(), CircleStatus.CONNECTED,
					connectionVo.getsUuid()));
			circle2.setMyConnections(myConnetions1);
		}

		this.saveOrUpdateSMECricle(circle2);

	}

	@Override
	public void removeConnection(ConnectionVo connectionVo) {

		/*
		 * @Get MyConnection by SmeId and update it by connection disconnected
		 */

		MyConnection myConnection = this.getConnection(connectionVo.getConnectionUuid());
		myConnection.setStatus(CircleStatus.DISCONNECTED);
		myConnection.setStatusUpdatedBy(connectionVo.getsUuid());
		this.saveMyConnection(myConnection);

		/*
		 * @Get MyConnection of connectedSmeId and update it by connection disconnected
		 */

		SMECircle myCircle = this.getBusinessCircle(myConnection.getMySmeConnectionId());
		List<MyConnection> myConnections = myCircle.getMyConnections();
		myConnections.forEach(conn -> {
			if (conn.getMySmeConnectionId().equals(connectionVo.getsUuid())) {
				conn.setStatus(CircleStatus.DISCONNECTED);
				conn.setStatusUpdatedBy(connectionVo.getsUuid());
				this.saveMyConnection(conn);
			}
		});
	}

	@Override
	public void cancelSentRequest(ConnectionVo connectionVo) {

		/*
		 * @ @Get SendRequest by SmeId and update it by request canceled
		 */
		SendRequest sendRequest = this.getSentRequest(connectionVo.getSendReqUuid());

		sendRequest.setStatus(CircleStatus.CANCELED);
		sendRequest.setStatusUpdatedBy(connectionVo.getsUuid());
		this.saveSendRequest(sendRequest);

		/*
		 * @Get ReceivedRequest of ReceiverSmeId and update it by request canceled
		 */

		SMECircle smeCircle = this.getBusinessCircle(sendRequest.getToSmeId());
		List<ReceiveRequest> receiveRequests = smeCircle.getReceiveRequests();
		receiveRequests.forEach(req -> {
			if (req.getFromSmeId().equals(connectionVo.getsUuid())) {
				req.setStatus(CircleStatus.CANCELED);
				req.setStatusUpdatedBy(connectionVo.getsUuid());
				this.saveReceivedRequest(req);
			}
		});

	}

	@Override
	public void rejectReceivedRequest(ConnectionVo connectionVo) {

		/*
		 * @Get ReceivedRequest by SmeId and update it by request deleted
		 */

		ReceiveRequest receiveRequest = this.getReceivedRequest(connectionVo.getReceiveReqUuid());
		receiveRequest.setStatus(CircleStatus.REJECTED);
		receiveRequest.setStatusUpdatedBy(connectionVo.getsUuid());
		this.saveReceivedRequest(receiveRequest);

		/*
		 * @Get SentRequest of SenderSmeId and update it by request deleted
		 */

		SMECircle circle1 = this.getBusinessCircle(receiveRequest.getFromSmeId());
		List<SendRequest> sentRequests = circle1.getSendRequests();
		sentRequests.forEach(sentRequest -> {
			if (sentRequest.getToSmeId().equals(connectionVo.getsUuid())) {
				sentRequest.setStatus(CircleStatus.REJECTED);
				sentRequest.setStatusUpdatedBy(connectionVo.getsUuid());
				this.saveSendRequest(sentRequest);
			}

		});

	}

	private void saveMyConnection(MyConnection myConnection) {
		connectionRepository.save(myConnection);
	}

	private void saveReceivedRequest(ReceiveRequest receiveRequest) {
		receiveRequestRepository.save(receiveRequest);
	}

	private void saveSendRequest(SendRequest sendRequest) {
		sendRequestRepository.save(sendRequest);
	}

	private MyConnection getConnection(String connectionUuId) {
		MyConnection myConnection = connectionRepository.findByConnectionUuidAndStatus(connectionUuId,
				CircleStatus.CONNECTED);

		if (myConnection == null) {
			throw new CustomException("No Connection with " + connectionUuId, HttpStatus.NOT_FOUND);
		}
		return myConnection;

	}

	private ReceiveRequest getReceivedRequest(String receiveReqUuid) {

		ReceiveRequest receiveRequest = receiveRequestRepository.findByReceiveReqUuidAndStatus(receiveReqUuid,
				CircleStatus.PENDING);

		if (receiveRequest == null) {
			throw new CustomException("No ReceiveRequest Pending with " + receiveReqUuid, HttpStatus.NOT_FOUND);
		}
		return receiveRequest;
	}

	private SendRequest getSentRequest(String sendReqUuid) {

		SendRequest sentRequest = sendRequestRepository.findBySendReqUuidAndStatus(sendReqUuid, CircleStatus.PENDING);
		if (sentRequest == null) {
			throw new CustomException("No Sent Request Pending With " + sendReqUuid, HttpStatus.NOT_FOUND);
		}

		return sentRequest;
	}

	@Override
	public Integer getCount(String smeId) {
		List<ReceiveRequest> requests = this.getBusinessCircle(smeId).getReceiveRequests();
		if (requests.size() > 0) {
			return requests.size();
		} else
			throw new CustomException("No Pending Request", HttpStatus.NOT_FOUND);
	}

	@Override
	public List<SMEDto> getPeopleYouMayKnow(String smeId) {

		List<SMEDto> smes = null;
		SMECircle myCircle = null;

		smes = smeService.getAllSME();
		smes = smes.parallelStream().filter(sme -> !sme.getsUuid().equals(smeId)).collect(Collectors.toList());

		try {
			myCircle = this.getBusinessCircle(smeId);

			/*
			 * @ filter sent request sme ,request received sme and already connected sme
			 * also set mutual connection of particular sme
			 */

			smes = smeBusinessCircleFilter.filterMyCircle(myCircle, smes);

			List<MyConnection> myConnections = myCircle.getMyConnections();
			if (myConnections != null && myConnections.size() > 0) {
				List<SMEDto> mutualConnectins = null;
				for (SMEDto sme : smes) {
					try {
						List<MyConnection> smeConnections = this.getAllConnections(sme.getsUuid());
						mutualConnectins = mutualConnectionService.getMutualConnection(myConnections, smeConnections);
						if (mutualConnectins != null && mutualConnectins.size() > 0) {
							sme.setMutualConnectionCount(mutualConnectins.size());
							sme.setMutualConnections(mutualConnectins);
						}

					} catch (CustomException e) {

					}
				}

			}
		} catch (CustomException e) {

		}

		return smes;

	}

	@Override
	public void changeCirclePrivacy(Privacy circlePrivacy) {
		if (circleRepository.existsById(circlePrivacy.getSmeId())) {

			switch (circlePrivacy.getPrivacy()) {
			case CirclePrivacy.MY_CIRCLE:
				circleRepository.changePrivacy(circlePrivacy.getSmeId(), CirclePrivacy.MY_CIRCLE);
				break;

			case CirclePrivacy.PRIVATE:
				circleRepository.changePrivacy(circlePrivacy.getSmeId(), CirclePrivacy.PRIVATE);
				break;

			case CirclePrivacy.PUBLIC:
				circleRepository.changePrivacy(circlePrivacy.getSmeId(), CirclePrivacy.PUBLIC);
				break;
			default:
				throw new CustomException(
						circlePrivacy.getPrivacy() + " is a invalid privacy. privacy should be one of them "
								+ CirclePrivacy.MY_CIRCLE + "," + CirclePrivacy.PRIVATE + "," + CirclePrivacy.PUBLIC,
						HttpStatus.BAD_REQUEST);
			}
		} else
			throw new CustomException("Circle Not Found for " + circlePrivacy.getSmeId(), HttpStatus.NOT_FOUND);
	}

	@Override
	public String getPrivacy(String smeId) {
		String privacy = circleRepository.getPriavcy(smeId);
		return privacy;
	}

}
