package com.smeface.service;

import java.util.List;

import com.smeface.circle.vo.ConnectionVo;
import com.smeface.dto.SMEDto;
import com.smeface.entity.MyConnection;
import com.smeface.entity.ReceiveRequest;
import com.smeface.entity.SMECircle;
import com.smeface.entity.SendRequest;
import com.smeface.model.Privacy;

public interface SMECircleService {

	public void addSendRequest(SMECircle circle);
	
	public void saveOrUpdateSMECricle(SMECircle circle);

	public SMECircle getBusinessCircle(String smeId);

	public Integer getCount(String smeId);

	public List<ReceiveRequest> getAllReceivedRequest(String smeId);

	public List<SendRequest> getAllSentRequest(String smeId);

	public void acceptConnection(ConnectionVo connectionVo);
	
	public void rejectReceivedRequest(ConnectionVo connectionVo);
	
	public void cancelSentRequest(ConnectionVo connectionVo);
	
	public void removeConnection(ConnectionVo connectionVo);

	public List<MyConnection> getAllConnections(String smeId);

	public List<SMEDto> getPeopleYouMayKnow(String smeId);

	public void changeCirclePrivacy(Privacy circlePrivacy);

	public String getPrivacy(String smeId);

	
	
}
