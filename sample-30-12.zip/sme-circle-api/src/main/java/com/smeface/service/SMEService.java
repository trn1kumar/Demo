package com.smeface.service;

import java.util.List;

import com.smeface.dto.SMEDto;
import com.smeface.entity.SMECircle;

public interface SMEService {

	public SMEDto getSME(String smeId);
	
	public List<SMEDto> getAllSME();

	public List<SMEDto> getPlatformListedSmes(SMECircle myCircle, String smeId);

}
