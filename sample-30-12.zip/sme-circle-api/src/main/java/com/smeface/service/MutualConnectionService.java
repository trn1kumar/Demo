package com.smeface.service;

import java.util.List;

import com.smeface.dto.SMEDto;
import com.smeface.entity.MyConnection;

public interface MutualConnectionService {

	public List<SMEDto> findMutualConnection(List<SMEDto> receivedRequestSmes, List<MyConnection> myCircleConnections,
			String loggedInSmeId);

	public List<SMEDto> getMutualConnection(List<MyConnection> myConnections, List<MyConnection> smeConnections);
}
