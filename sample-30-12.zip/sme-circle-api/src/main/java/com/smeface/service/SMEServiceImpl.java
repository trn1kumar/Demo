package com.smeface.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smeface.dto.SMEDto;
import com.smeface.entity.SMECircle;
import com.smeface.exception.CustomException;
import com.smeface.rest.endpoints.SmeInformationEndPoint;

@Service
public class SMEServiceImpl implements SMEService {

	@Autowired
	SmeInformationEndPoint smeInformationEndPoint;
	
	@Autowired
	SMEStatusCheckService smeStatusCheckService;
	
	
	@Override
	public SMEDto getSME(String smeId) {
		return smeInformationEndPoint.getSME(smeId);
	}
	
	@Override
	public List<SMEDto> getAllSME() {
		List<SMEDto> smes = null;
		try {
			smes = smeInformationEndPoint.getAllSME();
			return smes;

		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

	}

	@Override
	public List<SMEDto> getPlatformListedSmes(SMECircle myCircle, String smeId) {
		List<SMEDto> smes = this.getAllSME();
		smeStatusCheckService.checkStatus(myCircle, smes, smeId);

		return smes;
	}

}
