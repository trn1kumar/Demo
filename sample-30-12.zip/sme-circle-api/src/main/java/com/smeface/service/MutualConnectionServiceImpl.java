package com.smeface.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smeface.dto.SMEDto;
import com.smeface.entity.MyConnection;
import com.smeface.exception.CustomException;

import io.jsonwebtoken.lang.Assert;

@Service
public class MutualConnectionServiceImpl implements MutualConnectionService {

	@Autowired
	SMEService smeService;

	@Autowired
	SMECircleService circleService;

	@Override
	public List<SMEDto> getMutualConnection(List<MyConnection> myConnections, List<MyConnection> smeConnections) {

		List<SMEDto> mutualConnectins = new ArrayList<>();

		for (MyConnection myConnection : myConnections) {
			String connectionId = myConnection.getMySmeConnectionId();
			for (MyConnection smeConnection : smeConnections) {
				String connectionId1 = smeConnection.getMySmeConnectionId();
				if (connectionId.equals(connectionId1)) {

					SMEDto sme = smeService.getSME(connectionId1);
					mutualConnectins.add(sme);

					break;
				}
			}
		}
		return mutualConnectins;
	}

	@Override
	public List<SMEDto> findMutualConnection(List<SMEDto> smes, List<MyConnection> myCircleConnections,
			String loggedInSmeId) {

		List<SMEDto> mutualConnectins = null;
		List<MyConnection> myConnections = null;

		try {
			if (myCircleConnections != null) {
				// get mutual connection of own connections
				myConnections = myCircleConnections;
			} else {
				// get mutual connection of own sent requests and received requests and people
				// you may know
				StackTraceElement trace = new Exception().getStackTrace()[0];
				Assert.notNull(loggedInSmeId, "Id can not be null. Exception in " + trace.getClassName() + ". method "
						+ trace.getMethodName() + ". line number. " + trace.getLineNumber());

				myConnections = circleService.getAllConnections(loggedInSmeId);

			}

			for (SMEDto sme : smes) {
				try {
					if (!sme.getsUuid().equals(loggedInSmeId)) {
						List<MyConnection> smeConnections = circleService.getAllConnections(sme.getsUuid());
						mutualConnectins = this.getMutualConnection(myConnections, smeConnections);
						if (mutualConnectins != null && mutualConnectins.size() > 0) {
							sme.setMutualConnectionCount(mutualConnectins.size());
							sme.setMutualConnections(mutualConnectins);
						}
					}
				} catch (CustomException e) {

				}
			}

		} catch (CustomException e) {

		}
		return smes;
	}
}
