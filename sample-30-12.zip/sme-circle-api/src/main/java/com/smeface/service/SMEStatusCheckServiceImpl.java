package com.smeface.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.smeface.constants.CircleModuleConstants.SMEStatus;
import com.smeface.dto.SMEDto;
import com.smeface.entity.MyConnection;
import com.smeface.entity.ReceiveRequest;
import com.smeface.entity.SMECircle;
import com.smeface.entity.SendRequest;

@Service
public class SMEStatusCheckServiceImpl implements SMEStatusCheckService{
	
	@Override
	public void checkStatus(SMECircle myCircle, List<SMEDto> smes, String loggedInSmeId) {

		if (myCircle != null) {
			List<MyConnection> myConnections = myCircle.getMyConnections();
			if (myConnections != null && myConnections.size() > 0) {
				this.setStatusOfMyConnectedSmes(myConnections, smes);
			}

			List<SendRequest> sentReqs = myCircle.getSendRequests();
			if (sentReqs != null && sentReqs.size() > 0) {
				this.setStatusOfSentReqSmes(sentReqs, smes);
			}

			List<ReceiveRequest> recievedReqs = myCircle.getReceiveRequests();
			if (recievedReqs != null && recievedReqs.size() > 0) {
				this.setStatusOfRecievedReqSmes(recievedReqs, smes);
			}
		}

		smes.parallelStream().forEach(sme -> {
			if (sme.getsUuid().equals(loggedInSmeId)) {
				sme.setStatus(SMEStatus.OWNER);
			}
			if (sme.getStatus() == null) {
				sme.setStatus(SMEStatus.NEW);
			}
		});

		/*
		 * Thread thread = new Thread(() -> {
		 * 
		 * List<MyConnection> myConnections = myCircle.getMyConnections(); if
		 * (myConnections != null && myConnections.size() > 0) {
		 * this.setStatusOfMyConnectionSmes(myConnections, smes); } }); Thread thread1 =
		 * new Thread(() -> {
		 * 
		 * List<SendRequest> sentReqs = myCircle.getSendRequests(); if (sentReqs != null
		 * && sentReqs.size() > 0) { this.setStatusOfSentReqSmes(sentReqs, smes); } });
		 * Thread thread2 = new Thread(() -> {
		 * 
		 * List<ReceiveRequest> recievedReqs = myCircle.getReceiveRequests(); if
		 * (recievedReqs != null && recievedReqs.size() > 0) {
		 * this.setStatusOfRecievedReqSmes(recievedReqs, smes); } });
		 * 
		 * if (myCircle != null) { thread.start(); thread1.start(); thread2.start(); }
		 * 
		 * smes.parallelStream().forEach(sme -> { if (sme.getsUuid().equals(smeId)) {
		 * sme.setStatus(SMEStatus.OWNER); } if (sme.getStatus() == null) {
		 * sme.setStatus(SMEStatus.NEW); } });
		 */

	}

	@Override
	public void setStatusOfMyConnectedSmes(List<MyConnection> myConns, List<SMEDto> smes) {

		myConns.parallelStream().forEach(myConn -> {
			smes.parallelStream().forEach(sme -> {
				if (myConn.getMySmeConnectionId().equals(sme.getsUuid())) {
					sme.setStatus(SMEStatus.CONNECTED);
				}
			});
		});

	}

	@Override
	public void setStatusOfSentReqSmes(List<SendRequest> sentReqs, List<SMEDto> smes) {
		sentReqs.parallelStream().forEach(sentReq -> {
			smes.parallelStream().forEach(sme -> {
				if (sentReq.getToSmeId().equals(sme.getsUuid())) {
					sme.setStatus(SMEStatus.SENT_REQ);
				}
			});
		});
	}

	@Override
	public void setStatusOfRecievedReqSmes(List<ReceiveRequest> recieveReqs, List<SMEDto> smes) {
		recieveReqs.parallelStream().forEach(recieveReq -> {
			smes.parallelStream().forEach(sme -> {
				if (recieveReq.getFromSmeId().equals(sme.getsUuid())) {
					sme.setStatus(SMEStatus.RECIEVED_REQ);
				}
			});
		});
	}
}
