package com.smeface.constants;

public interface CircleModuleConstants {
	public interface CircleStatus {
		String PENDING = "Pending";
		String ACCEPTED = "Accepted";
		String REJECTED = "Rejected";
		String CANCELED = "Canceled";
		String CONNECTED = "Connected";
		String DISCONNECTED = "Disconnected";
	}

	public interface RoleAccess {
		String ADMIN = "hasAnyRole('ADMIN')";
		String ADMIN_AND_USER = "hasAnyRole('ADMIN','USER')";
	}

	public interface RequestRaram {
		String connectionParamKey = "s";
		String connectionParamValue = "business-post";
	}

	public interface SMEStatus {
		String SENT_REQ = "SENT_REQ";
		String RECIEVED_REQ = "RECIEVED_REQ";
		String CONNECTED = "CONNECTED";
		String NEW = "NEW";
		String OWNER = "OWNER";

	}

	public interface CirclePrivacy {
		String MY_CIRCLE = "Circle";
		String PRIVATE = "Private";
		String PUBLIC = "Public";
	}

}
