package com.smeface.constants;

public interface UrlMapping {
	String ROOT_API = "/smeface/circle"; // root level api
	
	String SMEs = "/{smeId}/smes"; // getPlatformListedSmes
	
	String SEND_REQ = "/send-request"; // send request
	
	String ACCEPT_REQUEST = "/add-connection"; // Accept Received Request
	
	String REJECT_REQUEST = "/reject-received-request"; // Reject Received Request
	
	String CANCEL_REQUEST = "/cancel-sent-request"; // Cancel Sent Request
	
	String REMOVE_CONNECTION = "/remove-connection"; // Remove Connection
	
	String GET_RECEIVED_REQUEST = "/{smeId}/received-requests"; // Get Received Request
	
	String GET_SENT_REQUEST = "/{smeId}/sent-requests"; // Get Sent Request
	
	String GET_CONNECTION = "/{smeId}/my-connections"; // Get Business Circle Connection
	
	String GET_SME_CONNECTION = "/{smeId}/my-connections/for/{loggedInSmeId}/sme"; // Get Business Circle Connection
																					// for sme
	String GET_BUSINESS_CIRCLE = "/{smeId}"; // get business circle
	
	String GET_RECEIVED_REQ_COUNT = "/{smeId}/received-requests/count"; // get received request count
	
	String GET_PEOPLE_YOU_MAY_KNOW = "/{smeId}/people-you-may-know";// get people you may know

	String CHANGE_PRIVACY = "/privacy";

	String CIRCLE = "/";
}
