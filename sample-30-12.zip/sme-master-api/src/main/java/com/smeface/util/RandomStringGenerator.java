package com.smeface.util;

import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;

public class RandomStringGenerator {
	
	public static Integer generateRandomNumber(int length) {
		return new Random().nextInt(length);
	}
	public static String generateRandomString(int length) {
		return RandomStringUtils.randomAlphabetic(length);
		
	}
}
