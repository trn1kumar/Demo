package com.smeface.constants;

public interface UrlMapping {
	String BASE_URL = "/smeface/smes";

	public interface SMEController {
		String SAVE_SME = "/sme";
		String SAVE_INFRASTRUCTURES = "/{sUuid}/sme/infrastructures";
		String SAVE_TEAMS = "/{sUuid}/sme/teams";
		String SAVE_CERTIFICATES = "/{sUuid}/sme/certificates";
		String SAVE_GALLERIES = "/{sUuid}/sme/galleries";
		String GET_TEAMS = "/{sUuid}/sme/teams";
		String GET_GALLERIES = "/{sUuid}/sme/galleries";
		String GET_INFRASTRUCTURES = "/{sUuid}/sme/infrastructures";
		String GET_CERTIFICATES = "/{sUuid}/sme/certificates";
		String GET_CERTIFICATE = "/{sUuid}/sme/certificates/{crtiUuid}";
		String GET_TEAM = "/{sUuid}/sme/teams/{teamUuid}";
		String GET_INFRASTRUCTURE = "/{sUuid}/sme/infrastructures/{infraUuid}";
		String GET_GALLERY = "/{sUuid}/sme/galleries/{galleryUuid}";
		String GET_SLIDER_IMAGES = "/{sUuid}/homepage/slider/images";
		String GET_SME = "/{sUuid}";
		String GET_SMEBY_UUID = "/user/{uuid}";
		String GET_SMES = "/fetch";
		String GET_SMEVO = "/{sUuid}/vo";
		String DELETE_CERTIFICATE = "/{sUuid}/sme/certificate/{crtiUuid}";
		String DELETE_GALLERY = "/{sUuid}/sme/gallery/{galleryUuid}";
		String DELETE_TEAM = "/{sUuid}/sme/team/{teamUuid}";
		String DELETE_INFRASTRUCTURE = "/{sUuid}/sme/infrastructure/{infraUuid}";
		String VALIDATE_GSTIN = "/{gstin}/validate";
		String GET_TOP_SMES = "/top";
		String SAVE_IMAGES = "/{sUuid}/images";
		String GET_SMES_WITH_PAGE = "/fetch/p";
	}
	public interface SMECategoryController{
		String CATEGORY = "/category";
		String CATEGORIES = "/categories";
	}

	public interface SMESearchController {
		String SERACH_SME = "/search/sme";
		String AUTO_SUGGEST_SEARCH = "/search/auto-suggest";
	}

	public interface FileController {
		String CHANGE_LOGO_IMAGE = "/{sUuid}/change/logo-image";
		String UPLOAD_HOME_SLIDER_IMAGE = "/{sUuid}/upload/slider-image";
	}
	
	public interface SMEDataPublishController{
		String UPDATE_INFO ="/{smeId}/{source}";
	}
}
