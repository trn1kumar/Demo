package com.smeface.constants;

public interface SMEMasterConstants {

	String CERTIFICATES = "certificates";
	String INFRASTRUCTURES = "infrastructures";
	String GALLERIES = "galleries";
	String TEAMS = "teams";

	public interface StatusConstant {
		String ACTIVE = "active";
		String DEACTIVE = "deactive";
		String BOTH = "both";
	}

	public interface SMEFormData {
		public String SME_DATA = "smeFormData";
		public String INFRASTRUCTURE_DATA = "infraFormData";
		public String MANAGEMENT_TEAM_DATA = "manageTeamFormData";
		public String CERTIFICATE_DATA = "certificatesFormData";
		public String GALLERY_DATA = "galleryFormData";
	}

	public interface SMEFileDirectory {
		public String SME = "sme/{sUuid}/logo";
		public String SME_HOME_SLIDER = "sme/{sUuid}/sliders";
		public String SME_INFRASTRUCTURE = "sme/{sUuid}/infrastructures";
		public String SME_MANAGEMENT_TEAM = "sme/{sUuid}/teams";
		public String SME_CERTIFICATE = "sme/{sUuid}/certificates";
		public String SME_GALLERY = "sme/{sUuid}/galleries";
	}

	interface RestEndpoint {
		public String headerKey = "Authorization";
	}
	
	public interface RoleAccess {
		String ADMIN = "hasAnyRole('ADMIN')";
		String USER = "hasAnyRole('USER')";
		String ADMIN_AND_USER = "hasAnyRole('USER', 'ADMIN')";
	}
}
