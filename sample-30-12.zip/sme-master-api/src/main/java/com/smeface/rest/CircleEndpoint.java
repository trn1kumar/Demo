package com.smeface.rest;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;

import com.smeface.constants.SMEMasterConstants.RestEndpoint;
import com.smeface.exception.CustomException;
import com.smeface.rest.UserEndpoint.User;

public class CircleEndpoint {

	private Client client;
	private String circleEndpoint;
	private String createCircle;
	Logger log = LogManager.getLogger(CircleEndpoint.class.getName());

	public CircleEndpoint(Client client, String circleEndpoint, String createCircle) {
		super();
		this.client = client;
		this.circleEndpoint = circleEndpoint;
		this.createCircle = createCircle;
	}

	public void createCircle(User user, String token) {
		Response response = null;
		try {
			log.info("Connecting to SME Circle Module with Api [method: POST and URI: " + circleEndpoint + createCircle + " ]");
			response = client.target(circleEndpoint).path(createCircle).request(MediaType.APPLICATION_JSON)
					.header(RestEndpoint.headerKey, "Bearer " + token)
					.post(Entity.entity(user, MediaType.APPLICATION_JSON));
			log.info(response);
			Integer responseCode = response.getStatus();
			if (responseCode != HttpStatus.CREATED.value())
				throw new CustomException("Error occured while creating Circle,Invalid Response:"
						+ response.getStatusInfo().getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (CustomException e) {
			throw e;
		} catch (Exception e) {
			throw new CustomException("Error Occurred for connect to Circle Module,Invalid Response:"
					+ response.getStatusInfo().getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
