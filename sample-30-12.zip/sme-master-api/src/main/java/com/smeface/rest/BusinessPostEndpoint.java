package com.smeface.rest;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.smeface.constants.SMEMasterConstants.RestEndpoint;
import com.smeface.exception.CustomException;
import com.smeface.model.PublishData;
import com.smeface.model.PublishFeed;

public class BusinessPostEndpoint {
	Logger log = LogManager.getLogger(BusinessPostEndpoint.class.getName());

	private Client client;
	private String businessPostEndpoint;
	private String createFeed;
	String updateStatus;

	public BusinessPostEndpoint(Client client, String businessPostEndpoint, String createFeed, String updateStatus) {
		super();
		this.client = client;
		this.businessPostEndpoint = businessPostEndpoint;
		this.createFeed = createFeed;
		this.updateStatus = updateStatus;
	}

	public void createFeed(PublishFeed feed) {
		try {

			HttpServletRequest curRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
					.getRequest();

			Response response = client.target(businessPostEndpoint).path(createFeed).request(MediaType.APPLICATION_JSON)
					.header(RestEndpoint.headerKey, curRequest.getHeader(RestEndpoint.headerKey))
					.post(Entity.entity(feed, MediaType.APPLICATION_JSON));

			log.info(response);

			Integer responseCode = response.getStatus();

			if (responseCode != HttpStatus.OK.value()) {
				throw new CustomException(
						"Exception occrurred at Business Post endpoint to create feed for service ,Invalid Response: "
								+ response.getStatusInfo().getReasonPhrase(),
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void updateFeedStatus(List<PublishData> publishData) {
		try {

			HttpServletRequest curRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
					.getRequest();

			Response response = client.target(businessPostEndpoint).path(updateStatus.replace("{feedId}", " "))
					.request(MediaType.APPLICATION_JSON)
					.header(RestEndpoint.headerKey, curRequest.getHeader(RestEndpoint.headerKey))
					.put(Entity.entity(publishData, MediaType.APPLICATION_JSON));

			log.info(response);
			Integer responseCode = response.getStatus();

			if (responseCode != HttpStatus.OK.value()) {
				throw new CustomException(
						"Exception occrurred at Business Post endpoint to active infrastructure feed,Invalid Response: "
								+ response.getStatusInfo().getReasonPhrase(),
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
