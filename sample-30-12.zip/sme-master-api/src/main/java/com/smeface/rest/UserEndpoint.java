package com.smeface.rest;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.smeface.constants.SMEMasterConstants.RestEndpoint;
import com.smeface.exception.CustomException;
import com.smeface.model.AuthToken;

public class UserEndpoint {

	@Autowired
	CreditCheckEndpoint creditCheckEndpoint;
	
	@Autowired
	CircleEndpoint circleEndpoint;

	private Client client;
	private String userEndpoint;
	private String changeType;

	Logger log = LogManager.getLogger(UserEndpoint.class.getName());

	public UserEndpoint(Client client, String userEndpoint, String changeType) {
		super();
		this.client = client;
		this.userEndpoint = userEndpoint;
		this.changeType = changeType;
	}

	public AuthToken changeUserTypeAndGetToken(String sUuid,String uuid) {

		AuthToken authToken = null;

		HttpServletRequest curRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
				.getRequest();

		User user = new User(uuid,sUuid);
		Response response = client.target(userEndpoint).path(changeType).request(MediaType.APPLICATION_JSON)
				.header(RestEndpoint.headerKey, curRequest.getHeader(RestEndpoint.headerKey))
				.put(Entity.entity(user, MediaType.APPLICATION_JSON));
		log.info(response);

		Integer responseCode = response.getStatus();

		if (responseCode == HttpStatus.OK.value()) {
			authToken = response.readEntity(new GenericType<AuthToken>() {
			});
			
			creditCheckEndpoint.selectPkg(user, authToken.getToken());
			circleEndpoint.createCircle(user, authToken.getToken());
			return authToken;

		} else if (responseCode == HttpStatus.NOT_FOUND.value()) {
			throw new CustomException("User Not Found with id " + uuid, HttpStatus.NOT_FOUND);

		} else {
			throw new CustomException("Internal Exception occrurred while getting token,Invalid Response: "
					+ response.getStatusInfo().getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	class User {

		private String uuid;
		
		private String sUuid;
		

		User(String uuid,String sUuid) {
			this.uuid = uuid;
			this.sUuid=sUuid;
		}

		public String getUuid() {
			return uuid;
		}

		public String getsUuid() {
			return sUuid;
		}

		public void setsUuid(String sUuid) {
			this.sUuid = sUuid;
		}

	}

}
