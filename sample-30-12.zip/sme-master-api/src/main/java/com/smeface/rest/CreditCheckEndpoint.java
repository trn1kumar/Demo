package com.smeface.rest;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;

import com.smeface.constants.SMEMasterConstants.RestEndpoint;
import com.smeface.exception.CustomException;
import com.smeface.rest.UserEndpoint.User;

public class CreditCheckEndpoint {
	private Client client;
	private String creditCheckEndpoint;
	private String selectPkgPath;

	Logger log = LogManager.getLogger(CreditCheckEndpoint.class.getName());

	public CreditCheckEndpoint(Client client, String creditCheckEndpoint, String selectPkgPath) {
		super();
		this.client = client;
		this.creditCheckEndpoint = creditCheckEndpoint;
		this.selectPkgPath = selectPkgPath;

	}

	public void selectPkg(User user, String token) {
		Response response = null;
		try {
			log.info("Connecting to Pricing Module with Api [method: POST and URI: " + creditCheckEndpoint + selectPkgPath + " ]");
			response = client.target(creditCheckEndpoint).path(selectPkgPath).request(MediaType.APPLICATION_JSON)
					.header(RestEndpoint.headerKey, "Bearer " + token)
					.post(Entity.entity(user, MediaType.APPLICATION_JSON));
			log.info(response);
			Integer responseCode = response.getStatus();

			if (responseCode != HttpStatus.CREATED.value())
				throw new CustomException("Error occured while selecting Pkg,Invalid Response:"
						+ response.getStatusInfo().getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			throw new CustomException("Error occured while Connect to pricing module,Invalid Response:"
					+ response.getStatusInfo().getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
