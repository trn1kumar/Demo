package com.smeface.dto;

import java.util.List;
import java.util.Map;

import com.smeface.model.filter.CategoryFilter;
import com.smeface.model.filter.CityFilter;

public class FilterDto {
	
	private Map<String,List<CityFilter>> filterByCities;
	
	private Map<String,List<CategoryFilter>> filterByCategories;
	

	public Map<String,List<CityFilter>> getFilterByCities() {
		return filterByCities;
	}

	public void setFilterByCities(Map<String,List<CityFilter>> filterByCities) {
		this.filterByCities = filterByCities;
	}

	public Map<String,List<CategoryFilter>> getFilterByCategories() {
		return filterByCategories;
	}

	public void setFilterByCategories(Map<String,List<CategoryFilter>> filterByCategories) {
		this.filterByCategories = filterByCategories;
	}

	
}
