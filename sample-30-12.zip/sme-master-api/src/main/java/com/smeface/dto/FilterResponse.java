package com.smeface.dto;

import java.util.List;

import com.smeface.vo.SMEInformationVo;

public class FilterResponse {
	
	private int totalCount;
	private FilterDto filter;
	private List<SMEInformationVo> result;
	

	public FilterResponse() {
		super();
	}

	public FilterResponse(FilterDto filter, List<SMEInformationVo> result,int totalCount) {
		super();
		this.filter = filter;
		this.result = result;
		this.totalCount=totalCount;
	}

	public FilterDto getFilter() {
		return filter;
	}

	public void setFilter(FilterDto filter) {
		this.filter = filter;
	}

	public List<SMEInformationVo> getResult() {
		return result;
	}

	public void setResult(List<SMEInformationVo> result) {
		this.result = result;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

}
