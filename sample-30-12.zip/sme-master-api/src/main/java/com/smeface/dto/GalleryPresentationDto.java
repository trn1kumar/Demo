package com.smeface.dto;

import com.smeface.common.audit.DateAuditable;

public class GalleryPresentationDto extends DateAuditable{

		private String url;
	    private String altText;
	    private String title;
	    private String thumbnailUrl; 
	    private String description;
	    
		public GalleryPresentationDto() {
			super();
		}
		public GalleryPresentationDto(String url, String altText, String title, String thumbnailUrl,
				String description) {
			super();
			this.url = url;
			this.altText = altText;
			this.title = title;
			this.thumbnailUrl = thumbnailUrl;
			this.description = description;
		}
		public String getUrl() {
			return url;
		}
		public String getAltText() {
			return altText;
		}
		public String getTitle() {
			return title;
		}
		public String getThumbnailUrl() {
			return thumbnailUrl;
		}
		public String getDescription() {
			return description;
		}
		public void setUrl(String url) {
			this.url = url;
		}
		public void setAltText(String altText) {
			this.altText = altText;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public void setThumbnailUrl(String thumbnailUrl) {
			this.thumbnailUrl = thumbnailUrl;
		}
		public void setDescription(String description) {
			this.description = description;
		}
	  
}
