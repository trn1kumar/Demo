package com.smeface.dto;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.smeface.common.audit.DateAuditable;
import com.smeface.entities.Image;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class InfrastructureDto extends DateAuditable{
	
	private String infraUuid;
	private String machineName;
	private String manufacturer;
	private String modelName;
	private boolean active;
	private boolean businessPost;
	private List<Image> images;
	private String description;
	private String quantity;
	private String capacity;

	public String getMachineName() {
		return machineName;
	}

	public void setMachineName(String machineName) {
		this.machineName = machineName;
	}

	public String getManufacturer() {
		return manufacturer;
	}


	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getCapacity() {
		return capacity;
	}

	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}

	public List<Image> getImages() {
		return images;
	}

	public void setImages(List<Image> images) {
		this.images = images;
	}

	public String getInfraUuid() {
		return infraUuid;
	}

	public void setInfraUuid(String infraUuid) {
		this.infraUuid = infraUuid;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean isBusinessPost() {
		return businessPost;
	}

	public void setBusinessPost(boolean businessPost) {
		this.businessPost = businessPost;
	}

}