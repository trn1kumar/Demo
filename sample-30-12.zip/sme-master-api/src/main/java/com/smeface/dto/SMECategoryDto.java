package com.smeface.dto;

import java.util.List;

import com.smeface.vo.SMEInformationVo;

public class SMECategoryDto {

	private String categoryUuid;
	private String categoryUrl;
	private String categoryName;
	private String imageLocation;
	private List<SMEInformationDto> smes;

	
	public String getCategoryUuid() {
		return categoryUuid;
	}
	public void setCategoryUuid(String categoryUuid) {
		this.categoryUuid = categoryUuid;
	}
	public String getCategoryUrl() {
		return categoryUrl;
	}
	public void setCategoryUrl(String categoryUrl) {
		this.categoryUrl = categoryUrl;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	
	
	public String getImageLocation() {
		return imageLocation;
	}
	public void setImageLocation(String imageLocation) {
		this.imageLocation = imageLocation;
	}
	public List<SMEInformationDto> getSmes() {
		return smes;
	}
	public void setSmes(List<SMEInformationDto> smes) {
		this.smes = smes;
	}
	
}
