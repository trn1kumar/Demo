package com.smeface.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.smeface.common.audit.DateAuditable;
import com.smeface.entities.Image;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class GalleryDto extends DateAuditable{

	private String galleryUuid;
	private String description;
	private String galleryTitle;
	private boolean active;
	private List<Image> images;

	public String getGalleryUuid() {
		return galleryUuid;
	}

	public void setGalleryUuid(String galleryUuid) {
		this.galleryUuid = galleryUuid;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<Image> getImages() {
		return images;
	}

	public void setImages(List<Image> images) {
		this.images = images;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getGalleryTitle() {
		return galleryTitle;
	}

	public void setGalleryTitle(String galleryTitle) {
		this.galleryTitle = galleryTitle;
	}
}
