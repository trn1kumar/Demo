package com.smeface.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.smeface.common.audit.DateAuditable;
import com.smeface.entities.Image;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CertificateDto extends DateAuditable{

	
	private String crtiUuid;
	private String certificateType;
	private String certificateDesc;
	private boolean active=false;
	private List<Image> images;

	public String getCertificateType() {
		return certificateType;
	}

	public void setCertificateType(String certificateType) {
		this.certificateType = certificateType;
	}

	public String getCertificateDesc() {
		return certificateDesc;
	}

	public void setCertificateDesc(String certificateDesc) {
		this.certificateDesc = certificateDesc;
	}


	public String getCrtiUuid() {
		return crtiUuid;
	}

	public void setCrtiUuid(String crtiUuid) {
		this.crtiUuid = crtiUuid;
	}

	public List<Image> getImages() {
		return images;
	}

	public void setImages(List<Image> images) {
		this.images = images;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}


}
