package com.smeface.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.smeface.common.audit.DateAuditable;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class SMEInformationDto extends DateAuditable {

	@JsonIgnore
	private Long smeId;

	private String smeName;

	private String sUuid;
	
	private String uuid;
	
	private String companyLogo;

	private String smeType;

	private String oneLineStatement;

	private String companyDescription;

	private String contactPerson;

	private String contactEmail;

	private String contactPhone;

	private String registeredAS;

	private String yearOfEstablishment;

	private Integer numberOfEmployees;

	private Double turnOver;

	private String gstin;

	private AddressDto smeAddress;
	
	private String logoImage;
	
	private String latitude;
	
	private String longitude;
	
	private String googlemapLink;
	
	private boolean active;

	public Long getSmeId() {
		return smeId;
	}

	public void setSmeId(Long smeId) {
		this.smeId = smeId;
	}

	public String getSmeName() {
		return smeName;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public String getOneLineStatement() {
		return oneLineStatement;
	}

	public void setOneLineStatement(String oneLineStatement) {
		this.oneLineStatement = oneLineStatement;
	}

	public String getCompanyDescription() {
		return companyDescription;
	}

	public void setCompanyDescription(String companyDescription) {
		this.companyDescription = companyDescription;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

	public String getRegisteredAS() {
		return registeredAS;
	}

	public void setRegisteredAS(String registeredAS) {
		this.registeredAS = registeredAS;
	}

	public String getYearOfEstablishment() {
		return yearOfEstablishment;
	}

	public void setYearOfEstablishment(String yearOfEstablishment) {
		this.yearOfEstablishment = yearOfEstablishment;
	}

	public Integer getNumberOfEmployees() {
		return numberOfEmployees;
	}

	public void setNumberOfEmployees(Integer numberOfEmployees) {
		this.numberOfEmployees = numberOfEmployees;
	}

	public Double getTurnOver() {
		return turnOver;
	}

	public void setTurnOver(Double turnOver) {
		this.turnOver = turnOver;
	}

	public String getCompanyLogo() {
		return companyLogo;
	}

	public void setCompanyLogo(String companyLogo) {
		this.companyLogo = companyLogo;
	}

	public String getSmeType() {
		return smeType;
	}

	public void setSmeType(String smeType) {
		this.smeType = smeType;
	}



	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getLogoImage() {
		return logoImage;
	}

	public void setLogoImage(String logoImage) {
		this.logoImage = logoImage;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getGooglemapLink() {
		return googlemapLink;
	}

	public void setGooglemapLink(String googlemapLink) {
		this.googlemapLink = googlemapLink;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public AddressDto getSmeAddress() {
		return smeAddress;
	}

	public void setSmeAddress(AddressDto smeAddress) {
		this.smeAddress = smeAddress;
	}

}
