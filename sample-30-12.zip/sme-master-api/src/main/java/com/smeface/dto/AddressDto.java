package com.smeface.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.smeface.entities.SMEInformation;

@JsonInclude(Include.NON_DEFAULT)
public class AddressDto {

	private String addrsUuid;
	private String street;
	private String locality;
	private String city;
	private String state;
	private String country;
	private int pincode;
	
	public String getAddrsUuid() {
		return addrsUuid;
	}
	public String getStreet() {
		return street;
	}
	public String getLocality() {
		return locality;
	}
	public String getCity() {
		return city;
	}
	public String getState() {
		return state;
	}
	public String getCountry() {
		return country;
	}
	public int getPincode() {
		return pincode;
	}
	public void setAddrsUuid(String addrsUuid) {
		this.addrsUuid = addrsUuid;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public void setLocality(String locality) {
		this.locality = locality;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public void setState(String state) {
		this.state = state;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	
}
