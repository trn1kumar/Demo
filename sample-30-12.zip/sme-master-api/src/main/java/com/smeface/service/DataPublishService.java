package com.smeface.service;

import java.util.Set;
import com.smeface.model.PublishData;

public interface DataPublishService {

	void updateCerificate(PublishData data);

	void updateManagementTeam(PublishData data);

	void updateInfrastructure(Set<PublishData> publishData);

	void updateGallery(PublishData data);

}
