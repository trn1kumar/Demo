package com.smeface.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.smeface.component.filter.FilterComponent;
import com.smeface.component.filter.GenericFilterComponent;
import com.smeface.dto.FilterDto;
import com.smeface.entities.SMECategory;
import com.smeface.entities.SMEInformation;
import com.smeface.mapper.SMEMapper;
import com.smeface.model.filter.CategoryFilter;
import com.smeface.model.filter.CityFilter;
import com.smeface.repository.AddressRepo;
import com.smeface.repository.SMECategoryRepository;

@Service
public class SMEFilterServiceImpl implements SMEFilterService {

	@Autowired
	AddressRepo addressRepo;

	@Autowired
	SMECategoryRepository smeCategoryRepo;

	@Autowired
	SMECategoryService smeCategoryService;

	@Autowired
	private SMEMapper mapper;

	@Autowired
	@Qualifier("cityFilter")
	FilterComponent cityFilterComponent;

	@Autowired
	@Qualifier("categoryFilter")
	FilterComponent categoryFilterComponent;

	@Autowired
	GenericFilterComponent genericFilterComponent;

	@Override
	// @Cacheable("smes")
	public FilterDto getFilter(Set<String> categoriesFilterParam, Set<String> citiesFilterParam) {

		FilterDto filter = new FilterDto();

		Map<String, List<CityFilter>> cityFilterMap = new HashMap<>();
		Map<String, List<CategoryFilter>> categoryFilterMap = new HashMap<>();

		Set<String> cities = addressRepo.getCities();
		List<CityFilter> citiesFilter = new ArrayList<>();
		cities.forEach(city -> {
			long count = addressRepo.countByCity(city);
			CityFilter cityFilter = new CityFilter(city, count);
			if (citiesFilterParam != null && citiesFilterParam.contains(city))
				cityFilter.setSelected(true);
			else
				cityFilter.setSelected(false);
			citiesFilter.add(cityFilter);
		});

		List<CategoryFilter> categoriesFilter = new ArrayList<>();
		List<SMECategory> categories = smeCategoryService.getAllCategories();
		categories.forEach(category -> {
			int count = smeCategoryRepo.getSMEsCountByCategoryUuid(category.getCategoryUuid());
			CategoryFilter categoryFilter = mapper.convertToDto(category, CategoryFilter.class);
			categoryFilter.setTotalSmesCount(count);
			if (categoriesFilterParam != null && categoriesFilterParam.contains(category.getCategoryUrl()))
				categoryFilter.setSelected(true);
			else
				categoryFilter.setSelected(false);
			categoriesFilter.add(categoryFilter);
		});

		cityFilterMap.put("City", citiesFilter);
		categoryFilterMap.put("Category", categoriesFilter);
		filter.setFilterByCities(cityFilterMap);
		filter.setFilterByCategories(categoryFilterMap);

		return filter;
	}

	@Override
	public List<SMEInformation> applyFilter(Set<String> categoriesFilterParam, Set<String> citiesFilterParam,
			int firstResult, int maxResult) {

		if (firstResult == 0 || firstResult < 0)
			firstResult = 1;
		--firstResult;

		Set<SMEInformation> smes = new HashSet<>();
		if (categoriesFilterParam != null && citiesFilterParam != null) {
			smes.addAll(
					genericFilterComponent.filter(categoriesFilterParam, citiesFilterParam, firstResult, maxResult));
		}
		if (categoriesFilterParam != null && citiesFilterParam == null) {
			smes.addAll(categoryFilterComponent.filter(categoriesFilterParam, firstResult, maxResult));
		}
		if (categoriesFilterParam == null && citiesFilterParam != null) {
			smes.addAll(cityFilterComponent.filter(citiesFilterParam, firstResult, maxResult));
		}

		return new ArrayList<>(smes);

	}
}
