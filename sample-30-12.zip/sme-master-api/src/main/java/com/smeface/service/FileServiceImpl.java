package com.smeface.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.smeface.entities.Image;
import com.smeface.exception.CustomException;
import com.smeface.model.UploadFileResponse;
import com.smeface.rest.ContentServerEndpoint;
import com.smeface.util.RandomStringGenerator;
import com.smeface.util.UuidUtil;

@Service
public class FileServiceImpl implements FileService {

	@Autowired
	ContentServerEndpoint contentServerEndpoint;

	@Override
	public List<Image> sendFilesToContentServer(List<MultipartFile> files, String fileLocation)
			throws IllegalArgumentException, IOException {

		List<Image> images = null;

		List<String> names = new ArrayList<>();
		files.forEach(file -> {
			try {
				String imageName = RandomStringGenerator.generateRandomNumber(1000) + file.getOriginalFilename();
				names.add(imageName);

			} catch (CustomException e) {
				e.printStackTrace();
			}
		});

		List<UploadFileResponse> fileDetails = contentServerEndpoint.sendFilesToContentServer(files, names,
				fileLocation);

		images = new ArrayList<>();
		for (UploadFileResponse fileDetail : fileDetails) {
			images.add(new Image(UuidUtil.getUuid(), fileDetail.getFileName(), fileDetail.getFileLocation(), true));
		}

		return images;

	}

	@Override
	public void deleteFileFromContentServer(String fileLocation) throws IOException {
		contentServerEndpoint.deleteFileFromContentServer(fileLocation);
	}
}
