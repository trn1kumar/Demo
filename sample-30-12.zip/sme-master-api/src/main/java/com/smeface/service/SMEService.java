package com.smeface.service;

import java.util.List;
import java.util.Optional;

import com.smeface.dto.SMEInformationDto;
import com.smeface.entities.Address;
import com.smeface.entities.Certificate;
import com.smeface.entities.Gallery;
import com.smeface.entities.Image;
import com.smeface.entities.Infrastructure;
import com.smeface.entities.ManagementTeam;
import com.smeface.entities.SMECategory;
import com.smeface.entities.SMEInformation;
import com.smeface.exception.CustomException;

public interface SMEService {

	// save
	public SMEInformation saveSme(SMECategory smeCategory) throws CustomException;
	
	public SMEInformation updateSme(SMEInformation sme) throws CustomException;

	public SMEInformation save(SMEInformation sme);

	public void saveGallery(List<Gallery> galleryList, String sUuid);

	public void saveInfrastructures(List<Infrastructure> infrastructure, String sUuid) throws CustomException;

	public void saveManagementTeams(List<ManagementTeam> managementTeam, String sUuid) throws CustomException;

	public void saveCertificates(List<Certificate> certificates, String sUuid) throws CustomException;

	public void updateSmeLogo(String sUuid, String imageLocation);

	public Address updateSmeAddress(String sUuid,Address address);

	// get data of particular sme
	public List<ManagementTeam> getAllManagementTeam(String sUuid);

	public List<Infrastructure> getAllInfrastructure(String sUuid);

	public List<Certificate> getAllCertificate(String sUuid);

	public List<Gallery> getAllGallery(String sUuid);

	// get single data
	public ManagementTeam getManagementTeam(String teamUuid);

	public Infrastructure getInfrastructure(String infraUuid);

	public Certificate getCertificate(String crtiUuid);

	public Gallery getGallery(String galleryUuid);

	// get sme
	public SMEInformation getSMEByUserId(String userId) throws CustomException;

	public Optional<SMEInformation> getSME(String sUuid) throws CustomException;

	public List<SMEInformation> getAllSME(int page,int size) throws CustomException;

	public SMEInformationDto getSmeVo(String sUuid);

	// get slider image
	public List<Image> getSliderImages(String sUuid);

	public void deleteCertificate(String crtiUuid);

	public void deleteGallery(String galleryUuid);

	public void deleteInfra(String infraUuid);

	public void deleteTeam(String teamUuid);

	public boolean isGSTINNumberExist(String gstin);

}
