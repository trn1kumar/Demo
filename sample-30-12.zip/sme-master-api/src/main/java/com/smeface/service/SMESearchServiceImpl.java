package com.smeface.service;

import java.util.List;
import javax.persistence.EntityManager;

import org.apache.lucene.search.Query;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.DatabaseRetrievalMethod;
import org.hibernate.search.query.ObjectLookupMethod;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smeface.entities.SMEInformation;

@Service
public class SMESearchServiceImpl implements SMESearchService {

	@Autowired
	private EntityManager entityManager;

	@Override
	public List<SMEInformation> getSearchResult(String searchText,int maxResult) {
		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(SMEInformation.class).get();

		Query lucenceQuery = queryBuilder.keyword().onFields("smeName").matching(searchText).createQuery();

		FullTextQuery fullTextQuery = fullTextEntityManager.createFullTextQuery(lucenceQuery, SMEInformation.class);
		fullTextQuery.setFirstResult(0);
		fullTextQuery.setMaxResults(maxResult);
		fullTextQuery.initializeObjectsWith(ObjectLookupMethod.SECOND_LEVEL_CACHE, DatabaseRetrievalMethod.QUERY);
		@SuppressWarnings("unchecked")
		List<SMEInformation> smes = fullTextQuery.getResultList();

		return smes;
	}

}
