package com.smeface.service;

import java.util.List;
import java.util.Set;

import com.smeface.dto.FilterDto;
import com.smeface.entities.SMEInformation;

public interface SMEFilterService {

	FilterDto getFilter(Set<String> categoriesFilterParam,Set<String> citiesFilterParam);
	
	List<SMEInformation> applyFilter(Set<String> categoriesFilterParam,Set<String> citiesFilterParam,int firstResult,int maxResult);

}
