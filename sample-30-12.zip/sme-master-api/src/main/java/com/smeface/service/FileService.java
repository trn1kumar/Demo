package com.smeface.service;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.smeface.entities.Image;

public interface FileService {

	// send file to content server
	public List<Image> sendFilesToContentServer(List<MultipartFile> files, String filePrefix)
			throws IllegalArgumentException, IOException;

	public void deleteFileFromContentServer(String fileLocation) throws IOException;

}
