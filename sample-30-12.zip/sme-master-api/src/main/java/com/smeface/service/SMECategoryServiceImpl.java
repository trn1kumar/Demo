package com.smeface.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.smeface.entities.SMECategory;
import com.smeface.exception.CustomException;
import com.smeface.repository.SMECategoryRepository;

@Service
public class SMECategoryServiceImpl implements SMECategoryService {

	@Autowired
	SMECategoryRepository smeCategoryRepository;

	@Override
	public void saveCategory(SMECategory category) {
		try {
			smeCategoryRepository.save(category);
		} catch (Exception e) {
			throw new CustomException("Error while saving Category " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public SMECategory getCategory(String categoryUuid) {
		SMECategory category = null;

		category = smeCategoryRepository.findByCategoryUuid(categoryUuid);
		if (category == null)
			throw new CustomException("category not found by " + categoryUuid, HttpStatus.NOT_FOUND);
		return category;
	}

	@Override
	public SMECategory getCategoryByUrl(String categoryUrl) {
		SMECategory category = null;

		category = smeCategoryRepository.findByCategoryUrl(categoryUrl);
		if (category == null)
			throw new CustomException("category not found by " + categoryUrl, HttpStatus.NOT_FOUND);
		return category;
	}

	@Override
	public List<SMECategory> getAllCategories() {
		List<SMECategory> categories = smeCategoryRepository.findAll();

		categories = categories.stream().filter(category -> category.getSmes() != null && category.getSmes().size() > 0)
				.collect(Collectors.toList());

		if (categories != null && categories.size() > 0)
			return categories;
		else
			throw new CustomException("No Categories Available", HttpStatus.NOT_FOUND);
	}

}
