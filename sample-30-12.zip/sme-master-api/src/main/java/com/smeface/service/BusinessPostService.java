package com.smeface.service;

import com.smeface.entities.Infrastructure;

public interface BusinessPostService {
	
	public void createBusinessPost(String sUuid,Infrastructure infra);
	
}
