package com.smeface.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.smeface.exception.CustomException;
import com.smeface.model.PublishData;
import com.smeface.repository.CertificateRepository;
import com.smeface.repository.GalleryRepository;
import com.smeface.repository.InfrastructureRepository;
import com.smeface.repository.ManagementTeamRepository;
import com.smeface.rest.BusinessPostEndpoint;

@Service
public class DataPublishServiceImpl implements DataPublishService {

	@Autowired
	CertificateRepository certificateRepository;

	@Autowired
	ManagementTeamRepository teamRepo;

	@Autowired
	SMEService smeService;

	@Autowired
	InfrastructureRepository infraRepo;

	@Autowired
	GalleryRepository galleryRepo;

	@Autowired
	BusinessPostEndpoint businessPostEndpoint;

	@Override
	public void updateCerificate(PublishData data) {
		if (certificateRepository.existsByCrtiUuid(data.getId()))
			certificateRepository.updateStatus(data.getId(), data.isStatus());
		else
			throw new CustomException("Unable to update, certificate not found with id: " + data.getId(),
					HttpStatus.NOT_FOUND);

	}

	@Override
	public void updateManagementTeam(PublishData data) {
		if (teamRepo.existsByTeamUuid(data.getId()))
			teamRepo.updateStatus(data.getId(), data.isStatus());
		else
			throw new CustomException("Unable to update, ManagementTeam not found with id: " + data.getId(),
					HttpStatus.NOT_FOUND);

	}

	@Override
	public void updateInfrastructure(Set<PublishData> publishData) {
		List<PublishData> publish = new ArrayList<>();

		try {
			for (PublishData data : publishData) {
				try {
					if (infraRepo.existsByInfraUuid(data.getId())) {
						infraRepo.updateStatus(data.getId(), data.isStatus());
						if (data.isBusinessPost() && data.isStatus()) {
							publish.add(data);
						}
					}
				} catch (CustomException e) {
					throw e;
				}
			}
			if (!publish.isEmpty())
				businessPostEndpoint.updateFeedStatus(publish);
		} catch (CustomException e) {
			throw e;
		} finally {
			publish = null;
		}

	}

	@Override
	public void updateGallery(PublishData data) {
		if (galleryRepo.existsByGalleryUuid(data.getId()))
			galleryRepo.updateStatus(data.getId(), data.isStatus());
		else
			throw new CustomException("Unable to update, Gallery not found with id: " + data.getId(),
					HttpStatus.NOT_FOUND);

	}

}
