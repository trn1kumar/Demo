package com.smeface.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smeface.exception.CustomException;
import com.smeface.model.AuthToken;
import com.smeface.rest.UserEndpoint;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserEndpoint userEndpoint;

	@Override
	public AuthToken updateUserTypeAndGetNewToken(String sUuid,String uuid) {

		AuthToken token = null;
		try {
			token = userEndpoint.changeUserTypeAndGetToken(sUuid,uuid);
		} catch (CustomException e) {
			throw e;
		}
		return token;
	}

}
