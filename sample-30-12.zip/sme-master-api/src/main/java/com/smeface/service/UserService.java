package com.smeface.service;

import com.smeface.model.AuthToken;

public interface UserService {

	public AuthToken updateUserTypeAndGetNewToken(String sUuid,String uuid);
}
