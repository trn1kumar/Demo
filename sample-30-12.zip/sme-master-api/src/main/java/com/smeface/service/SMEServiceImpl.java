package com.smeface.service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.smeface.dto.SMEInformationDto;
import com.smeface.entities.Address;
import com.smeface.entities.Certificate;
import com.smeface.entities.Gallery;
import com.smeface.entities.Image;
import com.smeface.entities.Infrastructure;
import com.smeface.entities.ManagementTeam;
import com.smeface.entities.SMECategory;
import com.smeface.entities.SMEInformation;
import com.smeface.exception.CustomException;
import com.smeface.mapper.SMEMapper;
import com.smeface.repository.AddressRepo;
import com.smeface.repository.CertificateRepository;
import com.smeface.repository.GalleryRepository;
import com.smeface.repository.InfrastructureRepository;
import com.smeface.repository.ManagementTeamRepository;
import com.smeface.repository.SMEInformationRepository;
import com.smeface.rest.ContentServerEndpoint;
import com.smeface.util.UuidUtil;

@Service(value = "smeService")
public class SMEServiceImpl implements SMEService {

	@Autowired
	private SMEInformationRepository smeRepository;

	@Autowired
	private InfrastructureRepository infraRepository;

	@Autowired
	private CertificateRepository certificateRepository;

	@Autowired
	private ManagementTeamRepository managementTeamRepository;

	@Autowired
	private GalleryRepository galleryRepository;

	@Autowired
	ContentServerEndpoint contentServerEndpoint;

	@Autowired
	SMECategoryService smeCategoryService;

	@Autowired
	AddressRepo addressRepo;

	@Autowired
	SMEMapper mapper;

	@Override
	public SMEInformation saveSme(SMECategory smeCategory) throws CustomException {

		SMEInformation sme = null;
		try {

			/*
			 * @ SaveOrUpdate sme
			 */
			sme = smeCategory.getSmes().get(0);
			if (smeRepository.existsByUuid(sme.getUuid()))
				throw new CustomException("SME Found Related to User " + sme.getUuid(), HttpStatus.BAD_REQUEST);

			// @set universal uuid and save
			sme.setsUuid(UuidUtil.getUuid(sme.getSmeName()));
			if (sme.getSmeAddress() != null)
				sme.getSmeAddress().setAddrsUuid(UuidUtil.getUuid());
			SMECategory existCategory = smeCategoryService.getCategory(smeCategory.getCategoryUuid());
			sme.setSmeCategory(existCategory);
			this.save(sme);

		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			throw new CustomException(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		return sme;
	}

	@Override
	public SMEInformation updateSme(SMEInformation sme) throws CustomException {

		try {

			if (sme.getsUuid() != null && smeRepository.existsBySUuid(sme.getsUuid())) {
				SMEInformation existSme = this.getSME(sme.getsUuid()).get();
				sme.setSmeId(existSme.getSmeId());
				sme.setHomeSliderImages(existSme.getHomeSliderImages());
				sme.setSmeAddress(existSme.getSmeAddress());

				sme = this.save(sme);
			} else
				throw new CustomException("SME Not found by " + sme.getsUuid() + " SME Updation failed.",
						HttpStatus.NOT_FOUND);

		} catch (Exception e) {
			throw new CustomException(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		return sme;
	}

	@Transactional
	public SMEInformation save(SMEInformation sme) {
		try {

			sme = smeRepository.saveAndFlush(sme);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return sme;
	}

	@Override
	public void updateSmeLogo(String sUuid, String imageLocation) {
		smeRepository.updateSmeLogo(sUuid, imageLocation);
	}

	@Override
	public void saveInfrastructures(List<Infrastructure> infrastructures, String sUuid) throws CustomException {

		SMEInformation existSme = null;
		Infrastructure infrastructure = infrastructures.get(0);

		/*
		 * @ if infrastructure id != null update infrastructure
		 */

		if (infrastructure.getInfraUuid() != null) {
			Infrastructure existInfrastructure = this.getInfrastructure(infrastructure.getInfraUuid());
			infrastructure.setId(existInfrastructure.getId());
			infrastructure.setActive(false);
			infrastructure.setBusinessPost(existInfrastructure.isBusinessPost());
			if (infrastructure.getImages() != null) {
				infrastructure.getImages().addAll(existInfrastructure.getImages());
			} else {
				infrastructure.setImages(existInfrastructure.getImages());
			}
			infraRepository.save(infrastructure);
		} else {
			/*
			 * @ else save new infrastructure
			 */

			infrastructures.forEach(infra -> {
				infra.setInfraUuid(UuidUtil.getUuid(infra.getMachineName()));
				infra.getImages().forEach(img -> {
					img.setActive(true);
					img.setImgUuid(UuidUtil.getUuid());
				});
			});

			existSme = this.getSME(sUuid).get();
			existSme.getInfrastructure().addAll(infrastructures);
			this.save(existSme);

		}

	}

	@Override
	@Transactional
	public void saveManagementTeams(List<ManagementTeam> teams, String sUuid) throws CustomException {

		/*
		 * @ if infrastructure id != null update ManagementTeam
		 */

		ManagementTeam team = teams.get(0);
		if (team.getTeamUuid() != null) {
			ManagementTeam existTeam = this.getManagementTeam(team.getTeamUuid());

			team.setTeamId(existTeam.getTeamId());
			team.setActive(false);
			managementTeamRepository.save(team);

		} else {

			/*
			 * @ else save new ManagementTeam
			 */

			teams.forEach(manageTeam -> {
				manageTeam.setTeamUuid(UuidUtil.getUuid(manageTeam.getFullName()));
			});

			SMEInformation existSme = this.getSME(sUuid).get();
			existSme.getManagementTeams().addAll(teams);

			this.save(existSme);

		}

	}

	@Override

	public void saveCertificates(List<Certificate> certificates, String sUuid) throws CustomException {

		/*
		 * @ if Certificate id != null update Certificate
		 */

		Certificate certificate = certificates.get(0);

		if (certificate.getCrtiUuid() != null) {

			Certificate existCertificate = this.getCertificate(certificate.getCrtiUuid());

			certificate.setId(existCertificate.getId());
			certificate.setActive(false);
			if (certificate.getImages() != null) {
				certificate.getImages().addAll(existCertificate.getImages());
			} else {
				certificate.setImages(existCertificate.getImages());
			}
			certificateRepository.save(certificate);

		} else {

			/*
			 * @ else save new ManagementTeam
			 */

			certificates.forEach(certi -> {
				certi.setCrtiUuid(UuidUtil.getUuid());
				certi.getImages().forEach(img -> {
					img.setActive(true);
					img.setImgUuid(UuidUtil.getUuid());
				});
			});

			SMEInformation existSme = this.getSME(sUuid).get();
			existSme.getCertificates().addAll(certificates);
			this.save(existSme);

		}

	}

	@Override
	@Transactional
	public void saveGallery(List<Gallery> galleryList, String sUuid) {
		SMEInformation existSme = null;
		Gallery gallery = galleryList.get(0);

		/*
		 * @ if infrastructure id != null update infrastructure
		 */

		if (gallery.getGalleryUuid() != null) {

			Gallery existGallery = this.getGallery(gallery.getGalleryUuid());

			gallery.setGalleryId(existGallery.getGalleryId());
			gallery.setActive(false);
			if (gallery.getImages() != null) {
				gallery.getImages().addAll(existGallery.getImages());
			} else {
				gallery.setImages(existGallery.getImages());
			}
			galleryRepository.save(gallery);

		} else {

			/*
			 * @ else save new infrastructure
			 */

			galleryList.forEach(glry -> {
				glry.setGalleryUuid(UuidUtil.getUuid());
				glry.getImages().forEach(img -> {
					img.setActive(true);
					img.setImgUuid(UuidUtil.getUuid());
				});
			});

			existSme = this.getSME(sUuid).get();
			existSme.getGallery().addAll(galleryList);

			this.save(existSme);

		}

	}

	@Override
	public Address updateSmeAddress(String sUuid, Address address) {
		try {
			address.setAddrsUuid(UuidUtil.getUuid());
			SMEInformation sme = this.getSME(sUuid).get();
			sme.setSmeAddress(address);
			this.save(sme);
			// addressRepo.save(address);
		} catch (Exception e) {
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return address;
	}

	@Override
	public Optional<SMEInformation> getSME(String sUuid) throws CustomException {

		Optional<SMEInformation> info = smeRepository.findBySUuid(sUuid);
		if (!info.isPresent()) {
			throw new CustomException("Sme Not present!!", HttpStatus.NOT_FOUND);
		}

		return info;

	}

	@Override
	public SMEInformation getSMEByUserId(String uuid) throws CustomException {
		SMEInformation info = smeRepository.findByUuid(uuid);
		if (info == null)
			throw new CustomException("SME Not listed by this user", HttpStatus.NOT_FOUND);
		else
			return info;

	}

	public Address getSmeAddress(String sUuid) {
		SMEInformation info = this.getSME(sUuid).get();
		if (info.getSmeAddress() != null)
			return info.getSmeAddress();
		else
			throw new CustomException("SME " + sUuid + " Don't have any address", HttpStatus.NO_CONTENT);
	}

	@Override
	public SMEInformationDto getSmeVo(String sUuid) {
		SMEInformationDto smeDto = null;
		if (smeRepository.existsBySUuid(sUuid)) {
			String[] str = smeRepository.smeInfo(sUuid).split(",");
			smeDto = new SMEInformationDto();
			smeDto.setsUuid(sUuid);

			smeDto.setSmeName(str[0]);
			if (!str[1].equals("null") && !StringUtils.isEmpty(str[1]))
				smeDto.setContactPerson(str[1]);
			if (!str[2].equals("null") && !StringUtils.isEmpty(str[2]))
				smeDto.setLogoImage(str[2]);
			try {
				Address smeAddress = this.getSmeAddress(sUuid);
				smeDto.setSmeAddress(mapper.convertToAddressVo(smeAddress));
			} catch (CustomException e) {

			}
		} else
			throw new CustomException("Sme Not present!!", HttpStatus.NOT_FOUND);

		return smeDto;
	}

	@Override
	public List<ManagementTeam> getAllManagementTeam(String sUuid) {

		List<ManagementTeam> teams = this.getSME(sUuid).get().getManagementTeams();

		if (teams != null && teams.size() > 0) {
			return teams;
		} else
			throw new CustomException("Company Management Teams Not Available.", HttpStatus.NOT_FOUND);

	}

	@Override
	public List<Infrastructure> getAllInfrastructure(String sUuid) {

		List<Infrastructure> infra = this.getSME(sUuid).get().getInfrastructure();
		if (infra != null && infra.size() > 0) {
			return infra;
		} else
			throw new CustomException("Company Infrastructures Not Available.", HttpStatus.NOT_FOUND);

	}

	@Override
	public List<Gallery> getAllGallery(String sUuid) {

		List<Gallery> galleryList = this.getSME(sUuid).get().getGallery();
		if (galleryList != null && galleryList.size() > 0) {
			return galleryList;
		} else
			throw new CustomException("Gallery is Empty.", HttpStatus.NOT_FOUND);
	}

	@Override
	public List<Certificate> getAllCertificate(String sUuid) {
		List<Certificate> certificates = this.getSME(sUuid).get().getCertificates();

		if (certificates != null && certificates.size() > 0) {
			return certificates;
		} else
			throw new CustomException("Company's Certificates Not Available", HttpStatus.NOT_FOUND);

	}

	@Override
	// @Cacheable("smes")
	public List<SMEInformation> getAllSME(int page, int size) throws CustomException {

		List<SMEInformation> smes = null;

		if (page == 0 || page < 0)
			page = 1;

		Page<SMEInformation> paggableList = smeRepository
				.findAll(PageRequest.of(--page, size, Sort.by(Direction.DESC, "creationDate")));

		smes = paggableList.getContent();

		// list = smeRepository.findAll(Sort.by(Direction.DESC, "creationDate"));
		if (smes != null && smes.size() > 0)
			return smes;

		else
			throw new CustomException("No SME's Available", HttpStatus.NOT_FOUND);
	}

	@Override
	public ManagementTeam getManagementTeam(String teamUuid) {
		ManagementTeam team = managementTeamRepository.findByTeamUuid(teamUuid);
		if (team == null) {
			throw new CustomException("Team not found with id " + teamUuid, HttpStatus.NOT_FOUND);
		}
		return team;
	}

	@Override
	public Infrastructure getInfrastructure(String infraUuid) {
		Infrastructure infrastructure = infraRepository.findByInfraUuid(infraUuid);
		if (infrastructure == null) {
			throw new CustomException("infrastructure not found with id " + infraUuid, HttpStatus.NOT_FOUND);
		}
		return infrastructure;
	}

	@Override
	public Certificate getCertificate(String crtiUuid) {

		Certificate certificate = certificateRepository.findByCrtiUuid(crtiUuid);
		if (certificate == null) {
			throw new CustomException("certificate not found with id " + crtiUuid, HttpStatus.NOT_FOUND);
		}
		return certificate;
	}

	@Override
	public Gallery getGallery(String galleryUuid) {
		Gallery gallery = galleryRepository.findByGalleryUuid(galleryUuid);
		if (gallery == null) {
			throw new CustomException("gallery not found with id " + galleryUuid, HttpStatus.NOT_FOUND);
		}
		return gallery;
	}

	@Override
	public List<Image> getSliderImages(String sUuid) {

		List<Image> homeSliderImages = this.getSME(sUuid).get().getHomeSliderImages();

		if (homeSliderImages != null && homeSliderImages.size() > 0) {
			return homeSliderImages;
		} else {
			throw new CustomException("No Slider Images Available for sme " + sUuid, HttpStatus.NOT_FOUND);
		}

	}

	@Override
	public void deleteCertificate(String crtiUuid) {
		Certificate c = this.getCertificate(crtiUuid);
		if (c.getImages() != null && c.getImages().size() > 0) {
			List<Image> images = c.getImages();
			images.forEach(img -> {
				try {
					contentServerEndpoint.deleteFileFromContentServer(img.getImageLocation());
				} catch (IOException e) {
					e.printStackTrace();
				}
			});
		}
		certificateRepository.delete(c);
	}

	public void deleteGallery(String galleryUuid) {

		Gallery g = this.getGallery(galleryUuid);

		if (g.getImages() != null && g.getImages().size() > 0) {
			List<Image> images = g.getImages();
			images.forEach(img -> {
				try {
					contentServerEndpoint.deleteFileFromContentServer(img.getImageLocation());
				} catch (IOException e) {
					e.printStackTrace();
				}
			});
		}
		galleryRepository.delete(g);
	}

	public void deleteInfra(String infraUuid) {

		Infrastructure i = this.getInfrastructure(infraUuid);

		if (i.getImages() != null && i.getImages().size() > 0) {
			List<Image> images = i.getImages();
			images.forEach(img -> {
				try {
					contentServerEndpoint.deleteFileFromContentServer(img.getImageLocation());
				} catch (IOException e) {
					e.printStackTrace();
				}
			});
		}
		infraRepository.delete(i);
	}

	public void deleteTeam(String teamUuid) {

		ManagementTeam team = this.getManagementTeam(teamUuid);

		if (team.getProfileImageUrl() != null) {
			try {
				contentServerEndpoint.deleteFileFromContentServer(team.getProfileImageUrl());
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
		managementTeamRepository.delete(team);
	}

	@Override
	public boolean isGSTINNumberExist(String gstin) {
		return smeRepository.existsByGstin(gstin);
	}

}
