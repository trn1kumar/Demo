package com.smeface.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smeface.entities.Infrastructure;
import com.smeface.model.PublishFeed;
import com.smeface.rest.BusinessPostEndpoint;

@Service
public class BusinessPostServiceImpl implements BusinessPostService {

	@Autowired
	BusinessPostEndpoint businessPostEndPoint;

	@Override
	public void createBusinessPost(String sUuid, Infrastructure infra) {

		PublishFeed feed = new PublishFeed(sUuid, infra.getInfraUuid(), infra.getMachineName(), infra.getDescription(),infra.getImages());
		try {
			businessPostEndPoint.createFeed(feed);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
