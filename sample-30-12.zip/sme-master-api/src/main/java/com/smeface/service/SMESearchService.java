package com.smeface.service;

import java.util.List;

import com.smeface.entities.SMEInformation;

public interface SMESearchService {

	
	public List<SMEInformation> getSearchResult(String searchText,int maxResult);
}
