package com.smeface.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
@Table(name = "sme_image")
public class Image {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	@JsonIgnore
	private Long imageId;

	@Column(name = "img_uuid", unique = true, updatable = false)
	private String imgUuid;

	@Column(name = "image_name")
	private String imageName;

	@Column(name = "image_location")
	private String imageLocation;

	@Column(name = "is_active")
	@JsonProperty(access = Access.WRITE_ONLY)
	private boolean active;

	public Image(String imgUuid, String imageName, String imageLocation, boolean isActive) {
		this.imgUuid = imgUuid;
		this.imageName = imageName;
		this.imageLocation = imageLocation;
		this.active = isActive;
	}

	public Image() {

	}

	public Long getImageId() {
		return imageId;
	}

	public void setImageId(Long imageId) {
		this.imageId = imageId;
	}

	public String getImgUuid() {
		return imgUuid;
	}

	public void setImgUuid(String imgUuid) {
		this.imgUuid = imgUuid;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public String getImageLocation() {
		return imageLocation;
	}

	public void setImageLocation(String imageLocation) {
		this.imageLocation = imageLocation;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean isActive) {
		this.active = isActive;
	}

}
