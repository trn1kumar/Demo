package com.smeface.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.apache.lucene.analysis.core.LowerCaseFilterFactory;
import org.apache.lucene.analysis.ngram.EdgeNGramFilterFactory;
import org.apache.lucene.analysis.pattern.PatternReplaceFilterFactory;
import org.apache.lucene.analysis.snowball.SnowballPorterFilterFactory;
import org.apache.lucene.analysis.standard.StandardTokenizerFactory;
import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Analyzer;
import org.hibernate.search.annotations.AnalyzerDef;
import org.hibernate.search.annotations.AnalyzerDefs;
import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;
import org.hibernate.search.annotations.Parameter;
import org.hibernate.search.annotations.Store;
import org.hibernate.search.annotations.TokenFilterDef;
import org.hibernate.search.annotations.TokenizerDef;

import com.smeface.common.audit.Auditable;

@Entity
@Table(name = "sme")
@AnalyzerDefs({
	
	@AnalyzerDef(name = "edgecustomanalyzer1", tokenizer = @TokenizerDef(factory = StandardTokenizerFactory.class), filters = {

			@TokenFilterDef(factory = LowerCaseFilterFactory.class),
			@TokenFilterDef(factory = SnowballPorterFilterFactory.class, params = {
					@Parameter(name = "language", value = "English") }),
			@TokenFilterDef(factory = EdgeNGramFilterFactory.class, params = {
					@Parameter(name = "maxGramSize", value = "8"),
					@Parameter(name = "minGramSize", value = "2") }) }),
	
	@AnalyzerDef(name = "customanalyzer", tokenizer = @TokenizerDef(factory = StandardTokenizerFactory.class), filters = {

			@TokenFilterDef(factory = LowerCaseFilterFactory.class),
			@TokenFilterDef(factory = PatternReplaceFilterFactory.class, params = {
					@Parameter(name = "pattern", value = "([^a-zA-Z0-9\\.])"),
					@Parameter(name = "replacement", value = " "), @Parameter(name = "replace", value = "all") }),
			@TokenFilterDef(factory = SnowballPorterFilterFactory.class, params = {
					@Parameter(name = "language", value = "English") })

	}) })
@Indexed
public class SMEInformation extends Auditable<String> {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "SmeId")
	private Long smeId;

	@Column(name = "UserId", unique = true, updatable = false)
	private String uuid;

	@Column(name = "sUuid", unique = true,updatable = false)
	private String sUuid;

	@Column(name = "sme_name")
	@Field(index = Index.YES, store = Store.NO, analyze = Analyze.YES)
	@Analyzer(definition = "edgecustomanalyzer1")
	private String smeName;

	@Column(name = "sme_Type")
	private String smeType;

	@Column(name = "OneLineStatement")
	private String oneLineStatement;

	@Column(name = "CompanyDescription", length = 1000)
	private String companyDescription;

	@Column(name = "ContactPerson")
	private String contactPerson;

	@Column(name = "ContactEmail")
	private String contactEmail;

	@Column(name = "ContactPhone")
	private String contactPhone;

	@Column(name = "RegisteredAs")
	private String registeredAS;

	@Column(name = "YearOfEstablishment")
	private String yearOfEstablishment;

	@Column(name = "NumberOfEmployees")
	private Integer numberOfEmployees;

	@Column(name = "TurnOver")
	private Double turnOver;

	@Column(name = "GSTIN")
	private String gstin;

	@Column(name = "logo_image")
	private String logoImage;

	@Column(name = "latitude")
	private String latitude;

	@Column(name = "longitude")
	private String longitude;

	@Column(name = "google_map_link")
	private String googlemapLink;

	@ManyToOne(optional = false)
	@JoinColumn(name = "categoryId",updatable=false)
	@IndexedEmbedded(includeEmbeddedObjectId=true)
	private SMECategory smeCategory;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "sme_address_id")
	@IndexedEmbedded
	private Address smeAddress;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "sme_id")
	private List<Image> homeSliderImages;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "sme_id", nullable = false)
	private List<ManagementTeam> managementTeams;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "sme_id", nullable = false)
	private List<Infrastructure> infrastructure;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "sme_id", nullable = false, insertable = true, updatable = false)
	private List<Certificate> certificates;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "sme_id", nullable = false)
	private List<Gallery> gallery;

	public Long getSmeId() {
		return smeId;
	}

	public void setSmeId(Long smeId) {
		this.smeId = smeId;
	}

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public List<ManagementTeam> getManagementTeams() {
		return managementTeams;
	}

	public void setManagementTeams(List<ManagementTeam> managementTeams) {
		this.managementTeams = managementTeams;
	}

	public List<Infrastructure> getInfrastructure() {
		return infrastructure;
	}

	public void setInfrastructure(List<Infrastructure> infrastructure) {
		this.infrastructure = infrastructure;
	}

	public String getSmeType() {
		return smeType;
	}

	public void setSmeType(String smeType) {
		this.smeType = smeType;
	}

	public List<Certificate> getCertificates() {
		return certificates;
	}

	public void setCertificates(List<Certificate> certificates) {
		this.certificates = certificates;
	}

	public List<Gallery> getGallery() {
		return gallery;
	}

	public void setGallery(List<Gallery> gallery) {
		this.gallery = gallery;
	}

	public String getSmeName() {
		return smeName;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getLogoImage() {
		return logoImage;
	}

	public void setLogoImage(String logoImage) {
		this.logoImage = logoImage;
	}

	public List<Image> getHomeSliderImages() {
		return homeSliderImages;
	}

	public void setHomeSliderImages(List<Image> homeSliderImages) {
		this.homeSliderImages = homeSliderImages;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public String getOneLineStatement() {
		return oneLineStatement;
	}

	public void setOneLineStatement(String oneLineStatement) {
		this.oneLineStatement = oneLineStatement;
	}

	public String getCompanyDescription() {
		return companyDescription;
	}

	public void setCompanyDescription(String companyDescription) {
		this.companyDescription = companyDescription;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

	public String getRegisteredAS() {
		return registeredAS;
	}

	public void setRegisteredAS(String registeredAS) {
		this.registeredAS = registeredAS;
	}

	public String getYearOfEstablishment() {
		return yearOfEstablishment;
	}

	public void setYearOfEstablishment(String yearOfEstablishment) {
		this.yearOfEstablishment = yearOfEstablishment;
	}

	public Integer getNumberOfEmployees() {
		return numberOfEmployees;
	}

	public void setNumberOfEmployees(Integer numberOfEmployees) {
		this.numberOfEmployees = numberOfEmployees;
	}

	public String getGooglemapLink() {
		return googlemapLink;
	}

	public void setGooglemapLink(String googlemapLink) {
		this.googlemapLink = googlemapLink;
	}

	public Double getTurnOver() {
		return turnOver;
	}

	public void setTurnOver(Double turnOver) {
		this.turnOver = turnOver;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public Address getSmeAddress() {
		return smeAddress;
	}

	public void setSmeAddress(Address smeAddress) {
		this.smeAddress = smeAddress;
	}

	public SMECategory getSmeCategory() {
		return smeCategory;
	}

	public void setSmeCategory(SMECategory smeCategory) {
		this.smeCategory = smeCategory;
	}

}
