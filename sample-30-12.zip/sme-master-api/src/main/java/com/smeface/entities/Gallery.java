package com.smeface.entities;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.smeface.common.audit.Auditable;

@Entity
@Table(name = "sme_gallery")
public class Gallery extends Auditable<String> {

	@Id
	@GeneratedValue
	@Column(name = "galleryId")
	private Long galleryId;
	
	@Column(name = "gallery_uuid",updatable=false,unique=true)
	private String galleryUuid;
	
	@Column(name = "galleryTitle",length = 30)
	private String galleryTitle;

	@Column(name = "description",length = 1000)
	private String description;
	
	@Column(name = "isActive")
	private boolean active=false;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "galleryId")
	private List<Image> images;


	public String getGalleryTitle() {
		return galleryTitle;
	}

	public void setGalleryTitle(String galleryTitle) {
		this.galleryTitle = galleryTitle;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Long getGalleryId() {
		return galleryId;
	}

	public void setGalleryId(Long galleryId) {
		this.galleryId = galleryId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public List<Image> getImages() {
		return images;
	}

	public void setImages(List<Image> images) {
		this.images = images;
	}

	public String getGalleryUuid() {
		return galleryUuid;
	}

	public void setGalleryUuid(String galleryUuid) {
		this.galleryUuid = galleryUuid;
	}

}
