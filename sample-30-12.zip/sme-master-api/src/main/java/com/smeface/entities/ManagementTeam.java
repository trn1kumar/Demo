package com.smeface.entities;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import com.smeface.common.audit.Auditable;

@Entity
@Table(name = "sme_mangement_team")
public class ManagementTeam extends Auditable<String> {

	@Id
	@GeneratedValue
	@Column(name = "management_team_id")
	private Long teamId;

	@Column(name = "team_uuid", updatable = false, unique = true)
	private String teamUuid;

	@Column(name = "Full_Name")
	private String fullName;

	@Column(name = "Designation",length = 1000)
	private String designation;

	@Column(name = "Experience")
	private Long experience;

	@Column(name = "mail_id")
	private String mail;

	@Column(name = "Profile_Description")
	private String profileDesc;
	
	@Column(name = "profileImageUrl")
	private String profileImageUrl;

	@Column(name = "isActive")
	private boolean active = false;

	@Column(name = "Facebook_Link")
	private String fbLink;

	@Column(name = "LinkedIn_Link")
	private String linkedinLink;

	@Column(name = "Twitter_Link")
	private String twitterLink;

	public Long getTeamId() {
		return teamId;
	}

	public void setTeamId(Long teamId) {
		this.teamId = teamId;
	}

	public boolean isActive() {
		return active;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Long getExperience() {
		return experience;
	}

	public void setExperience(Long experience) {
		this.experience = experience;
	}

	public String getProfileDesc() {
		return profileDesc;
	}

	public void setProfileDesc(String profileDesc) {
		this.profileDesc = profileDesc;
	}

	public String getFbLink() {
		return fbLink;
	}

	public void setFbLink(String fbLink) {
		this.fbLink = fbLink;
	}

	public String getLinkedinLink() {
		return linkedinLink;
	}

	public void setLinkedinLink(String linkedinLink) {
		this.linkedinLink = linkedinLink;
	}

	public String getTwitterLink() {
		return twitterLink;
	}

	public void setTwitterLink(String twitterLink) {
		this.twitterLink = twitterLink;
	}

	public String getTeamUuid() {
		return teamUuid;
	}

	public void setTeamUuid(String teamUuid) {
		this.teamUuid = teamUuid;
	}

	public String getProfileImageUrl() {
		return profileImageUrl;
	}

	public void setProfileImageUrl(String profileImageUrl) {
		this.profileImageUrl = profileImageUrl;
	}

}
