package com.smeface.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.ContainedIn;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;
import org.hibernate.search.annotations.Store;

@Entity
@Table(name = "sme_category")
@Indexed
public class SMECategory {

	@Id
	@GeneratedValue
	@Column(name = "categoryId")
	private Long categoryId;
	
	@Column(name = "categoryUuid",unique=true,updatable=false)
	private String categoryUuid;
	
	@Column(name = "categoryUrl",unique=true,updatable=false)
	@Field(index = Index.YES, store = Store.NO, analyze = Analyze.NO)
	private String categoryUrl;
	
	private String categoryName;
	private String imageLocation;

	@OneToMany(mappedBy = "smeCategory", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@ContainedIn
	private List<SMEInformation> smes;

	public Long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryUuid() {
		return categoryUuid;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryUuid(String categoryUuid) {
		this.categoryUuid = categoryUuid;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public List<SMEInformation> getSmes() {
		return smes;
	}

	public void setSmes(List<SMEInformation> smes) {
		this.smes = smes;
	}

	public String getCategoryUrl() {
		return categoryUrl;
	}

	public void setCategoryUrl(String categoryUrl) {
		this.categoryUrl = categoryUrl;
	}

	public String getImageLocation() {
		return imageLocation;
	}

	public void setImageLocation(String imageLocation) {
		this.imageLocation = imageLocation;
	}

}
