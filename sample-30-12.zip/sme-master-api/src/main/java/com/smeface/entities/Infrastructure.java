package com.smeface.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.smeface.common.audit.Auditable;

@Entity
@Table(name = "sme_infrastructure")
public class Infrastructure extends Auditable<String> {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "infrastructure_id")
	private Long id;

	@Column(name = "infra_uuid")
	private String infraUuid;

	@Column(name = "machine_name")
	@NotNull(message = "Machine Name cannot be null")
	private String machineName;

	@Column(name = "manufacturer")
	private String manufacturer;

	@Column(name = "model_name")
	private String modelName;

	@Column(name = "is_business_post")
	private boolean businessPost;

	@Column(name = "isActive")
	private boolean active = false;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "infrastructure_id")
	private List<Image> images;

	@Column(name = "machine_description",length = 1000)
	private String description;

	@Column(name = "machine_quantity")
	private String quantity;

	@Column(name = "machine_capacity")
	private String capacity;

	public Infrastructure() {
		super();
	}

	public Infrastructure(String infraUuid, String machineName, String description, List<Image> images) {
		this.infraUuid = infraUuid;
		this.machineName = machineName;
		this.description = description;
		this.images = images;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMachineName() {
		return machineName;
	}

	public boolean isActive() {
		return active;
	}

	public boolean isBusinessPost() {
		return businessPost;
	}

	public void setBusinessPost(boolean businessPost) {
		this.businessPost = businessPost;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setMachineName(String machineName) {
		this.machineName = machineName;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getCapacity() {
		return capacity;
	}

	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}

	public String getInfraUuid() {
		return infraUuid;
	}

	public void setInfraUuid(String infraUuid) {
		this.infraUuid = infraUuid;
	}

	public List<Image> getImages() {
		return images;
	}

	public void setImages(List<Image> images) {
		this.images = images;
	}

}