package com.smeface.exception;

public class CustomValidation extends RuntimeException {

	
	private static final long serialVersionUID = 1L;

	private ValidationErrors validationError;

	public CustomValidation(ValidationErrors validationError) {
		this.setValidationError(validationError);
	}

	public ValidationErrors getValidationError() {
		return validationError;
	}

	public void setValidationError(ValidationErrors validationError) {
		this.validationError = validationError;
	}

}
