package com.smeface.configuration;

import javax.annotation.Resource;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.smeface.rest.BusinessPostEndpoint;
import com.smeface.rest.CircleEndpoint;
import com.smeface.rest.ContentServerEndpoint;
import com.smeface.rest.CreditCheckEndpoint;
import com.smeface.rest.UserEndpoint;


@Configuration
@PropertySource(value = { "classpath:application.properties" })
//@PropertySource("file:/${app.home}/application-dev.properties")
public class BeanConfiguration {

	@Resource
	private Environment environment;
	
	@Bean
	public UserEndpoint userEndpoint() {

		Client client = ClientBuilder.newClient();
		String endpoint = environment.getRequiredProperty("user.endpoint");
		String changeTypePath = environment.getRequiredProperty("changetype.path");
		UserEndpoint userEndpoint = new UserEndpoint(client, endpoint, changeTypePath);
		return userEndpoint;

	}
	
	@Bean
	public CircleEndpoint circleEndpoint() {

		Client client = ClientBuilder.newClient();
		String endpoint = environment.getRequiredProperty("circle.endpoint");
		String createCircle = environment.getRequiredProperty("create.circle");
		CircleEndpoint circleEndpoint = new CircleEndpoint(client, endpoint, createCircle);
		return circleEndpoint;

	}

	@Bean
	public BusinessPostEndpoint businessPostEndpoint() {
		Client client = ClientBuilder.newClient();
		String endpoint = environment.getRequiredProperty("business-post.endpoint");
		String createFeed = environment.getRequiredProperty("post.path");
		String updateStatus=environment.getRequiredProperty("update.status.path");
		BusinessPostEndpoint businessPostEndpoint = new BusinessPostEndpoint(client, endpoint, createFeed,updateStatus);
		return businessPostEndpoint;

	}
	
	@Bean
	public CreditCheckEndpoint pricingEndpoint() {
		Client client = ClientBuilder.newClient();
		String endpoint = environment.getRequiredProperty("pricing.server.endpoint");
		String selectPkg = environment.getRequiredProperty("select.pkg.path");
		CreditCheckEndpoint pricingEndpoint = new CreditCheckEndpoint(client, endpoint, selectPkg);
		return pricingEndpoint;
	}
	
	@Bean
	public ContentServerEndpoint contentConfiguration() {
		Client client = ClientBuilder.newBuilder().register(MultiPartFeature.class).build();

		String contentServerEndPoint = environment.getRequiredProperty("contentserver.endpoint");
		String uploadMultipleFile = environment.getRequiredProperty("uploadsfiles.endpoint.path");
		String deleteFile = environment.getRequiredProperty("deletefile.endpoint.path");
		ContentServerEndpoint notification = new ContentServerEndpoint(client, contentServerEndPoint,
				uploadMultipleFile, deleteFile);
		return notification;
	}
}
