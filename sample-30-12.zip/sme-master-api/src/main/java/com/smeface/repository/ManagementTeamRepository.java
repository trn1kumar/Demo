package com.smeface.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.smeface.entities.ManagementTeam;

public interface ManagementTeamRepository extends JpaRepository<ManagementTeam, Long> {

	ManagementTeam findByTeamUuid(String teamUuid);

	boolean existsByTeamUuid(String teamUuid);

	@Modifying
	@Transactional
	@Query("update ManagementTeam m set m.active= :active where m.teamUuid= :teamUuid")
	public void updateStatus(@Param("teamUuid") String teamUuid, @Param("active") boolean active);
	
	
}
