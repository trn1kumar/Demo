package com.smeface.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.smeface.entities.SMECategory;

public interface SMECategoryRepository extends JpaRepository<SMECategory, Long> {

	SMECategory findByCategoryUuid(String categoryUuid);

	SMECategory findByCategoryUrl(String categoryUrl);

	@Query("select COUNT(s) from SMECategory c JOIN c.smes s where c.categoryUuid =:categoryUuid")
	int getSMEsCountByCategoryUuid(@Param("categoryUuid") String categoryUuid);

}
