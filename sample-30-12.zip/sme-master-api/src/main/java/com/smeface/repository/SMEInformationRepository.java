package com.smeface.repository;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.smeface.entities.SMEInformation;

public interface SMEInformationRepository extends JpaRepository<SMEInformation, Long> {

	SMEInformation findByUuid(String uuid);

	Optional<SMEInformation> findBySUuid(String sUuid);

	boolean existsBySUuid(String sUuid);

	@Query("select smeName,contactPerson,logoImage from SMEInformation s where s.sUuid=:sUuid")
	String smeInfo(@Param("sUuid") String sUuid);

	@Modifying
	@Transactional
	@Query("update SMEInformation s set s.logoImage=:imageLocation where s.sUuid= :sUuid")
	void updateSmeLogo(@Param("sUuid") String sUuid, @Param("imageLocation") String imageLocation);

	boolean existsByGstin(String gstin);

	boolean existsByUuid(String uuid);

}
