package com.smeface.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.smeface.entities.Gallery;

public interface GalleryRepository extends JpaRepository<Gallery, Long>{

	public Gallery findByGalleryUuid(String galleryUuid);
	
	boolean existsByGalleryUuid(String galleryUuid);

	@Modifying
	@Transactional
	@Query("update Gallery g set g.active= :active where g.galleryUuid= :galleryUuid")
	public void updateStatus(@Param("galleryUuid") String galleryUuid, @Param("active") boolean active);
	
}