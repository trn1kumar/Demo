
package com.smeface.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.smeface.aop.TrackTime;
import com.smeface.component.presentation.PresentationComponent;
import com.smeface.constants.SMEMasterConstants.RoleAccess;
import com.smeface.constants.SMEMasterConstants.SMEFileDirectory;
import com.smeface.constants.SMEMasterConstants.SMEFormData;
import com.smeface.constants.SMEMasterConstants.StatusConstant;
import com.smeface.constants.UrlMapping;
import com.smeface.custom.validation.SMEValid;
import com.smeface.dto.CertificateDto;
import com.smeface.dto.GalleryDto;
import com.smeface.dto.InfrastructureDto;
import com.smeface.dto.ManagementTeamDto;
import com.smeface.dto.SMEInformationDto;
import com.smeface.entities.Address;
import com.smeface.entities.Certificate;
import com.smeface.entities.Gallery;
import com.smeface.entities.Image;
import com.smeface.entities.Infrastructure;
import com.smeface.entities.ManagementTeam;
import com.smeface.entities.SMECategory;
import com.smeface.entities.SMEInformation;
import com.smeface.exception.CustomException;
import com.smeface.mapper.SMEMapper;
import com.smeface.model.AuthToken;
import com.smeface.repository.SMECategoryRepository;
import com.smeface.service.BusinessPostService;
import com.smeface.service.FileService;
import com.smeface.service.SMEFilterService;
import com.smeface.service.SMEService;
import com.smeface.service.UserService;
import com.smeface.util.JsonUtil;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.BASE_URL)
public class SMEController {
	@Autowired
	private SMEService smeService;

	@Autowired
	private SMEMapper mapper;

	@Autowired
	SMEFilterService smeFilterService;

	@Autowired
	private SMEValid valid;

	@Autowired
	@Qualifier("gallery")
	PresentationComponent galleryPresentationComponent;

	@Autowired
	private JsonUtil jsonUtil;

	@Autowired
	private FileService fileService;

	@Autowired
	UserService userService;

	@Autowired
	SMECategoryRepository smeCategoryRepository;
	
	@Value("${per-page-size}")
	private int size;
	
	@Value("${default-page}")
	private int defaultPage;

	@Autowired
	private BusinessPostService businessPostService;

	@PostMapping(UrlMapping.SMEController.SAVE_SME)
	public ResponseEntity<?> saveInfo(MultipartHttpServletRequest request,
			@RequestParam(value = "logoImage", required = false) MultipartFile logoImage)
			throws CustomException, IllegalArgumentException, IOException {

		SMECategory smeCategory = null;
		AuthToken token = null;

		smeCategory = jsonUtil.parseJsonData(request, SMEFormData.SME_DATA, SMECategory.class);

		valid.isValid(smeCategory.getSmes().get(0));

		SMEInformation information = smeService.saveSme(smeCategory);

		try {
			if (logoImage != null) {
				List<Image> images = fileService.sendFilesToContentServer(Arrays.asList(logoImage),
						SMEFileDirectory.SME.replace("{sUuid}", information.getsUuid()));
				information.setLogoImage(images.get(0).getImageLocation());
				smeService.updateSmeLogo(information.getsUuid(), information.getLogoImage());
			}

		} catch (CustomException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		token = userService.updateUserTypeAndGetNewToken(information.getsUuid(), information.getUuid());
		token.setsUuid(information.getsUuid());
		return new ResponseEntity<AuthToken>(token, HttpStatus.CREATED);
	}

	@PutMapping(UrlMapping.SMEController.SAVE_SME)
	@PreAuthorize(RoleAccess.ADMIN)
	public ResponseEntity<?> updateSme(@RequestBody SMEInformation sme) {

		SMEInformationDto smeDto = null;
		SMEInformation information = null;

		valid.isValid(sme);

		try {
			information = smeService.updateSme(sme);
			smeDto = mapper.convertToDto(information, SMEInformationDto.class);
		} catch (CustomException e) {
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return new ResponseEntity<SMEInformationDto>(smeDto, HttpStatus.OK);
	}

	@PostMapping("/{sUuid}/address")
	public ResponseEntity<?> updateAddress(@PathVariable String sUuid, @RequestBody Address address) {
		return ResponseEntity.ok(smeService.updateSmeAddress(sUuid, address));
	}

	@PostMapping(UrlMapping.SMEController.SAVE_INFRASTRUCTURES)
	@PreAuthorize(RoleAccess.ADMIN)
	public ResponseEntity<?> saveInfrastructures(@RequestBody InfrastructureDto infrastructureDto, @PathVariable String sUuid)
			throws CustomException {

		List<Infrastructure> infrastructures = new ArrayList<>();

		try {
			
			Infrastructure infrastructure = mapper.convertToEntity(infrastructureDto, Infrastructure.class);
			infrastructures.add(infrastructure);
			smeService.saveInfrastructures(infrastructures, sUuid);
			if (infrastructure.isBusinessPost())
				businessPostService.createBusinessPost(sUuid, infrastructure);
		} catch (CustomException e) {
			throw new CustomException(e.getMessage(), e.getErrorCode());
		}
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@PostMapping(UrlMapping.SMEController.SAVE_TEAMS)
	@PreAuthorize(RoleAccess.ADMIN)
	public ResponseEntity<?> saveManagementTeams(@RequestBody ManagementTeamDto managementTeamDto, @PathVariable String sUuid)
			throws CustomException{

		List<ManagementTeam> managementTeams = null;
		try {

			ManagementTeam managementTeam = mapper.convertToEntity(managementTeamDto, ManagementTeam.class);
			managementTeams = new ArrayList<>();
			managementTeams.add(managementTeam);
			smeService.saveManagementTeams(managementTeams, sUuid);
		} catch (CustomException e) {
			throw new CustomException(e.getMessage(), e.getErrorCode());
		}
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@PostMapping(UrlMapping.SMEController.SAVE_CERTIFICATES)
	@PreAuthorize(RoleAccess.ADMIN)
	public ResponseEntity<?> saveCertificate(@RequestBody CertificateDto certificateDto, @PathVariable String sUuid)
			throws CustomException {

		List<Certificate> certificates = new ArrayList<>();

		try {
			Certificate certificate = mapper.convertToEntity(certificateDto, Certificate.class);
			certificates.add(certificate);
			smeService.saveCertificates(certificates, sUuid);
		} catch (CustomException e) {
			throw new CustomException(e.getMessage(), e.getErrorCode());
		}
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@PostMapping(UrlMapping.SMEController.SAVE_GALLERIES)
	@PreAuthorize(RoleAccess.ADMIN)
	public ResponseEntity<?> saveGallery(@RequestBody GalleryDto galleryDto, @PathVariable String sUuid)
			throws CustomException {

		List<Gallery> galleryList = new ArrayList<>();
		try {
			Gallery gallery = mapper.convertToEntity(galleryDto, Gallery.class);
			galleryList.add(gallery);
			smeService.saveGallery(galleryList, sUuid);
		} catch (CustomException e) {
			throw new CustomException(e.getMessage(), e.getErrorCode());
		}
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@GetMapping(UrlMapping.SMEController.GET_TEAMS)
	public ResponseEntity<?> getManagementTeamsInfo(@PathVariable String sUuid,
			@RequestParam(required = false) String status) throws CustomException {

		List<ManagementTeam> teams = null;
		List<ManagementTeamDto> teamsDto = new ArrayList<>();
		try {
			teams = smeService.getAllManagementTeam(sUuid);
			if (status == null) {
				teams.forEach(team -> {
					teamsDto.add(mapper.convertToDto(team, ManagementTeamDto.class));
				});
			} else {
				switch (status) {
				case StatusConstant.ACTIVE:
					teams.stream().filter(team -> team.isActive()).forEach(team -> {
						teamsDto.add(mapper.convertToDto(team, ManagementTeamDto.class));
					});
					break;
				case StatusConstant.DEACTIVE:
					teams.stream().filter(team -> !team.isActive()).forEach(team -> {
						teamsDto.add(mapper.convertToDto(team, ManagementTeamDto.class));
					});
					break;
				}
			}
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return new ResponseEntity<List<ManagementTeamDto>>(teamsDto, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.SMEController.GET_GALLERIES)
	public ResponseEntity<?> getAllGallery(@PathVariable String sUuid, @RequestParam(required = false) String status)
			throws CustomException {

		List<Gallery> galleries = null;
		List<GalleryDto> galleriesDto = new ArrayList<>();
		try {
			galleries = smeService.getAllGallery(sUuid);
			if (status == null) {
				galleries.forEach(glryData -> {
					galleriesDto.add(mapper.convertToDto(glryData, GalleryDto.class));
				});
			} else {
				switch (status) {
				case StatusConstant.ACTIVE:
					galleries.parallelStream().filter(glryData -> glryData.isActive()).forEach(glryData -> {
						galleriesDto.add(mapper.convertToDto(glryData, GalleryDto.class));
					});
					break;
				case StatusConstant.DEACTIVE:
					galleries.stream().filter(glryData -> !glryData.isActive()).forEach(glryData -> {
						galleriesDto.add(mapper.convertToDto(glryData, GalleryDto.class));
					});
					break;
				}
			}

		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return new ResponseEntity<List<GalleryDto>>(galleriesDto, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.SMEController.GET_INFRASTRUCTURES)
	public ResponseEntity<?> getInfrastructuresInfo(@PathVariable String sUuid,
			@RequestParam(required = false) String status) throws CustomException {
		List<Infrastructure> infrastructures = null;
		List<InfrastructureDto> infrastructuresDto = new ArrayList<>();
		try {
			infrastructures = smeService.getAllInfrastructure(sUuid);

			if (status == null) {
				infrastructures.forEach(infra -> {
					infrastructuresDto.add(mapper.convertToDto(infra, InfrastructureDto.class));
				});
			} else {

				switch (status) {
				case StatusConstant.ACTIVE:
					infrastructures.stream().filter(infra -> infra.isActive()).forEach(infra -> {
						infrastructuresDto.add(mapper.convertToDto(infra, InfrastructureDto.class));
					});
					break;

				case StatusConstant.DEACTIVE:
					infrastructures.stream().filter(infra -> !infra.isActive()).forEach(infra -> {
						infrastructuresDto.add(mapper.convertToDto(infra, InfrastructureDto.class));
					});
					break;
				}
			}

		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return new ResponseEntity<List<InfrastructureDto>>(infrastructuresDto, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.SMEController.GET_CERTIFICATES)
	public ResponseEntity<?> getCertificates(@PathVariable String sUuid, @RequestParam(required = false) String status)
			throws CustomException {
		List<Certificate> certificates = null;
		List<CertificateDto> certificatesDto = new ArrayList<>();

		try {
			certificates = smeService.getAllCertificate(sUuid);

			if (status == null) {
				certificates.forEach(certificate -> {
					certificatesDto.add(mapper.convertToDto(certificate, CertificateDto.class));
				});
			} else {

				switch (status) {
				case StatusConstant.ACTIVE:
					certificates.stream().filter(certificate -> certificate.isActive()).forEach(certificate -> {
						certificatesDto.add(mapper.convertToDto(certificate, CertificateDto.class));
					});
					break;

				case StatusConstant.DEACTIVE:
					certificates.stream().filter(certificate -> !certificate.isActive()).forEach(certificate -> {
						certificatesDto.add(mapper.convertToDto(certificate, CertificateDto.class));
					});
					break;
				}

			}

		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<List<CertificateDto>>(certificatesDto, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.SMEController.GET_CERTIFICATE)
	public ResponseEntity<?> getCertificate(@PathVariable String crtiUuid) throws CustomException {
		Certificate certificate = null;
		CertificateDto certificateDto = null;
		try {
			certificate = smeService.getCertificate(crtiUuid);
			certificateDto = mapper.convertToDto(certificate, CertificateDto.class);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<CertificateDto>(certificateDto, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.SMEController.GET_TEAM)
	public ResponseEntity<?> getManagementTeam(@PathVariable String teamUuid) throws CustomException {
		ManagementTeam team = null;
		ManagementTeamDto teamDto = null;
		try {
			team = smeService.getManagementTeam(teamUuid);
			teamDto = mapper.convertToDto(team, ManagementTeamDto.class);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<ManagementTeamDto>(teamDto, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.SMEController.GET_INFRASTRUCTURE)
	public ResponseEntity<?> getInfrastructure(@PathVariable String infraUuid,
			@RequestParam(value = "source", required = false) String source) throws CustomException {
		Infrastructure infrastructure = null;
		InfrastructureDto infrastructureDto = null;
		try {
			infrastructure = smeService.getInfrastructure(infraUuid);
			if (source != null && source.equals("post"))
				infrastructure = new Infrastructure(infrastructure.getInfraUuid(), infrastructure.getMachineName(),
						infrastructure.getDescription(), infrastructure.getImages());
			infrastructureDto = mapper.convertToDto(infrastructure, InfrastructureDto.class);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<InfrastructureDto>(infrastructureDto, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.SMEController.GET_GALLERY)
	public ResponseEntity<?> getGallery(@PathVariable String galleryUuid) throws CustomException {
		Gallery gallery = null;
		/*
		 * List<? extends Object> galleryDto=null; gallery =
		 * smeService.getGallery(galleryUuid);
		 * galleryDto=galleryPresentationComponent.getPresentationObj(gallery);
		 */

		GalleryDto galleryDto = null;
		try {
			gallery = smeService.getGallery(galleryUuid);
			galleryDto = mapper.convertToDto(gallery, GalleryDto.class);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<GalleryDto>(galleryDto, HttpStatus.OK);
	}

	@DeleteMapping(UrlMapping.SMEController.DELETE_CERTIFICATE)
	@PreAuthorize(RoleAccess.ADMIN)
	public ResponseEntity<?> deleteCertificate(@PathVariable String crtiUuid) throws CustomException {

		try {
			smeService.deleteCertificate(crtiUuid);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>(HttpStatus.OK);

	}

	@DeleteMapping(UrlMapping.SMEController.DELETE_GALLERY)
	@PreAuthorize(RoleAccess.ADMIN)
	public ResponseEntity<?> deleteGallery(@PathVariable String galleryUuid) throws CustomException {

		try {
			smeService.deleteGallery(galleryUuid);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return new ResponseEntity<>(HttpStatus.OK);
	}

	@DeleteMapping(UrlMapping.SMEController.DELETE_INFRASTRUCTURE)
	@PreAuthorize(RoleAccess.ADMIN)
	public ResponseEntity<?> deleteInfrastructure(@PathVariable String infraUuid) throws CustomException {

		try {
			smeService.deleteInfra(infraUuid);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@DeleteMapping(UrlMapping.SMEController.DELETE_TEAM)
	@PreAuthorize(RoleAccess.ADMIN)
	public ResponseEntity<?> deleteTeam(@PathVariable String teamUuid) throws CustomException {

		try {
			smeService.deleteTeam(teamUuid);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@GetMapping(UrlMapping.SMEController.GET_SMEBY_UUID)
	public ResponseEntity<?> getSmeByUser(@PathVariable String uuid) throws CustomException {
		SMEInformation information = null;
		SMEInformationDto informationDto = null;
		try {
			information = smeService.getSMEByUserId(uuid);
			informationDto = mapper.convertToDto(information, SMEInformationDto.class);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<SMEInformationDto>(informationDto, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.SMEController.GET_SLIDER_IMAGES)
	public ResponseEntity<?> getSmeSliderImages(@PathVariable String sUuid) throws CustomException {

		List<Image> homeSliderImages = null;

		try {
			homeSliderImages = smeService.getSliderImages(sUuid);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return new ResponseEntity<List<Image>>(homeSliderImages, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.SMEController.GET_SME)
	public ResponseEntity<?> getSmeInfo(@PathVariable String sUuid) throws CustomException {
		SMEInformation information = null;
		SMEInformationDto informationDto = null;

		try {
			information = smeService.getSME(sUuid).get();
			informationDto = mapper.convertToDto(information, SMEInformationDto.class);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<SMEInformationDto>(informationDto, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.SMEController.GET_TOP_SMES)
	public ResponseEntity<?> getTopSME() throws CustomException {
		List<SMEInformationDto> smelist = null;
		try {
			smelist = smeService.getAllSME(defaultPage,size).stream().map(mapper::convertToDtoForSmeList).collect(Collectors.toList());
		} catch (CustomException e) {
			throw e;
		} catch (IllegalArgumentException e) {
			throw new CustomException(e.getMessage(), HttpStatus.NOT_ACCEPTABLE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<List<SMEInformationDto>>(smelist, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.SMEController.GET_SMEVO)
	public ResponseEntity<?> getSmeVo(@PathVariable String sUuid) throws CustomException {
		SMEInformationDto dtoInfo = null;
		try {
			dtoInfo = smeService.getSmeVo(sUuid);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<SMEInformationDto>(dtoInfo, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.SMEController.VALIDATE_GSTIN)
	@TrackTime
	public ResponseEntity<?> checkGSTINNumberPresent(@PathVariable String gstin) {
		if (smeService.isGSTINNumberExist(gstin))
			throw new CustomException("GSTIN Number Already Present", HttpStatus.BAD_REQUEST);
		else
			return ResponseEntity.ok().build();
	}

}
