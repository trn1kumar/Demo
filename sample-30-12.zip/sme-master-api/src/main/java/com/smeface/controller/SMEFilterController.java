package com.smeface.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smeface.constants.UrlMapping;
import com.smeface.dto.FilterDto;
import com.smeface.dto.FilterResponse;
import com.smeface.entities.SMEInformation;
import com.smeface.exception.CustomException;
import com.smeface.mapper.SMEMapper;
import com.smeface.service.SMEFilterService;
import com.smeface.service.SMEService;
import com.smeface.vo.SMEInformationVo;

@RestController
@RequestMapping(UrlMapping.BASE_URL)
@CrossOrigin("*")
public class SMEFilterController {

	@Autowired
	SMEFilterService smeFilterService;

	@Autowired
	private SMEService smeService;

	@Autowired
	private SMEMapper mapper;

	@Value("${per-page-size}")
	private int size;

	@Value("${default-page}")
	private int defaultPage;

	@Value("${default-first-result}")
	private int defaultFirstResult;

	@GetMapping(UrlMapping.SMEController.GET_SMES)
	public ResponseEntity<?> getSmes(@RequestParam(required = false) Set<String> categoriesFilterParam,
			@RequestParam(required = false) Set<String> citiesFilterParam, @RequestParam(required = false) Integer page,
			@RequestParam(required = false) Integer firstResult) {
		FilterResponse filterResponse = null;
		List<SMEInformation> smelist = null;
		FilterDto filterDto = null;
		List<SMEInformationVo> smes = new ArrayList<>();

		if (page == null && firstResult == null) {
			/*
			 * get filter
			 */
			filterDto = smeFilterService.getFilter(categoriesFilterParam, citiesFilterParam);
		}

		try {
			/*
			 * if Cities filter param is not null then get data according to that filter
			 */
			if (categoriesFilterParam != null && !categoriesFilterParam.isEmpty()
					|| citiesFilterParam != null && !citiesFilterParam.isEmpty()) {
				if (firstResult == null || firstResult == 0 || firstResult < 0)
					firstResult = defaultFirstResult;
				smelist = smeFilterService.applyFilter(categoriesFilterParam, citiesFilterParam, firstResult, size);

			} else {
				/*
				 * otherwise get data without filter
				 */
				if (page == null || page == 0 || page < 0)
					page = defaultPage;
				smelist = smeService.getAllSME(page, size);
			}

			smelist.forEach(sme -> {
				smes.add(mapper.convertToDto(sme, SMEInformationVo.class));

			});

			filterResponse = new FilterResponse(filterDto, smes, smes.size());
			return ResponseEntity.ok(filterResponse);

		} catch (CustomException e) {
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ResponseEntity.ok(smes);
	}

	/*
	 * @GetMapping(UrlMapping.SMEController.GET_SMES_WITH_PAGE) public
	 * ResponseEntity<?> getCategory(@RequestParam(required = false) Set<String>
	 * categoriesFilterParam,
	 * 
	 * @RequestParam(required = false) Set<String> citiesFilterParam, @RequestParam
	 * int page,
	 * 
	 * @RequestParam int firstResult) { List<SMEInformation> smelist = null;
	 * List<SMEInformationVo> smes = new ArrayList<>(); try {
	 * 
	 * if Cities filter param is not null then get data according to that filter
	 * 
	 * if (categoriesFilterParam != null && !categoriesFilterParam.isEmpty() ||
	 * citiesFilterParam != null && !citiesFilterParam.isEmpty()) { smelist =
	 * smeFilterService.applyFilter(categoriesFilterParam, citiesFilterParam,
	 * firstResult, size);
	 * 
	 * } else {
	 * 
	 * otherwise get data without filter
	 * 
	 * smelist = smeService.getAllSME(page, size); }
	 * 
	 * smelist.forEach(sme -> { smes.add(mapper.convertToDto(sme,
	 * SMEInformationVo.class));
	 * 
	 * });
	 * 
	 * } catch (CustomException e) { throw e; } catch (Exception e) {
	 * e.printStackTrace(); } return ResponseEntity.ok(smes); }
	 */
	@RequestMapping("/filter")
	public ResponseEntity<?> getFilter(@RequestParam(required = false) Set<String> categoriesFilterParam,
			@RequestParam(required = false) Set<String> citiesFilterParam) {
		/*
		 * List<SMEInformation> smes = null; List<SMEInformationVo> smeList = new
		 * ArrayList<>(); Map<String, Object> data = new HashMap<>();
		 */
		FilterDto filter = smeFilterService.getFilter(categoriesFilterParam, citiesFilterParam);
		/*
		 * smes = smeFilterService.applyFilter(categoriesFilterParam,
		 * citiesFilterParam); smes.forEach(sme -> {
		 * smeList.add(mapper.convertToDto(sme, SMEInformationVo.class));
		 * 
		 * }); data.put("filter", filter); data.put("data", smeList);
		 */
		return ResponseEntity.ok(filter);
	}

}
