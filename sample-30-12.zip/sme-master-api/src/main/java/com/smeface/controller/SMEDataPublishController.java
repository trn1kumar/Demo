package com.smeface.controller;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smeface.constants.SMEMasterConstants;
import com.smeface.constants.UrlMapping;
import com.smeface.constants.SMEMasterConstants.RoleAccess;
import com.smeface.exception.CustomException;
import com.smeface.model.PublishData;
import com.smeface.service.DataPublishService;

@RestController
@CrossOrigin("*")
@RequestMapping(UrlMapping.BASE_URL)
public class SMEDataPublishController {

	@Autowired
	DataPublishService publishService;

	@PutMapping(UrlMapping.SMEDataPublishController.UPDATE_INFO)
	@PreAuthorize(RoleAccess.ADMIN)
	public ResponseEntity<?> activeOrDeactiveSMEData(@RequestBody Set<PublishData> publishData,
			@PathVariable String source) {

		switch (source) {
		case SMEMasterConstants.CERTIFICATES:
			publishData.forEach(data -> publishService.updateCerificate(data));
			break;
		case SMEMasterConstants.INFRASTRUCTURES:
			 publishService.updateInfrastructure(publishData);
			break;
		case SMEMasterConstants.GALLERIES:
			publishData.forEach(data -> publishService.updateGallery(data));
			break;
		case SMEMasterConstants.TEAMS:
			publishData.forEach(data -> publishService.updateManagementTeam(data));
			break;
		default:
			throw new CustomException("Unable to update.", HttpStatus.BAD_REQUEST);
		}
		return ResponseEntity.ok().build();
	}

}
