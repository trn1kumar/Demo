package com.smeface.controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.smeface.constants.UrlMapping;
import com.smeface.constants.SMEMasterConstants;
import com.smeface.constants.SMEMasterConstants.SMEFileDirectory;
import com.smeface.entities.Image;
import com.smeface.entities.SMEInformation;
import com.smeface.exception.CustomException;
import com.smeface.rest.ContentServerEndpoint;
import com.smeface.service.FileService;
import com.smeface.service.SMEService;

@RestController
@CrossOrigin(origins = "*")
@SuppressWarnings("unused")
@RequestMapping(UrlMapping.BASE_URL)
public class FileController {

	@Autowired
	private SMEService smeService;

	@Autowired
	ContentServerEndpoint contentServerEndpoint;

	@Autowired
	FileService fileService;

	@PostMapping(UrlMapping.SMEController.SAVE_IMAGES)
	public ResponseEntity<?> uploadImages(@RequestParam(value = "images") MultipartFile[] files,
			@PathVariable String sUuid, @RequestParam String p) throws IllegalArgumentException, IOException {

		List<Image> images = null;
		String fileLocation = null;

		switch (p) {

		case SMEMasterConstants.CERTIFICATES:
			fileLocation = SMEFileDirectory.SME_CERTIFICATE.replace("{sUuid}", sUuid);
			break;
		case SMEMasterConstants.GALLERIES:
			fileLocation = SMEFileDirectory.SME_GALLERY.replace("{sUuid}", sUuid);
			break;
		case SMEMasterConstants.INFRASTRUCTURES:
			fileLocation = SMEFileDirectory.SME_INFRASTRUCTURE.replace("{sUuid}", sUuid);
			break;
		case SMEMasterConstants.TEAMS:
			fileLocation = SMEFileDirectory.SME_MANAGEMENT_TEAM.replace("{sUuid}", sUuid);
			break;
		}
		if (fileLocation != null)
			images = fileService.sendFilesToContentServer(Arrays.asList(files), fileLocation);

		return ResponseEntity.ok(images);

	}

	@PostMapping(UrlMapping.FileController.CHANGE_LOGO_IMAGE)
	public ResponseEntity<?> changeLogoImage(
			@RequestParam(value = "logoImage", required = false) MultipartFile logoImage, @PathVariable String sUuid)
			throws CustomException {

		SMEInformation sme = null;
		List<Image> images = null;
		String newLogoImage = null;
		try {
			if (logoImage == null) {
				throw new CustomException("logo image required", HttpStatus.NOT_ACCEPTABLE);
			}

			sme = smeService.getSME(sUuid).get();

			try {
				images = fileService.sendFilesToContentServer(Arrays.asList(logoImage),
						SMEFileDirectory.SME.replace("{sUuid}", sUuid));

			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			newLogoImage = images.get(0).getImageLocation();

			if (!StringUtils.isEmpty(sme.getLogoImage())) {
				try {
					contentServerEndpoint.deleteFileFromContentServer(sme.getLogoImage());
				} catch (IOException e) {
					e.printStackTrace();
				} catch (CustomException e) {
					e.printStackTrace();
				}
			}
			sme.setLogoImage(newLogoImage);
			smeService.save(sme);

		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

		return new ResponseEntity<>(HttpStatus.OK);
	}

	@PostMapping(UrlMapping.FileController.UPLOAD_HOME_SLIDER_IMAGE)
	public ResponseEntity<?> smeHomeSliderImage(
			@RequestParam(value = "sliderImages", required = false) MultipartFile[] sliderImages,
			@PathVariable String sUuid) throws CustomException {

		SMEInformation sme = null;
		List<Image> homeSliderImages = null;
		List<Image> existHomeSliderImages = null;
		try {
			if (sliderImages != null && sliderImages.length > 0) {
				sme = smeService.getSME(sUuid).get();
				try {
					homeSliderImages = fileService.sendFilesToContentServer(Arrays.asList(sliderImages),
							SMEFileDirectory.SME_HOME_SLIDER.replace("{sUuid}", sUuid));
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			} else {
				throw new CustomException("sliderImages required", HttpStatus.NOT_ACCEPTABLE);
			}

			existHomeSliderImages = sme.getHomeSliderImages();
			if (existHomeSliderImages != null && existHomeSliderImages.size() > 0) {

				existHomeSliderImages.forEach(img -> {
					try {
						contentServerEndpoint.deleteFileFromContentServer(img.getImageLocation());
					} catch (IOException e) {
						e.printStackTrace();
					} catch (CustomException e) {
						e.printStackTrace();
					}

				});

			}
			sme.setHomeSliderImages(homeSliderImages);
			smeService.save(sme);

		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

		return ResponseEntity.ok(homeSliderImages);
	}

}
