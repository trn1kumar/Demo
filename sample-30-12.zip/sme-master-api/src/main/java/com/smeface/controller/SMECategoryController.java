package com.smeface.controller;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smeface.constants.UrlMapping;
import com.smeface.entities.SMECategory;
import com.smeface.exception.CustomException;
import com.smeface.mapper.SMEMapper;
import com.smeface.service.SMECategoryService;
import com.smeface.service.SMEFilterService;
import com.smeface.vo.SMECategoryVo;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.BASE_URL)
public class SMECategoryController {

	@Autowired
	private SMEMapper mapper;

	@Autowired
	SMECategoryService smeCategoryService;


	@Autowired
	SMEFilterService smeFilterService;
	
	@GetMapping(UrlMapping.SMECategoryController.CATEGORIES)
	public ResponseEntity<?> getCategories() {
		List<SMECategory> categories = null;
		List<SMECategoryVo> categoriesDto = new ArrayList<>();
		try {
			categories = smeCategoryService.getAllCategories();
			categories.forEach(category -> {
				final int smeCount = category.getSmes().size();
				category.setSmes(null);
				SMECategoryVo categoryDto = mapper.convertToDto(category, SMECategoryVo.class);
				categoryDto.setTotalSmesCount(smeCount);
				categoriesDto.add(categoryDto);
			});
		} catch (CustomException e) {
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ResponseEntity.ok(categoriesDto);
	}
}
