package com.smeface.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smeface.constants.UrlMapping;
import com.smeface.entities.SMEInformation;
import com.smeface.mapper.SMEMapper;
import com.smeface.service.SMESearchService;
import com.smeface.vo.SMEInformationVo;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.BASE_URL)
public class SMESearchController {

	@Autowired
	SMESearchService smeSearchService;

	@Autowired
	SMEMapper mapper;

	public ResponseEntity<?> getSearchResults(@RequestParam(value = "searchText") String searchText) {
		return null;

	}

	@GetMapping("/suggest-search")
	public ResponseEntity<?> getAutoSuggestedResults(@RequestParam(value = "searchText") String searchText,
			@RequestParam(value = "maxResult") int maxResult) {

		List<SMEInformationVo> result = new ArrayList<>();

		List<SMEInformation> searchedSmes = smeSearchService.getSearchResult(searchText, maxResult);

		searchedSmes.forEach(sme -> {
			sme.getSmeAddress().setLocality(null);
			sme.getSmeAddress().setAddrsUuid(null);
			sme.getSmeAddress().setStreet(null);
			sme.getSmeAddress().setPincode(0);
			result.add(mapper.convertToDto(sme, SMEInformationVo.class));
		});

		return ResponseEntity.ok(result);
	}

}
