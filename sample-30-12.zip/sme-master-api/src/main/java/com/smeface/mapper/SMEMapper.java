package com.smeface.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.smeface.dto.AddressDto;
import com.smeface.dto.SMEInformationDto;
import com.smeface.entities.Address;
import com.smeface.entities.SMEInformation;
import com.smeface.exception.CustomException;

import io.jsonwebtoken.lang.Assert;

@Component
public class SMEMapper {

	public <T> T convertToEntity(Object srcObj, Class<T> targetClass) {
		T entity = null;

		try {
			Assert.notNull(srcObj, "source object can not be null for convertion");
			entity = new ModelMapper().map(srcObj, targetClass);
		} catch (IllegalArgumentException e) {
			throw new CustomException(e.getMessage(), HttpStatus.NOT_ACCEPTABLE);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return entity;
	}

	public <T> T convertToDto(Object srcObj, Class<T> targetClass) {
		T dto = null;

		try {
			Assert.notNull(srcObj, "source object can not be null for convertion");
			dto = new ModelMapper().map(srcObj, targetClass);
		} catch (IllegalArgumentException e) {
			throw new CustomException(e.getMessage(), HttpStatus.NOT_ACCEPTABLE);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return dto;
	}

	public SMEInformationDto convertToDtoForSmeList(SMEInformation information) {

		Assert.notNull(information, "class can not be null for convertion");
		AddressDto addressDto = null;

		SMEInformationDto smeDto = new SMEInformationDto();
		smeDto.setsUuid(information.getsUuid());
		smeDto.setSmeName(information.getSmeName());
		smeDto.setLogoImage(information.getLogoImage());
		smeDto.setContactPerson(information.getContactPerson());
		Address address = information.getSmeAddress();
		addressDto = this.convertToAddressVo(address);
		smeDto.setSmeAddress(addressDto);

		return smeDto;
	}

	public AddressDto convertToAddressVo(Address address) {
		if (address != null) {
			address.setStreet(null);
			address.setPincode(0);
			address.setCountry(null);
			return this.convertToDto(address, AddressDto.class);
		}
		return null;
	}

}
