package com.smeface.model;

import java.util.ArrayList;
import java.util.List;

import com.smeface.entities.Image;

public class PublishFeed {

	private String smeUuid;
	private String publishFeedId;
	private String title;
	private String description;
	private List<File> files;
	private final String postType = "infra";
	private final boolean active = false;
	private final String privacy = "public";

	class File {

		private String fileLocation;

		File(String fileLocation) {
			this.fileLocation = fileLocation;
		}

		public String getFileLocation() {
			return fileLocation;
		}

		public void setFileLocation(String fileLocation) {
			this.fileLocation = fileLocation;
		}

	}

	public PublishFeed() {
		super();
	}

	public PublishFeed(String smeUuid, String infraUuid, String machineName, String description, List<Image> files) {
		this.smeUuid = smeUuid;
		this.publishFeedId = infraUuid;
		this.title = machineName;
		this.description = description;
		if (files != null && files.size() > 0) {
			List<File> newFiles = new ArrayList<>();
			files.forEach(file -> {
				newFiles.add(new File(file.getImageLocation()));
			});
			this.setFiles(newFiles);
		}

	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPublishFeedId() {
		return publishFeedId;
	}

	public void setPublishFeedId(String publishFeedId) {
		this.publishFeedId = publishFeedId;
	}

	public String getPrivacy() {
		return privacy;
	}

	public boolean isActive() {
		return active;
	}

	public String getPostType() {
		return postType;
	}

	public List<File> getFiles() {
		return files;
	}

	public void setFiles(List<File> files) {
		this.files = files;
	}

	public String getSmeUuid() {
		return smeUuid;
	}

	public void setSmeUuid(String smeUuid) {
		this.smeUuid = smeUuid;
	}

}
