/*package com.smeface.model;

public class Parameter {

	private String param;
	
	private String smeId;

	public String getParam() {
		return param;
	}

	public void setParam(String param) {
		this.param = param;
	}

	public String getSmeId() {
		return smeId;
	}

	public void setSmeId(String smeId) {
		this.smeId = smeId;
	}
}
*/