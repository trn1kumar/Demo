package com.smeface.model;

public class PublishData {

	private String id;
	private boolean status;
	private boolean businessPost;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public boolean isBusinessPost() {
		return businessPost;
	}

	public void setBusinessPost(boolean businessPost) {
		this.businessPost = businessPost;
	}

}
