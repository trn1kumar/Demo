package com.smeface.model.filter;

public class CategoryFilter {

	private String categoryUuid;
	private String categoryUrl;
	private String categoryName;
	private int totalSmesCount;
	private boolean selected;

	public String getCategoryUuid() {
		return categoryUuid;
	}
	public String getCategoryUrl() {
		return categoryUrl;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public int getTotalSmesCount() {
		return totalSmesCount;
	}
	public void setCategoryUuid(String categoryUuid) {
		this.categoryUuid = categoryUuid;
	}
	public void setCategoryUrl(String categoryUrl) {
		this.categoryUrl = categoryUrl;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public void setTotalSmesCount(int totalSmesCount) {
		this.totalSmesCount = totalSmesCount;
	}
	public boolean isSelected() {
		return selected;
	}
	public void setSelected(boolean selected) {
		this.selected = selected;
	}

}
