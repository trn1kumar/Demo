package com.smeface.model.filter;

public class CityFilter {
	
	String city;
	long totalCount;
	boolean selected;
	public CityFilter(String city, long totalCount) {
		super();
		this.city = city;
		this.totalCount = totalCount;
	}
	public String getCity() {
		return city;
	}
	public long getTotalCount() {
		return totalCount;
	}
	public boolean isSelected() {
		return selected;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public void setTotalCount(long totalCount) {
		this.totalCount = totalCount;
	}
	public void setSelected(boolean selected) {
		this.selected = selected;
	}
	
	
}
