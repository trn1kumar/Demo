package com.smeface.component.presentation;

import java.util.List;

public interface PresentationComponent {

	public <E> List<? extends Object> getPresentationObj(E obj);
}
