package com.smeface.component.filter;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;

import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Query;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.DatabaseRetrievalMethod;
import org.hibernate.search.query.ObjectLookupMethod;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.smeface.entities.SMECategory;
import com.smeface.entities.SMEInformation;

@Component(value="categoryFilter")
public class CategoryFilterComponentImpl implements FilterComponent {

	
	@Autowired
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	//@Cacheable("smes")
	public <T> List<SMEInformation> filter(T categoriesFilterParam,int firstResult,int maxResult) {
		List<SMEInformation> smes = new ArrayList<>();

		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);
		
		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(SMECategory.class).get();
		
		List<Query> queryList = new LinkedList<Query>();
		((Set<String>) categoriesFilterParam).forEach(category->{
			queryList.add(queryBuilder.keyword().onFields("categoryUrl").matching(category).createQuery());
		});
		
		BooleanQuery.Builder booleanQuery = new BooleanQuery.Builder();
		queryList.forEach(q->{
			booleanQuery.add(q, BooleanClause.Occur.SHOULD);
		});
		FullTextQuery fullTextQuery = fullTextEntityManager.createFullTextQuery(booleanQuery.build(), SMECategory.class);
		
		fullTextQuery.setFirstResult(firstResult);
		fullTextQuery.setMaxResults(maxResult);
		
		fullTextQuery.initializeObjectsWith(
			    ObjectLookupMethod.SECOND_LEVEL_CACHE,
			    DatabaseRetrievalMethod.QUERY);
		List<SMECategory> categoryResult = fullTextQuery.getResultList();
		
		categoryResult.forEach(category->smes.addAll(category.getSmes()));

		return smes;

	}
}
