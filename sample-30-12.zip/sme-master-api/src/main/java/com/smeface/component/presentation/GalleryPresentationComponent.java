package com.smeface.component.presentation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.smeface.dto.GalleryPresentationDto;
import com.smeface.entities.Gallery;

@Component(value="gallery")
public class GalleryPresentationComponent implements PresentationComponent {

	@Override
	public <T> List<? extends Object> getPresentationObj(T obj) {
		Gallery gallery = (Gallery) obj;
		
		List<GalleryPresentationDto> galleryDto=new ArrayList<>();
		gallery.getImages().forEach(img -> {
			GalleryPresentationDto glryDto = new GalleryPresentationDto(img.getImageLocation(), null,
					gallery.getGalleryTitle(), img.getImageLocation(), gallery.getDescription());
			glryDto.setCreationDate(gallery.getCreationDate());
			glryDto.setLastModifiedDate(gallery.getLastModifiedDate());
			galleryDto.add(glryDto);
		});
		return galleryDto;
	}

}
