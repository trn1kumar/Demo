package com.smeface.component.filter;

import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Query;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.DatabaseRetrievalMethod;
import org.hibernate.search.query.ObjectLookupMethod;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.smeface.entities.SMEInformation;

@Component
public class GenericFilterComponent {

	@Autowired
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	//@Cacheable("smes")
	public List<SMEInformation> filter(Set<String> categoryFilterParam, Set<String> cityFilterParam,int firstResult,int maxResult) {
		
		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(SMEInformation.class).get();

		List<Query> queryList = new LinkedList<Query>();

		categoryFilterParam.forEach(category -> {
			cityFilterParam.forEach(city -> {
				Query query = queryBuilder.bool()
						.must(queryBuilder.keyword().onFields("smeAddress.city").matching(city).createQuery()).must(queryBuilder
								.keyword().onFields("smeCategory.categoryUrl").matching(category).createQuery())
						.createQuery();

				queryList.add(query);
			});
		});

		BooleanQuery.Builder booleanQuery = new BooleanQuery.Builder();
		queryList.forEach(q->booleanQuery.add(q, BooleanClause.Occur.SHOULD));
		FullTextQuery fullTextQuery = fullTextEntityManager.createFullTextQuery(booleanQuery.build(), SMEInformation.class);
		
		fullTextQuery.setFirstResult(firstResult);
		fullTextQuery.setMaxResults(maxResult);
		
		fullTextQuery.initializeObjectsWith(
			    ObjectLookupMethod.SECOND_LEVEL_CACHE,
			    DatabaseRetrievalMethod.QUERY);
		
		List<SMEInformation> smes = fullTextQuery.getResultList();

		return smes;

	}

}
