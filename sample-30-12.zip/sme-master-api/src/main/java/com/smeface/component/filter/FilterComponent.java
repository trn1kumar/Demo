package com.smeface.component.filter;

import java.util.List;
import com.smeface.entities.SMEInformation;


public interface FilterComponent {

	public <T> List<SMEInformation> filter(T filterParam,int firstResult,int maxResult);
	
}
