package com.smeface.vo;

import com.smeface.dto.AddressDto;

public class SMEInformationVo {
	
	private String smeName;

	private String sUuid;
	
	private String logoImage;
	
	private AddressDto smeAddress;

	public String getSmeName() {
		return smeName;
	}

	public String getsUuid() {
		return sUuid;
	}


	public AddressDto getSmeAddress() {
		return smeAddress;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}


	public void setSmeAddress(AddressDto smeAddress) {
		this.smeAddress = smeAddress;
	}

	public String getLogoImage() {
		return logoImage;
	}

	public void setLogoImage(String logoImage) {
		this.logoImage = logoImage;
	}
	
	
}
