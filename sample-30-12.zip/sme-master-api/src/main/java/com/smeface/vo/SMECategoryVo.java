package com.smeface.vo;

import java.util.List;

public class SMECategoryVo {

	private String categoryUuid;
	private String categoryUrl;
	private String categoryName;
	private int totalSmesCount;
	private List<SMEInformationVo> smes;
	
	
	public String getCategoryUuid() {
		return categoryUuid;
	}
	public String getCategoryUrl() {
		return categoryUrl;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public List<SMEInformationVo> getSmes() {
		return smes;
	}
	public void setCategoryUuid(String categoryUuid) {
		this.categoryUuid = categoryUuid;
	}
	public void setCategoryUrl(String categoryUrl) {
		this.categoryUrl = categoryUrl;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public void setSmes(List<SMEInformationVo> smes) {
		this.smes = smes;
	}
	public int getTotalSmesCount() {
		return totalSmesCount;
	}
	public void setTotalSmesCount(int totalSmesCount) {
		this.totalSmesCount = totalSmesCount;
	}
	
	
	
}
