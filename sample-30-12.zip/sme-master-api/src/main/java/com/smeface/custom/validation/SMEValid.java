package com.smeface.custom.validation;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.smeface.entities.SMEInformation;
import com.smeface.exception.CustomValidation;
import com.smeface.exception.ValidationErrors;

@Component
public class SMEValid {

	public void isValid(SMEInformation sme) {
		ValidationErrors validationError = new ValidationErrors();
		List<String> errors = new ArrayList<String>();

		if (StringUtils.isEmpty(sme.getSmeName())) {
			errors.add("SME Name can not be empty");
		} else if (sme.getSmeName().length() >= 50) {
			errors.add("SME Name should be between 0 to 50");
		}
		if (StringUtils.isEmpty(sme.getContactPhone())) {
			errors.add("Mobile Number cannot be null");
		} else if (!StringUtils.isNumeric(sme.getContactPhone())) {
			errors.add("Enter valid Mobile Number,Only digit are Permit");
		} else if (sme.getContactPhone().length() != 10) {
			errors.add("Mobile Number should be of 10 digits");
		}
		if (StringUtils.isEmpty(sme.getGstin())) {
			errors.add("GSTIN number cannot be Empty");
		} else if (sme.getGstin().length() != 15) {
			errors.add("GSTIN Number should be of 15 digits");
		}
		if (sme.getCompanyDescription() != null
				&& !(sme.getCompanyDescription().length() <= 1000)) {
			errors.add("Company Description should be less than 1000 characters");
		}

		if (errors.size() > 0) {
			validationError.setErrors(errors);
			throw new CustomValidation(validationError);
		}
	}
}
