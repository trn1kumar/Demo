package com.smeface.configuration;

import java.util.Properties;

import javax.annotation.Resource;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import com.smeface.notification.EmailSubscriber;
import com.smeface.rest.BulkSmsEndpoint;

@Configuration
@PropertySource(value = { "classpath:application.properties" })
public class ApplicationConfiguration {

	@Resource
	private Environment environment;
	

	@Bean
	public JavaMailSender getJavaMailSender() {
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		mailSender.setHost(environment.getRequiredProperty("mail.smtp.host"));
		mailSender.setPort(Integer.parseInt(environment.getRequiredProperty("mail.smtp.port").trim()));

		mailSender.setUsername(environment.getRequiredProperty("mail.username"));
		mailSender.setPassword(environment.getRequiredProperty("mail.password"));

		Properties props = mailSender.getJavaMailProperties();
		props.put("mail.transport.protocol", environment.getRequiredProperty("mail.transport.protocol"));
		props.put("mail.smtp.auth", environment.getRequiredProperty("mail.smtp.auth"));
		props.put("mail.smtp.starttls.enable", environment.getRequiredProperty("mail.smtp.starttls.enable"));
		props.put("mail.debug", environment.getRequiredProperty("mail.debug"));

		return mailSender;
	}

	@Bean
	public BulkSmsEndpoint getBulkSmsEndpoint() {
		Client client = ClientBuilder.newClient();
		String smsEndPoint = environment.getRequiredProperty("sms.endpoint");
		String smsUser = environment.getRequiredProperty("sms.user");
		String smsPassword = environment.getRequiredProperty("sms.password");
		String smsGenKey = environment.getRequiredProperty("sms.genkey");
		BulkSmsEndpoint bulkSmsEndpoint = new BulkSmsEndpoint(client, smsEndPoint, smsUser, smsPassword, smsGenKey);
		return bulkSmsEndpoint;
	}

	@Bean
	public EmailSubscriber getEmailSubscriber() {
		String mailSender = environment.getRequiredProperty("mail.username");
		EmailSubscriber emailSubscriber = new EmailSubscriber(mailSender);
		return emailSubscriber;
	}

}
