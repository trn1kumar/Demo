package com.smeface.exceptions;

import java.util.ArrayList;
import java.util.List;


public class ValidationError {

	List<String> errors = new ArrayList<>();

	String errorMessage;
	
	public ValidationError(String errorMessage)
	{
		this.errorMessage = errorMessage;
	}

	public void addValidationError(String defaultMessage) {
		errors.add(defaultMessage);

	}
	
	

}
