package com.smeface.util;

public class Constants {

	public static final String EMAIL_ID_NOT_NULL = "emailId should not be null.";
	public static final String MOBILE_NUMBER_NOT_NULL = "mobile_no should not be null.";
	
}
