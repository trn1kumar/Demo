package com.smeface.rest;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class BulkSmsEndpoint {

	private Client client;
	private String smsUsername;
	private String smsPassword;
	private String genKey;
	private String endPoint;

	Logger log = LogManager.getLogger(BulkSmsEndpoint.class.getName());

	public BulkSmsEndpoint(Client client, String endPoint, String smsUsername, String smsPassword, String genKey) {
		this.client = client;
		this.smsUsername = smsUsername;
		this.smsPassword = smsPassword;
		this.endPoint = endPoint;
		this.genKey = genKey;
	}

	public void callBulkSmsApi(String mobileNumber, String message, String sender) {

		WebTarget webTarget = client.target(endPoint).queryParam("user", smsUsername)
				.queryParam("password", smsPassword).queryParam("sender", sender).queryParam("genkey", genKey)
				.queryParam("number", mobileNumber).queryParam("message", message);
		Response response = webTarget.request().get();
		int responseCode = response.getStatus();
		if (responseCode == 200) {
			String res = response.readEntity(String.class);
			String messageId = res.trim().split("\n")[0];
			log.info("SMS sent with message Id : " + messageId);
		} else {
			log.error("Error sending SMS : Mobile No : " + mobileNumber + " , message : " + message
					+ " . Status code : " + response.getStatusInfo().getStatusCode() + " , Reason : "
					+ response.getStatusInfo().getReasonPhrase());
		}

	}

}
