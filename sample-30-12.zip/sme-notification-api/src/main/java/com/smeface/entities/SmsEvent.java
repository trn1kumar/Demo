package com.smeface.entities;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import com.smeface.notification.aspect.SmefaceLogger;

@Entity(name="SmsNotification")
public class SmsEvent extends Event {


	@Id
	@GeneratedValue
	private long id;
	
	private String mobileNo;
	private String eventMessage;
	private String sender;

	public void acceptLogIntercepter(SmefaceLogger logger) {
		logger.logRequest(this);
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEventMessage() {
		return eventMessage;
	}

	public void setEventMessage(String eventMessage) {
		this.eventMessage = eventMessage;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	@Override
	public String toString() {
		return "SmsEvent [mobileNo=" + mobileNo + ", eventMessage=" + eventMessage + ", sender=" + sender + "]";
	}

}
