package com.smeface.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import com.smeface.notification.aspect.SmefaceLogger;

@Entity(name = "EmailNotification")
public class EmailEvent extends Event {
	@Id
	@GeneratedValue
	private long id;
	private String emailId;
	private String subject;
	private String eventMessage = null;

	public EmailEvent() {
		// TODO Auto-generated constructor stub
	}

	public void acceptLogIntercepter(SmefaceLogger logger) {
		logger.logRequest(this);
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getEventMessage() {
		return eventMessage;
	}

	public void setEventMessage(String eventMessage) {
		this.eventMessage = eventMessage;
	}

	@Override
	public String toString() {
		return "EmailEvent [emailId=" + emailId + ", subject=" + subject + ", eventMessage=" + eventMessage + "]";
	}

}
