package com.smeface.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smeface.entities.EmailEvent;
import com.smeface.jpa.repositories.EmailNotificationRepository;

@Service
public class EmailNotificationService {

	@Autowired
	private EmailNotificationRepository emailNotificationRepository;

	public void saveEmailToDB(EmailEvent emailEvent) {
		emailNotificationRepository.save(emailEvent);
	}

}
