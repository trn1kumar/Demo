package com.smeface.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smeface.entities.SmsEvent;
import com.smeface.jpa.repositories.SmsNotificationRepository;

@Service
public class SmsNotificationService {

	@Autowired
	private SmsNotificationRepository smsNotificationRepository;

	public void saveSmsToDB(SmsEvent smsEvent) {
		smsNotificationRepository.save(smsEvent);

	}

}
