package com.smeface.common.constants;

public interface UrlMapping {
	String ROOTAPI = "/notification";
	String SEND_MAIL = "/mail";
	String SEND_SMS = "/sms";
}
