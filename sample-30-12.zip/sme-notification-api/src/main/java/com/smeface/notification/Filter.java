package com.smeface.notification;

import java.util.HashMap;
import java.util.LinkedList;

public class Filter
{
	private HashMap<EventType, LinkedList<Integer>> eventMap = new HashMap<>();
	
	public void apply(EventType event, int... severity)
	{
		LinkedList<Integer> severeList = new LinkedList<>();
		for (int severe : severity)
		{
			severeList.add(severe);
		}
		
		if (eventMap.get(event) != null)
		{
	
			
			eventMap.replace(event, severeList);
		}
		eventMap.put(event, severeList);
	}

	public HashMap<EventType, LinkedList<Integer>> getEventMap()
	{
		return eventMap;
	}

	public void setEventMap(HashMap<EventType, LinkedList<Integer>> eventMap)
	{
		this.eventMap = eventMap;
	}
}
