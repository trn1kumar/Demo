package com.smeface.notification;

public enum EventType
{
	SMSEVENT,
	EMAILEVENT;
}

