package com.smeface.notification.aspect;

import com.smeface.entities.EmailEvent;
import com.smeface.entities.SmsEvent;

public interface SmefaceLogger
{
	public void logRequest(SmsEvent event);
	public void logRequest(EmailEvent event);
}
