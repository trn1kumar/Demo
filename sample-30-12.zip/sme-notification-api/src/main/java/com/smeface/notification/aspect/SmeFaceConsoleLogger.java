package com.smeface.notification.aspect;

import com.smeface.entities.EmailEvent;
import com.smeface.entities.SmsEvent;

public class SmeFaceConsoleLogger implements SmefaceLogger
{

	@Override
	public void logRequest(SmsEvent event)
	{
		System.out.println("Notification sent to: " + event.getMobileNo());		
	}

	@Override
	public void logRequest(EmailEvent event)
	{
		System.out.println("Notification sent to: " + event.getEmailId());		
	}
}
