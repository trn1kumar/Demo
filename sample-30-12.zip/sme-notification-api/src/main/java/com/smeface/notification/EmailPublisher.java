package com.smeface.notification;

import static com.smeface.notification.EventService.EVENTSERVICE;

import org.springframework.stereotype.Service;

import com.smeface.entities.Event;


@Service
public class EmailPublisher extends Publisher
{
	@Override
	public void publish(Event event)
	{
		EVENTSERVICE.publish(event, EventType.EMAILEVENT);
	}
}
