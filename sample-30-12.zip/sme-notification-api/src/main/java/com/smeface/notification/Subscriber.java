package com.smeface.notification;

import com.smeface.entities.Event;

public abstract class Subscriber
{
	protected Filter filter = null;

	public abstract void inform(Event event);
	
	public void setFilter(Filter filter)
	{
		this.filter = filter;
	}
	
	public Filter getFilter()
	{
		return this.filter;
	}
	
	public abstract EventType getSubscriberEventType();
}
