package com.smeface.notification;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import com.smeface.entities.EmailEvent;
import com.smeface.entities.Event;
import com.smeface.service.EmailNotificationService;


public class EmailSubscriber extends Subscriber {

	@Autowired
	JavaMailSender emailSender;

	@Autowired
	EmailNotificationService emailNotificationService;

	
	String mailSender ;
	
	public EmailSubscriber(String mailSender) {
		this.mailSender = mailSender;
	}

	Logger logger = LogManager.getLogger(EmailSubscriber.class.getName());

	@Override
	public void inform(Event event) {
		EmailEvent emailEvent = (EmailEvent) event;
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(emailEvent.getEmailId());
		message.setSubject(emailEvent.getSubject());
		message.setText(emailEvent.getEventMessage());
		message.setFrom(mailSender);
		emailSender.send(message);
		emailNotificationService.saveEmailToDB(emailEvent);
		logger.info("Email : " + emailEvent.getEventMessage() + " sent to " + emailEvent.getEmailId());
	}

	public EventType getSubscriberEventType() {
		return EventType.EMAILEVENT;
	}
}
