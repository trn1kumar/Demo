package com.smeface.notification;

import com.smeface.entities.Event;

public abstract class Publisher
{
	public abstract void publish(Event event);
}
