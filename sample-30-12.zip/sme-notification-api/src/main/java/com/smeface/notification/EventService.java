package com.smeface.notification;

import java.util.ArrayList;

import com.smeface.entities.Event;

public enum EventService {
	EVENTSERVICE;

	private ArrayList<Subscriber> subscriberList = new ArrayList<>();

	public void publish(Event event, EventType eventType) {
		for (Subscriber subscriber : subscriberList) {
			if (subscriber.getFilter().getEventMap().containsKey(eventType)
					&& subscriber.getFilter().getEventMap().get(eventType).contains(event.getSeverity())) {
				subscriber.inform(event);
			}
		}
	}

	@SuppressWarnings({ "rawtypes" })
	public void subscribe(Subscriber subscriber, Class... eventType) throws InvalidEventException {
		for (Class event : eventType) {
			if (!Event.class.isAssignableFrom(event)) {
				throw new InvalidEventException("Wrong event type selected, couldn't subscribe");
			}
		}

		subscriberList.add(subscriber);
	}

	@SuppressWarnings({ "rawtypes" })
	public void unsubscribe(Subscriber subscriber, Class... eventType) throws InvalidEventException {
		for (Class event : eventType) {
			if (!Event.class.isAssignableFrom(event)) {
				throw new InvalidEventException("Wrong event type selected, couldn't un-subscribe");
			}
		}
		subscriberList.remove(subscriber);
	}
}
