package com.smeface.notification;

public class InvalidEventException extends Exception
{
	private static final long serialVersionUID = 1L;
	private String message;
	
	public InvalidEventException(String message)
	{
		this.message = message;
	}
	
	
	@Override
	public String getMessage()
	{
		return this.message;
	}
}
