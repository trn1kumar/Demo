package com.smeface.notification;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smeface.entities.Event;
import com.smeface.entities.SmsEvent;
import com.smeface.rest.BulkSmsEndpoint;
import com.smeface.service.SmsNotificationService;

@Service
public class SmsSubscriber extends Subscriber {
	@Autowired
	SmsNotificationService smsNotificationService;

	@Autowired
	BulkSmsEndpoint bulkSmsEndpoint;

	Logger log = LogManager.getLogger(SmsSubscriber.class.getName());

	@Override
	public void inform(Event event) {
		SmsEvent smsEvent = (SmsEvent) event;
		bulkSmsEndpoint.callBulkSmsApi(smsEvent.getMobileNo(), smsEvent.getEventMessage(), smsEvent.getSender());
		smsNotificationService.saveSmsToDB(smsEvent);
		log.info("SMS : " + smsEvent.getEventMessage() + " sent to " + smsEvent.getMobileNo());
	}

	public EventType getSubscriberEventType() {
		return EventType.SMSEVENT;
	}
}
