package com.smeface.controller;

import static com.smeface.notification.EventService.EVENTSERVICE;

import javax.annotation.PostConstruct;
import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.smeface.common.constants.UrlMapping;
import com.smeface.entities.EmailEvent;
import com.smeface.entities.Event;
import com.smeface.entities.SmsEvent;
import com.smeface.exceptions.ValidationError;
import com.smeface.notification.EmailPublisher;
import com.smeface.notification.EmailSubscriber;
import com.smeface.notification.EventType;
import com.smeface.notification.Filter;
import com.smeface.notification.InvalidEventException;
import com.smeface.notification.SmsPublisher;
import com.smeface.notification.SmsSubscriber;

@RestController
@RequestMapping(value = UrlMapping.ROOTAPI)
public class NotificationController {

	@Autowired
	private SmsPublisher smsPublisher;

	@Autowired
	private EmailPublisher emailPublisher;

	@Autowired
	private SmsSubscriber smsSubscriber;

	@Autowired
	private EmailSubscriber emailSubscriber;

	@Value("${sms.sender}")
	private String sender;

	Logger log = LogManager.getLogger(NotificationController.class.getName());

	@PostConstruct
	public void intializeApplication() {
		log.info("Initalizing Application..........");
		Filter filter = new Filter();
		filter.apply(EventType.SMSEVENT, Event.LOW, Event.AVERAGE, Event.CRITICAL);

		smsSubscriber.setFilter(filter);

		Filter filter1 = new Filter();
		filter1.apply(EventType.EMAILEVENT, Event.LOW, Event.CRITICAL);

		emailSubscriber.setFilter(filter1);

		try {
			EVENTSERVICE.subscribe(smsSubscriber, SmsEvent.class);
			EVENTSERVICE.subscribe(emailSubscriber, EmailEvent.class);
		} catch (InvalidEventException e) {
			log.error("Exception thrown: " + e.getLocalizedMessage(), e);
		}
		log.info("Application Initialized.");

	}

	@RequestMapping(value = UrlMapping.SEND_MAIL, method = RequestMethod.POST)
	public ResponseEntity<?> sendMail(@RequestBody @Valid EmailEvent emailEvent, Errors errors) {
		log.info("Request received for sending mail : " + emailEvent.toString());
		if (errors.hasErrors()) {
			return handleErrors(errors);
		}

		emailPublisher.publish(emailEvent);

		return ResponseEntity.ok("Mail sent.");

	}

	@RequestMapping(value = UrlMapping.SEND_SMS, method = RequestMethod.POST)
	public ResponseEntity<?> sendSMS(@RequestBody final SmsEvent smsEvent, Errors errors) {
		log.info("Request received for sending sms : " + smsEvent.toString());

		if (errors.hasErrors()) {
			return handleErrors(errors);
		}
		smsEvent.setSender(sender);
		smsPublisher.publish(smsEvent);

		return ResponseEntity.ok("SMS sent.");
	}

	private ResponseEntity<?> handleErrors(Errors errors) {
		ValidationError error = new ValidationError("Validation failed. " + errors.getErrorCount() + " error(s)");
		for (ObjectError objectError : errors.getAllErrors()) {

			error.addValidationError(objectError.getDefaultMessage());
		}
		return ResponseEntity.badRequest().body(error);

	}

}
