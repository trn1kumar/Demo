package com.smeface.jpa.repositories;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smeface.entities.EmailEvent;

@Transactional
public interface EmailNotificationRepository extends JpaRepository<EmailEvent, Long> {

}
