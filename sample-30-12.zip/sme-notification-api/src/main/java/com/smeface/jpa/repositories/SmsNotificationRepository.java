package com.smeface.jpa.repositories;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smeface.entities.SmsEvent;

@Transactional
public interface SmsNotificationRepository extends JpaRepository<SmsEvent, Long> {

}
