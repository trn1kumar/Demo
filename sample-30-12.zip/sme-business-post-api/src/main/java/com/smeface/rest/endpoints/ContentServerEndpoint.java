package com.smeface.rest.endpoints;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.glassfish.jersey.media.multipart.MultiPart;
import org.glassfish.jersey.media.multipart.file.FileDataBodyPart;
import org.springframework.http.HttpStatus;
import org.springframework.web.multipart.MultipartFile;

import com.smeface.exception.CustomException;
import com.smeface.model.UploadFileResponse;

public class ContentServerEndpoint {

	private Client client;
	private String contentServerEndPoint;
	private String uploadMultipleFile;
	private String deleteFile;

	Logger log = LogManager.getLogger(ContentServerEndpoint.class.getName());

	public ContentServerEndpoint(Client client, String contentServerEndPoint, String uploadMultipleFile,
			String deleteFile) {
		this.client = client;
		this.contentServerEndPoint = contentServerEndPoint;
		this.uploadMultipleFile = uploadMultipleFile;
		this.deleteFile = deleteFile;
	}

	public List<UploadFileResponse> sendFilesToContentServer(List<MultipartFile> multipartFiles, List<String> name,
			String location) throws IllegalArgumentException, IOException {

		Response response = null;
		MultiPart multiPart = null;
		List<File> files = null;
		int i = 0;

		WebTarget webTarget = client.target(contentServerEndPoint).path(uploadMultipleFile).path(location);
		multiPart = new MultiPart();
		multiPart.setMediaType(MediaType.MULTIPART_FORM_DATA_TYPE);
		files = new ArrayList<>();
		for (MultipartFile file : multipartFiles) {
			File tmpfile = convert(file, name.get(i++));
			FileDataBodyPart fileDataBodyPart = new FileDataBodyPart("files", tmpfile,
					MediaType.APPLICATION_OCTET_STREAM_TYPE);
			multiPart.bodyPart(fileDataBodyPart);
			files.add(tmpfile);
		}
		try {
			response = webTarget.request(MediaType.APPLICATION_JSON_TYPE)
					.post(Entity.entity(multiPart, multiPart.getMediaType()));
		} catch (Exception e) {
			for (File file : files) {
				file.delete();
			}
			throw new CustomException(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		log.info("Response: "+response);
		Integer responseCode = response.getStatus();
		if (responseCode != HttpStatus.OK.value()) {
			for (File file : files) {
				file.delete();
			}
			throw new CustomException("Problem for upload image to content server", HttpStatus.CONFLICT);
		}

		for (File file : files) {
			file.delete();
		}

		@SuppressWarnings("unused")
		List<UploadFileResponse> fileDetails = response.readEntity(new GenericType<List<UploadFileResponse>>() {
		});

		return fileDetails;

	}

	public File convert(MultipartFile file, String name) throws IOException {

		File convFile = new File(name);
		convFile.createNewFile();
		FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(file.getBytes());
		fos.close();
		return convFile;
	}

	public void deleteFileFromContentServer(String fileLocation) throws IOException {

		Response response = null;
		Client client = ClientBuilder.newClient();
		try {
			response = client.target(contentServerEndPoint).path(deleteFile).path(fileLocation)
					.request(MediaType.APPLICATION_JSON).delete();
		} catch (Exception e) {
			e.printStackTrace();
			//throw new CustomException(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		Integer responseCode = response.getStatus();

		/*if (responseCode != HttpStatus.OK.value()) {
			throw new CustomException("Problem for delete image from content server", HttpStatus.CONFLICT);
		}*/

	}

}
