package com.smeface.rest.endpoints;

import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.client.Client;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.http.HttpStatus;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.smeface.constants.BusinessPostConstants.RestEndpoint;
import com.smeface.dto.BusinessConnection;
import com.smeface.exception.CustomException;


public class SMECircleEndPoint {
	
	

	private Client client;
	private String smeCircleEndPoint;
	private String connectionsPath;

	public SMECircleEndPoint(Client client, String smeCircleEndPoint, String connectionsPath) {
		super();
		this.client = client;
		this.smeCircleEndPoint = smeCircleEndPoint;
		this.connectionsPath = connectionsPath;
	}

	public Set<BusinessConnection> getBusinessConnection(String sUuid) {
		
		HttpServletRequest curRequest = 
				((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
				.getRequest();
		
		Response response = client.target(smeCircleEndPoint).path(connectionsPath.replace("{smeId}", sUuid)).queryParam(RestEndpoint.paramKey,RestEndpoint.paramValue)
				.request(MediaType.APPLICATION_JSON).header(RestEndpoint.headerKey, curRequest.getHeader(RestEndpoint.headerKey)).get();

		Set<BusinessConnection> businessConnection = null;
		Integer responseCode = response.getStatus();

		if (responseCode == HttpStatus.OK.value()) {
			businessConnection = response.readEntity(new GenericType<Set<BusinessConnection>>() {
			});

			return businessConnection;

		} else if (responseCode == HttpStatus.NOT_FOUND.value()) {
			throw new CustomException("No Connections Available", HttpStatus.NOT_FOUND);

		} else {
			throw new CustomException("Internal Exception occrurred to connect circle service,Invalid Response: "
					+ response.getStatusInfo().getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
