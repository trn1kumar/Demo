package com.smeface.rest.endpoints;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.http.HttpStatus;

import com.smeface.dto.SMEDto;
import com.smeface.exception.CustomException;

public class SmeInformationEndPoint {

	private Client client;
	private String smeInformationEndPoint;
	private String listAllSme;
	private String listSme;

	public SmeInformationEndPoint(Client client, String smeInformationEndPoint, String listAllSme, String listSme) {
		this.client = client;
		this.smeInformationEndPoint = smeInformationEndPoint;
		this.listAllSme = listAllSme;
		this.listSme = listSme;
	}

	public List<SMEDto> getAllSME() {
		Response response = client.target(smeInformationEndPoint).path(listAllSme).request(MediaType.APPLICATION_JSON)
				.get();

		List<SMEDto> smeDto = null;
		Integer responseCode = response.getStatus();

		if (responseCode == HttpStatus.OK.value()) {
			smeDto = response.readEntity(new GenericType<List<SMEDto>>() {
			});

			return smeDto;

		} else if (responseCode == HttpStatus.NOT_FOUND.value()) {
			throw new CustomException("SME's Not Available", HttpStatus.NOT_FOUND);

		} else {
			throw new CustomException("Internal Exception occrurred while fetching product,Invalid Response: "
					+ response.getStatusInfo().getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public SMEDto getSME(String smeId) {

		Response response = client.target(smeInformationEndPoint).path(listSme.replace("{smeId}", smeId))
				.request(MediaType.APPLICATION_JSON).get();

		SMEDto smeDto = null;
		Integer responseCode = response.getStatus();

		if (responseCode == HttpStatus.OK.value()) {
			smeDto = response.readEntity(new GenericType<SMEDto>() {
			});
			return smeDto;

		} else if (responseCode == HttpStatus.NOT_FOUND.value()) {
			throw new CustomException("SME Not Available with id " + smeId, HttpStatus.NOT_FOUND);

		} else {
			throw new CustomException(
					"smeInformationEndPoint Internal Exception occrurred while fetching sme info ,Invalid Response: "
							+ response.getStatusInfo().getReasonPhrase(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
