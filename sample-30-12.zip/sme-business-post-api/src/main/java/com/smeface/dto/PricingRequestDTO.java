package com.smeface.dto;

public class PricingRequestDTO {

	private String userUUID;
	private String sUuid;
	private String uuid;
	private String plan;
	private String type;
	private String action;
	private int credits;
	public String getUserUUID() {
		return userUUID;
	}
	public String getsUuid() {
		return sUuid;
	}
	public String getUuid() {
		return uuid;
	}
	public String getPlan() {
		return plan;
	}
	public String getType() {
		return type;
	}
	public String getAction() {
		return action;
	}
	public int getCredits() {
		return credits;
	}
	public void setUserUUID(String userUUID) {
		this.userUUID = userUUID;
	}
	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public void setPlan(String plan) {
		this.plan = plan;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public void setCredits(int credits) {
		this.credits = credits;
	}
}
