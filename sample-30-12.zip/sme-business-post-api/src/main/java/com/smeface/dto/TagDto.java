package com.smeface.dto;


import java.util.Set;

public class TagDto {

	private String smeId;
	
	private SMEDto smeInfo;

	private Set<SMEBusinessPostDto> taggedPosts;

	public String getSmeId() {
		return smeId;
	}

	public void setSmeId(String smeId) {
		this.smeId = smeId;
	}

	public Set<SMEBusinessPostDto> getTaggedPosts() {
		return taggedPosts;
	}

	public void setTaggedPosts(Set<SMEBusinessPostDto> taggedPosts) {
		this.taggedPosts = taggedPosts;
	}

	public SMEDto getSmeInfo() {
		return smeInfo;
	}

	public void setSmeInfo(SMEDto smeInfo) {
		this.smeInfo = smeInfo;
	}

	

}
