package com.smeface.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BusinessConnection {
	
	private String mySmeConnectionId;

	public String getMySmeConnectionId() {
		return mySmeConnectionId;
	}

	public void setMySmeConnectionId(String mySmeConnectionId) {
		this.mySmeConnectionId = mySmeConnectionId;
	}

	
	
	
}
