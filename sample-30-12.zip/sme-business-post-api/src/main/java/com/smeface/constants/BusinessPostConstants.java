package com.smeface.constants;

public interface BusinessPostConstants {
	
	interface FileDirectory{
		public String FILE_DIR="sme/{sUuid}/business-posts";
	}

	interface RestEndpoint {
		public String paramValue = "business-post";
		public String paramKey = "s";
		public String headerKey = "Authorization";
	}

	interface Privacy {
		String CIRCLE = "circle";
		String PRIVATE = "private";
		String PUBLIC = "public";

	}
}
