package com.smeface.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.smeface.entity.File;

public interface FileRepository extends MongoRepository<File, String>{

}
