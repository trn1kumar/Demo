package com.smeface.repository;

public interface CustomRepository {

	public void updatePostStatus(String publishFeeds, boolean status);
}
