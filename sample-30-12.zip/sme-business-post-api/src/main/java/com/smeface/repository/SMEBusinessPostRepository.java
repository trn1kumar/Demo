package com.smeface.repository;

import java.util.Set;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.smeface.entity.SMEBusinessPost;

public interface SMEBusinessPostRepository
		extends MongoRepository<SMEBusinessPost, String>, CustomRepository {

	Set<SMEBusinessPost> findBySmeUuidAndActiveTrue(String smeUuid);

}