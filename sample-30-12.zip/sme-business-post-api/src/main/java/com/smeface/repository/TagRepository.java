package com.smeface.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.smeface.entity.Tag;

public interface TagRepository extends MongoRepository<Tag, String> {

}
