package com.smeface.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;

import com.mongodb.client.result.UpdateResult;
import com.smeface.entity.SMEBusinessPost;
import com.smeface.exception.CustomException;

public class CustomRepositoryImpl implements CustomRepository {

	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public void updatePostStatus(String publishFeeds, boolean status) {
		Query query = new Query(Criteria.where("publishFeedId").is(publishFeeds));
		Update update = new Update();
		update.set("active", status);
		UpdateResult result = mongoTemplate.updateFirst(query, update, SMEBusinessPost.class);

		if (result.getMatchedCount() == 0)
			throw new CustomException("Business Post not found with publish feeds id " + publishFeeds,
					HttpStatus.NOT_FOUND);
	}

}
