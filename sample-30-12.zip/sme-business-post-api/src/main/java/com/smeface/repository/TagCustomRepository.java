package com.smeface.repository;

public interface TagCustomRepository {

}
