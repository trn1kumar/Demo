package com.smeface.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smeface.dto.SMEDto;
import com.smeface.rest.endpoints.SmeInformationEndPoint;

@Service
public class SMEServiceImpl implements SMEService {

	@Autowired
	SmeInformationEndPoint smeInformationEndPoint;

	@Override
	// @Cacheable("sme")
	public SMEDto getSME(String sUuid) {
		return smeInformationEndPoint.getSME(sUuid);
	}

}
