package com.smeface.service;

import com.smeface.dto.SMEDto;

public interface SMEService {

	public SMEDto getSME(String sUuid);

}
