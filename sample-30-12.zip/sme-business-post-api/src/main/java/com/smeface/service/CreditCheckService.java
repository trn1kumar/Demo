package com.smeface.service;

public interface CreditCheckService {

}
