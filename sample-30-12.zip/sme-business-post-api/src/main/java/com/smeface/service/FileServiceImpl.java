package com.smeface.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.smeface.entity.File;
import com.smeface.exception.CustomException;
import com.smeface.model.UploadFileResponse;
import com.smeface.rest.endpoints.ContentServerEndpoint;
import com.smeface.util.RandomNumber;

@Service
public class FileServiceImpl implements FileService {
	
	@Autowired
	ContentServerEndpoint contentServerEndpoint;

	@Override
	public List<File> sendFilesToContentServer(List<MultipartFile> multipartFiles, String fileLocation)
			throws IllegalArgumentException, IOException {

		List<File> files = null;

		List<String> names = new ArrayList<>();
		multipartFiles.forEach(file -> {
			try {
				String imageName = RandomNumber.generate(1000) + file.getOriginalFilename();
				names.add(imageName);

			} catch (CustomException e) {
				e.printStackTrace();
			}
		});

		List<UploadFileResponse> fileDetails = contentServerEndpoint.sendFilesToContentServer(multipartFiles, names,
				fileLocation);

		files = new ArrayList<>();
		for (UploadFileResponse fileDetail : fileDetails) {
			files.add(new File(fileDetail.getFileName(), fileDetail.getFileLocation(), true));
		}

		return files;

	}

	@Override
	public void deleteFileFromContentServer(String fileLocation) throws IOException {
		contentServerEndpoint.deleteFileFromContentServer(fileLocation);
	}
}
