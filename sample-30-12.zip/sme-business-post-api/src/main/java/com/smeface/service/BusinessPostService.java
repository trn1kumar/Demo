package com.smeface.service;

import java.util.List;

import com.smeface.entity.SMEBusinessPost;
import com.smeface.model.PublishData;

public interface BusinessPostService {

	SMEBusinessPost createPost(SMEBusinessPost businessPost);
	
	public List<SMEBusinessPost> getPosts(String smeUuid,String smeUuid1);

	SMEBusinessPost updatePost(SMEBusinessPost businessPost);

	void deleteBusinessPost(String feedId);

	SMEBusinessPost getPost(String businessPostId);

	void updateStatus(List<PublishData> publish);
}
