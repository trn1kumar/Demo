package com.smeface.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.smeface.constants.BusinessPostConstants.Privacy;
import com.smeface.dto.BusinessConnection;
import com.smeface.entity.File;
import com.smeface.entity.SMEBusinessPost;
import com.smeface.entity.Tag;
import com.smeface.exception.CustomException;
import com.smeface.model.PublishData;
import com.smeface.repository.FileRepository;

import com.smeface.repository.SMEBusinessPostRepository;
import com.smeface.repository.TagRepository;
import com.smeface.rest.endpoints.ContentServerEndpoint;
import com.smeface.rest.endpoints.SMECircleEndPoint;

@Service
public class BusinessPostServiceImpl implements BusinessPostService {

	@Autowired
	SMEBusinessPostRepository smeBusinessPostRepo;

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	TagRepository tagRepository;

	@Autowired
	FileRepository fileRepository;

	@Autowired
	SMECircleEndPoint smeCircleEndPoint;

	@Autowired
	ContentServerEndpoint contentServerEndpoint;

	@Override
	public SMEBusinessPost createPost(SMEBusinessPost businessPost) {

		List<File> files = businessPost.getFiles();
		if (files != null && files.size() > 0) {
			this.save(files);
		}

		this.save(businessPost);

		if (businessPost.getPrivacy().equals(Privacy.CIRCLE)) {
			Set<String> tags = new HashSet<>();
			Set<BusinessConnection> conns = smeCircleEndPoint.getBusinessConnection(businessPost.getSmeUuid());
			conns.parallelStream().forEach(conn -> tags.add(conn.getMySmeConnectionId()));
			businessPost.setTags(tags);
			this.save(businessPost);
			this.tagPost(businessPost.getBusinessPostId(), tags);

		}
		if (businessPost.getPrivacy().equals(Privacy.PRIVATE)) {
			this.tagPost(businessPost.getBusinessPostId(), businessPost.getTags());

		}

		return businessPost;
	}

	private void tagPost(String postId, Set<String> tags) {

		tags.forEach(tagId -> {
			Optional<Tag> existTag = tagRepository.findById(tagId);
			if (existTag.isPresent()) {
				existTag.get().getTaggedPosts().add(postId);
				this.save(existTag.get());
			} else {
				Set<String> posts = new HashSet<>();
				posts.add(postId);
				this.save(new Tag(tagId, posts));
			}
		});
	}

	private SMEBusinessPost save(SMEBusinessPost businessPost) {
		try {
			smeBusinessPostRepo.save(businessPost);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomException("Error while saving post. " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return businessPost;
	}

	private Tag save(Tag tag) {
		try {
			tagRepository.save(tag);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomException("Error while saving tags. " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return tag;
	}

	private void save(List<File> files) {
		try {
			fileRepository.saveAll(files);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void delete(SMEBusinessPost post) {
		try {
			smeBusinessPostRepo.delete(post);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void delete(Tag tag) {
		try {
			tagRepository.delete(tag);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void delete(List<File> files) {
		try {
			fileRepository.deleteAll(files);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public SMEBusinessPost getPost(String postId) {
		Optional<SMEBusinessPost> postOpt = null;

		try {
			postOpt = smeBusinessPostRepo.findById(postId);
			if (!postOpt.isPresent())
				throw new CustomException("Post not present with id " + postId, HttpStatus.NOT_FOUND);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return postOpt.get();
	}

	@Override
	public List<SMEBusinessPost> getPosts(String smeUuid, String smeUuid1) {

		Set<SMEBusinessPost> posts = smeBusinessPostRepo.findBySmeUuidAndActiveTrue(smeUuid);
		try {
			Set<SMEBusinessPost> taggedPosts = this.getTaggedPosts(smeUuid);
			posts.addAll(taggedPosts);
		} catch (CustomException e) {

		}
		if (posts != null && posts.size() > 0) {
			if (smeUuid1 != null)
				posts = filterPostByPrivacy(posts, smeUuid1);

			List<SMEBusinessPost> posts1 = new ArrayList<>(posts);

			if (posts1.isEmpty())
				throw new CustomException("No Posts available for " + smeUuid, HttpStatus.NOT_FOUND);

			Collections.sort(posts1);
			Collections.reverse(posts1);

			return posts1;
		} else
			throw new CustomException("No Posts available for " + smeUuid, HttpStatus.NOT_FOUND);
	}

	private Set<SMEBusinessPost> getTaggedPosts(String smeUuid) {

		Set<SMEBusinessPost> posts = null;

		Tag tag = this.getTag(smeUuid);

		Set<String> taggedPostsId = tag.getTaggedPosts();
		if (taggedPostsId != null && taggedPostsId.size() > 0) {
			posts = new HashSet<>();
			for (String taggedPostId : taggedPostsId) {
				SMEBusinessPost post = this.getPost(taggedPostId);
				posts.add(post);
			}
		}

		return posts;
	}

	private Tag getTag(String smeId) {
		Optional<Tag> tagOpt = tagRepository.findById(smeId);
		if (!tagOpt.isPresent()) {
			throw new CustomException("Tag Not Present with id " + smeId, HttpStatus.NOT_FOUND);
		}
		return tagOpt.get();
	}

	private Set<SMEBusinessPost> filterPostByPrivacy(Set<SMEBusinessPost> posts, String smeUuid1) {
		return posts.parallelStream()
				.filter(post -> post.getPrivacy().equals(Privacy.PUBLIC) ? true
						: post.getSmeUuid().equals(smeUuid1) || post.getTags().contains(smeUuid1))
				.collect(Collectors.toSet());
	}

	@Override
	public SMEBusinessPost updatePost(SMEBusinessPost businessPost) {
		if (businessPost.getBusinessPostId() != null) {
			SMEBusinessPost existPost = this.getPost(businessPost.getBusinessPostId());
			businessPost.setCreationDate(existPost.getCreationDate());
			businessPost.setTags(existPost.getTags());
			businessPost.setFiles(existPost.getFiles());
			return this.save(businessPost);
		} else
			throw new CustomException("Unable to Update", HttpStatus.BAD_REQUEST);
	}

	@SuppressWarnings("unused")
	private boolean isPostExist(String postId) {
		return smeBusinessPostRepo.existsById(postId);
	}

	@Override
	public void deleteBusinessPost(String postId) {

		try {
			SMEBusinessPost post = this.getPost(postId);

			List<File> files = post.getFiles();
			if (files != null && files.size() > 0) {

				/*
				 * delete post files
				 */

				files.forEach(file -> {
					try {
						contentServerEndpoint.deleteFileFromContentServer(file.getFileLocation());
					} catch (IOException e) {
						e.printStackTrace();
					}
				});
				this.delete(files);
			}

			if (!post.getPrivacy().equals(Privacy.PUBLIC)) {

				/*
				 * delete tags for that post
				 */
				Set<String> tags = post.getTags();
				if (tags != null && !tags.isEmpty()) {
					tags.forEach(tagId -> {
						Tag tag = this.getTag(tagId);
						tag.getTaggedPosts().remove(postId);
						if (tag.getTaggedPosts().isEmpty())
							this.delete(tag);
						else
							this.save(tag);
					});
				}
			}

			/*
			 * delete post
			 */
			this.delete(post);

		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

	}

	@Override
	public void updateStatus(List<PublishData> publish) {
		publish.forEach(p -> {
			smeBusinessPostRepo.updatePostStatus(p.getId(), p.isStatus());
		});
	}

}
