package com.smeface.common.audit;

import java.util.Date;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Document
public abstract class DateAuditable implements Comparable<DateAuditable> {

	@CreatedDate
	protected Date creationDate;

	@LastModifiedDate
	@JsonIgnore
	protected Date lastModifiedDate;

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	@Override
	public int compareTo(DateAuditable o) {
		return this.getCreationDate().compareTo(o.getCreationDate());
	}

}
