package com.smeface.controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.smeface.constants.BusinessPostConstants.FileDirectory;
import com.smeface.entity.File;
import com.smeface.service.FileService;

@RestController
@CrossOrigin("*")
@RequestMapping("/smeface/business-post")
public class FileController {

	@Autowired
	FileService fileService;

	@PostMapping("{sUuid}/smes/{feedId}/feeds/files")
	public ResponseEntity<?> uploadBusinessPostFiles(@RequestParam(value = "files") MultipartFile[] multipartFiles,
			@PathVariable String sUuid) {

		List<File> images = null;

		try {
			images = fileService.sendFilesToContentServer(Arrays.asList(multipartFiles),
					FileDirectory.FILE_DIR.replace("{sUuid}", sUuid));
		} catch (IllegalArgumentException | IOException e) {
			e.printStackTrace();
		}
		return ResponseEntity.ok(images);
	}

	@DeleteMapping("{fileLocation}/file")
	public ResponseEntity<?> deleteBusinessPostFiles(@PathVariable String fileLocation) {

		try {
			fileService.deleteFileFromContentServer(fileLocation);
		} catch (IllegalArgumentException | IOException e) {
			e.printStackTrace();
		}
		return ResponseEntity.ok().build();
	}
}
