package com.smeface.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smeface.aop.LogArguments;
import com.smeface.dto.SMEBusinessPostDto;
import com.smeface.dto.SMEDto;
import com.smeface.entity.SMEBusinessPost;
import com.smeface.exception.CustomException;
import com.smeface.mapper.BusinessPostMapper;
import com.smeface.model.PublishData;
import com.smeface.service.BusinessPostService;
import com.smeface.service.SMEService;

@RestController
@RequestMapping("/smeface/business-post")
@CrossOrigin("*")
public class BusinessPostController {

	@Autowired
	BusinessPostService businessPostService;

	@Autowired
	BusinessPostMapper businessPostMapper;

	@Autowired
	SMEService smeService;

	@PostMapping("/feed/publish")
	@LogArguments
	public ResponseEntity<?> publish(@RequestBody SMEBusinessPost businessPost) {

		try {
			businessPostService.createPost(businessPost);
		} catch (CustomException e) {
			throw e;
		}

		return ResponseEntity.ok().build();
	}

	@PostMapping("/feed")
	@LogArguments
	public SMEBusinessPostDto createFeed(@RequestBody SMEBusinessPost businessPost) {

		businessPostService.createPost(businessPost);

		SMEBusinessPostDto postDto = businessPostMapper.convertToDto(businessPost, SMEBusinessPostDto.class);
		postDto.setSmeInfo(smeService.getSME(businessPost.getSmeUuid()));
		Set<String> tagsId = businessPost.getTags();

		if (tagsId != null && tagsId.size() > 0) {
			List<SMEDto> tags = new ArrayList<>();
			tagsId.forEach(tagId -> {
				tags.add(smeService.getSME(tagId));
			});
			postDto.setTaggedWith(tags);
		}

		return postDto;
	}

	@PutMapping("/{feedId}/feed")
	public ResponseEntity<?> updateFeed(@RequestBody SMEBusinessPost businessPost) {
		businessPostService.updatePost(businessPost);
		return ResponseEntity.ok().build();
	}

	@DeleteMapping("{feedId}/feed")
	public ResponseEntity<?> deleteFeed(@PathVariable String feedId) {
		businessPostService.deleteBusinessPost(feedId);
		return ResponseEntity.ok().build();
	}

	@GetMapping("/{feedId}/feed")
	public SMEBusinessPostDto getFeed(@PathVariable String feedId) {
		SMEBusinessPost post = businessPostService.getPost(feedId);
		SMEBusinessPostDto postDto = businessPostMapper.convertToDto(post, SMEBusinessPostDto.class);
		return postDto;
	}

	@GetMapping("/{smeUuid}/feeds")
	public ResponseEntity<?> getFeeds(@PathVariable String smeUuid,
			@RequestParam(required = false) String smeUuid1) {

		List<SMEBusinessPost> posts = businessPostService.getPosts(smeUuid, smeUuid1);
		List<SMEBusinessPostDto> postsDto = new ArrayList<>();
		posts.forEach(post -> {

			SMEBusinessPostDto postDto = businessPostMapper.convertToDto(post, SMEBusinessPostDto.class);
			postDto.setSmeInfo(smeService.getSME(post.getSmeUuid()));
			Set<String> tagsId = post.getTags();

			if (tagsId != null && tagsId.size() > 0) {
				List<SMEDto> tags = new ArrayList<>();
				tagsId.forEach(tagId -> {
					tags.add(smeService.getSME(tagId));
				});
				postDto.setTaggedWith(tags);
			}
			postsDto.add(postDto);

		});

		return ResponseEntity.ok(postsDto);
	}

	@PutMapping("/{feedId}/feed/status")
	public ResponseEntity<?> updatePostStatus(@RequestBody List<PublishData> publish) {
		try {
			businessPostService.updateStatus(publish);
		} catch (CustomException e) {
			throw e;
		}
		return ResponseEntity.ok().build();
	}

}
