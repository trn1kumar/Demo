package com.smeface.entity;

import java.util.Set;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="tags")
public class Tag {

	@Id
	private String smeId;

	private int unreadPostsCount = 0;

	Set<String> taggedPosts;

	public Tag() {
		super();
	}

	public Tag(String smeId) {
		super();
		this.smeId = smeId;
	}

	public Tag(String smeId, Set<String> taggedPosts) {
		super();
		this.smeId = smeId;
		this.taggedPosts = taggedPosts;
	}

	public String getSmeId() {
		return smeId;
	}

	public void setSmeId(String smeId) {
		this.smeId = smeId;
	}

	public Set<String> getTaggedPosts() {
		return taggedPosts;
	}

	public void setTaggedPosts(Set<String> taggedPosts) {
		this.taggedPosts = taggedPosts;
	}

	public int getUnreadPostsCount() {
		return unreadPostsCount;
	}

	public void setUnreadPostsCount(int unreadPostsCount) {
		this.unreadPostsCount = unreadPostsCount;
	}

	

}
