package com.smeface.entity;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class PostComment {

	@Id
	private String postCommentId;
	
	private String smeId;
	
	private List<String> comments;

	public String getPostCommentId() {
		return postCommentId;
	}

	public void setPostCommentId(String postCommentId) {
		this.postCommentId = postCommentId;
	}

	public String getSmeId() {
		return smeId;
	}

	public void setSmeId(String smeId) {
		this.smeId = smeId;
	}

	public List<String> getComments() {
		return comments;
	}

	public void setComments(List<String> comments) {
		this.comments = comments;
	}
	
	
}
