package com.smeface.entity;

import java.util.List;
import java.util.Set;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import com.smeface.common.audit.DateAuditable;

@Document(collection = "sme_posts")
public class SMEBusinessPost extends DateAuditable {

	@Id
	private String businessPostId;

	@Indexed
	private String smeUuid;
	
	private String title;

	private String description;

	private String privacy;

	private boolean active = true;

	private String postType = "default";

	@Indexed
	private String publishFeedId;

	@DBRef
	private List<File> files;

	private int postLikeCount;

	private int postCommentCount;

	private Set<String> likes;

	private Set<PostComment> postComments;

	private Set<String> tags;

	public String getBusinessPostId() {
		return businessPostId;
	}

	public void setBusinessPostId(String businessPostId) {
		this.businessPostId = businessPostId;
	}

	public String getSmeUuid() {
		return smeUuid;
	}

	public void setSmeUuid(String smeUuid) {
		this.smeUuid = smeUuid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPrivacy() {
		return privacy;
	}

	public void setPrivacy(String privacy) {
		this.privacy = privacy;
	}

	public Set<String> getTags() {
		return tags;
	}

	public void setTags(Set<String> tags) {
		this.tags = tags;
	}

	public int getPostLikeCount() {
		return postLikeCount;
	}

	public void setPostLikeCount(int postLikeCount) {
		this.postLikeCount = postLikeCount;
	}

	public int getPostCommentCount() {
		return postCommentCount;
	}

	public void setPostCommentCount(int postCommentCount) {
		this.postCommentCount = postCommentCount;
	}

	public Set<PostComment> getPostComments() {
		return postComments;
	}

	public void setPostComments(Set<PostComment> postComments) {
		this.postComments = postComments;
	}

	public Set<String> getLikes() {
		return likes;
	}

	public void setLikes(Set<String> likes) {
		this.likes = likes;
	}

	public List<File> getFiles() {
		return files;
	}

	public void setFiles(List<File> files) {
		this.files = files;
	}

	public String getPublishFeedId() {
		return publishFeedId;
	}

	public void setPublishFeedId(String publishFeedId) {
		this.publishFeedId = publishFeedId;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getPostType() {
		return postType;
	}

	public void setPostType(String postType) {
		this.postType = postType;
	}

}
