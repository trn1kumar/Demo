package com.smeface.model;

public class PublishFeed {
	
	private String sUuid;
	private String publishFeedId;
	private String title;
	private String description;
	private String privacy;
	
	public String getsUuid() {
		return sUuid;
	}
	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPublishFeedId() {
		return publishFeedId;
	}
	public void setPublishFeedId(String publishFeedId) {
		this.publishFeedId = publishFeedId;
	}
	public String getPrivacy() {
		return privacy;
	}
	public void setPrivacy(String privacy) {
		this.privacy = privacy;
	}
	
	
	

}
