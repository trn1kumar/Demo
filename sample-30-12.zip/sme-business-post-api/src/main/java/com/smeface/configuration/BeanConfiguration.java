package com.smeface.configuration;

import javax.annotation.Resource;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.smeface.rest.endpoints.SMECircleEndPoint;
import com.smeface.rest.endpoints.SmeInformationEndPoint;

@Configuration
@PropertySource(value = { "classpath:application.properties" })
public class BeanConfiguration {

	@Resource
	private Environment environment;

	@Bean
	public SmeInformationEndPoint smeInformationConfiguration() {
		Client client = ClientBuilder.newClient();
		String endPoint = environment.getRequiredProperty("sme.endpoint");
		String listAllSme = environment.getRequiredProperty("list.all.sme.path");
		String listSme = environment.getRequiredProperty("list.sme.path");
		SmeInformationEndPoint smeInformationEndPoint = new SmeInformationEndPoint(client, endPoint, listAllSme,
				listSme);
		return smeInformationEndPoint;
	}

	@Bean
	public SMECircleEndPoint smeCircleBeanConfig() {
		Client client = ClientBuilder.newClient();
		String endPoint = environment.getRequiredProperty("sme.circle.endpoint");
		String connectionsPath = environment.getRequiredProperty("sme.connection");

		SMECircleEndPoint smeCircleEndPoint = new SMECircleEndPoint(client, endPoint, connectionsPath);
		return smeCircleEndPoint;
	}
	

}
