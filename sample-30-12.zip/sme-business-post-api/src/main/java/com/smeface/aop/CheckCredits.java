package com.smeface.aop;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.UriComponentsBuilder;

import com.smeface.entity.SMEBusinessPost;
import com.smeface.exception.CustomException;
import com.smeface.model.PricingRequest;
import com.smeface.security.configuration.Constants;

@Aspect
@Configuration
public class CheckCredits {

	@Value("${pricing.server.endpoint}")
	private String url;

	@Value("${pricing.path}")
	private String path;

	@Value("${pricing.update.credits}")
	private String creditsPath;

	@Before("execution(* *.*(..)) && @annotation(auditable) && args(businessPost)")
	public Object beforeMethodExecution(JoinPoint joinPoint, LogArguments auditable, SMEBusinessPost businessPost) {
		final String uri = url + path;

		RestTemplate restTemplate = new RestTemplate();

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpServletRequest curRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
				.getRequest();
		String header = curRequest.getHeader(Constants.HEADER_STRING);
		headers.set(Constants.HEADER_STRING, header);
		try {
			ResponseEntity<String> response = null;
			UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(uri).queryParam("type", "BUSINESS_POST");
			response = restTemplate.exchange(builder.build().toUri(), HttpMethod.GET, new HttpEntity<String>(headers),
					String.class);

			if (response.getStatusCodeValue() == HttpStatus.OK.value()) {
				return true;
			} else {
				throw new CustomException("Error code not matched", HttpStatus.PAYMENT_REQUIRED);
			}
		} catch (CustomException err) {
			throw err;
		} catch (Exception e) {
			throw new CustomException("Payment Required", HttpStatus.PAYMENT_REQUIRED);

		}

	}

	@AfterReturning("execution(* *.*(..)) && @annotation(auditable) && args(businessPost)")
	public Object updateBiCredits(JoinPoint joinPoint, LogArguments auditable, SMEBusinessPost businessPost) {
		final String uri = url + creditsPath;

		PricingRequest pricingRequest = new PricingRequest();
		
		pricingRequest.setType("BUSINESS_POST");
		pricingRequest.setAction("DEBIT");
		pricingRequest.setCredits(1);
		RestTemplate restTemplate = new RestTemplate();

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpServletRequest curRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
				.getRequest();
		String header = curRequest.getHeader(Constants.HEADER_STRING);
		headers.set(Constants.HEADER_STRING, header);
		try {
			ResponseEntity<String> response = null;
			HttpEntity<PricingRequest> requestEntity = new HttpEntity<PricingRequest>(pricingRequest, headers);
			response = restTemplate.exchange(uri, HttpMethod.PUT, requestEntity, String.class);
			if (response.getStatusCodeValue() == HttpStatus.CREATED.value()) {
				return true;
			} else {
				throw new CustomException("Error Occured while updating credits", HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (CustomException err) {
			throw err;
		} catch (Exception e) {
			throw new CustomException("Error Occured at check credit service", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
