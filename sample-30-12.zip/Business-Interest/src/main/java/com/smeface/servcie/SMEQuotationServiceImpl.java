package com.smeface.servcie;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.smeface.cart.constant.BusinessInterestStatus;
import com.smeface.cart.entity.CartItem;
import com.smeface.cart.entity.RecievdBusinessInterest;
import com.smeface.cart.exception.CustomException;
import com.smeface.cart.repository.CartItemRepo;
import com.smeface.cart.repository.RecieveBusinessInterestRepo;
import com.smeface.cart.status.entity.FinalStage;
import com.smeface.cart.status.entity.OrderStatus;

@Service
public class SMEQuotationServiceImpl implements SMEQuotationService {

	@Autowired
	private RecieveBusinessInterestRepo recieveBusinessInterestRepo;

	@Autowired
	private CartItemRepo cartItemRepo;

	@Override
	public void accept(RecievdBusinessInterest recievdBusinessInterest) {
		try {
			RecievdBusinessInterest existingRecievdBusinessInterest = checkStatus(recievdBusinessInterest);
			if (existingRecievdBusinessInterest != null) {
				recievdBusinessInterest.getOrderStatus().getSecondStage()
						.setId(existingRecievdBusinessInterest.getOrderStatus().getSecondStage().getId());
				existingRecievdBusinessInterest.getOrderStatus().setSecondStage(recievdBusinessInterest.getOrderStatus().getSecondStage());
				existingRecievdBusinessInterest.getOrderStatus().getSecondStage()
						.setStepStatus(BusinessInterestStatus.QUOTATION_SENT);
				existingRecievdBusinessInterest.getOrderStatus().setCurrentStatus(BusinessInterestStatus.QUOTATION_STATUS);
				recieveBusinessInterestRepo.save(existingRecievdBusinessInterest);
				if (getUserAction(existingRecievdBusinessInterest) != null) {
					CartItem cartItem = getUserAction(existingRecievdBusinessInterest);
					recievdBusinessInterest.getOrderStatus().getSecondStage()
							.setId(cartItem.getOrderStatus().getSecondStage().getId());
					cartItem.getOrderStatus().setSecondStage(recievdBusinessInterest.getOrderStatus().getSecondStage());
					cartItem.getOrderStatus().getSecondStage().setStepStatus(BusinessInterestStatus.QUOTATION_RECIEVED);
					cartItem.getOrderStatus().setCurrentStatus(BusinessInterestStatus.QUOTATION_STATUS);
					cartItemRepo.saveAndFlush(cartItem);
				}

			}

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}

	}

	@Override
	public void reject(RecievdBusinessInterest recievdBusinessInterest) {
		try {
			RecievdBusinessInterest existingRecievdBusinessInterest = checkStatus(recievdBusinessInterest);
			if (existingRecievdBusinessInterest != null) {

				switch (recievdBusinessInterest.getOrderStatus().getCurrentStatus()) {
				case "Receive":
					recievdBusinessInterest.getOrderStatus().getFirstStage()
							.setId(existingRecievdBusinessInterest.getOrderStatus().getFirstStage().getId());
					existingRecievdBusinessInterest.getOrderStatus()
							.setFirstStage(recievdBusinessInterest.getOrderStatus().getFirstStage());

					existingRecievdBusinessInterest.getOrderStatus().getFirstStage()
							.setStepStatus(BusinessInterestStatus.BI_CLOSED);
					existingRecievdBusinessInterest.getOrderStatus().setCurrentStatus(BusinessInterestStatus.RECIEVED);
					break;
				case "Quotation":
					recievdBusinessInterest.getOrderStatus().getSecondStage()
							.setId(existingRecievdBusinessInterest.getOrderStatus().getSecondStage().getId());
					existingRecievdBusinessInterest.getOrderStatus()
							.setSecondStage(recievdBusinessInterest.getOrderStatus().getSecondStage());

					existingRecievdBusinessInterest.getOrderStatus().getSecondStage()
							.setStepStatus(BusinessInterestStatus.BI_CLOSED);
					existingRecievdBusinessInterest.getOrderStatus()
							.setCurrentStatus(BusinessInterestStatus.QUOTATION_STATUS);
					break;
				case "Purchase Order":
					recievdBusinessInterest.getOrderStatus().getThirdStage()
							.setId(existingRecievdBusinessInterest.getOrderStatus().getThirdStage().getId());
					existingRecievdBusinessInterest.getOrderStatus()
							.setThirdStage(recievdBusinessInterest.getOrderStatus().getThirdStage());

					existingRecievdBusinessInterest.getOrderStatus().getThirdStage()
							.setStepStatus(BusinessInterestStatus.BI_CLOSED);
					existingRecievdBusinessInterest.getOrderStatus()
							.setCurrentStatus(BusinessInterestStatus.PURCHASE_ORDER);
					break;

				}

				recieveBusinessInterestRepo.saveAndFlush(existingRecievdBusinessInterest);

				if (getUserAction(existingRecievdBusinessInterest) != null) {
					CartItem cartItem = getUserAction(existingRecievdBusinessInterest);
					switch (recievdBusinessInterest.getOrderStatus().getCurrentStatus()) {
					case "Receive":
						recievdBusinessInterest.getOrderStatus().getFirstStage()
								.setId(cartItem.getOrderStatus().getFirstStage().getId());
						cartItem.getOrderStatus()
								.setFirstStage(recievdBusinessInterest.getOrderStatus().getFirstStage());

						cartItem.getOrderStatus().getFirstStage().setStepStatus(BusinessInterestStatus.BI_CLOSED);
						cartItem.getOrderStatus().setCurrentStatus(BusinessInterestStatus.SENT);
						break;
					case "Quotation":

						recievdBusinessInterest.getOrderStatus().getSecondStage()
								.setId(cartItem.getOrderStatus().getSecondStage().getId());
						cartItem.getOrderStatus()
								.setSecondStage(recievdBusinessInterest.getOrderStatus().getSecondStage());

						cartItem.getOrderStatus().getSecondStage().setStepStatus(BusinessInterestStatus.BI_CLOSED);
						cartItem.getOrderStatus().setCurrentStatus(BusinessInterestStatus.QUOTATION_STATUS);
						break;
					case "Purchase Order":
						recievdBusinessInterest.getOrderStatus().getThirdStage()
								.setId(cartItem.getOrderStatus().getThirdStage().getId());
						cartItem.getOrderStatus()
								.setThirdStage(recievdBusinessInterest.getOrderStatus().getThirdStage());

						cartItem.getOrderStatus().getThirdStage().setStepStatus(BusinessInterestStatus.BI_CLOSED);
						cartItem.getOrderStatus().setCurrentStatus(BusinessInterestStatus.PURCHASE_ORDER);
						break;

					}

					cartItemRepo.saveAndFlush(cartItem);

				}

			}

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}

	}

	@Override
	public void revise(RecievdBusinessInterest recievdBusinessInterest) {
		try {
			RecievdBusinessInterest existingRecievdBusinessInterest = checkStatus(recievdBusinessInterest);
			if (existingRecievdBusinessInterest != null) {
				switch (recievdBusinessInterest.getOrderStatus().getCurrentStatus()) {

				case "Quotation":
					recievdBusinessInterest.getOrderStatus().getSecondStage()
							.setId(existingRecievdBusinessInterest.getOrderStatus().getSecondStage().getId());
					existingRecievdBusinessInterest.getOrderStatus()
							.setSecondStage(recievdBusinessInterest.getOrderStatus().getSecondStage());

					existingRecievdBusinessInterest.getOrderStatus().getSecondStage()
							.setStepStatus(BusinessInterestStatus.REVISE_QUOTATION_SENT);
					existingRecievdBusinessInterest.getOrderStatus()
							.setCurrentStatus(BusinessInterestStatus.QUOTATION_STATUS);
					break;
				case "Purchase Order":
					recievdBusinessInterest.getOrderStatus().getThirdStage()
							.setId(existingRecievdBusinessInterest.getOrderStatus().getThirdStage().getId());
					existingRecievdBusinessInterest.getOrderStatus()
							.setThirdStage(recievdBusinessInterest.getOrderStatus().getThirdStage());

					existingRecievdBusinessInterest.getOrderStatus().getThirdStage()
							.setStepStatus(BusinessInterestStatus.REVISE_QUOTATION_SENT);
					existingRecievdBusinessInterest.getOrderStatus()
							.setCurrentStatus(BusinessInterestStatus.PURCHASE_ORDER);
					break;

				}

				recieveBusinessInterestRepo.saveAndFlush(existingRecievdBusinessInterest);

				if (getUserAction(existingRecievdBusinessInterest) != null) {
					CartItem cartItem = getUserAction(existingRecievdBusinessInterest);
					switch (recievdBusinessInterest.getOrderStatus().getCurrentStatus()) {

					case "Quotation":

						recievdBusinessInterest.getOrderStatus().getSecondStage()
								.setId(cartItem.getOrderStatus().getSecondStage().getId());
						cartItem.getOrderStatus()
								.setSecondStage(recievdBusinessInterest.getOrderStatus().getSecondStage());

						cartItem.getOrderStatus().getSecondStage()
								.setStepStatus(BusinessInterestStatus.REVISE_QUOTATION_RECIEVED);
						cartItem.getOrderStatus().setCurrentStatus(BusinessInterestStatus.QUOTATION_STATUS);
						break;
					case "Purchase Order":
						recievdBusinessInterest.getOrderStatus().getThirdStage()
								.setId(cartItem.getOrderStatus().getThirdStage().getId());
						cartItem.getOrderStatus()
								.setThirdStage(recievdBusinessInterest.getOrderStatus().getThirdStage());

						cartItem.getOrderStatus().getThirdStage()
								.setStepStatus(BusinessInterestStatus.REVISE_QUOTATION_RECIEVED);
						cartItem.getOrderStatus().setCurrentStatus(BusinessInterestStatus.PURCHASE_ORDER);
						break;

					}

					cartItemRepo.saveAndFlush(cartItem);

				}

			}

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}

	}

	private CartItem getUserAction(RecievdBusinessInterest recievdBusinessInterest) {

		CartItem cartItem = cartItemRepo.findByBusinessInterestUUIDAndUserUUIdAndIsActive(
				recievdBusinessInterest.getBusinessInterestUUID(), recievdBusinessInterest.getUserUUID(), true);
		if (cartItem != null) {
			return cartItem;
		} else {
			return null;
		}

	}

	@Override
	public RecievdBusinessInterest getQuotation(String uuid) {

		try {
			RecievdBusinessInterest recievdBusinessInterest = recieveBusinessInterestRepo.findByUuid(uuid);
			if (recievdBusinessInterest != null) {
				return recievdBusinessInterest;
			} else {
				throw new CustomException("Proudct details mismatch", HttpStatus.CONFLICT);
			}

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}
	}

	@Transactional
	public RecievdBusinessInterest checkStatus(RecievdBusinessInterest recievdBusinessInterest) {
		try {

			RecievdBusinessInterest oldRecievdBusinessInterest = recieveBusinessInterestRepo
					.findByUuid(recievdBusinessInterest.getUuid());
			if (oldRecievdBusinessInterest != null) {

				return oldRecievdBusinessInterest;
			} else {
				throw new CustomException("Recieve interest not found with uuid " + recievdBusinessInterest.getUuid(),
						HttpStatus.NOT_FOUND);
			}
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public void confirmOrder(RecievdBusinessInterest recievdBusinessInterest) {

		try {
			RecievdBusinessInterest existingRecievdBusinessInterest = checkStatus(recievdBusinessInterest);
			if (existingRecievdBusinessInterest != null) {
				recievdBusinessInterest.setOrderStatus(new OrderStatus());
				recievdBusinessInterest.getOrderStatus().setFinalStage(new FinalStage());
				recievdBusinessInterest.getOrderStatus().getFinalStage()
						.setId(existingRecievdBusinessInterest.getOrderStatus().getFirstStage().getId());
				existingRecievdBusinessInterest.getOrderStatus().getFinalStage()
						.setStepStatus(BusinessInterestStatus.PURCHASE_ORDER_ACCEPTED);
				existingRecievdBusinessInterest.getOrderStatus().setCurrentStatus(BusinessInterestStatus.DELIVERED);

				recieveBusinessInterestRepo.saveAndFlush(existingRecievdBusinessInterest);
				if (getUserAction(existingRecievdBusinessInterest) != null) {
					CartItem cartItem = getUserAction(existingRecievdBusinessInterest);
					recievdBusinessInterest.setOrderStatus(new OrderStatus());
					recievdBusinessInterest.getOrderStatus().setFinalStage(new FinalStage());
					recievdBusinessInterest.getOrderStatus().getFinalStage()
							.setId(cartItem.getOrderStatus().getFinalStage().getId());
					cartItem.getOrderStatus().getFinalStage().setStepStatus(BusinessInterestStatus.ORDER_CONFIRMED);
					cartItem.getOrderStatus().setCurrentStatus(BusinessInterestStatus.RECIEVED);
					cartItemRepo.saveAndFlush(cartItem);
				}

			}

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}

	}

}
