package com.smeface.servcie;

import com.smeface.cart.entity.CartItem;

public interface UserQuotationService {

	public void revise(CartItem cartItem);

	public void accept(CartItem cartItem);

	public void reject(CartItem cartItem);

	public CartItem getQuotation(String uuid);
	

}
