package com.smeface.servcie;

import com.smeface.cart.entity.RecievdBusinessInterest;

public interface SMEQuotationService {

	public void accept(RecievdBusinessInterest recievdBusinessInterest);

	public void reject(RecievdBusinessInterest recievdBusinessInterest);

	public void revise(RecievdBusinessInterest recievdBusinessInterest);

	public void confirmOrder(RecievdBusinessInterest recievdBusinessInterest);

	public RecievdBusinessInterest getQuotation(String uuid);

}
