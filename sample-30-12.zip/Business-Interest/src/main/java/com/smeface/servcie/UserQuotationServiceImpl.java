package com.smeface.servcie;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.smeface.cart.constant.BusinessInterestStatus;
import com.smeface.cart.entity.CartItem;
import com.smeface.cart.entity.RecievdBusinessInterest;
import com.smeface.cart.exception.CustomException;
import com.smeface.cart.repository.CartItemRepo;
import com.smeface.cart.repository.RecieveBusinessInterestRepo;

@Service
public class UserQuotationServiceImpl implements UserQuotationService {

	@Autowired
	private CartItemRepo cartItemRepo;

	@Autowired
	private RecieveBusinessInterestRepo recieveBusinessInterestRepo;

	@Override
	public void revise(CartItem cartItem) {
		try {
			CartItem existingCartItem = checkStatus(cartItem.getUuid());
			if (existingCartItem != null) {

				switch (cartItem.getOrderStatus().getCurrentStatus()) {

				case "Quotation":
					cartItem.getOrderStatus().getSecondStage()
							.setId(existingCartItem.getOrderStatus().getSecondStage().getId());
					existingCartItem.getOrderStatus().setSecondStage(cartItem.getOrderStatus().getSecondStage());

					existingCartItem.getOrderStatus().getSecondStage()
							.setStepStatus(BusinessInterestStatus.REVISE_QUOTATION_REQUESTED);
					existingCartItem.getOrderStatus().setCurrentStatus(BusinessInterestStatus.QUOTATION_STATUS);
					break;
				case "Purchase Order":
					cartItem.getOrderStatus().getThirdStage()
							.setId(existingCartItem.getOrderStatus().getThirdStage().getId());
					existingCartItem.getOrderStatus().setThirdStage(cartItem.getOrderStatus().getThirdStage());

					existingCartItem.getOrderStatus().getThirdStage()
							.setStepStatus(BusinessInterestStatus.PURCHASE_ORDER_SENT);
					existingCartItem.getOrderStatus().setCurrentStatus(BusinessInterestStatus.PURCHASE_ORDER);
					break;

				}

				cartItemRepo.saveAndFlush(existingCartItem);

				if (getSmeAction(cartItem) != null) {
					RecievdBusinessInterest recievdBusinessInterest = getSmeAction(cartItem);
					switch (cartItem.getOrderStatus().getCurrentStatus()) {

					case "Quotation":
						cartItem.getOrderStatus().getSecondStage()
								.setId(recievdBusinessInterest.getOrderStatus().getSecondStage().getId());
						recievdBusinessInterest.getOrderStatus()
								.setSecondStage(cartItem.getOrderStatus().getSecondStage());

						recievdBusinessInterest.getOrderStatus().getSecondStage()
								.setStepStatus(BusinessInterestStatus.RECIEVED_REVISE_QUOTATION_REQUEST);
						recievdBusinessInterest.getOrderStatus()
								.setCurrentStatus(BusinessInterestStatus.QUOTATION_STATUS);
						break;
					case "Purchase Order":
						cartItem.getOrderStatus().getThirdStage()
								.setId(recievdBusinessInterest.getOrderStatus().getThirdStage().getId());
						recievdBusinessInterest.getOrderStatus()
								.setThirdStage(cartItem.getOrderStatus().getThirdStage());

						recievdBusinessInterest.getOrderStatus().getThirdStage()
								.setStepStatus(BusinessInterestStatus.PURCHASE_ORDER_RECIEVED);
						recievdBusinessInterest.getOrderStatus()
								.setCurrentStatus(BusinessInterestStatus.PURCHASE_ORDER);
						break;

					}

					recieveBusinessInterestRepo.saveAndFlush(recievdBusinessInterest);

				}
			}

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}

	}

	@Override
	public void reject(CartItem cartItem) {
		try {
			CartItem existingCartItem = checkStatus(cartItem.getUuid());
			if (existingCartItem != null) {

				switch (cartItem.getOrderStatus().getCurrentStatus()) {
				case "Sent":
					cartItem.getOrderStatus().getFirstStage()
							.setId(existingCartItem.getOrderStatus().getFirstStage().getId());
					existingCartItem.getOrderStatus().setFirstStage(cartItem.getOrderStatus().getFirstStage());

					existingCartItem.getOrderStatus().getFirstStage().setStepStatus(BusinessInterestStatus.BI_CLOSED);
					existingCartItem.getOrderStatus().setCurrentStatus(BusinessInterestStatus.SENT);
					break;
				case "Quotation":
					cartItem.getOrderStatus().getSecondStage()
							.setId(existingCartItem.getOrderStatus().getSecondStage().getId());
					existingCartItem.getOrderStatus().setSecondStage(cartItem.getOrderStatus().getSecondStage());

					existingCartItem.getOrderStatus().getSecondStage().setStepStatus(BusinessInterestStatus.BI_CLOSED);
					existingCartItem.getOrderStatus().setCurrentStatus(BusinessInterestStatus.QUOTATION_STATUS);
					break;
				case "Purchase Order":
					cartItem.getOrderStatus().getThirdStage()
							.setId(existingCartItem.getOrderStatus().getThirdStage().getId());
					existingCartItem.getOrderStatus().setThirdStage(cartItem.getOrderStatus().getThirdStage());

					existingCartItem.getOrderStatus().getThirdStage().setStepStatus(BusinessInterestStatus.BI_CLOSED);
					existingCartItem.getOrderStatus().setCurrentStatus(BusinessInterestStatus.PURCHASE_ORDER);
					break;

				}

				cartItemRepo.saveAndFlush(existingCartItem);

				if (getSmeAction(cartItem) != null) {
					RecievdBusinessInterest recievdBusinessInterest = getSmeAction(cartItem);
					switch (cartItem.getOrderStatus().getCurrentStatus()) {
					case "Sent":
						cartItem.getOrderStatus().getFirstStage()
								.setId(recievdBusinessInterest.getOrderStatus().getFirstStage().getId());
						recievdBusinessInterest.getOrderStatus()
								.setFirstStage(cartItem.getOrderStatus().getFirstStage());

						recievdBusinessInterest.getOrderStatus().getFirstStage()
								.setStepStatus(BusinessInterestStatus.BI_CLOSED);
						recievdBusinessInterest.getOrderStatus().setCurrentStatus(BusinessInterestStatus.SENT);
						break;
					case "Quotation":
						cartItem.getOrderStatus().getSecondStage()
								.setId(recievdBusinessInterest.getOrderStatus().getSecondStage().getId());
						recievdBusinessInterest.getOrderStatus()
								.setSecondStage(cartItem.getOrderStatus().getSecondStage());

						recievdBusinessInterest.getOrderStatus().getSecondStage()
								.setStepStatus(BusinessInterestStatus.BI_CLOSED);
						recievdBusinessInterest.getOrderStatus()
								.setCurrentStatus(BusinessInterestStatus.QUOTATION_STATUS);
						break;
					case "Purchase Order":
						cartItem.getOrderStatus().getThirdStage()
								.setId(recievdBusinessInterest.getOrderStatus().getThirdStage().getId());
						recievdBusinessInterest.getOrderStatus()
								.setThirdStage(cartItem.getOrderStatus().getThirdStage());

						recievdBusinessInterest.getOrderStatus().getThirdStage()
								.setStepStatus(BusinessInterestStatus.BI_CLOSED);
						recievdBusinessInterest.getOrderStatus()
								.setCurrentStatus(BusinessInterestStatus.PURCHASE_ORDER);
						break;

					}

					recieveBusinessInterestRepo.saveAndFlush(recievdBusinessInterest);
				}
			}

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}

	}

	private RecievdBusinessInterest getSmeAction(CartItem cartItem) {
		RecievdBusinessInterest recievdBusinessInterest = recieveBusinessInterestRepo.findByUuid(cartItem.getUuid());

		if (recievdBusinessInterest != null) {
			return recievdBusinessInterest;
		} else {
			return null;
		}

	}

	@Override
	public CartItem getQuotation(String uuid) {

		try {

			if (checkStatus(uuid) != null) {
				return checkStatus(uuid);
			} else {
				throw new CustomException("Proudct details mismatch", HttpStatus.CONFLICT);
			}

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}

	}

	@Override
	public void accept(CartItem cartItem) {
		try {
			if (checkStatus(cartItem.getUuid()) != null) {
				CartItem existingCartItem = checkStatus(cartItem.getUuid());

				cartItem.getOrderStatus().getThirdStage()
						.setId(existingCartItem.getOrderStatus().getThirdStage().getId());
				existingCartItem.getOrderStatus().setThirdStage(cartItem.getOrderStatus().getThirdStage());
				existingCartItem.getOrderStatus().getThirdStage()
						.setStepStatus(BusinessInterestStatus.PURCHASE_ORDER_SENT);
				existingCartItem.getOrderStatus().setCurrentStatus(BusinessInterestStatus.PURCHASE_ORDER);

				cartItemRepo.saveAndFlush(existingCartItem);

				if (getSmeAction(existingCartItem) != null) {
					RecievdBusinessInterest recievdBusinessInterest = getSmeAction(existingCartItem);

					cartItem.getOrderStatus().getThirdStage()
							.setId(recievdBusinessInterest.getOrderStatus().getThirdStage().getId());
					recievdBusinessInterest.getOrderStatus().setThirdStage(cartItem.getOrderStatus().getThirdStage());
					recievdBusinessInterest.getOrderStatus().getThirdStage()
							.setStepStatus(BusinessInterestStatus.PURCHASE_ORDER_RECIEVED);
					recievdBusinessInterest.getOrderStatus().setCurrentStatus(BusinessInterestStatus.PURCHASE_ORDER);

					recieveBusinessInterestRepo.saveAndFlush(recievdBusinessInterest);

				}

			}

		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}

	}

	private CartItem checkStatus(String uuid) {
		try {
			CartItem existingCartItem = cartItemRepo.findByUuid(uuid);
			if (existingCartItem != null) {
				return existingCartItem;
			} else {
				throw new CustomException("cart item not found", HttpStatus.NOT_FOUND);
			}
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
