package com.smeface.audit;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.Authentication;

import com.smeface.cart.securityConfiguration.AuthenticationFacade;


public class AuditorAwareImpl implements AuditorAware<String> {

	@Autowired
	AuthenticationFacade authenticationFacade;

	@Override
	public Optional<String> getCurrentAuditor() {

		Authentication authentication = authenticationFacade.getAuthentication();

		if (authentication == null || !authentication.isAuthenticated()) {
			return null;
		}

		return Optional.of(authentication.getName());

	}
}
