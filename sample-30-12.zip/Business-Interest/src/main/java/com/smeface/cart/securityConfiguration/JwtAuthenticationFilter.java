package com.smeface.cart.securityConfiguration;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.filter.OncePerRequestFilter;

import com.smeface.cart.exception.CustomException;


public class JwtAuthenticationFilter extends OncePerRequestFilter {
	
	@Value("${authentication.path}")
	String authenticationPoint;
	
	@Autowired
	private JwtTokenUtil jwtTokenUtil;
	
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		ResponseEntity<String> authResponse = null;
		String header = request.getHeader(Constants.HEADER_STRING);
		logger.info("Request URI "+request.getRequestURI());
		
		if (header != null) {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.set(Constants.HEADER_STRING, header);
			try {
				authResponse = restTemplate.exchange(authenticationPoint, HttpMethod.GET,
						new HttpEntity<String>(httpHeaders), String.class);
			} catch (Exception e) {
				e.printStackTrace();
				throw new CustomException("Invalid Authorization", HttpStatus.UNAUTHORIZED);
			}

			if (HttpStatus.OK == authResponse.getStatusCode()) {
				UsernamePasswordAuthenticationToken authentication = getAuthentication(request);

				SecurityContextHolder.getContext().setAuthentication(authentication);

				}
		}
		
			filterChain.doFilter(request, response);
		

	}

	private UsernamePasswordAuthenticationToken getAuthentication(HttpServletRequest request) {

		String header = request.getHeader(Constants.HEADER_STRING);
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.set(Constants.HEADER_STRING, header);
		String authToken = header.replace(Constants.TOKEN_PREFIX, "");
		if (authToken != null) {
			String user = jwtTokenUtil.getUsernameFromToken(authToken);

			if (user != null) {
				return new UsernamePasswordAuthenticationToken(user, null, new ArrayList<>());
			}
			return null;
		}
		return null;
	}
}

