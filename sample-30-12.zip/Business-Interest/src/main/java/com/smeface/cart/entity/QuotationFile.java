package com.smeface.cart.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "QuotationFile")
public class QuotationFile {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "QuotationID")
	private Long quotationID;

	@Column(name = "UniqueId")
	private String uniqueId;

	@Column(name = "FileName")
	private String fileName;

	@Column(name = "is_active")
	private boolean active;

	@Column(name = "FileLocation")
	private String fileLocation;

	public QuotationFile(String fileName, boolean active) {
		this.fileName = fileName;
		this.active = active;
	}

	public QuotationFile() {

	}

	public QuotationFile(String fileName) {
		this.fileName = fileName;

	}

	public Long getQuotationID() {
		return quotationID;
	}

	public void setQuotationID(Long quotationID) {
		this.quotationID = quotationID;
	}

	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

}
