package com.smeface.cart.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CartDto {

	private String uuid;

	private List<CartItemDTO> cartItem;

	private List<RecievedBusinessInterestDto> recievdBusinessInterests;

	private Integer sentCount;
	
	private Integer receiveCount;

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public List<CartItemDTO> getCartItem() {
		return cartItem;
	}

	public void setCartItem(List<CartItemDTO> cartItem) {
		this.cartItem = cartItem;
	}

	public List<RecievedBusinessInterestDto> getRecievdBusinessInterests() {
		return recievdBusinessInterests;
	}

	public void setRecievdBusinessInterests(List<RecievedBusinessInterestDto> recievdBusinessInterests) {
		this.recievdBusinessInterests = recievdBusinessInterests;
	}

	public Integer getSentCount() {
		return sentCount;
	}

	public void setSentCount(Integer sentCount) {
		this.sentCount = sentCount;
	}

	public Integer getReceiveCount() {
		return receiveCount;
	}

	public void setReceiveCount(Integer receiveCount) {
		this.receiveCount = receiveCount;
	}
	
	
}
