package com.smeface.cart.rest;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.smeface.cart.dto.EmailEvent;
import com.smeface.cart.dto.SmsEvent;


public class NotificationRestEndPoint {

	private Client client;
	private String notificationEndPoint;
	private String smsNotificationPath;
	private String emailEndPointPath;
	Logger log = LogManager.getLogger(NotificationRestEndPoint.class.getName());
	public NotificationRestEndPoint(Client client, String notificationEndPoint, String smsNotificationPath, String emailEndPointPath) {
		
		this.client=client;
		this.notificationEndPoint=notificationEndPoint;
		this.smsNotificationPath=smsNotificationPath;
		this.emailEndPointPath=emailEndPointPath;
	}
	
	public <T> void sendNotification(T t) {

		if (t instanceof SmsEvent) {
			SmsEvent sms = (SmsEvent) t;
			Response response = client.target(notificationEndPoint).path(smsNotificationPath)
					.request(MediaType.APPLICATION_JSON).post(Entity.entity(sms, MediaType.APPLICATION_JSON));

			log.info(response);

		} else if (t instanceof EmailEvent) {
			EmailEvent email = (EmailEvent) t;
			Response response = client.target(notificationEndPoint).path(emailEndPointPath)
					.request(MediaType.APPLICATION_JSON).post(Entity.entity(email, MediaType.APPLICATION_JSON));
			log.info(response);
		}
	}


/*	 Rest Call for Sending an email... 
	 param:  notificationEndPoint="notificationServer Point"
	 param:  smsEndPointPath:sms
	 And Notification Rest URL...
	// Rest Call for Sending SMS...
	public void sendSmsOtp(SmsEvent sms) {
		
		Response response = client.target(notificationEndPoint).path(smsNotificationPath)
				.request(MediaType.APPLICATION_JSON)
				.post(Entity.entity(sms, MediaType.APPLICATION_JSON));
		
		log.info(response);
	}

	 Rest Call for Sending an email... 
	 param:  notificationEndPoint="notificationServer Point"
	 param:  emailEndPointPath:mail
	 And Notification Rest URL...
	 
	public void sendEmailOtp(EmailEvent email) {
	
		Response response = client.target(notificationEndPoint).path(emailEndPointPath)
				.request(MediaType.APPLICATION_JSON)
				.post(Entity.entity(email, MediaType.APPLICATION_JSON));
		log.info(response);
	}

	*/

}
