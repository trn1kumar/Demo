package com.smeface.cart.mapper;

import org.springframework.http.HttpStatus;

import com.smeface.cart.dto.NameMapper;
import com.smeface.cart.dto.ProductDTO;
import com.smeface.cart.dto.SMEServiceDTO;
import com.smeface.cart.exception.CustomException;

public class NameConverter {

	public static <T> NameMapper converter(T obj) {

		if (obj != null) {
			if (obj instanceof ProductDTO) {
				NameMapper setFeild = new NameMapper();
				setFeild.setItemDisplayName(((ProductDTO) obj).getProductDisplayName());
				setFeild.setItemURL(((ProductDTO) obj).getProductName());
				setFeild.setPrice(((ProductDTO) obj).getPrice());
				setFeild.setItemImage(((ProductDTO) obj).getImages().get(0).getFileLocation());
				setFeild.setBusinessInterestUUID(((ProductDTO) obj).getUuid());
				setFeild.setSmeName(((ProductDTO) obj).getSmeName());
				setFeild.setsUuid(((ProductDTO) obj).getsUuid());
				return setFeild;
			} else {
				if (obj instanceof SMEServiceDTO) {
					NameMapper setFeild = new NameMapper();
					setFeild.setItemDisplayName(((SMEServiceDTO) obj).getServiceDisplayName());
					setFeild.setItemURL(((SMEServiceDTO) obj).getServiceUrlName());
					setFeild.setPrice(((SMEServiceDTO) obj).getPriceDetails().getPrice());
					setFeild.setBusinessInterestUUID(((SMEServiceDTO) obj).getServiceUUID());
					setFeild.setItemImage(((SMEServiceDTO) obj).getServiceImages().get(0).getFileLocation());
					setFeild.setSmeName(((SMEServiceDTO) obj).getSmeName());
					setFeild.setsUuid(((SMEServiceDTO) obj).getsUuid());
					return setFeild;
				} else {
					throw new CustomException("Error while converting in Name mapper converter",
							HttpStatus.EXPECTATION_FAILED);
				}
			}
		} else {
			return null;
		}

	}

}
