package com.smeface.cart.exception;

import com.smeface.cart.dto.ProductDTO;

public class NotEnoughBusinessInterestsInStockException extends Exception {

	
	private static final long serialVersionUID = 997858487817953530L;
	 private static final String DEFAULT_MESSAGE = "Not enough products in stock";

	    public NotEnoughBusinessInterestsInStockException() {
	        super(DEFAULT_MESSAGE);
	    }

	    public NotEnoughBusinessInterestsInStockException(ProductDTO product) {
	        super(String.format("Not enough %s products in stock. Only %d left", product.getProductDisplayName()));
	    }

}
