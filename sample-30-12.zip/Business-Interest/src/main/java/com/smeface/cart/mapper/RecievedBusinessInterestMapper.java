package com.smeface.cart.mapper;

public class RecievedBusinessInterestMapper {

}
