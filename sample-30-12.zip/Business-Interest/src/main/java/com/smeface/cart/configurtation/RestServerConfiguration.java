package com.smeface.cart.configurtation;

import javax.annotation.Resource;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.smeface.cart.rest.ContentServerEndpoint;
import com.smeface.cart.rest.NotificationRestEndPoint;
import com.smeface.cart.rest.ProductRestEndPoint;
import com.smeface.cart.rest.ServiceRestEndPoint;
import com.smeface.cart.rest.SmeServerEndpoint;
import com.smeface.cart.rest.UserServerEndpoint;



@Configuration
@PropertySource(value = { "classpath:application.properties" })
public class RestServerConfiguration {

	@Resource
	private Environment environment;
	
	@Bean
	public ContentServerEndpoint contentConfiguration() {
		Client client = ClientBuilder.newBuilder().register(MultiPartFeature.class).build();

		String contentServerEndPoint = environment.getRequiredProperty("contentserver.endpoint");
		String uploadMultipleFiles = environment.getRequiredProperty("files.endpoint.path");
		String deleteFile = environment.getRequiredProperty("deletefiles.endpoint.path");
		ContentServerEndpoint notification = new ContentServerEndpoint(client, contentServerEndPoint,
				uploadMultipleFiles,deleteFile);
		return notification;
	}

	@Bean
	public SmeServerEndpoint smeServerEndpoint() {
		
		Client client = ClientBuilder.newClient();
		String smeEndPointUrl = environment.getRequiredProperty("sme.endpoint");
		String getSmeUser = environment.getRequiredProperty("getsmeuser.path");
		SmeServerEndpoint sme = new SmeServerEndpoint(client, getSmeUser, smeEndPointUrl);
		return sme;
	}
	
	@Bean
	public ProductRestEndPoint productServerEndpoint() {
		
		Client client = ClientBuilder.newClient();
		String productEndPointUrl = environment.getRequiredProperty("product.endpoint");
		String getProductPath = environment.getRequiredProperty("product.path");
		ProductRestEndPoint product = new ProductRestEndPoint(client,getProductPath, productEndPointUrl);
		return product;
	}

	@Bean
	public ServiceRestEndPoint serviceServerEndpoint() {
		
		Client client = ClientBuilder.newClient();
		String productEndPointUrl = environment.getRequiredProperty("service.endpoint");
		String getProductPath = environment.getRequiredProperty("service.path");
		ServiceRestEndPoint product = new ServiceRestEndPoint(client,productEndPointUrl, getProductPath);
		return product;
	}
	@Bean
	public UserServerEndpoint userServerEndpoint() {
		
		Client client = ClientBuilder.newClient();
		String smeEndPointUrl = environment.getRequiredProperty("user.endpoint");
		String getSmeUser = environment.getRequiredProperty("getuser.path");
		UserServerEndpoint user = new UserServerEndpoint(client, getSmeUser, smeEndPointUrl);
		return user;
	}
	
	@Bean
	public NotificationRestEndPoint notificationConfiguration() {
		Client client = ClientBuilder.newClient();
		String notificationEndPoint = environment.getRequiredProperty("notification.endpoint");
		String smsEndPointPath = environment.getRequiredProperty("sms.endpoint.path");
		String emailEndPointPath = environment.getRequiredProperty("email.endpoint.path");
		NotificationRestEndPoint notification = new NotificationRestEndPoint(client, notificationEndPoint, smsEndPointPath,
				emailEndPointPath);
		return notification;
	}

}
