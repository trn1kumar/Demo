package com.smeface.cart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smeface.cart.constant.APIList;
import com.smeface.cart.entity.RecievdBusinessInterest;
import com.smeface.cart.exception.CustomException;
import com.smeface.servcie.SMEQuotationService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = "/smeface/cart/sme")
public class SmeQuotationController {

	@Autowired
	private SMEQuotationService quotationService;

	@PostMapping(value = APIList.smeActionAPI.REVISE)
	public ResponseEntity<?> revise(@RequestBody RecievdBusinessInterest recievdBusinessInterest) {
		try {
			quotationService.revise(recievdBusinessInterest);
			return new ResponseEntity<String>(HttpStatus.OK);
		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}
	}

	@PostMapping(value = APIList.smeActionAPI.REJECT)
	public ResponseEntity<?> reject(@RequestBody RecievdBusinessInterest recievdBusinessInterest) {
		try {
			quotationService.reject(recievdBusinessInterest);
			return new ResponseEntity<String>(HttpStatus.OK);
		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}
	}

	@PostMapping(value = APIList.smeActionAPI.ACCEPT)
	public ResponseEntity<?> accept(@RequestBody RecievdBusinessInterest recievdBusinessInterest) {
		try {
			quotationService.accept(recievdBusinessInterest);
			return new ResponseEntity<String>(HttpStatus.OK);
		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}
	}

	@PostMapping(value = APIList.smeActionAPI.CONFIRM)
	public ResponseEntity<?> confirmOrder(@RequestBody RecievdBusinessInterest recievdBusinessInterest) {
		try {
			quotationService.confirmOrder(recievdBusinessInterest);
			return new ResponseEntity<String>(HttpStatus.OK);
		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}
	}

}
