package com.smeface.cart.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.smeface.cart.entity.MessageCenter;
import com.smeface.cart.entity.QuotationFile;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CartItemDTO {

	private Long smeCartId;

	private ProductDTO products;

	private String status;
	
	private Boolean isActive;
	
	private Long smeID;

	private Long userId;
	
	private MessageCenter messageCenter;
	
	private QuotationFile quotationFiles;
	
	private String businessInterestUUID;
	
	private Boolean businessInterestStages;

	private Double totalAmount;

	public Long getSmeCartId() {
		return smeCartId;
	}

	public void setSmeCartId(Long smeCartId) {
		this.smeCartId = smeCartId;
	}

	public ProductDTO getProducts() {
		return products;
	}

	public void setProducts(ProductDTO products) {
		this.products = products;
	}

	
	
	public MessageCenter getMessageCenter() {
		return messageCenter;
	}

	public void setMessageCenter(MessageCenter messageCenter) {
		this.messageCenter = messageCenter;
	}

	public QuotationFile getQuotationFiles() {
		return quotationFiles;
	}

	public void setQuotationFiles(QuotationFile quotationFiles) {
		this.quotationFiles = quotationFiles;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


	public String getBusinessInterestUUID() {
		return businessInterestUUID;
	}

	public void setBusinessInterestUUID(String businessInterestUUID) {
		this.businessInterestUUID = businessInterestUUID;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Boolean getBusinessInterestStages() {
		return businessInterestStages;
	}

	public void setBusinessInterestStages(Boolean businessInterestStages) {
		this.businessInterestStages = businessInterestStages;
	}


	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Long getSmeID() {
		return smeID;
	}

	public void setSmeID(Long smeID) {
		this.smeID = smeID;
	}

}
