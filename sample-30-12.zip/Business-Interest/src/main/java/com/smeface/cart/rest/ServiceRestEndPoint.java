package com.smeface.cart.rest;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.http.HttpStatus;

import com.smeface.cart.dto.SMEServiceDTO;
import com.smeface.cart.exception.CustomException;

public class ServiceRestEndPoint {
	private Client client;
	private String serviceEndPointUrl;
	private String getServicePath;

	public ServiceRestEndPoint(Client client, String serviceEndPointUrl, String getServicePath) {
		this.getServicePath = getServicePath;
		this.client = client;
		this.serviceEndPointUrl = serviceEndPointUrl;
	}
	
	public SMEServiceDTO getService(String pUuid) {
		
		String path = getServicePath.replace("{serviceUUID}", pUuid);
		 client = ClientBuilder.newClient();
		Response response = client.target(serviceEndPointUrl).path(path)
				.request(MediaType.APPLICATION_JSON).get();

		SMEServiceDTO serviceDTO = null;
		Integer responseCode = response.getStatus();

		if (responseCode == HttpStatus.OK.value()) {
			serviceDTO = response.readEntity(new GenericType<SMEServiceDTO>() {
			});
			return serviceDTO;

		} else if (responseCode == HttpStatus.NOT_FOUND.value()) {
			return null;

		} else {
			throw new CustomException(" Internal Exception occrurred while fetching service,Invalid Response: "+
					response.getStatusInfo().getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
