package com.smeface.cart.rest;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.http.HttpStatus;


import com.smeface.cart.dto.UserDto;
import com.smeface.cart.exception.CustomException;


public class UserServerEndpoint {

	
	private Client client;
	private String smeEndPointUrl;
	private String getUser;

	public UserServerEndpoint(Client client, String getUser, String smeEndPointUrl) {
		this.client = client;
		this.getUser = getUser;
		this.smeEndPointUrl = smeEndPointUrl;
	}
	
	public UserDto getUser(String userId) {
		
		String path = getUser.replace("{uuid}", userId);
		client = ClientBuilder.newClient();
		Response response = client.target(smeEndPointUrl).path(path)
				.request(MediaType.APPLICATION_JSON).get();

		UserDto userDto = null;
		Integer responseCode = response.getStatus();

		if (responseCode == HttpStatus.OK.value()) {
			userDto = response.readEntity(new GenericType<UserDto>() {
			});
			return userDto;

		} else if (responseCode == HttpStatus.NOT_FOUND.value()) {
			throw new CustomException("User not found with id "+ userId,  HttpStatus.NOT_FOUND);

		} else {
			throw new CustomException(" Internal Exception occrurred while fetching product,Invalid Response: "+
					response.getStatusInfo().getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
