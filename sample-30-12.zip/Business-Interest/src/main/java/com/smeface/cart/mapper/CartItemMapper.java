package com.smeface.cart.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import com.smeface.cart.dto.CartItemDTO;
import com.smeface.cart.entity.CartItem;

@Component
public class CartItemMapper {

	public CartItemDTO convertToDto(CartItem cartItem) {
		ModelMapper mapper = new ModelMapper();
		try {
			CartItemDTO cartItemDTO = mapper.map(cartItem, CartItemDTO.class);
			
			
			cartItemDTO.setIsActive(true);
			

			return cartItemDTO;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public CartItem convertToEntity(CartItemDTO cartItemDTO) {
		ModelMapper mapper = new ModelMapper();
		try {
			CartItem cartItem = mapper.map(cartItemDTO, CartItem.class);
			cartItemDTO.setBusinessInterestStages(true);
			return cartItem;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
