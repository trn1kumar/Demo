package com.smeface.cart.status.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.smeface.cart.entity.MessageCenter;
import com.smeface.cart.entity.QuotationFile;

@Entity
@Table(name = "ItemSecondStage")
public class SecondStage {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	@Column(name = "Status")
	private String stepStatus;
	@OneToOne(cascade = CascadeType.ALL)
	private QuotationFile quotationFile;
	@OneToOne(cascade = CascadeType.ALL)
	private MessageCenter messageCenter;
	@Transient
	private String statusName = "Quotation";

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getStatusName() {
		return statusName;
	}

	public String getStepStatus() {
		return stepStatus;
	}

	public void setStepStatus(String stepStatus) {
		this.stepStatus = stepStatus;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

	public QuotationFile getQuotationFile() {
		return quotationFile;
	}

	public void setQuotationFile(QuotationFile quotationFile) {
		this.quotationFile = quotationFile;
	}

	public MessageCenter getMessageCenter() {
		return messageCenter;
	}

	public void setMessageCenter(MessageCenter messageCenter) {
		this.messageCenter = messageCenter;
	}

}