package com.smeface.cart.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.smeface.cart.constant.BusinessInterestStatus;
import com.smeface.cart.dto.NameMapper;
import com.smeface.cart.dto.ProductDTO;
import com.smeface.cart.dto.SMEInformationDto;
import com.smeface.cart.dto.SMEServiceDTO;
import com.smeface.cart.dto.UserDto;
import com.smeface.cart.entity.Cart;
import com.smeface.cart.entity.CartItem;
import com.smeface.cart.entity.RecievdBusinessInterest;
import com.smeface.cart.exception.CustomException;
import com.smeface.cart.mapper.NameConverter;
import com.smeface.cart.model.RecieveBusinessInterestModel;
import com.smeface.cart.repository.CartItemRepo;
import com.smeface.cart.repository.CartRepo;
import com.smeface.cart.repository.RecieveBusinessInterestRepo;
import com.smeface.cart.rest.ProductRestEndPoint;
import com.smeface.cart.rest.ServiceRestEndPoint;
import com.smeface.cart.rest.SmeServerEndpoint;
import com.smeface.cart.rest.UserServerEndpoint;
import com.smeface.cart.status.entity.FinalStage;
import com.smeface.cart.status.entity.FirstStage;
import com.smeface.cart.status.entity.OrderStatus;
import com.smeface.cart.status.entity.SecondStage;
import com.smeface.cart.status.entity.ThirdStage;
import com.smeface.cart.util.UniqueId;

@Service
@Transactional
public class CartItemServiceImpl implements CartItemService {

	@Autowired
	private CartItemRepo cartItemRepo;

	@Autowired
	private CartRepo cartRepo;

	@Autowired
	private RecieveBusinessInterestRepo recieveBusinessInterestRepo;

	@Autowired
	private ProductRestEndPoint productRestEndPoint;

	@Autowired
	private ServiceRestEndPoint serviceRestEndPoint;

	@Autowired
	private UserServerEndpoint userServerEndpoint;

	@Autowired
	private SmeServerEndpoint smeServerEndpoint;

	@Autowired
	private RecieveBusinessInterestModel recieveBusinessInterestModel;

	@Value("${cart.status}")
	private Boolean active;

	@Value("${cart.perpage}")
	private Integer limit;

	@Override
	public synchronized void cart(Cart cartRequest) {

		try {

			cartRequest.setIsActive(true);
			Cart oldCart = cartRepo.findByUserUuid(cartRequest.getUserUuid());
			cartRequest.getCartItem().stream().forEach(a -> {
				if (cartRequest.getCartItem().stream().findAny().get().getProvider().equals("PRODUCT")) {
					a.setCartAttribute(getBusinessInterestDetails(a.getBusinessInterestUUID(), ProductDTO.class));
				} else {
					a.setCartAttribute(getBusinessInterestDetails(a.getBusinessInterestUUID(), SMEServiceDTO.class));
				}
			});
			if (oldCart == null) {

				cartRequest.getCartItem().parallelStream().forEach(u -> {

					u.setIsActive(active);
					u.setOrderStatus(new OrderStatus());
					u.getOrderStatus().setFirstStage(new FirstStage());
					u.getOrderStatus().setSecondStage(new SecondStage());
					u.getOrderStatus().setThirdStage(new ThirdStage());
					u.getOrderStatus().setFinalStage(new FinalStage());
					u.getOrderStatus().getFirstStage().setStepStatus(BusinessInterestStatus.DONE);
					u.getOrderStatus().setCurrentStatus(BusinessInterestStatus.SENT);
					u.setUserUUId(cartRequest.getUserUuid());
					u.setUuid(UniqueId.getUUID());

				});
				cartRequest.setUuid(UniqueId.getUUIDs());
				cartRepo.saveAndFlush(cartRequest);
				recievedBusinessInterest(cartRequest);

			} else {

				List<CartItem> cartItems = oldCart.getCartItem();
				if (cartItems != null) {

					cartItems.forEach(a -> {
						if (a.getBusinessInterestUUID()
								.equals(cartRequest.getCartItem().stream().findAny().get().getBusinessInterestUUID())
								&& a.getIsActive() == true) {
							throw new CustomException(
									"User have already generated interest.Just update its quantity or delete that interest",
									HttpStatus.ALREADY_REPORTED);
						}
					});

					oldCart.setCartItem(cartRequest.getCartItem());
					oldCart.getCartItem().parallelStream().forEach(u -> {

						u.setOrderStatus(new OrderStatus());
						u.getOrderStatus().setFirstStage(new FirstStage());
						u.getOrderStatus().setSecondStage(new SecondStage());
						u.getOrderStatus().setThirdStage(new ThirdStage());
						u.getOrderStatus().setFinalStage(new FinalStage());
						u.getOrderStatus().getFirstStage().setStepStatus(BusinessInterestStatus.DONE);
						u.getOrderStatus().setCurrentStatus(BusinessInterestStatus.SENT);
						u.setIsActive(active);
						u.setUserUUId(cartRequest.getUserUuid());
						u.setUuid(UniqueId.getUUID());

					});

					cartRepo.saveAndFlush(oldCart);
					recievedBusinessInterest(cartRequest);

				}
			}
		} catch (CustomException e) {
			e.printStackTrace();
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());

		}

	}

	private NameMapper getBusinessInterestDetails(String uid, Class<?> obj) {
		if (obj.equals(ProductDTO.class)) {
			ProductDTO productDTO = productRestEndPoint.getProduct(uid);
			return NameConverter.converter(productDTO);
		}
		if (obj.equals(SMEServiceDTO.class)) {
			SMEServiceDTO smeServiceDTO = serviceRestEndPoint.getService(uid);
			return NameConverter.converter(smeServiceDTO);
		}
		return null;

	}

	@Override
	public void removeCartItem(String uuid) {

		try {
			CartItem cartItem = cartItemRepo.findByUuid(uuid);
			RecievdBusinessInterest recievdBusinessInterest = recieveBusinessInterestRepo
					.findByBusinessInterestUUIDAndUserUUIDAndIsActive(cartItem.getBusinessInterestUUID(),
							cartItem.getUserUUId(), true);
			if (recievdBusinessInterest != null) {
				recievdBusinessInterest.setIsActive(false);
			}

			cartItem.setIsActive(false);

			cartItemRepo.saveAndFlush(cartItem);
			recieveBusinessInterestRepo.saveAndFlush(recievdBusinessInterest);

		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}
	}

	@Override
	public void removeCart(String uuid) {
		try {
			Cart cart = cartRepo.findByUuid(uuid);
			if (cart.getIsActive() == true) {

				cart.setIsActive(false);
				cartRepo.saveAndFlush(cart);

			} else {
				throw new CustomException("Cart does not contain any Business interest or user account is deactive",
						HttpStatus.BAD_REQUEST);
			}

		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

	}

	@Override
	public synchronized CartItem getOneBusinessInterest(String uuid) {
		try {
			if (uuid != null) {
				CartItem cartItem = cartItemRepo.findByUuid(uuid);
				if (cartItem != null) {
					return cartItem;
				} else {
					throw new CustomException("Business interest no found", HttpStatus.NO_CONTENT);
				}
			} else {
				throw new CustomException("UUID not present", HttpStatus.BAD_REQUEST);
			}
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

	}

	@Override
	public Cart getCart(String userUUID) {
		return null;

		/*
		 * try { Cart cart = cartRepo.findByUserUuid(userUUID);
		 * 
		 * if (cart != null && cart.getIsActive() == active) {
		 * 
		 * List<CartItem> activeCartItems = cart.getCartItem().stream().filter(x ->
		 * x.getIsActive() == active) .collect(Collectors.toList());
		 * List<RecievdBusinessInterest> recievdBusinessInterests =
		 * cart.getRecievdBusinessInterests().stream() .filter(x -> x.getIsActive() ==
		 * active).collect(Collectors.toList()); if (activeCartItems.isEmpty() == false
		 * && activeCartItems != null) {
		 * 
		 * activeCartItems.parallelStream().forEachOrdered(ci -> { if
		 * (ci.getProvider().equals("PRODUCT")) { ci.setCartAttribute(
		 * getBusinessInterestDetails(ci.getBusinessInterestUUID(), ProductDTO.class));
		 * } if (ci.getProvider().equals("SERVICE")) { ci.setCartAttribute(
		 * getBusinessInterestDetails(ci.getBusinessInterestUUID(),
		 * SMEServiceDTO.class)); } });
		 * 
		 * }
		 * 
		 * if (recievdBusinessInterests.isEmpty() == false && recievdBusinessInterests
		 * != null) {
		 * 
		 * recievdBusinessInterests.parallelStream().forEachOrdered(action -> { if
		 * (action.getProvider().equals("PRODUCT")) { action.setCartAttribute(
		 * getBusinessInterestDetails(action.getBusinessInterestUUID(),
		 * ProductDTO.class)); } if (action.getProvider().equals("SERVICE")) {
		 * action.setCartAttribute(
		 * getBusinessInterestDetails(action.getBusinessInterestUUID(),
		 * SMEServiceDTO.class)); } if (action.getViewStatus() == true) {
		 * action.setUserDetails(this.userDetails(action.getUuid())); }
		 * 
		 * });
		 * 
		 * } cart.setCartItem(activeCartItems);
		 * 
		 * cart.setRecievdBusinessInterests(recievdBusinessInterests);
		 * cart.setCartItem(cart.getCartItem().stream().filter(ca ->
		 * ca.getCartAttribute() != null) .collect(Collectors.toList())); Integer
		 * sentCount = (int) cart.getCartItem().stream().count(); Integer recieveCount =
		 * (int) cart.getRecievdBusinessInterests().stream().count();
		 * cart.setSentCount(sentCount); cart.setReceiveCount(recieveCount);
		 * 
		 * return cart;
		 * 
		 * } else {
		 * 
		 * throw new CustomException("Problem while fetching cart",
		 * HttpStatus.BAD_REQUEST); } } catch (CustomException e) {
		 * 
		 * throw new CustomException(e.getErrorMessage(), e.getErrorCode()); }
		 */
	}

	@Override
	public synchronized CartItem updateBusinessInterest(CartItem cartItem) {
		try {
			CartItem cartItem2 = cartItemRepo.findBySmeCartId(cartItem.getSmeCartId());
			if (cartItem2 != null) {
				if (cartItem2.getIsActive() == true) {
					cartItem2.setBusinessInterestQuantity(cartItem.getBusinessInterestQuantity());
					cartItemRepo.saveAndFlush(cartItem2);
					return cartItem;
				} else {
					throw new CustomException("Product has been removed by provider", HttpStatus.NO_CONTENT);
				}

			} else {
				throw new CustomException("Product not found", HttpStatus.NOT_FOUND);
			}
		} catch (CustomException e) {

			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

	}

	@Transactional
	private void recievedBusinessInterest(Cart cartRequest) {

		SMEInformationDto smeInformationDto = getSmeDetails(cartRequest);
		Cart oldCart = cartRepo.findByUserUuid(smeInformationDto.getUuid());

		if (oldCart != null) {
			List<RecievdBusinessInterest> oldRecievdBusinessInterest = oldCart.getRecievdBusinessInterests();
			oldRecievdBusinessInterest.add(recieveBusinessInterestModel.setValues(cartRequest));
			oldCart.setIsActive(cartRequest.getIsActive());
			oldCart.setUserUuid(smeInformationDto.getUuid());
			oldRecievdBusinessInterest.stream().forEach(r -> {
				r.setSmeUserID(smeInformationDto.getUuid());
			});
			oldCart.setRecievdBusinessInterests(oldRecievdBusinessInterest);
			cartRepo.save(oldCart);

		} else {
			Cart cart = new Cart();
			List<RecievdBusinessInterest> listRecieveBusinessInterest = new ArrayList<RecievdBusinessInterest>();
			listRecieveBusinessInterest.add(recieveBusinessInterestModel.setValues(cartRequest));
			cart.setIsActive(cartRequest.getIsActive());
			cart.setUserUuid(smeInformationDto.getUuid());
			listRecieveBusinessInterest.stream().forEach(r -> {
				r.setSmeUserID(smeInformationDto.getUuid());
			});
			cart.setUuid(UniqueId.getUUIDs());
			cart.setRecievdBusinessInterests(listRecieveBusinessInterest);
			cartRepo.save(cart);
		}

	}

	@Override
	public Long totalCountOfUserCart(String userUUID) {
		Cart existingUserCart = cartRepo.findByUserUuid(userUUID);

		List<CartItem> activeCartItem = new ArrayList<>();
		List<RecievdBusinessInterest> activeRecievedCartItem = new ArrayList<>();
		Long totalCount = null;
		if (existingUserCart != null) {
			activeCartItem = existingUserCart.getCartItem().parallelStream().filter(x -> x.getIsActive() == active)
					.collect(Collectors.toList());
			activeRecievedCartItem = existingUserCart.getRecievdBusinessInterests().parallelStream()
					.filter(x -> x.getIsActive() == active).collect(Collectors.toList());

			Long sentCount = activeCartItem.parallelStream().count();
			Long recieveCount = activeRecievedCartItem.parallelStream().count();
			totalCount = sentCount + recieveCount;

		}
		return totalCount;
	}

	private SMEInformationDto getSmeDetails(Cart cartRequest) {
		try {
			ProductDTO product = null;
			SMEServiceDTO smeServiceDTO = null;
			SMEInformationDto smeInformationDto = null;

			if (cartRequest.getCartItem().stream().findAny().get().getProvider().equalsIgnoreCase("PRODUCT")) {
				product = productRestEndPoint
						.getProduct(cartRequest.getCartItem().stream().findAny().get().getBusinessInterestUUID());
				smeInformationDto = smeServerEndpoint.getSme(product.getsUuid());
			} else {
				smeServiceDTO = serviceRestEndPoint
						.getService(cartRequest.getCartItem().stream().findAny().get().getBusinessInterestUUID());
				smeInformationDto = smeServerEndpoint.getSme(smeServiceDTO.getsUuid());
			}

			if (smeInformationDto != null) {
				return smeInformationDto;
			} else {
				throw new CustomException("Error while fecthing sme information", HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		} catch (Exception err) {
			throw new CustomException(err.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@Override
	public Set<String> getProductCartItems(String userUUID) {
		List<CartItem> cartItemList = null;
		Set<String> productUUIDs = new HashSet<String>();
		try {
			cartItemList = this.getCartItems(userUUID, "PRODUCT", true);
			cartItemList.forEach(c -> {
				productUUIDs.add(c.getBusinessInterestUUID());
			});
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

		return productUUIDs;
	}

	@Override
	public Set<String> getServiceCartItems(String userUUID) {
		List<CartItem> cartItemList = null;
		Set<String> serviceUUIDs = new HashSet<String>();
		try {
			cartItemList = this.getCartItems(userUUID, "SERVICE", true);
			cartItemList.forEach(c -> {
				serviceUUIDs.add(c.getBusinessInterestUUID());
			});
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

		return serviceUUIDs;
	}

	private List<CartItem> getCartItems(String userUUID, String provider, Boolean b) {
		Optional<List<CartItem>> cartItemList = null;
		try {
			cartItemList = cartItemRepo.findByUserUUIdAndProviderAndIsActive(userUUID, provider, b);
			if (cartItemList.isPresent()) {
				return cartItemList.get();
			} else {
				throw new CustomException("CartItems not found", HttpStatus.NOT_FOUND);
			}
		} catch (CustomException e) {
			throw new CustomException("CartItems not found", HttpStatus.NOT_FOUND);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomException("Internal Server Error", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public UserDto userDetails(String recievedInterestUUId) {

		try {
			RecievdBusinessInterest recievdBusinessInterest = recieveBusinessInterestRepo
					.findByUuid(recievedInterestUUId);
			if (recievdBusinessInterest != null) {

				UserDto user = userServerEndpoint.getUser(recievdBusinessInterest.getUserUUID());
				return user;
			} else {
				throw new CustomException("BI not found with uid " + recievedInterestUUId, HttpStatus.NOT_FOUND);
			}
		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}

	}

	@Override
	public boolean checkUUIDisExist(String userUUID, String uuid) {
		try {
			if (cartItemRepo.findByBusinessInterestUUIDAndUserUUIdAndIsActive(uuid, userUUID, true) != null) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public Cart getRecievedInterest(String userId, int page) {
		try {

			if (page <= 0) {
				page = 1;
			}
			List<RecievdBusinessInterest> recievdBusinessInterests = recieveBusinessInterestRepo
					.findBySmeUserIDAndIsActive(userId, true,
							PageRequest.of(--page, limit, Sort.Direction.DESC, "creationDate"));

			if (recievdBusinessInterests != null) {
				recievdBusinessInterests.stream().filter(r -> r.getViewStatus() == active)
						.forEach(re -> re.setUserDetails(userDetails(re.getUuid())));
				Cart cart = new Cart();
				cart.setRecievdBusinessInterests(recievdBusinessInterests);

				cart.setSentCount(cartItemRepo.countByUserUUIdAndIsActive(userId, active));
				cart.setReceiveCount(recieveBusinessInterestRepo.countBySmeUserIDAndIsActive(userId, active));
				cart.setCartItem(null);
				return cart;

			} else {
				throw new CustomException("Problem while fetching recieve cart", HttpStatus.NOT_FOUND);
			}

		} catch (CustomException e) {
			e.printStackTrace();
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}
	}

	@Override
	public Cart getSentInterest(String userId, int page) {
		try {

			List<CartItem> activeCartItems = cartItemRepo.findByUserUUIdAndIsActive(userId, active,
					PageRequest.of(--page, limit, Sort.Direction.DESC, "creationDate"));

			if (activeCartItems != null) {
				Cart cart = new Cart();
				cart.setCartItem(activeCartItems);

				Integer recieveCount = recieveBusinessInterestRepo.countBySmeUserIDAndIsActive(userId, active);
				cart.setSentCount(cartItemRepo.countByUserUUIdAndIsActive(userId, active));
				cart.setReceiveCount(recieveCount);
				cart.setRecievdBusinessInterests(null);
				return cart;

			} else {
				throw new CustomException("Problem while fetching cart", HttpStatus.BAD_REQUEST);
			}

		} catch (CustomException e) {

			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

	}

}
