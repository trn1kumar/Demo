package com.smeface.cart.controller;

import java.io.IOException;

import org.glassfish.jersey.media.multipart.FormDataParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.smeface.cart.constant.BusinessInterestStatus;
import com.smeface.cart.entity.QuotationFile;
import com.smeface.cart.exception.CustomException;
import com.smeface.cart.util.SendFilesToContentServer;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = "/smeface/cart")
public class FileController {

	@Autowired
	private SendFilesToContentServer sendfiles;

	@PostMapping("/{sUuid}/upload")
	public ResponseEntity<?> smeUpload(@FormDataParam("files") MultipartFile files, @PathVariable String sUuid)
			throws IllegalArgumentException, IOException, CustomException {
		QuotationFile images = null;
		if (files != null) {
			images = sendfiles.sendFileToContentServer(files,
					BusinessInterestStatus.QUOTATION.replace("{sUuid}", sUuid));
		}
		return new ResponseEntity<QuotationFile>(images, HttpStatus.OK);
	}

	@PostMapping("/{userUUID}/user-upload")
	public ResponseEntity<?> userUpload(@FormDataParam("files") MultipartFile files, @PathVariable String userUUID)
			throws IllegalArgumentException, IOException, CustomException {
		QuotationFile images = null;
		if (files != null) {
			images = sendfiles.sendFileToContentServer(files,
					BusinessInterestStatus.USER_QUOTATION.replace("{uuid}", userUUID));
		}
		return new ResponseEntity<QuotationFile>(images, HttpStatus.OK);
	}
}