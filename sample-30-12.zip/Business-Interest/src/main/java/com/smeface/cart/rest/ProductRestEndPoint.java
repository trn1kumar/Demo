package com.smeface.cart.rest;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.http.HttpStatus;

import com.smeface.cart.dto.ProductDTO;
import com.smeface.cart.exception.CustomException;

public class ProductRestEndPoint {
	private Client client;
	private String productEndPointUrl;
	private String getProductPath;

	public ProductRestEndPoint(Client client, String productEndPointUrl, String getProductPath) {
		this.getProductPath = getProductPath;
		this.client = client;
		this.productEndPointUrl = productEndPointUrl;
	}
	
	public ProductDTO getProduct(String pUuid) {
		try {
		String path = productEndPointUrl.replace("{uuid}", pUuid);
		 client = ClientBuilder.newClient();
		Response response = client.target(getProductPath).path(path)
				.request(MediaType.APPLICATION_JSON).get();
		

		ProductDTO productDTO = null;
		Integer responseCode = response.getStatus();

		if (responseCode == HttpStatus.OK.value()) {
			productDTO = response.readEntity(new GenericType<ProductDTO>() {
			});
			return productDTO;

		} else if (responseCode == HttpStatus.BAD_REQUEST.value()) {
			/*throw new CustomException("Product not found with uuid "+ pUuid,  HttpStatus.NOT_FOUND);*/
			return null;

		} else {
			throw new CustomException(" Internal Exception occrurred while fetching product,Invalid Response: "+
					response.getStatusInfo().getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}catch (CustomException e) {
		throw new CustomException(e.getErrorMessage(), e.getErrorCode());
	}
	}
	
}
