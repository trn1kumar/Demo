package com.smeface.cart.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SMEServiceDTO {

	private String serviceUUID;
	private String serviceUrlName;
	private String serviceDisplayName;
	private List<ImageDto> serviceImages;
	private String serviceDescription;
	private PriceDetailsResponse priceDetails;
	private String smeName;
	private String sUuid;

	public String getServiceUUID() {
		return serviceUUID;
	}

	public void setServiceDisplayName(String serviceDisplayName) {
		this.serviceDisplayName = serviceDisplayName;
	}

	public void setServiceUUID(String serviceUUID) {
		this.serviceUUID = serviceUUID;
	}

	public String getServiceUrlName() {
		return serviceUrlName;
	}

	public void setServiceUrlName(String serviceUrlName) {
		this.serviceUrlName = serviceUrlName;
	}

	public String getServiceDisplayName() {
		return serviceDisplayName;
	}

	public String getServiceDescription() {
		return serviceDescription;
	}

	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}

	public String getSmeName() {
		return smeName;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public List<ImageDto> getServiceImages() {
		return serviceImages;
	}

	public void setServiceImages(List<ImageDto> serviceImages) {
		this.serviceImages = serviceImages;
	}

	public PriceDetailsResponse getPriceDetails() {
		return priceDetails;
	}

	public void setPriceDetails(PriceDetailsResponse priceDetails) {
		this.priceDetails = priceDetails;
	}

}
