package com.smeface.cart.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import com.smeface.cart.dto.CartDto;
import com.smeface.cart.entity.Cart;

@Component
public class CartMapper {
	public CartDto convertToDto(Cart cart) {
		ModelMapper mapper = new ModelMapper();
		try {
			
			CartDto cartDTO = mapper.map(cart, CartDto.class);
			
			
			return cartDTO;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public Cart convertToEntity(CartDto cartDTO) {
		ModelMapper mapper = new ModelMapper();
		try {
			Cart cart = mapper.map(cartDTO, Cart.class);

			return cart;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
