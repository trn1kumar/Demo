package com.smeface.cart.util;

import java.util.Random;

public class RandomNumber {
	
	public int numberGenerator() {
		Random random = new Random();
		int randomNumber = random.nextInt(100000);
		return randomNumber;
	}
}
