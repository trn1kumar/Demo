package com.smeface.cart.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@Table(name = "CartAttribute")
public class NameMapper {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long nameCartId;

	@Column(name = "ItemDisplayName")
	private String itemDisplayName;

	@Column(name = "ItemURL")
	private String itemURL;

	@Column(name = "sUuid")
	private String sUuid;

	@Column(name = "smeName")
	private String smeName;

	@Column(name = "businessInterestUUID")
	private String businessInterestUUID;

	@Column(name = "price")
	private Double price;

	@Column(name = "itemImage")
	private String itemImage;

	public NameMapper() {
		super();
	}

	public String getItemDisplayName() {
		return itemDisplayName;
	}

	public void setItemDisplayName(String itemDisplayName) {
		this.itemDisplayName = itemDisplayName;
	}

	public String getItemURL() {
		return itemURL;
	}

	public void setItemURL(String itemURL) {
		this.itemURL = itemURL;
	}

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public String getSmeName() {
		return smeName;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public String getBusinessInterestUUID() {
		return businessInterestUUID;
	}

	public void setBusinessInterestUUID(String businessInterestUUID) {
		this.businessInterestUUID = businessInterestUUID;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Long getNameCartId() {
		return nameCartId;
	}

	public void setNameCartId(Long nameCartId) {
		this.nameCartId = nameCartId;
	}

	public String getItemImage() {
		return itemImage;
	}

	public void setItemImage(String itemImage) {
		this.itemImage = itemImage;
	}

}
