package com.smeface.cart.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.smeface.cart.entity.CartItem;

@Repository
public interface CartItemRepo extends JpaRepository<CartItem, Long>{

	CartItem findBySmeCartId(Long smeCartId);
	CartItem findByUuid(String uuid);
	CartItem findByBusinessInterestUUIDAndUserUUIdAndIsActive(String businessInterestUUID, String userUUID, Boolean bool);     
	
	List<CartItem> findByUserUUIdAndIsActive(String userUUID,Boolean b, Pageable pageable);
	Optional<List<CartItem>> findByUserUUIdAndProviderAndIsActive(String userUUID,String provider,Boolean b);
	Integer countByUserUUIdAndIsActive(String userId, boolean bool);
}
