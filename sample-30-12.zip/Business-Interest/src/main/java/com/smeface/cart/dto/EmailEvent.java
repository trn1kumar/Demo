package com.smeface.cart.dto;

public class EmailEvent {
	
	
	private String emailId;
	private String subject;
	private String eventMessage = null;

	public EmailEvent() {
		// TODO Auto-generated constructor stub
	}

	

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getEventMessage() {
		return eventMessage;
	}

	public void setEventMessage(String eventMessage) {
		this.eventMessage = eventMessage;
	}

	@Override
	public String toString() {
		return "EmailEvent [emailId=" + emailId + ", subject=" + subject + ", eventMessage=" + eventMessage + "]";
	}

}
