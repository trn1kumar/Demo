package com.smeface.cart.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "MessageCenter")
public class MessageCenter {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(name = "Message")
	private String message;
	
	@Column(name = "Status")
	private String status;

	@Transient
	private List<String> messages;

	@Column(name = "userUUID")
	private String userUUID;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "USER_BUSINESS_INTEREST_CREATION_DATE", updatable = false)
	@CreatedDate
	private Date userBusinessInterestCreationDate = new Date();

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "USER_BUSINESS_INTEREST_CLOSING_DATE")
	@LastModifiedDate
	private Date userBusinessInterestClosingDate = new Date();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUserUUID() {
		return userUUID;
	}

	public void setUserUUID(String userUUID) {
		this.userUUID = userUUID;
	}

	public Date getUserBusinessInterestCreationDate() {
		return userBusinessInterestCreationDate;
	}

	public void setUserBusinessInterestCreationDate(Date userBusinessInterestCreationDate) {
		this.userBusinessInterestCreationDate = userBusinessInterestCreationDate;
	}

	public Date getUserBusinessInterestClosingDate() {
		return userBusinessInterestClosingDate;
	}

	public void setUserBusinessInterestClosingDate(Date userBusinessInterestClosingDate) {
		this.userBusinessInterestClosingDate = userBusinessInterestClosingDate;
	}

	public List<String> getMessages() {
		return messages;
	}

	public void setMessages(List<String> messages) {
		this.messages = messages;
	}

}
