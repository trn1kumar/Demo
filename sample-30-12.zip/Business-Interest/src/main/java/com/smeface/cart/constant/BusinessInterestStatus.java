package com.smeface.cart.constant;

public interface BusinessInterestStatus {

	public static final String PENDING = "PENDING";
	public static final String ACCEPTED = "ACCEPTED";
	public static final String DELETED = "DELETED";
	public static final String RECIEVED = "Receive";
	public static final String DELIVERED = "Delivered";
	public static final String SENT = "Sent";
	public static final String QUOTATION_STATUS = "Quotation";
	public static final String PURCHASE_ORDER = "Purchase Order";
	

	public static final String QUOTATION = "/sme/{sUuid}/QuotationFile";
	public static final String USER_QUOTATION = "/users/{uuid}/QuotationFile";
	public static final String QUOTATION_SENT = "QUOTATION SENT";
	public static final String REVISE_QUOTATION_SENT = "SENT REVISED QUOTATION";
	public static final String REVISE_QUOTATION_REQUESTED = "SENT REVISED QUOTATION REQUEST";
	public static final String RECIEVED_REVISE_QUOTATION_REQUEST = "RECIEVED REVISED QUOTATION REQUEST";
	
	public static final String REVISE_QUOTATION_RECIEVED = "RECIEVED REVISED QUOTATION";
	public static final String BI_CLOSED = "BI CLOSED";
	public static final String QUOTATION_RECIEVED = "QUOTATION RECEIVED";
	public static final String QUOTATION_ACCEPTED = "QUOTATION ACCEPTED";
	public static final String ORDER_CONFIRMED = "ORDER CONFIRMED";
	public static final String PURCHASE_ORDER_ACCEPTED = "PO ACCEPTED";
	public static final String PURCHASE_ORDER_SENT = "PO SENT";
	public static final String PURCHASE_ORDER_RECIEVED = "PO RECEIVED";
	
	public static final String DONE="Done";
	public static final String CANCELLED="Cancelled";
	public static final String CONFIRM="Confirm";
	
}
