package com.smeface.cart.service;

import java.util.Set;

import com.smeface.cart.dto.UserDto;
import com.smeface.cart.entity.Cart;
import com.smeface.cart.entity.CartItem;

public interface CartItemService {

	void cart(Cart cart);

	void removeCartItem(String uuid);

	void removeCart(String uuid);

	CartItem getOneBusinessInterest(String uuid);

	Cart getCart(String userId);

	Cart getRecievedInterest(String userId, int page);

	Cart getSentInterest(String userId, int page);

	CartItem updateBusinessInterest(CartItem cartItem);

	Long totalCountOfUserCart(String userId);

	Set<String> getServiceCartItems(String userUUID);

	Set<String> getProductCartItems(String userUUID);

	UserDto userDetails(String recievedInterestUUId);

	boolean checkUUIDisExist(String userUUID, String uuid);

}