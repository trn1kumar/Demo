package com.smeface.cart.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.smeface.cart.dto.EmailEvent;
import com.smeface.cart.dto.ProductDTO;
import com.smeface.cart.dto.SMEInformationDto;
import com.smeface.cart.dto.SmsEvent;
import com.smeface.cart.dto.UserDto;
import com.smeface.cart.entity.Cart;
import com.smeface.cart.exception.CustomException;
import com.smeface.cart.repository.RecieveBusinessInterestRepo;
import com.smeface.cart.rest.NotificationRestEndPoint;
import com.smeface.cart.rest.ProductRestEndPoint;
import com.smeface.cart.rest.SmeServerEndpoint;
import com.smeface.cart.rest.UserServerEndpoint;

@Component
public class Notification {
	
	@Autowired
	private ProductRestEndPoint productRestEndPoint;

	@Autowired
	 RecieveBusinessInterestRepo recieveBusinessInterestRepo;

	@Autowired
	 NotificationRestEndPoint notificationRestEndpoint;

	@Autowired
	 UserServerEndpoint userServerEndpoint;

	@Autowired
	 SmeServerEndpoint smeServerEndpoint;

	@Async
	public  void sendNotificationToSme(Cart cartRequest) {

		String link = "https://www.smeface.com/smeface/cart";
		ProductDTO product = productRestEndPoint.getProduct(cartRequest.getCartItem().stream().findAny().get().getBusinessInterestUUID());
		UserDto userDto = userServerEndpoint.getUser(cartRequest.getUserUuid());
		SMEInformationDto smeInformationDto = smeServerEndpoint.getSme(product.getsUuid());

		String emailId = smeInformationDto.getContactEmail();

		try {

			// Sms notification
			SmsEvent smsEvent = new SmsEvent();
			smsEvent.setMobileNo(smeInformationDto.getContactPhone());
			smsEvent.setEventMessage(
					"You have recieved a new Business interest from " + userDto.getUserFullName() + ". For product "
							+ product.getProductDisplayName() + ". Please visit " + link + " for further process");
			smsEvent.setSender("SUMNBH");
			notificationRestEndpoint.sendNotification(smsEvent);

			// Email notification
			if (emailId != null) {
				EmailEvent emailEvent = new EmailEvent();
				emailEvent.setEmailId(emailId);
				emailEvent.setEventMessage(
						"You have recieved new Business interest from " + userDto.getUserFullName() + ".");
				emailEvent.setEventMessage("You have recieved new Business interest from " + userDto.getUserFullName()
						+ "." + "\n Customer contact details are: " + "\n\t" + "Mobile number: "
						+ "**********"/*userDto.getUserMobile()*/ + "\n\t" + "Email id: " + "*****@****.com"/*userDto.getUserEmail()*/ + "\n\n"
						+ " Please find the details of product here below.\n" + "Product name : "
						+ product.getProductDisplayName() + "\nQuantity : "
						+ cartRequest.getCartItem().stream().filter(x -> x.getBusinessInterestQuantity() >= 1)
								.findFirst().get().getBusinessInterestQuantity()
						+ "\nTotal price:"
						+ (cartRequest.getCartItem().stream().filter(x -> x.getBusinessInterestQuantity() >= 1)
								.findFirst().get().getBusinessInterestQuantity()) * product.getPrice()
						+ "\n" + "Please visit " + link + " to proceed further");
				notificationRestEndpoint.sendNotification(emailEvent);
			}
		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}
	}
}
