package com.smeface.cart.dto;

public class SmsEvent {

	private String mobileNo;
	private String eventMessage;
	private String sender;

	

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEventMessage() {
		return eventMessage;
	}

	public void setEventMessage(String eventMessage) {
		this.eventMessage = eventMessage;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	@Override
	public String toString() {
		return "SmsEvent [mobileNo=" + mobileNo + ", eventMessage=" + eventMessage + ", sender=" + sender + "]";
	}

}
