package com.smeface.cart.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.smeface.cart.entity.RecievdBusinessInterest;
@Repository
public interface RecieveBusinessInterestRepo extends JpaRepository<RecievdBusinessInterest, Long> {

	RecievdBusinessInterest findByUuid(String uuid);
	List<RecievdBusinessInterest> findBySmeUserIDAndIsActive(String smeUserUid, boolean bool, Pageable pageable);
	RecievdBusinessInterest findByBusinessInterestUUIDAndUserUUIDAndIsActive(String productUUID, String userUUID,Boolean bool);
	Integer countBySmeUserIDAndIsActive(String smeId, boolean bool);
	
}
