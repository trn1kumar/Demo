package com.smeface.cart.util;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.smeface.cart.dto.UploadFileResponse;
import com.smeface.cart.entity.QuotationFile;
import com.smeface.cart.exception.CustomException;
import com.smeface.cart.rest.ContentServerEndpoint;

@Component
public class SendFilesToContentServer {

	@Autowired
	private ContentServerEndpoint contentServerEndpoint;

	public QuotationFile sendFileToContentServer(MultipartFile file,String fileContentDirName)
			throws IllegalArgumentException, IOException {
		String names = null;

		QuotationFile image = null;

		try {
			RandomNumber number = new RandomNumber();
			String imageName = number.numberGenerator() + file.getOriginalFilename();
			names = imageName;
			image = new QuotationFile(imageName, true);

		} catch (CustomException e) {
			e.printStackTrace();
		}

		List<UploadFileResponse> fileDetails = contentServerEndpoint.sendFileToContentServer(file, names, fileContentDirName);
		for (UploadFileResponse fileDetail : fileDetails) {
			image.setFileLocation(fileDetail.getFileLocation());
		}

		return image;
	}

}
