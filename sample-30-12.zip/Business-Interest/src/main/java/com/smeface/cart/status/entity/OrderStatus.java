package com.smeface.cart.status.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ItemStatus")
public class OrderStatus {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	@OneToOne(cascade = CascadeType.ALL)
	private FirstStage firstStage;
	@OneToOne(cascade = CascadeType.ALL)
	private SecondStage secondStage;
	@OneToOne(cascade = CascadeType.ALL)
	private ThirdStage thirdStage;
	@OneToOne(cascade = CascadeType.ALL)
	private FinalStage finalStage;
	@Column(name = "Current_Status")
	private String currentStatus;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	public FirstStage getFirstStage() {
		return firstStage;
	}

	public void setFirstStage(FirstStage firstStage) {
		this.firstStage = firstStage;
	}

	public SecondStage getSecondStage() {
		return secondStage;
	}

	public void setSecondStage(SecondStage secondStage) {
		this.secondStage = secondStage;
	}

	public ThirdStage getThirdStage() {
		return thirdStage;
	}

	public void setThirdStage(ThirdStage thirdStage) {
		this.thirdStage = thirdStage;
	}

	public FinalStage getFinalStage() {
		return finalStage;
	}

	public void setFinalStage(FinalStage finalStage) {
		this.finalStage = finalStage;
	}

	public String getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

}
