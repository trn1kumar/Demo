package com.smeface.cart.rest;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.http.HttpStatus;

import com.smeface.cart.dto.SMEInformationDto;
import com.smeface.cart.exception.CustomException;

public class SmeServerEndpoint {

	private Client client;
	private String smeEndPointUrl;
	private String getSmeUser;

	public SmeServerEndpoint(Client client, String getSmeUser, String smeEndPointUrl) {
		this.client = client;
		this.getSmeUser = getSmeUser;
		this.smeEndPointUrl = smeEndPointUrl;
	}
	
	public SMEInformationDto getSme(String smeId) {
		
		 client = ClientBuilder.newClient();
		Response response = client.target(smeEndPointUrl).path(getSmeUser + String.valueOf(smeId))
				.request(MediaType.APPLICATION_JSON).get();

		SMEInformationDto smeInformationDto = null;
		Integer responseCode = response.getStatus();

		if (responseCode == HttpStatus.OK.value()) {
			smeInformationDto = response.readEntity(new GenericType<SMEInformationDto>() {
			});
			return smeInformationDto;

		} else if (responseCode == HttpStatus.NOT_FOUND.value()) {
			throw new CustomException("SME not found with id "+ smeId.toString(),  HttpStatus.NOT_FOUND);

		} else {
			throw new CustomException(" Internal Exception occrurred while fetching details from SME Master Model,Invalid Response: "+
					response.getStatusInfo().getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
