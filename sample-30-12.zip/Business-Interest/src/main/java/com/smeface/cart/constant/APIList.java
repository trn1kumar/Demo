package com.smeface.cart.constant;

public class APIList {

	public enum cartAPI {
		CART;
		public static final String ADD_BUSINESS_INTEREST = "/business-interest"; // Add new business interest into cart
		public static final String CART_OF_USER = "/{userUUId}/c"; // get whole cart of a user
		public static final String REMOVE_CART = "/{uuid}"; // remove whole cart
		public static final String REMOVE_BUSINESS_INTEREST = "/{uuid}/r/business-interest"; // remove a cart item from
		public static final String UPDATE_BUSINESS_INTEREST = "/{uuid}/business-interest"; // add more quantity to a
		public static final String SERVICES_CART_ITEMS = "{userUUID}/service";
		public static final String PRODUCTS_CART_ITEMS = "{userUUID}/product";
		public static final String GET_USER_DETAILS = "/user-details";
		public static final String UUID_ISEXIST = "{userUUID}/{uuid}/check";
	}

	public enum smeActionAPI {
		SMEACTION;
		public static final String ACCEPT = "/accept";
		public static final String REJECT = "/reject";
		public static final String REVISE = "/revise";
		public static final String CONFIRM = "/confirm";

	}

	public enum userActionAPI {
		USERACTION;
		public static final String ACCEPT = "/accept";
		public static final String REJECT = "/reject";
		public static final String REVISE = "/revise";
	}

}
