package com.smeface.cart.aspectlogger;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.smeface.cart.dto.PricingRequestDTO;
import com.smeface.cart.entity.RecievdBusinessInterest;
import com.smeface.cart.exception.CustomException;
import com.smeface.cart.repository.RecieveBusinessInterestRepo;
import com.smeface.cart.securityConfiguration.Constants;

@Aspect
@Configuration
public class CheckCredits {

	@Value("${pricing.server.endpoint}")
	private String url;

	@Value("${pricing.path}")
	private String path;

	@Value("${pricing.update.credits}")
	private String creditsPath;

	@Autowired
	private RecieveBusinessInterestRepo businessInterestRepo;

	@Before("execution(* *.*(..)) && @annotation(auditable) && args(pricingRequestDTO)")
	public Object beforeMethodExecution(JoinPoint joinPoint, BeforeCall auditable,
			PricingRequestDTO pricingRequestDTO) {

		final String uri = url + path.replace("{sUuid}", pricingRequestDTO.getsUuid());

		RestTemplate restTemplate = new RestTemplate();

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpServletRequest curRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
				.getRequest();
		String header = curRequest.getHeader(Constants.HEADER_STRING);
		headers.set(Constants.HEADER_STRING, header);
		RecievdBusinessInterest businessInterest = businessInterestRepo.findByUuid(pricingRequestDTO.getUuid());
		try {
			ResponseEntity<String> response = null;
			if (businessInterest.getViewStatus() == false) {
				response = restTemplate.exchange(uri, HttpMethod.GET, new HttpEntity<String>(headers), String.class);

				if (response.getStatusCodeValue() == HttpStatus.OK.value()) {
					return true;
				} else {
					throw new CustomException("Error code not matched", HttpStatus.PAYMENT_REQUIRED);
				}
			} else {
				return true;
			}

		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		} catch (Exception e) {
			e.printStackTrace();
			throw new CustomException(e.getLocalizedMessage(), HttpStatus.PAYMENT_REQUIRED);

		}
	}

	@AfterReturning("execution(* *.*(..)) && @annotation(auditable) && args(pricingRequestDTO)")
	public Object updateBiCredits(JoinPoint joinPoint, BeforeCall auditable, PricingRequestDTO pricingRequestDTO) {

		final String uri = url + creditsPath;

		pricingRequestDTO.setType("BI_READ");
		pricingRequestDTO.setAction("DEBIT");
		pricingRequestDTO.setCredits(1);
		RestTemplate restTemplate = new RestTemplate();

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpServletRequest curRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
				.getRequest();
		String header = curRequest.getHeader(Constants.HEADER_STRING);
		headers.set(Constants.HEADER_STRING, header);
		RecievdBusinessInterest businessInterest = businessInterestRepo.findByUuid(pricingRequestDTO.getUuid());
		try {
			ResponseEntity<String> response = null;
			if (businessInterest.getViewStatus() == false) {
				HttpEntity<PricingRequestDTO> requestEntity = new HttpEntity<PricingRequestDTO>(pricingRequestDTO,
						headers);
				response = restTemplate.exchange(uri, HttpMethod.PUT, requestEntity, String.class);
				if (response.getStatusCodeValue() == HttpStatus.CREATED.value()) {
					businessInterest.setViewStatus(true);
					businessInterestRepo.save(businessInterest);
					return true;
				} else if (response.getStatusCodeValue() == HttpStatus.PAYMENT_REQUIRED.value()) {
					throw new CustomException("Payment required", HttpStatus.PAYMENT_REQUIRED);
				} else {

					throw new CustomException("Error code not matched", HttpStatus.INTERNAL_SERVER_ERROR);
				}
			} else {
				return true;
			}

		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}
	}
}
