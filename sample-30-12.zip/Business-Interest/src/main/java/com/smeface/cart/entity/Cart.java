package com.smeface.cart.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "CART")
public class Cart implements Serializable {

	private static final long serialVersionUID = -2954548630436559446L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(name = "CART_UUID", unique = true)
	private String uuid;
	
	@Column(name = "USER_UUID", unique = true)
	private String userUuid;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "cartId", nullable = false)
	@JsonIgnoreProperties
	private List<CartItem> cartItem;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "cartId", nullable = false)
	@JsonIgnoreProperties
	private List<RecievdBusinessInterest> recievdBusinessInterests;

	@Column(name = "ACTIVE_STATUS")
	private Boolean isActive;

	@Transient
	private Integer sentCount;

	@Transient
	private Integer receiveCount;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<RecievdBusinessInterest> getRecievdBusinessInterests() {
		return recievdBusinessInterests;
	}

	public void setRecievdBusinessInterests(List<RecievdBusinessInterest> recievdBusinessInterests) {
		this.recievdBusinessInterests = recievdBusinessInterests;
	}

	public List<CartItem> getCartItem() {
		return cartItem;
	}

	public void setCartItem(List<CartItem> cartItem) {
		this.cartItem = cartItem;
	}

	public Integer getSentCount() {
		return sentCount;
	}

	public void setSentCount(Integer sentCount) {
		this.sentCount = sentCount;
	}

	public Integer getReceiveCount() {
		return receiveCount;
	}

	public void setReceiveCount(Integer receiveCount) {
		this.receiveCount = receiveCount;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getUserUuid() {
		return userUuid;
	}

	public void setUserUuid(String userUuid) {
		this.userUuid = userUuid;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cartItem == null) ? 0 : cartItem.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((isActive == null) ? 0 : isActive.hashCode());
		result = prime * result + ((receiveCount == null) ? 0 : receiveCount.hashCode());
		result = prime * result + ((recievdBusinessInterests == null) ? 0 : recievdBusinessInterests.hashCode());
		result = prime * result + ((sentCount == null) ? 0 : sentCount.hashCode());
		result = prime * result + ((userUuid == null) ? 0 : userUuid.hashCode());
		result = prime * result + ((uuid == null) ? 0 : uuid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cart other = (Cart) obj;
		if (cartItem == null) {
			if (other.cartItem != null)
				return false;
		} else if (!cartItem.equals(other.cartItem))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (isActive == null) {
			if (other.isActive != null)
				return false;
		} else if (!isActive.equals(other.isActive))
			return false;
		if (receiveCount == null) {
			if (other.receiveCount != null)
				return false;
		} else if (!receiveCount.equals(other.receiveCount))
			return false;
		if (recievdBusinessInterests == null) {
			if (other.recievdBusinessInterests != null)
				return false;
		} else if (!recievdBusinessInterests.equals(other.recievdBusinessInterests))
			return false;
		if (sentCount == null) {
			if (other.sentCount != null)
				return false;
		} else if (!sentCount.equals(other.sentCount))
			return false;
		if (userUuid == null) {
			if (other.userUuid != null)
				return false;
		} else if (!userUuid.equals(other.userUuid))
			return false;
		if (uuid == null) {
			if (other.uuid != null)
				return false;
		} else if (!uuid.equals(other.uuid))
			return false;
		return true;
	}

	
}
