package com.smeface.cart.controller;

import java.util.HashMap;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smeface.cart.aspectlogger.BeforeCall;
import com.smeface.cart.constant.APIList;
import com.smeface.cart.dto.PricingRequestDTO;
import com.smeface.cart.dto.UserDto;
import com.smeface.cart.entity.Cart;
import com.smeface.cart.entity.CartItem;
import com.smeface.cart.entity.RecievdBusinessInterest;
import com.smeface.cart.exception.CustomException;
import com.smeface.cart.repository.RecieveBusinessInterestRepo;
import com.smeface.cart.service.CartItemService;
import com.smeface.cart.util.Notification;

/*
*@author Robin_Kumar
*
*/
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/smeface/cart")
public class CartController {

	@Autowired
	private CartItemService cartItemService;

	@Autowired
	private Notification notification;

	@Autowired
	private RecieveBusinessInterestRepo businessInterestRepo;

	@PostMapping(value = APIList.cartAPI.ADD_BUSINESS_INTEREST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> addBusinessInterestToCart(@RequestBody Cart cart) {

		try {
			CartItem cartItem = cart.getCartItem().stream().findFirst().get();
			if (cart.getUserUuid() != null && cartItem.getBusinessInterestUUID() != null) {

				cartItemService.cart(cart);
				notification.sendNotificationToSme(cart);
				HashMap<String, HttpStatus> response = new HashMap<>();
				response.put("Business interest generated", HttpStatus.OK);
				return new ResponseEntity<HashMap<String, HttpStatus>>(response, HttpStatus.CREATED);

			} else {
				throw new CustomException("User uid or Item UUID not present", HttpStatus.UNAUTHORIZED);
			}

		} catch (CustomException e) {
			e.printStackTrace();
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());

		} catch (Exception err) {
			err.printStackTrace();
			throw new CustomException(err.getMessage(), HttpStatus.BAD_REQUEST);
		}

	}

	@GetMapping(value = APIList.cartAPI.CART_OF_USER, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getBusinessInterest(@PathVariable String userUUId,
			@RequestParam(value = "count", required = false) String count,
			@RequestParam(value = "u", required = false) String userCart,
			@RequestParam(value = "page", required = false, defaultValue = "1") int page) {
		Cart cart = null;
		try {
			String newCount = "count";
			if (!newCount.equalsIgnoreCase(count)) {
				if (userUUId != null) {
					if (userCart != null && userCart.equals("user")) {
						cart = cartItemService.getSentInterest(userUUId, page);

						return new ResponseEntity<Cart>(cart, HttpStatus.OK);

					} else {
						cart = cartItemService.getRecievedInterest(userUUId, page);

						return new ResponseEntity<Cart>(cart, HttpStatus.OK);

					}

				} else {
					throw new CustomException("No User is  logged in", HttpStatus.UNAUTHORIZED);
				}
			} else {
				Long totalCount = cartItemService.totalCountOfUserCart(userUUId);
				if (totalCount == null) {
					totalCount = new Long(0);
				}
				HashMap<String, Long> map = new HashMap<>();
				map.put("Count", totalCount);

				return new ResponseEntity<HashMap<String, Long>>(map, HttpStatus.OK);
			}

		} catch (CustomException e) {
			e.printStackTrace();
			throw new CustomException(e.getMessage(), e.getErrorCode());
		}

	}

	@DeleteMapping(value = APIList.cartAPI.REMOVE_CART, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> removeCart(@PathVariable String uuid) {
		try {
			if (uuid != null) {
				cartItemService.removeCart(uuid);
			} else {
				throw new CustomException("Cart is empty", HttpStatus.NOT_FOUND);
			}
		} catch (CustomException e) {
			e.printStackTrace();
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}
		return new ResponseEntity<String>(HttpStatus.OK);
	}

	@DeleteMapping(value = APIList.cartAPI.REMOVE_BUSINESS_INTEREST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> removeBusinessInterest(@PathVariable String uuid) {
		try {

			if (uuid != null) {
				cartItemService.removeCartItem(uuid);
			}

		} catch (CustomException e) {
			e.printStackTrace();
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}
		return new ResponseEntity<String>(HttpStatus.OK);
	}

	@PutMapping(value = APIList.cartAPI.UPDATE_BUSINESS_INTEREST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> changeQuantity(@RequestBody CartItem cartItem) {

		try {
			if (cartItem != null && cartItem.getSmeCartId() != null) {
				cartItemService.updateBusinessInterest(cartItem);
				return new ResponseEntity<String>("Business interest updated", HttpStatus.OK);
			} else {
				throw new CustomException("Business Interest not found", HttpStatus.NOT_FOUND);
			}
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

	}

	@GetMapping(APIList.cartAPI.PRODUCTS_CART_ITEMS)
	public ResponseEntity<?> getProductsCartItems(@PathVariable String userUUID) {
		Set<String> productUUIDs = null;
		try {
			if (userUUID != null) {
				productUUIDs = cartItemService.getProductCartItems(userUUID);
			}
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

		return new ResponseEntity<Set<String>>(productUUIDs, HttpStatus.OK);
	}

	@GetMapping(APIList.cartAPI.SERVICES_CART_ITEMS)
	public ResponseEntity<?> getServicesCartItems(@PathVariable String userUUID) {
		Set<String> serviceUUIDs = null;
		try {
			if (userUUID != null) {
				serviceUUIDs = cartItemService.getServiceCartItems(userUUID);
			}
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

		return new ResponseEntity<Set<String>>(serviceUUIDs, HttpStatus.OK);
	}

	@PutMapping(APIList.cartAPI.GET_USER_DETAILS)
	@BeforeCall
	public ResponseEntity<?> getUserDetails(@RequestBody PricingRequestDTO pricingRequestDTO)
			throws NoSuchMethodException, SecurityException {

		try {
			RecievdBusinessInterest recievdBusinessInterest = businessInterestRepo
					.findByUuid(pricingRequestDTO.getUuid());

			if (pricingRequestDTO.getUuid() != null) {
				if (recievdBusinessInterest.getViewStatus() == false) {
					UserDto userDtoResponse = cartItemService.userDetails(pricingRequestDTO.getUuid());
					return new ResponseEntity<UserDto>(userDtoResponse, HttpStatus.OK);
				} else {
					UserDto userDtoResponse = cartItemService.userDetails(pricingRequestDTO.getUuid());
					return new ResponseEntity<UserDto>(userDtoResponse, HttpStatus.OK);
				}

			} else {
				throw new CustomException("Path variable not found", HttpStatus.NOT_FOUND);
			}
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

	}

	@GetMapping(APIList.cartAPI.UUID_ISEXIST)
	public ResponseEntity<?> checkServiceUUIDisExist(@PathVariable String userUUID, @PathVariable String uuid) {

		try {
			if (!cartItemService.checkUUIDisExist(userUUID, uuid)) {
				throw new CustomException("Uuid not found for user " + userUUID, HttpStatus.NOT_FOUND);
			}
		} catch (CustomException e) {
			throw e;
		}

		return new ResponseEntity<>(HttpStatus.OK);
	}
}
