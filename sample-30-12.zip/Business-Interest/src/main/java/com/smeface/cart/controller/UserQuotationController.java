package com.smeface.cart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smeface.cart.constant.APIList;
import com.smeface.cart.entity.CartItem;
import com.smeface.cart.exception.CustomException;
import com.smeface.servcie.UserQuotationService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = "/smeface/cart/user")
public class UserQuotationController {

	@Autowired
	private UserQuotationService userQuotationService;

	@PostMapping(value = APIList.userActionAPI.REVISE)
	public ResponseEntity<?> revise(@RequestBody CartItem cartItem) {
		try {
			userQuotationService.revise(cartItem);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}
	}

	@PostMapping(value = APIList.userActionAPI.REJECT)
	public ResponseEntity<?> reject(@RequestBody CartItem cartItem) {
		try {
			userQuotationService.reject(cartItem);
			return new ResponseEntity<String>(HttpStatus.OK);
		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}
	}

	@PostMapping(value = APIList.userActionAPI.ACCEPT)
	public ResponseEntity<?> accept(@RequestBody CartItem cartItem) {
		try {
			userQuotationService.accept(cartItem);
			return new ResponseEntity<String>(HttpStatus.OK);
		} catch (CustomException err) {
			throw new CustomException(err.getErrorMessage(), err.getErrorCode());
		}
	}

}
