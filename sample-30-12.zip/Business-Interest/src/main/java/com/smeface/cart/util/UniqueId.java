package com.smeface.cart.util;

import java.util.UUID;

public class UniqueId {
	public static String[] hardKey = new String[100];

	/**
	 * 128 bit UUID
	 */
	public static synchronized String getUUID() {
		RandomNumber number = new RandomNumber();
		String uuid = "BI" + number.numberGenerator()+number.numberGenerator();
		return uuid;
	}

	public static synchronized String getUUIDs() {
		String uuid = UUID.randomUUID().toString();
		return uuid.replace("-", "");
	}

}