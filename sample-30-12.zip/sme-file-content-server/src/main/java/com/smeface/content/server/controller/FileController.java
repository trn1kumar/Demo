package com.smeface.content.server.controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.smeface.content.server.common.constants.UrlMapping;
import com.smeface.content.server.exception.CustomException;
import com.smeface.content.server.payload.UploadFileResponse;
import com.smeface.content.server.service.FileStorageService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.BASE_URL)
public class FileController {

	private static final Logger logger = LoggerFactory.getLogger(FileController.class);

	@Autowired
	private FileStorageService fileStorageService;

	@PostMapping(UrlMapping.UPLOAD_FILE)
	public UploadFileResponse uploadFile(HttpServletRequest request,
			@RequestParam(value = "files", required = true) MultipartFile file) {
		logger.info("FileController " + "::" + " uploadFile()");
		String location;
		if (request.getRequestURI().contains("uploadFile")) {
			location = request.getRequestURI().replace(UrlMapping.BASE_URL + "/uploadFile/", "");
		} else
			location = request.getRequestURI().replace(UrlMapping.BASE_URL + "/uploadMultipleFiles/", "");

		try {
			UploadFileResponse fileDetail = fileStorageService.storeFile(file, location);
			String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath().path("/downloadFile/")
					.path(fileDetail.getFileName()).toUriString();
			fileDetail.setFileType(file.getContentType());
			fileDetail.setSize(file.getSize());
			fileDetail.setFileDownloadUri(fileDownloadUri);
			return fileDetail;
		} catch (CustomException e) {
			e.printStackTrace();
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}

	}

	@PostMapping(UrlMapping.UPLOAD_FILES)
	public List<UploadFileResponse> uploadMultipleFiles(HttpServletRequest request,
			@RequestParam(value = "files", required = true) MultipartFile[] files) {
		logger.info("FileController " + "::" + " uploadMultipleFiles()");
		return Arrays.asList(files).stream().map(file -> uploadFile(request, file)).collect(Collectors.toList());
	}

	@GetMapping(UrlMapping.FILE_LOCATION)
	public ResponseEntity<Resource> downloadFile(HttpServletRequest request) {
		// Load file as Resource
		String path = request.getRequestURI().replace(UrlMapping.BASE_URL + "/file/", "");
		Resource resource = fileStorageService.loadFileAsResource(path);

		// Try to determine file's content type
		String contentType = null;
		try {
			contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
		} catch (IOException ex) {
			logger.info("Could not determine file type.");
		}

		// Fallback to the default content type if type could not be determined
		if (contentType == null) {
			contentType = "application/octet-stream";
		}

		return ResponseEntity.ok().contentType(MediaType.parseMediaType(contentType))
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
				.body(resource);
	}

	@DeleteMapping(UrlMapping.FILE_LOCATION)
	public ResponseEntity<?> deleteFile(HttpServletRequest request) {

		logger.info("FileController " + "::" + " deleteFile()");
		String path = request.getRequestURI().replace(UrlMapping.BASE_URL + "/file/", "");
		try {
			fileStorageService.deleteFile(path);

		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}
		return new ResponseEntity<>(HttpStatus.OK);

	}

}
