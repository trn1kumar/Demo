package com.smeface.content.server.common.constants;

public interface UrlMapping {
	
	String BASE_URL="/smeface/cdn/api";
	
	String UPLOAD_FILE = "/uploadFile/**";
	String UPLOAD_FILES = "/uploadMultipleFiles/**";
	String FILE_LOCATION = "/file/**";
	
}
