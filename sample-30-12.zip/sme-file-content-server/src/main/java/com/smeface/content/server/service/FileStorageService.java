package com.smeface.content.server.service;

import java.io.File;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.smeface.content.server.aspectlogger.CentralLoggingHandler;
import com.smeface.content.server.exception.CustomException;
import com.smeface.content.server.exception.FileStorageException;
import com.smeface.content.server.payload.UploadFileResponse;
import com.smeface.content.server.property.FileStorageProperties;

@Service
public class FileStorageService {

	private Logger logger = LogManager.getLogger(CentralLoggingHandler.class);

	private String basePath;

	@Value("${root.folder}")
	private String rootFolder;

	@Autowired
	public FileStorageService(FileStorageProperties fileStorageProperties) {
		basePath = fileStorageProperties.getBasePath();
		logger.info("BasePath " + basePath);

		try {
			Path p = Paths.get(fileStorageProperties.getBasePath()).toAbsolutePath().normalize();
			Files.createDirectories(p);
		} catch (Exception ex) {
			throw new FileStorageException("Could not create the directory where the uploaded files will be stored.",
					ex);
		}
	}

	public UploadFileResponse storeFile(MultipartFile file, String location) {

		UploadFileResponse fileDetail = null;

		// Normalize file name
		String originalFilename = StringUtils.cleanPath(file.getOriginalFilename());
		boolean bool = false;

		try {

			// Check if the file's name contains invalid characters if
			if (originalFilename.contains("..")) {
				throw new CustomException("Sorry! Filename contains invalid path sequence " + originalFilename,
						HttpStatus.BAD_REQUEST);
			}

			String fileName = originalFilename.replace(" ", "");

			location = basePath + rootFolder + location;

			Path fileStorageLocation = Paths.get(location).toAbsolutePath().normalize();
			try {

				if (!fileStorageLocation.toFile().exists())
					Files.createDirectories(fileStorageLocation);
			} catch (Exception ex) {
				ex.printStackTrace();
				throw new FileStorageException(
						"Could not create the directory where the uploaded files will be stored.", ex);
			}
			Path targetLocation = fileStorageLocation.resolve(fileName);
			int indexLocation = targetLocation.toAbsolutePath().toString().indexOf("cdn") + 4;

			fileDetail = new UploadFileResponse(
					targetLocation.toAbsolutePath().toString().substring(indexLocation).replace("\\", "/"), fileName);

			try {
				Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
				bool = true;

			} catch (Exception e) {
				e.printStackTrace();
			}
			if (bool == true)
				return fileDetail;
			else
				throw new CustomException("Could not store file " + originalFilename + ". Please try again!",
						HttpStatus.BAD_REQUEST);

		} catch (Exception ex) {
			ex.printStackTrace();
			throw new CustomException(ex.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	public Resource loadFileAsResource(String fileLocation) {
		Path filePath = null;
		Resource resource = null;
		String location = basePath + rootFolder + fileLocation;
		filePath = Paths.get(location).toAbsolutePath().normalize();

		try {
			resource = new UrlResource(filePath.toUri());
			if (resource.exists() || resource.isReadable()) {
				return resource;
			} else {
				throw new CustomException("File not found for location " + fileLocation
						+ ". Please try again! Check location path is Valid.", HttpStatus.NOT_FOUND);
			}

		} catch (MalformedURLException ex) {
			ex.printStackTrace();
			throw new CustomException(ex.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	public void deleteFile(String fileLocation) {
		Path filePath = null;
		String location = basePath + rootFolder + fileLocation;
		filePath = Paths.get(location).toAbsolutePath().normalize();
		try {
			this.delete(new File(filePath.toString()));
		} catch (CustomException ex) {
			throw new CustomException(ex.getErrorMessage(), ex.getErrorCode());
		}

	}

	private void delete(File file) {
		boolean success = false;
		if (file.isDirectory()) {
			for (File deleteMe : file.listFiles()) {
				delete(deleteMe);
			}
		}
		success = file.delete();
		if (success) {
			logger.info(file.getName() + " Deleted");
		} else {
			throw new CustomException(file.getName() + " File Not present." + " Deletion failed!!!",
					HttpStatus.NOT_FOUND);

		}
	}

}
