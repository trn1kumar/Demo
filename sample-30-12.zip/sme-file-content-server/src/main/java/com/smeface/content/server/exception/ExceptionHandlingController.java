package com.smeface.content.server.exception;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.smeface.content.server.util.ValidationUtil;

@ControllerAdvice
public class ExceptionHandlingController {

	Logger log = LogManager.getLogger(ExceptionHandlingController.class.getName());

	@ExceptionHandler(CustomException.class)
	public ResponseEntity<ExceptionResponse> throwCustomException(CustomException ex) {
		ExceptionResponse response = new ExceptionResponse();
		response.setErrorCode(ex.getErrorCode().toString());
		response.setErrorMessage(ex.getMessage());
		return new ResponseEntity<ExceptionResponse>(response, ex.getErrorCode());
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ExceptionResponse> invalidInput(MethodArgumentNotValidException ex) {
		BindingResult result = ex.getBindingResult();
		ValidationErrors response = new ValidationErrors();
		response.setErrorCode(HttpStatus.BAD_REQUEST.toString());
		response.setErrorMessage("Invalid inputs.");
		response.setErrors(ValidationUtil.fromBindingErrors(result));

		return new ResponseEntity<ExceptionResponse>(response, HttpStatus.BAD_REQUEST);
	}

	

	@ExceptionHandler(NullPointerException.class)
	public ResponseEntity<ExceptionResponse> nullPointerException(NullPointerException exception) {

		ExceptionResponse response = new ExceptionResponse();
		response.setErrorCode("500");
		response.setErrorMessage(exception.getMessage());
		// response.setErrors(ValidationUtil.fromBindingErrors(exception.getClass().getName()));
		return new ResponseEntity<ExceptionResponse>(response, HttpStatus.BAD_REQUEST);
	}
}
