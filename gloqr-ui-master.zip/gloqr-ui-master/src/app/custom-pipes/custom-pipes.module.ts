import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NamePipe } from './pipes/item-name';
import { IndianCurrencyPipe, DecimalPricePipe, CustomPricePipe, PrecisionPrice } from './pipes/currency';
import { TimeAgoPipe } from 'time-ago-pipe';
import { FeedBackMessagePipe } from './pipes/feedback-message';
import { ProductNamePipe } from './pipes/productName';
import { SMENamePipe } from './pipes/sme-name';
import { TrimNamePipe } from './pipes/trim-name';
import { SMEVacancyFilterName } from './pipes/sme-vacancy-filter-name';
import { SMEAddressPipe } from './pipes/sme-address';
import { SafeUrlPipe } from './pipes/safe-url';

export const PIPES = [
  NamePipe,
  IndianCurrencyPipe,
  DecimalPricePipe,
  TimeAgoPipe,
  FeedBackMessagePipe,
  ProductNamePipe,
  SMENamePipe,
  TrimNamePipe,
  SMEVacancyFilterName,
  SMEAddressPipe,
  SafeUrlPipe,
  CustomPricePipe,
  PrecisionPrice
]

@NgModule({
  declarations: [
    PIPES
  ],
  imports: [
    CommonModule,
  ],
  exports:[
    PIPES
  ]
})
export class CustomPipesModule { }
