import { PipeTransform, Pipe } from '@angular/core';

@Pipe({
    name: 'feedBackMsgPipe',
    pure: false
  })
export class FeedBackMessagePipe implements PipeTransform {

    transform(value: string, ...args: any[]) {

        if(value != null && value.length > 27){
            return value.slice(0,27) + '...'
        }
        return value
    }
}