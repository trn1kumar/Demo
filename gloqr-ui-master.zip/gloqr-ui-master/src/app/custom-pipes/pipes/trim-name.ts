import { Pipe, PipeTransform } from "@angular/core";

@Pipe({ name: 'trimNamePipe' })
export class TrimNamePipe implements PipeTransform {

    transform(value: string, ...args: any[]) {

        if(value != null && value.length >= args[0]){
            return value.slice(0,args[0]) + '...'
        }
        return value
    }

}