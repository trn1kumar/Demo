import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-job-seeker-applied-jobs',
  templateUrl: './job-seeker-applied-jobs.component.html',
  styleUrls: ['./job-seeker-applied-jobs.component.css']
})
export class JobSeekerAppliedJobsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
