import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-job-seeker-shortlisted-jobs',
  templateUrl: './job-seeker-shortlisted-jobs.component.html',
  styleUrls: ['./job-seeker-shortlisted-jobs.component.css']
})
export class JobSeekerShortlistedJobsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
