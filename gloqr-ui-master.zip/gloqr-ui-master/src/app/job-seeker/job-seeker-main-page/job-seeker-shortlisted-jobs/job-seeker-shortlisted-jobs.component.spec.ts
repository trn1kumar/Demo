import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JobSeekerShortlistedJobsComponent } from './job-seeker-shortlisted-jobs.component';

describe('JobSeekerShortlistedJobsComponent', () => {
  let component: JobSeekerShortlistedJobsComponent;
  let fixture: ComponentFixture<JobSeekerShortlistedJobsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JobSeekerShortlistedJobsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JobSeekerShortlistedJobsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
