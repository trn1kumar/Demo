import { Component, OnInit, Input } from '@angular/core';
import { JobApplicantDto } from '@models/jobs';
import { ShortListButtonDialogComponent } from '../short-list-button-dialog/short-list-button-dialog.component';
import { MatDialogRef, MatDialog, MatDialogConfig } from '@angular/material';
import { Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { environment } from 'environments/environment';

@Component({
  selector: 'app-job-seeker-detail-page',
  templateUrl: './job-seeker-detail-page.component.html',
  styleUrls: ['./job-seeker-detail-page.component.css']
})
export class JobSeekerDetailPageComponent implements OnInit {


  @Input()
  jobApplicantDto: JobApplicantDto
  contentServer: string = environment.CONTENT_SERVER
  shortListedInfoDialog: MatDialogRef<ShortListButtonDialogComponent>;
  subcription$: Subscription
  applicantUuid: string
  disableFlag: boolean
  constructor(private matDialog: MatDialog, private route: ActivatedRoute) { }

  ngOnInit() {
    this.subcription$ = this.route.queryParams.subscribe(
      params => {
        this.applicantUuid = params['vid']
      }
    )
  }

  onClickShortList() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.disableClose = true
    dialogConfig.width = '400px';
    dialogConfig.height = '400px'
    dialogConfig.data = { name: this.jobApplicantDto.applicant.fullName, applicantUuid: this.jobApplicantDto.applicantUuid }
    let ref = this.matDialog.open(ShortListButtonDialogComponent, dialogConfig);

    // ref.afterClosed().subscribe(
    //   res => {
    //     if (res) {
    //       this.jobApplicantDto.shortListed = true
    //     }
    //   }
    // )

  }
}