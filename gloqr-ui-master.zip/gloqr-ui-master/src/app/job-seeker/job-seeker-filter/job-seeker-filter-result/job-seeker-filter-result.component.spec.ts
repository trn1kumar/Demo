import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JobSeekerFilterResultComponent } from './job-seeker-filter-result.component';

describe('JobSeekerFilterResultComponent', () => {
  let component: JobSeekerFilterResultComponent;
  let fixture: ComponentFixture<JobSeekerFilterResultComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JobSeekerFilterResultComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JobSeekerFilterResultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
