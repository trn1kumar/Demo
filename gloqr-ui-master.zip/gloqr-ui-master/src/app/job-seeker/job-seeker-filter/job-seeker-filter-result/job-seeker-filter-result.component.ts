import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-job-seeker-filter-result',
  templateUrl: './job-seeker-filter-result.component.html',
  styleUrls: ['./job-seeker-filter-result.component.css']
})
export class JobSeekerFilterResultComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
