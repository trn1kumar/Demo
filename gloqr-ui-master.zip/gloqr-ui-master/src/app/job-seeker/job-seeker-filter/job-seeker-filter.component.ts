import { Component, OnInit } from '@angular/core';
import { JobSeeker } from '@models/jobs';
import { Subscription } from 'rxjs';
import { JobSeekerService } from '../job-seekers-services/job-seeker.service';
import { PageTitleService } from '@services/page-title/page-title.service';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-job-seeker-filter',
  templateUrl: './job-seeker-filter.component.html',
  styleUrls: ['./job-seeker-filter.component.css']
})
export class JobSeekerFilterComponent implements OnInit {

  jobSeeker: Array<JobSeeker>
  subscription: Subscription

  constructor(private jobSeekerService:JobSeekerService,private pageTitleService: PageTitleService,private router: Router) 
  { 
    this.subscription = router.events
    .pipe(filter(e => e instanceof NavigationEnd))
    .subscribe((e: NavigationEnd) => {
      this.jobSeekerDisplay(e.url)
    });
   }

  ngOnInit() {
    this.pageTitleService.updateTitle('Job-Seeker Filter');

  }
  jobSeekerDisplay(url: string) {

    // this.jobSeekerService.getAllJobs(url).subscribe(
    //   res => {
    //     if(!res.error)
    //     {
    //       this.jobSeeker = res.data
    //     }
    //   },
     
    // )
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
