import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JobSeekerFilterBreadcrumbsComponent } from './job-seeker-filter-breadcrumbs.component';

describe('JobSeekerFilterBreadcrumbsComponent', () => {
  let component: JobSeekerFilterBreadcrumbsComponent;
  let fixture: ComponentFixture<JobSeekerFilterBreadcrumbsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JobSeekerFilterBreadcrumbsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JobSeekerFilterBreadcrumbsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
