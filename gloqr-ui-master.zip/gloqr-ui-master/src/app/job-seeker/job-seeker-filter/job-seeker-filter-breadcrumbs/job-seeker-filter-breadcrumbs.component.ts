import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-job-seeker-filter-breadcrumbs',
  templateUrl: './job-seeker-filter-breadcrumbs.component.html',
  styleUrls: ['./job-seeker-filter-breadcrumbs.component.css']
})
export class JobSeekerFilterBreadcrumbsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
