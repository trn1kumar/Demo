import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-job-seeker-filter-left-side',
  templateUrl: './job-seeker-filter-left-side.component.html',
  styleUrls: ['./job-seeker-filter-left-side.component.css']
})
export class JobSeekerFilterLeftSideComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
