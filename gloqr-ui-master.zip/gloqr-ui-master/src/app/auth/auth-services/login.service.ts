import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CustomHttpResponse } from '@models/custom.response';
import { AuthToken, Credentials, OtpData } from '../models/auth';
import { environment } from 'environments/environment';
import { Observable } from 'rxjs';
import { shareReplay } from 'rxjs/operators';
import { ResetPassword } from '@models/user';
const CACHE_SIZE = 1;

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private userDetail$: Observable<any>

  private headers = new HttpHeaders({
    'Content-Type': 'application/json',
  })

  constructor(private http: HttpClient) { }

  login(credentials: Credentials) {
    return this.http.post<CustomHttpResponse<AuthToken>>(environment.USER_URL + 'login', credentials)
  }

  loginWithOTP(otpData: OtpData) {
    return this.http.post<CustomHttpResponse<AuthToken>>(environment.USER_URL + 'login/otp', otpData)
  }

  resetPassword(resetPass: ResetPassword, otp: string) {
    return this.http.post<CustomHttpResponse<any>>(environment.USER_URL + 'password/reset', resetPass, { params: { otp: otp } })
  }


  googleSocialLogin(data) {
    return this.http.post<CustomHttpResponse<any>>(environment.USER_URL + 'login/google', data)
  }

  facebookSocialLogin(fbdata) {
    return this.http.post<CustomHttpResponse<any>>(environment.USER_URL + 'login/facebook', fbdata)
  }

  public getUserVo(uuid: string) {
    if (!this.userDetail$) {
      this.userDetail$ = this.http.get<CustomHttpResponse<any>>(environment.USER_URL + uuid + '/basic-info').pipe(
        shareReplay(CACHE_SIZE)
      )
    }
    return this.userDetail$;
  }
}
