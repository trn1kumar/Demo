import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthRoutingModule } from './auth-routing.module';
import { AuthRouteComponent } from './auth-route/auth-route.component';
import { SignUpComponent } from './auth-route/sign-up/sign-up.component';
import { LoginComponent } from './auth-route/login/login.component';
import { OtpVerifyComponent } from './auth-route/otp-verify/otp-verify.component';
import { ForgotPasswordComponent } from './auth-route/forgot-password/forgot-password.component';
import { SocialLoginModule, AuthServiceConfig, FacebookLoginProvider, GoogleLoginProvider } from "angularx-social-login";
import { SocialLoginCredentials } from '@models/social-login-credentials';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatInputModule, MatButtonModule } from '@angular/material';


export function getAuthServiceConfigs() {
  const config = new AuthServiceConfig(
    [
      {
        id: FacebookLoginProvider.PROVIDER_ID,
        provider: new FacebookLoginProvider(SocialLoginCredentials.facebookClientId)
      },
      {
        id: GoogleLoginProvider.PROVIDER_ID,
        provider: new GoogleLoginProvider(SocialLoginCredentials.googleClientId)
      }
    ]
  );
  return config;
}

@NgModule({
  declarations: [
    AuthRouteComponent,
    SignUpComponent,
    LoginComponent,
    OtpVerifyComponent,
    ForgotPasswordComponent
  ],
  imports: [
    CommonModule,
    AuthRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    MatInputModule,
    MatButtonModule
  ],
  exports: [
    AuthRouteComponent,
    SocialLoginModule
  ],
  entryComponents: [
    AuthRouteComponent
  ],
  providers: [{
    provide: AuthServiceConfig,
    useFactory: getAuthServiceConfigs
  }],
})
export class AuthModule { }
