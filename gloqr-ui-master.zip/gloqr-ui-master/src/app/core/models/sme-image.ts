
export interface SMEImage
{
    imageLocation:string
    imageLocationOne: string
    imageLocationTwo: string
    imgUuid:string
    imageName: string
    fileLocation:string
    size:number
    source:string
    alt:string
    title:string,
    thumbnail:string
    
}

