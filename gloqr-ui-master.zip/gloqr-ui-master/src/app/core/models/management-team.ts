
export class SMEManagementTeam
{
    fullName : string
    designation : string
    experience : number
    fbLink : string
    linkedinLink : string
    teamUuid : string
    twitterLink : string
    mail:string
    active:boolean
    profileImageUrl:string;
    profileDesc:string
    isSelected:boolean
    frontFeedBackMessage:string
    totalFilesSize:number
    isApprove:boolean
    isReject:boolean
}