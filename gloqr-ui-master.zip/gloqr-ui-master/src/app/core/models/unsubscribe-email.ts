 class UnSubscribeEmail
{
    unSubscribeEmailId:string
    description:string
}