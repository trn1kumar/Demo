export interface JwtToken{
    name:string
    profileImage:string
    usertype:string
    smeid:string
    uuid:string
    sub:string
    Role:string,
    iat:Date
    exp:Date
}