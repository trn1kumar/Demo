import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminRouteComponent } from './admin-route/admin-route.component';
import { NewSmesComponent } from './admin-route/new-smes/new-smes.component';
import { DashboardComponent } from './admin-route/dashboard/dashboard.component';
import { ExistingSmesComponent } from './admin-route/existing-smes/existing-smes.component';
import { SmeBasicDetailsComponent } from './admin-route/object-verification/sme-basic-details/sme-basic-details.component';
import { BusinessPostsComponent } from './admin-route/object-verification/business-posts/business-posts.component';
import { CertificatesComponent } from './admin-route/object-verification/certificates/certificates.component';
import { GalleriesComponent } from './admin-route/object-verification/galleries/galleries.component';
import { InfrastructuresComponent } from './admin-route/object-verification/infrastructures/infrastructures.component';
import { ProductsComponent } from './admin-route/object-verification/products/products.component';
import { ServicesComponent } from './admin-route/object-verification/services/services.component';
import { ManagementTeamsComponent } from './admin-route/object-verification/management-teams/management-teams.component';
import { VacanciesComponent } from './admin-route/object-verification/vacancies/vacancies.component';
import { PackageDetailsComponent } from './admin-route/object-verification/package-details/package-details.component';
import { GloqrLoginComponent } from './gloqr-login/gloqr-login.component';
import { GloqrAdminGuardService } from './gloqr-admin-services/gloqr-admin-guard.service';

const routes: Routes = [
  { path: 'login', component: GloqrLoginComponent },
  {
    path: '', component: AdminRouteComponent,canActivate: [GloqrAdminGuardService] ,
    children: [
      { path: 'dashboard', component: DashboardComponent},
      { path: 'new-smes', component: NewSmesComponent },
      { path: 'existing-smes', component: ExistingSmesComponent },
      { path: ':baseComponentUrl/:sUuid/:uuid/sme-basic-details', component: SmeBasicDetailsComponent },
      { path: ':baseComponentUrl/:sUuid/:uuid/posts-verification', component: BusinessPostsComponent },
      { path: ':baseComponentUrl/:sUuid/:uuid/certificates-verification', component: CertificatesComponent },
      { path: ':baseComponentUrl/:sUuid/:uuid/galleries-verification', component: GalleriesComponent },
      { path: ':baseComponentUrl/:sUuid/:uuid/infrastructures-verification', component: InfrastructuresComponent },
      { path: ':baseComponentUrl/:sUuid/:uuid/products-verification', component: ProductsComponent },
      { path: ':baseComponentUrl/:sUuid/:uuid/services-verification', component: ServicesComponent },
      { path: ':baseComponentUrl/:sUuid/:uuid/teams-verification', component: ManagementTeamsComponent },
      { path: ':baseComponentUrl/:sUuid/:uuid/vacancies-verification', component: VacanciesComponent },
      { path: ':baseComponentUrl/:sUuid/:uuid/package-details', component: PackageDetailsComponent }
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GloqrAdminRoutingModule { }
