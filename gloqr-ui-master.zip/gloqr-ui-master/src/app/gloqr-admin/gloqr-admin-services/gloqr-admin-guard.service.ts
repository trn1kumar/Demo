import { Injectable } from '@angular/core';
import { GloqrAdminTokenService } from './gloqr-admin-token.service';
import { Router, CanActivate, CanLoad } from '@angular/router';
import { GloqrAdminModule } from '../gloqr-admin.module';

@Injectable({
  providedIn: GloqrAdminModule
})
export class GloqrAdminGuardService implements CanActivate {

  constructor(private token: GloqrAdminTokenService, private router: Router) { }

  canActivate(): boolean {
    if (this.token.checkLoggedIn()) {
      return true
    }
    this.router.navigate(['/gloqr-admin/login'])
  }
}
