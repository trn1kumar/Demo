import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Router } from '@angular/router';
import { GloqrAdminModule } from '../gloqr-admin.module';

const SUPER_TOKEN_KEY = 's_Token';

@Injectable({
  providedIn: GloqrAdminModule
})
export class GloqrAdminTokenService {

  private login: BehaviorSubject<boolean>;

  constructor(private router: Router) {
    if (localStorage.getItem(SUPER_TOKEN_KEY)) {
      this.login = new BehaviorSubject<boolean>(true)
    } else {
      this.login = new BehaviorSubject<boolean>(false)
    }
  }

  public isLoggedIn(): Observable<boolean> {
    return this.login.asObservable();
  }

  public checkLoggedIn(): boolean {
    return this.login.getValue();
  }

  public clearTokenAndLogout() {
    localStorage.removeItem(SUPER_TOKEN_KEY)
    this.login.next(false)
    this.router.navigate(['/'])
  }

  public setSuperAdminToken(token: string) {
    localStorage.setItem(SUPER_TOKEN_KEY, token)
    this.login.next(true)
  }

  public getSuperAdminToken(): string {
    return localStorage.getItem(SUPER_TOKEN_KEY)
  }
}
