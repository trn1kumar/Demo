import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { GloqrAdminTokenService } from '../gloqr-admin-services/gloqr-admin-token.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-route',
  templateUrl: './admin-route.component.html',
  styleUrls: ['./admin-route.component.css']
})
export class AdminRouteComponent implements OnInit {

  isLoggedIn: boolean
  options: FormGroup;
  constructor(fb: FormBuilder, private gloqrAdminTokenService: GloqrAdminTokenService,
    private router: Router) {
    this.options = fb.group({
      bottom: 1,
      fixed: true,
      top: 55
    });
  }

  ngOnInit() {
    this.gloqrAdminTokenService.isLoggedIn().subscribe(
      res => {
        this.isLoggedIn = res
      }
    )
  }

}
