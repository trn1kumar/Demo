import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SmeHomeHeaderComponent } from './sme-home-header/sme-home-header.component';
import { SmeHomeFooterComponent } from './sme-home-footer/sme-home-footer.component';
import { RouterModule } from '@angular/router';
import { ExternalModule } from 'app/external-modules/external.module';

@NgModule({
  declarations: [SmeHomeHeaderComponent, SmeHomeFooterComponent],
  imports: [
    CommonModule,
    ExternalModule,
    RouterModule
  ],
  exports: [
    SmeHomeHeaderComponent,
    SmeHomeFooterComponent]
})
export class SmeHomeLayoutModule { }
