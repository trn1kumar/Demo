import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sme-view-footer',
  templateUrl: './sme-view-footer.component.html',
  styleUrls: ['./sme-view-footer.component.css']
})
export class SmeViewFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
