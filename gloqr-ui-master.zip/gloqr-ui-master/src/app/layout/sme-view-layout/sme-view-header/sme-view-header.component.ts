import { Component, OnInit, Input } from '@angular/core';
import { environment } from 'environments/environment';
import { SMEInformationVo } from '@models/sme';

@Component({
  selector: 'app-sme-view-header',
  templateUrl: './sme-view-header.component.html',
  styleUrls: ['./sme-view-header.component.css']
})
export class SmeViewHeaderComponent implements OnInit {

  @Input()
  smes:SMEInformationVo;
  contentServer:string = environment.CONTENT_SERVER
  constructor() { }

  ngOnInit() {
  }

  scrolltoTop() {
    window.scrollTo(0, 0)
  }
}
