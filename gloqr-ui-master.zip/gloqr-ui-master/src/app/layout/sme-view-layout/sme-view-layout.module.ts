import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SmeViewHeaderComponent } from './sme-view-header/sme-view-header.component';
import { SmeViewFooterComponent } from './sme-view-footer/sme-view-footer.component';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    SmeViewHeaderComponent, 
    SmeViewFooterComponent],
  imports: [
    CommonModule,
    RouterModule
  ],
  exports:[
    SmeViewHeaderComponent,
    SmeViewFooterComponent
  ]
})
export class SmeViewLayoutModule { }
