import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MainHeaderComponent } from './main-header/main-header.component';
import { MainFooterComponent } from './main-footer/main-footer.component';
import { MainMenuBarComponent } from './main-menu-bar/main-menu-bar.component';
import { RouterModule } from '@angular/router';
import { ExternalModule } from 'app/external-modules/external.module';
@NgModule({
  declarations: [
    MainHeaderComponent,
    MainFooterComponent,
    MainMenuBarComponent,
  ],
  exports: [
    MainHeaderComponent, 
    MainFooterComponent, 
    MainMenuBarComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    ExternalModule
  ]
})
export class MainLayoutModule { }
