import { Component, OnInit, Input } from '@angular/core';
import { ServiceCategory } from '@models/service';
import { environment } from 'environments/environment';
import { NguCarouselConfig } from '@ngu/carousel';

@Component({
  selector: 'app-slider-four',
  templateUrl: './slider-four.component.html',
  styleUrls: ['./slider-four.component.css']
})
export class SliderFourComponent implements OnInit {

  @Input()
  serviceCategories: Array<ServiceCategory>
  contentServer: string = environment.CONTENT_SERVER

  carousel: NguCarouselConfig = {
    grid: { xs: 1, sm: 3, md: 5, lg: 6, all: 0 },
    slide: 3,
    speed: 150,
    point: {
      visible: false
    },
    load: 6,
  }
  
  constructor() { }

  ngOnInit() {
  }

}
