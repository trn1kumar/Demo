import { Component, OnInit } from '@angular/core';
import { ServiceResponse, ServiceCategory } from '@models/service';
import { ProductResponse, ProductCategory } from '@models/product';
import { HomeService } from '@services/home/home.service';
import { TokenService } from '@services/token/token.service';
import { SME } from '@models/sme';
import { JobView } from '@models/jobs';

@Component({
  selector: 'app-all-route',
  templateUrl: './all-route.component.html',
  styleUrls: ['./all-route.component.css']
})
export class AllRouteComponent implements OnInit {

  services: Array<ServiceResponse>
  products: Array<ProductResponse>
  smes: Array<SME>;
  productCategories: Array<ProductCategory>
  serviceCategories: Array<ServiceCategory>
  jobs: Array<JobView>
  sUuid: string
  constructor(private token: TokenService, private homePage: HomeService) { }

  ngOnInit() {

    if (this.token.isLoggedIn()) {
      let userUUID: string = this.token.getUserId()

      if (this.token.isSME()) {
        this.sUuid = this.token.getSmeId()
        this.homePage.topSmesWithLogin().subscribe(
          res => {
            if (!res.error) {
              this.smes = res.data
            }
          }
        )
      }

      if (this.token.isNormalUser()) {
        this.homePage.topSmes().subscribe(
          res => {
            if (!res.error) {
              this.smes = res.data
            }
          }
        )
      }

      // if (this.token.isNormalUser()) {
      //   this.homePage.topJobs().subscribe(
      //     res => {
      //       if (!res.error) {
      //         this.jobs = res.data
      //       }
      //     }
      //   )
      // }

    } else {
      this.homePage.topSmes().subscribe(
        res => {
          if (!res.error) {
            this.smes = res.data
          }

        }
      )
  
    }

    this.homePage.services().subscribe(
      res => {
        if (!res.error) {
          this.services = res.data
        }
      }
    )
    this.homePage.topProducts().subscribe(
      res => {
        if (!res.error) {
          this.products = res.data
        }
      }
    )
    
    this.homePage.productCategoriesObservable().subscribe(
      res => {
        if (!res.error) {
          this.productCategories = res.data
        }
      }
    )
    this.homePage.serviceCategoriesObservable().subscribe(
      res => {
        if (!res.error) {
          this.serviceCategories = res.data
        }
      }
    )
    this.homePage.topJobs().subscribe(
      res => {
        if (!res.error) {
          this.jobs = res.data
        }
      }
    )
  }

}
