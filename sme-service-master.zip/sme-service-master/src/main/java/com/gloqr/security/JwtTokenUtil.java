package com.gloqr.security;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.gloqr.exception.CustomException;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;

@Component
public class JwtTokenUtil {

	public Claims getAllClaimsFromToken(String token) {
		Claims claims = null;
		try {
			claims = Jwts.parser().setSigningKey(JWTConstants.SIGNING_KEY).parseClaimsJws(token).getBody();
		} catch (ExpiredJwtException e) {
			throw new CustomException("Token is Expired...Relogin to proceed :: " + e.getMessage(),
					HttpStatus.BAD_REQUEST, e);
		} catch (SignatureException | MalformedJwtException e) {
			throw new CustomException("Invalid Token :: " + e.getMessage(), HttpStatus.BAD_REQUEST, e);
		} catch (Exception e) {
			throw new CustomException("Internal Error while parsing token ", e);
		}
		return claims;
	}

}
