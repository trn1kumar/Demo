package com.gloqr.util;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gloqr.security.JWTConstants;
import com.gloqr.security.JwtTokenUtil;

import io.jsonwebtoken.Claims;

@Component
public class RequestParser {

	@Autowired
	private HttpServletRequest httpRequest;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	protected Claims getClaims() {
		String header = httpRequest.getHeader(JWTConstants.HEADER_STRING);
		String authToken = header.replace(JWTConstants.TOKEN_PREFIX, "");
		return jwtTokenUtil.getAllClaimsFromToken(authToken);
	}

	public String getUserUUID() {
		return (String) getClaims().get(JWTConstants.USER_ID);
	}

	public String getSuuid() {
		return (String) getClaims().get(JWTConstants.SME_ID);
	}

	public String getHeader() {
		return httpRequest.getHeader(JWTConstants.HEADER_STRING);
	}

	public boolean isLoggedIn() {
		return StringUtils.isNotBlank(httpRequest.getHeader(JWTConstants.HEADER_STRING));
	}
}
