package com.gloqr.constants;

public class URLMapping {

	private URLMapping() {
		super();
	}

	public static final String BASE_URL = "api/services";

	// Admin Controller
	public static final String BASE_URL_ADMIN = BASE_URL + "/admin";

	public static final String CATEGORY = "categories";
	public static final String SUBCATEGORY = "categories/{categoryUuid}/subcategories";
	public static final String SPECIFICATION = "subcategories/{subCategoryUuid}/specifications";
	public static final String PRICE_UNIT = "price-units";
	public static final String SERVICE_STATE = "state";
	public static final String SERVICE_IMAGES = "images";
	public static final String SME_PENDING_SERVICES = "sme/{sUuid}/pending";
	public static final String SME_PENDING_SERVICES_COUNT = "count";
	public static final String UPDATE_COUNTS = "update-counts";

	// File Controller
	public static final String MULTIPLE_FILE = "files";
	public static final String SINGLE_FILE = "file";

	// Product Controller
	public static final String SERVICE = "service";
	public static final String TOP_SERVICES = "top";
	public static final String SIMILAR_SERVICES = "similar";
	public static final String SERVICE_BY_UUID = "{serviceUuid}/service";
	public static final String SERVICE_FOR_UPDATE = "{serviceUuid}/service-details";
	public static final String SERVICE_BI_COUNT = "{serviceUuid}/bi-count";
	public static final String SME_SERVICES_COUNT = "sme/{sUuid}/count";
	public static final String SME_SERVICES = "sme";
	public static final String SME_SERVICES_VIEW = "{sUuid}/sme";
	public static final String BUSINESS_POST_IMAGE = "post-images";
	public static final String AUTO_QUOTATION = "{serviceUuid}/auto-quotation";

	// Search Controller
	public static final String SERVICES_BY_CATEGORY = "{categoryName}";
	public static final String SERVICES_BY_SUBCATEGORY = "{categoryName}/{subCategoryName}";
	public static final String SEARCH_SUGGEST = "search-suggests";
	public static final String SEARCH_RESULT = "search/s";

	// Category Controller
	public static final String NAV_CATEGORIES = "nav-categories";
}
