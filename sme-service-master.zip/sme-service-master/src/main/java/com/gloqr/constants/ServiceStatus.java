package com.gloqr.constants;

public enum ServiceStatus {

	ACTIVE,DEACTIVE;
}
