package com.gloqr.constants;

public enum ServiceState {
	PENDING, APPROVED, REJECTED, DELETED
}
