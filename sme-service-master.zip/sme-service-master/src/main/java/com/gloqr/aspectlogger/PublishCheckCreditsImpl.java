package com.gloqr.aspectlogger;

import java.util.Optional;
import java.util.Set;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.gloqr.constants.ServiceStatus;
import com.gloqr.dto.PublishData;
import com.gloqr.exception.CreditType;
import com.gloqr.exception.CustomException;
import com.gloqr.exception.NoCreditException;
import com.gloqr.service.PricingService;

@Aspect
@Configuration
public class PublishCheckCreditsImpl {

	@Autowired
	private PricingService pricingService;

	@Before("execution(* com.gloqr.controller.*.*(..)) && @annotation(publishCheckCredits) && args(data)")
	public void beforeMethodExecution(JoinPoint joinPoint, PublishCheckCredits publishCheckCredits,
			Set<PublishData> data) {

		Optional<PublishData> publishData = null;

		try {
			publishData = data.stream().findFirst();

			if (publishData.isPresent() && publishData.get().getSmeAction().equals(ServiceStatus.ACTIVE)
					&& pricingService.checkListingCredits() < data.size()) {
				throw new NoCreditException(CreditType.PRODUCT_SERVICE_LISTING);
			}

		} catch (CustomException e) {
			throw e;
		}

	}
}
