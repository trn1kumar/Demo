package com.gloqr.aspectlogger;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.gloqr.dto.ImageDTO;
import com.gloqr.dto.ServiceDTO;
import com.gloqr.exception.CreditType;
import com.gloqr.exception.CustomException;
import com.gloqr.exception.NoCreditException;
import com.gloqr.service.PricingService;

@Aspect
@Configuration
public class CheckCreditsImpl {

	@Autowired
	private PricingService pricingService;

	@Before("execution(* com.gloqr.controller.*.*(..)) && @annotation(checkCredits) && args(serviceDTO)")
	public void beforeMethodExecution(JoinPoint joinPoint, CheckCredits checkCredits, ServiceDTO serviceDTO) {
		long totalImagesSize = 0;

		try {
			if (serviceDTO.getImages() != null && !serviceDTO.getImages().isEmpty()) {
				for (ImageDTO image : serviceDTO.getImages()) {
					totalImagesSize += image.getSize();
				}

				if (pricingService.checkImageCredits() < totalImagesSize) {
					throw new NoCreditException(CreditType.IMAGE_STORAGE);
				}
			}

			if (serviceDTO.isActive()) {
				pricingService.checkListingCredits();
			}

		} catch (CustomException e) {
			throw new CustomException(e.getMessage(), e.getStatus());
		}
	}

}
