package com.gloqr.filter;

import java.io.Serializable;
import java.util.List;

import com.gloqr.responses.ServiceResponse;

public class ServiceFilter implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<ServiceResponse> result;
	private long totalCount;

	public ServiceFilter() {

	}

	public ServiceFilter(List<ServiceResponse> result, long totalCount) {
		this.result = result;
		this.totalCount = totalCount;
	}

	public List<ServiceResponse> getResult() {
		return result;
	}

	public long getTotalCount() {
		return totalCount;
	}

	public void setResult(List<ServiceResponse> result) {
		this.result = result;
	}

	public void setTotalCount(long totalCount) {
		this.totalCount = totalCount;
	}

}
