package com.gloqr.filter;

import java.io.Serializable;

public class PriceFilter implements Serializable {

	private static final long serialVersionUID = 1L;

	private Double minPrice;
	private Double maxPrice;
	private Double selectedMinPrice;
	private Double selectedMaxPrice;

	public PriceFilter(Double minPrice, Double maxPrice) {
		super();
		this.minPrice = minPrice;
		this.maxPrice = maxPrice;
		this.selectedMinPrice = minPrice;
		this.selectedMaxPrice = maxPrice;
	}

	public Double getMinPrice() {
		return Math.floor(minPrice);
	}

	public Double getMaxPrice() {
		return Math.floor(maxPrice);
	}

	public Double getSelectedMinPrice() {
		return Math.floor(selectedMinPrice);
	}

	public Double getSelectedMaxPrice() {
		return Math.floor(selectedMaxPrice);
	}

	public void setSelectedMinPrice(Double selectedMinPrice) {
		this.selectedMinPrice = selectedMinPrice;
	}

	public void setSelectedMaxPrice(Double selectedMaxPrice) {
		this.selectedMaxPrice = selectedMaxPrice;
	}

}
