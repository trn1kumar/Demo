package com.gloqr.filter;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class Filter implements Serializable {

	private static final long serialVersionUID = 1L;

	private PriceFilter priceFilter;
	private List<SmeNameFilter> smeFilter;
	private Map<String, DiscountFilter> discountFilter;

	public Filter(List<SmeNameFilter> smeNameFilters) {
		this.smeFilter = smeNameFilters;
	}

	public Filter() {

	}

	public Map<String, DiscountFilter> getDiscountFilter() {
		return discountFilter;
	}

	public void setDiscountFilter(Map<String, DiscountFilter> discountFilter) {
		this.discountFilter = discountFilter;
	}

	public PriceFilter getPrice() {
		return priceFilter;
	}

	public void setPrice(PriceFilter priceFilter) {
		this.priceFilter = priceFilter;
	}

	public List<SmeNameFilter> getSmeFilter() {
		return smeFilter;
	}

	public void setSmeFilter(List<SmeNameFilter> smeFilter) {
		this.smeFilter = smeFilter;
	}

}
