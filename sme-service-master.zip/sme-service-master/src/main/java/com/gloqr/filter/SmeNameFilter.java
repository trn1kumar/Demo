package com.gloqr.filter;

import java.io.Serializable;

public class SmeNameFilter implements Serializable {

	private static final long serialVersionUID = 1L;

	private String smeName;
	private String sUuid;
	private boolean selected;
	private int count;

	public SmeNameFilter() {
		super();
	}

	public SmeNameFilter(String smeName, int count, boolean selected) {
		super();
		this.smeName = smeName;
		this.count = count;
		this.selected = selected;
	}

	public String getSmeName() {
		return smeName;
	}

	public String getsUuid() {
		return sUuid;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public int getCount() {
		return count;
	}
}
