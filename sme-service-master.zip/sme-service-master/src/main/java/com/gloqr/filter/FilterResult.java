package com.gloqr.filter;

public class FilterResult {

	private Filter filter;
	private ServiceFilter response;
	private Object category;

	public FilterResult() {
		super();
	}

	public FilterResult(Filter filter, ServiceFilter response) {
		super();
		this.filter = filter;
		this.response = response;
	}

	public Object getCategory() {
		return category;
	}

	public void setCategory(Object category) {
		this.category = category;
	}

	public Filter getFilter() {
		return filter;
	}

	public ServiceFilter getResponse() {
		return response;
	}

	public void setFilter(Filter filter) {
		this.filter = filter;
	}

	public void setResponse(ServiceFilter response) {
		this.response = response;
	}

}
