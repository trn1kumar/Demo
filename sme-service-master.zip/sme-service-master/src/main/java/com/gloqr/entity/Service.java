package com.gloqr.entity;

import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.lucene.analysis.core.LowerCaseFilterFactory;
import org.apache.lucene.analysis.ngram.EdgeNGramFilterFactory;
import org.apache.lucene.analysis.snowball.SnowballPorterFilterFactory;
import org.apache.lucene.analysis.standard.StandardTokenizerFactory;
import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Analyzer;
import org.hibernate.search.annotations.AnalyzerDef;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Facet;
import org.hibernate.search.annotations.FacetEncodingType;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.FieldBridge;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;
import org.hibernate.search.annotations.Parameter;
import org.hibernate.search.annotations.SortableField;
import org.hibernate.search.annotations.TokenFilterDef;
import org.hibernate.search.annotations.TokenizerDef;
import org.hibernate.search.bridge.builtin.IntegerBridge;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.gloqr.constants.QuotationFormat;
import com.gloqr.constants.ServiceState;

@Entity
@Table(name = "Service_Master")
@Indexed
@AnalyzerDef(name = "customanalyzer", tokenizer = @TokenizerDef(factory = StandardTokenizerFactory.class), filters = {
		@TokenFilterDef(factory = LowerCaseFilterFactory.class),
		@TokenFilterDef(factory = SnowballPorterFilterFactory.class, params = {
				@Parameter(name = "language", value = "English"), }), })
@AnalyzerDef(name = "nGramAnalyzer", tokenizer = @TokenizerDef(factory = StandardTokenizerFactory.class), filters = {
		@TokenFilterDef(factory = LowerCaseFilterFactory.class),
		@TokenFilterDef(factory = SnowballPorterFilterFactory.class, params = {
				@Parameter(name = "language", value = "English"), }),
		@TokenFilterDef(factory = EdgeNGramFilterFactory.class, params = {
				@Parameter(name = "maxGramSize", value = "25"), @Parameter(name = "minGramSize", value = "2") }) })
public class Service extends Audit {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Service_ID")
	@DocumentId
	private Long serviceID;

	@Column(name = "Service_UUID", unique = true, nullable = false)
	private String serviceUuid;

	@Column(name = "Service_Url_Name")
	private String serviceUrlName;

	@Column(name = "Service_Name", nullable = false, length = 200)
	@Field
	@Analyzer(definition = "nGramAnalyzer")
	private String serviceName;

	@Column(name = "SME_Name", nullable = false)
	@Field(analyze = Analyze.NO)
	@Facet
	private String smeName;

	@Column(name = "SME_UUID", nullable = false, updatable = false)
	@Field(analyze = Analyze.NO)
	@Facet
	private String sUuid;

	@Column(name = "Service_Description", length = 2000, nullable = false)
	private String description;

	@Column(name = "Available_Location", length = 300)
	private String location;

	@Column(name = "Terms_Condition", length = 2000)
	private String termsAndCondition;

	@Column(columnDefinition = "TEXT")
	private String feedbackMessage;

	@Column(name = "Main_Image", nullable = false)
	private String mainImage;

	@Column(name = "Price_Unit")
	private String priceUnit;

	@Column(name = "Service_Price", nullable = false, columnDefinition = "DOUBLE(9,2) UNSIGNED")
	private Double price;

	@Column(name = "Discount", length = 3, columnDefinition = "INT UNSIGNED")
	@Field(name = "discountFacet", analyze = Analyze.NO, bridge = @FieldBridge(impl = IntegerBridge.class))
	@Field(analyze = Analyze.NO)
	@Facet(encoding = FacetEncodingType.STRING)
	private int discount;

	@Column(name = "Discounted_Price", columnDefinition = "DOUBLE(9,2) UNSIGNED")
	@Field
	@SortableField
	private Double discountedPrice;

	@Column(name = "GST", columnDefinition = "FLOAT UNSIGNED")
	private float gst;

	@Column(name = "bicount", columnDefinition = "INT UNSIGNED")
	@Field
	@SortableField
	private int biCount;

	@Column(name = "is_Active")
	@Field
	private boolean active;

	@Column(name = "Modified")
	public boolean modified;

	@Column(name = "Bussiness_Post")
	private boolean businessPost;

	@Column(name = "Business_Post_Activated")
	private boolean businessPostActivated;

	@Column(name = "Auto_Quotation")
	private boolean autoQuotation;

	@ElementCollection(fetch = FetchType.LAZY)
	@CollectionTable(name = "Service_Specifications")
	@MapKeyColumn(name = "Name", nullable = false)
	@Column(name = "Value", nullable = false)
	private Map<String, String> specifications;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "Service_ID")
	private List<ServiceImage> images;

	@Column(name = "Service_State")
	@Enumerated(EnumType.STRING)
	@Field
	private ServiceState serviceState;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SubCategory_ID")
	@JsonIgnoreProperties("services")
	@IndexedEmbedded(includeEmbeddedObjectId = true)
	private ServiceSubCategory subCategory;

	@Column(name = "Quotation_Format")
	@Enumerated(EnumType.STRING)
	private QuotationFormat quotationFormat;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "Other_Category_ID")
	private OtherCategory otherCategory;

	@Transient
	private boolean addedToCart;

	public boolean isAutoQuotation() {
		return autoQuotation;
	}

	public void setAutoQuotation(boolean autoQuotation) {
		this.autoQuotation = autoQuotation;
	}

	public Long getServiceID() {
		return serviceID;
	}

	public String getServiceUuid() {
		return serviceUuid;
	}

	public String getServiceUrlName() {
		return serviceUrlName;
	}

	public String getServiceName() {
		return serviceName;
	}

	public String getSmeName() {
		return smeName;
	}

	public String getsUuid() {
		return sUuid;
	}

	public String getDescription() {
		return description;
	}

	public String getLocation() {
		return location;
	}

	public String getTermsAndCondition() {
		return termsAndCondition;
	}

	public String getFeedbackMessage() {
		return feedbackMessage;
	}

	public String getMainImage() {
		return mainImage;
	}

	public String getPriceUnit() {
		return priceUnit;
	}

	public Double getPrice() {
		return price;
	}

	public int getDiscount() {
		return discount;
	}

	public Double getDiscountedPrice() {
		return discountedPrice;
	}

	public float getGst() {
		return gst;
	}

	public int getBiCount() {
		return biCount;
	}

	public boolean isActive() {
		return active;
	}

	public boolean isModified() {
		return modified;
	}

	public boolean isBusinessPost() {
		return businessPost;
	}

	public boolean isBusinessPostActivated() {
		return businessPostActivated;
	}

	public Map<String, String> getSpecifications() {
		return specifications;
	}

	public List<ServiceImage> getImages() {
		return images;
	}

	public ServiceState getServiceState() {
		return serviceState;
	}

	public ServiceSubCategory getSubCategory() {
		return subCategory;
	}

	public QuotationFormat getQuotationFormat() {
		return quotationFormat;
	}

	public boolean isAddedToCart() {
		return addedToCart;
	}

	public void setServiceID(Long serviceID) {
		this.serviceID = serviceID;
	}

	public void setServiceUuid(String serviceUuid) {
		this.serviceUuid = serviceUuid;
	}

	public void setServiceUrlName(String serviceUrlName) {
		this.serviceUrlName = serviceUrlName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public void setTermsAndCondition(String termsAndCondition) {
		this.termsAndCondition = termsAndCondition;
	}

	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}

	public void setMainImage(String mainImage) {
		this.mainImage = mainImage;
	}

	public void setPriceUnit(String priceUnit) {
		this.priceUnit = priceUnit;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}

	public void setDiscountedPrice(Double discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

	public void setGst(float gst) {
		this.gst = gst;
	}

	public void setBiCount(int biCount) {
		this.biCount = biCount;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setModified(boolean modified) {
		this.modified = modified;
	}

	public void setBusinessPost(boolean businessPost) {
		this.businessPost = businessPost;
	}

	public void setBusinessPostActivated(boolean businessPostActivated) {
		this.businessPostActivated = businessPostActivated;
	}

	public void setSpecifications(Map<String, String> specifications) {
		this.specifications = specifications;
	}

	public void setImages(List<ServiceImage> images) {
		this.images = images;
	}

	public void setServiceState(ServiceState serviceState) {
		this.serviceState = serviceState;
	}

	public void setSubCategory(ServiceSubCategory subCategory) {
		this.subCategory = subCategory;
	}

	public void setQuotationFormat(QuotationFormat quotationFormat) {
		this.quotationFormat = quotationFormat;
	}

	public void setAddedToCart(boolean addedToCart) {
		this.addedToCart = addedToCart;
	}

	public OtherCategory getOtherCategory() {
		return otherCategory;
	}

	public void setOtherCategory(OtherCategory otherCategory) {
		this.otherCategory = otherCategory;
	}

}
