package com.gloqr.entity;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.IndexedEmbedded;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "Service_SubCatgory")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class ServiceSubCategory extends Audit {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SubCategory_ID")
	private Long subCategoryID;

	@Column(name = "SubCategory_UUID", unique = true, nullable = false, updatable = false)
	@Field(analyze = Analyze.NO)
	private String subCategoryUuid;

	@Column(name = "SubCategory_Name", unique = true, nullable = false, length = 200)
	private String subCategoryName;

	@Column(name = "SubCategoryUrlName", nullable = false, length = 200)
	private String urlName;

	@Column(name = "SubCategoryIsActive")
	private boolean active;

	@Column(name = "SubCategory_Image_Location")
	private String fileLocation;

	@Column(name = "Services_Count", columnDefinition = "BIGINT(20) UNSIGNED")
	private long servicesCount;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "Category_ID", nullable = false)
	@JsonIgnoreProperties("subCategories")
	@IndexedEmbedded(includeEmbeddedObjectId = true)
	private ServiceCategory serviceCategory;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "SubCategory_ID", nullable = false)
	private Set<MasterSpecification> specifications;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "subCategory")
	@JsonIgnoreProperties("subCategory")
	private List<Service> services;

	public Long getSubCategoryID() {
		return subCategoryID;
	}

	public String getSubCategoryUuid() {
		return subCategoryUuid;
	}

	public String getSubCategoryName() {
		return subCategoryName;
	}

	public String getUrlName() {
		return urlName;
	}

	public boolean isActive() {
		return active;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public long getServicesCount() {
		return servicesCount;
	}

	public ServiceCategory getServiceCategory() {
		return serviceCategory;
	}

	public Set<MasterSpecification> getSpecifications() {
		return specifications;
	}

	public List<Service> getServices() {
		return services;
	}

	public void setSubCategoryID(Long subCategoryID) {
		this.subCategoryID = subCategoryID;
	}

	public void setSubCategoryUuid(String subCategoryUuid) {
		this.subCategoryUuid = subCategoryUuid;
	}

	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}

	public void setUrlName(String urlName) {
		this.urlName = urlName;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

	public void setServicesCount(long servicesCount) {
		this.servicesCount = servicesCount;
	}

	public void setServiceCategory(ServiceCategory serviceCategory) {
		this.serviceCategory = serviceCategory;
	}

	public void setSpecifications(Set<MasterSpecification> specifications) {
		this.specifications = specifications;
	}

	public void setServices(List<Service> services) {
		this.services = services;
	}

}
