package com.gloqr.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name = "Service_Image")
public class ServiceImage extends Audit {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Image_ID")
	private Long imageID;

	@Column(name = "Main_Image")
	private boolean mainImage;

	@Column(name = "Image_Location", nullable = false)
	private String fileLocation;

	@Column(name = "Image_Location_One")
	private String fileLocationOne;

	@Column(name = "Image_Location_Two")
	private String fileLocationTwo;

	@Column(name = "Image_Size")
	private long size;

	@Column(name = "Image_Is_Active")
	private boolean active;

	@Column(name = "Business_Post_Image")
	private boolean businessPostImage;

	public ServiceImage(String fileLocation) {
		super();
		this.fileLocation = fileLocation;
	}

	public String getFileLocationOne() {
		return fileLocationOne;
	}

	public void setFileLocationOne(String fileLocationOne) {
		this.fileLocationOne = fileLocationOne;
	}

	public String getFileLocationTwo() {
		return fileLocationTwo;
	}

	public void setFileLocationTwo(String fileLocationTwo) {
		this.fileLocationTwo = fileLocationTwo;
	}

	public boolean isBusinessPostImage() {
		return businessPostImage;
	}

	public void setBusinessPostImage(boolean businessPostImage) {
		this.businessPostImage = businessPostImage;
	}

	public ServiceImage() {
		super();
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public long getSize() {
		return size;
	}

	public void setSize(long size) {
		this.size = size;
	}

	public boolean isMainImage() {
		return mainImage;
	}

	public void setMainImage(boolean mainImage) {
		this.mainImage = mainImage;
	}

	public Long getImageID() {
		return imageID;
	}

	public void setImageID(Long imageID) {
		this.imageID = imageID;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

}
