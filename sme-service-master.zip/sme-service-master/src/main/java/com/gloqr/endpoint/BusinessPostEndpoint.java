package com.gloqr.endpoint;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.gloqr.dto.PublishData;
import com.gloqr.dto.PublishFeed;
import com.gloqr.exception.CustomException;
import com.gloqr.responses.CustomHttpResponse;
import com.gloqr.security.JWTConstants;
import com.gloqr.util.RequestParser;

public class BusinessPostEndpoint {
	Logger logger = LogManager.getLogger();

	private Client client;
	private String businessPostEndpointURL;
	private String createFeed;
	String updateStatus;

	@Autowired
	private RequestParser requestParser;

	public BusinessPostEndpoint(Client client, String businessPostEndpointURL, String createFeed, String updateStatus) {
		super();
		this.client = client;
		this.businessPostEndpointURL = businessPostEndpointURL;
		this.createFeed = createFeed;
		this.updateStatus = updateStatus;
	}

	public void createBusinessPost(PublishFeed feed) {

		Response response = null;
		try {
			response = client.target(businessPostEndpointURL).path(createFeed).queryParam("publishedPost", true)
					.request(MediaType.APPLICATION_JSON).header(JWTConstants.HEADER_STRING, requestParser.getHeader())
					.post(Entity.entity(feed, MediaType.APPLICATION_JSON));

			logger.info("Response from Business Post enpoint :: " + response.toString());

			if (response.getStatus() == HttpStatus.OK.value()) {
				logger.info("Business Post Successfully Created");
			} else {
				logger.info("Reason :: " + response.getStatusInfo().getReasonPhrase());
			}

		} catch (Exception e) {
			throw new CustomException(e.getMessage(), e);
		}

	}

	public void updateBusinessPostStatus(List<PublishData> postedProducts) {

		Response response = null;
		try {
			response = client.target(businessPostEndpointURL).path(updateStatus).request(MediaType.APPLICATION_JSON)
					.header(JWTConstants.HEADER_STRING, requestParser.getHeader())
					.put(Entity.entity(postedProducts, MediaType.APPLICATION_JSON));

			logger.info("Response from Business Post enpoint :: " + response.toString());

			CustomHttpResponse<?> res = response.readEntity(new GenericType<CustomHttpResponse<?>>() {
			});

			if (!res.isError()) {
				logger.info("Business Post Activated Successfully");
			} else {
				logger.info("Reason :: " + response.getStatusInfo().getReasonPhrase());
			}

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
}
