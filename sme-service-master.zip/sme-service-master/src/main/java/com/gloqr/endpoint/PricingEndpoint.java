package com.gloqr.endpoint;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.gloqr.dto.CreditsCheckResponse;
import com.gloqr.dto.PricingRequest;
import com.gloqr.exception.CreditType;
import com.gloqr.exception.CustomException;
import com.gloqr.exception.NoCreditException;
import com.gloqr.responses.CustomHttpResponse;
import com.gloqr.security.JWTConstants;
import com.gloqr.util.RequestParser;

public class PricingEndpoint {

	Logger logger = LogManager.getLogger();

	private Client client;
	private String pricingEnpointUrl;
	private String creditsPath;
	private String adminUpdateCreditsPath;

	@Autowired
	private RequestParser requestParser;

	public PricingEndpoint(Client client, String pricingEnpointUrl, String creditsPath, String adminUpdateCreditsPath) {
		super();
		this.client = client;
		this.pricingEnpointUrl = pricingEnpointUrl;
		this.creditsPath = creditsPath;
		this.adminUpdateCreditsPath = adminUpdateCreditsPath;
	}

	public long checkCredits(CreditType creditType) {

		logger.info("Checking Credits from Pricing API for " + creditType);

		Response response = null;
		CustomHttpResponse<CreditsCheckResponse> httpResponse = null;
		try {
			response = client.target(pricingEnpointUrl).path(creditsPath).queryParam("type", creditType)
					.request(MediaType.APPLICATION_JSON).header(JWTConstants.HEADER_STRING, requestParser.getHeader())
					.get();

			logger.info("Response from Pricing enpoint :: " + response.toString());

		} catch (Exception e) {
			throw new CustomException("Internal Server Error While Checking Credits :: " + e.getMessage(), e);
		}

		httpResponse = response.readEntity(new GenericType<CustomHttpResponse<CreditsCheckResponse>>() {
		});

		if (httpResponse.isError() && httpResponse.getCode() == HttpStatus.PAYMENT_REQUIRED.value()) {
			throw new NoCreditException(creditType);
		} else {
			return httpResponse.getData().getCredits();
		}
	}

	public void updateCredits(PricingRequest pricingRequest) {
		String url = null;

		if (StringUtils.isNotBlank(pricingRequest.getsUuid()) && StringUtils.isNotBlank(pricingRequest.getUserUUID())) {
			url = adminUpdateCreditsPath;
		} else {
			url = creditsPath;
		}

		logger.info("Updating Credits :: " + pricingRequest.toString());

		Response response = null;

		try {
			logger.info("URI:: {} {}", pricingEnpointUrl, url);
			response = client.target(pricingEnpointUrl).path(url).request(MediaType.APPLICATION_JSON)
					.header(JWTConstants.HEADER_STRING, requestParser.getHeader())
					.put(Entity.entity(pricingRequest, MediaType.APPLICATION_JSON));

			logger.info("Response from Pricing enpoint :: " + response.toString());

		} catch (Exception e) {
			throw new CustomException("Internal Server Error While Updating Credits :: " + e.getMessage(), e);
		}

		CustomHttpResponse<?> httpResponse = response.readEntity(new GenericType<CustomHttpResponse<?>>() {
		});

		if (httpResponse.isError() && httpResponse.getCode() == HttpStatus.PAYMENT_REQUIRED.value()) {
			throw new NoCreditException(pricingRequest.getCreditType());
		}

	}
}
