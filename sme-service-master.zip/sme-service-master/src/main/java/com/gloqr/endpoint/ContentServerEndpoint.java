package com.gloqr.endpoint;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.glassfish.jersey.media.multipart.MultiPart;
import org.glassfish.jersey.media.multipart.file.FileDataBodyPart;
import org.springframework.http.HttpStatus;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.exception.CustomException;
import com.gloqr.responses.FileUploadResponse;

public class ContentServerEndpoint {

	Logger logger = LogManager.getLogger();

	private Client client;
	private String contentServerEndPointURL;
	private String singleFile;
	private String uploadMultipleFiles;
	private String deleteFile;

	public ContentServerEndpoint(Client client, String contentServerEndPointURL, String singleFile,
			String uploadMultipleFiles, String deleteFile) {
		super();
		this.client = client;
		this.contentServerEndPointURL = contentServerEndPointURL;
		this.singleFile = singleFile;
		this.uploadMultipleFiles = uploadMultipleFiles;
		this.deleteFile = deleteFile;
	}

	public List<FileUploadResponse> sendFilesToContentServer(List<MultipartFile> multipartFiles,
			List<String> imageNames, String fileLocation) throws IOException {
		Response response = null;
		List<File> files = null;
		int i = 0;

		WebTarget webTarget = client.target(contentServerEndPointURL).path(uploadMultipleFiles).path(fileLocation);

		try (MultiPart multiPart = new MultiPart()) {

			multiPart.setMediaType(MediaType.MULTIPART_FORM_DATA_TYPE);
			files = new ArrayList<>();
			for (MultipartFile file : multipartFiles) {
				File tmpfile = convert(file, imageNames.get(i++));
				FileDataBodyPart fileDataBodyPart = new FileDataBodyPart("files", tmpfile,
						MediaType.APPLICATION_OCTET_STREAM_TYPE);
				multiPart.bodyPart(fileDataBodyPart);
				files.add(tmpfile);
			}

			response = webTarget.request(MediaType.APPLICATION_JSON_TYPE)
					.post(Entity.entity(multiPart, multiPart.getMediaType()));

			logger.info("Response from Contentserver enpoint :: " + response.toString());

			if (response.getStatus() != HttpStatus.OK.value()) {
				throw new CustomException("Error occured while uploading files to content server", HttpStatus.CONFLICT);
			}

		} catch (Exception e) {
			throw new CustomException(e.getMessage(), HttpStatus.BAD_REQUEST);
		} finally {
			for (File f : files) {
				cleanUp(f.toPath());
			}
		}

		return response.readEntity(new GenericType<List<FileUploadResponse>>() {
		});

	}

	public FileUploadResponse sendSingleFile(MultipartFile file, String imageName, String fileLocation)
			throws IOException {

		Response response = null;

		WebTarget webTarget = client.target(contentServerEndPointURL).path(singleFile).path(fileLocation);
		File tempFile = convert(file, imageName);

		try (MultiPart multiPart = new MultiPart()) {

			multiPart.setMediaType(MediaType.MULTIPART_FORM_DATA_TYPE);

			FileDataBodyPart fileDataBodyPart = new FileDataBodyPart("files", tempFile,
					MediaType.APPLICATION_OCTET_STREAM_TYPE);
			multiPart.bodyPart(fileDataBodyPart);

			response = webTarget.request(MediaType.APPLICATION_JSON_TYPE)
					.post(Entity.entity(multiPart, multiPart.getMediaType()));

			logger.info("Response from Contentserver enpoint :: " + response.toString());

			if (response.getStatus() != HttpStatus.OK.value()) {
				throw new CustomException("Error occured while uploading file to content server", HttpStatus.CONFLICT);
			}

		} catch (Exception e) {
			throw new CustomException(e.getMessage(), HttpStatus.BAD_REQUEST);
		} finally {
			cleanUp(tempFile.toPath());
		}

		return response.readEntity(FileUploadResponse.class);
	}

	public File convert(MultipartFile file, String name) throws IOException {

		File convFile = new File(name);
		if (convFile.createNewFile()) {
			try (FileOutputStream fos = new FileOutputStream(convFile);) {
				fos.write(file.getBytes());
			} catch (Exception e) {
				logger.info("Error while converting file");
				throw e;
			}
		}
		return convFile;
	}

	public void deleteMultipleFiles(List<String> fileLocations) {

		Response response = null;
		try {
			response = client.target(contentServerEndPointURL).path(deleteFile)
					.queryParam("fileLocations", fileLocations).request(MediaType.APPLICATION_JSON).delete();

			logger.info(response.toString());

		} catch (Exception e) {
			throw new CustomException("Error while deleting Service Image from ContentServer",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

		if (response.getStatus() != HttpStatus.OK.value()) {
			throw new CustomException("Error occured while deleting image from contentserver", HttpStatus.CONFLICT);
		}
	}

	public void cleanUp(Path path) throws IOException {
		Files.delete(path);
	}
}
