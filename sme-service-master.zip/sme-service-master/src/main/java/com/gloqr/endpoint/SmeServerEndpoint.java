package com.gloqr.endpoint;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;

import com.gloqr.dto.ItemCountUpdate;
import com.gloqr.dto.SMEInformationDto;
import com.gloqr.exception.CustomException;
import com.gloqr.responses.CustomHttpResponse;
import com.gloqr.security.JWTConstants;

public class SmeServerEndpoint {
	private Client client;
	private String smeEndPointUrl;
	private String getSme;
	private String countPath;

	Logger logger = LogManager.getLogger();

	public SmeServerEndpoint(Client client, String getSme, String smeEndPointUrl, String countPath) {
		this.client = client;
		this.getSme = getSme;
		this.smeEndPointUrl = smeEndPointUrl;
		this.countPath = countPath;
	}

	public SMEInformationDto getSme(String smeId) {

		logger.info("Getting SME Information from SME-Master Module");

		Response response = null;

		try {
			response = client.target(smeEndPointUrl).path(getSme.replace("{sUuid}", smeId))
					.request(MediaType.APPLICATION_JSON).get();

			logger.info("Response from enpoint SME module:: " + response.toString());

			CustomHttpResponse<SMEInformationDto> res = response
					.readEntity(new GenericType<CustomHttpResponse<SMEInformationDto>>() {
					});

			if (!res.isError()) {
				return res.getData();
			} else {
				throw new CustomException("Error while getting SME Name from SME Module",
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} catch (Exception e) {
			throw new CustomException("Internal Server Error while getting SME Name", HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	public void countUpdate(String sUuid, ItemCountUpdate count, String token) {

		logger.info("Updating Count of SME Service with details :: " + count.toString());
		try {
			Response response = client.target(smeEndPointUrl).path(countPath).queryParam("smeUuid", sUuid)
					.request(MediaType.APPLICATION_JSON).header(JWTConstants.HEADER_STRING, token)
					.put(Entity.entity(count, MediaType.APPLICATION_JSON));

			logger.info("Response from enpoint SME module :: " + response.toString());
		} catch (Exception e) {
			logger.error("Error while updating count :: " + e.toString());
		}

	}
}
