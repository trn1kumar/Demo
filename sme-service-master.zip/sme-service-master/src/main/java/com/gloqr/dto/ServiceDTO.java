package com.gloqr.dto;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.gloqr.constants.QuotationFormat;
import com.gloqr.entity.OtherCategory;

public class ServiceDTO {

	private String subCategoryUuid;

	@Size(min = 3, max = 100, message = "{service.name.size}")
	@NotBlank(message = "{service.name}")
	private String serviceName;

	@NotBlank(message = "{service.desc}")
	@Size(min = 50, max = 1500, message = "{service.desc.size}")
	private String description;

	@Size(max = 200, message = "{service.location.size}")
	@Pattern(regexp = "^[a-zA-Z, ]*$", message = "{service.location.pattern}")
	private String location;

	@Size(min = 20, max = 2000, message = "{service.terms.size}")
	@NotBlank(message = "{service.terms}")
	private String termsAndCondition;

	private String priceUnit;

	@NotNull(message = "{service.price}")
	private Double price;

	private int discount;
	private float gst;
	private long stock;
	private boolean active;
	private boolean businessPost;
	private boolean autoQuotation;
	private Map<String, String> specifications;

	@Valid
	private List<ImageDTO> images;

	private List<ImageDTO> deletedImages;

	@NotNull(message = "{quotation.format}")
	private QuotationFormat quotationFormat;

	@Valid
	private OtherCategory otherCategory;

	public boolean isAutoQuotation() {
		return autoQuotation;
	}

	private String mainImage;

	public String getSubCategoryUuid() {
		return subCategoryUuid;
	}

	public String getServiceName() {
		return serviceName;
	}

	public String getDescription() {
		return description;
	}

	public String getLocation() {
		return location;
	}

	public String getTermsAndCondition() {
		return termsAndCondition;
	}

	public String getPriceUnit() {
		return priceUnit;
	}

	public Double getPrice() {
		return price;
	}

	public int getDiscount() {
		return discount;
	}

	public float getGst() {
		return gst;
	}

	public long getStock() {
		return stock;
	}

	public boolean isActive() {
		return active;
	}

	public boolean isBusinessPost() {
		return businessPost;
	}

	public Map<String, String> getSpecifications() {
		return specifications;
	}

	public List<ImageDTO> getImages() {
		return images;
	}

	public List<ImageDTO> getDeletedImages() {
		return deletedImages;
	}

	public QuotationFormat getQuotationFormat() {
		return quotationFormat;
	}

	public OtherCategory getOtherCategory() {
		return otherCategory;
	}

	public String getMainImage() {
		return mainImage;
	}

}
