package com.gloqr.dto;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_DEFAULT)
public class SubCategoryDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String subCategoryUuid;

	private String urlName;

	@NotBlank(message = "{subcategory.name}")
	private String subCategoryName;

	@NotBlank(message = "{file.location}")
	private String fileLocation;

	@Valid
	private List<MasterDataDTO> specifications;

	@JsonIgnoreProperties("subCategories")
	private CategoryDTO serviceCategory;

	private long servicesCount;

	public long getServicesCount() {
		return servicesCount;
	}

	public String getSubCategoryUuid() {
		return subCategoryUuid;
	}

	public String getUrlName() {
		return urlName;
	}

	public String getSubCategoryName() {
		return subCategoryName;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public List<MasterDataDTO> getSpecifications() {
		return specifications;
	}

	public void setSubCategoryUuid(String subCategoryUuid) {
		this.subCategoryUuid = subCategoryUuid;
	}

	public void setUrlName(String urlName) {
		this.urlName = urlName;
	}

	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

	public void setServicesCount(long servicesCount) {
		this.servicesCount = servicesCount;
	}

	public CategoryDTO getServiceCategory() {
		return serviceCategory;
	}

	public void setServiceCategory(CategoryDTO serviceCategory) {
		this.serviceCategory = serviceCategory;
	}

}
