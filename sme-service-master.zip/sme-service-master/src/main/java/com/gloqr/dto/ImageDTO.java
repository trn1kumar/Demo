package com.gloqr.dto;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;

public class ImageDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@NotBlank(message = "{file.location}")
	private String fileLocation;
	private long size;
	private boolean mainImage;
	private String fileLocationOne;
	private String fileLocationTwo;

	public String getFileLocation() {
		return fileLocation;
	}

	public long getSize() {
		return size;
	}

	public boolean isMainImage() {
		return mainImage;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

	public void setSize(long size) {
		this.size = size;
	}

	public void setMainImage(boolean mainImage) {
		this.mainImage = mainImage;
	}

	public String getFileLocationOne() {
		return fileLocationOne;
	}

	public void setFileLocationOne(String fileLocationOne) {
		this.fileLocationOne = fileLocationOne;
	}

	public String getFileLocationTwo() {
		return fileLocationTwo;
	}

	public void setFileLocationTwo(String fileLocationTwo) {
		this.fileLocationTwo = fileLocationTwo;
	}

}
