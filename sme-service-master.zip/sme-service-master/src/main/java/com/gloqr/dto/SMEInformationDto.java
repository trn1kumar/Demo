package com.gloqr.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SMEInformationDto implements Serializable {

	private static final long serialVersionUID = 1L;

	public SMEInformationDto() {
		super();
	}

	private String sUuid;

	private String smeName;

	private String smeType;

	private String uuid;

	private AddressDto smeAddress;

	private String contactPerson;

	private String contactEmail;

	private String contactPhone;

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public AddressDto getSmeAddress() {
		return smeAddress;
	}

	public void setSmeAddress(AddressDto smeAddress) {
		this.smeAddress = smeAddress;
	}

	public String getSmeName() {
		return smeName;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

	public String getSmeType() {
		return smeType;
	}

	public void setSmeType(String smeType) {
		this.smeType = smeType;
	}

	@JsonInclude(JsonInclude.Include.NON_DEFAULT)
	@JsonIgnoreProperties(ignoreUnknown = true)
	class AddressDto implements Serializable {

		private static final long serialVersionUID = 1L;
		private String street;
		private String locality;
		private String city;
		private String state;
		private String country;
		private int pincode;

		public AddressDto() {
			super();
		}

		public String getStreet() {
			return street;
		}

		public void setStreet(String street) {
			this.street = street;
		}

		public String getLocality() {
			return locality;
		}

		public void setLocality(String locality) {
			this.locality = locality;
		}

		public String getCity() {
			return city;
		}

		public void setCity(String city) {
			this.city = city;
		}

		public String getState() {
			return state;
		}

		public void setState(String state) {
			this.state = state;
		}

		public String getCountry() {
			return country;
		}

		public void setCountry(String country) {
			this.country = country;
		}

		public int getPincode() {
			return pincode;
		}

		public void setPincode(int pincode) {
			this.pincode = pincode;
		}
	}
}
