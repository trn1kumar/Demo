package com.gloqr.dto;

import java.util.List;

public class PublishFeed {

	private String smeUuid;
	private String publishFeedId;
	private String title;
	private String description;
	private List<ImageDTO> files;
	private boolean active;
	private static final String POSTTYPE = "SERVICE";
	private static final String PRIVACY = "PUBLIC";

	public PublishFeed(String smeUuid, String productUuid, String productName, String description,
			List<ImageDTO> files) {
		this.smeUuid = smeUuid;
		this.publishFeedId = productUuid;
		this.title = productName;
		this.description = description;
		this.files = files;
	}

	public String getSmeUuid() {
		return smeUuid;
	}

	public String getPublishFeedId() {
		return publishFeedId;
	}

	public String getTitle() {
		return title;
	}

	public String getDescription() {
		return description;
	}

	public List<ImageDTO> getFiles() {
		return files;
	}

	public boolean isActive() {
		return active;
	}

	public String getPostType() {
		return POSTTYPE;
	}

	public String getPrivacy() {
		return PRIVACY;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

}
