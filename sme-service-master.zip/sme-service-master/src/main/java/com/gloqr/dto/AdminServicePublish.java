package com.gloqr.dto;

import java.util.List;

public class AdminServicePublish {

	private String smeId;
	private String userId;
	private List<PublishData> data;

	public String getSmeId() {
		return smeId;
	}

	public String getUserId() {
		return userId;
	}

	public List<PublishData> getData() {
		return data;
	}

}
