package com.gloqr.dto;

import java.util.List;

import javax.validation.constraints.NotBlank;

import com.gloqr.constants.ServiceState;
import com.gloqr.constants.ServiceStatus;

public class PublishData {

	@NotBlank(message = "{service.uuid}")
	private String id;

	// for sme admin
	private ServiceStatus smeAction;

	// for smeface admin
	private ServiceState state;
	private String feedbackMessage;
	private String subCategoryUuid;
	private List<ImageDTO> editedImages;

	public String getId() {
		return id;
	}

	public ServiceStatus getSmeAction() {
		return smeAction;
	}

	public ServiceState getState() {
		return state;
	}

	public String getFeedbackMessage() {
		return feedbackMessage;
	}

	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}

	public String getSubCategoryUuid() {
		return subCategoryUuid;
	}

	public void setSubCategoryUuid(String subCategoryUuid) {
		this.subCategoryUuid = subCategoryUuid;
	}

	public List<ImageDTO> getEditedImages() {
		return editedImages;
	}
}
