package com.gloqr.repository;

import java.util.List;

import com.gloqr.entity.Service;
import com.gloqr.responses.ServiceDetails;
import com.gloqr.responses.ServiceResponse;
import com.gloqr.responses.ServiceVO;
import com.gloqr.responses.SingleService;

public interface ServiceDao {

	List<ServiceResponse> topServices(int page);

	ServiceDetails serviceByUuid(String serviceUuid);

	void deleteService(String serviceUuid, String suuid);

	void evictTopServices();

	void saveService(Service service);

	void serviceBiCount(String serviceUuid);

	List<ServiceVO> servicesOfSME(String sUuid);

	List<SingleService> pendingServicesOfSME(String sUuid);

	void updateAutoQutationStatus(String serviceUuid, boolean autoQuotation, String sUuid);

	SingleService serviceForUpdate(String serviceUuid);
}
