package com.gloqr.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gloqr.entity.ServiceCategory;

@Repository
public interface CategoryRepo extends JpaRepository<ServiceCategory, Long> {

	ServiceCategory findByCategoryUuidAndActiveTrue(String categoryUuid);

	List<ServiceCategory> findByActiveTrueOrderByCategoryNameAsc();
}
