package com.gloqr.repository;

import java.util.TreeSet;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.gloqr.entity.ServiceSubCategory;

public interface SubCategoryRepo extends JpaRepository<ServiceSubCategory, Long> {

	ServiceSubCategory findBySubCategoryUuidAndActiveTrue(String subCategoryUuid);

	@Query("select i.name from ServiceSubCategory s JOIN s.specifications i where s.subCategoryUuid=:subCategoryUuid")
	TreeSet<String> getSubcategorySpecifications(String subCategoryUuid);
}
