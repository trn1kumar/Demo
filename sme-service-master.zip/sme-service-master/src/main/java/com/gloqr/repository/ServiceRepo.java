package com.gloqr.repository;

import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gloqr.constants.ServiceState;
import com.gloqr.dto.ItemCountUpdate;
import com.gloqr.entity.Service;

public interface ServiceRepo extends JpaRepository<Service, Long> {

	@Query("SELECT new com.gloqr.dto.ItemCountUpdate(COUNT(CASE WHEN s.serviceState!='DELETED' THEN 1 END),COUNT(CASE WHEN s.active=1 AND s.serviceState='APPROVED' THEN 1 END) ,COUNT(CASE WHEN s.active=1 AND s.serviceState='PENDING' THEN 1 END)) FROM Service s where s.sUuid=:sUuid")
	ItemCountUpdate getCounts(@Param("sUuid") String sUuid);

	List<Service> findByActiveTrueAndServiceState(ServiceState serviceState, Pageable pageable);

	List<Service> findBySUuid(String sUuid);

	Service findByServiceUuid(String serviceUuid);

	@Query("SELECT s.sUuid FROM Service s")
	Set<String> getSuuids();

	@Transactional
	@Modifying
	@Query("update Service s set s.autoQuotation= :autoQuotation where s.serviceUuid= :serviceUuid")
	void updateAutoQutationStatus(@Param("serviceUuid") String serviceUuid,
			@Param("autoQuotation") boolean autoQuotation);

	int countBySUuidAndServiceStateIsNotIn(String sUuid, ServiceState serviceState);

	int countBySUuidAndServiceStateAndActiveTrue(String sUuid, ServiceState serviceState);

	@Query(value = "SELECT FLOOR(MIN(s.discountedPrice)) FROM Service s JOIN "
			+ "s.subCategory sc JOIN sc.serviceCategory c " + "where c.categoryUuid=:categoryUuid AND c.active=true "
			+ "AND s.active=true AND s.serviceState=:serviceState")
	Double categoryMinPrice(@Param("categoryUuid") String categoryUuid,
			@Param("serviceState") ServiceState serviceState);

	@Query(value = "SELECT CEIL(MAX(s.discountedPrice)) FROM Service s JOIN "
			+ "s.subCategory sc JOIN sc.serviceCategory c " + "where c.categoryUuid=:categoryUuid AND c.active=true "
			+ "AND s.active=true AND s.serviceState=:serviceState")
	Double categoryMaxPrice(@Param("categoryUuid") String categoryUuid,
			@Param("serviceState") ServiceState serviceState);

	@Query(value = "SELECT FLOOR(MIN(s.discountedPrice)) FROM Service s JOIN s.subCategory sc "
			+ "where sc.subCategoryUuid=:subCategoryUuid AND sc.active=true "
			+ "AND s.active=true AND s.serviceState=:serviceState")
	Double subCategoryMinPrice(@Param("subCategoryUuid") String subCategoryUuid,
			@Param("serviceState") ServiceState serviceState);

	@Query(value = "SELECT CEIL(MAX(s.discountedPrice)) FROM Service s JOIN s.subCategory sc "
			+ "where sc.subCategoryUuid=:subCategoryUuid AND sc.active=true "
			+ "AND s.active=true AND s.serviceState=:serviceState")
	Double subCategoryMaxPrice(@Param("subCategoryUuid") String subCategoryUuid,
			@Param("serviceState") ServiceState serviceState);

}
