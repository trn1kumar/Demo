package com.gloqr.repository;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.constants.Constants;
import com.gloqr.constants.ServiceState;
import com.gloqr.entity.Service;
import com.gloqr.entity.ServiceImage;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.Mapper;
import com.gloqr.responses.ServiceDetails;
import com.gloqr.responses.ServiceResponse;
import com.gloqr.responses.ServiceVO;
import com.gloqr.responses.SingleService;
import com.gloqr.service.PricingService;

@Repository
public class ServiceDaoImpl implements ServiceDao {

	Logger logger = LogManager.getLogger();

	@Autowired
	private ServiceRepo serviceRepo;

	@Value("${service.page.limit}")
	private Integer pageLimit;

	@Autowired
	private Mapper mapper;

	@Autowired
	private PricingService pricingService;

	@Override
	@Cacheable(value = "topServices", key = "#page")
	public List<ServiceResponse> topServices(int page) {

		if (page <= 0) {
			page = 1;
		}

		List<Service> services = serviceRepo.findByActiveTrueAndServiceState(ServiceState.APPROVED,
				PageRequest.of(--page, pageLimit, Sort.Direction.DESC, "biCount"));

		if (services != null) {
			List<ServiceResponse> response = new ArrayList<>();
			services.stream().forEach(s -> response.add(mapper.convertToDto(s, ServiceResponse.class)));

			return response;
		} else {
			throw new CustomException("Top Services not Found", HttpStatus.NOT_FOUND);
		}

	}

	@Override
	@Cacheable(value = "serviceDto", key = "#serviceUuid")
	public ServiceDetails serviceByUuid(String serviceUuid) {
		Service service = serviceRepo.findByServiceUuid(serviceUuid);

		if (service != null && !service.getServiceState().equals(ServiceState.DELETED)) {
			return mapper.convertToDto(service, ServiceDetails.class);
		} else {
			throw new CustomException("Service not found with id :: " + serviceUuid, HttpStatus.NOT_FOUND);
		}

	}

	@Override
	@Caching(evict = { @CacheEvict(value = { "smeServices", "smePendingServices" }, key = "#service.getsUuid()"),
			@CacheEvict(value = { "serviceDto", "serviceAllDetails" }, key = "#service.getServiceUuid()") })
	public void saveService(Service service) {
		try {
			serviceRepo.save(service);
		} catch (Exception e) {
			throw new CustomException("Error Saving Service", e);
		}
	}

	@Override
	@Transactional
	@Caching(evict = { @CacheEvict(value = { "smeServices", "smePendingServices" }, key = "#suuid"),
			@CacheEvict(value = { "serviceDto", "serviceAllDetails" }, key = "#serviceUuid") })
	public void deleteService(String serviceUuid, String suuid) {
		Service service = serviceRepo.findByServiceUuid(serviceUuid);

		if (service.getsUuid().equals(suuid) && !service.isActive()) {
			service.setServiceState(ServiceState.DELETED);
			serviceRepo.save(service);
		} else {
			throw new CustomException("Service not found for id :: " + serviceUuid + " & " + suuid,
					HttpStatus.NOT_FOUND);
		}

		pricingService.updateImageStorageCredits(service.getImages().stream().mapToLong(ServiceImage::getSize).sum(),
				Constants.CREDIT, "Deleted Service Images for id :: " + service.getServiceUuid());
	}

	@CacheEvict(value = { "topServices" }, allEntries = true)
	@Override
	public void evictTopServices() {
		logger.info("Evicted Top Products Cache");
	}

	@Override
	@Caching(evict = { @CacheEvict(value = { "serviceDto", "serviceAllDetails" }, key = "#serviceUuid"),
			@CacheEvict(value = "topServices", allEntries = true) })
	public void serviceBiCount(String serviceUuid) {
		Service service = serviceRepo.findByServiceUuid(serviceUuid);

		if (service != null) {
			service.setBiCount(service.getBiCount() + 1);
			try {
				serviceRepo.save(service);
			} catch (Exception e) {
				throw new CustomException("Error while updating BI Count of service id :: " + serviceUuid, e);
			}
		} else {
			logger.warn("Service Not Found for id :: " + serviceUuid);
		}

	}

	@Override
	@Cacheable(value = "smeServices", key = "#sUuid")
	public List<ServiceVO> servicesOfSME(String sUuid) {

		List<Service> smeServices = serviceRepo.findBySUuid(sUuid);

		if (smeServices == null || smeServices.isEmpty()) {
			throw new CustomException("Services not found for SME id :: " + sUuid, HttpStatus.NOT_FOUND);
		}

		List<ServiceVO> services = new ArrayList<>();
		smeServices.stream().forEach(s -> services.add(mapper.convertToDto(s, ServiceVO.class)));

		return services;
	}

	@Override
	@Cacheable(value = "smePendingServices", key = "#sUuid")
	public List<SingleService> pendingServicesOfSME(String sUuid) {
		List<Service> smeServices = serviceRepo.findBySUuid(sUuid);

		if (smeServices == null || smeServices.isEmpty()) {
			throw new CustomException("Services not found for SME id :: " + sUuid, HttpStatus.NOT_FOUND);
		}

		List<SingleService> services = new ArrayList<>();
		smeServices.stream().filter(f -> f.getServiceState().equals(ServiceState.PENDING) && f.isActive())
				.forEach(s -> services.add(mapper.convertToDto(s, SingleService.class)));

		if (services.isEmpty()) {
			throw new CustomException("Pending Services not found for SME id :: " + sUuid, HttpStatus.NOT_FOUND);
		}

		return services;
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "smeServices", key = "#sUuid"),
			@CacheEvict(value = "serviceAllDetails", key = "#serviceUuid") })
	public void updateAutoQutationStatus(String serviceUuid, boolean autoQuotation, String sUuid) {
		serviceRepo.updateAutoQutationStatus(serviceUuid, autoQuotation);
	}

	@Override
	@Cacheable(value = "serviceAllDetails", key = "#serviceUuid")
	public SingleService serviceForUpdate(String serviceUuid) {
		Service service = serviceRepo.findByServiceUuid(serviceUuid);

		if (service != null && !service.getServiceState().equals(ServiceState.DELETED)) {
			return mapper.convertToDto(service, SingleService.class);
		} else {
			throw new CustomException("Service not found with id :: " + serviceUuid, HttpStatus.NOT_FOUND);
		}
	}

}
