package com.gloqr.controller;

import java.io.IOException;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.constants.Constants;
import com.gloqr.constants.URLMapping;
import com.gloqr.exception.CustomException;
import com.gloqr.responses.CustomHttpResponse;
import com.gloqr.responses.FileUploadResponse;
import com.gloqr.service.FileService;
import com.gloqr.util.FileUtil;
import com.gloqr.util.RequestParser;
import com.gloqr.util.ResponseMaker;

@RestController
@RequestMapping(URLMapping.BASE_URL)
public class FileController {

	@Autowired
	private FileService fileService;

	@Autowired
	private FileUtil fileUtil;

	@Autowired
	private RequestParser requestParser;

	@Autowired
	private ResponseMaker responseMaker;

	@PreAuthorize(value = Constants.ROLE_GLOQR_AND_SME)
	@PostMapping(URLMapping.MULTIPLE_FILE)
	public ResponseEntity<CustomHttpResponse<List<FileUploadResponse>>> uploadImages(
			@FormDataParam("files") List<MultipartFile> files,
			@RequestParam(value = "s", required = false) String sUuid) throws IOException {

		if (files != null && (!files.isEmpty())) {
			fileUtil.checkFileFormat(files);
		} else {
			throw new CustomException("No file selected", HttpStatus.BAD_REQUEST);
		}

		// If request param is null then request is considered as coming from SME ADMIN
		// else GLOQR ADMIN
		if (StringUtils.isBlank(sUuid)) {
			sUuid = requestParser.getSuuid();
		}

		List<FileUploadResponse> response = fileService.sendMultipleFiles(files, Constants.FILE_LOCATION, sUuid);

		return responseMaker.successResponse(response, HttpStatus.CREATED);
	}

	@PostMapping(URLMapping.SINGLE_FILE)
	@PreAuthorize(value = Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<FileUploadResponse>> singleFileUpload(
			@FormDataParam("file") MultipartFile file) throws IOException {

		if (file != null) {
			fileUtil.checkFileFormat(file);
		} else {
			throw new CustomException("No file selected", HttpStatus.BAD_REQUEST);
		}

		FileUploadResponse response = fileService.sendSingleFile(file, Constants.CATEGORY_FILE_LOCATION);

		return responseMaker.successResponse(response, HttpStatus.CREATED);
	}

}
