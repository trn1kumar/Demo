package com.gloqr.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.URLMapping;
import com.gloqr.filter.FilterResult;
import com.gloqr.responses.CustomHttpResponse;
import com.gloqr.responses.ServiceResponse;
import com.gloqr.service.CartService;
import com.gloqr.service.SearchService;
import com.gloqr.util.RequestParser;
import com.gloqr.util.ResponseMaker;

@RestController
@RequestMapping(URLMapping.BASE_URL)
public class SearchController {

	@Autowired
	private SearchService searchService;

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private CartService cartService;

	@Autowired
	private RequestParser requestParser;

	@GetMapping(URLMapping.SEARCH_SUGGEST)
	public ResponseEntity<CustomHttpResponse<List<String>>> searchSuggests(
			@RequestParam(value = "searchText") String searchText,
			@RequestParam(value = "maxResult", required = false, defaultValue = "10") Integer maxResults) {

		return responseMaker.successResponse(searchService.searchSuggest(searchText, maxResults), HttpStatus.OK);
	}

	@GetMapping(URLMapping.SEARCH_RESULT)
	public ResponseEntity<CustomHttpResponse<FilterResult>> searchResult(
			@RequestParam(value = "searchText", required = false) String searchText,
			@RequestParam(value = "page", required = false, defaultValue = "0") Integer page,
			@RequestParam(value = "sort", required = false) String sort,
			@RequestParam(value = "sme", required = false) Set<String> smeNames) {

		FilterResult filter = searchService.searchResult(searchText, smeNames, sort, page);

		if (requestParser.isLoggedIn() && filter.getResponse().getResult() != null) {
			cartService.addedToCartList(requestParser.getUserUUID(), filter.getResponse().getResult());
		}
		if (page < 0) {
			filter.setFilter(null);
		}

		return responseMaker.successResponse(filter, HttpStatus.OK);
	}

	@GetMapping(URLMapping.SERVICES_BY_CATEGORY)
	public ResponseEntity<CustomHttpResponse<FilterResult>> getCategoryByName(@PathVariable String categoryName,
			@RequestParam(value = "price", required = false) String price,
			@RequestParam(value = "sme", required = false) Set<String> smeNames,
			/* @RequestParam(value = "disc", required = false) String discount, */
			@RequestParam(value = "sort", required = false) String sort, @RequestParam(value = "c") String categoryId,
			@RequestParam(value = "page", required = false, defaultValue = "0") Integer page) {

		FilterResult result = searchService.filterByCategory(categoryId, smeNames, price, sort, page);

		if (requestParser.isLoggedIn() && result.getResponse().getResult() != null) {
			cartService.addedToCartList(requestParser.getUserUUID(), result.getResponse().getResult());
		}

		return responseMaker.successResponse(result, HttpStatus.OK);
	}

	@GetMapping(URLMapping.SERVICES_BY_SUBCATEGORY)
	public ResponseEntity<CustomHttpResponse<FilterResult>> getSubCatgegoryByName(@PathVariable String categoryName,
			@PathVariable String subCategoryName, @RequestParam(value = "price", required = false) String price,
			@RequestParam(value = "sme", required = false) Set<String> smeNames,
			/* @RequestParam(value = "disc", required = false) String discount, */
			@RequestParam(value = "sort", required = false) String sort,
			@RequestParam(value = "c") String subCategoryId,
			@RequestParam(value = "page", required = false, defaultValue = "0") Integer page) {

		FilterResult result = searchService.filterBySubCategory(subCategoryId, smeNames, price, sort, page);

		if (requestParser.isLoggedIn() && result.getResponse().getResult() != null) {
			cartService.addedToCartList(requestParser.getUserUUID(), result.getResponse().getResult());
		}

		return responseMaker.successResponse(result, HttpStatus.OK);
	}

	@GetMapping(URLMapping.SIMILAR_SERVICES)
	public ResponseEntity<CustomHttpResponse<List<ServiceResponse>>> similarProducts(
			@RequestParam(value = "page", defaultValue = "1", required = false) int page,
			@RequestParam(value = "s") String subCategoryUuid, @RequestParam(value = "p") String serviceUuid) {

		List<ServiceResponse> services = searchService.similarServices(subCategoryUuid, serviceUuid, page);

		if (requestParser.isLoggedIn() && services != null) {
			cartService.addedToCartList(requestParser.getUserUUID(), services);
		}

		return responseMaker.successResponse(services, HttpStatus.OK);
	}

}
