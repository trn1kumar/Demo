package com.gloqr.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.Constants;
import com.gloqr.constants.URLMapping;
import com.gloqr.dto.AdminServicePublish;
import com.gloqr.dto.CategoryDTO;
import com.gloqr.dto.MasterDataDTO;
import com.gloqr.dto.PublishData;
import com.gloqr.dto.SubCategoryDTO;
import com.gloqr.exception.CustomException;
import com.gloqr.repository.ServiceRepo;
import com.gloqr.responses.CustomHttpResponse;
import com.gloqr.responses.SingleService;
import com.gloqr.service.AdminService;
import com.gloqr.service.NotificationService;
import com.gloqr.util.RequestParser;
import com.gloqr.util.ResponseMaker;

@RestController
@RequestMapping(URLMapping.BASE_URL_ADMIN)
public class AdminController {

	@Autowired
	private AdminService adminService;

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private RequestParser requestParser;

	@Autowired
	private NotificationService notification;

	@Autowired
	ServiceRepo serviceRepo;

	@PostMapping(URLMapping.CATEGORY)
	@PreAuthorize(value = Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<String>> addServiceCategory(@RequestBody @Valid CategoryDTO categoryDTO) {

		adminService.addServiceCategory(categoryDTO);

		return responseMaker.successResponse("Service Category Added Successfully", HttpStatus.CREATED);
	}

	@PostMapping(URLMapping.SUBCATEGORY)
	@PreAuthorize(value = Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<String>> addServiceSubCategory(@PathVariable String categoryUuid,
			@RequestBody @Valid SubCategoryDTO subCategoryDTO) {

		if (StringUtils.isNotBlank(categoryUuid)) {
			adminService.addServiceSubCategory(categoryUuid, subCategoryDTO);
		} else {
			throw new CustomException("Category UUID cannot be null or empty", HttpStatus.BAD_REQUEST);
		}

		return responseMaker.successResponse("Service SubCategory Added Successfully", HttpStatus.CREATED);
	}

	@PostMapping(URLMapping.SPECIFICATION)
	@PreAuthorize(value = Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<String>> addSubCategorySpecifications(@PathVariable String subCategoryUuid,
			@RequestBody @Valid Set<MasterDataDTO> specificationDTO) {

		if (StringUtils.isNotBlank(subCategoryUuid)) {
			adminService.addSubCategorySpecifications(subCategoryUuid, specificationDTO);
		} else {
			throw new CustomException("SubCategory UUID cannot be null or empty", HttpStatus.BAD_REQUEST);
		}

		return responseMaker.successResponse("SubCategory Specifications Added Successfully", HttpStatus.CREATED);
	}

	@PostMapping(URLMapping.PRICE_UNIT)
	@PreAuthorize(value = Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<String>> addPriceUnits(
			@RequestBody @Valid Set<MasterDataDTO> priceUnitsDTO) {

		adminService.addPriceUnits(priceUnitsDTO);

		return responseMaker.successResponse("Price Units Added Successfully", HttpStatus.CREATED);
	}

	@PutMapping(URLMapping.SERVICE_STATE)
	@PreAuthorize(value = Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<String>> updateServiceState(
			@RequestBody @Valid AdminServicePublish productPublish) {

		adminService.updateServiceState(productPublish);
		// ASYNC Call
		notification.updateCountInSmeModule(productPublish.getSmeId(), requestParser.getHeader());
		return responseMaker.successResponse("Service State Updated Successfully", HttpStatus.OK);
	}

	@PutMapping(URLMapping.SERVICE_IMAGES)
	@PreAuthorize(value = Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<String>> updateServiceImages(@RequestBody @Valid PublishData publishData)
			throws IOException {

		adminService.updateServiceImages(publishData);

		return responseMaker.successResponse("Service Images Updated Successfully", HttpStatus.OK);
	}

	@GetMapping(URLMapping.UPDATE_COUNTS)
	@PreAuthorize(value = Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<String>> update() {

		Set<String> suuids = serviceRepo.getSuuids();

		for (String suuid : suuids) {
			notification.updateCountInSmeModule(suuid, requestParser.getHeader());
		}

		return responseMaker.successResponse("Count Updated Successfully", HttpStatus.OK);
	}

	@GetMapping(URLMapping.SME_PENDING_SERVICES)
	@PreAuthorize(value = Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<List<SingleService>>> getCategories(@PathVariable String sUuid) {

		return responseMaker.successResponse(adminService.pendingServicesOfSME(sUuid), HttpStatus.OK);
	}

	@GetMapping(URLMapping.SME_PENDING_SERVICES_COUNT)
	@PreAuthorize(value = Constants.ROLE_GLOQR_ADMIN)
	public ResponseEntity<CustomHttpResponse<Map<String, Integer>>> getCategoriesCount(
			@RequestParam List<String> smeIds) {

		return responseMaker.successResponse(adminService.smePendingServicesCount(smeIds), HttpStatus.OK);
	}

}
