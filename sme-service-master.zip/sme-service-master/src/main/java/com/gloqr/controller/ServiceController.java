package com.gloqr.controller;

import java.util.List;
import java.util.Set;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.aspectlogger.CheckCredits;
import com.gloqr.aspectlogger.PublishCheckCredits;
import com.gloqr.constants.Constants;
import com.gloqr.constants.URLMapping;
import com.gloqr.dto.PublishData;
import com.gloqr.dto.ServiceDTO;
import com.gloqr.exception.CustomException;
import com.gloqr.responses.CustomHttpResponse;
import com.gloqr.responses.FileUploadResponse;
import com.gloqr.responses.ServiceDetails;
import com.gloqr.responses.ServiceResponse;
import com.gloqr.responses.ServiceVO;
import com.gloqr.responses.ServicesCount;
import com.gloqr.responses.SingleService;
import com.gloqr.service.MasterService;
import com.gloqr.service.NotificationService;
import com.gloqr.util.RequestParser;
import com.gloqr.util.ResponseMaker;

@RestController
@RequestMapping(URLMapping.BASE_URL)
public class ServiceController {

	@Autowired
	private MasterService service;

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private RequestParser requestParser;

	@Autowired
	private NotificationService notification;

	@PostMapping(URLMapping.SERVICE)
	@PreAuthorize(value = Constants.ROLE_SME)
	@CheckCredits
	public ResponseEntity<CustomHttpResponse<String>> addService(@RequestBody @Valid ServiceDTO serviceDTO) {
		String sUuid = requestParser.getSuuid();
		service.addService(serviceDTO, sUuid);
		// ASYNC Call
		notification.updateCountInSmeModule(sUuid, requestParser.getHeader());

		return responseMaker.successResponse("Service Added Successfully", HttpStatus.CREATED);
	}

	@GetMapping(URLMapping.TOP_SERVICES)
	public ResponseEntity<CustomHttpResponse<List<ServiceResponse>>> topServices(
			@RequestParam(value = "page", defaultValue = "1") int page) {
		String userUuid = null;
		if (requestParser.isLoggedIn()) {
			userUuid = requestParser.getUserUUID();
		}

		return responseMaker.successResponse(service.topServices(userUuid, page), HttpStatus.OK);
	}

	@GetMapping(URLMapping.SERVICE_BY_UUID)
	public ResponseEntity<CustomHttpResponse<ServiceDetails>> serviceByUuid(@PathVariable String serviceUuid) {
		String userUuid = null;
		if (requestParser.isLoggedIn()) {
			userUuid = requestParser.getUserUUID();
		}

		return responseMaker.successResponse(service.serviceByUuid(serviceUuid, userUuid), HttpStatus.OK);
	}

	@GetMapping(URLMapping.SERVICE_FOR_UPDATE)
	public ResponseEntity<CustomHttpResponse<SingleService>> serviceForUpdate(@PathVariable String serviceUuid) {

		return responseMaker.successResponse(service.serviceForUpdate(serviceUuid), HttpStatus.OK);
	}

	@DeleteMapping(URLMapping.SERVICE_BY_UUID)
	@PreAuthorize(value = Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> deleteService(@PathVariable String serviceUuid) {
		String sUuid = requestParser.getSuuid();
		service.deleteService(serviceUuid, sUuid);
		notification.updateCountInSmeModule(sUuid, requestParser.getHeader());
		return responseMaker.successResponse("Service Deleted Successfully", HttpStatus.OK);
	}

	@PutMapping(URLMapping.SERVICE_BY_UUID)
	@PreAuthorize(value = Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> updateService(@PathVariable String serviceUuid,
			@RequestBody @Valid ServiceDTO serviceDTO) {

		if (StringUtils.isBlank(serviceUuid)) {
			throw new CustomException("Service Uuid cannot be null or empty.", HttpStatus.BAD_REQUEST);
		}
		String sUuid = requestParser.getSuuid();
		service.updateService(serviceUuid, sUuid, serviceDTO);

		// ASYNC Call
		notification.updateCountInSmeModule(sUuid, requestParser.getHeader());

		return responseMaker.successResponse("Service Updated Successfully", HttpStatus.OK);
	}

	@PutMapping(URLMapping.AUTO_QUOTATION)
	@PreAuthorize(value = Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> changeAutoQuotationStatus(@PathVariable String serviceUuid,
			@RequestBody ServiceDTO serviceDTO) {

		service.updateAutoQuotationStatus(serviceUuid, serviceDTO);

		return responseMaker.successResponse("Auto Quotation Status Updated Successfully", HttpStatus.OK);
	}

	@PutMapping(URLMapping.SERVICE)
	@PreAuthorize(value = Constants.ROLE_SME)
	@PublishCheckCredits
	public ResponseEntity<CustomHttpResponse<String>> updateServiceStatus(@RequestBody @Valid Set<PublishData> data) {

		service.updateServiceStatus(data);
		notification.updateCountInSmeModule(requestParser.getSuuid(), requestParser.getHeader());
		return responseMaker.successResponse("Service Status Updated Successfully", HttpStatus.OK);
	}

	@PreAuthorize(value = Constants.ROLE_SME_AND_USER)
	@PutMapping(URLMapping.SERVICE_BI_COUNT)
	public ResponseEntity<CustomHttpResponse<String>> updateBiCount(@PathVariable String serviceUuid) {

		service.serviceBiCount(serviceUuid);

		return responseMaker.successResponse("Business Interest Count Updated Successfully", HttpStatus.OK);
	}

	@GetMapping(URLMapping.SME_SERVICES_COUNT)
	public ResponseEntity<CustomHttpResponse<ServicesCount>> smeServicesCount(@PathVariable String sUuid,
			@RequestParam(value = "status") boolean viewMode) {

		return responseMaker.successResponse(service.smeServicesCount(sUuid, viewMode), HttpStatus.OK);
	}

	@GetMapping(URLMapping.SME_SERVICES)
	@PreAuthorize(value = Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<List<ServiceVO>>> getServicesOfSME(
			@RequestParam(value = "status", defaultValue = "active") String status) {
		List<ServiceVO> servicesVo = null;

		if (status.equals("all")) {
			servicesVo = service.servicesOfSME(requestParser.getSuuid());
		} else {
			servicesVo = service.servicesOfSME(requestParser.getSuuid(), status);
		}

		return responseMaker.successResponse(servicesVo, HttpStatus.OK);
	}

	@GetMapping(URLMapping.SME_SERVICES_VIEW)
	public ResponseEntity<CustomHttpResponse<List<ServiceResponse>>> approvedServices(@PathVariable String sUuid) {
		String userUuid = null;
		if (requestParser.isLoggedIn()) {
			userUuid = requestParser.getUserUUID();
		}
		
		return responseMaker.successResponse(service.smeServicesViewMode(sUuid, userUuid), HttpStatus.OK);
	}

	@PutMapping(URLMapping.BUSINESS_POST_IMAGE)
	@PreAuthorize(value = Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> modifyPostImages(@RequestBody List<FileUploadResponse> images) {

		service.updateBusinessPostImages(images);

		return responseMaker.successResponse("Business Post Image Status Updated Successfully", HttpStatus.OK);
	}
}
