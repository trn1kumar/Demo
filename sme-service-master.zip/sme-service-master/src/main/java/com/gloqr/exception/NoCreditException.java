package com.gloqr.exception;

public class NoCreditException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private final CreditType creditType;

	public NoCreditException(CreditType creditType) {
		super();
		this.creditType = creditType;
	}

	public CreditType geCreditType() {
		return creditType;
	}

}
