package com.gloqr.config;

import javax.annotation.Resource;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.gloqr.endpoint.BusinessPostEndpoint;
import com.gloqr.endpoint.CartEndpoint;
import com.gloqr.endpoint.ContentServerEndpoint;
import com.gloqr.endpoint.NotificationEndPoint;
import com.gloqr.endpoint.PricingEndpoint;
import com.gloqr.endpoint.SmeServerEndpoint;

@Configuration
@PropertySource(value = { "file:${location}/sme_service_${env}.properties" })
public class RestEndpointConfig {

	@Resource
	private Environment environment;

	@Bean
	public ClientConfig clientConfig() {
		ClientConfig configuration = new ClientConfig();
		configuration.property(ClientProperties.CONNECT_TIMEOUT, 10000);
		configuration.property(ClientProperties.READ_TIMEOUT, 30000);

		return configuration;
	}

	@Bean
	public ContentServerEndpoint contentConfig() {
		Client client = ClientBuilder.newBuilder().register(MultiPartFeature.class).build();
		String contentServerEndPoint = environment.getRequiredProperty("contentserver.endpoint");
		String singleFile = environment.getRequiredProperty("single.file.path");
		String uploadMultipleFile = environment.getRequiredProperty("multiple.file.path");
		String deleteFile = environment.getRequiredProperty("delete.file.path");

		return new ContentServerEndpoint(client, contentServerEndPoint, singleFile, uploadMultipleFile, deleteFile);
	}

	@Bean
	public SmeServerEndpoint smeServerEndpoint() {

		Client client = ClientBuilder.newClient(clientConfig());
		String smeEndPointUrl = environment.getRequiredProperty("sme.endpoint");
		String getSme = environment.getRequiredProperty("getaddress.path");
		String countPath = environment.getRequiredProperty("count.path");

		return new SmeServerEndpoint(client, getSme, smeEndPointUrl, countPath);
	}

	@Bean
	public PricingEndpoint pricingEndpoint() {

		Client client = ClientBuilder.newClient(clientConfig());
		String pricingEndpointUrl = environment.getRequiredProperty("pricing.endpoint");
		String creditsPath = environment.getRequiredProperty("user.credits");
		String adminUpdateCreditsPath = environment.getRequiredProperty("admin.update.credits");

		return new PricingEndpoint(client, pricingEndpointUrl, creditsPath, adminUpdateCreditsPath);
	}

	@Bean
	public BusinessPostEndpoint businessPostEndpoint() {
		Client client = ClientBuilder.newClient(clientConfig());
		String endpoint = environment.getRequiredProperty("business-post.endpoint");
		String createFeed = environment.getRequiredProperty("post.path");
		String updateStatus = environment.getRequiredProperty("update.status.path");

		return new BusinessPostEndpoint(client, endpoint, createFeed, updateStatus);
	}

	@Bean
	public CartEndpoint cartConfig() {

		Client client = ClientBuilder.newClient(clientConfig());
		String cartEndpoint = environment.getRequiredProperty("cart.endpoint");
		String listPath = environment.getRequiredProperty("added.to.cart");

		return new CartEndpoint(client, cartEndpoint, listPath);
	}

	@Bean
	public NotificationEndPoint notificationConfiguration() {
		Client client = ClientBuilder.newClient(clientConfig());
		String endPoint = environment.getRequiredProperty("notification.endpoint");
		String emailPath = environment.getRequiredProperty("email.path");
		String smsPath = environment.getRequiredProperty("sms.path");

		return new NotificationEndPoint(client, endPoint, emailPath, smsPath);
	}
}
