package com.gloqr.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.gloqr.constants.ServiceState;
import com.gloqr.dto.ServiceDTO;
import com.gloqr.entity.Service;
import com.gloqr.exception.CustomException;
import com.gloqr.util.CustomGenerator;

@Component
public class Mapper {

	@Autowired
	private CustomGenerator generator;

	public <T> T convertToEntity(Object srcObj, Class<T> targetClass) {
		T entity = null;

		try {
			entity = new ModelMapper().map(srcObj, targetClass);
		} catch (Exception e) {
			throw new CustomException("Error while converting DTO to Entity", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return entity;
	}

	public <T> T convertToDto(Object srcObj, Class<T> targetClass) {
		T dto = null;

		try {
			dto = new ModelMapper().map(srcObj, targetClass);
		} catch (Exception e) {
			throw new CustomException("Error while converting Entity to DTO", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return dto;
	}

	public void modifyExistingProduct(Service existingService, ServiceDTO serviceDTO) {
		existingService.setServiceName(serviceDTO.getServiceName());
		existingService.setServiceUrlName(generator.filterName(serviceDTO.getServiceName()));

		existingService.setPrice(serviceDTO.getPrice());
		existingService.setPriceUnit(serviceDTO.getPriceUnit());
		if (serviceDTO.getDiscount() != 0) {
			existingService.setDiscountedPrice(
					serviceDTO.getPrice() - ((serviceDTO.getPrice() * serviceDTO.getDiscount()) / 100));
		} else {
			existingService.setDiscountedPrice(serviceDTO.getPrice());
		}

		existingService.setDescription(serviceDTO.getDescription());
		existingService.setLocation(serviceDTO.getLocation());
		existingService.setActive(serviceDTO.isActive());
		existingService.setServiceState(ServiceState.PENDING);
		existingService.setGst(serviceDTO.getGst());
		existingService.setTermsAndCondition(serviceDTO.getTermsAndCondition());
		existingService.setQuotationFormat(serviceDTO.getQuotationFormat());
		existingService.setModified(true);
		existingService.setAutoQuotation(serviceDTO.isAutoQuotation());

		if (existingService.getSpecifications() != null) {
			existingService.getSpecifications().clear();
		}

		existingService.setSpecifications(serviceDTO.getSpecifications());
	}
}
