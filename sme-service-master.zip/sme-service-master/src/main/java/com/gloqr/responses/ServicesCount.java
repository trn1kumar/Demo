package com.gloqr.responses;

public class ServicesCount {

	private String smeId;
	private int count;

	public ServicesCount(String smeId, int count) {
		super();
		this.smeId = smeId;
		this.count = count;
	}

	public String getSmeId() {
		return smeId;
	}

	public int getCount() {
		return count;
	}

}
