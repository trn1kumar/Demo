package com.gloqr.responses;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.gloqr.constants.ServiceState;

@JsonInclude(Include.NON_DEFAULT)
public class ServiceVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String serviceUuid;
	private String serviceName;
	private String serviceUrlName;
	private String sUuid;
	private String smeName;
	private String mainImage;
	private String priceUnit;
	private Double price;
	private Double discountedPrice;
	private int discount;
	private int biCount;
	private ServiceState serviceState;
	private boolean active;
	private boolean modified;
	private Date createdAt;
	private Date updatedAt;
	private String feedbackMessage;
	private boolean autoQuotation;

	public boolean isAutoQuotation() {
		return autoQuotation;
	}

	public void setAutoQuotation(boolean autoQuotation) {
		this.autoQuotation = autoQuotation;
	}

	public int getBiCount() {
		return biCount;
	}

	public void setBiCount(int biCount) {
		this.biCount = biCount;
	}

	public String getServiceUuid() {
		return serviceUuid;
	}

	public void setServiceUuid(String serviceUuid) {
		this.serviceUuid = serviceUuid;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getServiceUrlName() {
		return serviceUrlName;
	}

	public void setServiceUrlName(String serviceUrlName) {
		this.serviceUrlName = serviceUrlName;
	}

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public String getSmeName() {
		return smeName;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public String getMainImage() {
		return mainImage;
	}

	public void setMainImage(String mainImage) {
		this.mainImage = mainImage;
	}

	public String getPriceUnit() {
		return priceUnit;
	}

	public void setPriceUnit(String priceUnit) {
		this.priceUnit = priceUnit;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Double getDiscountedPrice() {
		return discountedPrice;
	}

	public void setDiscountedPrice(Double discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

	public int getDiscount() {
		return discount;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}

	public ServiceState getServiceState() {
		return serviceState;
	}

	public void setServiceState(ServiceState serviceState) {
		this.serviceState = serviceState;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean isModified() {
		return modified;
	}

	public void setModified(boolean modified) {
		this.modified = modified;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getFeedbackMessage() {
		return feedbackMessage;
	}

	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}

}
