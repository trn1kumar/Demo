package com.gloqr.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.gloqr.constants.ServiceState;
import com.gloqr.dto.SMEInformationDto;
import com.gloqr.endpoint.NotificationEndPoint;
import com.gloqr.endpoint.SmeServerEndpoint;
import com.gloqr.model.notification.EmailEvent;
import com.gloqr.repository.ServiceRepo;

@Service
public class NotificationServiceImpl implements NotificationService {

	private Logger log = LogManager.getLogger();

	@Autowired
	private SmeServerEndpoint smeEndpoint;

	@Autowired
	private NotificationEndPoint notificationEndpoint;

	@Autowired
	private TemplateEngine templateEngine;

	@Autowired
	private ServiceRepo serviceRepo;

	@Value(value = "${verification.email.subject}")
	private String verificationEmailSubject;
	
	@Value(value = "${website.url}")
	private String websiteUrl;

	@Value(value = "${content.server.url}")
	private String contentServerUrl;

	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd 'at' hh:mm:ss a");

	public static final String VERIFICATION_TEMPLATE = "servicesVerification.html";

	@Override
	@Async
	public void servicesVerificationSummaryNotifi(String smeId, List<com.gloqr.entity.Service> services) {

		SMEInformationDto sme = smeEndpoint.getSme(smeId);

		if (StringUtils.isNotBlank(sme.getContactEmail())) {
			List<com.gloqr.entity.Service> approvedService = new ArrayList<>();
			List<com.gloqr.entity.Service> rejectedService = new ArrayList<>();

			services.stream().forEach(service -> {
				if (service.getServiceState().equals(ServiceState.APPROVED))
					approvedService.add(service);
				else if (service.getServiceState().equals(ServiceState.REJECTED))
					rejectedService.add(service);
			});

			Context context = new Context();
			context.setVariable("smeName", sme.getSmeName());
			context.setVariable("approvedService", approvedService);
			context.setVariable("rejectedService", rejectedService);
			context.setVariable("totalApproved", approvedService.size());
			context.setVariable("totalRejected", rejectedService.size());
			context.setVariable("approvedDateTime", formatter.format(new Date()));
			context.setVariable("homeUrl", websiteUrl);
			context.setVariable("contentServerUrl", contentServerUrl);

			String mailPage = templateEngine.process(VERIFICATION_TEMPLATE, context);
			EmailEvent emailEvent = new EmailEvent(sme.getContactEmail(), verificationEmailSubject, mailPage);

			notificationEndpoint.sendEmail(emailEvent);

		} else {
			log.warn("Cant't send email..Email ID cannot be empty or null for SME ID :: " + smeId);
		}
	}

	@Override
	@Async
	public void updateCountInSmeModule(String sUuid, String token) {
		smeEndpoint.countUpdate(sUuid, serviceRepo.getCounts(sUuid), token);
	}
}
