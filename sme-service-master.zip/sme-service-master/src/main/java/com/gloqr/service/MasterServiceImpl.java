package com.gloqr.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.gloqr.constants.Constants;
import com.gloqr.constants.ServiceState;
import com.gloqr.constants.ServiceStatus;
import com.gloqr.dto.ImageDTO;
import com.gloqr.dto.PublishData;
import com.gloqr.dto.ServiceDTO;
import com.gloqr.endpoint.SmeServerEndpoint;
import com.gloqr.entity.Service;
import com.gloqr.entity.ServiceImage;
import com.gloqr.entity.ServiceSubCategory;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.Mapper;
import com.gloqr.repository.MasterDataDao;
import com.gloqr.repository.ServiceDao;
import com.gloqr.repository.ServiceImageRepo;
import com.gloqr.repository.ServiceRepo;
import com.gloqr.responses.FileUploadResponse;
import com.gloqr.responses.ServiceDetails;
import com.gloqr.responses.ServiceResponse;
import com.gloqr.responses.ServiceVO;
import com.gloqr.responses.ServicesCount;
import com.gloqr.responses.SingleService;
import com.gloqr.util.CustomGenerator;

@org.springframework.stereotype.Service
public class MasterServiceImpl implements MasterService {
	Logger logger = LogManager.getLogger();

	@Autowired
	private ServiceRepo serviceRepo;

	@Autowired
	private Mapper mapper;

	@Autowired
	private AdminService adminService;

	@Autowired
	private CustomGenerator generator;

	@Autowired
	private SmeServerEndpoint smeEndpoint;

	@Autowired
	private BusinessPostService postService;

	@Autowired
	private PricingService pricingService;

	@Autowired
	private ServiceDao serviceDao;

	@Autowired
	private CartService cartService;

	@Autowired
	private ServiceImageRepo imageRepo;

	@Autowired
	private MasterDataDao masterDao;

	@Override
	@Transactional
	public void addService(ServiceDTO serviceDTO, String sUuid) {
		ServiceSubCategory subCategory = null;

		if (StringUtils.isNotBlank(serviceDTO.getSubCategoryUuid())) {
			subCategory = adminService.getServiceSubCategory(serviceDTO.getSubCategoryUuid());
		}

		Service service = mapper.convertToEntity(serviceDTO, Service.class);
		service.setSubCategory(subCategory);
		service.setsUuid(sUuid);
		service.setServiceState(ServiceState.PENDING);
		service.setServiceUuid(generator.generateUUID());
		service.setServiceUrlName(generator.filterName(service.getServiceName()));

		if (service.getDiscount() != 0) {
			service.setDiscountedPrice(service.getPrice() - ((service.getPrice() * service.getDiscount()) / 100));
		} else {
			service.setDiscountedPrice(service.getPrice());
		}

		service.setSmeName(smeEndpoint.getSme(sUuid).getSmeName().trim());

		List<ServiceImage> images = new ArrayList<>();
		service.getImages().stream().forEach(i -> {
			ServiceImage image = imageRepo.findByFileLocation(i.getFileLocation());
			if (i.isMainImage()) {
				service.setMainImage(i.getFileLocation());
				image.setMainImage(true);
			}
			if (service.isBusinessPost()) {
				image.setBusinessPostImage(true);
			}
			image.setActive(true);
			image.setFileLocationOne(i.getFileLocation());
			image.setFileLocationTwo(i.getFileLocation());
			images.add(image);
		});
		service.setImages(images);

		serviceDao.saveService(service);

		try {
			if (service.isBusinessPost()) {
				postService.createBusinessPost(service, serviceDTO.getImages());
				if (service.isActive()) {
					service.setBusinessPostActivated(true);
				}
			}
		} catch (CustomException e) {
			logger.error("Error while creating business post :: " + e.getMessage());
		}

		if (service.isActive()) {
			pricingService.updateListingCredits(1, Constants.DEBIT,
					"New Service Publish with id :: " + service.getServiceUuid());
		}

		pricingService.updateImageStorageCredits(service.getImages().stream().mapToLong(ServiceImage::getSize).sum(),
				Constants.DEBIT, "New Service Images for id :: " + service.getServiceUuid());
	}

	@Override
	public List<ServiceResponse> topServices(String userUUID, int page) {
		List<ServiceResponse> services = serviceDao.topServices(page);

		if (StringUtils.isNotBlank(userUUID)) {
			cartService.addedToCartList(userUUID, services);
		}

		return services;
	}

	@Override
	public ServiceDetails serviceByUuid(String serviceUuid, String userUUID) {
		ServiceDetails service = serviceDao.serviceByUuid(serviceUuid);

		service.setSmeInfo(smeEndpoint.getSme(service.getsUuid()));

		if (StringUtils.isNotBlank(userUUID) && cartService.isAddedToCart(userUUID, serviceUuid)) {
			service.setAddedToCart(true);
		}

		if (service.getSpecifications().isEmpty()) {
			service.setSpecifications(null);
		} else {
			service.setSpecifications(new TreeMap<>(service.getSpecifications()));
		}

		return service;
	}

	@Override
	public void deleteService(String serviceUuid, String suuid) {
		serviceDao.deleteService(serviceUuid, suuid);
	}

	@Override
	public SingleService serviceForUpdate(String serviceUuid) {

		return serviceDao.serviceForUpdate(serviceUuid);
	}

	@Override
	@Transactional
	public void updateService(String serviceUuid, String sUuid, ServiceDTO serviceDTO) {
		Service existingService = serviceByUuid(serviceUuid);

		checkServiceStateForUpdate(existingService, sUuid);

		long deletedImageSize = 0;
		long newImagesSize = 0;

		if (serviceDTO.getDeletedImages() != null && !serviceDTO.getDeletedImages().isEmpty()) {
			List<ServiceImage> deleteImages = new ArrayList<>();
			for (ImageDTO di : serviceDTO.getDeletedImages()) {
				existingService.getImages().stream().forEach(ei -> {
					if (di.getFileLocation().equals(ei.getFileLocation())) {
						ei.setActive(false);
						deleteImages.add(ei);
					}
				});
				deletedImageSize += di.getSize();
			}
			existingService.getImages().removeAll(deleteImages);
		}

		if (serviceDTO.getImages() != null && !serviceDTO.getImages().isEmpty()) {
			for (ImageDTO ni : serviceDTO.getImages()) {
				ServiceImage newImage = imageRepo.findByFileLocation(ni.getFileLocation());
				newImage.setActive(true);
				newImage.setFileLocationOne(newImage.getFileLocation());
				newImage.setFileLocationTwo(newImage.getFileLocation());
				existingService.getImages().add(newImage);
				newImagesSize += ni.getSize();
			}
		}

		for (ServiceImage img : existingService.getImages()) {
			if (img.getFileLocation().equals(serviceDTO.getMainImage())) {
				img.setMainImage(true);
				existingService.setMainImage(serviceDTO.getMainImage());
			}
		}

		existingService.setSmeName(smeEndpoint.getSme(sUuid).getSmeName().trim());
		mapper.modifyExistingProduct(existingService, serviceDTO);

		serviceDao.saveService(existingService);

		updateProductCredits(existingService, deletedImageSize, newImagesSize);

	}

	@Override
	public void updateAutoQuotationStatus(String serviceUuid, ServiceDTO serviceDTO) {
		ServiceDetails s = serviceDao.serviceByUuid(serviceUuid);

		if (s.isActive()) {
			serviceDao.updateAutoQutationStatus(serviceUuid, serviceDTO.isAutoQuotation(), s.getsUuid());
		} else {
			throw new CustomException("Service is not in Active State", HttpStatus.BAD_REQUEST);
		}
	}

	@Override
	@Transactional
	public void updateServiceStatus(Set<PublishData> data) {
		List<PublishData> businessPostServices = new ArrayList<>();
		List<Service> services = new ArrayList<>();

		for (PublishData publishData : data) {
			boolean status = false;

			if (publishData.getSmeAction().equals(ServiceStatus.ACTIVE)) {
				status = true;
			}

			Service service = serviceByUuid(publishData.getId());

			if ((status && service.isActive()) || (!status && !service.isActive())) {
				continue;
			}

			if (service.isBusinessPost() && !service.isBusinessPostActivated() && status) {
				businessPostServices.add(publishData);
				service.setBusinessPostActivated(true);
			}
			service.setActive(status);
			services.add(service);
		}

		doActions(businessPostServices, services);
	}

	@Override
	public void serviceBiCount(String serviceUuid) {
		serviceDao.serviceBiCount(serviceUuid);
	}

	@Override
	public ServicesCount smeServicesCount(String sUuid, boolean viewMode) {
		int count = 0;

		if (viewMode) {
			count = serviceRepo.countBySUuidAndServiceStateAndActiveTrue(sUuid, ServiceState.APPROVED);
		} else {
			count = serviceRepo.countBySUuidAndServiceStateIsNotIn(sUuid, ServiceState.DELETED);
		}
		return new ServicesCount(sUuid, count);
	}

	@Override
	public List<ServiceVO> servicesOfSME(String sUuid) {
		List<ServiceVO> services = serviceDao.servicesOfSME(sUuid);

		return services.stream().filter(s -> !s.getServiceState().equals(ServiceState.DELETED))
				.collect(Collectors.toList());
	}

	@Override
	public List<ServiceVO> servicesOfSME(String sUuid, String status) {
		List<ServiceVO> services = serviceDao.servicesOfSME(sUuid);

		List<ServiceVO> list = new ArrayList<>();

		if (status.equals("active")) {
			services.stream().filter(s -> s.isActive() && (!s.getServiceState().equals(ServiceState.DELETED)))
					.forEach(s -> list.add(s));
		} else if (status.equals("deactive")) {
			services.stream().filter(s -> !s.isActive() && (!s.getServiceState().equals(ServiceState.DELETED)))
					.forEach(s -> list.add(s));
		}
		if (list.isEmpty()) {
			throw new CustomException("Services Not Found for SME id :: " + sUuid, HttpStatus.NOT_FOUND);
		}

		return list;
	}

	@Override
	public List<ServiceResponse> smeServicesViewMode(String sUuid, String userUUID) {
		List<ServiceVO> services = serviceDao.servicesOfSME(sUuid);

		List<ServiceResponse> response = new ArrayList<>();

		services.stream()
				.filter(s -> s.isActive() && s.getServiceState().equals(ServiceState.APPROVED)
						&& (!s.getServiceState().equals(ServiceState.DELETED)))
				.forEach(s -> response.add(mapper.convertToDto(s, ServiceResponse.class)));

		if (response.isEmpty()) {
			throw new CustomException("Services Not Found for SME id :: " + sUuid, HttpStatus.NOT_FOUND);
		}

		if (StringUtils.isNotBlank(userUUID)) {
			cartService.addedToCartList(userUUID, response);
		}

		return response;
	}

	@Override
	public void updateBusinessPostImages(List<FileUploadResponse> images) {
		Set<String> fileLocations = new HashSet<>();
		images.stream().forEach(i -> fileLocations.add(i.getFileLocation()));
		imageRepo.updateBusinessPostImage(fileLocations);
	}

	public void doActions(List<PublishData> businessPostServices, List<Service> services) {

		if (!services.isEmpty()) {
			services.stream().forEach(s -> {
				if (s.getServiceState().equals(ServiceState.APPROVED)) {
					if (s.isActive()) {
						s.getSubCategory().setServicesCount(s.getSubCategory().getServicesCount() + 1);
					} else {
						s.getSubCategory().setServicesCount(s.getSubCategory().getServicesCount() - 1);
					}
				}
				serviceDao.saveService(s);
			});
			serviceDao.evictTopServices();
			masterDao.evictCategoryCache();

			Optional<Service> publishData = null;

			publishData = services.stream().findFirst();

			if (publishData.isPresent() && publishData.get().isActive()) {
				pricingService.updateListingCredits(services.size(), Constants.DEBIT, "Activated Services");
			} else {
				pricingService.updateListingCredits(services.size(), Constants.CREDIT, "Deactived Services");
				masterDao.evictCategoryCache();
			}

		}

		if (!businessPostServices.isEmpty()) {
			postService.activateBusinessPost(businessPostServices);
		}

	}

	private void updateProductCredits(Service existingService, long deletedImageSize, long newImagesSize) {
		if (existingService.isActive()) {
			pricingService.updateListingCredits(1, Constants.DEBIT,
					"Update Service and publish for id :: " + existingService.getServiceUuid());
		}

		if (newImagesSize > deletedImageSize) {
			long remainingSize = pricingService.checkImageCredits();
			long debitSize = newImagesSize - deletedImageSize;

			if (remainingSize < debitSize) {
				throw new CustomException("No credits left for ", HttpStatus.PAYMENT_REQUIRED);
			}
			if (remainingSize > debitSize) {
				pricingService.updateImageStorageCredits(debitSize, Constants.DEBIT,
						"New Images Added for Existing Service for id :: " + existingService.getServiceUuid());
			}
		}

		if (newImagesSize < deletedImageSize) {
			pricingService.updateImageStorageCredits((deletedImageSize - newImagesSize), Constants.CREDIT,
					"Image Deleted for Existing Service for id :: " + existingService.getServiceUuid());
		}

	}

	private void checkServiceStateForUpdate(Service service, String suuid) {
		if (!service.getsUuid().equals(suuid)) {
			throw new CustomException("You are not allowed to edit this service", HttpStatus.NOT_ACCEPTABLE);
		}
		if (service.isActive() && (service.getServiceState().equals(ServiceState.APPROVED)
				|| service.getServiceState().equals(ServiceState.PENDING))) {
			throw new CustomException("Service is Active. First deactivate the service then try again",
					HttpStatus.BAD_REQUEST);
		}

	}

	private Service serviceByUuid(String serviceUuid) {
		Service service = serviceRepo.findByServiceUuid(serviceUuid);

		if (service != null) {
			return service;
		} else {
			throw new CustomException("Service not found for id :: " + serviceUuid, HttpStatus.BAD_REQUEST);
		}
	}
}
