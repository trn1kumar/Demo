package com.gloqr.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.dto.ImageDTO;
import com.gloqr.dto.PublishData;
import com.gloqr.dto.PublishFeed;
import com.gloqr.endpoint.BusinessPostEndpoint;
import com.gloqr.exception.CustomException;

@Service
public class BusinessPostServiceImpl implements BusinessPostService {

	Logger logger = LogManager.getLogger();

	@Autowired
	private BusinessPostEndpoint postEndpoint;

	@Override
	public void createBusinessPost(com.gloqr.entity.Service service, List<ImageDTO> images) {
		PublishFeed feed = new PublishFeed(service.getsUuid(), service.getServiceUuid(), service.getServiceName(),
				service.getDescription(), images);

		logger.info("Creating Business Post for Service");

		if (service.isActive()) {
			feed.setActive(true);
		}

		try {
			postEndpoint.createBusinessPost(feed);
		} catch (CustomException e) {
			throw e;
		}

	}

	@Override
	public void activateBusinessPost(List<PublishData> postedServices) {
		logger.info("Activating Business Post for Service");

		postEndpoint.updateBusinessPostStatus(postedServices);
	}

}
