package com.gloqr.service;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.apache.lucene.search.Query;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.hibernate.search.query.engine.spi.FacetManager;
import org.hibernate.search.query.facet.Facet;
import org.hibernate.search.query.facet.FacetingRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.http.HttpStatus;

import com.gloqr.constants.ServiceState;
import com.gloqr.dto.AdminServicePublish;
import com.gloqr.dto.CategoryDTO;
import com.gloqr.dto.ImageDTO;
import com.gloqr.dto.MasterDataDTO;
import com.gloqr.dto.PublishData;
import com.gloqr.dto.SubCategoryDTO;
import com.gloqr.entity.MasterSpecification;
import com.gloqr.entity.PriceUnit;
import com.gloqr.entity.Service;
import com.gloqr.entity.ServiceCategory;
import com.gloqr.entity.ServiceSubCategory;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.Mapper;
import com.gloqr.repository.CategoryRepo;
import com.gloqr.repository.ImageDao;
import com.gloqr.repository.MasterDataDao;
import com.gloqr.repository.ServiceDao;
import com.gloqr.repository.ServiceRepo;
import com.gloqr.repository.SubCategoryRepo;
import com.gloqr.responses.SingleService;
import com.gloqr.util.CustomGenerator;

@org.springframework.stereotype.Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private CategoryRepo categoryRepo;

	@Autowired
	private SubCategoryRepo subCategoryRepo;

	@Autowired
	private CustomGenerator generator;

	@Autowired
	private Mapper mapper;

	@Autowired
	private MasterDataDao masterDao;

	@Autowired
	private ServiceRepo serviceRepo;

	@Autowired
	private ServiceDao serviceDao;

	@Autowired
	private PricingService pricingService;

	@Autowired
	private NotificationService notificationService;

	private String dateFormat = "E, dd MMM yyyy HH:mm:ss";

	@Autowired
	private EntityManager entityManager;

	@Autowired
	private ImageDao imageDao;

	@Autowired
	private FileService fileService;

	@Override
	@Transactional
	@CacheEvict(value = "serviceCategories", allEntries = true)
	public void addServiceCategory(CategoryDTO categoryDTO) {
		categoryDTO.setCategoryUuid(generator.generateUUID());
		categoryDTO.setUrlName(generator.filterName(categoryDTO.getCategoryName()));

		ServiceCategory category = mapper.convertToEntity(categoryDTO, ServiceCategory.class);
		category.setActive(true);

		if (category.getSubCategories() != null)
			category.getSubCategories().stream().forEach(s -> {
				s.setSubCategoryUuid(generator.generateUUID());
				s.setUrlName(generator.filterName(s.getSubCategoryName()));
				s.setActive(true);
				s.setServiceCategory(category);
			});

		try {
			categoryRepo.save(category);
			masterDao.evictCategoryCache();
		} catch (Exception e) {
			throw new CustomException("Error while saving product category", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	@Transactional
	public void addServiceSubCategory(String categoryUuid, @Valid SubCategoryDTO subCategoryDTO) {

		ServiceCategory category = getProductCategory(categoryUuid);

		ServiceSubCategory subCategory = mapper.convertToEntity(subCategoryDTO, ServiceSubCategory.class);
		subCategory.setSubCategoryUuid(generator.generateUUID());
		subCategory.setUrlName(generator.filterName(subCategory.getSubCategoryName()));
		subCategory.setActive(true);
		subCategory.setServiceCategory(category);

		saveSubCategory(subCategory);

	}

	@Override
	public void addSubCategorySpecifications(String subCategoryUuid, Set<MasterDataDTO> specificationDTO) {
		ServiceSubCategory subCategory = getServiceSubCategory(subCategoryUuid);
		Set<MasterSpecification> specifications = new HashSet<>();
		specificationDTO.stream()
				.forEach(s -> specifications.add(mapper.convertToEntity(s, MasterSpecification.class)));

		subCategory.getSpecifications().addAll(specifications);
		saveSubCategory(subCategory);
	}

	@Override
	public void addPriceUnits(Set<MasterDataDTO> priceUnitsDTO) {
		Set<PriceUnit> priceUnits = new HashSet<>();
		priceUnitsDTO.stream().forEach(p -> priceUnits.add(mapper.convertToEntity(p, PriceUnit.class)));
		masterDao.savePriceUnits(priceUnits);
	}

	@Override
	public ServiceSubCategory getServiceSubCategory(String subCategoryUuid) {
		ServiceSubCategory subCategory = subCategoryRepo.findBySubCategoryUuidAndActiveTrue(subCategoryUuid);

		if (subCategory != null) {
			return subCategory;
		} else {
			throw new CustomException("Service SubCategory not found for uuid :: " + subCategoryUuid,
					HttpStatus.BAD_REQUEST);
		}
	}

	private ServiceCategory getProductCategory(String categoryUuid) {
		ServiceCategory category = categoryRepo.findByCategoryUuidAndActiveTrue(categoryUuid);

		if (category != null) {
			return category;
		} else {
			throw new CustomException("Service Category not found for uuid :: " + categoryUuid, HttpStatus.BAD_REQUEST);
		}

	}

	private void saveSubCategory(ServiceSubCategory subCategory) {
		try {
			subCategoryRepo.save(subCategory);
			masterDao.evictCategoryCache();
		} catch (Exception e) {
			throw new CustomException("Error while saving service subcategory", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	@Transactional
	public void updateServiceState(AdminServicePublish servicePublish) {
		List<Service> services = new ArrayList<>();

		for (PublishData data : servicePublish.getData()) {
			ServiceState state = data.getState();
			Service service = serviceByUuid(data.getId());

			if (service.isActive() && service.getServiceState().equals(ServiceState.PENDING)) {
				service.setServiceState(state);
				if (service.getServiceState().equals(ServiceState.REJECTED)) {
					service.setActive(false);
				}
				if (StringUtils.isNotBlank(data.getSubCategoryUuid())
						&& service.getServiceState().equals(ServiceState.APPROVED)) {
					service.setSubCategory(getServiceSubCategory(data.getSubCategoryUuid()));
				}
				checkFeedMessage(data, state, service);
				services.add(service);
			}
		}

		if (!services.isEmpty()) {
			services.stream().forEach(s -> {
				if (s.isActive() && s.getServiceState().equals(ServiceState.APPROVED)) {
					s.getSubCategory().setServicesCount(s.getSubCategory().getServicesCount() + 1);
				}
				serviceDao.saveService(s);
			});
			serviceDao.evictTopServices();
			masterDao.evictCategoryCache();
		}

		long credits = servicePublish.getData().stream().filter(p -> p.getState().equals(ServiceState.REJECTED))
				.count();

		if (credits > 0) {
			pricingService.adminUpdateCredits(credits, servicePublish.getSmeId(), servicePublish.getUserId());
		}

		notificationService.servicesVerificationSummaryNotifi(servicePublish.getSmeId(), services);

	}

	@Override
	public void updateServiceImages(PublishData publishData) throws IOException {
		Service service = serviceByUuid(publishData.getId());

		List<String> deleteImages = new ArrayList<>();

		service.getImages().forEach(existImg -> {
			for (ImageDTO imgDto : publishData.getEditedImages()) {
				if (imgDto.getFileLocation().equals(existImg.getFileLocation())) {

					if (StringUtils.isNotBlank(imgDto.getFileLocationOne())) {
						if (checkModifiedFiles(existImg.getFileLocation(), imgDto.getFileLocationOne(),
								existImg.getFileLocationOne(), deleteImages)) {
							existImg.setFileLocationOne(imgDto.getFileLocationOne());
						}
					} else {
						existImg.setFileLocationOne(existImg.getFileLocation());
					}

					if (StringUtils.isNotBlank(imgDto.getFileLocationTwo())) {
						if (checkModifiedFiles(existImg.getFileLocation(), imgDto.getFileLocationTwo(),
								existImg.getFileLocationTwo(), deleteImages)) {
							existImg.setFileLocationTwo(imgDto.getFileLocationTwo());
							if (existImg.isMainImage()) {
								service.setMainImage(imgDto.getFileLocationTwo());
							}
						}
					} else {
						existImg.setFileLocationTwo(existImg.getFileLocation());
						if (existImg.isMainImage()) {
							service.setMainImage(existImg.getFileLocation());
						}
					}

					break;
				}
			}
		});
		serviceDao.saveService(service);
		if (!deleteImages.isEmpty())
			fileService.deleteMultipleFiles(deleteImages);
	}

	private boolean checkModifiedFiles(String existFileLocation, String newFileLocation, String existFileLocationOne,
			List<String> deleteImages) {
		if (!(existFileLocation.equals(newFileLocation) || newFileLocation.equals(existFileLocationOne))) {

			if (!existFileLocation.equals(existFileLocationOne)) {
				deleteImages.add(existFileLocationOne);
			}
			imageDao.deleteByFilelocation(newFileLocation);
			return true;
		}
		return false;
	}

	@Override
	public List<SingleService> pendingServicesOfSME(String sUuid) {
		return serviceDao.pendingServicesOfSME(sUuid);
	}

	@Override
	public Map<String, Integer> smePendingServicesCount(List<String> smeIds) {
		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(Service.class).get();

		Query query1 = queryBuilder.keyword().onField("serviceState").matching(ServiceState.PENDING).createQuery();
		Query query2 = queryBuilder.keyword().onField("active").matching("true").createQuery();

		FacetingRequest facetReq1 = queryBuilder.facet().name("sUuidFacet").onField("sUuid").discrete()
				.includeZeroCounts(true).createFacetingRequest();

		Query finalQuery = queryBuilder.bool().must(query1).must(query2).createQuery();

		FullTextQuery queryResult = fullTextEntityManager.createFullTextQuery(finalQuery, Service.class);
		FacetManager facetManager = queryResult.getFacetManager();
		facetManager.enableFaceting(facetReq1);

		List<Facet> facets = facetManager.getFacets("sUuidFacet");

		Map<String, Integer> map = null;

		if (!facets.isEmpty()) {
			map = new HashMap<>();
			for (Facet f : facets) {
				if (smeIds.contains(f.getValue())) {
					map.put(f.getValue(), f.getCount());
				}
			}
		}

		return map;
	}

	private void checkFeedMessage(PublishData publishData, ServiceState state, Service existService) {

		if (StringUtils.isNotBlank(publishData.getFeedbackMessage())) {
			String dateAndAction = "[ Date:-" + new SimpleDateFormat(dateFormat).format(new Date()) + " Action:-"
					+ state + " ] ";

			publishData.setFeedbackMessage(dateAndAction.concat(publishData.getFeedbackMessage()));

			if (StringUtils.isNotBlank(existService.getFeedbackMessage())) {
				existService.setFeedbackMessage(
						existService.getFeedbackMessage().concat("| " + publishData.getFeedbackMessage()));
			} else {
				existService.setFeedbackMessage(publishData.getFeedbackMessage());
			}
		}

	}

	private Service serviceByUuid(String serviceUuid) {
		Service service = serviceRepo.findByServiceUuid(serviceUuid);

		if (service != null) {
			return service;
		} else {
			throw new CustomException("Service not found for id :: " + serviceUuid, HttpStatus.BAD_REQUEST);
		}
	}

}
