package com.gloqr.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.dto.CategoryDTO;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.Mapper;
import com.gloqr.repository.MasterDataDao;
import com.gloqr.responses.CategoryResponse;
import com.gloqr.responses.SubCategoryResponse;

@Service
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	private MasterDataDao masterDao;

	@Autowired
	private Mapper mapper;

	@Override
	public List<CategoryDTO> menuBarData() {
		List<CategoryDTO> categories = masterDao.getCategories();
		List<CategoryDTO> response = new ArrayList<>();

		categories.stream().filter(c -> !c.getSubCategories().isEmpty()).forEach(c -> {
			c.setSubCategories(
					c.getSubCategories().stream().filter(f -> f.getServicesCount() > 0).collect(Collectors.toList()));
			if (!c.getSubCategories().isEmpty()) {
				response.add(mapper.convertToDto(c, CategoryDTO.class));
			}
		});

		return response;
	}

	@Override
	public Map<String, Object> serviceCategories() {
		Map<String, Object> map = new HashMap<>();

		map.put("priceUnits", masterDao.getPriceUnits());

		List<CategoryResponse> categories = new ArrayList<>();
		try {
			masterDao.getCategories().stream()
					.forEach(c -> categories.add(mapper.convertToDto(c, CategoryResponse.class)));
		} catch (CustomException e) {
			return map;
		}

		map.put("categories", categories);

		return map;
	}

	@Override
	public List<SubCategoryResponse> serviceSubCategories(String categoryUuid) {
		CategoryDTO categoryDTO = masterDao.getCategory(categoryUuid);

		List<SubCategoryResponse> subCategories = new ArrayList<>();
		categoryDTO.getSubCategories().stream()
				.forEach(c -> subCategories.add(mapper.convertToDto(c, SubCategoryResponse.class)));

		return subCategories;
	}

	@Override
	public Set<String> subCategorySpecs(String subCategoryUuid) {
		return masterDao.getSubCategorySpecifications(subCategoryUuid);
	}

}
