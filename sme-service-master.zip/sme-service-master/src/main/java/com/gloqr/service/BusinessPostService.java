package com.gloqr.service;

import java.util.List;

import com.gloqr.dto.ImageDTO;
import com.gloqr.dto.PublishData;
import com.gloqr.entity.Service;

public interface BusinessPostService {
	
	public void createBusinessPost(Service service, List<ImageDTO> images);

	public void activateBusinessPost(List<PublishData> postedServices);
}
