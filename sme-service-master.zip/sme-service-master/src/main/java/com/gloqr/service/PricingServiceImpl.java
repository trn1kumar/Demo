package com.gloqr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.constants.Constants;
import com.gloqr.dto.PricingRequest;
import com.gloqr.endpoint.PricingEndpoint;
import com.gloqr.exception.CreditType;

@Service
public class PricingServiceImpl implements PricingService {

	@Autowired
	private PricingEndpoint pricingEndpoint;

	@Override
	public void adminUpdateCredits(long credits, String sUuid, String userUUID) {
		PricingRequest request = new PricingRequest(CreditType.PRODUCT_SERVICE_LISTING, Constants.CREDIT, credits);
		request.setsUuid(sUuid);
		request.setUserUUID(userUUID);

		pricingEndpoint.updateCredits(request);
	}

	@Override
	public void updateListingCredits(long credits, String action, String usedFor) {
		PricingRequest request = new PricingRequest(CreditType.PRODUCT_SERVICE_LISTING, action, credits);
		request.setUsedFor(usedFor);

		pricingEndpoint.updateCredits(request);
	}

	@Override
	public void updateImageStorageCredits(long credits, String action, String usedFor) {
		PricingRequest request = new PricingRequest(CreditType.IMAGE_STORAGE, action, credits);
		request.setUsedFor(usedFor);

		pricingEndpoint.updateCredits(request);
	}

	@Override
	public long checkImageCredits() {
		return pricingEndpoint.checkCredits(CreditType.IMAGE_STORAGE);
	}

	@Override
	public long checkListingCredits() {
		return pricingEndpoint.checkCredits(CreditType.PRODUCT_SERVICE_LISTING);
	}
}
