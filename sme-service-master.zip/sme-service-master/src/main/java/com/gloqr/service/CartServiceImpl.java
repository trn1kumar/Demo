package com.gloqr.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.endpoint.CartEndpoint;
import com.gloqr.responses.ServiceResponse;

@Service
public class CartServiceImpl implements CartService {

	@Autowired
	private CartEndpoint cartEndpoint;

	@Override
	public void addedToCartList(String userUUID, List<ServiceResponse> services) {
		List<String> serviceUuids = cartEndpoint.addedToCartList(userUUID);
		if (serviceUuids != null) {
			services.stream().forEach(s -> {
				if (serviceUuids.contains(s.getServiceUuid())) {
					s.setAddedToCart(true);
				}
			});
		}
	}

	@Override
	public boolean isAddedToCart(String userUUID, String serviceUuid) {

		List<String> serviceUuids = cartEndpoint.addedToCartList(userUUID);

		return serviceUuids != null && !serviceUuids.isEmpty() && serviceUuids.contains(serviceUuid);
	}

}
