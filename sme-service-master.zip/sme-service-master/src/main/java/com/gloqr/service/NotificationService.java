package com.gloqr.service;

import java.util.List;

import com.gloqr.entity.Service;

public interface NotificationService {

	void servicesVerificationSummaryNotifi(String smeId, List<Service> services);

	void updateCountInSmeModule(String sUuid, String token);
}
