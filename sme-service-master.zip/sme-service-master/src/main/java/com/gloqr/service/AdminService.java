package com.gloqr.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.gloqr.dto.AdminServicePublish;
import com.gloqr.dto.CategoryDTO;
import com.gloqr.dto.MasterDataDTO;
import com.gloqr.dto.PublishData;
import com.gloqr.dto.SubCategoryDTO;
import com.gloqr.entity.ServiceSubCategory;
import com.gloqr.responses.SingleService;

public interface AdminService {

	/* Add Category */
	void addServiceCategory(CategoryDTO categoryDTO);

	/* Add SubCategory */
	void addServiceSubCategory(String categoryUuid, SubCategoryDTO subCategoryDTO);

	/* SubCategory Specifications */
	void addSubCategorySpecifications(String subCategoryUuid, Set<MasterDataDTO> specificationDTO);

	/* Price Units */
	void addPriceUnits(Set<MasterDataDTO> priceUnitsDTO);

	/* SubCategory by uuid */
	ServiceSubCategory getServiceSubCategory(String subCategoryUuid);

	/* Update Service State */
	void updateServiceState(AdminServicePublish productPublish);

	/* Pending Services of SME */
	List<SingleService> pendingServicesOfSME(String sUuid);

	/* Pending Services count of SME's */
	Map<String, Integer> smePendingServicesCount(List<String> smeIds);

	/* Update Service Edited Images */
	void updateServiceImages(PublishData publishData) throws IOException;

}
