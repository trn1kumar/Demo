package com.gloqr.service;

public interface PricingService {

	long checkImageCredits();

	long checkListingCredits();

	void adminUpdateCredits(long credits, String sUuid, String userUUID);

	void updateListingCredits(long credits, String action, String usedFor);

	void updateImageStorageCredits(long credits, String action, String usedFor);
}
