package com.gloqr.service;

import java.util.List;

import com.gloqr.responses.ServiceResponse;

public interface CartService {

	void addedToCartList(String userUUID, List<ServiceResponse> services);

	boolean isAddedToCart(String userUUID, String productUuid);
}
