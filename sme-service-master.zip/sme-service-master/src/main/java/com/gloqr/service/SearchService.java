package com.gloqr.service;

import java.util.List;
import java.util.Set;

import com.gloqr.filter.FilterResult;
import com.gloqr.responses.ServiceResponse;

public interface SearchService {

	List<String> searchSuggest(String searchText, int maxResults);

	FilterResult searchResult(String searchText, Set<String> smeNames, String sort, int page);

	List<ServiceResponse> similarServices(String subCategoryUuid, String serviceUuid, int page);

	FilterResult filterByCategory(String categoryUuid, Set<String> smeNames, String price, String sort, int page);

	FilterResult filterBySubCategory(String subCategoryUuid, Set<String> smeNames, String price, String sort, int page);

}
