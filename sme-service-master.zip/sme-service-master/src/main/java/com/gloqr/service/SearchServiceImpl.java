package com.gloqr.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;

import org.apache.commons.lang3.StringUtils;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.NumericRangeQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Sort;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.hibernate.search.query.engine.spi.FacetManager;
import org.hibernate.search.query.facet.Facet;
import org.hibernate.search.query.facet.FacetingRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.gloqr.constants.ServiceState;
import com.gloqr.dto.CategoryDTO;
import com.gloqr.dto.SubCategoryDTO;
import com.gloqr.entity.Service;
import com.gloqr.exception.CustomException;
import com.gloqr.filter.Filter;
import com.gloqr.filter.FilterResult;
import com.gloqr.filter.PriceFilter;
import com.gloqr.filter.ServiceFilter;
import com.gloqr.filter.SmeNameFilter;
import com.gloqr.mapper.Mapper;
import com.gloqr.repository.MasterDataDao;
import com.gloqr.repository.ServiceRepo;
import com.gloqr.responses.ServiceResponse;

@org.springframework.stereotype.Service
public class SearchServiceImpl implements SearchService {

	@Autowired
	private EntityManager entityManager;

	@Autowired
	private Mapper mapper;

	@Autowired
	private MasterDataDao masterDao;

	@Autowired
	private ServiceRepo serviceRepo;

	private String serviceName = "serviceName";

	private String smeNameFacet = "smeNameFacet";

	/*
	 * private String discountFacet = "discountFacet"; private String discountField
	 * = "discount";
	 */

	private String smeNameField = "smeName";

	private String discountedPriceField = "discountedPrice";

	private String biCount = "biCount";

	private int pageSize = 40;

	@Override
	public List<String> searchSuggest(String searchText, int maxResults) {
		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(Service.class).get();

		Query query1 = queryBuilder.keyword().onField(serviceName).matching(searchText).createQuery();

		Query finalQuery = queryBuilder.bool().must(query1).must(activeQuery(queryBuilder))
				.must(approvedQuery(queryBuilder)).createQuery();

		FullTextQuery queryResult = fullTextEntityManager.createFullTextQuery(finalQuery, Service.class);
		queryResult.setMaxResults(10);

		@SuppressWarnings("unchecked")
		List<Service> services = queryResult.getResultList();

		List<String> suggestResponse = new ArrayList<>();

		services.stream().forEach(s -> suggestResponse.add(s.getServiceName()));

		return suggestResponse;
	}

	@Override
	public FilterResult searchResult(String searchText, Set<String> smeNames, String sort, int page) {

		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(Service.class).overridesForField(serviceName, "customanalyzer").get();

		Query query1 = null;
		if (StringUtils.isBlank(searchText)) {
			query1 = queryBuilder.all().createQuery();
		} else {
			query1 = queryBuilder.keyword().onField(serviceName).matching(searchText).createQuery();
		}

		BooleanQuery.Builder builder = new BooleanQuery.Builder();
		if (smeNames != null && !smeNames.isEmpty()) {
			getSmeNameQuery(smeNames, queryBuilder, query1).stream()
					.forEach(q -> builder.add(q, BooleanClause.Occur.SHOULD));
		} else {
			builder.add(query1, BooleanClause.Occur.MUST);
			builder.add(activeQuery(queryBuilder), BooleanClause.Occur.MUST);
			builder.add(approvedQuery(queryBuilder), BooleanClause.Occur.MUST);
		}

		FullTextQuery queryResult = fullTextEntityManager.createFullTextQuery(builder.build(), Service.class);
		int size = pageSize;
		if (page < 0) {
			page = 0;
			size = 10;
		}
		queryResult.setMaxResults(size);
		queryResult.setFirstResult(size * page);

		// check and set sort query
		checkAndSetSortQuery(sort, queryBuilder, queryResult);

		@SuppressWarnings("unchecked")
		List<Service> products = queryResult.getResultList();

		if (products.isEmpty()) {
			throw new CustomException("Services not found for search text :: " + searchText, HttpStatus.NOT_FOUND);
		}

		List<ServiceResponse> searchResponse = new ArrayList<>();
		products.stream().forEach(p -> searchResponse.add(mapper.convertToDto(p, ServiceResponse.class)));

		List<Facet> smeNameFacets = getSmeNameFilter(fullTextEntityManager, queryBuilder, query1);
		List<SmeNameFilter> smeNameFilters = makeSelectedTrue(smeNameFacets, smeNames);

		return new FilterResult(new Filter(smeNameFilters),
				new ServiceFilter(searchResponse, queryResult.getResultSize()));
	}

	@Override
	public List<ServiceResponse> similarServices(String subCategoryUuid, String serviceUuid, int page) {
		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(Service.class).get();

		Query categoryQuery = queryBuilder.keyword().onField("subCategory.subCategoryUuid").matching(subCategoryUuid)
				.createQuery();
		Query finalQuery = queryBuilder.bool().must(categoryQuery).must(activeQuery(queryBuilder))
				.must(approvedQuery(queryBuilder)).createQuery();

		FullTextQuery queryResult = fullTextEntityManager.createFullTextQuery(finalQuery, Service.class);
		Sort sortQuery = queryBuilder.sort().byField("biCount").desc().createSort();
		queryResult.setSort(sortQuery);

		@SuppressWarnings("unchecked")
		List<Service> services = queryResult.getResultList();
		List<ServiceResponse> response = null;
		if (!services.isEmpty()) {
			response = new ArrayList<>();
			for (Service s : services) {
				if (!s.getServiceUuid().equals(serviceUuid)) {
					response.add(mapper.convertToDto(s, ServiceResponse.class));
				}
			}

		}
		return response;
	}

	@Override
	public FilterResult filterByCategory(String categoryUuid, Set<String> smeNames, String price, String sort,
			int page) {
		if (StringUtils.isNotBlank(categoryUuid)) {
			masterDao.getCategory(categoryUuid);
		} else {
			throw new CustomException("Service Category Id cannot be null or empty", HttpStatus.BAD_REQUEST);
		}

		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);
		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(Service.class).get();
		Query categoryQuery = queryBuilder.keyword().onField("subCategory.serviceCategory.categoryUuid")
				.matching(categoryUuid).createQuery();

		FilterResult filterResult = filterQueryParams(fullTextEntityManager, queryBuilder, categoryQuery, smeNames,
				price, page, sort);

		// Minimum & Maximum price in category
		filterResult.getFilter()
				.setPrice(new PriceFilter(serviceRepo.categoryMinPrice(categoryUuid, ServiceState.APPROVED),
						serviceRepo.categoryMaxPrice(categoryUuid, ServiceState.APPROVED)));

		// SubCategory list
		CategoryDTO category = masterDao.getCategory(categoryUuid);
		category.setSubCategories(category.getSubCategories().stream().filter(s -> s.getServicesCount() > 0)
				.collect(Collectors.toList()));
		filterResult.setCategory(category);

		// Selected price range from displaying in filter
		if (StringUtils.isNotBlank(price)) {
			String[] arr2 = price.trim().split("-");
			filterResult.getFilter().getPrice().setSelectedMinPrice(Double.valueOf(arr2[0]));
			filterResult.getFilter().getPrice().setSelectedMaxPrice(Double.valueOf(arr2[1]));
		}

		return filterResult;
	}

	@Override
	public FilterResult filterBySubCategory(String subCategoryUuid, Set<String> smeNames, String price, String sort,
			int page) {
		if (StringUtils.isNotBlank(subCategoryUuid)) {
			masterDao.getSubCategory(subCategoryUuid);
		} else {
			throw new CustomException("Service SubCategory Id cannot be null or empty", HttpStatus.BAD_REQUEST);
		}

		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);
		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(Service.class).get();
		Query categoryQuery = queryBuilder.keyword().onField("subCategory.subCategoryUuid").matching(subCategoryUuid)
				.createQuery();

		FilterResult filterResult = filterQueryParams(fullTextEntityManager, queryBuilder, categoryQuery, smeNames,
				price, page, sort);

		// Minimum & Maximum price in category
		filterResult.getFilter()
				.setPrice(new PriceFilter(serviceRepo.subCategoryMinPrice(subCategoryUuid, ServiceState.APPROVED),
						serviceRepo.subCategoryMaxPrice(subCategoryUuid, ServiceState.APPROVED)));

		// SubCategory Object
		SubCategoryDTO category = masterDao.getSubCategory(subCategoryUuid);
		filterResult.setCategory(category);

		// Selected price range from displaying in filter
		if (StringUtils.isNotBlank(price)) {
			String[] arr2 = price.trim().split("-");
			filterResult.getFilter().getPrice().setSelectedMinPrice(Double.valueOf(arr2[0]));
			filterResult.getFilter().getPrice().setSelectedMaxPrice(Double.valueOf(arr2[1]));
		}

		return filterResult;
	}

	private FilterResult filterQueryParams(FullTextEntityManager fullTextEntityManager, QueryBuilder queryBuilder,
			Query categoryQuery, Set<String> smeNames, String price, int page, String sort) {

		BooleanQuery.Builder builder = new BooleanQuery.Builder();
		List<Facet> smeNameFacets = null;

		/*
		 * if (smeNames != null && StringUtils.isNotBlank(price) && discount != null) {
		 * 
		 * getCombineQuery(discount, price, smeNames, queryBuilder, categoryQuery)
		 * .forEach(q -> builder.add(q, BooleanClause.Occur.SHOULD));
		 * 
		 * } else
		 */ if (smeNames != null && StringUtils.isNotBlank(price)) {

			getSmeNameAndPriceQuery(price, smeNames, queryBuilder, categoryQuery)
					.forEach(q -> builder.add(q, BooleanClause.Occur.SHOULD));

		} /*
			 * else if (smeNames != null && discount != null) {
			 * 
			 * getSmeNameAndDiscountQuery(discount, smeNames, queryBuilder,
			 * categoryQuery).stream() .forEach(q -> builder.add(q,
			 * BooleanClause.Occur.SHOULD));
			 * 
			 * } else if (StringUtils.isNotBlank(price) && discount != null) {
			 * 
			 * getDiscountAndPriceQuery(discount, price, queryBuilder,
			 * categoryQuery).stream() .forEach(q -> builder.add(q,
			 * BooleanClause.Occur.SHOULD));
			 * 
			 * }
			 */
		else if (smeNames != null) {

			getSmeNameQuery(smeNames, queryBuilder, categoryQuery).stream()
					.forEach(q -> builder.add(q, BooleanClause.Occur.SHOULD));
			smeNameFacets = getSmeNameFilter(fullTextEntityManager, queryBuilder, categoryQuery);

		} else if (StringUtils.isNotBlank(price)) {

			builder.add(getPriceQuery(price, queryBuilder, categoryQuery), BooleanClause.Occur.SHOULD);

		} /*
			 * else if (discount != null) {
			 * 
			 * getDiscountQuery(discount, queryBuilder, categoryQuery).stream() .forEach(q
			 * -> builder.add(q, BooleanClause.Occur.SHOULD));
			 * 
			 * }
			 */
		else {
			builder.add(categoryQuery, BooleanClause.Occur.MUST);
			builder.add(activeQuery(queryBuilder), BooleanClause.Occur.MUST);
			builder.add(approvedQuery(queryBuilder), BooleanClause.Occur.MUST);
		}

		return getResult(fullTextEntityManager, queryBuilder, builder, page, sort, smeNames, smeNameFacets);
	}

	private FilterResult getResult(FullTextEntityManager fullTextEntityManager, QueryBuilder queryBuilder,
			BooleanQuery.Builder builder, int page, String sort, Set<String> smeNames, List<Facet> smeNameFacets) {

		FullTextQuery queryResult = fullTextEntityManager.createFullTextQuery(builder.build(), Service.class);

		if (page < 0) {
			page = 0;
		}
		queryResult.setMaxResults(pageSize);
		queryResult.setFirstResult(pageSize * page);

		// check and set sort query
		checkAndSetSortQuery(sort, queryBuilder, queryResult);

		return filterResult(queryResult, queryBuilder, smeNames, smeNameFacets);
	}

	public FilterResult filterResult(FullTextQuery queryResult, QueryBuilder queryBuilder, Set<String> smeNames,
			List<Facet> smeNameFacets) {
		@SuppressWarnings("unchecked")
		List<Service> serviceResult = queryResult.getResultList();

		// Enabling faceted result of getting filter values
		FacetingRequest facetReq1 = queryBuilder.facet().name(smeNameFacet).onField(smeNameField).discrete()
				.createFacetingRequest();
		/*
		 * FacetingRequest facetReq2 =
		 * queryBuilder.facet().name(discountFacet).onField(discountField).discrete()
		 * .createFacetingRequest();
		 */
		FacetManager facetManager = queryResult.getFacetManager();
		facetManager.enableFaceting(facetReq1);
		/* facetManager.enableFaceting(facetReq2); */

		List<ServiceResponse> services = new ArrayList<>();
		serviceResult.stream().forEach(p -> services.add(mapper.convertToDto(p, ServiceResponse.class)));

		// total count and list of services
		ServiceFilter serviceFilter = new ServiceFilter(services, queryResult.getResultSize());

		// discount and smeName filter
		/* List<Facet> discountFacets = facetManager.getFacets(discountFacet); */
		if (smeNameFacets == null) {
			smeNameFacets = facetManager.getFacets(smeNameFacet);
		}
		Filter filter = new Filter(makeSelectedTrue(smeNameFacets, smeNames));
		/* filter.setDiscountFilter(getDiscountFilter(discountFacets)); */

		return new FilterResult(filter, serviceFilter);
	}

	private void checkAndSetSortQuery(String sort, QueryBuilder queryBuilder, FullTextQuery queryResult) {
		if (StringUtils.isNotBlank(sort) && sort.equals("desc")) {
			Sort sortQuery = queryBuilder.sort().byField(discountedPriceField).desc().createSort();
			queryResult.setSort(sortQuery);
		} else if ((StringUtils.isNotBlank(sort) && sort.equals("asc"))) {
			Sort sortQuery = queryBuilder.sort().byField(discountedPriceField).asc().createSort();
			queryResult.setSort(sortQuery);
		} else {
			Sort sortQuery = queryBuilder.sort().byField(biCount).desc().createSort();
			queryResult.setSort(sortQuery);
		}
	}

	private List<Facet> getSmeNameFilter(FullTextEntityManager fullTextEntityManager, QueryBuilder queryBuilder,
			Query categoryQuery) {
		BooleanQuery.Builder builder = new BooleanQuery.Builder();
		builder.add(categoryQuery, BooleanClause.Occur.MUST);
		builder.add(activeQuery(queryBuilder), BooleanClause.Occur.MUST);
		builder.add(approvedQuery(queryBuilder), BooleanClause.Occur.MUST);

		FacetingRequest facetReq = queryBuilder.facet().name(smeNameFacet).onField(smeNameField).discrete()
				.createFacetingRequest();
		FullTextQuery queryResult = fullTextEntityManager.createFullTextQuery(builder.build(), Service.class);
		FacetManager facetManager = queryResult.getFacetManager();
		facetManager.enableFaceting(facetReq);

		return facetManager.getFacets(smeNameFacet);
	}

	private List<SmeNameFilter> makeSelectedTrue(List<Facet> smeNameFacets, Set<String> smeNames) {
		List<SmeNameFilter> smeNameFilters = null;
		if (!smeNameFacets.isEmpty()) {
			smeNameFilters = new ArrayList<>();

			for (Facet f : smeNameFacets) {
				if (smeNames != null && smeNames.contains(f.getValue())) {
					smeNameFilters.add(new SmeNameFilter(f.getValue(), f.getCount(), true));
				} else {
					smeNameFilters.add(new SmeNameFilter(f.getValue(), f.getCount(), false));
				}
			}

			smeNameFilters.sort(Comparator.comparing(SmeNameFilter::isSelected).reversed()
					.thenComparing(Comparator.comparing(SmeNameFilter::getSmeName)));
		}
		return smeNameFilters;
	}

	private Set<Query> getSmeNameQuery(Set<String> smeNames, QueryBuilder queryBuilder, Query categoryQuery) {
		Set<Query> queries = new HashSet<>();

		for (String smeName : smeNames) {
			Query q = queryBuilder.bool().must(categoryQuery).must(activeQuery(queryBuilder))
					.must(approvedQuery(queryBuilder))
					.must(queryBuilder.keyword().onField(smeNameField).matching(smeName.replace("'", "")).createQuery())
					.createQuery();
			queries.add(q);
		}

		return queries;
	}

	private Query getPriceQuery(String price, QueryBuilder queryBuilder, Query categoryQuery) {
		String[] arr = price.trim().split("-");
		Double minPrice = Double.valueOf(arr[0]);
		Double maxPrice = Double.valueOf(arr[1]);
		return queryBuilder.bool().must(categoryQuery).must(activeQuery(queryBuilder)).must(approvedQuery(queryBuilder))
				.must(NumericRangeQuery.newDoubleRange(discountedPriceField, minPrice, maxPrice, true, true))
				.createQuery();
	}

	private Set<Query> getSmeNameAndPriceQuery(String price, Set<String> smeNames, QueryBuilder queryBuilder,
			Query categoryQuery) {
		String[] priceArr = price.trim().split("-");
		Double minPrice = Double.valueOf(priceArr[0]);
		Double maxPrice = Double.valueOf(priceArr[1]);

		Set<Query> queries = new HashSet<>();

		for (String smeName : smeNames) {
			Query q = queryBuilder.bool().must(categoryQuery).must(activeQuery(queryBuilder))
					.must(approvedQuery(queryBuilder))
					.must(queryBuilder.keyword().onField(smeNameField).matching(smeName).createQuery())
					.must(NumericRangeQuery.newDoubleRange(discountedPriceField, minPrice, maxPrice, true, true))
					.createQuery();
			queries.add(q);
		}

		return queries;

	}

	private Query activeQuery(QueryBuilder queryBuilder) {
		return queryBuilder.keyword().onField("active").matching("true").createQuery();
	}

	private Query approvedQuery(QueryBuilder queryBuilder) {
		return queryBuilder.keyword().onField("serviceState").matching(ServiceState.APPROVED).createQuery();
	}

	/*
	 * private Map<String, DiscountFilter> getDiscountFilter(List<Facet>
	 * discountFacets) { Map<String, DiscountFilter> discountFilter = null; if
	 * (!discountFacets.isEmpty()) { discountFilter = new TreeMap<>(); for (Facet f
	 * : discountFacets) { int i = Integer.parseInt(f.getValue()); int count =
	 * f.getCount();
	 * 
	 * if (i <= 10) { discountFilter = check(discountFilter, "0 - 10", "0-10",
	 * count); } else if (i > 10 && i <= 20) { discountFilter =
	 * check(discountFilter, "11 - 20", "11-20", count); } else if (i > 20 && i <=
	 * 30) { discountFilter = check(discountFilter, "21 - 30", "21-30", count); }
	 * else if (i > 30 && i <= 40) { discountFilter = check(discountFilter,
	 * "31 - 40", "31-40", count); } else if (i > 40 && i <= 50) { discountFilter =
	 * check(discountFilter, "41 - 50", "41-50", count); } else { discountFilter =
	 * check(discountFilter, "51 - * ", "51-99", count); } } } return
	 * discountFilter; }
	 * 
	 * private Map<String, DiscountFilter> check(Map<String, DiscountFilter> map,
	 * String key, String value, int count) { DiscountFilter dsc = map.get(key); if
	 * (dsc != null) { dsc.setCount(dsc.getCount() + count); } else { map.put(key,
	 * new DiscountFilter(value, count)); } return map; } private Set<Query>
	 * getDiscountQuery(Set<String> discount, QueryBuilder queryBuilder, Query
	 * categoryQuery) { Set<Query> queries = new HashSet<>();
	 * 
	 * for (String disc : discount) { String[] arr = disc.trim().split("-"); int
	 * minDisc = Integer.parseInt(arr[0]); int maxDisc = Integer.parseInt(arr[1]);
	 * if (maxDisc > 99 || maxDisc < 0) { maxDisc = 99; } if (minDisc > 99 ||
	 * minDisc < 0) { minDisc = 0; }
	 * 
	 * Query q =
	 * queryBuilder.bool().must(categoryQuery).must(activeQuery(queryBuilder))
	 * .must(approvedQuery(queryBuilder))
	 * .must(queryBuilder.range().onField(discountField).from(minDisc).to(maxDisc).
	 * createQuery()) .createQuery(); queries.add(q); }
	 * 
	 * return queries; } private Set<Query> getSmeNameAndDiscountQuery(Set<String>
	 * discount, Set<String> smeNames, QueryBuilder queryBuilder, Query
	 * categoryQuery) {
	 * 
	 * Set<Query> queries = new HashSet<>();
	 * 
	 * for (String disc : discount) { String[] arr = disc.trim().split("-"); int
	 * minDisc = Integer.parseInt(arr[0]); int maxDisc = Integer.parseInt(arr[1]);
	 * if (maxDisc > 99 || maxDisc < 0) { maxDisc = 99; } if (minDisc > 99 ||
	 * minDisc < 0) { minDisc = 0; } for (String smeName : smeNames) { Query q =
	 * queryBuilder.bool().must(categoryQuery).must(activeQuery(queryBuilder))
	 * .must(approvedQuery(queryBuilder))
	 * .must(queryBuilder.keyword().onField(smeNameField).matching(smeName).
	 * createQuery())
	 * .must(queryBuilder.range().onField(discountField).from(minDisc).to(maxDisc).
	 * createQuery()) .createQuery(); queries.add(q); } }
	 * 
	 * return queries;
	 * 
	 * } private Set<Query> getDiscountAndPriceQuery(Set<String> discount, String
	 * price, QueryBuilder queryBuilder, Query categoryQuery) {
	 * 
	 * String[] arr2 = price.trim().split("-"); Double minPrice =
	 * Double.valueOf(arr2[0]); Double maxPrice = Double.valueOf(arr2[1]);
	 * 
	 * Set<Query> queries = new HashSet<>();
	 * 
	 * for (String disc : discount) { String[] arr = disc.trim().split("-"); int
	 * minDisc = Integer.parseInt(arr[0]); int maxDisc = Integer.parseInt(arr[1]);
	 * if (maxDisc > 99 || maxDisc < 0) { maxDisc = 99; } if (minDisc > 99 ||
	 * minDisc < 0) { minDisc = 0; }
	 * 
	 * Query q =
	 * queryBuilder.bool().must(categoryQuery).must(activeQuery(queryBuilder))
	 * .must(approvedQuery(queryBuilder))
	 * .must(NumericRangeQuery.newDoubleRange(discountedPriceField, minPrice,
	 * maxPrice, true, true))
	 * .must(queryBuilder.range().onField(discountField).from(minDisc).to(maxDisc).
	 * createQuery()) .createQuery(); queries.add(q); }
	 * 
	 * return queries; }
	 * 
	 * private Set<Query> getCombineQuery(Set<String> discount, String price,
	 * Set<String> smeNames, QueryBuilder queryBuilder, Query categoryQuery) {
	 * 
	 * String[] arr2 = price.trim().split("-"); Double minPrice =
	 * Double.valueOf(arr2[0]); Double maxPrice = Double.valueOf(arr2[1]);
	 * 
	 * Set<Query> queries = new HashSet<>();
	 * 
	 * for (String disc : discount) { String[] arr = disc.trim().split("-"); int
	 * minDisc = Integer.parseInt(arr[0]); int maxDisc = Integer.parseInt(arr[1]);
	 * if (maxDisc > 99 || maxDisc < 0) { maxDisc = 99; } if (minDisc > 99 ||
	 * minDisc < 0) { minDisc = 0; } for (String smeName : smeNames) { Query q =
	 * queryBuilder.bool().must(categoryQuery).must(activeQuery(queryBuilder))
	 * .must(approvedQuery(queryBuilder))
	 * .must(queryBuilder.keyword().onField(smeNameField).matching(smeName).
	 * createQuery())
	 * .must(queryBuilder.range().onField(discountField).from(minDisc).to(maxDisc).
	 * createQuery()) .must(NumericRangeQuery.newDoubleRange(discountedPriceField,
	 * minPrice, maxPrice, true, true)) .createQuery(); queries.add(q); } }
	 * 
	 * return queries;
	 * 
	 * }
	 */

}
