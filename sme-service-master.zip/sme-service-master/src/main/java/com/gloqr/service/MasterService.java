package com.gloqr.service;

import java.util.List;
import java.util.Set;

import com.gloqr.dto.PublishData;
import com.gloqr.dto.ServiceDTO;
import com.gloqr.responses.FileUploadResponse;
import com.gloqr.responses.ServiceDetails;
import com.gloqr.responses.ServiceResponse;
import com.gloqr.responses.ServiceVO;
import com.gloqr.responses.ServicesCount;
import com.gloqr.responses.SingleService;

public interface MasterService {

	/* Add new Service */
	void addService(ServiceDTO serviceDTO, String sUuid);

	/* Top Services */
	List<ServiceResponse> topServices(String userUUID, int page);

	/* Service for Display Page */
	ServiceDetails serviceByUuid(String serviceUuid, String userUUID);

	/* Soft Delete Service */
	void deleteService(String serviceUuid, String suuid);

	/* Update Service */
	void updateService(String serviceUuid, String suuid, ServiceDTO serviceDTO);

	/* Update Status */
	void updateServiceStatus(Set<PublishData> data);

	/* Increment Count after show interest from Cart Module */
	void serviceBiCount(String serviceUuid);

	/* SME Services Count view and edit page */
	ServicesCount smeServicesCount(String sUuid, boolean viewMode);

	/* SME Services All */
	List<ServiceVO> servicesOfSME(String suuid);

	/* SME Services Active or Deactive as per status */
	List<ServiceVO> servicesOfSME(String suuid, String status);

	/* SME Services View Mode */
	List<ServiceResponse> smeServicesViewMode(String sUuid, String userUUID);

	/* Update Status of Business Post Images */
	void updateBusinessPostImages(List<FileUploadResponse> images);

	SingleService serviceForUpdate(String serviceUuid);

	/* Update Auto Quotation Status */
	void updateAutoQuotationStatus(String serviceUuid, ServiceDTO serviceDTO);

}
