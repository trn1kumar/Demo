package com.gloqr.entities;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import com.gloqr.audit.DateAuditable;
import com.gloqr.constants.JobGroup;
import com.gloqr.constants.JobSubGroup;

@Entity
@Table(name = "scheduler_job_details")
public class SchedulerJobDetail extends DateAuditable {

	@Id
	@GeneratedValue
	private Long schedulerJobId;

	@Column(name = "job_name", unique = true, updatable = false)
	private String jobName;

	@Column(name = "job_group")
	@Enumerated(EnumType.STRING)
	private JobGroup jobGroup;

	@Column(name = "job_sub_group")
	@Enumerated(EnumType.STRING)
	private JobSubGroup jobSubGroup;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "scheduler_jobs_join_scheduler_configs", joinColumns = @JoinColumn(name = "schedulerJobId", referencedColumnName = "schedulerJobId"), inverseJoinColumns = @JoinColumn(name = "configId", referencedColumnName = "configId"))
	private List<SchedulerConfig> schedulerConfigs;

	@OneToMany(cascade = CascadeType.ALL)
	@LazyCollection(LazyCollectionOption.FALSE)
	@JoinColumn(name = "scheduler_job_id")
	private List<EmailEvent> emailEvents;

	@OneToMany(cascade = CascadeType.ALL)
	@LazyCollection(LazyCollectionOption.FALSE)
	@JoinColumn(name = "scheduler_job_id")
	private List<SmsEvent> smsEvents;

	@Column(name = "remind_notifi_job_data_json_string", columnDefinition = "TEXT")
	private String remindNotifiJobDataJsonString;

	@Column(name = "un_schedule")
	private boolean unSchedule;

	@Column(name = "next_execution_at")
	@Temporal(TemporalType.TIMESTAMP)
	private Date nextExecutionTime;

	private int dailyExecutedCount;
	private int monthlyExecutedCount;
	private int weeklyExecutedCount;
	private int yearlyExecutedCount;

	private boolean immediateExecutionComplete;
	private boolean dailyExecutionComplete;
	private boolean monthlyExecutionComplete;
	private boolean weeklyExecutionComplete;
	private boolean yearlyExecutionComplete;

	public Long getSchedulerJobId() {
		return schedulerJobId;
	}

	public void setSchedulerJobId(Long schedulerJobId) {
		this.schedulerJobId = schedulerJobId;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public List<SchedulerConfig> getSchedulerConfigs() {
		return schedulerConfigs;
	}

	public void setSchedulerConfigs(List<SchedulerConfig> schedulerConfigs) {
		this.schedulerConfigs = schedulerConfigs;
	}

	public List<EmailEvent> getEmailEvents() {
		return emailEvents;
	}

	public void setEmailEvents(List<EmailEvent> emailEvents) {
		this.emailEvents = emailEvents;
	}

	public List<SmsEvent> getSmsEvents() {
		return smsEvents;
	}

	public void setSmsEvents(List<SmsEvent> smsEvents) {
		this.smsEvents = smsEvents;
	}

	public JobGroup getJobGroup() {
		return jobGroup;
	}

	public void setJobGroup(JobGroup jobGroup) {
		this.jobGroup = jobGroup;
	}

	public JobSubGroup getJobSubGroup() {
		return jobSubGroup;
	}

	public void setJobSubGroup(JobSubGroup jobSubGroup) {
		this.jobSubGroup = jobSubGroup;
	}

	public int getDailyExecutedCount() {
		return dailyExecutedCount;
	}

	public void setDailyExecutedCount(int dailyExecutedCount) {
		this.dailyExecutedCount = dailyExecutedCount;
	}

	public int getMonthlyExecutedCount() {
		return monthlyExecutedCount;
	}

	public void setMonthlyExecutedCount(int monthlyExecutedCount) {
		this.monthlyExecutedCount = monthlyExecutedCount;
	}

	public int getWeeklyExecutedCount() {
		return weeklyExecutedCount;
	}

	public void setWeeklyExecutedCount(int weeklyExecutedCount) {
		this.weeklyExecutedCount = weeklyExecutedCount;
	}

	public int getYearlyExecutedCount() {
		return yearlyExecutedCount;
	}

	public void setYearlyExecutedCount(int yearlyExecutedCount) {
		this.yearlyExecutedCount = yearlyExecutedCount;
	}

	public boolean isDailyExecutionComplete() {
		return dailyExecutionComplete;
	}

	public void setDailyExecutionComplete(boolean dailyExecutionComplete) {
		this.dailyExecutionComplete = dailyExecutionComplete;
	}

	public boolean isMonthlyExecutionComplete() {
		return monthlyExecutionComplete;
	}

	public void setMonthlyExecutionComplete(boolean monthlyExecutionComplete) {
		this.monthlyExecutionComplete = monthlyExecutionComplete;
	}

	public boolean isWeeklyExecutionComplete() {
		return weeklyExecutionComplete;
	}

	public void setWeeklyExecutionComplete(boolean weeklyExecutionComplete) {
		this.weeklyExecutionComplete = weeklyExecutionComplete;
	}

	public boolean isYearlyExecutionComplete() {
		return yearlyExecutionComplete;
	}

	public void setYearlyExecutionComplete(boolean yearlyExecutionComplete) {
		this.yearlyExecutionComplete = yearlyExecutionComplete;
	}

	public boolean isUnSchedule() {
		return unSchedule;
	}

	public void setUnSchedule(boolean unSchedule) {
		this.unSchedule = unSchedule;
	}

	public String getRemindNotifiJobDataJsonString() {
		return remindNotifiJobDataJsonString;
	}

	public void setRemindNotifiJobDataJsonString(String remindNotifiJobDataJsonString) {
		this.remindNotifiJobDataJsonString = remindNotifiJobDataJsonString;
	}

	public Date getNextExecutionTime() {
		return nextExecutionTime;
	}

	public void setNextExecutionTime(Date nextExecutionTime) {
		this.nextExecutionTime = nextExecutionTime;
	}

	public boolean isImmediateExecutionComplete() {
		return immediateExecutionComplete;
	}

	public void setImmediateExecutionComplete(boolean immediateExecutionComplete) {
		this.immediateExecutionComplete = immediateExecutionComplete;
	}

}
