package com.gloqr.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.gloqr.constants.JobGroup;
import com.gloqr.constants.SchedulerType;

@Entity
@Table(name = "scheduler_config")
public class SchedulerConfig {

	@Id
	@GeneratedValue
	private Long configId;

	@Column(name = "scheduler_type")
	@Enumerated(EnumType.STRING)
	private SchedulerType schedulerType;

	@Column(name = "job_group")
	@Enumerated(EnumType.STRING)
	private JobGroup jobGroup;

	@Column(name = "frequency")
	private int frequency;

	@Column(name = "initial_delay")
	private int initialDelay;

	@Column(name = "interval_time")
	private int intervalTime;

	public Long getConfigId() {
		return configId;
	}

	public void setConfigId(Long configId) {
		this.configId = configId;
	}

	public SchedulerType getSchedulerType() {
		return schedulerType;
	}

	public void setSchedulerType(SchedulerType schedulerType) {
		this.schedulerType = schedulerType;
	}

	public JobGroup getJobGroup() {
		return jobGroup;
	}

	public void setJobGroup(JobGroup jobGroup) {
		this.jobGroup = jobGroup;
	}

	public int getFrequency() {
		return frequency;
	}

	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}

	public int getInitialDelay() {
		return initialDelay;
	}

	public void setInitialDelay(int initialDelay) {
		this.initialDelay = initialDelay;
	}

	public int getIntervalTime() {
		return intervalTime;
	}

	public void setIntervalTime(int intervalTime) {
		this.intervalTime = intervalTime;
	}

}
