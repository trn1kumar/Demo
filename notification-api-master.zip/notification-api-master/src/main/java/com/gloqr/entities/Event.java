package com.gloqr.entities;

import com.gloqr.audit.DateAuditable;
import com.gloqr.notification.aspect.SmefaceLogger;

public abstract class Event extends DateAuditable{
	protected int severity = 1;

	public static final int CRITICAL = 3;
	public static final int AVERAGE = 2;
	public static final int LOW = 1;

	public abstract void setEventMessage(String message);

	public abstract String getEventMessage();

	public abstract void acceptLogIntercepter(SmefaceLogger logger);

	public int getSeverity() {
		return severity;
	}

	public void setSeverity(int severity) {
		this.severity = severity;
	}

}
