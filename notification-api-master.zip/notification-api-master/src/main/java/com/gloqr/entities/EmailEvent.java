
package com.gloqr.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.gloqr.notification.aspect.SmefaceLogger;

@Entity(name = "notification_email_event")
public class EmailEvent extends Event {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "email_event_id")
	private Long emailEventId;

	@Column(name = "email_id")
	private String emailId;

	@Column(name = "email_subject")
	private String subject;

	@Column(name = "eventMessage", columnDefinition = "TEXT")
	private String eventMessage;

	@Column(name = "attachment_file_location")
	private String attachmentFileLocation;

	@Column(name = "sent_status")
	private boolean sentStatus;
	
	@Column(name = "failed_status")
	private boolean failedStatus;

	@Column(name = "total_resend_count")
	private int totalResendCount;

	public EmailEvent() {
		super();
	}

	public EmailEvent(String emailId, String subject, String eventMessage, String attachmentFileLocation) {
		super();
		this.emailId = emailId;
		this.subject = subject;
		this.eventMessage = eventMessage;
		this.attachmentFileLocation = attachmentFileLocation;
	}

	public void acceptLogIntercepter(SmefaceLogger logger) {
		logger.logRequest(this);
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	@Override
	public String getEventMessage() {
		return eventMessage;
	}

	@Override
	public void setEventMessage(String eventMessage) {
		this.eventMessage = eventMessage;
	}

	public Long getEmailEventId() {
		return emailEventId;
	}

	public void setEmailEventId(Long emailEventId) {
		this.emailEventId = emailEventId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAttachmentFileLocation() {
		return attachmentFileLocation;
	}

	public void setAttachmentFileLocation(String attachmentFileLocation) {
		this.attachmentFileLocation = attachmentFileLocation;
	}

	public boolean isSentStatus() {
		return sentStatus;
	}

	public void setSentStatus(boolean sentStatus) {
		this.sentStatus = sentStatus;
	}

	public int getTotalResendCount() {
		return totalResendCount;
	}

	public void setTotalResendCount(int totalResendCount) {
		this.totalResendCount = totalResendCount;
	}

	public boolean isFailedStatus() {
		return failedStatus;
	}

	public void setFailedStatus(boolean failedStatus) {
		this.failedStatus = failedStatus;
	}

}
