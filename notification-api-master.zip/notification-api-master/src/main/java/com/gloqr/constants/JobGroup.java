package com.gloqr.constants;

public enum JobGroup {

	CIRCLE_NOTIFICATION, BI_NOTIFICATION;

}
