package com.gloqr.constants;

public enum JobSubGroup {

	CIRCLE_INVITE_RECEIVED, BI_FIRST_STAGE, BI_SECOND_STAGE, BI_THIRD_STAGE, BI_FOURTH_STAGE

}
