package com.gloqr.constants;

public enum SchedulerType {

	IMMEDIATE, DAILY, MONTHLY, WEEKLY, YEARLY
}
