package com.gloqr.constants;

import java.util.EnumMap;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class NotificationTemplates {

	private EnumMap<JobSubGroup, Map<SchedulerType, String>> biSubGrpsAndTemplates = null;
	private EnumMap<JobSubGroup, Map<SchedulerType, String>> circleSubGrpsAndTemplates = null;

	public static final String DAILY_REMIND_CIRCLE_INVITE_RECEIVED = "RemindCircleInviteReceived";
	public static final String WEELKY_REMIND_CIRCLE_INVITE_RECEIVED = "RemindCircleInviteReceived";
	public static final String MONTHLY_REMIND_CIRCLE_INVITE_RECEIVED = "RemindCircleInviteReceived";

	public static final String DAILY_REMIND_BI_RECEIVED = "RemindBIReceived";
	public static final String WEEKLY_REMIND_BI_RECEIVED = "RemindBIReceived";
	public static final String MONTHLY_REMIND_BI_RECEIVED = "RemindBIReceived";

	public static final String DAILY_REMIND_QUOTATION_RECEIVED = "RemindQuotationReceived";
	public static final String WEEKLY_REMIND_QUOTATION_RECEIVED = "RemindQuotationReceived";
	public static final String MONTHLY_REMIND_QUOTATION_RECEIVED = "RemindQuotationReceived";

	public static final String DAILY_REMIND_PO_RECEIVED = "RemindPOReceived";
	public static final String WEEKLY_REMIND_PO_RECEIVED = "RemindPOReceived";
	public static final String MONTHLY_REMIND_PO_RECEIVED = "RemindPOReceived";

	public static final String DAILY_REMIND_ORDER_CONFIRMED = "RemindOrderConfirmed";
	public static final String WEEKLY_REMIND_ORDER_CONFIRMED = "RemindOrderConfirmed";
	public static final String MONTHLY_REMIND_ORDER_CONFIRMED = "RemindOrderConfirmed";

	public NotificationTemplates() {
		addBiNotificationTemplates();
		addCircleNotificationTemplates();
	}

	public void addBiNotificationTemplates() {

		biSubGrpsAndTemplates = new EnumMap<>(JobSubGroup.class);

		addBIFirstStageTemplates(biSubGrpsAndTemplates);
		addBISecondStageTemplates(biSubGrpsAndTemplates);
		addBIThirdStageTemplates(biSubGrpsAndTemplates);
		addBIFourthStageTemplates(biSubGrpsAndTemplates);
	}

	public void addCircleNotificationTemplates() {
		circleSubGrpsAndTemplates = new EnumMap<>(JobSubGroup.class);

		Map<SchedulerType, String> inviteReceivedTemplates = new EnumMap<>(SchedulerType.class);
		inviteReceivedTemplates.put(SchedulerType.DAILY, DAILY_REMIND_CIRCLE_INVITE_RECEIVED);
		inviteReceivedTemplates.put(SchedulerType.WEEKLY, WEELKY_REMIND_CIRCLE_INVITE_RECEIVED);
		inviteReceivedTemplates.put(SchedulerType.MONTHLY, MONTHLY_REMIND_CIRCLE_INVITE_RECEIVED);

		circleSubGrpsAndTemplates.put(JobSubGroup.CIRCLE_INVITE_RECEIVED, inviteReceivedTemplates);

	}

	private Map<JobSubGroup, Map<SchedulerType, String>> addBIFirstStageTemplates(
			Map<JobSubGroup, Map<SchedulerType, String>> map) {
		Map<SchedulerType, String> biReceivedTemplates = new EnumMap<>(SchedulerType.class);
		biReceivedTemplates.put(SchedulerType.DAILY, DAILY_REMIND_BI_RECEIVED);
		biReceivedTemplates.put(SchedulerType.WEEKLY, DAILY_REMIND_BI_RECEIVED);
		biReceivedTemplates.put(SchedulerType.MONTHLY, DAILY_REMIND_BI_RECEIVED);

		map.put(JobSubGroup.BI_FIRST_STAGE, biReceivedTemplates);
		return map;
	}

	private Map<JobSubGroup, Map<SchedulerType, String>> addBISecondStageTemplates(
			Map<JobSubGroup, Map<SchedulerType, String>> map) {
		Map<SchedulerType, String> quotationReceivedTemplates = new EnumMap<>(SchedulerType.class);
		quotationReceivedTemplates.put(SchedulerType.DAILY, DAILY_REMIND_QUOTATION_RECEIVED);
		quotationReceivedTemplates.put(SchedulerType.WEEKLY, WEEKLY_REMIND_QUOTATION_RECEIVED);
		quotationReceivedTemplates.put(SchedulerType.MONTHLY, MONTHLY_REMIND_QUOTATION_RECEIVED);

		map.put(JobSubGroup.BI_SECOND_STAGE, quotationReceivedTemplates);
		return map;
	}

	private Map<JobSubGroup, Map<SchedulerType, String>> addBIThirdStageTemplates(
			Map<JobSubGroup, Map<SchedulerType, String>> map) {
		Map<SchedulerType, String> poReceivedTemplates = new EnumMap<>(SchedulerType.class);
		poReceivedTemplates.put(SchedulerType.DAILY, DAILY_REMIND_PO_RECEIVED);
		poReceivedTemplates.put(SchedulerType.WEEKLY, WEEKLY_REMIND_PO_RECEIVED);
		poReceivedTemplates.put(SchedulerType.MONTHLY, MONTHLY_REMIND_PO_RECEIVED);

		map.put(JobSubGroup.BI_THIRD_STAGE, poReceivedTemplates);
		return map;
	}

	private Map<JobSubGroup, Map<SchedulerType, String>> addBIFourthStageTemplates(
			Map<JobSubGroup, Map<SchedulerType, String>> map) {
		Map<SchedulerType, String> orderConfirmedTemplates = new EnumMap<>(SchedulerType.class);
		orderConfirmedTemplates.put(SchedulerType.DAILY, DAILY_REMIND_ORDER_CONFIRMED);
		orderConfirmedTemplates.put(SchedulerType.WEEKLY, WEEKLY_REMIND_ORDER_CONFIRMED);
		orderConfirmedTemplates.put(SchedulerType.MONTHLY, MONTHLY_REMIND_ORDER_CONFIRMED);

		map.put(JobSubGroup.BI_FOURTH_STAGE, orderConfirmedTemplates);
		return map;
	}

	public Map<JobSubGroup, Map<SchedulerType, String>> getBiNotificationTemplates() {
		return biSubGrpsAndTemplates.clone();		
	}

	public Map<JobSubGroup, Map<SchedulerType, String>> getCircleNotificationTemplates() {
		return circleSubGrpsAndTemplates.clone();
	}

}
