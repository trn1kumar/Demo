package com.gloqr.rest.endpoint;

import javax.ws.rs.client.Client;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;

import com.gloqr.exceptions.CustomException;

public class BulkSmsEndpoint {

	private Client client;
	private String endPoint;
	private String smsApiKey;

	public static final String INITIAL_EXCEPTION_MSG = "Exception while send sms.";

	static final Logger log = LogManager.getLogger(BulkSmsEndpoint.class.getName());

	public BulkSmsEndpoint(Client client, String endPoint, String smsApiKey) {
		this.client = client;
		this.endPoint = endPoint;
		this.smsApiKey = smsApiKey;
	}

	public void callBulkSmsApi(String mobileNumber, String message, String sender) {

		Response response = null;
		try {
			response = client.target(endPoint).queryParam("apikey", smsApiKey).queryParam("sender", sender)
					.queryParam("number", mobileNumber).queryParam("message", message).request().get();
		} catch (Exception e) {
			throw new CustomException("Couldn't connect to bulksmsapps service.", HttpStatus.INTERNAL_SERVER_ERROR);
		}

		String res = response.readEntity(String.class);
		String messageId = res.trim().split("\n")[0];
		if (messageId.contains("TRACE:201!")) {
			throw new CustomException(INITIAL_EXCEPTION_MSG + " Username or password may be wrong.",
					HttpStatus.INTERNAL_SERVER_ERROR);
		} else if (messageId.contains("TRACE:205!")) {
			throw new CustomException(INITIAL_EXCEPTION_MSG + " Insufficient Credits.",
					HttpStatus.INTERNAL_SERVER_ERROR);
		} else if (messageId.contains("TRACE:207!")) {
			throw new CustomException(INITIAL_EXCEPTION_MSG + " Un-authorized user.", HttpStatus.INTERNAL_SERVER_ERROR);
		} else if (messageId.contains("TRACE:209!")) {
			throw new CustomException(INITIAL_EXCEPTION_MSG + " Sender ID is not Valid.",
					HttpStatus.INTERNAL_SERVER_ERROR);
		} else if (messageId.contains("TRACE:105!")) {
			throw new CustomException(INITIAL_EXCEPTION_MSG + " Empty Message.", HttpStatus.INTERNAL_SERVER_ERROR);
		} else if (messageId.contains("TRACE:106!")) {
			throw new CustomException(INITIAL_EXCEPTION_MSG + " Invalid Mobile Number.",
					HttpStatus.INTERNAL_SERVER_ERROR);
		} else if (messageId.contains("TRACE:107!")) {
			throw new CustomException(INITIAL_EXCEPTION_MSG + " Not Valid API KEY.", HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.info("SMS: Sent Successfully to {}, message Id : {}", mobileNumber, messageId);

	}

}
