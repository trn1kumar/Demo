package com.gloqr.rest.endpoint;

import javax.ws.rs.client.Client;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;

import com.gloqr.exceptions.CustomException;

public class ContentServerEndpoint {

	private Client client;
	private String endPointUri;
	private String downloadFilePath;

	private static final Logger log = LogManager.getLogger();

	public ContentServerEndpoint(Client client, String endPointUri, String downloadFile) {
		this.client = client;
		this.endPointUri = endPointUri;
		this.downloadFilePath = downloadFile;
	}

	public byte[] downloadFileInBytes(String fileLocation) {

		Response response = null;
		byte[] fileBytes = null;

		log.info("Connecting to Content-Server... {method=GET ,uri= {}{} ,fileLocation= {} }", endPointUri,
				downloadFilePath, fileLocation);

		try {
			response = client.target(endPointUri).path(downloadFilePath).path(fileLocation)
					.request(MediaType.MULTIPART_FORM_DATA).get();
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}
		logResponse(response);

		Integer statusCode = response.getStatus();
		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}

		try {
			fileBytes = response.readEntity(byte[].class);

		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}

		return fileBytes;
	}

	private void throwEntityResponseReadException(Exception e) {
		throw new CustomException("Exception at read response from Content Server Module. Message: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	private void throwInvalidResponseException(int statusCode) {
		throw new CustomException("Invalid Response from Content Server Module: ", HttpStatus.resolve(statusCode));
	}

	private void throwConnectionRefusedException(Exception e) {
		throw new CustomException("Couldn't Connect to Content Server module, Exception: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	private void logResponse(Response response) {
		log.info("Response From Content Server Module : " + response);
	}

}
