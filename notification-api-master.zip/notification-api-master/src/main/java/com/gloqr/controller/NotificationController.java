package com.gloqr.controller;

import static com.gloqr.notification.EventService.EVENTSERVICE;

import java.util.Arrays;

import javax.annotation.PostConstruct;
import javax.mail.MessagingException;
import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.thymeleaf.util.StringUtils;

import com.gloqr.constants.UrlMapping;

import com.gloqr.dto.EmailEventDto;
import com.gloqr.dto.SchedulerJobDetailDto;
import com.gloqr.dto.SmsEventDto;
import com.gloqr.dto.UnsubscribeDto;
import com.gloqr.entities.EmailEvent;
import com.gloqr.entities.Event;
import com.gloqr.entities.SchedulerJobDetail;
import com.gloqr.entities.SmsEvent;
import com.gloqr.jpa.repositories.SchedulerConfigRepo;
import com.gloqr.mapper.NotificationMapper;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.model.http.response.ResponseMessage;
import com.gloqr.notification.EmailPublisher;
import com.gloqr.notification.EmailSubscriber;
import com.gloqr.notification.EventType;
import com.gloqr.notification.Filter;
import com.gloqr.notification.InvalidEventException;
import com.gloqr.notification.SmsPublisher;
import com.gloqr.notification.SmsSubscriber;
import com.gloqr.service.SchedulerService;

@RestController
@RequestMapping(value = UrlMapping.ROOT_API)
@SuppressWarnings("rawtypes")
public class NotificationController {

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private SmsPublisher smsPublisher;

	@Autowired
	private EmailPublisher emailPublisher;

	@Autowired
	private SmsSubscriber smsSubscriber;

	@Autowired
	private EmailSubscriber emailSubscriber;

	@Autowired
	private SchedulerService schedulerService;

	@Autowired
	private NotificationMapper mapper;

	@Value("${sms.sender}")
	private String sender;

	private static final Logger log = LogManager.getLogger();

	@Autowired
	SchedulerConfigRepo schedulerBasicConfigRepo;

	@PostConstruct
	public void intializeApplication() {
		log.info("Initalizing Application..........");

		Filter filter = new Filter();
		filter.apply(EventType.SMSEVENT, Event.LOW, Event.AVERAGE, Event.CRITICAL);

		smsSubscriber.setFilter(filter);

		Filter filter1 = new Filter();
		filter1.apply(EventType.EMAILEVENT, Event.LOW, Event.CRITICAL);

		emailSubscriber.setFilter(filter1);

		try {
			EVENTSERVICE.subscribe(smsSubscriber, SmsEvent.class);
			EVENTSERVICE.subscribe(emailSubscriber, EmailEvent.class);
		} catch (InvalidEventException e) {
			log.error("Exception thrown: " + e.getLocalizedMessage(), e);
		}
		log.info("Application Initialized.");

	}

	@PostMapping(UrlMapping.SEND_MAIL)
	public ResponseEntity<CustomHttpResponse> sendMail(@RequestBody final EmailEventDto emailEventDto)
			throws MessagingException {
		log.info("Request received for sending mail : " + emailEventDto.toString());

		EmailEvent emailEvent = mapper.convertToEntity(emailEventDto, EmailEvent.class);
		emailPublisher.publish(emailEvent);

		return responseMaker.successResponse("Mail sent.", HttpStatus.OK);

	}

	@PostMapping(UrlMapping.SEND_SMS)
	public ResponseEntity<CustomHttpResponse> sendSMS(@RequestBody final SmsEventDto smsEventDto)
			throws MessagingException {
		log.info("Request received for sending sms : " + smsEventDto.toString());

		SmsEvent smsEvent = mapper.convertToEntity(smsEventDto, SmsEvent.class);

		smsEvent.setSender(sender);
		smsPublisher.publish(smsEvent);

		return responseMaker.successResponse("SMS sent.", HttpStatus.OK);
	}

	@PostMapping(UrlMapping.SCHEDULE_JOB)
	public ResponseEntity<CustomHttpResponse> scheduleNewJob(
			@Valid @RequestBody final SchedulerJobDetailDto schedulerJobInfoDto,
			@RequestParam(required = false) String jobNameForUnSchedule) {

		try {
			if (!StringUtils.isEmptyOrWhitespace(jobNameForUnSchedule)) {
				log.info("Job available for Un-Schedule. JOB_NAME:- {}", jobNameForUnSchedule);
				schedulerService.unscheduleJob(jobNameForUnSchedule);
			}

			SmsEvent smsEvent = schedulerJobInfoDto.getSmsEvent();
			EmailEvent emailEvent = schedulerJobInfoDto.getEmailEvent();
			if (smsEvent != null) {
				smsEvent.setSender(sender);
			}

			SchedulerJobDetail schedulerJobInfo = mapper.convertToEntity(schedulerJobInfoDto, SchedulerJobDetail.class);
			schedulerJobInfo.setEmailEvents(Arrays.asList(emailEvent));
			schedulerJobInfo.setSmsEvents(Arrays.asList(smsEvent));

			schedulerService.saveSchedulerJobInfo(schedulerJobInfo);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessage.SUCCESS, HttpStatus.OK);
	}

	@PutMapping(UrlMapping.UNSCHEDULE_JOB)
	public ResponseEntity<CustomHttpResponse> unscheduleJob(@RequestParam String jobName) {
		schedulerService.unscheduleJob(jobName);
		return responseMaker.successResponse(ResponseMessage.SUCCESS, HttpStatus.OK);
	}

	@PostMapping(UrlMapping.UNSUBSCRIBE_MAIL)
	@CrossOrigin("*")
	public ResponseEntity<CustomHttpResponse> saveUnsubscribeMailDetail(
			@Valid @RequestBody UnsubscribeDto unsubscribeDto) throws MessagingException {
		EmailEvent emailEvent = new EmailEvent();
		emailEvent.setEmailId("mumbai@gloqr.com");
		String emailMsg = "Dear Priya, <br> <br> Please Unsubscribe given email Id:- "
				+ unsubscribeDto.getUnSubscribeEmailId() + ".";

		if (unsubscribeDto.getUnSubscribeReason() != null) {
			emailMsg = emailMsg + "<br> <br> Reason:- " + unsubscribeDto.getUnSubscribeReason() + ".";
		}
		emailEvent.setEventMessage(emailMsg);
		emailEvent.setSubject("Request for Un-Subscribe Email");
		emailPublisher.publish(emailEvent);

		return responseMaker.successResponse("Mail sent.", HttpStatus.OK);
	}
}
