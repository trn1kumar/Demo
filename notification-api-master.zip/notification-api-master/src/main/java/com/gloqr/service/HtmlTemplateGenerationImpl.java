package com.gloqr.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.gloqr.constants.JobGroup;
import com.gloqr.constants.JobSubGroup;
import com.gloqr.constants.NotificationTemplates;
import com.gloqr.constants.SchedulerType;
import com.gloqr.exceptions.CustomException;
import com.gloqr.model.remind.notification.BICartNotificationData;
import com.gloqr.model.remind.notification.CircleNotificationData;
import com.gloqr.util.JsonUtil;

@Service
public class HtmlTemplateGenerationImpl implements HtmlTemplateGeneration {

	@Autowired
	private TemplateEngine templateEngine;

	@Autowired
	private JsonUtil jsonUtil;

	@Autowired
	private NotificationTemplates templates;

	@Override
	public String generateHtmlTemplate(final String jobDataJsonString, final JobGroup jobGroup,
			final JobSubGroup jobSubGroup, final SchedulerType schedulerType) {
		String htmlTemplate = null;

		try {
			if (jobGroup.equals(JobGroup.CIRCLE_NOTIFICATION)) {
				CircleNotificationData data = jsonUtil.parseJsonData(jobDataJsonString, CircleNotificationData.class);

				Map<JobSubGroup, Map<SchedulerType, String>> subGrpsAndTemplates = templates
						.getCircleNotificationTemplates();
				htmlTemplate = generateTemplates(subGrpsAndTemplates, jobSubGroup, schedulerType, data);

			} else if (jobGroup.equals(JobGroup.BI_NOTIFICATION)) {

				BICartNotificationData data = jsonUtil.parseJsonData(jobDataJsonString, BICartNotificationData.class);

				Map<JobSubGroup, Map<SchedulerType, String>> subGrpsAndTemplates = templates
						.getBiNotificationTemplates();
				htmlTemplate = generateTemplates(subGrpsAndTemplates, jobSubGroup, schedulerType, data);

			}
		} catch (Exception e) {
			throw new CustomException(
					"Error while create html template for jobGroup: '" + jobGroup + "',jobSubGroup: '" + jobSubGroup
							+ "',schedulerType: '" + schedulerType + "'.    Message:-  " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return htmlTemplate;
	}

	private <T> String generateTemplates(Map<JobSubGroup, Map<SchedulerType, String>> subGrpsAndTemplates,
			JobSubGroup jobSubGroup, SchedulerType schedulerType, T data) {
		String template = null;
		for (Map.Entry<JobSubGroup, Map<SchedulerType, String>> grps : subGrpsAndTemplates.entrySet()) {
			if (jobSubGroup.equals(grps.getKey())) {
				Map<SchedulerType, String> templatesMap = grps.getValue();
				for (Map.Entry<SchedulerType, String> types : templatesMap.entrySet()) {
					if (schedulerType.equals(types.getKey())) {
						Context context = new Context();
						context.setVariable("data", data);
						template = create(types.getValue(), context);
						break;
					}
				}
				break;
			}

		}

		if (template == null)
			throw new CustomException(
					"'" + schedulerType + "' Scheduler Type is Invalid Selection to Create html template for '"
							+ jobSubGroup + "'job sub-group.",
					HttpStatus.INTERNAL_SERVER_ERROR);

		return template;
	}

	private String create(String template, Context context) {
		return templateEngine.process(template, context);
	}

}
