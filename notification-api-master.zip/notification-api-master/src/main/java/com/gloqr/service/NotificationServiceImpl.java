package com.gloqr.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.entities.EmailEvent;
import com.gloqr.entities.Event;
import com.gloqr.entities.SmsEvent;
import com.gloqr.notification.EmailPublisher;
import com.gloqr.notification.SmsPublisher;

@Service
public class NotificationServiceImpl implements NotificationService {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private EmailPublisher emailPublisher;

	@Autowired
	private SmsPublisher smsPublisher;

	@Override
	public void sendNotifications(List<Event> events) {
		events.parallelStream().forEach(event -> {
			if (event instanceof EmailEvent) {
				sendEmail((EmailEvent) event);
			}

			if (event instanceof SmsEvent) {
				sendSms((SmsEvent) event);
			}
		});

	}

	private void sendEmail(EmailEvent emailEvent) {
		if (emailEvent != null) {
			try {
				emailPublisher.publish(emailEvent);
			} catch (Exception e) {
				log.error("Scheduled Email Sent failed.");
			}
		}

	}

	private void sendSms(SmsEvent smsEvent) {
		if (smsEvent != null) {
			try {
				smsPublisher.publish(smsEvent);
			} catch (Exception e) {
				log.error("Scheduled SMS Sent failed.");
			}
		}

	}

}
