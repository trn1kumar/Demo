package com.gloqr.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.gloqr.dao.NotificationEventDao;
import com.gloqr.entities.EmailEvent;
import com.gloqr.entities.SmsEvent;
import com.gloqr.notification.EmailPublisher;
import com.gloqr.notification.SmsPublisher;

@Service
public class FailedEventHandler {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private NotificationEventDao eventDao;

	@Autowired
	private SmsPublisher smsPublisher;

	@Autowired
	private EmailPublisher emailPublisher;

	// 10 Sec
	@Scheduled(fixedRate = 10000)
	private void failedSmsEventHandlerScheduler() {
		List<SmsEvent> smsEvents = eventDao.getFailedSmsEvents();

		if (!smsEvents.isEmpty()) {
			smsEvents.parallelStream().forEach(event -> {
				int totalResendCount = event.getTotalResendCount() + 1;
				log.info("Resending failed SmsEvent, SmsEventId:: {} and Total Resend Count:: {}",
						event.getSmsEventId(), totalResendCount);
				try {

					event.setTotalResendCount(totalResendCount);
					smsPublisher.publish(event);
				} catch (Exception e) {
					log.error("Exception in failedSmsEventHandlerScheduler( ) . message:: {}", e.getMessage());
				}

			});
		}
	}

	// 10 Sec
	@Scheduled(fixedRate = 10000)
	private void failedEmailEventHandlerScheduler() {
		List<EmailEvent> emailEvents = eventDao.getFailedEmailEvents();

		if (!emailEvents.isEmpty()) {
			emailEvents.parallelStream().forEach(event -> {
				int totalResendCount = event.getTotalResendCount() + 1;
				log.info("Resending failed EmailEvent, EmailEventId:: {} and Total Resend Count:: {}",
						event.getEmailEventId(), totalResendCount);
				try {
					event.setTotalResendCount(totalResendCount);
					emailPublisher.publish(event);
				} catch (Exception e) {
					log.error("Exception in failedEmailEventHandlerScheduler( ), . message:: {}", e.getMessage());
				}

			});
		}
	}
}
