package com.gloqr.service;

import com.gloqr.constants.JobGroup;
import com.gloqr.constants.JobSubGroup;
import com.gloqr.constants.SchedulerType;

public interface HtmlTemplateGeneration {

	public String generateHtmlTemplate(final String jobDataJsonString, final JobGroup jobGroup,
			final JobSubGroup jobSubGroup, final SchedulerType schedulerType);

}
