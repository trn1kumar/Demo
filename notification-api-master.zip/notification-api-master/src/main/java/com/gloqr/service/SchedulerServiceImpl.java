package com.gloqr.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gloqr.constants.SchedulerType;
import com.gloqr.dao.SchedulingDao;
import com.gloqr.entities.EmailEvent;
import com.gloqr.entities.Event;
import com.gloqr.entities.SchedulerConfig;
import com.gloqr.entities.SchedulerJobDetail;
import com.gloqr.entities.SmsEvent;

@Service
public class SchedulerServiceImpl implements SchedulerService {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private SchedulingDao schedulingDao;

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private HtmlTemplateGeneration templateGeneration;

	@Override
	public void saveSchedulerJobInfo(SchedulerJobDetail jobDetail) {

		List<SchedulerConfig> schedulerBasicConfigs = schedulingDao
				.getSchedulerConfigsBySchedulerGroup(jobDetail.getJobGroup());
		jobDetail.setSchedulerConfigs(schedulerBasicConfigs);

		schedulingDao.saveSchedulerJobInfo(jobDetail);
	}

	// 30 Sec
	@Scheduled(fixedRate = 30000)
	@Transactional(readOnly = true)
	public void executeImmediateJobs() {
		List<SchedulerJobDetail> jobs = schedulingDao.getImmediateExecutedJobs();
		if (!jobs.isEmpty()) {
			manageImmediateExecutedJobs(jobs);
		}

	}

	private void manageImmediateExecutedJobs(List<SchedulerJobDetail> jobs) {
		jobs.parallelStream().forEach(jobDetail -> {
			log.info("'IMMEDIATE' Executing JOB_NAME:- {}", jobDetail.getJobName());
			List<Event> events = new ArrayList<>();

			if (jobDetail.getSmsEvents() != null && !jobDetail.getSmsEvents().isEmpty())
				events.add(jobDetail.getSmsEvents().get(0));
			if (jobDetail.getEmailEvents() != null && !jobDetail.getEmailEvents().isEmpty())
				events.add(jobDetail.getEmailEvents().get(0));

			notificationService.sendNotifications(events);

			Date nextExecutionTime = getNextExecutionTimeFromImmediateExecution(jobDetail);
			
			jobDetail.setNextExecutionTime(nextExecutionTime);
			jobDetail.setImmediateExecutionComplete(true);
			setUnScheduleStatus(jobDetail);
			schedulingDao.saveSchedulerJobInfo(jobDetail);

		});
	}

	// 5 mins
	@Scheduled(fixedRate = 300000)
	@Transactional(readOnly = true)
	public void executeDailyJobs() {
		List<SchedulerJobDetail> jobs = schedulingDao.getDailyExecutedJobs();
		if (!jobs.isEmpty()) {
			manageDailyExecutedJobs(jobs);
		}

	}

	private void manageDailyExecutedJobs(List<SchedulerJobDetail> jobs) {
		jobs.parallelStream().forEach(jobDetail -> {
			int dailyExecutedCount = jobDetail.getDailyExecutedCount();

			SchedulerConfig schedulerConfig = getFilteredSchedulerConfig(jobDetail, SchedulerType.DAILY).get();

			int freq = schedulerConfig.getFrequency();
			if (dailyExecutedCount < freq) {
				log.info("'DAILY' Executing JOB_NAME:- {}", jobDetail.getJobName());

				sendNotificationEvents(jobDetail, SchedulerType.DAILY);

				log.info("Increasing 'DAILY' Executed Count by 'ONE' for JOB:- {}", jobDetail.getJobName());
				jobDetail.setDailyExecutedCount(dailyExecutedCount + 1);
				int nextExecutedCount = dailyExecutedCount + 1;
				log.info("Current Execution Count: {} and 'DAILY' Scheduler Frequency: {}", nextExecutedCount, freq);
				if (nextExecutedCount == freq) {
					log.info("Updating 'DAILY' Execution Complete for JOB:- {}", jobDetail.getJobName());
					jobDetail.setDailyExecutionComplete(true);
				}
				setNextExecutionTimeFromDailyExecution(jobDetail, schedulerConfig);
				setUnScheduleStatus(jobDetail);
				schedulingDao.saveSchedulerJobInfo(jobDetail);
			}
		});
	}

	// 7 mins
	@Scheduled(fixedRate = 420000)
	@Transactional(readOnly = true)
	public void executeWeeklyJobs() {
		List<SchedulerJobDetail> jobs = schedulingDao.getWeeklyExecutedJobs();
		if (!jobs.isEmpty()) {
			manageWeeklyExecutedJobs(jobs);
		}

	}

	private void manageWeeklyExecutedJobs(List<SchedulerJobDetail> jobs) {
		jobs.forEach(jobDetail -> {

			int weeklyExecutedCount = jobDetail.getWeeklyExecutedCount();
			SchedulerConfig schedulerConfig = getFilteredSchedulerConfig(jobDetail, SchedulerType.WEEKLY).get();

			int freq = schedulerConfig.getFrequency();
			if (weeklyExecutedCount < freq) {
				log.info("'WEEKLY' Executing JOB_NAME: {}", jobDetail.getJobName());
				sendNotificationEvents(jobDetail, SchedulerType.WEEKLY);

				log.info("Increasing 'WEEKLY' Executed Count by 'ONE' for JOB: {}", jobDetail.getJobName());
				jobDetail.setWeeklyExecutedCount(weeklyExecutedCount + 1);
				int nextExecutedCount = weeklyExecutedCount + 1;

				log.info("Current Execution Count: {} and 'WEEKLY' Scheduler Frequency: {}", nextExecutedCount, freq);
				if (nextExecutedCount == freq) {
					log.info("Updating 'WEEKLY' Execution Complete for JOB: {}", jobDetail.getJobName());
					jobDetail.setWeeklyExecutionComplete(true);
				}
				setNextExecutionTimeFromWeeklyExecution(jobDetail, schedulerConfig);
				setUnScheduleStatus(jobDetail);
				schedulingDao.saveSchedulerJobInfo(jobDetail);
			}
		});
	}

	// 9 mins
	@Scheduled(fixedRate = 540000)
	@Transactional(readOnly = true)
	public void executeMonthlyJobs() {
		List<SchedulerJobDetail> jobs = schedulingDao.getMonthlyExecutedJobs();
		if (!jobs.isEmpty()) {
			manageMonthlyExecutedJobs(jobs);
		}

	}

	private void manageMonthlyExecutedJobs(List<SchedulerJobDetail> jobs) {
		jobs.forEach(jobDetail -> {

			int monthlyExecutedCount = jobDetail.getMonthlyExecutedCount();
			SchedulerConfig schedulerConfig = getFilteredSchedulerConfig(jobDetail, SchedulerType.MONTHLY).get();
			int freq = schedulerConfig.getFrequency();

			if (monthlyExecutedCount < freq) {
				log.info("'MONTHLY' Executing JOB_NAME: {}", jobDetail.getJobName());

				sendNotificationEvents(jobDetail, SchedulerType.MONTHLY);

				log.info("Increasing 'MONTHLY' Executed Count by 'ONE' for JOB: {}", jobDetail.getJobName());
				jobDetail.setMonthlyExecutedCount(monthlyExecutedCount + 1);
				int nextExecutedCount = monthlyExecutedCount + 1;

				log.info("Current Execution Count: {} and 'MONTHLY' Scheduler Frequency: {}", nextExecutedCount, freq);
				if (nextExecutedCount == freq) {
					log.info("Updating 'MONTHLY' Execution Complete for JOB: {}", jobDetail.getJobName());
					jobDetail.setMonthlyExecutionComplete(true);
				}
				setNextExecutionTimeFromMonthlyExecution(jobDetail, schedulerConfig);
				setUnScheduleStatus(jobDetail);
				schedulingDao.saveSchedulerJobInfo(jobDetail);
			}
		});
	}

	// 12 mins
	@Scheduled(fixedRate = 720000)
	@Transactional(readOnly = true)
	public void executeYearlyJobs() {
		List<SchedulerJobDetail> jobs = schedulingDao.getYearlyExecutedJobs();
		if (!jobs.isEmpty()) {
			manageYearlyExecutedJobs(jobs);
		}

	}

	private void manageYearlyExecutedJobs(List<SchedulerJobDetail> jobs) {
		jobs.forEach(jobDetail -> {

			int yearlyExecutedCount = jobDetail.getYearlyExecutedCount();
			SchedulerConfig schedulerConfig = getFilteredSchedulerConfig(jobDetail, SchedulerType.YEARLY).get();
			int freq = schedulerConfig.getFrequency();
			if (yearlyExecutedCount < freq) {
				log.info("'YEARLY' Executing JOB_NAME: ", jobDetail.getJobName());

				sendNotificationEvents(jobDetail, SchedulerType.YEARLY);

				log.info("Increasing 'YEARLY' Executed Count by 'ONE' for JOB: ", jobDetail.getJobName());
				jobDetail.setYearlyExecutedCount(yearlyExecutedCount + 1);
				int nextExecutedCount = yearlyExecutedCount + 1;
				log.info("Current Execution Count: {} and 'YEARLY' Scheduler Frequency: {}", nextExecutedCount, freq);
				if (nextExecutedCount == freq) {
					log.info("Updating 'YEARLY' Execution Complete 'TRUE' for JOB: ", jobDetail.getJobName());
					jobDetail.setYearlyExecutionComplete(true);
				}
				setUnScheduleStatus(jobDetail);
				schedulingDao.saveSchedulerJobInfo(jobDetail);
			}
		});
	}

	private Date getNextExecutionTimeFromImmediateExecution(SchedulerJobDetail jobDetail) {
		Calendar c = Calendar.getInstance();
		Optional<SchedulerConfig> dailyConfigOpt = getFilteredSchedulerConfig(jobDetail, SchedulerType.DAILY);
		if (dailyConfigOpt.isPresent()) {
			SchedulerConfig dailyConfig = dailyConfigOpt.get();
			Date date = getDate(jobDetail.getNextExecutionTime());
			c.setTime(date);
			int days = dailyConfig.getInitialDelay();

			if (days < 1) {
				log.info("'DAILY' Initial Delay {} is less then 1 day.Setting Default 1 day Initial Delay", days);
				days = 1;
			}
			c.add(Calendar.DATE, days);

			logNextExcecutionTime(c.getTime(), jobDetail.getJobName());

		} else {
			log.info("NO 'DAILY' Scheduler Type Available for JOB:{} ,after 'HOURLY' Scheduler Type Execute completely",
					jobDetail.getJobName());
		}
		return c.getTime();
	}

	private void setNextExecutionTimeFromDailyExecution(SchedulerJobDetail jobDetail, SchedulerConfig schedulerConfig) {
		int days = 0;
		Calendar c = Calendar.getInstance();
		Date date = getDate(jobDetail.getNextExecutionTime());
		c.setTime(date);
		if (jobDetail.isDailyExecutionComplete()) {
			Optional<SchedulerConfig> weeklyConfigOpt = getFilteredSchedulerConfig(jobDetail, SchedulerType.WEEKLY);

			if (weeklyConfigOpt.isPresent()) {
				SchedulerConfig weeklyConfig = weeklyConfigOpt.get();
				days = weeklyConfig.getInitialDelay();
				if (days < 7) {
					log.info("'WEEKLY' Initial Delay {} is less then 7 days.Setting Default 7 days Initial Delay",
							days);
					days = 7;
				}
			} else {
				log.info(
						"NO 'WEEKLY' Scheduler Type Available for JOB:{} ,after 'DAILY' Scheduler Type Execute completely",
						jobDetail.getJobName());
			}
		} else {
			days = schedulerConfig.getIntervalTime();
			if (days < 1) {
				log.info("'DAILY' Interval Time {} is less then 1 day.Setting Default 1 day Interval Time", days);
				days = 1;
			}

		}
		c.add(Calendar.DATE, days);

		if (days > 1)
			logNextExcecutionTime(c.getTime(), jobDetail.getJobName());
		jobDetail.setNextExecutionTime(c.getTime());
	}

	private void setNextExecutionTimeFromWeeklyExecution(SchedulerJobDetail jobDetail,
			SchedulerConfig schedulerConfig) {
		int days = 0;
		Calendar c = Calendar.getInstance();
		Date date = getDate(jobDetail.getNextExecutionTime());
		c.setTime(date);
		if (jobDetail.isWeeklyExecutionComplete()) {
			Optional<SchedulerConfig> monthlyConfigOpt = getFilteredSchedulerConfig(jobDetail, SchedulerType.MONTHLY);

			if (monthlyConfigOpt.isPresent()) {
				SchedulerConfig monthlyConfig = monthlyConfigOpt.get();
				days = monthlyConfig.getInitialDelay();
				if (days < 30) {
					log.info("'MONTHLY' Initial Delay {} is less then 30 days.Setting Default 30 days Initial Delay",
							days);
					days = 30;
				}
			} else {
				log.info(
						"NO 'MONTHLY' Scheduler Type Available for JOB:{} ,after 'WEEKLY' Scheduler Type Execute completely",
						jobDetail.getJobName());
			}
		} else {
			days = schedulerConfig.getIntervalTime();
			if (days < 7) {
				log.info("'WEEKLY' Interval Time {} is less then 7 days.Setting Default 7 days Interval Time", days);
				days = 7;
			}

		}
		c.add(Calendar.DATE, days);
		if (days > 1)
			logNextExcecutionTime(c.getTime(), jobDetail.getJobName());
		jobDetail.setNextExecutionTime(c.getTime());
	}

	private void setNextExecutionTimeFromMonthlyExecution(SchedulerJobDetail jobDetail,
			SchedulerConfig schedulerConfig) {
		int days = 0;
		Calendar c = Calendar.getInstance();
		Date date = getDate(jobDetail.getNextExecutionTime());
		c.setTime(date);
		if (!jobDetail.isMonthlyExecutionComplete()) {
			days = schedulerConfig.getIntervalTime();
			if (days < 30) {
				log.info("'MONTHLY' Interval Time {} is less then 30 days.Setting Default 30 days Interval Time", days);
				days = 30;
			}
			c.add(Calendar.DATE, days);

			if (days > 1)
				logNextExcecutionTime(c.getTime(), jobDetail.getJobName());
			jobDetail.setNextExecutionTime(c.getTime());
		}

	}

	private Date getDate(Date date) {
		return date != null ? date : new Date();
	}

	private Optional<SchedulerConfig> getFilteredSchedulerConfig(SchedulerJobDetail jobDetail,
			SchedulerType schedulerType) {
		return jobDetail.getSchedulerConfigs().stream()
				.filter(config -> config.getSchedulerType().equals(schedulerType)).findFirst();
	}

	private void setUnScheduleStatus(SchedulerJobDetail jobDetail) {

		boolean isUnSchedule = false;

		for (SchedulerConfig jobConfig : jobDetail.getSchedulerConfigs()) {

			if (jobConfig.getSchedulerType().equals(SchedulerType.DAILY)) {
				if (jobDetail.isDailyExecutionComplete()) {
					isUnSchedule = true;
				} else {
					isUnSchedule = false;
					break;
				}
			}

			if (jobConfig.getSchedulerType().equals(SchedulerType.MONTHLY)) {
				if (jobDetail.isMonthlyExecutionComplete()) {
					isUnSchedule = true;
				} else {
					isUnSchedule = false;
					break;
				}
			}

			if (jobConfig.getSchedulerType().equals(SchedulerType.WEEKLY)) {
				if (jobDetail.isWeeklyExecutionComplete()) {
					isUnSchedule = true;
				} else {
					isUnSchedule = false;
					break;
				}
			}

			if (jobConfig.getSchedulerType().equals(SchedulerType.YEARLY)) {
				if (jobDetail.isYearlyExecutionComplete()) {
					isUnSchedule = true;
				} else {
					isUnSchedule = false;
					break;
				}
			}

		}
		jobDetail.setUnSchedule(isUnSchedule);
	}

	@Override
	public void unscheduleJob(String jobName) {
		schedulingDao.unscheduleJobByJobName(jobName);
	}

	private void sendNotificationEvents(SchedulerJobDetail jobDetail, SchedulerType schedulerType) {
		List<Event> events = new ArrayList<>();
		if (jobDetail.getSmsEvents() != null && !jobDetail.getSmsEvents().isEmpty()) {
			SmsEvent smsDetail = jobDetail.getSmsEvents().get(0);
			SmsEvent smsEvent = new SmsEvent(smsDetail.getMobileNo(), smsDetail.getEventMessage(),
					smsDetail.getSender());
			jobDetail.getSmsEvents().add(smsEvent);
			events.add(smsEvent);
		}
		if (jobDetail.getEmailEvents() != null && !jobDetail.getEmailEvents().isEmpty()
				&& jobDetail.getRemindNotifiJobDataJsonString() != null) {
			EmailEvent emailDetail = jobDetail.getEmailEvents().get(0);
			try {
				String eventMessage = templateGeneration.generateHtmlTemplate(
						jobDetail.getRemindNotifiJobDataJsonString(), jobDetail.getJobGroup(),
						jobDetail.getJobSubGroup(), schedulerType);

				EmailEvent emailEvent = new EmailEvent(emailDetail.getEmailId(), emailDetail.getSubject(), eventMessage,
						emailDetail.getAttachmentFileLocation());

				jobDetail.getEmailEvents().add(emailEvent);
				events.add(emailEvent);
			} catch (Exception e) {
				log.error("Error in createNotificationEvents() .  message:  {}", e.getMessage());
			}

		}

		if (!events.isEmpty())
			notificationService.sendNotifications(events);

	}

	private void logNextExcecutionTime(Date date, String jobName) {
		SimpleDateFormat ft = new SimpleDateFormat("E yyyy.MM.dd 'at' hh:mm:ss a");
		log.info("Next Execution At: {} for JOB: {}", ft.format(date), jobName);
	}

}
