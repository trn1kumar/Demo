package com.gloqr.service;

import com.gloqr.entities.SchedulerJobDetail;

public interface SchedulerService {

	void saveSchedulerJobInfo(SchedulerJobDetail schedulerJobInfo);

	void unscheduleJob(String jobName);

}
