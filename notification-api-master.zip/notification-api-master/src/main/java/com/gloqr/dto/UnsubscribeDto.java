package com.gloqr.dto;

public class UnsubscribeDto {

	private String unSubscribeEmailId;
	private String unSubscribeReason;
	
	
	public String getUnSubscribeReason() {
		return unSubscribeReason;
	}
	public void setUnSubscribeReason(String unSubscribeReason) {
		this.unSubscribeReason = unSubscribeReason;
	}
	public String getUnSubscribeEmailId() {
		return unSubscribeEmailId;
	}
	public void setUnSubscribeEmailId(String unSubscribeEmailId) {
		this.unSubscribeEmailId = unSubscribeEmailId;
	}

	
	
}
