package com.gloqr.dto;

public class EmailEventDto {

	private Long emailEventId;
	private String emailId;
	private String subject;
	private String eventMessage;
	private String attachmentFileLocation;

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getEventMessage() {
		return eventMessage;
	}

	public void setEventMessage(String eventMessage) {
		this.eventMessage = eventMessage;
	}

	public String getAttachmentFileLocation() {
		return attachmentFileLocation;
	}

	public void setAttachmentFileLocation(String attachmentFileLocation) {
		this.attachmentFileLocation = attachmentFileLocation;
	}

	@Override
	public String toString() {
		return "EmailEventDto [emailId=" + emailId + ", subject=" + subject + "]";
	}

	public Long getEmailEventId() {
		return emailEventId;
	}

	public void setEmailEventId(Long emailEventId) {
		this.emailEventId = emailEventId;
	}

}
