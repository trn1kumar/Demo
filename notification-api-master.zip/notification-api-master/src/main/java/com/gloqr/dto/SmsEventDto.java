package com.gloqr.dto;

public class SmsEventDto {

	private String mobileNo;
	private String eventMessage;

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEventMessage() {
		return eventMessage;
	}

	public void setEventMessage(String eventMessage) {
		this.eventMessage = eventMessage;
	}

	@Override
	public String toString() {
		return "SmsEventDto [mobileNo=" + mobileNo + ", eventMessage=" + eventMessage + "]";
	}

}
