package com.gloqr.dto;

import javax.validation.constraints.NotNull;

import com.gloqr.constants.JobGroup;
import com.gloqr.constants.JobSubGroup;
import com.gloqr.entities.EmailEvent;
import com.gloqr.entities.SmsEvent;

public class SchedulerJobDetailDto {

	@NotNull(message = "Job Name Required")
	private String jobName;

	@NotNull(message = "Job Group Required")
	private JobGroup jobGroup;

	@NotNull(message = "Job Sub Group Required")
	private JobSubGroup jobSubGroup;

	private String remindNotifiJobDataJsonString;

	private EmailEvent emailEvent;
	private SmsEvent smsEvent;

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public JobGroup getJobGroup() {
		return jobGroup;
	}

	public void setJobGroup(JobGroup jobGroup) {
		this.jobGroup = jobGroup;
	}

	public JobSubGroup getJobSubGroup() {
		return jobSubGroup;
	}

	public void setJobSubGroup(JobSubGroup jobSubGroup) {
		this.jobSubGroup = jobSubGroup;
	}

	public EmailEvent getEmailEvent() {
		return emailEvent;
	}

	public void setEmailEvent(EmailEvent emailEvent) {
		this.emailEvent = emailEvent;
	}

	public SmsEvent getSmsEvent() {
		return smsEvent;
	}

	public void setSmsEvent(SmsEvent smsEvent) {
		this.smsEvent = smsEvent;
	}

	public String getRemindNotifiJobDataJsonString() {
		return remindNotifiJobDataJsonString;
	}

	public void setRemindNotifiJobDataJsonString(String remindNotifiJobDataJsonString) {
		this.remindNotifiJobDataJsonString = remindNotifiJobDataJsonString;
	}

}
