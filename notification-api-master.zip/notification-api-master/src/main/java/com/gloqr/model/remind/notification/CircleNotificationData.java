package com.gloqr.model.remind.notification;

public class CircleNotificationData {

	private String smeDetailsUrl;
	private String pendingReqUrl;
	private String reqReceiverSmeName;
	private String reqReceiverSmeId;
	private int mutualConnsCount;
	private int circleConnsCount;

	private TemplateCommonUrls urls;
	private SMEDetails smeDetails;

	public String getSmeDetailsUrl() {
		return smeDetailsUrl;
	}

	public void setSmeDetailsUrl(String smeDetailsUrl) {
		this.smeDetailsUrl = smeDetailsUrl;
	}

	public String getPendingReqUrl() {
		return pendingReqUrl;
	}

	public void setPendingReqUrl(String pendingReqUrl) {
		this.pendingReqUrl = pendingReqUrl;
	}

	public String getReqReceiverSmeName() {
		return reqReceiverSmeName;
	}

	public void setReqReceiverSmeName(String reqReceiverSmeName) {
		this.reqReceiverSmeName = reqReceiverSmeName;
	}

	public SMEDetails getSmeDetails() {
		return smeDetails;
	}

	public void setSmeDetails(SMEDetails smeDetails) {
		this.smeDetails = smeDetails;
	}

	public int getMutualConnsCount() {
		return mutualConnsCount;
	}

	public void setMutualConnsCount(int mutualConnsCount) {
		this.mutualConnsCount = mutualConnsCount;
	}

	public int getCircleConnsCount() {
		return circleConnsCount;
	}

	public void setCircleConnsCount(int circleConnsCount) {
		this.circleConnsCount = circleConnsCount;
	}

	public TemplateCommonUrls getUrls() {
		return urls;
	}

	public void setUrls(TemplateCommonUrls urls) {
		this.urls = urls;
	}

	public String getReqReceiverSmeId() {
		return reqReceiverSmeId;
	}

	public void setReqReceiverSmeId(String reqReceiverSmeId) {
		this.reqReceiverSmeId = reqReceiverSmeId;
	}

}
