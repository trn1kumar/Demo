package com.gloqr.model.remind.notification;

public class BICartNotificationData {

	private String userDetailsImgPath;
	private String secondCartStageImgPath;
	private String thirdCartStageImgPath;
	private String fourthCartStageImgPath;
	
	private TemplateCommonUrls urls;
	private BiCartItemData cartItem;

	public TemplateCommonUrls getUrls() {
		return urls;
	}

	public void setUrls(TemplateCommonUrls urls) {
		this.urls = urls;
	}

	public BiCartItemData getCartItem() {
		return cartItem; 
	}

	public void setCartItem(BiCartItemData cartItem) {
		this.cartItem = cartItem;
	}


	public String getUserDetailsImgPath() {
		return userDetailsImgPath;
	}

	public void setUserDetailsImgPath(String userDetailsImgPath) {
		this.userDetailsImgPath = userDetailsImgPath;
	}

	public String getSecondCartStageImgPath() {
		return secondCartStageImgPath;
	}

	public void setSecondCartStageImgPath(String secondCartStageImgPath) {
		this.secondCartStageImgPath = secondCartStageImgPath;
	}

	public String getThirdCartStageImgPath() {
		return thirdCartStageImgPath;
	}

	public void setThirdCartStageImgPath(String thirdCartStageImgPath) {
		this.thirdCartStageImgPath = thirdCartStageImgPath;
	}

	public String getFourthCartStageImgPath() {
		return fourthCartStageImgPath;
	}

	public void setFourthCartStageImgPath(String fourthCartStageImgPath) {
		this.fourthCartStageImgPath = fourthCartStageImgPath;
	}

}
