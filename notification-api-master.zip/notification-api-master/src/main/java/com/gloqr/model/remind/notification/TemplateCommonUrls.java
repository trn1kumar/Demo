package com.gloqr.model.remind.notification;

public class TemplateCommonUrls {

	private String websiteUrl;
	private String contentServerUrl;
	private String gloqrLogoPath;
	private String fbLogoPath;
	private String linkedinLogoPath;
	private String twitterLogoPath;
	private String instaLogoPath;
	private String ytLogoPath;

	public void setWebsiteUrl(String websiteUrl) {
		this.websiteUrl = websiteUrl;
	}

	public void setContentServerUrl(String contentServerUrl) {
		this.contentServerUrl = contentServerUrl;
	}

	public void setGloqrLogoPath(String gloqrLogoPath) {
		this.gloqrLogoPath = gloqrLogoPath;
	}

	public void setFbLogoPath(String fbLogoPath) {
		this.fbLogoPath = fbLogoPath;
	}

	public void setLinkedinLogoPath(String linkedinLogoPath) {
		this.linkedinLogoPath = linkedinLogoPath;
	}

	public void setTwitterLogoPath(String twitterLogoPath) {
		this.twitterLogoPath = twitterLogoPath;
	}

	public void setInstaLogoPath(String instaLogoPath) {
		this.instaLogoPath = instaLogoPath;
	}

	public void setYtLogoPath(String ytLogoPath) {
		this.ytLogoPath = ytLogoPath;
	}

	public String getWebsiteUrl() {
		return websiteUrl;
	}

	public String getContentServerUrl() {
		return contentServerUrl;
	}

	public String getGloqrLogoPath() {
		return gloqrLogoPath;
	}

	public String getFbLogoPath() {
		return fbLogoPath;
	}

	public String getLinkedinLogoPath() {
		return linkedinLogoPath;
	}

	public String getTwitterLogoPath() {
		return twitterLogoPath;
	}

	public String getInstaLogoPath() {
		return instaLogoPath;
	}

	public String getYtLogoPath() {
		return ytLogoPath;
	}

}
