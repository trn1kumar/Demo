package com.gloqr.model.http.response;

public class ResponseMessage {

	public static final String SUCCESS = "Success";
}
