package com.gloqr.notification;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.dao.NotificationEventDao;
import com.gloqr.entities.Event;
import com.gloqr.entities.SmsEvent;
import com.gloqr.rest.endpoint.BulkSmsEndpoint;

@Service
public class SmsSubscriber extends Subscriber {

	@Autowired
	private NotificationEventDao notificationEventDao;

	@Autowired
	private BulkSmsEndpoint bulkSmsEndpoint;

	private static final Logger log = LogManager.getLogger();

	@Override
	public void inform(Event event) {

		SmsEvent smsEvent = (SmsEvent) event;

		log.info("SMS: Sending to {} . textMessage:- {}", smsEvent.getMobileNo(), smsEvent.getEventMessage());

		try {
			bulkSmsEndpoint.callBulkSmsApi(smsEvent.getMobileNo(), smsEvent.getEventMessage(), smsEvent.getSender());
			smsEvent.setSentStatus(true);
			smsEvent.setFailedStatus(false);
			notificationEventDao.saveSmsToDB(smsEvent);
		} catch (Exception e) {

			log.info("SMS SENDING ON {} FAILED.", smsEvent.getMobileNo());
			smsEvent.setFailedStatus(true);
			notificationEventDao.saveSmsToDB(smsEvent);
			throw e;
		}

	}

	public EventType getSubscriberEventType() {
		return EventType.SMSEVENT;
	}
}
