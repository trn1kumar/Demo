package com.gloqr.notification;

import javax.mail.MessagingException;

import com.gloqr.entities.Event;

public abstract class Subscriber {
	protected Filter filter = null;

	public abstract void inform(Event event) throws MessagingException;

	public void setFilter(Filter filter) {
		this.filter = filter;
	}

	public Filter getFilter() {
		return this.filter;
	}

	public abstract EventType getSubscriberEventType();
}