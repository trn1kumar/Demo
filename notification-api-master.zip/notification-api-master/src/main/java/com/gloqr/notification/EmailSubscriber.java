
package com.gloqr.notification;

import java.nio.charset.StandardCharsets;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import com.gloqr.dao.NotificationEventDao;
import com.gloqr.entities.EmailEvent;
import com.gloqr.entities.Event;
import com.gloqr.exceptions.CustomException;
import com.gloqr.rest.endpoint.ContentServerEndpoint;

public class EmailSubscriber extends Subscriber {
	private static final Logger log = LogManager.getLogger();

	@Autowired
	private JavaMailSender emailSender;

	@Autowired
	private NotificationEventDao notificationEventDao;

	@Autowired
	private ContentServerEndpoint contentServerEndpoint;

	private String mailSender;

	public EmailSubscriber(String mailSender) {
		this.mailSender = mailSender;
	}

	@Override
	public void inform(Event event) throws MessagingException {

		EmailEvent emailEvent = (EmailEvent) event;

		log.info("EMAIL: Sending to {}", emailEvent.getEmailId());

		try {
			MimeMessage message = emailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			String attachmentFileLocation = emailEvent.getAttachmentFileLocation();
			if (attachmentFileLocation != null) {
				loadAttachmentFromContentServer(helper, attachmentFileLocation);
			}

			helper.setText(emailEvent.getEventMessage(), true);
			helper.setSubject(emailEvent.getSubject());
			helper.setTo(emailEvent.getEmailId());
			helper.setFrom(mailSender);
			emailSender.send(message);

			log.info("EMAIL: Sent Successfully to {}", emailEvent.getEmailId());
			emailEvent.setSentStatus(true);
			emailEvent.setFailedStatus(false);
			notificationEventDao.saveEmailToDB(emailEvent);

		} catch (Exception e) {

			log.info("MAIL SENDING ON {} FAILED.", emailEvent.getEmailId());
			emailEvent.setFailedStatus(true);
			notificationEventDao.saveEmailToDB(emailEvent);

			throw new CustomException(
					"Sending mail on " + emailEvent.getEmailId() + " failed. message:-  " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

	}

	private void loadAttachmentFromContentServer(MimeMessageHelper helper, String attachmentFileLocation)
			throws MessagingException {

		try {
			log.info("Downloading attachment file from content server. file location: {}", attachmentFileLocation);
			String[] strs = attachmentFileLocation.split("/");
			String fileName = strs[strs.length - 1];
			byte[] bytes = contentServerEndpoint.downloadFileInBytes(attachmentFileLocation);
			helper.addAttachment(fileName, new ByteArrayResource(bytes));
			log.info("File Downloaded and Added to Email Attachment");

		} catch (Exception e) {
			log.error("Failed to add a file atachment: file location: {} and exception: {}", attachmentFileLocation,
					e.getMessage());
		}
	}

	public EventType getSubscriberEventType() {
		return EventType.EMAILEVENT;
	}

	public String getMailSender() {
		return mailSender;
	}

	public void setMailSender(String mailSender) {
		this.mailSender = mailSender;
	}

}
