
package com.gloqr.notification;

import static com.gloqr.notification.EventService.EVENTSERVICE;

import javax.mail.MessagingException;

import org.springframework.stereotype.Service;

import com.gloqr.entities.Event;


@Service
public class EmailPublisher extends Publisher
{
	@Override
	public void publish(Event event) throws MessagingException
	{
		EVENTSERVICE.publish(event, EventType.EMAILEVENT);
	}
}
