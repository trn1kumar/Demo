package com.gloqr.dao;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.entities.EmailEvent;
import com.gloqr.entities.SmsEvent;
import com.gloqr.exceptions.CustomException;
import com.gloqr.jpa.repositories.EmailNotificationRepository;
import com.gloqr.jpa.repositories.SmsNotificationRepository;

@Repository
public class NotificationEventDaoImpl implements NotificationEventDao {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private SmsNotificationRepository smsNotificationRepo;

	@Autowired
	private EmailNotificationRepository emailNotificationRepo;

	@Override
	public void saveSmsToDB(SmsEvent smsEvent) {
		try {
			log.info("Saving SMS Event Info into Database");
			smsNotificationRepo.save(smsEvent);
		} catch (Exception e) {
			throw new CustomException("Exception in saveSmsToDB(). message:- " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public void saveEmailToDB(EmailEvent emailEvent) {
		try {
			log.info("Saving EMAIL Event Info into Database");
			emailNotificationRepo.save(emailEvent);
		} catch (Exception e) {
			throw new CustomException("Exception in saveEmailToDB(). message:- " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@Override
	public List<SmsEvent> getFailedSmsEvents() {
		return smsNotificationRepo.findFailedSmsEvents();
	}

	@Override
	public List<EmailEvent> getFailedEmailEvents() {
		return emailNotificationRepo.findFailedEmailEvents();
	}

}
