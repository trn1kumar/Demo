package com.gloqr.dao;

import java.util.List;

import com.gloqr.constants.JobGroup;
import com.gloqr.entities.SchedulerConfig;
import com.gloqr.entities.SchedulerJobDetail;

public interface SchedulingDao {

	public void saveSchedulerJobInfo(SchedulerJobDetail schedulerJobInfo);

	public List<SchedulerConfig> getSchedulerConfigsBySchedulerGroup(JobGroup schedulerGroup);

	public List<SchedulerJobDetail> getDailyExecutedJobs();

	public List<SchedulerJobDetail> getWeeklyExecutedJobs();

	public List<SchedulerJobDetail> getMonthlyExecutedJobs();

	public List<SchedulerJobDetail> getYearlyExecutedJobs();

	public void unscheduleJobByJobName(String jobName);

	public List<SchedulerJobDetail> getImmediateExecutedJobs();

}
