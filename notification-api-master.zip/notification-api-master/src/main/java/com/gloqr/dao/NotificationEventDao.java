package com.gloqr.dao;

import java.util.List;

import com.gloqr.entities.EmailEvent;
import com.gloqr.entities.SmsEvent;

public interface NotificationEventDao {

	void saveSmsToDB(SmsEvent smsEvent);

	void saveEmailToDB(EmailEvent emailEvent);

	public List<SmsEvent> getFailedSmsEvents();

	public List<EmailEvent> getFailedEmailEvents();

}
