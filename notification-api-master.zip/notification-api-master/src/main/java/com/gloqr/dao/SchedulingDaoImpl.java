package com.gloqr.dao;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.gloqr.constants.JobGroup;
import com.gloqr.entities.SchedulerConfig;
import com.gloqr.entities.SchedulerJobDetail;
import com.gloqr.exceptions.CustomException;
import com.gloqr.jpa.repositories.SchedulerConfigRepo;
import com.gloqr.jpa.repositories.SchedulerJobDetailRepo;

@Repository
public class SchedulingDaoImpl implements SchedulingDao {
	public static final Logger log = LogManager.getLogger();

	@Autowired
	private SchedulerJobDetailRepo schedulerJobDetailRepo;

	@Autowired
	private SchedulerConfigRepo schedulerConfigRepo;

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = false, rollbackFor = Exception.class)
	public void saveSchedulerJobInfo(SchedulerJobDetail schedulerJobInfo) {
		schedulerJobDetailRepo.save(schedulerJobInfo);
	}
	

	@Override
	public List<SchedulerConfig> getSchedulerConfigsBySchedulerGroup(JobGroup schedulerGroup) {
		List<SchedulerConfig> configs = schedulerConfigRepo.findByJobGroup(schedulerGroup);
		if (configs.isEmpty()) {
			throw new CustomException("No Scheduler Configuration available for Job-Group: " + schedulerGroup,
					HttpStatus.NOT_FOUND);
		}
		return configs;
	}
	
	@Override
	public List<SchedulerJobDetail> getImmediateExecutedJobs() {
		return schedulerJobDetailRepo.findImmediateExecutedJobs();
	}

	@Override
	public List<SchedulerJobDetail> getDailyExecutedJobs() {
		return schedulerJobDetailRepo.findDailyExecutedJobs();
	}

	@Override
	public List<SchedulerJobDetail> getWeeklyExecutedJobs() {
		return schedulerJobDetailRepo.findWeeklyExecutedJobs();
	}

	@Override
	public List<SchedulerJobDetail> getMonthlyExecutedJobs() {
		return schedulerJobDetailRepo.findMonthlyExecutedJobs();
	}

	@Override
	public List<SchedulerJobDetail> getYearlyExecutedJobs() {
		return schedulerJobDetailRepo.findYearlyExecutedJobs();
	}

	@Override
	public void unscheduleJobByJobName(String jobName) {
		log.info("Un-Sheculing JOB_NAME:- {}", jobName);
		try {
			schedulerJobDetailRepo.updateUnScheduleByTrue(jobName);
		} catch (Exception e) {
			throw new CustomException("Couldn't UnSchedule job : " + jobName, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	


}
