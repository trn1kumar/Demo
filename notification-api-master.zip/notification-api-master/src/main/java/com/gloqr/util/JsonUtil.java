package com.gloqr.util;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.gloqr.exceptions.CustomException;
import com.google.gson.Gson;

@Component
public class JsonUtil {

	public <T> T parseJsonData(String jsonStringData, Class<T> parseClass) {
		try {
			return new Gson().fromJson(jsonStringData, parseClass);
		} catch (Exception e) {
			throw new CustomException("failed to parse JSON data", HttpStatus.NOT_ACCEPTABLE);
		}
	}

}
