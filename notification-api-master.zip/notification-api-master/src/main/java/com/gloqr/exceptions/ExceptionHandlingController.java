package com.gloqr.exceptions;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.util.ValidationUtil;


@ControllerAdvice
@SuppressWarnings("rawtypes")
public class ExceptionHandlingController {

	@Autowired
	ResponseMaker responseMaker;

	@ExceptionHandler(CustomException.class)
	public ResponseEntity<CustomHttpResponse> throwCustomException(CustomException ex) {
		return responseMaker.errorResponse(ex.getMessage(), ex.getCustomErrorCode(), ex.getHttpStatus());
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<CustomHttpResponse> throwException(Exception ex) {
		return responseMaker.errorResponse(ex.getMessage(), 0, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(CustomValidation.class)
	public ResponseEntity<ExceptionResponse> invalidInput(CustomValidation ex) {
		ValidationErrors validationError = ex.getValidationError();
		validationError.setErrorCode(HttpStatus.BAD_REQUEST.value());
		validationError.setErrorMessage("Invalid inputs.");
		return new ResponseEntity<>(validationError, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ExceptionResponse> invalidInput(MethodArgumentNotValidException ex) {
		BindingResult result = ex.getBindingResult();
		ValidationErrors response = new ValidationErrors();
		response.setErrorCode(HttpStatus.BAD_REQUEST.value());
		response.setErrorMessage("Invalid inputs.");
		response.setErrors(ValidationUtil.fromBindingErrors(result));

		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(NullPointerException.class)
	public ResponseEntity<CustomHttpResponse> nullPointerException(NullPointerException ex) {
		return responseMaker.errorResponse(ex.getMessage(), 0, HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
