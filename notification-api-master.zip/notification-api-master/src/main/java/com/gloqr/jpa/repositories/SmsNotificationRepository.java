package com.gloqr.jpa.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.gloqr.entities.SmsEvent;

@Repository
public interface SmsNotificationRepository extends JpaRepository<SmsEvent, Long> {

	@Query("SELECT s FROM notification_sms_event s WHERE s.failedStatus =true AND s.sentStatus=false AND s.totalResendCount < 3")
	List<SmsEvent> findFailedSmsEvents();

}
