package com.gloqr.jpa.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.gloqr.entities.EmailEvent;

@Repository
public interface EmailNotificationRepository extends JpaRepository<EmailEvent, Long> {

	@Query("SELECT e FROM notification_email_event e WHERE e.failedStatus =true AND e.sentStatus=false AND e.totalResendCount < 3")
	List<EmailEvent> findFailedEmailEvents();
}
