package com.gloqr.jpa.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.gloqr.entities.SchedulerJobDetail;

public interface SchedulerJobDetailRepo extends JpaRepository<SchedulerJobDetail, Long> {
	
	@Query("SELECT s FROM SchedulerJobDetail s JOIN  s.schedulerConfigs sc where s.unSchedule=false AND s.immediateExecutionComplete=false AND sc.schedulerType='IMMEDIATE'")
	List<SchedulerJobDetail> findImmediateExecutedJobs();

	@Query("SELECT s FROM SchedulerJobDetail s JOIN  s.schedulerConfigs sc where s.nextExecutionTime<= CURRENT_TIMESTAMP AND s.unSchedule=false AND s.immediateExecutionComplete=true AND s.dailyExecutionComplete=false AND sc.schedulerType='DAILY'")
	List<SchedulerJobDetail> findDailyExecutedJobs();

	@Query("SELECT s FROM SchedulerJobDetail s JOIN  s.schedulerConfigs sc where s.nextExecutionTime<= CURRENT_TIMESTAMP AND s.unSchedule=false AND s.dailyExecutionComplete=true AND s.weeklyExecutionComplete=false AND sc.schedulerType='WEEKLY'")
	List<SchedulerJobDetail> findWeeklyExecutedJobs();

	@Query("SELECT s FROM SchedulerJobDetail s JOIN  s.schedulerConfigs sc where s.nextExecutionTime<= CURRENT_TIMESTAMP AND s.unSchedule=false AND s.weeklyExecutionComplete=true AND s.monthlyExecutionComplete=false AND sc.schedulerType='MONTHLY'")
	List<SchedulerJobDetail> findMonthlyExecutedJobs();

	@Query("SELECT s FROM SchedulerJobDetail s JOIN  s.schedulerConfigs sc where s.nextExecutionTime<= CURRENT_TIMESTAMP AND s.unSchedule=false AND s.monthlyExecutionComplete=true AND s.yearlyExecutionComplete=false AND sc.schedulerType='YEARLY'")
	List<SchedulerJobDetail> findYearlyExecutedJobs();

	@Transactional
	@Modifying
	@Query("UPDATE SchedulerJobDetail s set s.unSchedule=true WHERE s.jobName = :jobName")
	void updateUnScheduleByTrue(@Param("jobName") String jobName);


}
