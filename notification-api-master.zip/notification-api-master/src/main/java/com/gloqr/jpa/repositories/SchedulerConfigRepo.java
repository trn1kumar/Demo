package com.gloqr.jpa.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.constants.JobGroup;
import com.gloqr.entities.SchedulerConfig;

public interface SchedulerConfigRepo extends JpaRepository<SchedulerConfig, Long> {

	List<SchedulerConfig> findByJobGroup(JobGroup jobGroup);

}
