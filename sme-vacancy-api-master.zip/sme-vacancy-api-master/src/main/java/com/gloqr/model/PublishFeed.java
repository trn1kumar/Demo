package com.gloqr.model;

public class PublishFeed {

	private String smeUuid;
	private String publishFeedId;
	private String title;
	private String description;
	private boolean active;
	private static final String POSTTYPE = "VACANCY";
	private static final String PRIVACY = "PUBLIC";

	public PublishFeed() {
		super();
	}

	public PublishFeed(String smeUuid, String infraUuid, String machineName, String description) {
		this.setSmeUuid(smeUuid);
		this.publishFeedId = infraUuid;
		this.title = machineName;
		this.description = description;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getPublishFeedId() {
		return publishFeedId;
	}

	public void setPublishFeedId(String publishFeedId) {
		this.publishFeedId = publishFeedId;
	}

	public boolean isActive() {
		return active;
	}

	public String getSmeUuid() {
		return smeUuid;
	}

	public void setSmeUuid(String smeUuid) {
		this.smeUuid = smeUuid;
	}

	public String getPostType() {
		return POSTTYPE;
	}

	public String getPrivacy() {
		return PRIVACY;
	}

	@Override
	public String toString() {
		return "PublishFeed [smeUuid=" + smeUuid + ", publishFeedId=" + publishFeedId + ", title=" + title + "]";
	}
	
	
	

}
