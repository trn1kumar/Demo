package com.gloqr.model.filter;

import java.util.Date;

public class FilterByRelevance {

	private Date minCreationDate;
	private Date maxCreationDate;
	private boolean selected;
	private long totalVacancies;
	
	public Date getMinCreationDate() {
		return minCreationDate;
	}
	public Date getMaxCreationDate() {
		return maxCreationDate;
	}
	public boolean isSelected() {
		return selected;
	}
	
	public void setMinCreationDate(Date minCreationDate) {
		this.minCreationDate = minCreationDate;
	}
	public void setMaxCreationDate(Date maxCreationDate) {
		this.maxCreationDate = maxCreationDate;
	}
	public void setSelected(boolean selected) {
		this.selected = selected;
	}
	public long getTotalVacancies() {
		return totalVacancies;
	}
	public void setTotalVacancies(long totalVacancies) {
		this.totalVacancies = totalVacancies;
	}

	
	
}
