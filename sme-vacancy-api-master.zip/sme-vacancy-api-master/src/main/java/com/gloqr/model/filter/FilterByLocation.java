package com.gloqr.model.filter;

public class FilterByLocation implements Comparable<FilterByLocation> {

	private String location;
	private boolean selected;
	private long totalVacancies;

	public String getLocation() {
		return location;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public long getTotalVacancies() {
		return totalVacancies;
	}

	public void setTotalVacancies(long totalVacancies) {
		this.totalVacancies = totalVacancies;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((location == null) ? 0 : location.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FilterByLocation other = (FilterByLocation) obj;
		if (location == null) {
			if (other.location != null)
				return false;
		} else if (!location.equals(other.location)) {
			return false;
		}
		return true;
	}

	@Override
	public int compareTo(FilterByLocation o) {
		/*
		 * object 'o' is comparing with object 'this' for getting max
		 * totalVacanciesCount results first in filter section (i.e descending order).
		 */
		return (int) (o.totalVacancies - this.totalVacancies);
	}
}
