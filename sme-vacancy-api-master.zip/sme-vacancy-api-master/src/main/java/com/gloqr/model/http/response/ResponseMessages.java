package com.gloqr.model.http.response;

public class ResponseMessages {
	private ResponseMessages() {

	}

	public static final String SUCCESS = "Success";
	public static final String VACANCY_POSTED = "Job Posted Successfully";
	public static final String VACANCY_UPDATED = "Job Updated Successfully";
	public static final String VACANCY_APLLIED = "Application Submited Successfully";
	public static final String VACANCY_DELETED = "Job Deleted Successfully";
	public static final String JOBSEEKER_SHORTLISTED = "Shortlisted Successfully";
}
