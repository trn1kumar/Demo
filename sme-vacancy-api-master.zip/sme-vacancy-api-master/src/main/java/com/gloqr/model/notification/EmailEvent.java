package com.gloqr.model.notification;


public class EmailEvent {

	private String emailId;
	private String subject;
	private String eventMessage;
	private String attachmentFileLocation;
	
	public EmailEvent(String emailId, String subject, String eventMessage, String attachmentFileLocation) {
		super();
		this.emailId = emailId;
		this.subject = subject;
		this.eventMessage = eventMessage;
		this.attachmentFileLocation = attachmentFileLocation;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getEventMessage() {
		return eventMessage;
	}

	public void setEventMessage(String eventMessage) {
		this.eventMessage = eventMessage;
	}

	public String getAttachmentFileLocation() {
		return attachmentFileLocation;
	}

	public void setAttachmentFileLocation(String attachmentFileLocation) {
		this.attachmentFileLocation = attachmentFileLocation;
	}



}
