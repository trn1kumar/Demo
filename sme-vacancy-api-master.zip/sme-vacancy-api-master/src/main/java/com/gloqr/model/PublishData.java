package com.gloqr.model;

import javax.validation.constraints.NotBlank;

import com.gloqr.constants.VacancyState;
import com.gloqr.constants.VacancyStatus;

public class PublishData {

	@NotBlank
	private String id;

	// for sme
	private VacancyStatus smeAction;

	// for gloqr admin
	private VacancyState state;
	private String feedbackMessage;
	private String jobRoleUuid;
	
	public String getJobRoleUuid() {
		return jobRoleUuid;
	}

	public void setJobRoleUuid(String jobRoleUuid) {
		this.jobRoleUuid = jobRoleUuid;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public VacancyState getState() {
		return state;
	}

	public void setState(VacancyState state) {
		this.state = state;
	}

	public String getFeedbackMessage() {
		return feedbackMessage;
	}

	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}

	public VacancyStatus getSmeAction() {
		return smeAction;
	}

	public void setSmeAction(VacancyStatus smeAction) {
		this.smeAction = smeAction;
	}

	@Override
	public String toString() {
		return "PublishData [id=" + id + "]";
	}

}
