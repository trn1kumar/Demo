package com.gloqr.model;

import java.util.List;

public class VacancyStateChange {

	private String smeId;
	private String userId;
	private List<PublishData> vacanciesInfo;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getSmeId() {
		return smeId;
	}

	public void setSmeId(String smeId) {
		this.smeId = smeId;
	}

	public List<PublishData> getVacanciesInfo() {
		return vacanciesInfo;
	}

	public void setVacanciesInfo(List<PublishData> vacanciesInfo) {
		this.vacanciesInfo = vacanciesInfo;
	}

}
