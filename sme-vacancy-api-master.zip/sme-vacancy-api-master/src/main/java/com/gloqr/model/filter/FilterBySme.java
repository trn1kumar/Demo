package com.gloqr.model.filter;

public class FilterBySme implements Comparable<FilterBySme> {
	private String sUuid;
	private String smeName;
	private boolean selected;
	private long totalVacancies;

	public String getsUuid() {
		return sUuid;
	}

	public String getSmeName() {
		return smeName;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public long getTotalVacancies() {
		return totalVacancies;
	}

	public void setTotalVacancies(long totalVacancies) {
		this.totalVacancies = totalVacancies;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((sUuid == null) ? 0 : sUuid.hashCode());
		result = prime * result + ((smeName == null) ? 0 : smeName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FilterBySme other = (FilterBySme) obj;
		if (sUuid == null) {
			if (other.sUuid != null)
				return false;
		} else if (!sUuid.equals(other.sUuid)) {
			return false;
		}
		if (smeName == null) {
			if (other.smeName != null)
				return false;
		} else if (!smeName.equals(other.smeName)) {
			return false;
		}
		return true;
	}

	@Override
	public int compareTo(FilterBySme o) {
		/*
		 * object 'o' is comparing with object 'this' for getting max
		 * totalVacanciesCount results first in filter section (i.e descending order).
		 */
		return (int) (o.totalVacancies - this.totalVacancies);
	}

}
