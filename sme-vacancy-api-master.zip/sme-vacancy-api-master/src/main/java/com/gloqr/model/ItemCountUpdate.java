package com.gloqr.model;

public class ItemCountUpdate {

	private static final String ITEM_TYPE = "VACANCY";
	private Long totalCount;
	private Long activeApprovedCount;
	private Long activePendingCount;

	public ItemCountUpdate(Long totalCount, Long activeApprovedCount, Long activePendingCount) {
		super();
		this.totalCount = totalCount;
		this.activeApprovedCount = activeApprovedCount;
		this.setActivePendingCount(activePendingCount);

	}

	public String getItemType() {
		return ITEM_TYPE;
	}

	public Long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}

	public Long getActiveApprovedCount() {
		return activeApprovedCount;
	}

	public void setActiveApprovedCount(Long activeApprovedCount) {
		this.activeApprovedCount = activeApprovedCount;
	}

	public Long getActivePendingCount() {
		return activePendingCount;
	}

	public void setActivePendingCount(Long activePendingCount) {
		this.activePendingCount = activePendingCount;
	}

	@Override
	public String toString() {
		return "ItemCountUpdate [totalCount=" + totalCount + ", activeApprovedCount=" + activeApprovedCount
				+ ", activePendingCount=" + activePendingCount + "]";
	}

}
