package com.gloqr.model.filter;

public class FilterByRole implements Comparable<FilterByRole> {
	private String jobRole;
	private boolean selected;
	private long totalVacancies;

	public String getJobRole() {
		return jobRole;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setJobRole(String jobRole) {
		this.jobRole = jobRole;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public long getTotalVacancies() {
		return totalVacancies;
	}

	public void setTotalVacancies(long totalVacancies) {
		this.totalVacancies = totalVacancies;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((jobRole == null) ? 0 : jobRole.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FilterByRole other = (FilterByRole) obj;
		if (jobRole == null) {
			if (other.jobRole != null)
				return false;
		} else if (!jobRole.equals(other.jobRole)) {
			return false;
		}
		return true;
	}

	@Override
	public int compareTo(FilterByRole o) {
		/*
		 * object 'o' is comparing with object 'this' for getting max
		 * totalVacanciesCount results first in filter section (i.e descending order).
		 */
		return (int) (o.totalVacancies - this.totalVacancies);
	}
}
