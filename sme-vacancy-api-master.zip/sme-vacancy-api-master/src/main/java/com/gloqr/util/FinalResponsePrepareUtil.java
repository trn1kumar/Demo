package com.gloqr.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.gloqr.dto.SMEDto;
import com.gloqr.dto.VacancyDto;
import com.gloqr.dto.master.CourseDto;
import com.gloqr.dto.master.SpecializationDto;
import com.gloqr.entities.Vacancy;
import com.gloqr.entities.master.Course;
import com.gloqr.entities.master.Specialization;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.VacancyMapper;
import com.gloqr.service.SmeService;
import com.gloqr.vo.VacancyBasicInfo;
import com.gloqr.vo.VacancyVo;

@Component
public class FinalResponsePrepareUtil {

	@Autowired
	private SmeService smeService;

	@Autowired
	private VacancyMapper vacancyMapper;

	public VacancyDto prepareForDto(Vacancy vacancy) {
		// Set Spec null for Avoid copy into VacancyDto
		vacancy.getQualificationCourses().forEach(c -> c.setSpecializations(null));

		VacancyDto vacancyDto = vacancyMapper.convertToDto(vacancy, VacancyDto.class);
		List<CourseDto> courses = new ArrayList<>(vacancyDto.getQualificationCourses());

		List<Specialization> specs = vacancy.getQualificationSpecializations();
		if (specs != null && !specs.isEmpty()) {
			for (Specialization s : specs) {
				SpecializationDto sDto = vacancyMapper.convertToDto(s, SpecializationDto.class);
				Optional<CourseDto> cOpt = courses.stream()
						.filter(c -> c.getCourseId().equals(s.getCourse().getCourseId())).findFirst();
				if (cOpt.isPresent()) {
					cOpt.get().getSpecializations().add(sDto);
				} else {
					CourseDto c = vacancyMapper.convertToDto(s.getCourse(), CourseDto.class);
					List<SpecializationDto> sList = new ArrayList<>();
					sList.add(sDto);
					c.setSpecializations(sList);
					courses.add(c);
				}
			}
		}
		vacancyDto.setQualificationSpecializations(null);
		vacancyDto.setSmeInfo(smeService.getSME(vacancy.getSmeUuid()));
		vacancyDto.setTotalApplicants(vacancy.getApplicants().size());
		vacancyDto.setQualificationCourses(courses);
		return vacancyDto;
	}

	public List<VacancyDto> prepareForDtos(List<Vacancy> vacancies, String sUuid) {
		List<VacancyDto> vacanciesDto = new ArrayList<>();
		SMEDto sme = smeService.getSME(sUuid);
		vacancies.forEach(vacancy -> {

			VacancyDto dto = vacancyMapper.convertToDto(vacancy, VacancyDto.class);

			dto.setSmeInfo(sme);
			dto.setTotalApplicants(vacancy.getApplicants().size());
			vacanciesDto.add(dto);
		});

		return vacanciesDto;
	}

	public List<VacancyVo> prepareForVos(List<Vacancy> vacancies, String sUuid, Map<String, SMEDto> smes) {

		if (sUuid == null && smes == null) {
			throw new CustomException("Either 'sUuid' or 'smes' must be specified.", HttpStatus.BAD_REQUEST);
		}

		if (sUuid != null && smes != null) {
			throw new CustomException("'sUuid' and 'smes' cannot both be specified. Choose either one.",
					HttpStatus.BAD_REQUEST);
		}

		SMEDto sme = null;
		List<VacancyVo> vacanciesVo = new ArrayList<>();
		if (sUuid != null) {
			sme = smeService.getSME(sUuid);
		}

		for (Vacancy vacancy : vacancies) {
			VacancyVo vo = this.prepareForVo(vacancy);
			if (sme != null) {
				vo.setSmeInfo(sme);
			} else {
				vo.setSmeInfo(smes.get(vacancy.getSmeUuid()));
			}
			vacanciesVo.add(vo);
		}

		return vacanciesVo;
	}

	public VacancyVo prepareForVo(Vacancy vacancy, String sUuid) {
		SMEDto sme = null;
		if (sUuid == null) {
			throw new CustomException("smeId can not be null for preparing vo", HttpStatus.BAD_REQUEST);
		}
		sme = smeService.getSME(sUuid);
		VacancyVo vacancyVo = this.prepareForVo(vacancy);
		vacancyVo.setSmeInfo(sme);

		return vacancyVo;
	}

	private VacancyVo prepareForVo(Vacancy vacancy) {

		Map<String, List<String>> formattedSpecializations = new HashMap<>();
		VacancyVo vacancyVo = vacancyMapper.convertToDto(vacancy, VacancyVo.class);
		vacancyVo.setTotalApplicants(vacancy.getApplicants().size());
		if (vacancy.getJobRole() != null) {
			vacancyVo.setJobRole(vacancy.getJobRole().getJobRole());
		}
		List<Specialization> specs = vacancy.getQualificationSpecializations();
		List<Course> courses = vacancy.getQualificationCourses();
		if (specs != null && !specs.isEmpty()) {
			specs.forEach(spec -> {
				if (formattedSpecializations.containsKey(spec.getCourse().getCourseName())) {
					formattedSpecializations.get(spec.getCourse().getCourseName()).add(spec.getSpecializationName());
				} else {
					List<String> specValues = new ArrayList<>();
					specValues.add(spec.getSpecializationName());
					formattedSpecializations.put(spec.getCourse().getCourseName(), specValues);
				}
			});

		}
		if (courses != null && !courses.isEmpty()) {
			courses.forEach(course -> {
				if (!formattedSpecializations.containsKey(course.getCourseName())) {
					formattedSpecializations.put(course.getCourseName(), new ArrayList<>());
				}
			});
		}

		// use for show specializations in single string

		List<String> finalStrs = new ArrayList<>();
		formattedSpecializations.forEach((k, v) -> {
			String tempStr = "";
			String str1 = v.stream().map(str -> str).collect(Collectors.joining(","));
			if (!StringUtils.isEmpty(str1))
				tempStr = k + "(" + str1 + ")";
			else
				tempStr = k;
			finalStrs.add(tempStr);

		});
		vacancyVo.setRawFormatQualification(finalStrs.stream().map(str -> str).collect(Collectors.joining(", ")));
		vacancyVo.setLocations(String.join(", ", vacancy.getLocations()));
		vacancyVo.setEmploymentTypes(String.join(", ", vacancy.getEmploymentTypes()));
		vacancyVo.setJobTypes(String.join(", ", vacancy.getJobTypes()));
		vacancyVo.setRequiredDocuments(String.join(", ", vacancy.getRequiredDocuments()));
		return vacancyVo;

	}

	public List<VacancyBasicInfo> prepareForVacancyBasicDetail(List<Vacancy> vacancies) {
		List<VacancyBasicInfo> vacancies1 = new ArrayList<>();
		for (Vacancy vacancy : vacancies) {
			VacancyBasicInfo vacancyBasicDetail = vacancyMapper.convertToDto(vacancy, VacancyBasicInfo.class);
			if (vacancy.getJobRole() != null) {
				vacancyBasicDetail.setJobRole(vacancy.getJobRole().getJobRole());
			}
			vacancies1.add(vacancyBasicDetail);
		}

		return vacancies1;
	}

}
