package com.gloqr.util;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.dto.VacancyDto;
import com.gloqr.dto.jobseekers.ExperienceDetailDto;
import com.gloqr.dto.jobseekers.JobSeekerProfileDto;
import com.gloqr.entities.CustomApplicant;
import com.gloqr.exception.CustomValidation;
import com.gloqr.exception.ValidationErrors;

public class ValidationUtil {

	public static List<String> fromBindingErrors(Errors errors) {
		List<String> validErrors = new ArrayList<>();
		for (ObjectError objectError : errors.getAllErrors()) {
			validErrors.add(objectError.getDefaultMessage());
		}
		return validErrors;
	}

	public static void checkValidation(Object obj) {

		if (obj instanceof JobSeekerProfileDto) {
			checkValidationForJobSeekerProfile((JobSeekerProfileDto) obj);

		}

		else if (obj instanceof ExperienceDetailDto) {
			checkValidationForJobSeekerExperience((ExperienceDetailDto) obj);
		}

		else if (obj instanceof VacancyDto) {
			checkValidationForVacancyDto((VacancyDto) obj);

		} else if (obj instanceof CustomApplicant) {
			checkValidationForVacancyDto((VacancyDto) obj);
		}

	}

	private static void checkValidationForVacancyDto(VacancyDto vacancyDto) {
		ValidationErrors validationError = new ValidationErrors();

		List<String> errors = new ArrayList<>();

		if (vacancyDto.getMinSalary() > vacancyDto.getMaxSalary()) {
			errors.add("Max Salary Should be greater than Min Salary");

		}

		if (!errors.isEmpty()) {
			validationError.setErrors(errors);
			throw new CustomValidation(validationError);
		}
	}

	private static void checkValidationForJobSeekerProfile(JobSeekerProfileDto jobSeekerProfileDto) {
		ValidationErrors validationError = new ValidationErrors();

		List<String> errors = new ArrayList<>();
		if (jobSeekerProfileDto.getDob() != null) {

			Calendar birthDate = Calendar.getInstance();

			birthDate.setTime(jobSeekerProfileDto.getDob());

			Calendar currentDate = Calendar.getInstance();
			currentDate.setTime(new Date());

			int age = currentDate.get(Calendar.YEAR) - birthDate.get(Calendar.YEAR);

			if (age < 18 || age > 70) {
				errors.add("Age Should be greater than 18 and less than 70");
			}
		}

		if (!errors.isEmpty()) {
			validationError.setErrors(errors);
			throw new CustomValidation(validationError);
		}

	}

	private static void checkValidationForJobSeekerExperience(ExperienceDetailDto experienceDetailDto) {
		ValidationErrors validationError = new ValidationErrors();

		List<String> errors = new ArrayList<>();

		Calendar startDate = Calendar.getInstance();
		startDate.setTime(experienceDetailDto.getStartDate());

		Date minStartDate = new Date(1970, 0, 0);

	}

	public static void checkValidation(MultipartFile multipartFile) {

		ValidationErrors validationError = new ValidationErrors();

		List<String> errors = new ArrayList<>();
		try {
			if (multipartFile != null) {
				String fileName = multipartFile.getOriginalFilename();
				if (multipartFile.isEmpty() || multipartFile.getSize() == 0) {
					errors.add("Error for File Name= " + fileName + " ,Please select a valid File");
				} else {
					if (multipartFile.getSize() / 2e-6 <= 1) {
						errors.add("Error for File Name= " + fileName + " ,File Size must be Max 1 MB");
					}
					if (!(multipartFile.getContentType().equalsIgnoreCase("application/pdf")
							|| multipartFile.getContentType().equalsIgnoreCase("application/rtf")

							|| multipartFile.getContentType().equalsIgnoreCase("text/plain")
							|| multipartFile.getContentType().equalsIgnoreCase(
									"application/vnd.openxmlformats-officedocument.wordprocessingml.document")
							|| multipartFile.getContentType().equalsIgnoreCase("application/msword"))) {
						errors.add("Error for File Name= " + fileName + " , Only (.pdf .doc .docx) format supprot");
					}
				}
			}
			if (!errors.isEmpty()) {
				validationError.setErrors(errors);
				throw new CustomValidation(validationError);
			}
		} catch (CustomValidation e) {
			throw e;
		}

	}

}
