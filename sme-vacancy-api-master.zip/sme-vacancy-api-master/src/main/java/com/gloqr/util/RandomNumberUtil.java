package com.gloqr.util;

import java.util.Random;

import org.springframework.http.HttpStatus;

import com.gloqr.exception.CustomException;

public class RandomNumberUtil {

	private RandomNumberUtil() {
		throw new CustomException("Utility class.", HttpStatus.INTERNAL_SERVER_ERROR);
	}

	public static Integer generate(int length) {
		return new Random().nextInt(length);
	}

}
