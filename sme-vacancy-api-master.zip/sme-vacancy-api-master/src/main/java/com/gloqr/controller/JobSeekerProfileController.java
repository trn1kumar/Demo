package com.gloqr.controller;

import java.io.IOException;
import java.util.List;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.constants.UrlMapping;
import com.gloqr.constants.VacancyConstants.FileDirectory;
import com.gloqr.constants.VacancyConstants.RoleAccess;
import com.gloqr.dto.jobseekers.BasicJobSeekerProfileDto;
import com.gloqr.dto.jobseekers.CareerProfileDto;
import com.gloqr.dto.jobseekers.EducationalDetailDto;
import com.gloqr.dto.jobseekers.ExperienceDetailDto;
import com.gloqr.dto.jobseekers.JobSeekerProfileDto;
import com.gloqr.entities.jobseekers.CareerProfile;
import com.gloqr.entities.jobseekers.EducationalDetail;
import com.gloqr.entities.jobseekers.ExperienceDetail;
import com.gloqr.entities.jobseekers.JobSeekerProfile;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.VacancyMapper;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.model.http.response.ResponseMessages;
import com.gloqr.rest.endpoint.UserEndPoint;
import com.gloqr.security.context.holder.UserDetails;
import com.gloqr.service.FileService;
import com.gloqr.service.JobSeekerService;
import com.gloqr.util.ValidationUtil;

@SuppressWarnings("rawtypes")
@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.JOB_SEEKER_ROOT_API)
public class JobSeekerProfileController {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private JobSeekerService jobSeekerService;

	@Autowired
	private VacancyMapper customMapper;

	@Autowired
	private FileService fileService;

	@Autowired
	private UserEndPoint userEndPoint;

	@PostMapping(UrlMapping.JOB_SEEKER_BASIC_PROFILE)
	@PreAuthorize(RoleAccess.USER)
	public ResponseEntity<CustomHttpResponse> createJobSeekerProfile(Authentication authentication,
			@Valid @RequestBody BasicJobSeekerProfileDto basicJobSeekerProfileDto) {
		JobSeekerProfile jobSeekerProfile = null;
		UserDetails userDetail = (UserDetails) authentication.getPrincipal();

		log.info("Request for create job profile by user id :: {}", userDetail.getUserId());

		try {
			basicJobSeekerProfileDto.setJobSeekerProfileId(userDetail.getUserId());
			jobSeekerProfile = customMapper.convertToEntity(basicJobSeekerProfileDto, JobSeekerProfile.class);
			jobSeekerService.createJobSeekerProfile(jobSeekerProfile);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse("Success", HttpStatus.CREATED);

	}

	@PostMapping(UrlMapping.JOB_SEEKER_PROFILE)
	@PreAuthorize(RoleAccess.USER)
	public ResponseEntity<CustomHttpResponse> createJobSeekerProfile(Authentication authentication,
			@Valid @RequestBody JobSeekerProfileDto jobSeekerProfileDto) {
		JobSeekerProfile jobSeekerProfile = null;
		UserDetails userDetail = (UserDetails) authentication.getPrincipal();

		log.info("Request for create job profile by user id :: {}", userDetail.getUserId());

		try {
			ValidationUtil.checkValidation(jobSeekerProfileDto);
			jobSeekerProfileDto.setJobSeekerProfileId(userDetail.getUserId());
			jobSeekerProfile = customMapper.convertToEntity(jobSeekerProfileDto, JobSeekerProfile.class);
			jobSeekerService.createJobSeekerProfile(jobSeekerProfile);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse("Success", HttpStatus.CREATED);

	}

	@PutMapping(UrlMapping.JOB_SEEKER_PROFILE)
	@PreAuthorize(RoleAccess.USER)
	public ResponseEntity<CustomHttpResponse> updateJobSeekerProfile(Authentication authentication,
			@Valid @RequestBody JobSeekerProfileDto jobSeekerProfileDto) {
		JobSeekerProfile jobSeekerProfile = null;

		UserDetails userDetail = (UserDetails) authentication.getPrincipal();
		log.info("Request for update job profile by user id :: {}", userDetail.getUserId());
		try {
			ValidationUtil.checkValidation(jobSeekerProfileDto);
			jobSeekerProfileDto.setJobSeekerProfileId(userDetail.getUserId());
			jobSeekerProfile = customMapper.convertToEntity(jobSeekerProfileDto, JobSeekerProfile.class);
			jobSeekerService.updateJobSeekerProfile(jobSeekerProfile);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse("Success", HttpStatus.OK);

	}

	@PostMapping(UrlMapping.EDUCATIONAL_DETAIL)
	@PreAuthorize(RoleAccess.USER)
	public ResponseEntity<CustomHttpResponse> addEducationalDetail(Authentication authentication,
			@Valid @RequestBody EducationalDetailDto educationalDto) {
		EducationalDetail educationalDetail = null;

		UserDetails userDetail = (UserDetails) authentication.getPrincipal();
		log.info("Request for add EducationalDetail by user id :: {}", userDetail.getUserId());
		try {
			educationalDetail = customMapper.convertToEntity(educationalDto, EducationalDetail.class);
			jobSeekerService.addEducationalDetail(userDetail.getUserId(), educationalDetail);
		} catch (CustomException e) {
			throw e;
		}

		return responseMaker.successResponse("Success", HttpStatus.CREATED);

	}

	@PutMapping(UrlMapping.EDUCATIONAL_DETAIL)
	@PreAuthorize(RoleAccess.USER)
	public ResponseEntity<CustomHttpResponse> updateEducationalDetail(Authentication authentication,
			@Valid @RequestBody EducationalDetailDto educationalDto) {
		EducationalDetail educationalDetail = null;

		UserDetails userDetail = (UserDetails) authentication.getPrincipal();
		log.info("Request for update EducationalDetail by user id :: {}", userDetail.getUserId());
		try {
			educationalDetail = customMapper.convertToEntity(educationalDto, EducationalDetail.class);
			jobSeekerService.updateEducationalDetail(userDetail.getUserId(), educationalDetail);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse("Success", HttpStatus.OK);

	}

	@PostMapping(UrlMapping.EXPERIENCE_DETAIL)
	@PreAuthorize(RoleAccess.USER)
	public ResponseEntity<CustomHttpResponse> addExperienceDetail(Authentication authentication,
			@Valid @RequestBody ExperienceDetailDto experienceDto) {
		ExperienceDetail experienceDetail = null;

		UserDetails userDetail = (UserDetails) authentication.getPrincipal();
		log.info("Request for add ExperienceDetail by user id :: {}", userDetail.getUserId());
		try {
			experienceDetail = customMapper.convertToEntity(experienceDto, ExperienceDetail.class);
			jobSeekerService.addExperienceDetail(userDetail.getUserId(), experienceDetail);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse("Success", HttpStatus.CREATED);

	}

	@PutMapping(UrlMapping.EXPERIENCE_DETAIL)
	@PreAuthorize(RoleAccess.USER)
	public ResponseEntity<CustomHttpResponse> updateExperienceDetail(Authentication authentication,
			@Valid @RequestBody ExperienceDetailDto experienceDto) {
		ExperienceDetail experienceDetail = null;

		UserDetails userDetail = (UserDetails) authentication.getPrincipal();
		log.info("Request for update ExperienceDetail by user id :: {}", userDetail.getUserId());
		try {
			experienceDetail = customMapper.convertToEntity(experienceDto, ExperienceDetail.class);
			jobSeekerService.updateExperienceDetail(userDetail.getUserId(), experienceDetail);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse("Success", HttpStatus.OK);

	}

	@PostMapping(UrlMapping.CAREER_DETAIL)
	@PreAuthorize(RoleAccess.USER)
	public ResponseEntity<CustomHttpResponse> addCareerDetail(Authentication authentication,
			@Valid @RequestBody CareerProfileDto careerProfileDto) {
		CareerProfile careerProfile = null;

		UserDetails userDetail = (UserDetails) authentication.getPrincipal();
		log.info("Request for add CareerDetail by user id :: {}", userDetail.getUserId());
		try {
			careerProfile = customMapper.convertToEntity(careerProfileDto, CareerProfile.class);
			jobSeekerService.addCareerDetail(userDetail.getUserId(), careerProfile);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse("Success", HttpStatus.CREATED);

	}

	@PutMapping(UrlMapping.CAREER_DETAIL)
	@PreAuthorize(RoleAccess.USER)
	public ResponseEntity<CustomHttpResponse> updateCareerDetail(Authentication authentication,
			@Valid @RequestBody CareerProfileDto careerProfileDto) {
		CareerProfile careerProfile = null;

		UserDetails userDetail = (UserDetails) authentication.getPrincipal();
		log.info("Request for update CareerDetail by user id :: {}", userDetail.getUserId());
		try {
			careerProfile = customMapper.convertToEntity(careerProfileDto, CareerProfile.class);
			jobSeekerService.updateCareerDetail(userDetail.getUserId(), careerProfile);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse("Success", HttpStatus.OK);

	}

	@PostMapping(UrlMapping.SKILL_SETS)
	@PreAuthorize(RoleAccess.USER)
	public ResponseEntity<CustomHttpResponse> addSkillSets(Authentication authentication,
			@RequestBody List<String> skillSets) {

		UserDetails userDetail = (UserDetails) authentication.getPrincipal();
		log.info("Request for add SkillSets by user id :: {}", userDetail.getUserId());
		try {
			jobSeekerService.addSkillSets(userDetail.getUserId(), skillSets);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse("Success", HttpStatus.OK);

	}

	@GetMapping(UrlMapping.JOB_SEEKER_PROFILE)
	@PreAuthorize(RoleAccess.USER)
	public ResponseEntity<CustomHttpResponse<JobSeekerProfileDto>> getJobSeekerProfile(Authentication authentication) {

		JobSeekerProfileDto jobSeekerProfileDto = null;
		UserDetails userDetail = (UserDetails) authentication.getPrincipal();

		try {
			JobSeekerProfile jobSeekerProfile = jobSeekerService.getJobSeekerProfile(userDetail.getUserId());
			jobSeekerProfileDto = customMapper.convertToDto(jobSeekerProfile, JobSeekerProfileDto.class);
			List<ExperienceDetail> details = jobSeekerProfile.getExperienceDetails();

			if (details != null && !details.isEmpty()) {
				for (ExperienceDetail detail : details) {
					if (detail.isCurrentlyWorking()) {
						jobSeekerProfileDto.setCurrentOrganization(detail.getCompanyName());
						jobSeekerProfileDto.setCurrentDesig(detail.getJobRole().getJobRole());
					}
				}
			}

		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(jobSeekerProfileDto, "Success", HttpStatus.OK);

	}

	@PutMapping(UrlMapping.JOB_SEEKER_UPLOAD_RESUME)
	@PreAuthorize(RoleAccess.USER)
	public ResponseEntity<CustomHttpResponse> uploadJobSeekerResume(Authentication authentication,
			@RequestParam(value = "resume", required = false) MultipartFile resume) {

		UserDetails userDetail = (UserDetails) authentication.getPrincipal();
		String jobSeekerId = userDetail.getUserId();
		log.info("Request for upload JobSeeker Resume by user id :: {}", jobSeekerId);

		String newResumeUrl = null;
		String resumeFileName = null;

		try {
			ValidationUtil.checkValidation(resume);
			if (resume != null) {

				resumeFileName = resume.getOriginalFilename();
				newResumeUrl = fileService.sendFilesToContentServer(resume,
						FileDirectory.RESUME_DIR.replace("{userId}", jobSeekerId));
			}

		} catch (IllegalArgumentException | IOException e) {
			throw new CustomException("Resume file does not upload successfully", HttpStatus.INTERNAL_SERVER_ERROR);
		}

		String existResumeUrl = jobSeekerService.updateResume(newResumeUrl, resumeFileName, jobSeekerId);

		if (!StringUtils.isBlank(existResumeUrl)) {
			try {
				fileService.deleteFileFromContentServer(existResumeUrl);
			} catch (Exception e) {
				log.error(e.getMessage());
			}
		}
		return responseMaker.successResponse("Resume Uploaded Successfully", HttpStatus.OK);
	}

	@DeleteMapping(UrlMapping.JOB_SEEKER_DELETE_RESUME)
	@PreAuthorize(RoleAccess.USER)
	public ResponseEntity<CustomHttpResponse> removeJobSeekerResume(Authentication authentication) {
		UserDetails userDetail = (UserDetails) authentication.getPrincipal();

		String jobSeekerId = userDetail.getUserId();
		String newResumeUrl = null;
		String resumeFileName = null;

		try {

			String existResumeUrl = jobSeekerService.updateResume(newResumeUrl, resumeFileName, jobSeekerId);

			if (!StringUtils.isBlank(existResumeUrl)) {
				fileService.deleteFileFromContentServer(existResumeUrl);
			}
		} catch (Exception e) {
			log.error(e.getMessage());
		}

		return responseMaker.successResponse("Resume Deleted Successfully", HttpStatus.OK);

	}

	@GetMapping(UrlMapping.JOB_SEEKER_VIEW_MODE)
	@PreAuthorize(RoleAccess.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse<JobSeekerProfileDto>> getJobSeekerForViewMode(@PathVariable String jobSeekerProfileUuid) {
		log.info("Request for get single Job-Seeker for view mode by jobSeeker id {}", jobSeekerProfileUuid);

		JobSeekerProfileDto jobSeekerProfileDto = null;

		
		try {
			JobSeekerProfile jobSeekerProfile = jobSeekerService.getJobSeekerProfileByUuid(jobSeekerProfileUuid);
			//UserDto userDto = userEndPoint.getUser(jobSeekerProfile.getJobSeekerProfileId());
			jobSeekerProfileDto = customMapper.convertToDto(jobSeekerProfile, JobSeekerProfileDto.class);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(jobSeekerProfileDto, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

}
