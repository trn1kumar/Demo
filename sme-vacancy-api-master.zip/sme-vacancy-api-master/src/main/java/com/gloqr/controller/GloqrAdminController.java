package com.gloqr.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.UrlMapping;
import com.gloqr.constants.VacancyConstants.RoleAccess;
import com.gloqr.dto.SMEDto;
import com.gloqr.dto.VacancyDto;
import com.gloqr.entities.Vacancy;
import com.gloqr.model.VacancyStateChange;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.repository.SMEVacancyRepository;
import com.gloqr.security.context.holder.AuthenticationFacade;
import com.gloqr.service.SmeService;
import com.gloqr.util.FinalResponsePrepareUtil;
import com.gloqr.service.CountManageService;
import com.gloqr.service.GloqrAdminService;
import com.gloqr.service.NotificationService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.GLOQR_ADMIN_API)
@SuppressWarnings("rawtypes")
public class GloqrAdminController {

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private GloqrAdminService smeVacancyAdminService;

	@Autowired
	private SmeService smeService;

	@Autowired
	private FinalResponsePrepareUtil dtoUtil;

	@Autowired
	private AuthenticationFacade authenticationFacade;

	@Autowired
	private CountManageService countManageService;

	@Autowired
	private NotificationService notificationService;



	@PutMapping(UrlMapping.MODIFY_VACANCY)
	public ResponseEntity<CustomHttpResponse> modifyState(@RequestBody VacancyStateChange smeAndVacancyInfo) {
		try {
			List<Vacancy> modifedData = smeVacancyAdminService.approveOrRejectVacancies(smeAndVacancyInfo);
			notificationService.sendVacancyVerificationSummaryNotification(smeAndVacancyInfo.getSmeId(), modifedData);
			countManageService.updateVacanciesCount(smeAndVacancyInfo.getSmeId(), authenticationFacade.getJwtToken());
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse("Success", HttpStatus.OK);
	}

	@GetMapping(UrlMapping.SME_VACANCIES)
	public ResponseEntity<CustomHttpResponse<List<VacancyDto>>> getSMEVacancies(@PathVariable String smeId) {
		List<VacancyDto> vacanciesDto = new ArrayList<>();
		SMEDto sme = smeService.getSME(smeId);
		try {
			List<Vacancy> vacancies = smeVacancyAdminService.getPendingVacanciesBySmeId(smeId);
			vacancies.forEach(vacancy -> {
				VacancyDto dto = dtoUtil.prepareForDto(vacancy);
				dto.setSmeInfo(sme);
				vacanciesDto.add(dto);
			});
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(vacanciesDto, "Success", HttpStatus.OK);
	}
	
	// Update Manually Count If Some Count Manage Miss-Behavior Happen
	
	@Autowired
	private SMEVacancyRepository vacancyRepo;

	@GetMapping("update-counts")
	@PreAuthorize(RoleAccess.ALL_ROLES)
	public ResponseEntity<CustomHttpResponse> updateCounts() {
		Set<String> smeIds = vacancyRepo.getSmeUuid();
		for (String smeId : smeIds) {
			countManageService.updateVacanciesCount(smeId, authenticationFacade.getJwtToken());
		}
		return responseMaker.successResponse("Success", HttpStatus.OK);
	}

}
