package com.gloqr.controller;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.UrlMapping;
import com.gloqr.constants.VacancyState;
import com.gloqr.dto.SMEDto;
import com.gloqr.dto.filter.FilterResponseDto;
import com.gloqr.dto.filter.VacancyFilterDto;
import com.gloqr.entities.Vacancy;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.model.http.response.ResponseMessages;
import com.gloqr.security.context.holder.UserDetails;
import com.gloqr.service.SmeService;
import com.gloqr.service.VacancyService;
import com.gloqr.service.filter.FilterService;
import com.gloqr.util.FinalResponsePrepareUtil;
import com.gloqr.vo.VacancyVo;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.VACANCY_ROOT_API)
public class VacancyFilterController {

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private FilterService vacancyFilterService;

	@Autowired
	private VacancyService vacancyService;

	@Autowired
	private SmeService smeService;

	@Autowired
	private FinalResponsePrepareUtil dtoUtil;

	@GetMapping(UrlMapping.VACANCIES)
	public ResponseEntity<CustomHttpResponse<FilterResponseDto>> getAllVacancies(Authentication authentication,
			@RequestParam(required = false) Set<String> filterBySmes,
			@RequestParam(required = false) Set<String> filterByLocations,
			@RequestParam(required = false) Set<String> filterByJobRoles,
			@RequestParam(required = false) Set<String> filterBySalaries,
			@RequestParam(required = false) Set<String> filterByExperiences,
			@RequestParam(required = false) Integer page) {

		FilterResponseDto filtersAndResult = null;

		try {

			if (page == null || page < 0)
				page = 0;

			List<Vacancy> vacancies = vacancyFilterService.appyFilter(filterBySmes, filterByLocations, filterByJobRoles,
					filterBySalaries, filterByExperiences, page);

			Set<String> smeIds = vacancyService.getSmeUuidOfVacancyActiveTrueAndVacancyState(VacancyState.APPROVED);
			if (!vacancies.isEmpty() && authentication != null && (UserDetails) authentication.getPrincipal() != null) {
				UserDetails userDetail = (UserDetails) authentication.getPrincipal();
				final String loggedInUserId = userDetail.getUserId();
				if (userDetail.getSmeId() == null)
					vacancyService.setVacancyApplied(vacancies, loggedInUserId);
			}

			Map<String, SMEDto> smes = smeService.getSMEs(smeIds);
			List<VacancyVo> vacancyVos = dtoUtil.prepareForVos(vacancies, null, smes);

			Map<String, Object> filters = vacancyFilterService.getFilter(smes, filterBySmes, filterByLocations,
					filterByJobRoles, filterBySalaries, filterByExperiences);
			filtersAndResult = new FilterResponseDto(filters, vacancyVos, vacancyVos.size());

		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(filtersAndResult, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.MENU_BAR_FILTER)
	public ResponseEntity<CustomHttpResponse<VacancyFilterDto>> getFilter() {

		VacancyFilterDto vacancyFilter = null;
		try {
			Set<String> smeIds = vacancyService.getSmeUuidOfVacancyActiveTrueAndVacancyState(VacancyState.APPROVED);
			Map<String, SMEDto> smes = smeService.getSMEs(smeIds);
			Map<String, Object> filters = vacancyFilterService.getFilter(smes, null, null, null, null, null);
			vacancyFilter = new VacancyFilterDto(filters);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(vacancyFilter, "Success", HttpStatus.OK);
	}

}
