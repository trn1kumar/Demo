package com.gloqr.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.master.CourseCategoryDto;
import com.gloqr.dto.master.CourseDto;
import com.gloqr.dto.master.IndustrialAreaDto;
import com.gloqr.dto.master.IndustrialJobRoleDto;
import com.gloqr.dto.master.SpecializationDto;
import com.gloqr.entities.master.Course;
import com.gloqr.entities.master.CourseCategory;
import com.gloqr.entities.master.IndustrialArea;
import com.gloqr.entities.master.IndustrialJobRole;
import com.gloqr.entities.master.Specialization;
import com.gloqr.mapper.VacancyMapper;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.service.MasterDataService;
import com.gloqr.vo.master.CourseCategoryVo;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.VACANCY_ROOT_API)
@SuppressWarnings("rawtypes")
public class MasterDataController {

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private VacancyMapper vacancyMapper;

	@Autowired
	private MasterDataService masterDataService;

	@PostMapping(UrlMapping.INDUSTRIAL_AREA)
	public ResponseEntity<CustomHttpResponse> addIndustrialArea(
			@Valid @RequestBody IndustrialAreaDto industrialAreaDto) {
		IndustrialArea industrialArea = null;

		try {
			industrialArea = vacancyMapper.convertToEntity(industrialAreaDto, IndustrialArea.class);
			masterDataService.saveIndustrialArea(industrialArea);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse("Success", HttpStatus.CREATED);

	}

	@GetMapping(UrlMapping.INDUSTRIAL_AREA)
	public ResponseEntity<CustomHttpResponse<List<IndustrialAreaDto>>> getIndustrialAreas() {
		List<IndustrialArea> industrialAreas = null;
		List<IndustrialAreaDto> industrialAreaDtos = new ArrayList<>();
		try {
			industrialAreas = masterDataService.getAllIndustrialArea();
			industrialAreaDtos = vacancyMapper.convertToDtos(industrialAreas, IndustrialAreaDto.class);

		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(industrialAreaDtos, "Success", HttpStatus.OK);

	}

	@GetMapping(UrlMapping.JOB_ROLES)
	public ResponseEntity<CustomHttpResponse<List<IndustrialJobRoleDto>>> getJobRoles(
			@RequestParam String industrialAreaId) {
		List<IndustrialJobRole> vacancyJobRoles = null;
		List<IndustrialJobRoleDto> vacancyJobRoleDtos = new ArrayList<>();
		try {
			vacancyJobRoles = masterDataService.getJobRoles(industrialAreaId);

			vacancyJobRoles.forEach(role -> {
				role.setIndustrialArea(null);
				vacancyJobRoleDtos.add(vacancyMapper.convertToDto(role, IndustrialJobRoleDto.class));
			});
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(vacancyJobRoleDtos, "Success", HttpStatus.OK);

	}

	@GetMapping(UrlMapping.GET_CATEGORIES)
	public ResponseEntity<CustomHttpResponse<List<CourseCategoryDto>>> getCourseCategories() {
		List<CourseCategoryDto> courseCategoriesDto = null;
		try {
			List<CourseCategory> courseCategories = masterDataService.getCourseCategories();
			courseCategoriesDto = vacancyMapper.convertToDtos(courseCategories, CourseCategoryDto.class);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(courseCategoriesDto, "Success", HttpStatus.OK);

	}

	@GetMapping(UrlMapping.GET_COURSES)
	public ResponseEntity<CustomHttpResponse<List<CourseDto>>> getCourses(@RequestParam String courseCategoryId) {
		List<CourseDto> coursesDto = new ArrayList<>();
		try {
			List<Course> courses = masterDataService.getCourses(courseCategoryId);
			courses.forEach(course -> {
				course.setSpecializations(null);
				coursesDto.add(vacancyMapper.convertToDto(course, CourseDto.class));
			});

		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(coursesDto, "Success", HttpStatus.OK);

	}

	@GetMapping(UrlMapping.GET_SPECIALIZATIONS)
	public ResponseEntity<CustomHttpResponse<List<SpecializationDto>>> getSpecializations(
			@RequestParam String courseId) {
		List<SpecializationDto> specializationsDto = new ArrayList<>();
		try {
			List<Specialization> specializations = masterDataService.getSpecializations(courseId);
			specializationsDto = vacancyMapper.convertToDtos(specializations, SpecializationDto.class);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(specializationsDto, "Success", HttpStatus.OK);

	}

	@GetMapping(UrlMapping.GET_CATEGORIES_WITH_COURSES)
	public ResponseEntity<CustomHttpResponse<List<CourseCategoryVo>>> getCourseCategoriesWithCourses() {
		List<CourseCategoryVo> courseCategoriesVo = null;
		try {
			List<CourseCategory> courseCategories = masterDataService.getCourseCategories();
			courseCategories.forEach(cat -> cat.getCourses().forEach(course -> {
				if (course.getSpecializations() != null) {
					course.setTotalSpecializations(course.getSpecializations().size());
				}
			}));
			courseCategoriesVo = vacancyMapper.convertToVos(courseCategories, CourseCategoryVo.class);

		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(courseCategoriesVo, "Success", HttpStatus.OK);
	}

}
