package com.gloqr.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.gloqr.aop.PostVacancyCheckCredits;
import com.gloqr.constants.UrlMapping;
import com.gloqr.constants.VacancyConstants.FileDirectory;
import com.gloqr.constants.VacancyConstants.RoleAccess;
import com.gloqr.dto.SMEDto;
import com.gloqr.dto.VacancyApplicantDto;
import com.gloqr.dto.VacancyDto;
import com.gloqr.entities.CustomApplicant;
import com.gloqr.entities.Vacancy;
import com.gloqr.entities.VacancyApplicant;
import com.gloqr.entities.jobseekers.ExperienceDetail;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.VacancyMapper;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.model.http.response.ResponseMessages;
import com.gloqr.security.context.holder.AuthenticationFacade;
import com.gloqr.security.context.holder.UserDetails;
import com.gloqr.service.CountManageService;
import com.gloqr.service.FileService;
import com.gloqr.service.SmeService;
import com.gloqr.service.VacancyService;
import com.gloqr.util.FinalResponsePrepareUtil;
import com.gloqr.util.JsonUtil;
import com.gloqr.util.ValidationUtil;
import com.gloqr.vo.VacancyBasicInfo;
import com.gloqr.vo.VacancyVo;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.VACANCY_ROOT_API)
@SuppressWarnings("rawtypes")
public class VacancyController {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private JsonUtil jsonUtil;

	@Autowired
	private FileService fileService;

	@Autowired
	private VacancyService vacancyService;

	@Autowired
	private VacancyMapper vacancyMapper;

	@Autowired
	private SmeService smeService;

	@Autowired
	private FinalResponsePrepareUtil finalObjectPrepareUtil;

	@Autowired
	private AuthenticationFacade authenticationFacade;

	@Autowired
	private CountManageService countManageService;

	@PreAuthorize(RoleAccess.SME_ADMIN)
	@PostMapping(UrlMapping.SAVE)
	@PostVacancyCheckCredits
	public ResponseEntity<CustomHttpResponse> postVacancy(Authentication authentication,
			@Valid @RequestBody VacancyDto vacancyDto) {

		UserDetails userDetail = (UserDetails) authentication.getPrincipal();
		vacancyDto.setSmeUuid(userDetail.getSmeId());
		log.info("Request for Post-Vacancy by userId {} and smeId: {}", userDetail.getUserId(), userDetail.getSmeId());

		ValidationUtil.checkValidation(vacancyDto);
		try {
			Vacancy vacancy = vacancyMapper.convertToEntity(vacancyDto, Vacancy.class);
			vacancyService.saveVacancy(vacancy);

			countManageService.updateVacanciesCount(vacancy.getSmeUuid(), authenticationFacade.getJwtToken());
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(ResponseMessages.VACANCY_POSTED, HttpStatus.CREATED);

	}

	@PreAuthorize(RoleAccess.SME_ADMIN)
	@PutMapping(UrlMapping.SAVE)
	@PostVacancyCheckCredits
	public ResponseEntity<CustomHttpResponse> updateVacancy(Authentication authentication,
			@Valid @RequestBody VacancyDto vacancyDto) {

		UserDetails userDetail = (UserDetails) authentication.getPrincipal();
		vacancyDto.setSmeUuid(userDetail.getSmeId());
		log.info("Request for update vacancy by userId {} and smeId: {}", userDetail.getUserId(),
				userDetail.getSmeId());
		try {

			Vacancy vacancy = vacancyMapper.convertToEntity(vacancyDto, Vacancy.class);
			vacancyService.updateVacancy(vacancy);
			countManageService.updateVacanciesCount(vacancy.getSmeUuid(), authenticationFacade.getJwtToken());
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.VACANCY_UPDATED, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.VACANCIES_BY_SME_EDIT_MODE)
	@PreAuthorize(RoleAccess.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse<List<VacancyVo>>> getVacanciesBySmeIdForEditMode(
			Authentication authentication, @RequestParam(required = false) boolean pendingVacancies) {
		UserDetails userDetail = (UserDetails) authentication.getPrincipal();

		List<VacancyVo> vacanciesVo = null;
		log.info("Request for get vacancies for edit mode by userId {} and smeId: {}", userDetail.getUserId(),
				userDetail.getSmeId());
		try {

			List<Vacancy> vacancies = vacancyService.getVacanciesBySmeId(userDetail.getSmeId(), pendingVacancies);
			vacanciesVo = finalObjectPrepareUtil.prepareForVos(vacancies, userDetail.getSmeId(), null);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(vacanciesVo, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.VACANCIES_BY_SME_VIEW_MODE)
	public ResponseEntity<CustomHttpResponse<List<VacancyVo>>> getVacanciesBySmeIdForViewMode(
			Authentication authentication, @PathVariable String smeId) {
		log.info("Request for get vacancies for view mode by smeId: {}", smeId);
		List<VacancyVo> vacanciesVo = null;

		try {
			List<Vacancy> vacancies = vacancyService.getActiveAndApprovedVacancies(smeId);

			if (authentication != null && (UserDetails) authentication.getPrincipal() != null) {
				UserDetails userDetail = (UserDetails) authentication.getPrincipal();
				final String loggedInUserId = userDetail.getUserId();
				vacancyService.setVacancyApplied(vacancies, loggedInUserId);
			}

			vacanciesVo = finalObjectPrepareUtil.prepareForVos(vacancies, smeId, null);

		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(vacanciesVo, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.VACANCY_EDIT_MODE)
	@PreAuthorize(RoleAccess.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse<VacancyDto>> getVacancyForEditMode(Authentication authentication,
			@PathVariable String vacancyUuid) {
		UserDetails userDetail = (UserDetails) authentication.getPrincipal();
		VacancyDto vacancyDto = null;

		log.info("Request for get single vacancy for edit mode by userId {} and smeId: {} and vacancyId: {}",
				userDetail.getUserId(), userDetail.getSmeId(), vacancyUuid);

		try {
			Vacancy vacancy = vacancyService.getVacancyByUuidAndSmeId(vacancyUuid, userDetail.getSmeId());
			vacancyDto = finalObjectPrepareUtil.prepareForDto(vacancy);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(vacancyDto, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.VACANCY_VIEW_MODE)
	public ResponseEntity<CustomHttpResponse<VacancyVo>> getVacancyForViewMode(Authentication authentication,
			@PathVariable String vacancyUuid) {
		log.info("Request for get single vacancy for view mode by vacancy id {}", vacancyUuid);
		VacancyVo vacancyVo = null;

		try {
			Vacancy vacancy = vacancyService.getVacancyByUuidAndActiveAndState(vacancyUuid);
			if (authentication != null && (UserDetails) authentication.getPrincipal() != null) {
				UserDetails userDetail = (UserDetails) authentication.getPrincipal();
				final String loggedInUserId = userDetail.getUserId();
				vacancyService.setVacancyApplied(Arrays.asList(vacancy), loggedInUserId);
			}
			vacancyVo = finalObjectPrepareUtil.prepareForVo(vacancy, vacancy.getSmeUuid());
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(vacancyVo, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@PostMapping(UrlMapping.APPLY)
	@PreAuthorize(RoleAccess.USER)
	public ResponseEntity<CustomHttpResponse> applyVacancy(Authentication authentication,
			@PathVariable String vacancyUuid) {

		UserDetails userDetail = (UserDetails) authentication.getPrincipal();

		final String jobSeekerUserId = userDetail.getUserId();

		try {
			vacancyService.applyVacancy(vacancyUuid, jobSeekerUserId, null);

		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(ResponseMessages.VACANCY_APLLIED, HttpStatus.OK);

	}

	@PostMapping(UrlMapping.CUSTOM_APPLY)
	@PreAuthorize(RoleAccess.SME_ADMIN)
	public ResponseEntity<CustomHttpResponse> applyVacancy(Authentication authentication,
			MultipartHttpServletRequest request, @RequestParam(value = "resume", required = false) MultipartFile resume,
			@PathVariable String vacancyUuid) {
		UserDetails userDetail = (UserDetails) authentication.getPrincipal();

		CustomApplicant customApplicant = jsonUtil.parseJsonData(request, "applicant", CustomApplicant.class);

		try {

			// ValidationUtil.checkValidation(customApplicant);

			try {
				if (resume != null) {
					ValidationUtil.checkValidation(resume);
					String resumeLocation = fileService.sendFilesToContentServer(resume,
							FileDirectory.CUSTOM_APPLICANT_RESUME_DIR.replace("{vacancyId}", vacancyUuid));
					customApplicant.setResumeUrl(resumeLocation);
					customApplicant.setResumeFileName(resume.getOriginalFilename());
				}
			} catch (Exception e) {
				log.error("Resume file does not upload successfully. exception message: {}", e.getMessage());
			}
			customApplicant.setRefSmeId(userDetail.getSmeId());
			vacancyService.applyVacancy(vacancyUuid, null, customApplicant);

		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.VACANCY_APLLIED, HttpStatus.OK);

	}

	@PreAuthorize(RoleAccess.SME_ADMIN)
	@GetMapping(UrlMapping.APPLICANTS)
	public ResponseEntity<CustomHttpResponse<List<VacancyApplicantDto>>> getJobApplicants(
			@PathVariable String vacancyUuid) {

		List<VacancyApplicantDto> jobApplicantsDto = new ArrayList<>();

		List<VacancyApplicant> jobApplicants = null;

		try {
			jobApplicants = vacancyService.getJobApplicants(vacancyUuid);

			jobApplicants.forEach(jobApplicant -> {
				VacancyApplicantDto dto = vacancyMapper.convertToDto(jobApplicant, VacancyApplicantDto.class);

				if (jobApplicant.getApplicant() != null) {
					List<ExperienceDetail> details = jobApplicant.getApplicant().getExperienceDetails();

					if (details != null && !details.isEmpty()) {
						for (ExperienceDetail detail : details) {
							if (detail.isCurrentlyWorking()) {
								dto.getApplicant().setCurrentOrganization(detail.getCompanyName());
								dto.getApplicant().setCurrentDesig(detail.getJobRole().getJobRole());
							}
						}
					}
				}

				jobApplicantsDto.add(dto);
			});
		} catch (CustomException e) {
			throw e;
		}
		return responseMaker.successResponse(jobApplicantsDto, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@PreAuthorize(RoleAccess.SME_ADMIN)
	@GetMapping(UrlMapping.GET_SINGLE_APPLICANT)
	public ResponseEntity<CustomHttpResponse<VacancyApplicantDto>> getSingleApplicantByApplicantUuid(
			@PathVariable String applicantUuid) {

		VacancyApplicantDto vacancyApplicantDto = null;

		try {
			VacancyApplicant vacancyApplicant = vacancyService.getApplicantProfileByUuid(applicantUuid);
			// UserDto userDto =
			// userEndPoint.getUser(jobSeekerProfile.getJobSeekerProfileId());
			vacancyApplicantDto = vacancyMapper.convertToDto(vacancyApplicant, VacancyApplicantDto.class);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(vacancyApplicantDto, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@DeleteMapping(UrlMapping.DELETE_VACANCY)
	public ResponseEntity<CustomHttpResponse<String>> deleteVacancy(@PathVariable("vacancyUuid") String vacancyUuid) {
		try {

			CustomHttpResponse<String> customHttpResponse = new CustomHttpResponse<>(false, HttpStatus.OK.value(),
					HttpStatus.OK, ResponseMessages.SUCCESS, "Method implemetation are pending...vacancy not deleted.");
			return ResponseEntity.ok().body(customHttpResponse);

		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getHttpStatus());
		}
	}

	@GetMapping(UrlMapping.GET_TOP_JOBS)
	public ResponseEntity<CustomHttpResponse<List<VacancyBasicInfo>>> getTopJobs() {
		List<VacancyBasicInfo> vacancies = null;
		try {
			vacancies = vacancyService.getTopVacancies();

			Set<String> smeIds = vacancies.stream().map(VacancyBasicInfo::getSmeUuid).collect(Collectors.toSet());
			Map<String, SMEDto> smes = smeService.getSMEs(smeIds);
			for (VacancyBasicInfo vacancy : vacancies) {
				vacancy.setSmeInfo(smes.get(vacancy.getSmeUuid()));
			}

		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(vacancies, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@PreAuthorize(RoleAccess.SME_ADMIN)
	@PostMapping(UrlMapping.SHORTLISTED)
	public ResponseEntity<CustomHttpResponse> saveShortListedCandidateDetail(
			@Valid @RequestBody VacancyApplicantDto vacancyApplicantDto) {

		if (vacancyApplicantDto.getApplicantUuid() == null) {
			throw new CustomException("", HttpStatus.INTERNAL_SERVER_ERROR);
		}

		try {
			VacancyApplicant vacancyApplicant = vacancyMapper.convertToEntity(vacancyApplicantDto,
					VacancyApplicant.class);

			vacancyService.shortListJobSeeker(vacancyApplicant);

		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(ResponseMessages.JOBSEEKER_SHORTLISTED, HttpStatus.CREATED);

	}

}
