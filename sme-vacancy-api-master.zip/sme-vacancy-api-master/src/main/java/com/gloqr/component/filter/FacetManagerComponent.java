package com.gloqr.component.filter;

import java.util.HashMap;
import java.util.Map;

import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.hibernate.search.query.engine.spi.FacetManager;
import org.hibernate.search.query.facet.FacetingRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.gloqr.constants.FilterConstant.FacetConstant;
import com.gloqr.constants.FilterConstant.SearchFileds;
import com.gloqr.service.filter.VacancyFilterService;

@Component
public class FacetManagerComponent {

	@Autowired
	@Qualifier("vacActiveApprovedFilter")
	private VacancyFilterService vacancyFilterService;

	public FacetManager getFacetManagerForActiveApprovedVacancy(final FullTextEntityManager fullTextEntityManager,
			final QueryBuilder queryBuilder) {

		FullTextQuery fullTextQuery = vacancyFilterService.createFullTextQuery(fullTextEntityManager, queryBuilder,
				null, 0, 0);
		FacetManager facetManager = fullTextQuery.getFacetManager();

		Map<String, FacetingRequest> facetingRequests = getFacetingRequests(queryBuilder);
		facetManager.enableFaceting(facetingRequests.get(FacetConstant.SME_ID_FACET_REQ));
		facetManager.enableFaceting(facetingRequests.get(FacetConstant.LOCATIONS_FACET_REQ));
		facetManager.enableFaceting(facetingRequests.get(FacetConstant.JOB_ROLE_FACET_REQ));

		return facetManager;
	}

	public Map<String, FacetingRequest> getFacetingRequests(final QueryBuilder queryBuilder) {

		FacetingRequest smeIdFacetingRequest = queryBuilder.facet().name(FacetConstant.SME_ID_FACET)
				.onField(SearchFileds.SME_ID).discrete().includeZeroCounts(false).createFacetingRequest();

		FacetingRequest locationsFacetingRequest = queryBuilder.facet().name(FacetConstant.LOCATIONS_FACET)
				.onField(SearchFileds.LOCATIONS).discrete().includeZeroCounts(false).createFacetingRequest();

		FacetingRequest jobRoleFacetingRequest = queryBuilder.facet().name(FacetConstant.JOB_ROLE_FACET)
				.onField(SearchFileds.JOB_ROLE).discrete().includeZeroCounts(false).createFacetingRequest();

		Map<String, FacetingRequest> facetingRequests = new HashMap<>();
		facetingRequests.put(FacetConstant.SME_ID_FACET_REQ, smeIdFacetingRequest);
		facetingRequests.put(FacetConstant.LOCATIONS_FACET_REQ, locationsFacetingRequest);
		facetingRequests.put(FacetConstant.JOB_ROLE_FACET_REQ, jobRoleFacetingRequest);

		return facetingRequests;
	}
}
