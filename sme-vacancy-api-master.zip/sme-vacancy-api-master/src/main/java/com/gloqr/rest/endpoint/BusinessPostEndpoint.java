package com.gloqr.rest.endpoint;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.gloqr.exception.CustomException;
import com.gloqr.model.PublishFeed;
import com.gloqr.security.configuration.JwtConstants;
import com.gloqr.security.context.holder.AuthenticationFacade;

public class BusinessPostEndpoint {
	private Logger log = LogManager.getLogger();

	private Client client;
	private String endPointUri;
	private String createFeed;

	@Autowired
	private AuthenticationFacade authenticationFacade;

	public BusinessPostEndpoint(Client client, String endPointUri, String createFeed) {
		super();
		this.client = client;
		this.endPointUri = endPointUri;
		this.createFeed = createFeed;
	}

	public void createFeed(PublishFeed feed) {

		Response response = null;

		log.info("Creating Post..");
		log.info("Connecting to Business-Post module... {method=POST ,uri={}{} ,params=publishedPost:true ,body={} }",
				endPointUri, createFeed, feed);

		try {
			response = client.target(endPointUri).path(createFeed).queryParam("publishedPost", true)
					.request(MediaType.APPLICATION_JSON)
					.header(JwtConstants.HEADER_STRING, authenticationFacade.getJwtToken())
					.post(Entity.entity(feed, MediaType.APPLICATION_JSON));
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);
		Integer statusCode = response.getStatus();

		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}

	}


	private void throwInvalidResponseException(int statusCode) {
		throw new CustomException("Invalid Response from Business post Module: ", HttpStatus.resolve(statusCode));
	}

	private void throwConnectionRefusedException(Exception e) {
		throw new CustomException("Couldn't Connect to Business post module, Exception: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	private void logResponse(Response response) {
		log.info("Response From Business post Module : " + response);
	}

}
