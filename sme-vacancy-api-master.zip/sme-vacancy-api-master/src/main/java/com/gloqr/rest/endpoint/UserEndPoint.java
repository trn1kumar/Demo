package com.gloqr.rest.endpoint;

import javax.ws.rs.client.Client;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;

import com.gloqr.dto.UserDto;
import com.gloqr.exception.CustomException;
import com.gloqr.model.http.response.CustomHttpResponse;

public class UserEndPoint {

	private Client client;
	private String endPointUri;
	private String userPath;
	private Logger log = LogManager.getLogger();

	public UserEndPoint(Client client, String endPointUri, String userPath) {
		super();
		this.client = client;
		this.endPointUri = endPointUri;
		this.userPath = userPath;
	}

	public UserDto getUser(String userUuid) {
		Response response = null;
		CustomHttpResponse<UserDto> userDtoResponse = null;

		try {
			response = client.target(endPointUri).path(userPath.replace("{uuid}", userUuid))
					.request(MediaType.APPLICATION_JSON).get();
		} catch (Exception e) {
			throwConnectionRefusedException(e);

		}

		logResponse(response);
		Integer statusCode = response.getStatus();

		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}

		try {
			userDtoResponse = response.readEntity(new GenericType<CustomHttpResponse<UserDto>>() {
			});
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}

		return userDtoResponse.getData();

	}

	private void throwEntityResponseReadException(Exception e) {
		throw new CustomException("Exception at read response from Authentication-Server. Message: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private void throwInvalidResponseException(int statusCode) {
		throw new CustomException("Invalid Response from Authentication-Server: ", HttpStatus.resolve(statusCode));
	}

	private void throwConnectionRefusedException(Exception e) {
		throw new CustomException("Couldn't Connect to Authentication-Server, Exception: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private void logResponse(Response response) {
		log.info("Response From Authentication-Server : " + response);
	}

}
