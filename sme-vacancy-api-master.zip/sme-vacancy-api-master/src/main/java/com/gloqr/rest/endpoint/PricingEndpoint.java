package com.gloqr.rest.endpoint;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.gloqr.constants.CreditType;
import com.gloqr.exception.CustomException;
import com.gloqr.exception.NoCreditException;
import com.gloqr.model.CreditsCheckResponse;
import com.gloqr.model.PricingRequest;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.security.configuration.JwtConstants;
import com.gloqr.security.context.holder.AuthenticationFacade;

@Component
public class PricingEndpoint {

	private Logger logger = LogManager.getLogger();
	private Client client;
	private String endPointUri;
	private String checkCreditsPath;
	private String adminUpdateCreditsPath;

	@Autowired
	private AuthenticationFacade authenticationFacade;

	public PricingEndpoint(Client client, String endPointUri, String checkCreditsPath, String adminUpdateCreditsPath) {
		super();
		this.client = client;
		this.endPointUri = endPointUri;
		this.checkCreditsPath = checkCreditsPath;
		this.adminUpdateCreditsPath = adminUpdateCreditsPath;
	}

	public void updateCredits(CreditType creditType, String usedForMessage, String action, long credits) {
		PricingRequest pricingRequest = null;
		pricingRequest = new PricingRequest();
		pricingRequest.setAction(action);
		pricingRequest.setCredits(credits);
		pricingRequest.setUsedFor(usedForMessage);
		pricingRequest.setType(creditType);
		this.updateCredits(pricingRequest);
	}

	public long checkCredits(CreditType creditType) {

		logger.info("Checking available credits for  :: " + creditType);
		logger.info("Connecting to Pricing Module...  {method=GET ,uri= {}{} ,param= type:{} }", endPointUri,
				checkCreditsPath, creditType.toString());

		Response response = null;
		CustomHttpResponse<CreditsCheckResponse> httpResponse = null;
		try {
			response = client.target(endPointUri).path(checkCreditsPath).queryParam("type", creditType.toString())
					.request(MediaType.APPLICATION_JSON)
					.header(JwtConstants.HEADER_STRING, authenticationFacade.getJwtToken()).get();

		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);
		Integer statusCode = response.getStatus();
		if (statusCode != HttpStatus.OK.value()) {
			invalidResponseException(statusCode);
		}
		try {
			httpResponse = response.readEntity(new GenericType<CustomHttpResponse<CreditsCheckResponse>>() {
			});

		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}

		if (httpResponse.isError() && httpResponse.getCode() == HttpStatus.PAYMENT_REQUIRED.value()) {
			throw new NoCreditException(creditType);
		} else if (httpResponse.isError()) {
			throw new CustomException(httpResponse.getMessage(), httpResponse.getStatus());
		}

		logger.info("Available credits :  " + httpResponse.getData().getCredits());
		return httpResponse.getData().getCredits();
	}

	public void updateCredits(PricingRequest pricingRequestDTO) {

		String url = null;
		if (StringUtils.isNotBlank(pricingRequestDTO.getsUuid())
				&& StringUtils.isNotBlank(pricingRequestDTO.getUserUUID())) {
			url = adminUpdateCreditsPath;
		} else {
			url = checkCreditsPath;
		}

		logger.info("Updating Credits..");
		logger.info("Connecting to Pricing Module...  {method=PUT ,uri= {}{} ,body= {} }", endPointUri, url,
				pricingRequestDTO);

		CustomHttpResponse<?> httpResponse = null;
		Response response = null;
		try {
			response = client.target(endPointUri).path(url).request(MediaType.APPLICATION_JSON)
					.header(JwtConstants.HEADER_STRING, authenticationFacade.getJwtToken())
					.put(Entity.entity(pricingRequestDTO, MediaType.APPLICATION_JSON));

		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);
		Integer statusCode = response.getStatus();
		if (statusCode != HttpStatus.OK.value()) {
			invalidResponseException(statusCode);
		}

		try {
			httpResponse = response.readEntity(new GenericType<CustomHttpResponse<?>>() {
			});

		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}

		if (httpResponse.isError() && httpResponse.getCode() == HttpStatus.PAYMENT_REQUIRED.value()) {
			throw new NoCreditException(pricingRequestDTO.getCreditType());
		} else if (httpResponse.isError()) {
			throw new CustomException(httpResponse.getMessage(), httpResponse.getStatus());
		}
	}

	private void throwConnectionRefusedException(Exception e) {
		throw new CustomException("Couldn't Connect to Pricing module, Exception: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	private void throwEntityResponseReadException(Exception e) {
		throw new CustomException("Exception at read response from Pricing Module. Message: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	public void noCreditsLeftException(CreditType creditType) {
		throw new NoCreditException(creditType);
	}

	public void invalidResponseException(int statusCode) {
		throw new CustomException("Invalid Response from Pricing endpoint ", HttpStatus.resolve(statusCode));
	}

	private void logResponse(Response response) {
		logger.info("Response From Pricing Module : " + response.toString());
	}

}
