package com.gloqr.entities.master;

import java.util.List;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "courses")
public class Course {

	@Id
	@Column(name = "course_id")
	private String courseId;

	@Column(name = "course_name")
	private String courseName;

	@OneToMany(mappedBy = "course", cascade = CascadeType.ALL)
	private List<Specialization> specializations;

	@Transient
	private int totalSpecializations;

	@ManyToOne(fetch = FetchType.LAZY)
	private CourseCategory courseCategory;

	public CourseCategory getCourseCategory() {
		return courseCategory;
	}

	public void setCourseCategory(CourseCategory courseCategory) {
		this.courseCategory = courseCategory;
	}

	public String getCourseName() {
		return courseName;
	}

	public List<Specialization> getSpecializations() {
		return specializations;
	}

	public String getCourseId() {
		return courseId;
	}

	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}

	public int getTotalSpecializations() {
		return totalSpecializations;
	}

	public void setTotalSpecializations(int totalSpecializations) {
		this.totalSpecializations = totalSpecializations;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public void setSpecializations(List<Specialization> specializations) {
		this.specializations = specializations;
	}

	@Override
	public int hashCode() {
		return Objects.hash(courseId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Course))
			return false;
		Course other = (Course) obj;
		return Objects.equals(courseId, other.courseId);
	}
	
	
	
	

}
