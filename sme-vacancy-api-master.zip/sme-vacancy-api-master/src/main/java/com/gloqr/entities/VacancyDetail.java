package com.gloqr.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name= "sme_vacancy_detail")
public class VacancyDetail {

	@Id
	@GeneratedValue
	@Column(name = "vacancy_detail_id")
	@JsonIgnore
	private Long detailId;
	
	@Column(name = "vacancy_detail_uuid")
	private String vdUuId;

	@Column(name="long_description",length = 1000)
	String longDescription;
	
	@Column(name="contact_email_Id")
	private String contactEmail;
	
	@Column(name="contact_mobile_Number")
	private String contactMobileNumber;

	public String getLongDescription() {
		return longDescription;
	}

	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getContactMobileNumber() {
		return contactMobileNumber;
	}

	public void setContactMobileNumber(String contactMobileNumber) {
		this.contactMobileNumber = contactMobileNumber;
	}

	public Long getDetailId() {
		return detailId;
	}

	public void setDetailId(Long detailId) {
		this.detailId = detailId;
	}

	public String getVdUuId() {
		return vdUuId;
	}

	public void setVdUuId(String vdUuId) {
		this.vdUuId = vdUuId;
	}

	@Override
	public String toString() {
		return "VacancyDetail [detailId=" + detailId + ", vdUuId=" + vdUuId + ", longDescription=" + longDescription
				+ ", contactEmail=" + contactEmail + ", contactMobileNumber=" + contactMobileNumber + "]";
	}

}
