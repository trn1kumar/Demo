package com.gloqr.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "sme_vacancy_other_category")
public class VacancyOtherCategory implements Serializable{
	
	private static final long serialVersionUID = -1414595965479848783L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@JsonIgnore
	private Long id;
	
	@Column(length = 100)
	@Size(max = 100, message = "Category Name should be less than 100")
	private String customIndustrialArea;

	@Column(length = 100)
	@Size(max = 100, message = "SubCategory Name should be less than 100")
	private String customJobRoleUuid;

	private String areaUuid;

	public String getCustomIndustrialArea() {
		return customIndustrialArea;
	}

	public void setCustomIndustrialArea(String customIndustrialArea) {
		this.customIndustrialArea = customIndustrialArea;
	}

	public String getCustomJobRoleUuid() {
		return customJobRoleUuid;
	}

	public void setCustomJobRoleUuid(String customJobRoleUuid) {
		this.customJobRoleUuid = customJobRoleUuid;
	}

	public String getAreaUuid() {
		return areaUuid;
	}

	public void setAreaUuid(String areaUuid) {
		this.areaUuid = areaUuid;
	}


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
}
