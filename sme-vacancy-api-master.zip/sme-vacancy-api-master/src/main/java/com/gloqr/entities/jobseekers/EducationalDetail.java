package com.gloqr.entities.jobseekers;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gloqr.entities.master.Course;
import com.gloqr.entities.master.Specialization;

@Entity
@Table(name = "JobSeekersEducationalDetail")
public class EducationalDetail {

	@Id
	@Column(name = "educationalDetailId")
	@JsonIgnore
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long educationalDetailId;

	@Column(name = "educationalDetailUuid", unique = true, updatable = true)
	private String educationalDetailUuid;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "specialization_id")
	private Specialization qualificationSpecialization;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "course_id")
	private Course qualificationCourse;

	@Column(name = "universityName")
	private String universityName;

	@Column(name = "instituteName")
	private String instituteName;

	@Column(name = "passingOutYear")
	private int passingOutYear;

	@Column(name = "percentage")
	private double percentage;

	public String getEducationalDetailUuid() {
		return educationalDetailUuid;
	}

	public void setEducationalDetailUuid(String educationalDetailUuid) {
		this.educationalDetailUuid = educationalDetailUuid;
	}

	public String getInstituteName() {
		return instituteName;
	}

	public double getPercentage() {
		return percentage;
	}

	public Course getQualificationCourse() {
		return qualificationCourse;
	}

	public void setQualificationCourse(Course qualificationCourse) {
		this.qualificationCourse = qualificationCourse;
	}

	public Long getEducationalDetailId() {
		return educationalDetailId;
	}

	public Specialization getQualificationSpecialization() {
		return qualificationSpecialization;
	}

	public void setQualificationSpecialization(Specialization qualificationSpecialization) {
		this.qualificationSpecialization = qualificationSpecialization;
	}

	public void setEducationalDetailId(Long educationalDetailId) {
		this.educationalDetailId = educationalDetailId;
	}

	public int getPassingOutYear() {
		return passingOutYear;
	}

	public void setPassingOutYear(int passingOutYear) {
		this.passingOutYear = passingOutYear;
	}

	public String getUniversityName() {
		return universityName;
	}

	public void setUniversityName(String universityName) {
		this.universityName = universityName;
	}
	
	public void setInstituteName(String instituteName) {
		this.instituteName = instituteName;
	}

	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}

}
