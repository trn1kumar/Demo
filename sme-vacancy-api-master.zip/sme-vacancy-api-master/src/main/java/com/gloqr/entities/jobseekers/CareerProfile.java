package com.gloqr.entities.jobseekers;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gloqr.constants.PreferredShift;
import com.gloqr.entities.master.IndustrialJobRole;

@Entity
@Table(name = "JobSeekersCareerProfileDetail")
public class CareerProfile {

	@Id
	@Column(name = "careerProfileDetailId")
	@JsonIgnore
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long careerProfileDetailId;

	@Column(name = "careerProfileDetailUuid")
	private String careerProfileDetailUuid;

	@ElementCollection
	@CollectionTable(name = "job_seeker_career_profile_job_types", joinColumns = @JoinColumn(name = "career_profile_detail_id"))
	@Column(name = "jobType")
	private List<String> jobTypes;

	@ElementCollection
	@CollectionTable(name = "job_seeker_career_profile_employment_types", joinColumns = @JoinColumn(name = "career_profile_detail_id"))
	@Column(name = "employmentType")
	private List<String> employmentTypes;

	@Enumerated(EnumType.STRING)
	private PreferredShift preferredShift;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "salaryId")
	private EmploymentSalary expectedSalary;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "jobRoleId")
	private IndustrialJobRole jobRole;

	@ElementCollection
	@CollectionTable(name = "job_seeker_career_profile_preffered_job_locations", joinColumns = @JoinColumn(name = "careerProfileDetailId"))
	@Column(name = "location")
	private List<String> prefferedJobLocations;

	public String getCareerProfileDetailUuid() {
		return careerProfileDetailUuid;
	}

	public PreferredShift getPreferredShift() {
		return preferredShift;
	}

	public IndustrialJobRole getJobRole() {
		return jobRole;
	}

	public List<String> getJobTypes() {
		return jobTypes;
	}

	public List<String> getEmploymentTypes() {
		return employmentTypes;
	}

	public void setJobTypes(List<String> jobTypes) {
		this.jobTypes = jobTypes;
	}

	public void setEmploymentTypes(List<String> employmentTypes) {
		this.employmentTypes = employmentTypes;
	}

	public void setPreferredShift(PreferredShift preferredShift) {
		this.preferredShift = preferredShift;
	}

	public void setJobRole(IndustrialJobRole jobRole) {
		this.jobRole = jobRole;
	}

	public void setCareerProfileDetailUuid(String careerProfileDetailUuid) {
		this.careerProfileDetailUuid = careerProfileDetailUuid;
	}

	public Long getCareerProfileDetailId() {
		return careerProfileDetailId;
	}

	public void setCareerProfileDetailId(Long careerProfileDetailId) {
		this.careerProfileDetailId = careerProfileDetailId;
	}

	public EmploymentSalary getExpectedSalary() {
		return expectedSalary;
	}

	public void setExpectedSalary(EmploymentSalary expectedSalary) {
		this.expectedSalary = expectedSalary;
	}

	public List<String> getPrefferedJobLocations() {
		return prefferedJobLocations;
	}

	public void setPrefferedJobLocations(List<String> prefferedJobLocations) {
		this.prefferedJobLocations = prefferedJobLocations;
	}

}
