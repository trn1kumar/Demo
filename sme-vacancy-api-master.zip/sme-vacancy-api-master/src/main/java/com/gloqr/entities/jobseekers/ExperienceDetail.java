package com.gloqr.entities.jobseekers;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gloqr.entities.master.IndustrialJobRole;

@Entity
@Table(name = "JobSeekersExceperienceDetail")
public class ExperienceDetail implements Comparable<ExperienceDetail> {

	@Id
	@Column(name = "experienceDetailId")
	@JsonIgnore
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long experienceDetailId;

	@Column(name = "experienceDetailUuid", unique = true, updatable = true)
	private String experienceDetailUuid;

	@Column(name = "companyName")
	private String companyName;

	@Column(name = "description")
	private String description;

	@Column(name = "startDate")
	private Date startDate;

	@Column(name = "endDate")
	private Date endDate;

	@Column(name = "currentlyWorking")
	private boolean currentlyWorking;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "jobRoleId")
	private IndustrialJobRole jobRole;

	@Column(name = "noticePeriod")
	private String noticePeriod;

	public IndustrialJobRole getJobRole() {
		return jobRole;
	}

	public void setJobRole(IndustrialJobRole jobRole) {
		this.jobRole = jobRole;
	}

	public String getCompanyName() {
		return companyName;
	}

	public String getNoticePeriod() {
		return noticePeriod;
	}

	public void setNoticePeriod(String noticePeriod) {
		this.noticePeriod = noticePeriod;
	}

	public String getDescription() {
		return description;
	}

	public Date getStartDate() {
		return startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public boolean isCurrentlyWorking() {
		return currentlyWorking;
	}

	public void setCurrentlyWorking(boolean currentlyWorking) {
		this.currentlyWorking = currentlyWorking;
	}



	public Long getExperienceDetailId() {
		return experienceDetailId;
	}

	public void setExperienceDetailId(Long experienceDetailId) {
		this.experienceDetailId = experienceDetailId;
	}

	public String getExperienceDetailUuid() {
		return experienceDetailUuid;
	}

	public void setExperienceDetailUuid(String experienceDetailUuid) {
		this.experienceDetailUuid = experienceDetailUuid;
	}

	@Override
	public int compareTo(ExperienceDetail o) {

		int i = this.isCurrentlyWorking() ? 1 : 0;
		int i1 = o.isCurrentlyWorking() ? 1 : 0;
		return i1 - i;

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((experienceDetailId == null) ? 0 : experienceDetailId.hashCode());
		result = prime * result + ((experienceDetailUuid == null) ? 0 : experienceDetailUuid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExperienceDetail other = (ExperienceDetail) obj;
		if (experienceDetailId == null) {
			if (other.experienceDetailId != null)
				return false;
		} else if (!experienceDetailId.equals(other.experienceDetailId)) {
			return false;
		}

		if (experienceDetailUuid == null) {
			if (other.experienceDetailUuid != null)
				return false;
		} else if (!experienceDetailUuid.equals(other.experienceDetailUuid)) {
			return false;
		}

		return true;
	}

}
