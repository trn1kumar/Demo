package com.gloqr.entities.master;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "specializations")
public class Specialization {

	@Id
	@Column(name = "specialization_id")
	private String specializationId;

	@Column(name = "specializationName")
	private String specializationName;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "courseId", updatable = false)
	private Course course;



	public String getSpecializationId() {
		return specializationId;
	}

	public String getSpecializationName() {
		return specializationName;
	}

	public void setSpecializationId(String specializationId) {
		this.specializationId = specializationId;
	}

	public void setSpecializationName(String specializationName) {
		this.specializationName = specializationName;
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

}
