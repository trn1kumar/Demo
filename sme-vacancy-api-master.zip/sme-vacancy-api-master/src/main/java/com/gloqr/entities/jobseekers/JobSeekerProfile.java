package com.gloqr.entities.jobseekers;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.gloqr.audit.Auditable;
import com.gloqr.constants.Gender;

@Entity
@Table(name = "JobSeekerProfile")
public class JobSeekerProfile extends Auditable<String> {

	@Id
	@Column(name = "jobSeekerProfileId")
	private String jobSeekerProfileId;

	@Column(name = "jobSeekerProfileUuid", nullable = false, unique = true, updatable = false)
	private String jobSeekerProfileUuid;

	@Column(name = "fullName")
	private String fullName;

	@Column(name = "emailId")
	private String emailId;

	@Column(name = "mobileNumber")
	private String mobileNumber;

	@Enumerated(EnumType.STRING)
	private Gender gender;

	@Column(name = "dob")
	private Date dob;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "resumeId")
	private JobSeekerResume resume;
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "jobSeekerAddressId")
	private JobSeekerAddress jobSeekerAddress;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "salaryId")
	private EmploymentSalary currentSalary;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "experienceId")
	private Experience totalExperience;

	@ElementCollection
	@CollectionTable(name = "job_seeker_skill_sets", joinColumns = @JoinColumn(name = "jobSeekerProfileId"))
	@Column(name = "skill_set")
	private List<String> skillSets;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "educationalDetailId")
	private EducationalDetail educationalDetail;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "jobSeekerProfileId", nullable = false)
	private List<ExperienceDetail> experienceDetails;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "careerProfileDetailId")
	private CareerProfile careerProfile;

	public String getEmailId() {
		return emailId;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public EducationalDetail getEducationalDetail() {
		return educationalDetail;
	}

	public EmploymentSalary getCurrentSalary() {
		return currentSalary;
	}

	public void setCurrentSalary(EmploymentSalary currentSalary) {
		this.currentSalary = currentSalary;
	}

	public Experience getTotalExperience() {
		return totalExperience;
	}

	public void setTotalExperience(Experience totalExperience) {
		this.totalExperience = totalExperience;
	}

	public CareerProfile getCareerProfile() {
		return careerProfile;
	}

	public String getJobSeekerProfileId() {
		return jobSeekerProfileId;
	}

	public String getJobSeekerProfileUuid() {
		return jobSeekerProfileUuid;
	}

	public void setJobSeekerProfileId(String jobSeekerProfileId) {
		this.jobSeekerProfileId = jobSeekerProfileId;
	}

	public void setJobSeekerProfileUuid(String jobSeekerProfileUuid) {
		this.jobSeekerProfileUuid = jobSeekerProfileUuid;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public Date getDob() {
		return dob;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public void setEducationalDetail(EducationalDetail educationalDetail) {
		this.educationalDetail = educationalDetail;
	}

	public List<ExperienceDetail> getExperienceDetails() {
		return experienceDetails;
	}

	public void setExperienceDetails(List<ExperienceDetail> experienceDetails) {
		this.experienceDetails = experienceDetails;
	}

	public void setCareerProfile(CareerProfile careerProfile) {
		this.careerProfile = careerProfile;
	}

	public List<String> getSkillSets() {
		return skillSets;
	}

	public void setSkillSets(List<String> skillSets) {
		this.skillSets = skillSets;
	}
	
	public JobSeekerResume getResume() {
		return resume;
	}

	public void setResume(JobSeekerResume resume) {
		this.resume = resume;
	}

	public JobSeekerAddress getJobSeekerAddress() {
		return jobSeekerAddress;
	}

	public void setJobSeekerAddress(JobSeekerAddress jobSeekerAddress) {
		this.jobSeekerAddress = jobSeekerAddress;
	}
	
}
