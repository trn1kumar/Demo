package com.gloqr.entities.jobseekers;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gloqr.constants.Currency;
import com.gloqr.constants.DateType;

@Entity
@Table(name = "job_seeker_employment_salary")
public class EmploymentSalary {

	@Id
	@Column(name = "salaryId")
	@JsonIgnore
	private String salaryId;

	@Column(name = "salary")
	private long salary;

	@Enumerated(EnumType.STRING)
	private DateType salaryType;

	@Enumerated(EnumType.STRING)
	private Currency currency;

	public String getSalaryId() {
		return salaryId;
	}

	public void setSalaryId(String salaryId) {
		this.salaryId = salaryId;
	}

	public long getSalary() {
		return salary;
	}

	public void setSalary(long salary) {
		this.salary = salary;
	}

	public DateType getSalaryType() {
		return salaryType;
	}

	public void setSalaryType(DateType salaryType) {
		this.salaryType = salaryType;
	}

	public Currency getCurrency() {
		return currency;
	}

	public void setCurrency(Currency currency) {
		this.currency = currency;
	}

}
