package com.gloqr.entities.jobseekers;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "job_seeker_experience")
public class Experience {

	@Id
	@Column(name = "experienceId")
	@JsonIgnore
	private String experienceId;

	@Column(name = "month")
	private int month;

	@Column(name = "year", length = 20)
	@NotBlank(message = "year can not be blank")
	private String year; // year is a string for contain 'Fresher'

	public String getExperienceId() {
		return experienceId;
	}

	public void setExperienceId(String experienceId) {
		this.experienceId = experienceId;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

}
