package com.gloqr.entities;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.gloqr.entities.jobseekers.JobSeekerProfile;

@Entity
@Table(name = "sme_vacancy_applicants")
public class VacancyApplicant {

	@Id
	@GeneratedValue
	@Column(name = "vacancy_applicant_id")
	private Long applicantId;

	@Column(name = "vacancy_applicant_uuid", updatable = false, unique = true, nullable = false)
	private String applicantUuid;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "job_seeker_profile_id")
	private JobSeekerProfile applicant;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "custom_applicant_id")
	private CustomApplicant customApplicant;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "shortlist_info_id")
	private ShortListedInfo shortListedInfo;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "sme_vacancy_id")
	private Vacancy vacancy;

	@Column(name = "apply_date")
	private Date applyDate;

	@Column(name = "shortlisted")
	private boolean shortListed;

	public Long getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(Long applicantId) {
		this.applicantId = applicantId;
	}

	public String getApplicantUuid() {
		return applicantUuid;
	}

	public void setApplicantUuid(String applicantUuid) {
		this.applicantUuid = applicantUuid;
	}

	public JobSeekerProfile getApplicant() {
		return applicant;
	}

	public void setApplicant(JobSeekerProfile applicant) {
		this.applicant = applicant;
	}

	public Date getApplyDate() {
		return applyDate;
	}

	public void setApplyDate(Date applyDate) {
		this.applyDate = applyDate;
	}

	public CustomApplicant getCustomApplicant() {
		return customApplicant;
	}

	public void setCustomApplicant(CustomApplicant customApplicant) {
		this.customApplicant = customApplicant;
	}

	public boolean isShortListed() {
		return shortListed;
	}

	public void setShortListed(boolean shortListed) {
		this.shortListed = shortListed;
	}

	public ShortListedInfo getShortListedInfo() {
		return shortListedInfo;
	}

	public void setShortListedInfo(ShortListedInfo shortListedInfo) {
		this.shortListedInfo = shortListedInfo;
	}

	public Vacancy getVacancy() {
		return vacancy;
	}

	public void setVacancy(Vacancy vacancy) {
		this.vacancy = vacancy;
	}
}
