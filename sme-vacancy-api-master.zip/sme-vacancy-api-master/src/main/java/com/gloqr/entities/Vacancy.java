package com.gloqr.entities;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.lucene.analysis.core.LowerCaseFilterFactory;
import org.apache.lucene.analysis.pattern.PatternReplaceFilterFactory;
import org.apache.lucene.analysis.snowball.SnowballPorterFilterFactory;
import org.apache.lucene.analysis.standard.StandardTokenizerFactory;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Analyzer;
import org.hibernate.search.annotations.AnalyzerDef;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Facet;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;
import org.hibernate.search.annotations.Parameter;
import org.hibernate.search.annotations.Store;
import org.hibernate.search.annotations.TokenFilterDef;
import org.hibernate.search.annotations.TokenizerDef;

import com.gloqr.audit.Auditable;
import com.gloqr.constants.PreferredShift;
import com.gloqr.constants.VacancyState;
import com.gloqr.entities.master.Course;
import com.gloqr.entities.master.IndustrialJobRole;
import com.gloqr.entities.master.Specialization;

@Entity
@Table(name = "sme_vacancy")

@AnalyzerDef(name = "customanalyzer", tokenizer = @TokenizerDef(factory = StandardTokenizerFactory.class), filters = {

		@TokenFilterDef(factory = LowerCaseFilterFactory.class),
		@TokenFilterDef(factory = PatternReplaceFilterFactory.class, params = {
				@Parameter(name = "pattern", value = "([^a-zA-Z0-9\\.])"),
				@Parameter(name = "replacement", value = " "), @Parameter(name = "replace", value = "all") }),
		@TokenFilterDef(factory = SnowballPorterFilterFactory.class, params = {
				@Parameter(name = "language", value = "English") })

})
@Indexed
public class Vacancy extends Auditable<String> {

	@Id
	@GeneratedValue
	@Column(name = "sme_vacancy_id")
	@DocumentId
	private Long vacancyId;

	@Column(name = "sme_uuid")
	@Field(analyze = Analyze.NO)
	@Facet
	private String smeUuid;

	@Column(name = "vacancy_uuid")
	private String vacancyUuid;
	
	@Column(name = "vacancy_url")
	private String vacancyUrl;

	@Column(name = "vacancyState", length = 15)
	@Enumerated(EnumType.STRING)
	@Field(index = Index.YES, store = Store.NO, analyze = Analyze.NO)
	private VacancyState vacancyState;

	@Column(name = "is_business_post_activated")
	private boolean businessPostAlreadyActivated;

	@Column(name = "is_business_post")
	private boolean businessPost;

	@Column(name = "is_modified")
	private boolean vacancyModified;

	@Column(name = "feedback_message")
	private String feedbackMessage;

	@Column(name = "vacancy_title")
	private String vacancyTitle;
	
	@Column(name = "short_description")
	private String shortDescription;

	@Column(name = "minimum_work_experience")
	@Field(index = Index.YES, store = Store.NO, analyze = Analyze.YES)
	@Analyzer(definition = "customanalyzer")
	private double minExp;

	@Column(name = "maximum_work_experience")
	@Field(index = Index.YES, store = Store.NO, analyze = Analyze.YES)
	@Analyzer(definition = "customanalyzer")
	private double maxExp;

	@Column(name = "minimum_salary")
	@Field(index = Index.YES, store = Store.NO, analyze = Analyze.YES)
	@Analyzer(definition = "customanalyzer")
	private long minSalary;

	@Column(name = "maximum_salary")
	@Field(index = Index.YES, store = Store.NO, analyze = Analyze.YES)
	@Analyzer(definition = "customanalyzer")
	private long maxSalary;
	
	@ElementCollection
	@CollectionTable(name = "sme_vacancy_join_required_documents", joinColumns = @JoinColumn(name = "sme_vacancy_id"))
	@Column(name = "requiredDocuments")
	private List<String> requiredDocuments;
	
	@ElementCollection
	@CollectionTable(name = "sme_vacancy_join_job_types", joinColumns = @JoinColumn(name = "sme_vacancy_id"))
	@Column(name = "jobType")
	private List<String> jobTypes;

	@ElementCollection
	@CollectionTable(name = "sme_vacancy_join_employment_types", joinColumns = @JoinColumn(name = "sme_vacancy_id"))
	@Column(name = "employmentType")
	private List<String> employmentTypes;

	@ElementCollection
	@CollectionTable(name = "sme_vacancy_join_skill_sets", joinColumns = @JoinColumn(name = "sme_vacancy_id"))
	@Column(name = "skill_set")
	private List<String> skillSets;

	@Enumerated(EnumType.STRING)
	private PreferredShift preferredShift;

	@ElementCollection
	@CollectionTable(name = "sme_vacancy_join_locations", joinColumns = @JoinColumn(name = "sme_vacancy_id"))
	@Column(name = "location")
	@Field(analyze = Analyze.NO)
	@IndexedEmbedded
	@Facet
	private List<String> locations;
	
	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name = "sme_vacancies_join_qualification_course", joinColumns = @JoinColumn(name = "sme_vacancy_id"), inverseJoinColumns = @JoinColumn(name = "course_id"))
	@Fetch(value = FetchMode.SUBSELECT)
	private List<Course> qualificationCourses;

	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name = "sme_vacancies_join_qualifications", joinColumns = @JoinColumn(name = "sme_vacancy_id"), inverseJoinColumns = @JoinColumn(name = "specialization_id"))
	private List<Specialization> qualificationSpecializations;

	@Column(name = "no_of_vacancy")
	private int noOfVacancy;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "job_role_id")
	@IndexedEmbedded
	private IndustrialJobRole jobRole;

	@Column(name = "last_apply_date")
	private Date lastApplyDate;

	@Column(name = "is_vacancy_active")
	@Field(analyze = Analyze.NO)
	private boolean vacancyActive;
	
	@Transient
	private boolean applied;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "vacancy_detail_id")
	private VacancyDetail vacancyDetail;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY,mappedBy = "vacancy")
	private List<VacancyApplicant> applicants;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "Other_Category_ID")
	private VacancyOtherCategory otherCategory;
		
	
	public List<String> getRequiredDocuments() {
		return requiredDocuments;
	}

	public void setRequiredDocuments(List<String> requiredDocuments) {
		this.requiredDocuments = requiredDocuments;
	}

	public String getVacancyUrl() {
		return vacancyUrl;
	}

	public void setVacancyUrl(String vacancyUrl) {
		this.vacancyUrl = vacancyUrl;
	}

	public boolean isVacancyModified() {
		return vacancyModified;
	}

	public void setVacancyModified(boolean vacancyModified) {
		this.vacancyModified = vacancyModified;
	}

	public boolean isBusinessPostAlreadyActivated() {
		return businessPostAlreadyActivated;
	}

	public void setBusinessPostAlreadyActivated(boolean businessPostAlreadyActivated) {
		this.businessPostAlreadyActivated = businessPostAlreadyActivated;
	}

	public Long getVacancyId() {
		return vacancyId;
	}

	public List<String> getJobTypes() {
		return jobTypes;
	}

	public void setJobTypes(List<String> jobTypes) {
		this.jobTypes = jobTypes;
	}

	public List<String> getEmploymentTypes() {
		return employmentTypes;
	}

	public void setEmploymentTypes(List<String> employmentTypes) {
		this.employmentTypes = employmentTypes;
	}

	public List<Course> getQualificationCourses() {
		return qualificationCourses;
	}

	public void setQualificationCourses(List<Course> qualificationCourses) {
		this.qualificationCourses = qualificationCourses;
	}

	public List<String> getSkillSets() {
		return skillSets;
	}

	public void setSkillSets(List<String> skillSets) {
		this.skillSets = skillSets;
	}

	public PreferredShift getPreferredShift() {
		return preferredShift;
	}

	public void setPreferredShift(PreferredShift preferredShift) {
		this.preferredShift = preferredShift;
	}

	public List<String> getLocations() {
		return locations;
	}

	public void setLocations(List<String> locations) {
		this.locations = locations;
	}

	public List<Specialization> getQualificationSpecializations() {
		return qualificationSpecializations;
	}

	public void setQualificationSpecializations(List<Specialization> qualificationSpecializations) {
		this.qualificationSpecializations = qualificationSpecializations;
	}

	public IndustrialJobRole getJobRole() {
		return jobRole;
	}

	public void setJobRole(IndustrialJobRole jobRole) {
		this.jobRole = jobRole;
	}

	public void setVacancyId(Long vacancyId) {
		this.vacancyId = vacancyId;
	}

	public VacancyState getVacancyState() {
		return vacancyState;
	}

	public void setVacancyState(VacancyState vacancyState) {
		this.vacancyState = vacancyState;
	}

	public String getSmeUuid() {
		return smeUuid;
	}

	public void setSmeUuid(String smeUuid) {
		this.smeUuid = smeUuid;
	}

	public String getVacancyUuid() {
		return vacancyUuid;
	}

	public void setVacancyUuid(String vacancyUuid) {
		this.vacancyUuid = vacancyUuid;
	}

	public String getVacancyTitle() {
		return vacancyTitle;
	}

	public void setVacancyTitle(String vacancyTitle) {
		this.vacancyTitle = vacancyTitle;
	}

	public double getMinExp() {
		return minExp;
	}

	public void setMinExp(double minExp) {
		this.minExp = minExp;
	}

	public double getMaxExp() {
		return maxExp;
	}

	public void setMaxExp(double maxExp) {
		this.maxExp = maxExp;
	}

	public long getMinSalary() {
		return minSalary;
	}

	public void setMinSalary(long minSalary) {
		this.minSalary = minSalary;
	}

	public long getMaxSalary() {
		return maxSalary;
	}

	public void setMaxSalary(long maxSalary) {
		this.maxSalary = maxSalary;
	}

	public int getNoOfVacancy() {
		return noOfVacancy;
	}

	public void setNoOfVacancy(int noOfVacancy) {
		this.noOfVacancy = noOfVacancy;
	}

	public Date getLastApplyDate() {
		return lastApplyDate;
	}

	public void setLastApplyDate(Date lastApplyDate) {
		this.lastApplyDate = lastApplyDate;
	}

	public boolean isVacancyActive() {
		return vacancyActive;
	}

	public void setVacancyActive(boolean vacancyActive) {
		this.vacancyActive = vacancyActive;
	}
	
	public List<VacancyApplicant> getApplicants() {
		return applicants;
	}

	public void setApplicants(List<VacancyApplicant> applicants) {
		this.applicants = applicants;
	}

	public String getShortDescription() {
		return shortDescription;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	public VacancyDetail getVacancyDetail() {
		return vacancyDetail;
	}

	public void setVacancyDetail(VacancyDetail vacancyDetail) {
		this.vacancyDetail = vacancyDetail;
	}

	public boolean isBusinessPost() {
		return businessPost;
	}

	public void setBusinessPost(boolean businessPost) {
		this.businessPost = businessPost;
	}

	public String getFeedbackMessage() {
		return feedbackMessage;
	}

	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}

	@Override
	public String toString() {
		return "SMEVacancy [smeUuid=" + smeUuid + ", vacancyUuid=" + vacancyUuid + ", vacancyTitle=" + vacancyTitle
				+ ", shortDescription=" + shortDescription + ", locations=" + locations + "]";
	}

	public VacancyOtherCategory getOtherCategory() {
		return otherCategory;
	}

	public void setOtherCategory(VacancyOtherCategory otherCategory) {
		this.otherCategory = otherCategory;
	}

	public boolean isApplied() {
		return applied;
	}

	public void setApplied(boolean applied) {
		this.applied = applied;
	}
	
	
	
}
