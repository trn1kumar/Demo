package com.gloqr.entities.jobseekers;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gloqr.audit.Auditable;

@Entity
@Table(name = "job_seeker_resume")
public class JobSeekerResume extends Auditable<String> {

	@Id
	@Column(name = "resumeId")
	@JsonIgnore
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long resumeId;
	
	
	@Column(name = "resumeUrl")
	private String resumeUrl;
	
	@Column(name = "resumeFileName")
	private String resumeFileName;

	public Long getResumeId() {
		return resumeId;
	}

	public void setResumeId(Long resumeId) {
		this.resumeId = resumeId;
	}

	public String getResumeUrl() {
		return resumeUrl;
	}

	public void setResumeUrl(String resumeUrl) {
		this.resumeUrl = resumeUrl;
	}

	public String getResumeFileName() {
		return resumeFileName;
	}

	public void setResumeFileName(String resumeFileName) {
		this.resumeFileName = resumeFileName;
	}
	
}
