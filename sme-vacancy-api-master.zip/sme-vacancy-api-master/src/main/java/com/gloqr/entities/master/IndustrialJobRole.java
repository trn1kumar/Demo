package com.gloqr.entities.master;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Facet;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Store;

@Entity
@Table(name = "industrial_job_role")
public class IndustrialJobRole {

	@Id
	@Column(name = "jobRoleUuid", updatable = false, unique = true)
	private String jobRoleUuid;

	@Column(name = "jobRole")
	@Field(index = Index.YES, store = Store.NO, analyze = Analyze.NO)
	@Facet
	private String jobRole;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "area_id")
	private IndustrialArea industrialArea;

	public IndustrialArea getIndustrialArea() {
		return industrialArea;
	}

	public void setIndustrialArea(IndustrialArea industrialArea) {
		this.industrialArea = industrialArea;
	}

	public String getJobRoleUuid() {
		return jobRoleUuid;
	}

	public String getJobRole() {
		return jobRole;
	}

	public void setJobRoleUuid(String jobRoleUuid) {
		this.jobRoleUuid = jobRoleUuid;
	}

	public void setJobRole(String jobRole) {
		this.jobRole = jobRole;
	}

}
