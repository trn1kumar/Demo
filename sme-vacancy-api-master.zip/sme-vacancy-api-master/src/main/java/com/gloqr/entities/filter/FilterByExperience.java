package com.gloqr.entities.filter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "SmeVacancyFilterByExperience")
public class FilterByExperience  {

	@Id
	@GeneratedValue
	@Column(name = "filterByExperienceId")
	@JsonIgnore
	private Long filterByExperienceId;
	@JsonIgnore
	@Column(name = "filterByExperienceUuId", updatable = false, unique = true, nullable = false)
	private String filterByExperienceUuId;

	@Column(name = "minExperience")
	private double minExp;

	@Column(name = "maxExperience")
	private double maxExp;

	@Column(name = "formattedExperience")
	private String formattedExperience;
	@Transient
	private boolean selected;
	@Transient
	private int totalVacancies;

	public FilterByExperience() {
		super();
	}

	public FilterByExperience(String filterByExperienceUuId, double minExp, double maxExp, String formattedExperience) {
		super();
		this.filterByExperienceUuId = filterByExperienceUuId;
		this.minExp = minExp;
		this.maxExp = maxExp;
		this.formattedExperience = formattedExperience;
	}

	public String getFormattedExperience() {
		return formattedExperience;
	}

	public void setFormattedExperience(String formattedExperience) {
		this.formattedExperience = formattedExperience;
	}

	public double getMinExp() {
		return minExp;
	}

	public double getMaxExp() {
		return maxExp;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setMinExp(double minExp) {
		this.minExp = minExp;
	}

	public void setMaxExp(double maxExp) {
		this.maxExp = maxExp;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public int getTotalVacancies() {
		return totalVacancies;
	}

	public void setTotalVacancies(int totalVacancies) {
		this.totalVacancies = totalVacancies;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((filterByExperienceId == null) ? 0 : filterByExperienceId.hashCode());
		result = prime * result + ((filterByExperienceUuId == null) ? 0 : filterByExperienceUuId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FilterByExperience other = (FilterByExperience) obj;
		if (filterByExperienceId == null) {
			if (other.filterByExperienceId != null)
				return false;
		} else if (!filterByExperienceId.equals(other.filterByExperienceId)) {
			return false;
		}
		if (filterByExperienceUuId == null) {
			if (other.filterByExperienceUuId != null)
				return false;
		} else if (!filterByExperienceUuId.equals(other.filterByExperienceUuId)) {
			return false;
		}
		return true;
	}


}
