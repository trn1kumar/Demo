package com.gloqr.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "sme_vacancy_shortlist_info")
public class ShortListedInfo {

	@Id
	@Column(name = "short_list_info_id")
	@GeneratedValue
	private Long shortListInfoId;

	private Date interviewDate;

	private String description;

	public Long getShortListInfoId() {
		return shortListInfoId;
	}

	public void setShortListInfoId(Long shortListInfoId) {
		this.shortListInfoId = shortListInfoId;
	}

	public Date getInterviewDate() {
		return interviewDate;
	}

	public void setInterviewDate(Date interviewDate) {
		this.interviewDate = interviewDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
