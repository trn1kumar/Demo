package com.gloqr.entities.master;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "IndustrialArea")
public class IndustrialArea {

	@Id
	@Column(name = "areaUuid", updatable = false, unique = true)
	@GeneratedValue
	private String areaUuid;

	@Column(name = "industrialAreaName")
	private String industrialAreaName;

	@OneToMany(mappedBy = "industrialArea",cascade = CascadeType.ALL)
	private List<IndustrialJobRole> jobRoles;

	public String getAreaUuid() {
		return areaUuid;
	}

	public String getIndustrialAreaName() {
		return industrialAreaName;
	}

	public List<IndustrialJobRole> getJobRoles() {
		return jobRoles;
	}

	public void setAreaUuid(String areaUuid) {
		this.areaUuid = areaUuid;
	}

	public void setIndustrialAreaName(String industrialAreaName) {
		this.industrialAreaName = industrialAreaName;
	}

	public void setJobRoles(List<IndustrialJobRole> jobRoles) {
		this.jobRoles = jobRoles;
	}

}
