package com.gloqr.entities.filter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "SmeVacancyFilterBySalary")
public class FilterBySalary  {

	@Id
	@GeneratedValue
	@Column(name = "filterSalaryId")
	@JsonIgnore
	private Long filterSalaryId;
	@JsonIgnore
	@Column(name = "filterSalaryUuId", updatable = false, unique = true, nullable = false)
	private String filterSalaryUuId;
	@Column(name = "minSalary")
	private long minSalary;
	@Column(name = "maxSalary")
	private long maxSalary;
	@Column(name = "formattedSalary")
	private String formattedSalary;

	@Transient
	private boolean selected;

	@Transient
	private int totalVacancies;

	public FilterBySalary() {
		super();
	}

	public FilterBySalary(String filterSalaryUuId, long minSalary, long maxSalary, String formattedSalary) {
		super();

		this.filterSalaryUuId = filterSalaryUuId;
		this.minSalary = minSalary;
		this.maxSalary = maxSalary;
		this.formattedSalary = formattedSalary;
	}

	public long getMinSalary() {
		return minSalary;
	}

	public long getMaxSalary() {
		return maxSalary;
	}

	public String getFormattedSalary() {
		return formattedSalary;
	}

	public void setMinSalary(long minSalary) {
		this.minSalary = minSalary;
	}

	public void setMaxSalary(long maxSalary) {
		this.maxSalary = maxSalary;
	}

	public void setFormattedSalary(String formattedSalary) {
		this.formattedSalary = formattedSalary;
	}

	public String getFilterSalaryUuId() {
		return filterSalaryUuId;
	}

	public void setFilterSalaryUuId(String filterSalaryUuId) {
		this.filterSalaryUuId = filterSalaryUuId;
	}

	public Long getFilterSalaryId() {
		return filterSalaryId;
	}

	public void setFilterSalaryId(Long filterSalaryId) {
		this.filterSalaryId = filterSalaryId;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public int getTotalVacancies() {
		return totalVacancies;
	}

	public void setTotalVacancies(int totalVacancies) {
		this.totalVacancies = totalVacancies;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((filterSalaryId == null) ? 0 : filterSalaryId.hashCode());
		result = prime * result + ((filterSalaryUuId == null) ? 0 : filterSalaryUuId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FilterBySalary other = (FilterBySalary) obj;
		if (filterSalaryId == null) {
			if (other.filterSalaryId != null)
				return false;
		} else if (!filterSalaryId.equals(other.filterSalaryId)) {
			return false;
		}
		if (filterSalaryUuId == null) {
			if (other.filterSalaryUuId != null)
				return false;
		} else if (!filterSalaryUuId.equals(other.filterSalaryUuId)) {
			return false;
		}
		return true;
	}


}
