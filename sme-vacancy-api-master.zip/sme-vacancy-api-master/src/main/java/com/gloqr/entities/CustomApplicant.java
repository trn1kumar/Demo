package com.gloqr.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "sme_vacancy_custom_applicants")
public class CustomApplicant {

	@Id
	@Column(name = "custom_applicant_id")
	private String customApplicantId;

	@Column(name = "ref_sme_id")
	private String refSmeId;

	@Column(name = "full_name")
	private String fullName;

	@Column(name = "contact_number")
	private String contactNumber;

	@Column(name = "email_id")
	private String emailId;

	@Column(name = "resume_url")
	private String resumeUrl;

	@Column(name = "resume_file_name")
	private String resumeFileName;
	
	public String getResumeFileName() {
		return resumeFileName;
	}

	public void setResumeFileName(String resumeFileName) {
		this.resumeFileName = resumeFileName;
	}

	public String getCustomApplicantId() {
		return customApplicantId;
	}

	public void setCustomApplicantId(String customApplicantId) {
		this.customApplicantId = customApplicantId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getResumeUrl() {
		return resumeUrl;
	}

	public void setResumeUrl(String resumeUrl) {
		this.resumeUrl = resumeUrl;
	}

	public String getRefSmeId() {
		return refSmeId;
	}

	public void setRefSmeId(String refSmeId) {
		this.refSmeId = refSmeId;
	}

}
