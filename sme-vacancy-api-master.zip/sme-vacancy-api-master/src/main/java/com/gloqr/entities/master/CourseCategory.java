package com.gloqr.entities.master;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "course_category")
public class CourseCategory {

	@Id
	@Column(name = "course_category_id")
	private String courseCategoryId;

	@Column(name = "course_category_name")
	private String courseCategoryName;

	@OneToMany(mappedBy = "courseCategory", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<Course> courses;

	public String getCourseCategoryName() {
		return courseCategoryName;
	}

	public List<Course> getCourses() {
		return courses;
	}

	public String getCourseCategoryId() {
		return courseCategoryId;
	}

	public void setCourseCategoryId(String courseCategoryId) {
		this.courseCategoryId = courseCategoryId;
	}

	public void setCourseCategoryName(String courseCategoryName) {
		this.courseCategoryName = courseCategoryName;
	}

	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}

}
