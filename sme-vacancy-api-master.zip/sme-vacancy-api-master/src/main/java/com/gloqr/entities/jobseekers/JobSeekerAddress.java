package com.gloqr.entities.jobseekers;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "job_seeker_address")
public class JobSeekerAddress {
	
	@Id
	@Column(name = "jobSeekerAddressId")
	@JsonIgnore
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long jobSeekerAddressId;
	
	private String currentCity;

	private String currentState;

	private String currentCountry;


	public Long getJobSeekerAddressId() {
		return jobSeekerAddressId;
	}

	public void setJobSeekerAddressId(Long jobSeekerAddressId) {
		this.jobSeekerAddressId = jobSeekerAddressId;
	}

	public String getCurrentCity() {
		return currentCity;
	}

	public void setCurrentCity(String currentCity) {
		this.currentCity = currentCity;
	}

	public String getCurrentState() {
		return currentState;
	}

	public void setCurrentState(String currentState) {
		this.currentState = currentState;
	}

	public String getCurrentCountry() {
		return currentCountry;
	}

	public void setCurrentCountry(String currentCountry) {
		this.currentCountry = currentCountry;
	}
	
	
}
