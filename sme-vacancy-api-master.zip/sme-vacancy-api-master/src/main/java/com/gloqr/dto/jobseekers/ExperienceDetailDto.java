package com.gloqr.dto.jobseekers;

import java.util.Date;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.gloqr.dto.master.IndustrialJobRoleDto;

public class ExperienceDetailDto {

	private String experienceDetailUuid;

	@NotBlank(message = "Company name can not blank")
	@Size(max=200,message="Company Name is greater than 200 words")
	private String companyName;

	@Size(max=500,message="Job Description is greater than 500 words")
	private String description;

	private Date startDate;

	private Date endDate;

	private boolean currentlyWorking;

	@Valid
	private IndustrialJobRoleDto jobRole;

	private String noticePeriod;

	public String getNoticePeriod() {
		return noticePeriod;
	}

	public void setNoticePeriod(String noticePeriod) {
		this.noticePeriod = noticePeriod;
	}

	public String getCompanyName() {
		return companyName;
	}

	public String getDescription() {
		return description;
	}

	public Date getStartDate() {
		return startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public boolean isCurrentlyWorking() {
		return currentlyWorking;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public void setCurrentlyWorking(boolean currentlyWorking) {
		this.currentlyWorking = currentlyWorking;
	}

	public IndustrialJobRoleDto getJobRole() {
		return jobRole;
	}

	public void setJobRole(IndustrialJobRoleDto jobRole) {
		this.jobRole = jobRole;
	}

	public String getExperienceDetailUuid() {
		return experienceDetailUuid;
	}

	public void setExperienceDetailUuid(String experienceDetailUuid) {
		this.experienceDetailUuid = experienceDetailUuid;
	}

}
