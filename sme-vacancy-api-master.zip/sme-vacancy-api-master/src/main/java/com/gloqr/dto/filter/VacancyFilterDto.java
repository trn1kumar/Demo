package com.gloqr.dto.filter;

import java.util.Map;

public class VacancyFilterDto {

	private Map<String, Object> filters;

	public VacancyFilterDto(Map<String, Object> filters) {
		this.filters = filters;
	}

	public Map<String, Object> getFilters() {
		return filters;
	}

}
