package com.gloqr.dto.jobseekers;

public class SkillSetDto {

	private String skillSetUuid;

	private String skillSetName;

	public String getSkillSetUuid() {
		return skillSetUuid;
	}

	public String getSkillSetName() {
		return skillSetName;
	}

	public void setSkillSetUuid(String skillSetUuid) {
		this.skillSetUuid = skillSetUuid;
	}

	public void setSkillSetName(String skillSetName) {
		this.skillSetName = skillSetName;
	}

}
