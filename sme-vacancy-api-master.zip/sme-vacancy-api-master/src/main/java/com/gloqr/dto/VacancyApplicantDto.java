package com.gloqr.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.gloqr.dto.jobseekers.JobSeekerProfileDto;

@JsonInclude(Include.NON_DEFAULT)
public class VacancyApplicantDto {

	private String applicantUuid;

	private JobSeekerProfileDto applicant;

	private CustomApplicantDto customApplicant;
	
	private ShortListedInfoDto shortListedInfo;

	private Date applyDate;

	private boolean shortListed;
	
	public String getApplicantUuid() {
		return applicantUuid;
	}

	public void setApplicantUuid(String applicantUuid) {
		this.applicantUuid = applicantUuid;
	}

	public Date getApplyDate() {
		return applyDate;
	}

	public JobSeekerProfileDto getApplicant() {
		return applicant;
	}

	public void setApplicant(JobSeekerProfileDto applicant) {
		this.applicant = applicant;
	}

	public void setApplyDate(Date applyDate) {
		this.applyDate = applyDate;
	}

	public CustomApplicantDto getCustomApplicant() {
		return customApplicant;
	}

	public void setCustomApplicant(CustomApplicantDto customApplicant) {
		this.customApplicant = customApplicant;
	}

	public ShortListedInfoDto getShortListedInfo() {
		return shortListedInfo;
	}

	public void setShortListedInfo(ShortListedInfoDto shortListedInfo) {
		this.shortListedInfo = shortListedInfo;
	}

	public boolean isShortListed() {
		return shortListed;
	}

	public void setShortListed(boolean shortListed) {
		this.shortListed = shortListed;
	}

}
