package com.gloqr.dto.jobseekers;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class BasicJobSeekerProfileDto {

	@JsonIgnore
	private String jobSeekerProfileId;

	private String jobSeekerProfileUuid;

	@NotBlank
	@Size(max=100,message="Max 100 Characters allowed")
	@Pattern(regexp="[a-zA-Z ]*$",message="Only Alphabets are allowed")
	private String fullName;

	@Email(message="You Can Use Letters, Numbers & Periods[ i.e. . _ ]")
	private String emailId;

	@Size(max=10,message="Invalid Mobile Number")
	@Pattern(regexp="[0-9]+",message="Alphabets and Special Symbols not Allowed")
	private String mobileNumber;

	public String getJobSeekerProfileId() {
		return jobSeekerProfileId;
	}

	public void setJobSeekerProfileId(String jobSeekerProfileId) {
		this.jobSeekerProfileId = jobSeekerProfileId;
	}

	public String getJobSeekerProfileUuid() {
		return jobSeekerProfileUuid;
	}

	public void setJobSeekerProfileUuid(String jobSeekerProfileUuid) {
		this.jobSeekerProfileUuid = jobSeekerProfileUuid;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	
}
