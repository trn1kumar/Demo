package com.gloqr.dto.master;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class IndustrialAreaDto {

	private String areaUuid;

	private String industrialAreaName;

	public String getAreaUuid() {
		return areaUuid;
	}

	public String getIndustrialAreaName() {
		return industrialAreaName;
	}

	public void setAreaUuid(String areaUuid) {
		this.areaUuid = areaUuid;
	}

	public void setIndustrialAreaName(String industrialAreaName) {
		this.industrialAreaName = industrialAreaName;
	}

}
