package com.gloqr.dto.jobseekers;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.gloqr.dto.master.CourseDto;
import com.gloqr.dto.master.SpecializationDto;

public class EducationalDetailDto {

	private String educationalDetailUuid;

	@Valid
	private CourseDto qualificationCourse;

	@Valid
	private SpecializationDto qualificationSpecialization;
	
	@NotBlank(message = "University Name can not left null or empty")
	@Size(max=150,message="Max 150 Characters allowed")
	private String universityName;

	@NotBlank(message = "Institute Name can not left null or empty")
	@Size(max=150,message="Max 150 Characters allowed")
	private String instituteName;

	private int passingOutYear;

	@Min(1)
	@Max(100)
	private double percentage;

	public String getInstituteName() {
		return instituteName;
	}

	public int getPassingOutYear() {
		return passingOutYear;
	}

	public CourseDto getQualificationCourse() {
		return qualificationCourse;
	}

	public void setQualificationCourse(CourseDto qualificationCourse) {
		this.qualificationCourse = qualificationCourse;
	}

	public double getPercentage() {
		return percentage;
	}
	
	public String getUniversityName() {
		return universityName;
	}

	public void setUniversityName(String universityName) {
		this.universityName = universityName;
	}
	
	public void setInstituteName(String instituteName) {
		this.instituteName = instituteName;
	}

	public void setPassingOutYear(int passingOutYear) {
		this.passingOutYear = passingOutYear;
	}

	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}

	public String getEducationalDetailUuid() {
		return educationalDetailUuid;
	}

	public void setEducationalDetailUuid(String educationalDetailUuid) {
		this.educationalDetailUuid = educationalDetailUuid;
	}

	public SpecializationDto getQualificationSpecialization() {
		return qualificationSpecialization;
	}

	public void setQualificationSpecialization(SpecializationDto qualificationSpecialization) {
		this.qualificationSpecialization = qualificationSpecialization;
	}

}
