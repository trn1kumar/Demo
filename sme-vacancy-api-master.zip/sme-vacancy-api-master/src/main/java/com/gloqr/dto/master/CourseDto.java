package com.gloqr.dto.master;

import java.util.List;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class CourseDto {

	@NotBlank(message = "courseId can not be null or empty")
	private String courseId;

	private String courseName;

	private List<SpecializationDto> specializations;

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getCourseId() {
		return courseId;
	}

	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}

	public List<SpecializationDto> getSpecializations() {
		return specializations;
	}

	public void setSpecializations(List<SpecializationDto> specializations) {
		this.specializations = specializations;
	}

}
