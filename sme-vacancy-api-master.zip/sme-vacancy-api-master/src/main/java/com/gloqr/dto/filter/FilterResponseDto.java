package com.gloqr.dto.filter;

import java.util.List;
import java.util.Map;

import com.gloqr.vo.VacancyVo;

public class FilterResponseDto extends VacancyFilterDto {

	private List<VacancyVo> results;
	private int totalVacanciesCount;

	public FilterResponseDto(Map<String, Object> filters, List<VacancyVo> results, int totalVacanciesCount) {
		super(filters);
		this.results = results;
		this.totalVacanciesCount = totalVacanciesCount;
	}

	public int getTotalVacanciesCount() {
		return totalVacanciesCount;
	}

	public void setTotalVacanciesCount(int totalVacanciesCount) {
		this.totalVacanciesCount = totalVacanciesCount;
	}

	public List<VacancyVo> getResults() {
		return results;
	}

	public void setResults(List<VacancyVo> results) {
		this.results = results;
	}
}
