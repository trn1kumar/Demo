package com.gloqr.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class VacancyDetailDto {


	private String vdUuId;

	@Size(min=10,max=1000,message="{size.longDescription}")
	private String longDescription;
	
	@Email(message="{email.contactEmail}")
	private String contactEmail;
	
	@Pattern(regexp="^[0-9]+$",message="{pattern.contactMobileNumber}")
	@Size(min=10,max=10,message= "{size.contactMobileNumber}")
	private String contactMobileNumber;

	public String getVdUuId() {
		return vdUuId;
	}

	public String getLongDescription() {
		return longDescription;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public String getContactMobileNumber() {
		return contactMobileNumber;
	}

	public void setVdUuId(String vdUuId) {
		this.vdUuId = vdUuId;
	}

	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public void setContactMobileNumber(String contactMobileNumber) {
		this.contactMobileNumber = contactMobileNumber;
	}
	
}
