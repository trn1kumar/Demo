package com.gloqr.dto.jobseekers;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.gloqr.constants.Gender;
import com.gloqr.entities.jobseekers.EmploymentSalary;
import com.gloqr.entities.jobseekers.Experience;
import com.gloqr.entities.jobseekers.JobSeekerResume;
@JsonInclude(Include.NON_DEFAULT)
public class JobSeekerProfileDto extends BasicJobSeekerProfileDto {

	
	private String currentOrganization;

	private String currentDesig;
	
	private String userProfileImg;

	private Gender gender;

	private Date dob;	
	
	private JobSeekerAddressDto jobSeekerAddress;
	
	@Valid
	@NotNull(message = "current salary can not null")
	private EmploymentSalary currentSalary;

	@Valid
	@NotNull(message = "total experience can not null")
	private Experience totalExperience;

	private JobSeekerResume resume;

	private EducationalDetailDto educationalDetail;

	private List<ExperienceDetailDto> experienceDetails;

	private CareerProfileDto careerProfile;

	private List<String> skillSets;


	public EmploymentSalary getCurrentSalary() {
		return currentSalary;
	}

	public void setCurrentSalary(EmploymentSalary currentSalary) {
		this.currentSalary = currentSalary;
	}

	public Date getDob() {
		return dob;
	}

	public EducationalDetailDto getEducationalDetail() {
		return educationalDetail;
	}

	public CareerProfileDto getCareerProfile() {
		return careerProfile;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public void setEducationalDetail(EducationalDetailDto educationalDetail) {
		this.educationalDetail = educationalDetail;
	}

	public void setCareerProfile(CareerProfileDto careerProfile) {
		this.careerProfile = careerProfile;
	}

	public List<String> getSkillSets() {
		return skillSets;
	}

	public void setSkillSets(List<String> skillSets) {
		this.skillSets = skillSets;
	}

	public Experience getTotalExperience() {
		return totalExperience;
	}

	public void setTotalExperience(Experience totalExperience) {
		this.totalExperience = totalExperience;
	}

	public List<ExperienceDetailDto> getExperienceDetails() {
		return experienceDetails;
	}

	public void setExperienceDetails(List<ExperienceDetailDto> experienceDetails) {
		this.experienceDetails = experienceDetails;
	}

	public String getCurrentOrganization() {
		return currentOrganization;
	}

	public void setCurrentOrganization(String currentOrganization) {
		this.currentOrganization = currentOrganization;
	}

	public String getCurrentDesig() {
		return currentDesig;
	}

	public void setCurrentDesig(String currentDesig) {
		this.currentDesig = currentDesig;
	}
	public JobSeekerResume getResume() {
		return resume;
	}

	public void setResume(JobSeekerResume resume) {
		this.resume = resume;
	}

	public JobSeekerAddressDto getJobSeekerAddress() {
		return jobSeekerAddress;
	}

	public void setJobSeekerAddress(JobSeekerAddressDto jobSeekerAddress) {
		this.jobSeekerAddress = jobSeekerAddress;
	}

	public String getUserProfileImg() {
		return userProfileImg;
	}

	public void setUserProfileImg(String userProfileImg) {
		this.userProfileImg = userProfileImg;
	}

	

	
}
