package com.gloqr.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class VacancyTypeDto {

	@NotNull(message="{notnull.jobTypeUuid}")
	@NotEmpty(message="{notempty.jobTypeUuid}")
	private String jobTypeUuid;

	private String jobType;

	public String getJobTypeUuid() {
		return jobTypeUuid;
	}

	public String getJobType() {
		return jobType;
	}

	public void setJobTypeUuid(String jobTypeUuid) {
		this.jobTypeUuid = jobTypeUuid;
	}

	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	
	
}
