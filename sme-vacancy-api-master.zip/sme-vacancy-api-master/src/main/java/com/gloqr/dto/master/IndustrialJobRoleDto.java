package com.gloqr.dto.master;

import javax.validation.constraints.NotBlank;

public class IndustrialJobRoleDto {

	@NotBlank(message = "job role id can not blank")
	private String jobRoleUuid;

	private String jobRole;

	private IndustrialAreaDto industrialArea;

	public String getJobRoleUuid() {
		return jobRoleUuid;
	}

	public String getJobRole() {
		return jobRole;
	}

	public void setJobRoleUuid(String jobRoleUuid) {
		this.jobRoleUuid = jobRoleUuid;
	}

	public void setJobRole(String jobRole) {
		this.jobRole = jobRole;
	}

	public IndustrialAreaDto getIndustrialArea() {
		return industrialArea;
	}

	public void setIndustrialArea(IndustrialAreaDto industrialArea) {
		this.industrialArea = industrialArea;
	}

}
