package com.gloqr.dto.jobseekers;

import java.util.List;

import javax.validation.Valid;
import com.gloqr.constants.PreferredShift;
import com.gloqr.dto.master.IndustrialJobRoleDto;
import com.gloqr.entities.jobseekers.EmploymentSalary;

public class CareerProfileDto {

	private String careerProfileDetailUuid;

	private List<String> jobTypes;

	private List<String> employmentTypes;

	private PreferredShift preferredShift;

	@Valid
	private EmploymentSalary expectedSalary;

	private IndustrialJobRoleDto jobRole;

	private List<String> prefferedJobLocations;

	public String getCareerProfileDetailUuid() {
		return careerProfileDetailUuid;
	}

	public PreferredShift getPreferredShift() {
		return preferredShift;
	}

	public void setCareerProfileDetailUuid(String careerProfileDetailUuid) {
		this.careerProfileDetailUuid = careerProfileDetailUuid;
	}

	public void setPreferredShift(PreferredShift preferredShift) {
		this.preferredShift = preferredShift;
	}

	public IndustrialJobRoleDto getJobRole() {
		return jobRole;
	}

	public void setJobRole(IndustrialJobRoleDto jobRole) {
		this.jobRole = jobRole;
	}

	public List<String> getPrefferedJobLocations() {
		return prefferedJobLocations;
	}

	public void setPrefferedJobLocations(List<String> prefferedJobLocations) {
		this.prefferedJobLocations = prefferedJobLocations;
	}

	public List<String> getJobTypes() {
		return jobTypes;
	}

	public List<String> getEmploymentTypes() {
		return employmentTypes;
	}

	public void setJobTypes(List<String> jobTypes) {
		this.jobTypes = jobTypes;
	}

	public void setEmploymentTypes(List<String> employmentTypes) {
		this.employmentTypes = employmentTypes;
	}

	public EmploymentSalary getExpectedSalary() {
		return expectedSalary;
	}

	public void setExpectedSalary(EmploymentSalary expectedSalary) {
		this.expectedSalary = expectedSalary;
	}

}
