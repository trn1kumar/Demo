package com.gloqr.dto.jobseekers;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class JobSeekerResumeDto {

	@JsonIgnore
	private String resumeId;

	private String resumeUrl;
	
	private String resumeFileName;

	public String getResumeId() {
		return resumeId;
	}

	public void setResumeId(String resumeId) {
		this.resumeId = resumeId;
	}

	public String getResumeUrl() {
		return resumeUrl;
	}

	public void setResumeUrl(String resumeUrl) {
		this.resumeUrl = resumeUrl;
	}

	public String getResumeFileName() {
		return resumeFileName;
	}

	public void setResumeFileName(String resumeFileName) {
		this.resumeFileName = resumeFileName;
	}

}
