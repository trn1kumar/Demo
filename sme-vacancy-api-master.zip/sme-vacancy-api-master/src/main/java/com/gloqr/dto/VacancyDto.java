package com.gloqr.dto;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.gloqr.audit.DateAuditable;
import com.gloqr.constants.PreferredShift;
import com.gloqr.constants.VacancyState;
import com.gloqr.dto.master.CourseDto;
import com.gloqr.dto.master.IndustrialJobRoleDto;
import com.gloqr.dto.master.SpecializationDto;
import com.gloqr.entities.VacancyOtherCategory;

//@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class VacancyDto extends DateAuditable {

	private SMEDto smeInfo;

	private String smeUuid;

	private String vacancyUuid;

	@NotBlank(message = "{notblank.vacancyTitle}")
	@Size(min = 3, max = 100, message = "{size.vacancyTitle}")
	private String vacancyTitle;

	@NotBlank(message = "{notblank.shortDescription}")
	@Size(min = 3, max = 200, message = "{size.shortDescription}")
	private String shortDescription;

	private String feedbackMessage;

	private VacancyState vacancyState;

	private boolean businessPostAlreadyActivated;

	private boolean vacancyActive;

	private boolean vacancyModified;

	private boolean businessPost;

	@Min(value = 0, message = "{min.minExp}")
	@Max(value = 100, message = "{max.minExp}")
	private double minExp;

	@Min(value = 0, message = "{min.maxExp}")
	@Max(value = 100, message = "{max.maxExp}")
	private double maxExp;

	@Min(value = 0, message = "{min.minSalary}")
	private long minSalary;

	@Min(value = 0, message = "{min.maxSalary}")
	private long maxSalary;

	@Min(value = 0, message = "{min.noOfVacancy}")
	private int noOfVacancy;

	private Date lastApplyDate;

	private int totalApplicants;

	private IndustrialJobRoleDto jobRole;
	
	private boolean appiled;

	private List<CourseDto> qualificationCourses;
	
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private List<SpecializationDto> qualificationSpecializations;
	
	private List<String> requiredDocuments;

	private List<String> jobTypes;

	private List<String> employmentTypes;

	private PreferredShift preferredShift;

	private List<String> locations;

	/* @NotNull(message = "{notblank.keySkills}") */
	private List<String> skillSets;

	@Valid
	private VacancyDetailDto vacancyDetail;
	
	private VacancyOtherCategory otherCategory;

	public SMEDto getSmeInfo() {
		return smeInfo;
	}

	public void setSmeInfo(SMEDto smeInfo) {
		this.smeInfo = smeInfo;
	}

	public String getSmeUuid() {
		return smeUuid;
	}

	public void setSmeUuid(String smeUuid) {
		this.smeUuid = smeUuid;
	}

	public String getVacancyUuid() {
		return vacancyUuid;
	}

	public void setVacancyUuid(String vacancyUuid) {
		this.vacancyUuid = vacancyUuid;
	}

	public String getVacancyTitle() {
		return vacancyTitle;
	}

	public void setVacancyTitle(String vacancyTitle) {
		this.vacancyTitle = vacancyTitle;
	}

	public String getShortDescription() {
		return shortDescription;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	public String getFeedbackMessage() {
		return feedbackMessage;
	}

	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}

	public VacancyState getVacancyState() {
		return vacancyState;
	}

	public void setVacancyState(VacancyState vacancyState) {
		this.vacancyState = vacancyState;
	}

	public boolean isBusinessPostAlreadyActivated() {
		return businessPostAlreadyActivated;
	}

	public void setBusinessPostAlreadyActivated(boolean businessPostAlreadyActivated) {
		this.businessPostAlreadyActivated = businessPostAlreadyActivated;
	}

	public boolean isVacancyActive() {
		return vacancyActive;
	}

	public void setVacancyActive(boolean vacancyActive) {
		this.vacancyActive = vacancyActive;
	}

	public boolean isVacancyModified() {
		return vacancyModified;
	}

	public void setVacancyModified(boolean vacancyModified) {
		this.vacancyModified = vacancyModified;
	}

	public boolean isBusinessPost() {
		return businessPost;
	}

	public void setBusinessPost(boolean businessPost) {
		this.businessPost = businessPost;
	}

	public double getMinExp() {
		return minExp;
	}

	public void setMinExp(double minExp) {
		this.minExp = minExp;
	}

	public double getMaxExp() {
		return maxExp;
	}

	public void setMaxExp(double maxExp) {
		this.maxExp = maxExp;
	}

	public long getMinSalary() {
		return minSalary;
	}

	public void setMinSalary(long minSalary) {
		this.minSalary = minSalary;
	}

	public long getMaxSalary() {
		return maxSalary;
	}

	public void setMaxSalary(long maxSalary) {
		this.maxSalary = maxSalary;
	}

	public int getNoOfVacancy() {
		return noOfVacancy;
	}

	public void setNoOfVacancy(int noOfVacancy) {
		this.noOfVacancy = noOfVacancy;
	}

	public Date getLastApplyDate() {
		return lastApplyDate;
	}

	public void setLastApplyDate(Date lastApplyDate) {
		this.lastApplyDate = lastApplyDate;
	}

	public List<String> getRequiredDocuments() {
		return requiredDocuments;
	}

	public void setRequiredDocuments(List<String> requiredDocuments) {
		this.requiredDocuments = requiredDocuments;
	}

	public IndustrialJobRoleDto getJobRole() {
		return jobRole;
	}

	public void setJobRole(IndustrialJobRoleDto jobRole) {
		this.jobRole = jobRole;
	}

	public List<String> getJobTypes() {
		return jobTypes;
	}

	public void setJobTypes(List<String> jobTypes) {
		this.jobTypes = jobTypes;
	}

	public List<String> getEmploymentTypes() {
		return employmentTypes;
	}

	public void setEmploymentTypes(List<String> employmentTypes) {
		this.employmentTypes = employmentTypes;
	}

	public PreferredShift getPreferredShift() {
		return preferredShift;
	}

	public void setPreferredShift(PreferredShift preferredShift) {
		this.preferredShift = preferredShift;
	}

	public List<String> getLocations() {
		return locations;
	}

	public void setLocations(List<String> locations) {
		this.locations = locations;
	}

	public List<String> getSkillSets() {
		return skillSets;
	}

	public void setSkillSets(List<String> skillSets) {
		this.skillSets = skillSets;
	}

	public VacancyDetailDto getVacancyDetail() {
		return vacancyDetail;
	}

	public void setVacancyDetail(VacancyDetailDto vacancyDetail) {
		this.vacancyDetail = vacancyDetail;
	}

	public int getTotalApplicants() {
		return totalApplicants;
	}

	public void setTotalApplicants(int totalApplicants) {
		this.totalApplicants = totalApplicants;
	}

	public List<SpecializationDto> getQualificationSpecializations() {
		return qualificationSpecializations;
	}

	public void setQualificationSpecializations(List<SpecializationDto> qualificationSpecializations) {
		this.qualificationSpecializations = qualificationSpecializations;
	}

	public List<CourseDto> getQualificationCourses() {
		return qualificationCourses;
	}

	public void setQualificationCourses(List<CourseDto> qualificationCourses) {
		this.qualificationCourses = qualificationCourses;
	}

	public boolean isAppiled() {
		return appiled;
	}

	public void setAppiled(boolean appiled) {
		this.appiled = appiled;
	}

	public VacancyOtherCategory getOtherCategory() {
		return otherCategory;
	}

	public void setOtherCategory(VacancyOtherCategory otherCategory) {
		this.otherCategory = otherCategory;
	}
	
}
