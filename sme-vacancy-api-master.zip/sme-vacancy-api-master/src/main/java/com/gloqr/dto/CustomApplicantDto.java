package com.gloqr.dto;

public class CustomApplicantDto {

	private String customApplicantId;

	private String refSmeName;

	private String refSmeId;

	private String fullName;

	private String contactNumber;

	private String emailId;

	private String resumeUrl;

	private String resumeFileName;

	
	public String getCustomApplicantId() {
		return customApplicantId;
	}

	public void setCustomApplicantId(String customApplicantId) {
		this.customApplicantId = customApplicantId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getResumeUrl() {
		return resumeUrl;
	}

	public void setResumeUrl(String resumeUrl) {
		this.resumeUrl = resumeUrl;
	}

	public String getRefSmeId() {
		return refSmeId;
	}

	public void setRefSmeId(String refSmeId) {
		this.refSmeId = refSmeId;
	}

	public String getRefSmeName() {
		return refSmeName;
	}

	public void setRefSmeName(String refSmeName) {
		this.refSmeName = refSmeName;
	}

	public String getResumeFileName() {
		return resumeFileName;
	}

	public void setResumeFileName(String resumeFileName) {
		this.resumeFileName = resumeFileName;
	}

}
