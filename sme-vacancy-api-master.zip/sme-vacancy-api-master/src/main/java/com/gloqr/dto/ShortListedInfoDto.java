package com.gloqr.dto;

import java.util.Date;

public class ShortListedInfoDto {

	
	private Date interviewDate;
	
	private String description;


	public Date getInterviewDate() {
		return interviewDate;
	}

	public void setInterviewDate(Date interviewDate) {
		this.interviewDate = interviewDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
