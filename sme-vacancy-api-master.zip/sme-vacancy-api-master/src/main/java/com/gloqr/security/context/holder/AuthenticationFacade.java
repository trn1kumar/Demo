package com.gloqr.security.context.holder;

import org.springframework.security.core.Authentication;

public interface AuthenticationFacade {
	
	public Authentication getAuthentication();

	public String getJwtToken();
}
