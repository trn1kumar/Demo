package com.gloqr.mapper;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import com.gloqr.exception.CustomException;

@Component
public class VacancyMapper {

	public <T1, T> List<T> convertToEntities(List<T1> objs, Class<T> targetClass) {
		return convert(objs, targetClass);
	}

	public <T1, T> List<T> convertToDtos(List<T1> objs, Class<T> targetClass) {
		return convert(objs, targetClass);
	}

	public <T> T convertToEntity(Object srcObj, Class<T> targetClass) {
		return convert(srcObj, targetClass);
	}

	public <T> T convertToDto(Object srcObj, Class<T> targetClass) {
		return convert(srcObj, targetClass);
	}

	public <T> T convertToVo(Object srcObj, Class<T> targetClass) {
		return convert(srcObj, targetClass);
	}

	public <T1, T> List<T> convertToVos(List<T1> objs, Class<T> targetClass) {
		return convert(objs, targetClass);
	}

	private <T> T convert(Object srcObj, Class<T> targetClass) {
		T convertedObj = null;
		Assert.notNull(srcObj, "Source Obj can not be null for convertion");
		try {
			convertedObj = new ModelMapper().map(srcObj, targetClass);

		} catch (Exception e) {
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
		return convertedObj;
	}

	private <T1, T> List<T> convert(List<T1> objs, Class<T> targetClass) {
		List<T> entities = new ArrayList<>();

		Assert.notNull(objs, "Source Objs can not be null for convertion");
		try {
			objs.forEach(srcObj -> entities.add(new ModelMapper().map(srcObj, targetClass)));
		} catch (Exception e) {
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
		return entities;
	}

}
