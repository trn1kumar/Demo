package com.gloqr.repository.jobseekers;

import java.util.List;
import java.util.Optional;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gloqr.entities.jobseekers.ExperienceDetail;
import com.gloqr.entities.jobseekers.JobSeekerProfile;

public interface JobSeekerRepository extends JpaRepository<JobSeekerProfile, String> {

	public Optional<JobSeekerProfile> findByJobSeekerProfileIdAndJobSeekerProfileUuid(String seekerProfileId,
			String seekerProfileUuid);
	
	public Optional<JobSeekerProfile> findByJobSeekerProfileUuid(String jobSeekerProfileUuid);
	
	@Query("Select case when (count(e) > 0)  then true else false end  from JobSeekerProfile p JOIN p.educationalDetail e where p.jobSeekerProfileId=:jobSeekerId AND e.educationalDetailUuid=:educationalDetailUuid")
	public boolean isJobSeekerHasGivenEducationalDetail(@Param("jobSeekerId") String jobSeekerId,
			@Param("educationalDetailUuid") String educationalDetailUuid);

	@Query("Select case when (count(e) > 0)  then true else false end  from JobSeekerProfile p JOIN p.experienceDetails e where p.jobSeekerProfileId=:jobSeekerId AND e.experienceDetailUuid=:experienceDetailUuid")
	public boolean isJobSeekerHasGivenExperienceDetail(@Param("jobSeekerId") String jobSeekerId,
			@Param("experienceDetailUuid") String experienceDetailId);

	@Query("Select case when (count(cp) > 0)  then true else false end  from JobSeekerProfile p JOIN p.careerProfile cp where p.jobSeekerProfileId=:jobSeekerId AND cp.careerProfileDetailUuid=:careerProfileDetailUuid")
	public boolean isJobSeekerHasGivenCareerProfile(@Param("jobSeekerId") String jobSeekerId,
			@Param("careerProfileDetailUuid") String careerProfileId);

	@Query("Select e from JobSeekerProfile p JOIN p.experienceDetails e where p.jobSeekerProfileId=:jobSeekerId")
	public List<ExperienceDetail> getExperienceDetailsBySeekerId(@Param("jobSeekerId") String jobSeekerId);

	
}
