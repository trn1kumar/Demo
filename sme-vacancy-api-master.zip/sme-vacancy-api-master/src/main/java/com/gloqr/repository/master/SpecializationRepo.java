package com.gloqr.repository.master;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.entities.master.Specialization;

public interface SpecializationRepo extends JpaRepository<Specialization, String> {

	List<Specialization> findBySpecializationIdIn(Set<String> specsId);

}
