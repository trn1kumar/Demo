package com.gloqr.repository.jobseekers;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.entities.jobseekers.EmploymentSalary;

public interface EmploymentSalaryRepo extends JpaRepository<EmploymentSalary, String>{

}
