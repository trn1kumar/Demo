package com.gloqr.repository.jobseekers;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.entities.jobseekers.Experience;

public interface ExperienceRepo extends JpaRepository<Experience, String>{

}
