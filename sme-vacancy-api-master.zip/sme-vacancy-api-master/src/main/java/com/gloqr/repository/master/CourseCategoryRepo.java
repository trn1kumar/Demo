package com.gloqr.repository.master;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gloqr.entities.master.Course;
import com.gloqr.entities.master.CourseCategory;

public interface CourseCategoryRepo extends JpaRepository<CourseCategory, String> {

	@Query("select s from CourseCategory c JOIN c.courses s where c.courseCategoryId =:courseCategoryId")
	List<Course> findCoursesByCategoryId(@Param("courseCategoryId") String courseCategoryId);

}
