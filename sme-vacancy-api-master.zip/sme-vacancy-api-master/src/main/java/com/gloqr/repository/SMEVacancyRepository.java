package com.gloqr.repository;

import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gloqr.constants.VacancyState;
import com.gloqr.entities.Vacancy;
import com.gloqr.model.ItemCountUpdate;

public interface SMEVacancyRepository extends JpaRepository<Vacancy, Long> {

	List<Vacancy> findBySmeUuidAndVacancyActiveTrue(String sUuid, Sort by);

	List<Vacancy> findBySmeUuidAndVacancyActiveFalse(String sUuid, Sort by);

	List<Vacancy> findBySmeUuid(String sUuid, Sort sort);

	List<Vacancy> findByVacancyStateAndVacancyActiveTrue(VacancyState approved, Pageable pagable);

	List<Vacancy> findBySmeUuidAndVacancyStateAndVacancyActiveTrue(String smeId, VacancyState vacancyState, Sort sort);

	Vacancy findByVacancyUuidAndVacancyActiveAndVacancyState(String vacancyUuid, boolean status, VacancyState state);

	boolean existsByVacancyUuid(String vacancyUuid);

	public Vacancy findByVacancyUuid(String jobUuid);

	long countBySmeUuidAndVacancyActiveTrueAndVacancyState(String smeId, VacancyState state);

	Vacancy findByVacancyUuidAndSmeUuid(String vacancyUuid, String smeUuid);

	@Modifying
	@Transactional
	@Query("update Vacancy s set s.vacancyState=:vacancyState where s.vacancyUuid=:vacancyUuid")
	void updateVacancyState(@Param("vacancyUuid") String vacancyUuid, @Param("vacancyState") VacancyState vacancyState);

	@Modifying
	@Transactional
	@Query("update Vacancy s set s.businessPostAlreadyActivated=true where s.vacancyUuid=:vacancyUuid")
	void updateBusinessPostAlreadyActivatedTrue(@Param("vacancyUuid") String vacancyUuid);

	List<Vacancy> findBySmeUuidAndVacancyStateNotIn(String smeUuid, VacancyState state);

	void deleteByVacancyUuid(@Param("vacancyUuid") String vacancyUuid);

	@Transactional
	@Modifying
	@Query("update Vacancy s set s.vacancyActive=:status where s.vacancyUuid=:id")
	void updateStatus(@Param("id") String id, @Param("status") boolean status);

	@Query("select smeUuid from Vacancy v")
	public Set<String> getSmeUuid();

	@Query("select smeUuid from Vacancy v where v.vacancyActive=true And v.vacancyState=:state")
	public Set<String> getSmeUuidOfVacancyActiveTrueAndVacancyState(@Param("state") VacancyState state);

	@Query("select MAX (maxExp) from Vacancy v where v.vacancyActive=:status And v.vacancyState=:state")
	public Double getMaxExperience(@Param("status") boolean status, @Param("state") VacancyState state);

	@Query("select MIN (minExp) from Vacancy v where v.vacancyActive=:status And v.vacancyState=:state")
	public Double getMinExperience(@Param("status") boolean status, @Param("state") VacancyState state);

	@Query("select MIN (minSalary) from Vacancy v where v.vacancyActive=:status And v.vacancyState=:state")
	public Long getMinSalary(@Param("status") boolean status, @Param("state") VacancyState state);

	@Query("select MAX (maxSalary) from Vacancy v where v.vacancyActive=:status And v.vacancyState=:state")
	public Long getMaxSalary(@Param("status") boolean status, @Param("state") VacancyState state);

	@Query("select DISTINCT l from Vacancy v JOIN v.locations l where v.vacancyActive=:status And v.vacancyState=:state")
	public Set<String> getActiveAndApprovedVacanciesJobLocations(@Param("status") boolean status,
			@Param("state") VacancyState state);

	@Query("select r.jobRole from Vacancy v JOIN v.jobRole r where v.vacancyActive=:status And v.vacancyState=:state")
	public Set<String> getActiveAndApprovedVacanciesJobRoles(@Param("status") boolean status,
			@Param("state") VacancyState state);

	@Query("select MAX(creationDate) from Vacancy v where v.vacancyActive=:status")
	public Date getMaxCreationDate(@Param("status") boolean status);

	@Query("select MIN(creationDate) from Vacancy v where v.vacancyActive=:status")
	public Date getMinCreationDate(@Param("status") boolean status);

	@Query("select COUNT(*) from Vacancy v where v.minExp>=:minExp AND v.maxExp<=:maxExp AND v.vacancyActive=:status AND v.vacancyState=:state")
	int getActiveAndApprovedVacanciesCountByExperience(@Param("minExp") double minExp, @Param("maxExp") double maxExp,
			@Param("status") boolean b, @Param("state") VacancyState state);

	// sum of number of vacancies

	@Query("select SUM(v.noOfVacancy) from Vacancy v where v.smeUuid=:smeId AND v.vacancyActive= true AND v.vacancyState=:vacancyState")
	int sumOfTotalVacanciesBySmeUuidAndVacancyActiveTrueAndVacancyState(@Param("smeId") String smeId,
			@Param("vacancyState") VacancyState vacancyState);

	@Query("select SUM(v.noOfVacancy) from Vacancy v JOIN v.locations l where l=:location AND v.vacancyActive=:status And v.vacancyState=:state")
	int sumOfTotalVacanciesByLocationAndActiveAndState(@Param("location") String location,
			@Param("status") boolean status, @Param("state") VacancyState state);

	@Query("select SUM(v.noOfVacancy) from Vacancy v JOIN v.jobRole r where r.jobRole=:jobRole AND v.vacancyActive=:status And v.vacancyState=:state")
	int sumOfTotalVacanciesByJobRoleAndActiveAndState(@Param("jobRole") String jobRole, @Param("status") boolean status,
			@Param("state") VacancyState state);

	@Query("select SUM(v.noOfVacancy) from Vacancy v where v.minSalary>=:minSalary AND v.maxSalary<=:maxSalary AND v.vacancyActive=:status AND v.vacancyState=:state")
	Long sumOfTotalVacanciesBySalaryAndActiveAndState(@Param("minSalary") long minSalary,
			@Param("maxSalary") long maxSalary, @Param("status") boolean status, @Param("state") VacancyState state);

	@Query("select SUM(v.noOfVacancy) from Vacancy v where v.minExp>=:minExp AND v.maxExp<=:maxExp AND v.vacancyActive=:status AND v.vacancyState=:state")
	Long sumOfTotalVacanciesByExperienceAndActiveAndState(@Param("minExp") double minExp,
			@Param("maxExp") double maxExp, @Param("status") boolean b, @Param("state") VacancyState state);

	@Query("SELECT new com.gloqr.model.ItemCountUpdate(COUNT(v),COUNT(CASE WHEN v.vacancyActive=1 AND v.vacancyState='APPROVED' THEN 1 END) ,COUNT(CASE WHEN v.vacancyActive=1 AND v.vacancyState='PENDING' THEN 1 END)) FROM Vacancy v where v.smeUuid=:smeUuid")
	ItemCountUpdate getCounts(@Param("smeUuid") String smeUuid);

	@Query("select v.vacancyTitle,v.vacancyUrl,v.smeUuid from Vacancy v join v.applicants a where a.applicantId=:applicantId")
	String getVacancyTitleAndUrlAndSmeId(@Param("applicantId") Long applicantId);

}
