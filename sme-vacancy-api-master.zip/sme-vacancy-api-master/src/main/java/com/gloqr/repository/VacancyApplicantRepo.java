package com.gloqr.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gloqr.entities.VacancyApplicant;

@Repository
public interface VacancyApplicantRepo extends JpaRepository<VacancyApplicant, Long> {

	VacancyApplicant findByApplicantUuid(String applicantUuid);

}
