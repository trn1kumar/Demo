package com.gloqr.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.entities.filter.FilterBySalary;

public interface VacancyFilterBySalaryRepo extends JpaRepository<FilterBySalary, Long> {

}
