package com.gloqr.repository.jobseekers;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.entities.jobseekers.EducationalDetail;

public interface EducationalDetailRepo extends JpaRepository<EducationalDetail, Long> {

	EducationalDetail findByEducationalDetailUuid(String educationalDetailId);

}
