package com.gloqr.repository.master;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gloqr.entities.master.IndustrialArea;
import com.gloqr.entities.master.IndustrialJobRole;

public interface IndustrialAreaRepository extends JpaRepository<IndustrialArea, String> {

	@Query("select r from IndustrialArea a JOIN a.jobRoles r where a.areaUuid=:areaUuid")
	List<IndustrialJobRole> findJobRolesByIndustrialAreaId(@Param("areaUuid") String industrialAreaId);

	/*
	 * @Query("select DISTINCT a from IndustrialArea a LEFT JOIN FETCH a.jobRoles")
	 * public List<IndustrialArea> findAll();
	 */
}
