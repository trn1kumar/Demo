package com.gloqr.repository.master;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.entities.master.IndustrialJobRole;

public interface JobRoleRepository extends JpaRepository<IndustrialJobRole, Long> {

	IndustrialJobRole findByJobRoleUuid(String jobRoleUuid);

}
