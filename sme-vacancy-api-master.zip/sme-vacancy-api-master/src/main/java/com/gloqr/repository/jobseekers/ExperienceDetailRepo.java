package com.gloqr.repository.jobseekers;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.entities.jobseekers.ExperienceDetail;

public interface ExperienceDetailRepo extends JpaRepository<ExperienceDetail, Long> {

	ExperienceDetail findByExperienceDetailUuid(String experienceDetailId);

}
