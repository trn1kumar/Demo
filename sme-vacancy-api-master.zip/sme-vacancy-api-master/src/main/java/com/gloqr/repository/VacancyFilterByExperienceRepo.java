package com.gloqr.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.entities.filter.FilterByExperience;

public interface VacancyFilterByExperienceRepo extends JpaRepository<FilterByExperience, Long> {

}
