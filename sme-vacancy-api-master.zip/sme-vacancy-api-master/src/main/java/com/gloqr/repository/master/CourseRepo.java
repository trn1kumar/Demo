package com.gloqr.repository.master;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gloqr.entities.master.Course;
import com.gloqr.entities.master.Specialization;

public interface CourseRepo extends JpaRepository<Course, String> {

	@Query("select s from Course c JOIN c.specializations s where c.courseId =:courseId")
	List<Specialization> findSpecializationsByCourseId(@Param("courseId") String courseId);

	List<Course> findByCourseIdIn(Set<String> coursesId);

	Course findByCourseId(String courseId);

}
