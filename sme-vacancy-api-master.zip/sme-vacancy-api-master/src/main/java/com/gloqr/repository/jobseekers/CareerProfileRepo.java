package com.gloqr.repository.jobseekers;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.entities.jobseekers.CareerProfile;

public interface CareerProfileRepo extends JpaRepository<CareerProfile, Long> {

	CareerProfile findByCareerProfileDetailUuid(String careerProfileId);

}
