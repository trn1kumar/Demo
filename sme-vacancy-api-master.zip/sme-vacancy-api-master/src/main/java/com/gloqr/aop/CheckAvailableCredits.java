package com.gloqr.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.Authentication;

import com.gloqr.constants.CreditType;
import com.gloqr.dto.VacancyDto;
import com.gloqr.exception.CustomException;
import com.gloqr.rest.endpoint.PricingEndpoint;

@Aspect
@Configuration
public class CheckAvailableCredits {

	@Autowired
	private PricingEndpoint pricingEnpoint;

	@Before("@annotation(checkCredits) && args(authentication,vacancyDto)")
	public void beforeMethodExecution(JoinPoint joinPoint, PostVacancyCheckCredits checkCredits,
			Authentication authentication, VacancyDto vacancyDto) {

		try {
			pricingEnpoint.checkCredits(CreditType.JOB_POSTING);
		} catch (CustomException e) {
			throw e;
		}

	}

}
