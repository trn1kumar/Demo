package com.gloqr.vo;

import java.util.Date;
import java.util.List;

import com.gloqr.constants.PreferredShift;
import com.gloqr.constants.VacancyState;
import com.gloqr.entities.VacancyDetail;

public class VacancyVo extends VacancyBasicInfo {

	private String shortDescription;

	private boolean vacancyActive;

	private VacancyState vacancyState;

	private boolean applied;

	private String locations;

	private String jobTypes;

	private String employmentTypes;

	private String requiredDocuments;

	private List<String> skillSets;

	private PreferredShift preferredShift;

	private String rawFormatQualification;

	private Date lastApplyDate;

	private VacancyDetail vacancyDetail;

	private int totalApplicants;

	private Date creationDate;

	private Date lastModifiedDate;

	public String getShortDescription() {
		return shortDescription;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	public List<String> getSkillSets() {
		return skillSets;
	}

	public void setSkillSets(List<String> skillSets) {
		this.skillSets = skillSets;
	}

	public PreferredShift getPreferredShift() {
		return preferredShift;
	}

	public void setPreferredShift(PreferredShift preferredShift) {
		this.preferredShift = preferredShift;
	}

	public String getLocations() {
		return locations;
	}

	public void setLocations(String locations) {
		this.locations = locations;
	}

	public String getJobTypes() {
		return jobTypes;
	}

	public void setJobTypes(String jobTypes) {
		this.jobTypes = jobTypes;
	}

	public String getEmploymentTypes() {
		return employmentTypes;
	}

	public void setEmploymentTypes(String employmentTypes) {
		this.employmentTypes = employmentTypes;
	}

	public String getRequiredDocuments() {
		return requiredDocuments;
	}

	public void setRequiredDocuments(String requiredDocuments) {
		this.requiredDocuments = requiredDocuments;
	}

	public Date getLastApplyDate() {
		return lastApplyDate;
	}

	public void setLastApplyDate(Date lastApplyDate) {
		this.lastApplyDate = lastApplyDate;
	}

	public VacancyDetail getVacancyDetail() {
		return vacancyDetail;
	}

	public void setVacancyDetail(VacancyDetail vacancyDetail) {
		this.vacancyDetail = vacancyDetail;
	}

	public int getTotalApplicants() {
		return totalApplicants;
	}

	public void setTotalApplicants(int totalApplicants) {
		this.totalApplicants = totalApplicants;
	}

	public String getRawFormatQualification() {
		return rawFormatQualification;
	}

	public void setRawFormatQualification(String rawFormatQualification) {
		this.rawFormatQualification = rawFormatQualification;
	}

	public boolean isVacancyActive() {
		return vacancyActive;
	}

	public void setVacancyActive(boolean vacancyActive) {
		this.vacancyActive = vacancyActive;
	}

	public VacancyState getVacancyState() {
		return vacancyState;
	}

	public void setVacancyState(VacancyState vacancyState) {
		this.vacancyState = vacancyState;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public boolean isApplied() {
		return applied;
	}

	public void setApplied(boolean applied) {
		this.applied = applied;
	}

}
