package com.gloqr.vo.master;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class CourseVo {

	private String courseId;
	private String courseName;
	private int totalSpecializations;

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getCourseId() {
		return courseId;
	}

	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}

	public int getTotalSpecializations() {
		return totalSpecializations;
	}

	public void setTotalSpecializations(int totalSpecializations) {
		this.totalSpecializations = totalSpecializations;
	}

}
