package com.gloqr.vo.master;

import java.util.List;


public class CourseCategoryVo {

	private String courseCategoryId;
	private String courseCategoryName;
	private List<CourseVo> courses;
	
	public String getCourseCategoryName() {
		return courseCategoryName;
	}

	public void setCourseCategoryName(String courseCategoryName) {
		this.courseCategoryName = courseCategoryName;
	}

	public String getCourseCategoryId() {
		return courseCategoryId;
	}

	public void setCourseCategoryId(String courseCategoryId) {
		this.courseCategoryId = courseCategoryId;
	}

	public List<CourseVo> getCourses() {
		return courses;
	}

	public void setCourses(List<CourseVo> courses) {
		this.courses = courses;
	}


}
