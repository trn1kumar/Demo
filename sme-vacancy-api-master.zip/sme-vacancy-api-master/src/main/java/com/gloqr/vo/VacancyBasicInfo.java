package com.gloqr.vo;

import java.io.Serializable;

import com.gloqr.dto.SMEDto;

public class VacancyBasicInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6171730286409532666L;

	private String vacancyUuid;

	private String vacancyUrl;

	private String smeUuid;

	private SMEDto smeInfo;

	private String vacancyTitle;

	private String jobRole;

	private double minExp;

	private double maxExp;

	private long minSalary;

	private long maxSalary;

	private int noOfVacancy;

	public String getVacancyTitle() {
		return vacancyTitle;
	}

	public void setVacancyTitle(String vacancyTitle) {
		this.vacancyTitle = vacancyTitle;
	}

	public String getJobRole() {
		return jobRole;
	}

	public void setJobRole(String jobRole) {
		this.jobRole = jobRole;
	}

	public double getMinExp() {
		return minExp;
	}

	public void setMinExp(double minExp) {
		this.minExp = minExp;
	}

	public double getMaxExp() {
		return maxExp;
	}

	public void setMaxExp(double maxExp) {
		this.maxExp = maxExp;
	}

	public long getMinSalary() {
		return minSalary;
	}

	public void setMinSalary(long minSalary) {
		this.minSalary = minSalary;
	}

	public long getMaxSalary() {
		return maxSalary;
	}

	public void setMaxSalary(long maxSalary) {
		this.maxSalary = maxSalary;
	}

	public int getNoOfVacancy() {
		return noOfVacancy;
	}

	public void setNoOfVacancy(int noOfVacancy) {
		this.noOfVacancy = noOfVacancy;
	}

	public String getVacancyUuid() {
		return vacancyUuid;
	}

	public void setVacancyUuid(String vacancyUuid) {
		this.vacancyUuid = vacancyUuid;
	}

	public SMEDto getSmeInfo() {
		return smeInfo;
	}

	public void setSmeInfo(SMEDto smeInfo) {
		this.smeInfo = smeInfo;
	}

	public String getSmeUuid() {
		return smeUuid;
	}

	public void setSmeUuid(String smeUuid) {
		this.smeUuid = smeUuid;
	}

	public String getVacancyUrl() {
		return vacancyUrl;
	}

	public void setVacancyUrl(String vacancyUrl) {
		this.vacancyUrl = vacancyUrl;
	}

}
