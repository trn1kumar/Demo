package com.gloqr.service;

import java.util.List;

import com.gloqr.entities.jobseekers.CareerProfile;
import com.gloqr.entities.jobseekers.EducationalDetail;
import com.gloqr.entities.jobseekers.ExperienceDetail;
import com.gloqr.entities.jobseekers.JobSeekerProfile;

public interface JobSeekerService {

	public void createJobSeekerProfile(JobSeekerProfile jobSeekerProfile);

	public void updateJobSeekerProfile(JobSeekerProfile jobSeekerProfile);

	public void addEducationalDetail(String jobSeekerId, EducationalDetail educationalDetail);

	public void updateEducationalDetail(String jobSeekerId, EducationalDetail educationalDetail);

	public void addExperienceDetail(String jobSeekerId, ExperienceDetail experienceDetail);

	public void updateExperienceDetail(String jobSeekerId, ExperienceDetail experienceDetail);

	public void addCareerDetail(String jobSeekerId, CareerProfile careerProfile);

	public void updateCareerDetail(String jobSeekerId, CareerProfile careerProfile);

	public void addSkillSets(String jobSeekerId, List<String> skillSets);

	public JobSeekerProfile getJobSeekerProfile(String jobSeekerId);
	
	public JobSeekerProfile getJobSeekerProfileByUuid(String jobSeekerProfileUuid);
	
	public void checkAndSetCourseDetail(EducationalDetail educationDetail);

	public String updateResume(String resumeUrl,String resumeFileName,String jobSeekerId);

}
