package com.gloqr.service;

import java.util.List;

import com.gloqr.entities.Vacancy;
import com.gloqr.model.VacancyStateChange;



public interface GloqrAdminService {

	List<Vacancy> approveOrRejectVacancies(VacancyStateChange smeAndVacancyInfo);

	List<Vacancy> getPendingVacanciesBySmeId(String smeId);

}
