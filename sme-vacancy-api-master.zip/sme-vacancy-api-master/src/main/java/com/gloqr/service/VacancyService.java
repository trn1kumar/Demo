package com.gloqr.service;

import java.util.List;
import java.util.Set;

import com.gloqr.constants.VacancyState;
import com.gloqr.entities.CustomApplicant;
import com.gloqr.entities.Vacancy;
import com.gloqr.entities.VacancyApplicant;
import com.gloqr.vo.VacancyBasicInfo;

public interface VacancyService {

	// save
	public Vacancy saveVacancy(Vacancy vacancy);

	public Vacancy updateVacancy(Vacancy vacancy);

	public void saveVacancies(List<Vacancy> vacancies);

	public void applyVacancy(String vacancyUuid, String jobSeekerUserId, CustomApplicant customApplicant);

	public List<Vacancy> getActiveAndApprovedVacancies(String sUuid);

	// get multiple vacancies by sme id
	public List<Vacancy> getVacanciesBySmeId(String smeUuid, boolean pendingVacancies);

	// get single data
	public Vacancy getVacancyByUuid(String vacancyUuid);

	public Vacancy getVacancyByUuidAndActiveAndState(String vacancyUuid);

	public Vacancy getVacancyByUuidAndSmeId(String vacancyUuid, String smeId);

	// get job applicants
	public List<VacancyApplicant> getJobApplicants(String vacancyUuid);

	public Set<String> getSmeUuidOfVacancyActiveTrueAndVacancyState(VacancyState state);

	public List<VacancyBasicInfo> getTopVacancies();

	public void setVacancyApplied(List<Vacancy> vacancies, String loggedInUserId);

	public VacancyApplicant getApplicantProfileByUuid(String applicantUuid);

	public void shortListJobSeeker(VacancyApplicant vacancyApplicant);
}
