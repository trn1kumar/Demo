package com.gloqr.service.filter;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.gloqr.dto.SMEDto;
import com.gloqr.entities.Vacancy;

public interface FilterService {

	public Map<String, Object> getFilter(Map<String, SMEDto> smes, Set<String> filterBySmes,
			Set<String> filterByLocations, Set<String> filterByJobRoles, Set<String> filterBySalaries,
			Set<String> filterByExperiences);

	public List<Vacancy> appyFilter(Set<String> smes, Set<String> locations, Set<String> jobRoles, Set<String> salaries,
			Set<String> experiences, int page);

}
