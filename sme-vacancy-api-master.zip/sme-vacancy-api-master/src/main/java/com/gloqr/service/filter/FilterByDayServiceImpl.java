package com.gloqr.service.filter;

import java.util.List;
import java.util.Set;

import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.stereotype.Service;

import com.gloqr.entities.Vacancy;

@Service(value = "relevanceFilter")
public class FilterByDayServiceImpl implements VacancyFilterService {

	@Override
	public List<Vacancy> filter(Set<String> filterParams, int firstResult, int maxResult) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FullTextQuery createFullTextQuery(FullTextEntityManager fullTextEntityManager, QueryBuilder queryBuilder,
			Set<String> filterParams, int firstResult, int maxResult) {
		// TODO Auto-generated method stub
		return null;
	}

}
