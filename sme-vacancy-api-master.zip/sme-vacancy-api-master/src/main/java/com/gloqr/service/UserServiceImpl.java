package com.gloqr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.dto.UserDto;
import com.gloqr.exception.CustomException;
import com.gloqr.rest.endpoint.UserEndPoint;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserEndPoint userEndPoint;

	@Override
	public UserDto getUser(String userId) {
		UserDto userInfo = null;
		try {
			userInfo = userEndPoint.getUser(userId);
		} catch (CustomException e) {
			e.printStackTrace();
		}
		return userInfo;
	}

}
