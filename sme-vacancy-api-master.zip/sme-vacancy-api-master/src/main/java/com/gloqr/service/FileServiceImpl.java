package com.gloqr.service;

import java.io.IOException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.model.UploadFileResponse;
import com.gloqr.rest.endpoint.ContentServerEndpoint;
import com.gloqr.util.RandomNumberUtil;

@Service
public class FileServiceImpl implements FileService {

	@Autowired
	ContentServerEndpoint contentServerEndpoint;

	@Override
	public String sendFilesToContentServer(MultipartFile file, String fileContentDirName) throws IOException {

		String imageName = RandomNumberUtil.generate(10000000) + file.getOriginalFilename();
		UploadFileResponse fileDetail = contentServerEndpoint.sendFileToContentServer(file, imageName,
				fileContentDirName);

		return fileDetail.getFileLocation();

	}

	@Override
	public void deleteFileFromContentServer(String fileLocation) throws IOException {
		contentServerEndpoint.deleteFileFromContentServer(fileLocation);
	}
}
