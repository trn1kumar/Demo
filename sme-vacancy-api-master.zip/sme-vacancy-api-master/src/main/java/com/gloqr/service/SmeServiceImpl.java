package com.gloqr.service;

import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.dto.SMEDto;
import com.gloqr.rest.endpoint.SmeEndPoint;

@Service
public class SmeServiceImpl implements SmeService {

	@Autowired
	SmeEndPoint smeInformationEndPoint;

	@Override
	public SMEDto getSME(String sUuid) {
		return smeInformationEndPoint.getSME(sUuid);
	}

	@Override
	public Map<String, SMEDto> getSMEs(Set<String> smeIds) {
		return smeInformationEndPoint.getSMEs(smeIds);
	}

}
