package com.gloqr.service;

import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gloqr.constants.CreditType;
import com.gloqr.constants.VacancyState;
import com.gloqr.dao.MasterDataDao;
import com.gloqr.dao.VacancyApplicantDao;
import com.gloqr.dao.VacancyDao;
import com.gloqr.entities.CustomApplicant;
import com.gloqr.entities.Vacancy;
import com.gloqr.entities.VacancyApplicant;
import com.gloqr.entities.jobseekers.ExperienceDetail;
import com.gloqr.entities.jobseekers.JobSeekerProfile;
import com.gloqr.entities.master.Course;
import com.gloqr.entities.master.IndustrialJobRole;
import com.gloqr.entities.master.Specialization;
import com.gloqr.exception.CustomException;
import com.gloqr.rest.endpoint.PricingEndpoint;
import com.gloqr.util.FinalResponsePrepareUtil;
import com.gloqr.util.UuidUtil;
import com.gloqr.vo.VacancyBasicInfo;

@Service
public class VacancyServiceImpl implements VacancyService {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private VacancyDao vacancyDao;

	@Autowired
	private VacancyApplicantDao applicantDao;

	@Autowired
	private MasterDataDao masterDataDao;

	@Autowired
	private PricingEndpoint pricingEnpoint;

	@Autowired
	private BusinessPostService businessPostService;

	@Autowired
	private JobSeekerService jobSeekerService;

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private FinalResponsePrepareUtil finalObjectPrepareUtil;

	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public Vacancy saveVacancy(Vacancy vacancy) {

		vacancy.setVacancyUrl(UuidUtil.getUrlName(vacancy.getVacancyTitle()));
		vacancy.setVacancyUuid(UuidUtil.getUuid());
		vacancy.setVacancyState(VacancyState.PENDING);
		vacancy.setVacancyActive(true);
		preparedForSaveData(vacancy);
		if (vacancy.getVacancyDetail() != null)
			vacancy.getVacancyDetail().setVdUuId(UuidUtil.getUuid());

		vacancyDao.saveVacancy(vacancy);

		if (vacancy.isBusinessPost()) {
			try {
				businessPostService.createBusinessPost(vacancy);
				vacancy.setBusinessPostAlreadyActivated(true);
			} catch (CustomException e) {
				vacancy.setBusinessPost(false);
				log.warn("Can't create business post.setting business post=false. Exception message:: {}",
						e.getMessage());
			}

		}

		pricingEnpoint.updateCredits(CreditType.JOB_POSTING, "Added new Vacancy. Id:: " + vacancy.getVacancyUuid(),
				"DEBIT", 1);

		return vacancy;
	}

	private void preparedForSaveData(Vacancy vacancy) {

		List<Course> rawCourses = vacancy.getQualificationCourses();
		List<Specialization> rawSpecs = vacancy.getQualificationSpecializations();

		if (rawCourses == null && rawSpecs == null) {
			throw new CustomException("either 'courses' or 'specializations' required", HttpStatus.BAD_REQUEST);
		}
		Set<String> courseIdsFromSpec = null;
		if (rawSpecs != null) {
			Set<String> specsId = rawSpecs.stream().map(Specialization::getSpecializationId)
					.collect(Collectors.toSet());
			List<Specialization> specs = masterDataDao.getSpecializationsByIds(specsId);
			courseIdsFromSpec = specs.stream().map(spec -> spec.getCourse().getCourseId()).collect(Collectors.toSet());

			vacancy.setQualificationSpecializations(specs);
		}
		if (rawCourses != null) {

			/*
			 * remove courses which are having specialization.because of if specialization
			 * present course will be auto map with entity mapping.so removing its make
			 * clean database mapping
			 */

			Set<String> courseIds = rawCourses.stream().map(Course::getCourseId).collect(Collectors.toSet());

			if (courseIdsFromSpec != null && !courseIdsFromSpec.isEmpty()) {
				Iterator<String> itrs = courseIds.iterator();
				while (itrs.hasNext()) {
					if (courseIdsFromSpec.contains(itrs.next())) {
						itrs.remove();
					}
				}
			}

			List<Course> courses = masterDataDao.getCoursesByIds(courseIds);
			vacancy.setQualificationCourses(courses);
		}
		if (vacancy.getJobRole() != null) {
			IndustrialJobRole jobRole = masterDataDao.getJobRole(vacancy.getJobRole().getJobRoleUuid());

			vacancy.setJobRole(jobRole);
		}

	}

	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public Vacancy updateVacancy(Vacancy vacancy) {

		if (vacancy.getVacancyUuid() == null) {
			throw new CustomException("Vacancy uuid can not be null. couldn't update", HttpStatus.BAD_REQUEST);
		}

		Vacancy existVacancy = this.getVacancyByUuidAndSmeId(vacancy.getVacancyUuid(), vacancy.getSmeUuid());

		if (existVacancy.isVacancyActive() || existVacancy.getVacancyState().equals(VacancyState.APPROVED)) {
			throw new CustomException("Given Vacancy is in eighter 'Active Mode' or 'Approved State'. couldn't update",
					HttpStatus.BAD_REQUEST);
		}

		vacancy.setVacancyId(existVacancy.getVacancyId());
		vacancy.setVacancyUrl(existVacancy.getVacancyUrl());
		vacancy.setApplicants(existVacancy.getApplicants());
		vacancy.setFeedbackMessage(existVacancy.getFeedbackMessage());
		vacancy.setQualificationCourses(existVacancy.getQualificationCourses());
		vacancy.setQualificationSpecializations(existVacancy.getQualificationSpecializations());
		vacancy.setJobRole(existVacancy.getJobRole());

		if (vacancy.getVacancyDetail() != null && existVacancy.getVacancyDetail() != null) {
			vacancy.getVacancyDetail().setDetailId(existVacancy.getVacancyDetail().getDetailId());
			vacancy.getVacancyDetail().setVdUuId(existVacancy.getVacancyDetail().getVdUuId());
		} else if (vacancy.getVacancyDetail() != null) {
			vacancy.getVacancyDetail().setVdUuId(UuidUtil.getUuid());
		}

		vacancy.setVacancyModified(true);
		vacancy.setVacancyState(VacancyState.PENDING);
		vacancy.setVacancyActive(true);

		vacancyDao.saveVacancy(vacancy);
		pricingEnpoint.updateCredits(CreditType.JOB_POSTING, "Updated new Vacancy. Id :: " + vacancy.getVacancyUuid(),
				"DEBIT", 1);

		return vacancy;
	}

	@Override
	@Transactional(readOnly = true)
	public Vacancy getVacancyByUuidAndSmeId(String vacancyUuid, String smeUuid) {
		return vacancyDao.getVacancyByUuidAndSmeId(vacancyUuid, smeUuid);
	}

	@Override
	public Vacancy getVacancyByUuid(String vacancyUuid) {
		return vacancyDao.getSingleVacancy(vacancyUuid);

	}

	@Override
	public Vacancy getVacancyByUuidAndActiveAndState(String vacancyUuid) {
		return vacancyDao.getVacancyByUuidAndActiveAndState(vacancyUuid);

	}

	@Override
	public void applyVacancy(String vacancyUuid, String jobSeekerUserId, CustomApplicant customApplicant) {

		try {
			Vacancy vacancy = this.getVacancyByUuid(vacancyUuid);
			VacancyApplicant vacancyApplicant = new VacancyApplicant();
			vacancyApplicant.setApplicantUuid(UuidUtil.getUuid().substring(0, 9));
			vacancyApplicant.setApplyDate(new Date());
			vacancyApplicant.setVacancy(vacancy);

			if (jobSeekerUserId != null) {
				setVacancyApplied(Arrays.asList(vacancy), jobSeekerUserId);
				if (vacancy.isApplied()) {
					throw new CustomException("Already Applied", 600, HttpStatus.BAD_REQUEST);
				}
				JobSeekerProfile applicant = jobSeekerService.getJobSeekerProfile(jobSeekerUserId);
				vacancyApplicant.setApplicant(applicant);
			}

			else if (customApplicant != null) {
				customApplicant.setCustomApplicantId(UuidUtil.getUuid().substring(0, 9));
				vacancyApplicant.setCustomApplicant(customApplicant);
			} else {
				throw new CustomException("No Applicants. either 'jobSeekerUserId' or 'customApplicant' required.",
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

			if (vacancy.getApplicants() != null) {
				vacancy.getApplicants().add(vacancyApplicant);
			} else {
				vacancy.setApplicants(Arrays.asList(vacancyApplicant));
			}

			vacancyDao.saveVacancy(vacancy);
			notificationService.sendVacancyAppliedNotification(vacancy, vacancyApplicant);

		} catch (CustomException e) {
			throw e;

		}
	}

	@Override
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public VacancyApplicant getApplicantProfileByUuid(String applicantUuid) {

		try {
			VacancyApplicant vacancyApplicant = applicantDao.getApplicant(applicantUuid);

			if (vacancyApplicant.getApplicant() != null) {
				jobSeekerService.checkAndSetCourseDetail(vacancyApplicant.getApplicant().getEducationalDetail());
				List<ExperienceDetail> expDetails = vacancyApplicant.getApplicant().getExperienceDetails();
				Collections.sort(expDetails);
				return vacancyApplicant;
			} else {
				throw new CustomException("Job Seeker Profile Not Found with ApplicantUuid:  " + applicantUuid,
						HttpStatus.NOT_FOUND);
			}

		} catch (CustomException e) {
			throw e;

		}

	}

	@Override
	public List<VacancyApplicant> getJobApplicants(String vacancyUuid) {
		Vacancy vacancy = this.getVacancyByUuid(vacancyUuid);
		if (vacancy.getApplicants() != null && !vacancy.getApplicants().isEmpty())
			return vacancy.getApplicants();
		else
			throw new CustomException("no one applied yet for vacancy ::" + vacancyUuid, HttpStatus.NOT_FOUND);
	}

	@Override
	public void saveVacancies(List<Vacancy> vacancies) {
		vacancyDao.saveVacancies(vacancies);
	}

	@Override
	public Set<String> getSmeUuidOfVacancyActiveTrueAndVacancyState(VacancyState state) {
		return vacancyDao.getSmeUuidOfVacancyActiveTrueAndVacancyState(state);
	}

	@Override
	public List<Vacancy> getActiveAndApprovedVacancies(String smeId) {
		return vacancyDao.getVacanciesBySmeUuidAndVacancyStateAndVacancyActiveTrue(smeId, VacancyState.APPROVED);
	}

	@Override
	public List<Vacancy> getVacanciesBySmeId(String smeUuid, boolean pendingVacancies) {
		return vacancyDao.getVacanciesBySmeId(smeUuid, pendingVacancies);
	}

	@Override
	@Cacheable(value = "topVacancies")
	public List<VacancyBasicInfo> getTopVacancies() {
		List<Vacancy> vacancies = vacancyDao.getTopVacancies();
		return finalObjectPrepareUtil.prepareForVacancyBasicDetail(vacancies);

	}

	@Override
	public void setVacancyApplied(List<Vacancy> vacancies, String loggedInUserId) {

		vacancies.stream().filter(vacancy -> vacancy.getApplicants() != null && !vacancy.getApplicants().isEmpty())
				.filter(vacancy -> vacancy.getApplicants().stream()
						.filter(applicant -> applicant.getApplicant() != null)
						.anyMatch(applicant -> applicant.getApplicant().getJobSeekerProfileId().equals(loggedInUserId)))
				.forEach(vacancy -> vacancy.setApplied(true));

	}

	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public void shortListJobSeeker(VacancyApplicant vacancyApplicant) {

		VacancyApplicant applicant = applicantDao.getApplicant(vacancyApplicant.getApplicantUuid());
		applicant.setShortListedInfo(vacancyApplicant.getShortListedInfo());
		applicant.setShortListed(true);
		applicantDao.saveApplicant(applicant);

		String vacancyTitleAndUrlAndSmeId = vacancyDao.getVacancyTitleAndUrlAndSmeId(applicant.getApplicantId());

		notificationService.sendSeekerShortlistedNotification(applicant, vacancyTitleAndUrlAndSmeId);

	}

}
