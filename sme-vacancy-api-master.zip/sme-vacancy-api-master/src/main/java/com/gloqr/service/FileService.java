package com.gloqr.service;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;


public interface FileService {

	public String sendFilesToContentServer(MultipartFile file, String fileContentDirName)
			throws IllegalArgumentException, IOException;

	public void deleteFileFromContentServer(String fileLocation) throws IOException;
	
}
