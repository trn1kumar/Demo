package com.gloqr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.entities.Vacancy;
import com.gloqr.model.PublishFeed;
import com.gloqr.rest.endpoint.BusinessPostEndpoint;

@Service
public class BusinessPostServiceImpl implements BusinessPostService {

	@Autowired
	private BusinessPostEndpoint businessPostEndPoint;

	@Override
	public void createBusinessPost(Vacancy vacancy) {

		PublishFeed feed = new PublishFeed(vacancy.getSmeUuid(), vacancy.getVacancyUuid(), vacancy.getVacancyTitle(),
				vacancy.getShortDescription());

		if (vacancy.isVacancyActive())
			feed.setActive(true);

		businessPostEndPoint.createFeed(feed);

	}

}
