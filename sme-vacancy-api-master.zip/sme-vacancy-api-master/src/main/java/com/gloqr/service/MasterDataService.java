package com.gloqr.service;

import java.util.List;

import com.gloqr.entities.master.Course;
import com.gloqr.entities.master.CourseCategory;
import com.gloqr.entities.master.IndustrialArea;
import com.gloqr.entities.master.IndustrialJobRole;
import com.gloqr.entities.master.Specialization;

public interface MasterDataService {

	List<IndustrialJobRole> getAllJobRoles();

	void saveIndustrialArea(IndustrialArea industrialArea);

	List<IndustrialArea> getAllIndustrialArea();

	List<CourseCategory> getCourseCategories();

	List<Course> getCourses(String courseCategoryId);

	List<Specialization> getSpecializations(String courseId);

	List<IndustrialJobRole> getJobRoles(String industrialAreaId);

}
