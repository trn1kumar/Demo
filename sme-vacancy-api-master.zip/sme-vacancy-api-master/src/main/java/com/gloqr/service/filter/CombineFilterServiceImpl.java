package com.gloqr.service.filter;

import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;

import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.SortField;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gloqr.constants.FilterConstant;
import com.gloqr.constants.FilterConstant.SearchFileds;
import com.gloqr.constants.VacancyState;
import com.gloqr.entities.Vacancy;

@Component
public class CombineFilterServiceImpl {

	@Autowired
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	public List<Vacancy> applyCombineFilterResult(Set<String> smeFilterParams, Set<String> locationFilterParams,
			Set<String> jobRoleFilterParams, Set<String> salaryFilterParams, Set<String> experienceFilterParams,
			int firstResult, int maxResult) {

		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);
		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(Vacancy.class).get();
		List<Query> queryList = new LinkedList<>();

		if (smeFilterParams != null && locationFilterParams != null && jobRoleFilterParams != null
				&& salaryFilterParams != null && experienceFilterParams != null) {
			getQueriesForAllFilters(queryList, queryBuilder, smeFilterParams, locationFilterParams, jobRoleFilterParams,
					salaryFilterParams, experienceFilterParams);

		} else if (smeFilterParams != null && locationFilterParams != null && jobRoleFilterParams != null) {
			getQueriesForSMELocationRoleFilters(queryList, queryBuilder, smeFilterParams, locationFilterParams,
					jobRoleFilterParams);

		} else if (smeFilterParams != null && locationFilterParams != null && salaryFilterParams != null) {
			getQueriesForSMELocationSalaryFilters(queryList, queryBuilder, smeFilterParams, locationFilterParams,
					salaryFilterParams);

		} else if (smeFilterParams != null && locationFilterParams != null && experienceFilterParams != null) {

			getQueriesForSMELocationExperienceFilters(queryList, queryBuilder, smeFilterParams, locationFilterParams,
					experienceFilterParams);

		} else if (smeFilterParams != null && jobRoleFilterParams != null && salaryFilterParams != null) {

			getQueriesForSMEJobRoleSalaryFilters(queryList, queryBuilder, smeFilterParams, jobRoleFilterParams,
					salaryFilterParams);

		} else if (smeFilterParams != null && jobRoleFilterParams != null && experienceFilterParams != null) {

			getQueriesForSMEJobRoleExperienceFilters(queryList, queryBuilder, smeFilterParams, jobRoleFilterParams,
					experienceFilterParams);

		} else if (smeFilterParams != null && salaryFilterParams != null && experienceFilterParams != null) {

			getQueriesForSMESalaryExperienceFilters(queryList, queryBuilder, smeFilterParams, salaryFilterParams,
					experienceFilterParams);

		} else if (locationFilterParams != null && jobRoleFilterParams != null && salaryFilterParams != null) {

			getQueriesForLocationJobRoleSalaryFilters(queryList, queryBuilder, locationFilterParams,
					jobRoleFilterParams, salaryFilterParams);

		} else if (locationFilterParams != null && jobRoleFilterParams != null && experienceFilterParams != null) {

			getQueriesForLocationJobRoleExperienceFilters(queryList, queryBuilder, locationFilterParams,
					jobRoleFilterParams, experienceFilterParams);

		} else if (locationFilterParams != null && salaryFilterParams != null && experienceFilterParams != null) {

			getQueriesForLocationSalaryExperienceFilters(queryList, queryBuilder, locationFilterParams,
					salaryFilterParams, experienceFilterParams);

		} else if (jobRoleFilterParams != null && salaryFilterParams != null && experienceFilterParams != null) {

			getQueriesForRoleSalaryExperienceFilters(queryList, queryBuilder, jobRoleFilterParams, salaryFilterParams,
					experienceFilterParams);

		} else if (smeFilterParams != null && locationFilterParams != null) {

			getQueriesForSMELocationFilters(queryList, queryBuilder, smeFilterParams, locationFilterParams);

		} else if (smeFilterParams != null && jobRoleFilterParams != null) {
			getQueriesForSMERoleFilters(queryList, queryBuilder, smeFilterParams, jobRoleFilterParams);

		} else if (smeFilterParams != null && salaryFilterParams != null) {

			getQueriesForSMESalaryFilters(queryList, queryBuilder, smeFilterParams, salaryFilterParams);

		} else if (smeFilterParams != null && experienceFilterParams != null) {

			getQueriesForSMEExperienceFilters(queryList, queryBuilder, smeFilterParams, experienceFilterParams);

		} else if (locationFilterParams != null && jobRoleFilterParams != null) {

			getQueriesForLocationRoleFilters(queryList, queryBuilder, locationFilterParams, jobRoleFilterParams);

		} else if (locationFilterParams != null && salaryFilterParams != null) {

			getQueriesForLocationSalaryFilters(queryList, queryBuilder, locationFilterParams, salaryFilterParams);

		} else if (locationFilterParams != null && experienceFilterParams != null) {
			getQueriesForLocationExperienceFilters(queryList, queryBuilder, locationFilterParams,
					experienceFilterParams);

		} else if (jobRoleFilterParams != null && salaryFilterParams != null) {

			getQueriesForRoleSalaryFilters(queryList, queryBuilder, jobRoleFilterParams, salaryFilterParams);

		} else if (jobRoleFilterParams != null && experienceFilterParams != null) {

			getQueriesForRoleExperienceFilters(queryList, queryBuilder, jobRoleFilterParams, experienceFilterParams);

		} else if (salaryFilterParams != null && experienceFilterParams != null) {
			getQueriesForSalaryExperienceFilters(queryList, queryBuilder, salaryFilterParams, experienceFilterParams);

		}

		BooleanQuery.Builder booleanQuery = new BooleanQuery.Builder();

		queryList.forEach(q -> booleanQuery.add(q, BooleanClause.Occur.SHOULD));

		FullTextQuery queryResult = fullTextEntityManager.createFullTextQuery(booleanQuery.build(), Vacancy.class);

		queryResult.setFirstResult(firstResult).setMaxResults(maxResult);

		Sort sort = new Sort(new SortField(SearchFileds.CREATION_DATE, SortField.Type.LONG, true));
		queryResult.setSort(sort);

		return queryResult.getResultList();

	}

	private void getQueriesForSalaryExperienceFilters(List<Query> queryList, QueryBuilder queryBuilder,
			Set<String> salaryFilterParams, Set<String> experienceFilterParams) {
		salaryFilterParams.forEach(salary -> {
			String[] strs = salary.split("-");
			long minSalary = Long.parseLong(strs[0]) * FilterConstant.SALARY_CURRENCY;
			long maxSalary = Long.parseLong(strs[1]) * FilterConstant.SALARY_CURRENCY;

			experienceFilterParams.forEach(exp -> {
				String[] strs1 = exp.split("-");
				double minExp = Double.parseDouble(strs1[0]);
				double maxExp = Double.parseDouble(strs1[1]);
				Query query = queryBuilder.bool()
						.must(queryBuilder.range().onField(SearchFileds.MIN_EXP).above(minExp).createQuery())
						.must(queryBuilder.range().onField(SearchFileds.MAX_EXP).below(maxExp).createQuery())
						.must(queryBuilder.range().onField(SearchFileds.MIN_SALARY).above(minSalary).createQuery())
						.must(queryBuilder.range().onField(SearchFileds.MAX_SALARY).below(maxSalary).createQuery())
						.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true).createQuery())
						.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE).matching(VacancyState.APPROVED)
								.createQuery())
						.createQuery();
				queryList.add(query);
			});
		});
	}

	private void getQueriesForRoleExperienceFilters(List<Query> queryList, QueryBuilder queryBuilder,
			Set<String> jobRoleFilterParams, Set<String> experienceFilterParams) {
		jobRoleFilterParams.forEach(role -> experienceFilterParams.forEach(exp -> {
			String[] strs = exp.split("-");
			double minExp = Double.parseDouble(strs[0]);
			double maxExp = Double.parseDouble(strs[1]);
			Query query = queryBuilder.bool()
					.must(queryBuilder.range().onField(SearchFileds.MIN_EXP).above(minExp).createQuery())
					.must(queryBuilder.range().onField(SearchFileds.MAX_EXP).below(maxExp).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.JOB_ROLE).matching(role).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE).matching(VacancyState.APPROVED)
							.createQuery())
					.createQuery();
			queryList.add(query);
		}));
	}

	private void getQueriesForRoleSalaryFilters(List<Query> queryList, QueryBuilder queryBuilder,
			Set<String> jobRoleFilterParams, Set<String> salaryFilterParams) {
		jobRoleFilterParams.forEach(role -> salaryFilterParams.forEach(salary -> {
			String[] strs = salary.split("-");
			long minSalary = Long.parseLong(strs[0]) * FilterConstant.SALARY_CURRENCY;
			long maxSalary = Long.parseLong(strs[1]) * FilterConstant.SALARY_CURRENCY;

			Query query = queryBuilder.bool()
					.must(queryBuilder.range().onField(SearchFileds.MIN_SALARY).above(minSalary).createQuery())
					.must(queryBuilder.range().onField(SearchFileds.MAX_SALARY).below(maxSalary).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.JOB_ROLE).matching(role).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE).matching(VacancyState.APPROVED)
							.createQuery())
					.createQuery();
			queryList.add(query);
		}));
	}

	private void getQueriesForLocationExperienceFilters(List<Query> queryList, QueryBuilder queryBuilder,
			Set<String> locationFilterParams, Set<String> experienceFilterParams) {
		locationFilterParams.forEach(location -> experienceFilterParams.forEach(exp -> {
			String[] strs = exp.split("-");
			double minExp = Double.parseDouble(strs[0]);
			double maxExp = Double.parseDouble(strs[1]);

			Query query = queryBuilder.bool()
					.must(queryBuilder.keyword().onField(SearchFileds.LOCATIONS).matching(location).createQuery())
					.must(queryBuilder.range().onField(SearchFileds.MIN_EXP).above(minExp).createQuery())
					.must(queryBuilder.range().onField(SearchFileds.MAX_EXP).below(maxExp).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE).matching(VacancyState.APPROVED)
							.createQuery())
					.createQuery();
			queryList.add(query);
		}));
	}

	private void getQueriesForLocationSalaryFilters(List<Query> queryList, QueryBuilder queryBuilder,
			Set<String> locationFilterParams, Set<String> salaryFilterParams) {
		locationFilterParams.forEach(location -> salaryFilterParams.forEach(salary -> {
			String[] strs = salary.split("-");
			long minSalary = Long.parseLong(strs[0]) * FilterConstant.SALARY_CURRENCY;
			long maxSalary = Long.parseLong(strs[1]) * FilterConstant.SALARY_CURRENCY;

			Query query = queryBuilder.bool()
					.must(queryBuilder.keyword().onField(SearchFileds.LOCATIONS).matching(location).createQuery())
					.must(queryBuilder.range().onField(SearchFileds.MIN_SALARY).above(minSalary).createQuery())
					.must(queryBuilder.range().onField(SearchFileds.MAX_SALARY).below(maxSalary).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE).matching(VacancyState.APPROVED)
							.createQuery())
					.createQuery();
			queryList.add(query);
		}));
	}

	private void getQueriesForLocationRoleFilters(List<Query> queryList, QueryBuilder queryBuilder,
			Set<String> locationFilterParams, Set<String> jobRoleFilterParams) {
		locationFilterParams.forEach(location -> jobRoleFilterParams.forEach(role -> {

			Query query = queryBuilder.bool()
					.must(queryBuilder.keyword().onField(SearchFileds.LOCATIONS).matching(location).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.JOB_ROLE).matching(role).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE).matching(VacancyState.APPROVED)
							.createQuery())
					.createQuery();
			queryList.add(query);
		}));
	}

	private void getQueriesForSMEExperienceFilters(List<Query> queryList, QueryBuilder queryBuilder,
			Set<String> smeFilterParams, Set<String> experienceFilterParams) {
		smeFilterParams.forEach(smeId -> experienceFilterParams.forEach(exp -> {
			String[] strs = exp.split("-");
			double minExp = Double.parseDouble(strs[0]);
			double maxExp = Double.parseDouble(strs[1]);

			Query query = queryBuilder.bool()
					.must(queryBuilder.keyword().onField(SearchFileds.SME_ID).matching(smeId).createQuery())
					.must(queryBuilder.range().onField(SearchFileds.MIN_EXP).above(minExp).createQuery())
					.must(queryBuilder.range().onField(SearchFileds.MAX_EXP).below(maxExp).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE).matching(VacancyState.APPROVED)
							.createQuery())
					.createQuery();
			queryList.add(query);
		}));
	}

	private void getQueriesForSMESalaryFilters(List<Query> queryList, QueryBuilder queryBuilder,
			Set<String> smeFilterParams, Set<String> salaryFilterParams) {
		smeFilterParams.forEach(smeId -> salaryFilterParams.forEach(salary -> {
			String[] strs = salary.split("-");
			long minSalary = Long.parseLong(strs[0]) * FilterConstant.SALARY_CURRENCY;
			long maxSalary = Long.parseLong(strs[1]) * FilterConstant.SALARY_CURRENCY;

			Query query = queryBuilder.bool()
					.must(queryBuilder.keyword().onField(SearchFileds.SME_ID).matching(smeId).createQuery())
					.must(queryBuilder.range().onField(SearchFileds.MIN_SALARY).above(minSalary).createQuery())
					.must(queryBuilder.range().onField(SearchFileds.MAX_SALARY).below(maxSalary).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE).matching(VacancyState.APPROVED)
							.createQuery())
					.createQuery();
			queryList.add(query);
		}));
	}

	private void getQueriesForSMERoleFilters(List<Query> queryList, QueryBuilder queryBuilder,
			Set<String> smeFilterParams, Set<String> jobRoleFilterParams) {
		smeFilterParams.forEach(smeId -> jobRoleFilterParams.forEach(role -> {
			Query query = queryBuilder.bool()
					.must(queryBuilder.keyword().onField(SearchFileds.SME_ID).matching(smeId).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.JOB_ROLE).matching(role).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE).matching(VacancyState.APPROVED)
							.createQuery())
					.createQuery();
			queryList.add(query);
		}));

	}

	private void getQueriesForSMELocationFilters(List<Query> queryList, QueryBuilder queryBuilder,
			Set<String> smeFilterParams, Set<String> locationFilterParams) {
		smeFilterParams.forEach(smeId -> locationFilterParams.forEach(location -> {
			Query query = queryBuilder.bool()
					.must(queryBuilder.keyword().onField(SearchFileds.SME_ID).matching(smeId).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.LOCATIONS).matching(location).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE).matching(VacancyState.APPROVED)
							.createQuery())
					.createQuery();
			queryList.add(query);
		}));
	}

	private void getQueriesForRoleSalaryExperienceFilters(List<Query> queryList, QueryBuilder queryBuilder,
			Set<String> jobRoleFilterParams, Set<String> salaryFilterParams, Set<String> experienceFilterParams) {
		jobRoleFilterParams.forEach(role -> salaryFilterParams.forEach(salary -> {
			String[] strs = salary.split("-");
			long minSalary = Long.parseLong(strs[0]) * FilterConstant.SALARY_CURRENCY;
			long maxSalary = Long.parseLong(strs[1]) * FilterConstant.SALARY_CURRENCY;

			experienceFilterParams.forEach(exp -> {
				String[] strs1 = exp.split("-");
				double minExp = Double.parseDouble(strs1[0]);
				double maxExp = Double.parseDouble(strs1[1]);

				Query query = queryBuilder.bool()
						.must(queryBuilder.range().onField(SearchFileds.MIN_SALARY).above(minSalary).createQuery())
						.must(queryBuilder.range().onField(SearchFileds.MAX_SALARY).below(maxSalary).createQuery())
						.must(queryBuilder.range().onField(SearchFileds.MIN_EXP).above(minExp).createQuery())
						.must(queryBuilder.range().onField(SearchFileds.MAX_SALARY).below(maxExp).createQuery())
						.must(queryBuilder.keyword().onField(SearchFileds.JOB_ROLE).matching(role).createQuery())
						.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true).createQuery())
						.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE).matching(VacancyState.APPROVED)
								.createQuery())
						.createQuery();
				queryList.add(query);
			});
		}));
	}

	private void getQueriesForLocationSalaryExperienceFilters(List<Query> queryList, QueryBuilder queryBuilder,
			Set<String> locationFilterParams, Set<String> salaryFilterParams, Set<String> experienceFilterParams) {
		locationFilterParams.forEach(location -> salaryFilterParams.forEach(salary -> {
			String[] strs = salary.split("-");
			long minSalary = Long.parseLong(strs[0]) * FilterConstant.SALARY_CURRENCY;
			long maxSalary = Long.parseLong(strs[1]) * FilterConstant.SALARY_CURRENCY;

			experienceFilterParams.forEach(exp -> {
				String[] strs1 = exp.split("-");
				double minExp = Double.parseDouble(strs1[0]);
				double maxExp = Double.parseDouble(strs1[1]);

				Query query = queryBuilder.bool()
						.must(queryBuilder.range().onField(SearchFileds.MIN_SALARY).above(minSalary).createQuery())
						.must(queryBuilder.range().onField(SearchFileds.MAX_SALARY).below(maxSalary).createQuery())
						.must(queryBuilder.range().onField(SearchFileds.MIN_EXP).above(minExp).createQuery())
						.must(queryBuilder.range().onField(SearchFileds.MAX_EXP).below(maxExp).createQuery())
						.must(queryBuilder.keyword().onField(SearchFileds.LOCATIONS).matching(location).createQuery())
						.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true).createQuery())
						.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE).matching(VacancyState.APPROVED)
								.createQuery())
						.createQuery();
				queryList.add(query);
			});
		}));
	}

	private void getQueriesForLocationJobRoleExperienceFilters(List<Query> queryList, QueryBuilder queryBuilder,
			Set<String> locationFilterParams, Set<String> jobRoleFilterParams, Set<String> experienceFilterParams) {
		locationFilterParams.forEach(location -> jobRoleFilterParams.forEach(role ->

		experienceFilterParams.forEach(exp -> {
			String[] strs = exp.split("-");
			double minExp = Double.parseDouble(strs[0]);
			double maxExp = Double.parseDouble(strs[1]);

			Query query = queryBuilder.bool()
					.must(queryBuilder.keyword().onField(SearchFileds.JOB_ROLE).matching(role).createQuery())
					.must(queryBuilder.range().onField(SearchFileds.MIN_EXP).above(minExp).createQuery())
					.must(queryBuilder.range().onField(SearchFileds.MAX_EXP).below(maxExp).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.LOCATIONS).matching(location).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE).matching(VacancyState.APPROVED)
							.createQuery())
					.createQuery();
			queryList.add(query);
		})));
	}

	private void getQueriesForLocationJobRoleSalaryFilters(List<Query> queryList, QueryBuilder queryBuilder,
			Set<String> locationFilterParams, Set<String> jobRoleFilterParams, Set<String> salaryFilterParams) {
		locationFilterParams.forEach(location -> jobRoleFilterParams.forEach(role ->

		salaryFilterParams.forEach(salary -> {
			String[] strs = salary.split("-");
			long minSalary = Long.parseLong(strs[0]) * FilterConstant.SALARY_CURRENCY;
			long maxSalary = Long.parseLong(strs[1]) * FilterConstant.SALARY_CURRENCY;

			Query query = queryBuilder.bool()
					.must(queryBuilder.keyword().onField(SearchFileds.JOB_ROLE).matching(role).createQuery())
					.must(queryBuilder.range().onField(SearchFileds.MIN_SALARY).above(minSalary).createQuery())
					.must(queryBuilder.range().onField(SearchFileds.MAX_SALARY).below(maxSalary).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.LOCATIONS).matching(location).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE).matching(VacancyState.APPROVED)
							.createQuery())
					.createQuery();
			queryList.add(query);
		})));
	}

	private void getQueriesForSMESalaryExperienceFilters(List<Query> queryList, QueryBuilder queryBuilder,
			Set<String> smeFilterParams, Set<String> salaryFilterParams, Set<String> experienceFilterParams) {
		smeFilterParams.forEach(smeId -> salaryFilterParams.forEach(salary -> {
			String[] strs = salary.split("-");
			long minSalary = Long.parseLong(strs[0]) * FilterConstant.SALARY_CURRENCY;
			long maxSalary = Long.parseLong(strs[1]) * FilterConstant.SALARY_CURRENCY;
			experienceFilterParams.forEach(exp -> {
				String[] strs1 = exp.split("-");
				double minExp = Double.parseDouble(strs1[0]);
				double maxExp = Double.parseDouble(strs1[1]);

				Query query = queryBuilder.bool()
						.must(queryBuilder.keyword().onField(SearchFileds.SME_ID).matching(smeId).createQuery())
						.must(queryBuilder.range().onField(SearchFileds.MIN_SALARY).above(minSalary).createQuery())
						.must(queryBuilder.range().onField(SearchFileds.MAX_SALARY).below(maxSalary).createQuery())
						.must(queryBuilder.range().onField(SearchFileds.MIN_EXP).above(minExp).createQuery())
						.must(queryBuilder.range().onField(SearchFileds.MAX_EXP).below(maxExp).createQuery())
						.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true).createQuery())
						.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE).matching(VacancyState.APPROVED)
								.createQuery())
						.createQuery();
				queryList.add(query);
			});
		}));
	}

	private void getQueriesForSMEJobRoleExperienceFilters(List<Query> queryList, QueryBuilder queryBuilder,
			Set<String> smeFilterParams, Set<String> jobRoleFilterParams, Set<String> experienceFilterParams) {
		smeFilterParams.forEach(smeId -> jobRoleFilterParams.forEach(role -> experienceFilterParams.forEach(exp -> {
			String[] strs = exp.split("-");
			double minExp = Double.parseDouble(strs[0]);
			double maxExp = Double.parseDouble(strs[1]);

			Query query = queryBuilder.bool()
					.must(queryBuilder.keyword().onField(SearchFileds.SME_ID).matching(smeId).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.JOB_ROLE).matching(role).createQuery())
					.must(queryBuilder.range().onField(SearchFileds.MIN_EXP).above(minExp).createQuery())
					.must(queryBuilder.range().onField(SearchFileds.MAX_EXP).below(maxExp).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE).matching(VacancyState.APPROVED)
							.createQuery())
					.createQuery();
			queryList.add(query);
		})));

	}

	private void getQueriesForSMEJobRoleSalaryFilters(List<Query> queryList, QueryBuilder queryBuilder,
			Set<String> smeFilterParams, Set<String> jobRoleFilterParams, Set<String> salaryFilterParams) {
		smeFilterParams.forEach(smeId -> jobRoleFilterParams.forEach(role -> salaryFilterParams.forEach(salary -> {
			String[] strs = salary.split("-");
			long minSalary = Long.parseLong(strs[0]) * FilterConstant.SALARY_CURRENCY;
			long maxSalary = Long.parseLong(strs[1]) * FilterConstant.SALARY_CURRENCY;

			Query query = queryBuilder.bool()
					.must(queryBuilder.keyword().onField(SearchFileds.SME_ID).matching(smeId).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.JOB_ROLE).matching(role).createQuery())
					.must(queryBuilder.range().onField(SearchFileds.MIN_SALARY).above(minSalary).createQuery())
					.must(queryBuilder.range().onField(SearchFileds.MAX_SALARY).below(maxSalary).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE).matching(VacancyState.APPROVED)
							.createQuery())
					.createQuery();
			queryList.add(query);
		})));
	}

	private void getQueriesForSMELocationExperienceFilters(List<Query> queryList, QueryBuilder queryBuilder,
			Set<String> smeFilterParams, Set<String> locationFilterParams, Set<String> experienceFilterParams) {
		smeFilterParams
				.forEach(smeId -> locationFilterParams.forEach(location -> experienceFilterParams.forEach(exp -> {
					String[] strs = exp.split("-");
					double minExp = Double.parseDouble(strs[0]);
					double maxExp = Double.parseDouble(strs[1]);

					Query query = queryBuilder.bool()
							.must(queryBuilder.keyword().onField(SearchFileds.SME_ID).matching(smeId).createQuery())
							.must(queryBuilder.keyword().onField(SearchFileds.LOCATIONS).matching(location)
									.createQuery())
							.must(queryBuilder.range().onField(SearchFileds.MIN_EXP).above(minExp).createQuery())
							.must(queryBuilder.range().onField(SearchFileds.MAX_EXP).below(maxExp).createQuery())
							.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true)
									.createQuery())
							.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE)
									.matching(VacancyState.APPROVED).createQuery())
							.createQuery();
					queryList.add(query);
				})));
	}

	private void getQueriesForSMELocationSalaryFilters(List<Query> queryList, QueryBuilder queryBuilder,
			Set<String> smeFilterParams, Set<String> locationFilterParams, Set<String> salaryFilterParams) {
		smeFilterParams.forEach(smeId -> locationFilterParams.forEach(location -> salaryFilterParams.forEach(salary -> {
			String[] strs = salary.split("-");
			long minSalary = Long.parseLong(strs[0]) * FilterConstant.SALARY_CURRENCY;
			long maxSalary = Long.parseLong(strs[1]) * FilterConstant.SALARY_CURRENCY;

			Query query = queryBuilder.bool()
					.must(queryBuilder.keyword().onField(SearchFileds.SME_ID).matching(smeId).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.LOCATIONS).matching(location).createQuery())
					.must(queryBuilder.range().onField(SearchFileds.MIN_SALARY).above(minSalary).createQuery())
					.must(queryBuilder.range().onField(SearchFileds.MAX_SALARY).below(maxSalary).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE).matching(VacancyState.APPROVED)
							.createQuery())
					.createQuery();
			queryList.add(query);
		})));
	}

	private void getQueriesForSMELocationRoleFilters(List<Query> queryList, QueryBuilder queryBuilder,
			Set<String> smeFilterParams, Set<String> locationFilterParams, Set<String> jobRoleFilterParams) {
		smeFilterParams.forEach(smeId -> locationFilterParams.forEach(location -> jobRoleFilterParams.forEach(role -> {
			Query query = queryBuilder.bool()
					.must(queryBuilder.keyword().onField(SearchFileds.SME_ID).matching(smeId).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.LOCATIONS).matching(location).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.JOB_ROLE).matching(role).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE).matching(VacancyState.APPROVED)
							.createQuery())
					.createQuery();
			queryList.add(query);
		})));
	}

	private void getQueriesForAllFilters(List<Query> queryList, QueryBuilder queryBuilder, Set<String> smeFilterParams,
			Set<String> locationFilterParams, Set<String> jobRoleFilterParams, Set<String> salaryFilterParams,
			Set<String> experienceFilterParams) {
		smeFilterParams.forEach(smeId -> locationFilterParams
				.forEach(location -> jobRoleFilterParams.forEach(role -> salaryFilterParams.forEach(salary -> {
					String[] strs = salary.split("-");
					long minSalary = Long.parseLong(strs[0]) * FilterConstant.SALARY_CURRENCY;
					long maxSalary = Long.parseLong(strs[1]) * FilterConstant.SALARY_CURRENCY;

					experienceFilterParams.forEach(exp -> {
						String[] strs1 = exp.split("-");
						double minExp = Double.parseDouble(strs1[0]);
						double maxExp = Double.parseDouble(strs1[1]);

						Query query = queryBuilder.bool()
								.must(queryBuilder.keyword().onField(SearchFileds.SME_ID).matching(smeId).createQuery())
								.must(queryBuilder.keyword().onField(SearchFileds.LOCATIONS).matching(location)
										.createQuery())
								.must(queryBuilder.range().onField(SearchFileds.MIN_SALARY).above(minSalary)
										.createQuery())
								.must(queryBuilder.range().onField(SearchFileds.MAX_SALARY).below(maxSalary)
										.createQuery())
								.must(queryBuilder.range().onField(SearchFileds.MIN_EXP).above(minExp).createQuery())
								.must(queryBuilder.range().onField(SearchFileds.MAX_EXP).below(maxExp).createQuery())
								.must(queryBuilder.keyword().onField(SearchFileds.JOB_ROLE).matching(role)
										.createQuery())
								.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true)
										.createQuery())
								.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE)
										.matching(VacancyState.APPROVED).createQuery())
								.createQuery();
						queryList.add(query);
					});
				}))));
	}

}
