package com.gloqr.service;

import java.util.List;

import com.gloqr.entities.Vacancy;
import com.gloqr.entities.VacancyApplicant;

public interface NotificationService {

	void sendVacancyAppliedNotification(Vacancy vacancy,VacancyApplicant vacancyApplicant);

	void sendVacancyVerificationSummaryNotification(String smeId,List<Vacancy> vacancies);

	void sendSeekerShortlistedNotification(VacancyApplicant vacancyApplicant,String vacancyTitleAndUrl);
}
