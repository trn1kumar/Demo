package com.gloqr.service.filter;

import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;

import org.apache.lucene.search.Query;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.SortField;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.DatabaseRetrievalMethod;
import org.hibernate.search.query.ObjectLookupMethod;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.constants.VacancyState;
import com.gloqr.constants.FilterConstant.SearchFileds;
import com.gloqr.entities.Vacancy;

@Service("vacActiveApprovedFilter")
public class FilterByInitialCriteriaServiceImpl implements VacancyFilterService {

	@Autowired
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public List<Vacancy> filter(Set<String> filterParams, int firstResult, int maxResult) {
		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(Vacancy.class).get();
		FullTextQuery fullTextQuery = createFullTextQuery(fullTextEntityManager, queryBuilder, filterParams,
				firstResult, maxResult);

		return fullTextQuery.getResultList();
	}

	@Override
	public FullTextQuery createFullTextQuery(FullTextEntityManager fullTextEntityManager, QueryBuilder queryBuilder,
			Set<String> filterParams, int firstResult, int maxResult) {

		// 'filterParams' can be null.not used here

		Query query = queryBuilder.bool()
				.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true).createQuery())
				.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE).matching(VacancyState.APPROVED)
						.createQuery())
				.createQuery();

		FullTextQuery fullTextQuery = fullTextEntityManager.createFullTextQuery(query, Vacancy.class);
		Sort sort = new Sort(new SortField(SearchFileds.CREATION_DATE, SortField.Type.LONG, true));
		fullTextQuery.setSort(sort);
		fullTextQuery.initializeObjectsWith(ObjectLookupMethod.SECOND_LEVEL_CACHE, DatabaseRetrievalMethod.QUERY);

		fullTextQuery.setFirstResult(firstResult).setMaxResults(maxResult);

		return fullTextQuery;
	}

}
