package com.gloqr.service;

public interface CountManageService {

	void updateVacanciesCount(String smeUuid, String jwtTokenString);

}
