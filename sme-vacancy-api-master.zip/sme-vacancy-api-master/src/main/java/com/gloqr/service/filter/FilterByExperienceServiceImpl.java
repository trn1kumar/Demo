package com.gloqr.service.filter;

import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;

import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.SortField;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.DatabaseRetrievalMethod;
import org.hibernate.search.query.ObjectLookupMethod;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.constants.FilterConstant.SearchFileds;
import com.gloqr.constants.VacancyState;
import com.gloqr.entities.Vacancy;

@Service(value = "vacExpFilter")
public class FilterByExperienceServiceImpl implements VacancyFilterService {

	@Autowired
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public List<Vacancy> filter(Set<String> experienceFilterParams, int firstResult, int maxResult) {
		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(Vacancy.class).get();
		
		FullTextQuery fullTextQuery=createFullTextQuery(fullTextEntityManager, queryBuilder, experienceFilterParams, firstResult, maxResult);
		return fullTextQuery.getResultList();
	}

	@Override
	public FullTextQuery createFullTextQuery(FullTextEntityManager fullTextEntityManager, QueryBuilder queryBuilder,
			Set<String> experienceFilterParams, int firstResult, int maxResult) {
		List<Query> queryList = new LinkedList<>();

		experienceFilterParams.forEach(exp -> {

			String[] strs = exp.split("-");
			double minExp = Double.parseDouble(strs[0]);
			double maxExp = Double.parseDouble(strs[1]);

			Query query = queryBuilder.bool()
					.must(queryBuilder.range().onField(SearchFileds.MIN_EXP).above(minExp).createQuery())
					.must(queryBuilder.range().onField(SearchFileds.MAX_EXP).below(maxExp).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_ACTIVE).matching(true).createQuery())
					.must(queryBuilder.keyword().onField(SearchFileds.VACANCY_STATE).matching(VacancyState.APPROVED)
							.createQuery())
					.createQuery();
			queryList.add(query);

		});
		BooleanQuery.Builder booleanQuery = new BooleanQuery.Builder();
		queryList.forEach(q -> booleanQuery.add(q, BooleanClause.Occur.SHOULD));

		FullTextQuery fullTextQuery = fullTextEntityManager.createFullTextQuery(booleanQuery.build(), Vacancy.class);
		fullTextQuery.initializeObjectsWith(ObjectLookupMethod.SECOND_LEVEL_CACHE, DatabaseRetrievalMethod.QUERY);
		Sort sort = new Sort(new SortField(SearchFileds.CREATION_DATE, SortField.Type.LONG, true));
		fullTextQuery.setSort(sort);
		
		fullTextQuery.setFirstResult(firstResult).setMaxResults(maxResult);
		
		return fullTextQuery;
	}

}
