package com.gloqr.service;

import com.gloqr.dto.UserDto;

public interface UserService {

	public UserDto getUser(String userId);
}
