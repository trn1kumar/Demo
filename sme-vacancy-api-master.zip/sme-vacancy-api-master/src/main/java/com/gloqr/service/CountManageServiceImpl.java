package com.gloqr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.gloqr.dao.VacancyDao;
import com.gloqr.model.ItemCountUpdate;
import com.gloqr.rest.endpoint.SmeEndPoint;

@Service
public class CountManageServiceImpl implements CountManageService {

	@Autowired
	private VacancyDao vacancyDao;

	@Autowired
	private SmeEndPoint smeEndPoint;

	@Override
	@Async("taskExecutor")
	public void updateVacanciesCount(String smeUuid, String jwtTokenString) {
		ItemCountUpdate countUpdateData = vacancyDao.getCounts(smeUuid);
		smeEndPoint.updateVacanciesCount(smeUuid, countUpdateData, jwtTokenString);
	}

}
