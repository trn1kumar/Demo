package com.gloqr.service.filter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.constants.FilterConstant;
import com.gloqr.constants.VacancyState;
import com.gloqr.dto.SMEDto;
import com.gloqr.entities.Vacancy;
import com.gloqr.entities.filter.FilterByExperience;
import com.gloqr.entities.filter.FilterBySalary;
import com.gloqr.exception.CustomException;
import com.gloqr.model.filter.FilterByLocation;
import com.gloqr.model.filter.FilterByRole;
import com.gloqr.model.filter.FilterBySme;
import com.gloqr.repository.SMEVacancyRepository;
import com.gloqr.repository.VacancyFilterByExperienceRepo;
import com.gloqr.repository.VacancyFilterBySalaryRepo;
import com.gloqr.util.PaginationUtil;

@Service
public class FilterServiceImpl implements FilterService {

	@Autowired
	private SMEVacancyRepository smeVacancyRepository;

	@Autowired
	private VacancyFilterBySalaryRepo salaryFilterRepo;

	@Autowired
	private VacancyFilterByExperienceRepo experienceFilterRepo;

	@Autowired
	private PaginationUtil paginationUtil;

	@Autowired
	@Qualifier("vacActiveApprovedFilter")
	private VacancyFilterService filterByInitialCriteria;

	@Autowired
	@Qualifier("vacSmeFilter")
	private VacancyFilterService filterBySme;

	@Autowired
	@Qualifier("vacLocationFilter")
	private VacancyFilterService filterByLocation;

	@Autowired
	@Qualifier("vacRoleFilter")
	private VacancyFilterService filterByJobRole;

	@Autowired
	@Qualifier("vacSalaryFilter")
	private VacancyFilterService filterBySalary;

	@Autowired
	@Qualifier("vacExpFilter")
	private VacancyFilterService filterByExperience;

	@Autowired
	private CombineFilterServiceImpl combineFilter;

	private static final String REPLACE_WITH = "";

	@Override
	public Map<String, Object> getFilter(Map<String, SMEDto> smes, Set<String> smesFilterParam,
			Set<String> locationsFilterParam, Set<String> jobRolesFilterParam, Set<String> salariesFilterParam,
			Set<String> experiencesFilterParam) {

		HashMap<String, Object> filters = new HashMap<>();

		List<FilterBySme> filterBySmes = getFilterForSMEs(smes, smesFilterParam);
		List<FilterByLocation> filterByLocations = getFilterForLocations(locationsFilterParam);
		List<FilterByRole> filterByJobRoles = getFilterForJobRoles(jobRolesFilterParam);

		List<FilterBySalary> filterBySalaries = getFilterForSalary(salariesFilterParam);
		List<FilterByExperience> filterByExps = getFilterForExperience(experiencesFilterParam);

		// sort byTotalVacacniescount
		Collections.sort(filterBySmes);
		Collections.sort(filterByLocations);
		Collections.sort(filterByJobRoles);

		/*
		 * sort bySelected. comparing object 'o2' with object 'o1' for get selected
		 * result first (i.e descending order).
		 */
		Collections.sort(filterBySmes,
				(FilterBySme o1, FilterBySme o2) -> Boolean.compare(o2.isSelected(), o1.isSelected()));
		Collections.sort(filterByLocations,
				(FilterByLocation o1, FilterByLocation o2) -> Boolean.compare(o2.isSelected(), o1.isSelected()));
		Collections.sort(filterByJobRoles,
				(FilterByRole o1, FilterByRole o2) -> Boolean.compare(o2.isSelected(), o1.isSelected()));

		Collections.sort(filterBySalaries,
				(FilterBySalary o1, FilterBySalary o2) -> Boolean.compare(o2.isSelected(), o1.isSelected()));

		Collections.sort(filterByExps,
				(FilterByExperience o1, FilterByExperience o2) -> Boolean.compare(o2.isSelected(), o1.isSelected()));

		filters.put("SME", filterBySmes);
		filters.put("Location", filterByLocations);
		filters.put("Job_Role", filterByJobRoles);
		filters.put("Salary", filterBySalaries);
		filters.put("Experience", filterByExps);
		return filters;

	}

	private List<FilterByExperience> getFilterForExperience(Set<String> experiencesFilterParam) {
		List<FilterByExperience> filterByExps = new ArrayList<>();
		Double maxExp = smeVacancyRepository.getMaxExperience(true, VacancyState.APPROVED);
		Double minExp = smeVacancyRepository.getMinExperience(true, VacancyState.APPROVED);

		if (maxExp != null && minExp != null) {
			experiencesFilterParam = replaceFormattedExperience(experiencesFilterParam);
			List<FilterByExperience> filterByExps1 = experienceFilterRepo.findAll();
			for (int i = 0; i < filterByExps1.size(); i++) {
				FilterByExperience e = filterByExps1.get(i);
				String formattedExperience = e.getFormattedExperience().replaceFirst(FilterConstant.EXP_YEAR,
						REPLACE_WITH);
				Long totalCount1 = smeVacancyRepository.sumOfTotalVacanciesByExperienceAndActiveAndState(e.getMinExp(),
						e.getMaxExp(), true, VacancyState.APPROVED);
				if (totalCount1 != null)
					e.setTotalVacancies(totalCount1.intValue());
				if (experiencesFilterParam != null && experiencesFilterParam.contains(formattedExperience))
					e.setSelected(true);

				if (e.getMaxExp() == maxExp || e.getMaxExp() > maxExp) {
					filterByExps.add(e);
					break;
				}
				filterByExps.add(e);
			}

		}
		filterByExps = filterByExps.stream().filter(exp -> exp.getTotalVacancies() != 0).collect(Collectors.toList());
		return filterByExps;
	}

	private List<FilterBySalary> getFilterForSalary(Set<String> salariesFilterParam) {
		Long maxSalary = smeVacancyRepository.getMaxSalary(true, VacancyState.APPROVED);
		Long minSalary = smeVacancyRepository.getMinSalary(true, VacancyState.APPROVED);
		List<FilterBySalary> filterBySalaries = new ArrayList<>();
		if (maxSalary != null && minSalary != null) {
			salariesFilterParam = replaceFormattedSalary(salariesFilterParam);
			List<FilterBySalary> filterBySalariesList = salaryFilterRepo.findAll();
			long diff = (maxSalary / FilterConstant.SALARY_CURRENCY);
			for (int i = 0; i < filterBySalariesList.size(); i++) {
				FilterBySalary f = filterBySalariesList.get(i);
				String formattedSalary = f.getFormattedSalary().replaceFirst(FilterConstant.SALARY_CURRENCY_UNIT,
						REPLACE_WITH);

				Long totalCount = smeVacancyRepository.sumOfTotalVacanciesBySalaryAndActiveAndState(
						f.getMinSalary() * FilterConstant.SALARY_CURRENCY,
						f.getMaxSalary() * FilterConstant.SALARY_CURRENCY, true, VacancyState.APPROVED);

				if (totalCount != null)
					f.setTotalVacancies(totalCount.intValue());
				if (salariesFilterParam != null && salariesFilterParam.contains(formattedSalary))
					f.setSelected(true);

				if (f.getMaxSalary() == diff || f.getMaxSalary() > diff) {
					filterBySalaries.add(f);
					break;
				}
				filterBySalaries.add(f);

			}

		}
		filterBySalaries = filterBySalaries.stream().filter(salary -> salary.getTotalVacancies() != 0)
				.collect(Collectors.toList());

		return filterBySalaries;
	}

	private List<FilterByRole> getFilterForJobRoles(Set<String> jobRolesFilterParam) {
		Set<String> jobRoles = smeVacancyRepository.getActiveAndApprovedVacanciesJobRoles(true, VacancyState.APPROVED);
		List<FilterByRole> filterByJobRoles = new ArrayList<>();

		jobRoles.stream().filter(Objects::nonNull).forEach(jobRole -> {
			int totalCount = smeVacancyRepository.sumOfTotalVacanciesByJobRoleAndActiveAndState(jobRole, true,
					VacancyState.APPROVED);
			FilterByRole roleFilters = new FilterByRole();
			roleFilters.setJobRole(jobRole);
			roleFilters.setTotalVacancies(totalCount);
			if (jobRolesFilterParam != null && jobRolesFilterParam.contains(jobRole))
				roleFilters.setSelected(true);

			filterByJobRoles.add(roleFilters);
		});

		return filterByJobRoles;
	}

	private List<FilterByLocation> getFilterForLocations(Set<String> locationsFilterParam) {
		Set<String> locations = smeVacancyRepository.getActiveAndApprovedVacanciesJobLocations(true,
				VacancyState.APPROVED);
		List<FilterByLocation> filterByLocations = new ArrayList<>();
		locations.stream().filter(Objects::nonNull).forEach(location -> {
			int totalCount = smeVacancyRepository.sumOfTotalVacanciesByLocationAndActiveAndState(location, true,
					VacancyState.APPROVED);
			FilterByLocation locationFilters = new FilterByLocation();
			locationFilters.setLocation(location);
			locationFilters.setTotalVacancies(totalCount);
			if (locationsFilterParam != null && locationsFilterParam.contains(location))
				locationFilters.setSelected(true);

			filterByLocations.add(locationFilters);
		});

		return filterByLocations;
	}

	private List<FilterBySme> getFilterForSMEs(Map<String, SMEDto> smes, Set<String> smesFilterParam) {
		List<FilterBySme> filterBySmes = new ArrayList<>();

		smes.forEach((smeId, sme) -> {
			int count = smeVacancyRepository.sumOfTotalVacanciesBySmeUuidAndVacancyActiveTrueAndVacancyState(smeId,
					VacancyState.APPROVED);
			FilterBySme smeFilters = new FilterBySme();
			smeFilters.setSmeName(sme.getSmeName());
			smeFilters.setTotalVacancies(count);
			smeFilters.setsUuid(smeId);
			if (smesFilterParam != null && smesFilterParam.contains(smeId))
				smeFilters.setSelected(true);

			filterBySmes.add(smeFilters);
		});
		return filterBySmes;
	}

	@Override
	public List<Vacancy> appyFilter(Set<String> smes, Set<String> locations, Set<String> jobRoles, Set<String> salaries,
			Set<String> experiences, int page) {

		int size = paginationUtil.getPageSize();
		// page started from '1'.
		int firstResult = page * size;
		int maxResult = size;

		List<Vacancy> vacancies = null;

		salaries = replaceFormattedSalary(salaries);
		experiences = replaceFormattedExperience(experiences);

		int count = getNonNullFilterParamsCount(smes, locations, jobRoles, salaries, experiences);

		if (count > 1)
			vacancies = combineFilter.applyCombineFilterResult(smes, locations, jobRoles, salaries, experiences,
					firstResult, maxResult);
		else {
			if (smes != null) {
				vacancies = filterBySme.filter(smes, firstResult, maxResult);
			} else if (locations != null) {
				vacancies = filterByLocation.filter(locations, firstResult, maxResult);
			} else if (jobRoles != null) {
				vacancies = filterByJobRole.filter(jobRoles, firstResult, maxResult);
			} else if (salaries != null) {
				vacancies = filterBySalary.filter(salaries, firstResult, maxResult);
			} else if (experiences != null) {
				vacancies = filterByExperience.filter(experiences, firstResult, maxResult);
			} else {
				vacancies = filterByInitialCriteria.filter(null, firstResult, maxResult);
			}
		}

		if (page == 0) {
			// if 0 page request then return result with out throw exception
			return vacancies;
		} else if (vacancies != null && !vacancies.isEmpty()) {
			return vacancies;
		} else {
			throw new CustomException("No More Vacancies Available", HttpStatus.NOT_FOUND);
		}
	}

	private int getNonNullFilterParamsCount(Set<String> smes, Set<String> locations, Set<String> jobRoles,
			Set<String> salaries, Set<String> experiences) {
		int count = 0;
		if (smes != null)
			++count;
		if (locations != null)
			++count;
		if (jobRoles != null)
			++count;
		if (salaries != null)
			++count;
		if (experiences != null)
			++count;
		return count;

	}

	private Set<String> replaceFormattedSalary(Set<String> salariesFilterParam) {
		if (salariesFilterParam != null)
			salariesFilterParam = salariesFilterParam.stream()
					.map(salary -> salary.replaceFirst(FilterConstant.SALARY_CURRENCY_UNIT, REPLACE_WITH))
					.collect(Collectors.toSet());
		return salariesFilterParam;
	}

	private Set<String> replaceFormattedExperience(Set<String> experiencesFilterParam) {
		if (experiencesFilterParam != null)
			experiencesFilterParam = experiencesFilterParam.stream()
					.map(exp -> exp.replaceFirst(FilterConstant.EXP_YEAR, REPLACE_WITH)).collect(Collectors.toSet());
		return experiencesFilterParam;
	}

}
