package com.gloqr.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.dao.MasterDataDao;
import com.gloqr.entities.master.Course;
import com.gloqr.entities.master.CourseCategory;
import com.gloqr.entities.master.IndustrialArea;
import com.gloqr.entities.master.IndustrialJobRole;
import com.gloqr.entities.master.Specialization;
import com.gloqr.repository.master.IndustrialAreaRepository;
import com.gloqr.repository.master.JobRoleRepository;

@Service
public class MasterDataServiceImpl implements MasterDataService {

	@Autowired
	JobRoleRepository jobRoleRepository;

	@Autowired
	IndustrialAreaRepository industrialAreaRepository;

	@Autowired
	MasterDataDao masterDataDao;

	@Override
	public List<IndustrialArea> getAllIndustrialArea() {
		return masterDataDao.getAllIndustrialArea();
	}

	@Override
	public List<IndustrialJobRole> getJobRoles(String industrialAreaId) {
		return masterDataDao.getJobRolesByIndustrialAreaId(industrialAreaId);
	}


	@Override
	public List<IndustrialJobRole> getAllJobRoles() {
		return masterDataDao.getJobRoles();
	}

	@Override
	public List<CourseCategory> getCourseCategories() {
		return masterDataDao.getAllCourseCategories();
	}

	@Override
	public List<Course> getCourses(String courseCategoryId) {
		return masterDataDao.getCoursesByCategory(courseCategoryId);
	}

	@Override
	public List<Specialization> getSpecializations(String courseId) {
		return masterDataDao.getSpecializationsByCourse(courseId);
	}

	@Override
	public void saveIndustrialArea(IndustrialArea industrialArea) {
		masterDataDao.saveIndustrialArea(industrialArea);
	}

}
