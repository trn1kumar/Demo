package com.gloqr.service;

import java.util.Map;
import java.util.Set;

import com.gloqr.dto.SMEDto;

public interface SmeService {

	public SMEDto getSME(String sUuid);

	public Map<String, SMEDto> getSMEs(Set<String> smeIds);
}
