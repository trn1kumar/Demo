package com.gloqr.service;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gloqr.dao.JobSeekerDao;
import com.gloqr.dao.MasterDataDao;
import com.gloqr.entities.jobseekers.CareerProfile;
import com.gloqr.entities.jobseekers.EducationalDetail;
import com.gloqr.entities.jobseekers.ExperienceDetail;
import com.gloqr.entities.jobseekers.JobSeekerAddress;
import com.gloqr.entities.jobseekers.JobSeekerProfile;
import com.gloqr.entities.jobseekers.JobSeekerResume;
import com.gloqr.entities.master.Course;
import com.gloqr.entities.master.IndustrialJobRole;
import com.gloqr.entities.master.Specialization;
import com.gloqr.exception.CustomException;
import com.gloqr.util.UuidUtil;

@Service
public class JobSeekerServiceImpl implements JobSeekerService {

	@Autowired
	JobSeekerDao jobSeekerDao;

	@Autowired
	VacancyService vacancyService;

	@Autowired
	MasterDataDao masterDataDao;

	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public void createJobSeekerProfile(JobSeekerProfile jobSeekerProfile) {

		jobSeekerProfile.setJobSeekerProfileUuid(UuidUtil.getUuid());
		jobSeekerDao.saveJobSeekerProfile(jobSeekerProfile);

	}

	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public void updateJobSeekerProfile(JobSeekerProfile jobSeekerProfile) {
		JobSeekerProfile existSeekerProfile = null;
		if (jobSeekerProfile.getJobSeekerProfileUuid() != null) {
			existSeekerProfile = jobSeekerDao.getJobSeekerProfileByIdAndUuid(jobSeekerProfile.getJobSeekerProfileId(),
					jobSeekerProfile.getJobSeekerProfileUuid());
			if (existSeekerProfile.getCurrentSalary() != null) {
				jobSeekerProfile.getCurrentSalary().setSalaryId(existSeekerProfile.getCurrentSalary().getSalaryId());

			} else {
				jobSeekerProfile.getCurrentSalary().setSalaryId(UuidUtil.getUuid());
			}

			JobSeekerAddress existAddress = existSeekerProfile.getJobSeekerAddress();

			if (existAddress != null) {
				jobSeekerProfile.getJobSeekerAddress().setJobSeekerAddressId(existAddress.getJobSeekerAddressId());
			}

			if (existSeekerProfile.getTotalExperience() != null) {
				jobSeekerProfile.getTotalExperience()
						.setExperienceId(existSeekerProfile.getTotalExperience().getExperienceId());
			} else {
				jobSeekerProfile.getTotalExperience().setExperienceId(UuidUtil.getUuid());

			}

			jobSeekerProfile.setCareerProfile(existSeekerProfile.getCareerProfile());
			jobSeekerProfile.setEducationalDetail(existSeekerProfile.getEducationalDetail());
			jobSeekerProfile.setSkillSets(existSeekerProfile.getSkillSets());
			jobSeekerDao.saveJobSeekerProfile(jobSeekerProfile);

		} else {
			throw new CustomException("JobSeekerProfileUuid can not be null or empty. Updation Failed.",
					HttpStatus.BAD_REQUEST);
		}

	}

	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public void addEducationalDetail(String jobSeekerId, EducationalDetail educationalDetail) {

		JobSeekerProfile seekerProfile = jobSeekerDao.getJobSeekerProfile(jobSeekerId);
		this.manageQualification(educationalDetail);
		educationalDetail.setEducationalDetailUuid(UuidUtil.getUuid());
		seekerProfile.setEducationalDetail(educationalDetail);
		jobSeekerDao.saveJobSeekerProfile(seekerProfile);
	}

	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public void updateEducationalDetail(String jobSeekerId, EducationalDetail educationalDetail) {

		String educationalDetailUuid = educationalDetail.getEducationalDetailUuid();

		if (educationalDetailUuid != null) {
			boolean bool = jobSeekerDao.isJobSeekerHasGivenEducationalDetail(jobSeekerId, educationalDetailUuid);
			if (bool) {
				EducationalDetail existDetail = jobSeekerDao.getEducationalDetail(educationalDetailUuid);
				this.manageQualification(educationalDetail);
				educationalDetail.setEducationalDetailId(existDetail.getEducationalDetailId());
				jobSeekerDao.saveEducationalDetail(educationalDetail);

			} else {
				throwUnthorizedException();
			}
		} else {
			throw new CustomException("educational detailId can not be null for updation. Updation failed!!!",
					HttpStatus.BAD_REQUEST);
		}

	}

	private void manageQualification(EducationalDetail educationalDetail) {
		Specialization spec = educationalDetail.getQualificationSpecialization();
		Course course = educationalDetail.getQualificationCourse();
		if ((spec == null && course == null) || (spec != null && course != null)) {
			throw new CustomException(
					"both specialization and course can not be null or non null at a same time.either 'specialization' or 'course' required",
					HttpStatus.BAD_REQUEST);
		}

		if (spec != null) {
			Specialization existSpec = masterDataDao.getSpecializationById(spec.getSpecializationId());
			educationalDetail.setQualificationSpecialization(existSpec);
		} else {
			Course existCourse = masterDataDao.getCourseById(course.getCourseId());
			educationalDetail.setQualificationCourse(existCourse);
		}
	}

	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public void addExperienceDetail(String jobSeekerId, ExperienceDetail experienceDetail) {

		validateExperienceDetail(experienceDetail);

		experienceDetail.setExperienceDetailUuid(UuidUtil.getUuid());

		JobSeekerProfile seekerProfile = jobSeekerDao.getJobSeekerProfile(jobSeekerId);

		List<ExperienceDetail> experienceDetails = seekerProfile.getExperienceDetails();

		if (experienceDetail.isCurrentlyWorking())
			manageExistingCurrentExperience(experienceDetail.getStartDate(), experienceDetails);

		IndustrialJobRole jobRole = masterDataDao.getJobRole(experienceDetail.getJobRole().getJobRoleUuid());
		experienceDetail.setJobRole(jobRole);
		experienceDetails.add(experienceDetail);
		jobSeekerDao.saveJobSeekerProfile(seekerProfile);
	}

	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public void updateExperienceDetail(String jobSeekerId, ExperienceDetail experienceDetail) {

		ExperienceDetail existExpDetail = null;

		String experienceDetailId = experienceDetail.getExperienceDetailUuid();
		if (experienceDetailId != null) {
			boolean bool = jobSeekerDao.isJobSeekerHasGivenExperienceDetail(jobSeekerId, experienceDetailId);
			if (bool) {
				validateExperienceDetail(experienceDetail);

				if (experienceDetail.isCurrentlyWorking()) {
					existExpDetail = manageCurrentlyWorkingExpAndGetExistExpDetail(jobSeekerId, experienceDetail);
				} else {
					existExpDetail = jobSeekerDao.getExperienceDetail(experienceDetailId);
				}
				experienceDetail.setExperienceDetailId(existExpDetail.getExperienceDetailId());

				IndustrialJobRole existExpJobRole = existExpDetail.getJobRole();
				String jobRoleId = experienceDetail.getJobRole().getJobRoleUuid();

				if (existExpJobRole.getJobRoleUuid().equals(jobRoleId)) {
					// if job role not changed then set existing job role
					experienceDetail.setJobRole(existExpJobRole);
				} else {
					// if job role changed then get new updated job role and set to experience
					IndustrialJobRole jobRole = masterDataDao.getJobRole(jobRoleId);
					experienceDetail.setJobRole(jobRole);
				}
				jobSeekerDao.saveExperienceDetail(experienceDetail);

			} else {
				throwUnthorizedException();
			}

		} else {
			throw new CustomException("experience detailId can not be null for updation. Updation failed!!!",
					HttpStatus.BAD_REQUEST);
		}
	}

	private ExperienceDetail manageCurrentlyWorkingExpAndGetExistExpDetail(String jobSeekerId,
			ExperienceDetail experienceDetail) {

		ExperienceDetail existExpDetail = null;

		List<ExperienceDetail> existExpDetails = jobSeekerDao.getExperienceDetailsBySeekerId(jobSeekerId);

		// filter updating experience and return
		Optional<ExperienceDetail> existExpOpt = existExpDetails.stream()
				.filter(exp -> exp.getExperienceDetailUuid().equals(experienceDetail.getExperienceDetailUuid()))
				.findFirst();

		if (existExpOpt.isPresent()) {
			existExpDetail = existExpOpt.get();
			manageExistingCurrentExperience(experienceDetail.getStartDate(), existExpDetails);
		} else {
			throw new CustomException("No Experience found for " + experienceDetail.getExperienceDetailUuid(),
					HttpStatus.NOT_FOUND);
		}

		return existExpDetail;
	}

	private void manageExistingCurrentExperience(Date endDate, List<ExperienceDetail> experienceDetails) {
		/*
		 * if updating or new Experience is currently working then make existing
		 * currently experience false and save it
		 */

		if (!experienceDetails.isEmpty()) {
			experienceDetails.forEach(exp -> {
				if (exp.isCurrentlyWorking()) {
					exp.setCurrentlyWorking(false);
					exp.setNoticePeriod(null);
					exp.setEndDate(endDate);
					jobSeekerDao.saveExperienceDetail(exp);
				}
			});
		}
	}

	private void validateExperienceDetail(ExperienceDetail experienceDetail) {

		/*
		 * if Experience is current then Notice period should not be null and experience
		 * end date should be null and if Experience is not current then Notice period
		 * should be null and experience end date should be not null otherwise throw
		 * exception
		 */

		if ((experienceDetail.isCurrentlyWorking() && experienceDetail.getNoticePeriod() != null
				&& experienceDetail.getEndDate() == null)
				|| (!experienceDetail.isCurrentlyWorking() && experienceDetail.getNoticePeriod() == null
						&& experienceDetail.getEndDate() != null)) {
			// Nothing to do
		} else {
			throw new CustomException(
					"Combination of Currently Working,Experience EndDate and Notice Period are not valid",
					HttpStatus.BAD_REQUEST);
		}
	}

	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public void addCareerDetail(String jobSeekerId, CareerProfile careerProfile) {

		careerProfile.setCareerProfileDetailUuid(UuidUtil.getUuid());
		careerProfile.getExpectedSalary().setSalaryId(UuidUtil.getUuid());
		IndustrialJobRole jobRole = masterDataDao.getJobRole(careerProfile.getJobRole().getJobRoleUuid());
		careerProfile.setJobRole(jobRole);
		JobSeekerProfile seekerProfile = jobSeekerDao.getJobSeekerProfile(jobSeekerId);
		seekerProfile.setCareerProfile(careerProfile);
		jobSeekerDao.saveJobSeekerProfile(seekerProfile);
	}

	@Override
	public void updateCareerDetail(String jobSeekerId, CareerProfile careerProfile) {

		String careerProfileId = careerProfile.getCareerProfileDetailUuid();

		if (careerProfileId != null) {

			if (jobSeekerDao.isJobSeekerHasGivenCareerProfile(jobSeekerId, careerProfileId)) {
				CareerProfile existCareerProfile = jobSeekerDao.getCareerProfileByUuid(careerProfileId);
				careerProfile.setCareerProfileDetailId(existCareerProfile.getCareerProfileDetailId());

				IndustrialJobRole existJobRole = existCareerProfile.getJobRole();
				String jobRoleUuid = careerProfile.getJobRole().getJobRoleUuid();

				if (existJobRole.getJobRoleUuid().equals(jobRoleUuid)) {
					careerProfile.setJobRole(existJobRole);
				} else {
					IndustrialJobRole newJobRole = masterDataDao
							.getJobRole(careerProfile.getJobRole().getJobRoleUuid());
					careerProfile.setJobRole(newJobRole);
				}

				careerProfile.getExpectedSalary().setSalaryId(existCareerProfile.getExpectedSalary().getSalaryId());

				jobSeekerDao.saveCareerProfileInfo(careerProfile);

			} else {
				throwUnthorizedException();
			}

		} else {
			throw new CustomException("careerProfile Id can not be null", HttpStatus.BAD_REQUEST);
		}

	}

	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public void addSkillSets(String jobSeekerId, List<String> skillSets) {
		JobSeekerProfile seekerProfile = jobSeekerDao.getJobSeekerProfile(jobSeekerId);
		seekerProfile.setSkillSets(skillSets);
		jobSeekerDao.saveJobSeekerProfile(seekerProfile);
	}

	@Override
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public JobSeekerProfile getJobSeekerProfile(String jobSeekerId) {
		JobSeekerProfile jobSeekerProfile = jobSeekerDao.getJobSeekerProfile(jobSeekerId);
		checkAndSetCourseDetail(jobSeekerProfile.getEducationalDetail());
		List<ExperienceDetail> expDetails = jobSeekerProfile.getExperienceDetails();
		Collections.sort(expDetails);
		return jobSeekerProfile;
	}
	
	
	@Override
	@Transactional(readOnly = true, rollbackFor = Exception.class)
	public JobSeekerProfile getJobSeekerProfileByUuid(String jobSeekerProfileUuid) {
		
		JobSeekerProfile jobSeekerProfile = jobSeekerDao.getJobSeekerProfileByUuid(jobSeekerProfileUuid);
		checkAndSetCourseDetail(jobSeekerProfile.getEducationalDetail());
		List<ExperienceDetail> expDetails = jobSeekerProfile.getExperienceDetails();
		Collections.sort(expDetails);
		return jobSeekerProfile;
	}
	
	
	public void checkAndSetCourseDetail(EducationalDetail educationDetail) {
		if (educationDetail != null && educationDetail.getQualificationSpecialization() != null) {
			Course c = educationDetail.getQualificationSpecialization().getCourse();
			Course c1 = new Course();
			c1.setCourseId(c.getCourseId());
			c1.setCourseName(c.getCourseName());
			educationDetail.setQualificationCourse(c1);
		}
	}

	private void throwUnthorizedException() {
		throw new CustomException("Unathorized Access for updation", HttpStatus.UNAUTHORIZED);
	}

	@Override
	public String updateResume(String resumeUrl, String resumeFileName, String jobSeekerId) {

		String existResumeUrl = null;

		JobSeekerProfile jobSeekerProfile = jobSeekerDao.getJobSeekerProfile(jobSeekerId);
		JobSeekerResume jobSeekerResume = jobSeekerProfile.getResume();

		if (jobSeekerResume != null) {
			existResumeUrl = jobSeekerProfile.getResume().getResumeUrl();
			jobSeekerResume.setResumeUrl(resumeUrl);
			jobSeekerResume.setResumeFileName(resumeFileName);
			jobSeekerProfile.setResume(jobSeekerResume);

		} else {
			JobSeekerResume newJobSeekerResume = new JobSeekerResume();

			newJobSeekerResume.setResumeFileName(resumeFileName);

			newJobSeekerResume.setResumeUrl(resumeUrl);

			jobSeekerProfile.setResume(newJobSeekerResume);
		}

		jobSeekerDao.saveJobSeekerProfile(jobSeekerProfile);
		return existResumeUrl;

	}

	

}
