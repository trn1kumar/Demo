package com.gloqr.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gloqr.constants.CreditType;
import com.gloqr.constants.VacancyConstants.BooleanClause;
import com.gloqr.constants.VacancyState;
import com.gloqr.dao.MasterDataDao;
import com.gloqr.dao.VacancyDao;
import com.gloqr.entities.Vacancy;
import com.gloqr.entities.master.IndustrialJobRole;
import com.gloqr.exception.CustomException;
import com.gloqr.model.PricingRequest;
import com.gloqr.model.PublishData;
import com.gloqr.model.VacancyStateChange;
import com.gloqr.rest.endpoint.PricingEndpoint;

@Service
public class GloqrAdminServiceImpl implements GloqrAdminService {

	private static final Logger log = LogManager.getLogger();

	@Autowired
	private VacancyDao vacancyDao;

	@Autowired
	private VacancyService vacancyService;

	@Autowired
	private PricingEndpoint pricingEnpoint;

	public static final String DATE_FORMAT = "E, dd MMM yyyy HH:mm:ss";

	@Autowired
	private MasterDataDao masterDataDao;

	@Override
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public List<Vacancy> approveOrRejectVacancies(VacancyStateChange smeAndVacancyInfo) {
		List<Vacancy> saveForBatchUpdate = new ArrayList<>();
		String userId = smeAndVacancyInfo.getUserId();
		String smeId = smeAndVacancyInfo.getSmeId();

		for (PublishData vacancy : smeAndVacancyInfo.getVacanciesInfo()) {
			this.changeState(vacancy, saveForBatchUpdate);
		}
		this.updateStates(userId, smeId, saveForBatchUpdate);

		return saveForBatchUpdate;
	}

	private void changeState(PublishData vacancy, List<Vacancy> saveForBatchUpdate) {
		String vacancyId = vacancy.getId();
		VacancyState state = vacancy.getState();

		try {

			Vacancy existVacancy = vacancyService.getVacancyByUuid(vacancyId);
			if (existVacancy.isVacancyActive() && existVacancy.getVacancyState().equals(VacancyState.PENDING)) {
				existVacancy.setVacancyState(state);

				if (state.equals(VacancyState.REJECTED)) {
					existVacancy.setVacancyActive(BooleanClause.FALSE);
				} else if (StringUtils.isNotBlank(vacancy.getJobRoleUuid()) && state.equals(VacancyState.APPROVED)) {
					IndustrialJobRole industrialJobRole = masterDataDao.getJobRole(vacancy.getJobRoleUuid());

					existVacancy.setJobRole(industrialJobRole);
				}

				if (vacancy.getFeedbackMessage() != null) {
					String dateAndAction = "[ Date:-" + new SimpleDateFormat(DATE_FORMAT).format(new Date())
							+ " Action:-" + state + " ] ";
					vacancy.setFeedbackMessage(dateAndAction.concat(vacancy.getFeedbackMessage()));

					if (existVacancy.getFeedbackMessage() != null) {
						existVacancy.setFeedbackMessage(
								existVacancy.getFeedbackMessage().concat("| " + vacancy.getFeedbackMessage()));
					} else {
						existVacancy.setFeedbackMessage(vacancy.getFeedbackMessage());
					}
				}

				saveForBatchUpdate.add(existVacancy);
			}

		} catch (CustomException e) {
			log.info("Exception:- {}", e.getErrorMessage());
		}

	}

	private void updateStates(String userId, String smeId, List<Vacancy> saveForBatchUpdate) {
		if (!saveForBatchUpdate.isEmpty()) {
			vacancyService.saveVacancies(saveForBatchUpdate);

			long rejectedVacanciesCount = saveForBatchUpdate.stream()
					.filter(vacancy -> vacancy.getVacancyState().equals(VacancyState.REJECTED)).count();

			if (rejectedVacanciesCount > 0) {
				PricingRequest pricingRequest = new PricingRequest();
				pricingRequest.setType(CreditType.JOB_POSTING);
				pricingRequest.setCredits(rejectedVacanciesCount);
				pricingRequest.setAction("CREDIT");
				pricingRequest.setsUuid(smeId);
				pricingRequest.setUserUUID(userId);
				pricingEnpoint.updateCredits(pricingRequest);
			}
		} else {
			throw new CustomException("No Valid Data Available for Change Vacancies State", HttpStatus.BAD_REQUEST);
		}

	}

	@Override
	public List<Vacancy> getPendingVacanciesBySmeId(String smeId) {
		return vacancyDao.getVacanciesBySmeUuidAndVacancyStateAndVacancyActiveTrue(smeId, VacancyState.PENDING);
	}
}
