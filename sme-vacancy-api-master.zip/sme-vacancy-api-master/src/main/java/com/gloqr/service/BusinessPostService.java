package com.gloqr.service;

import com.gloqr.entities.Vacancy;

public interface BusinessPostService {

	public void createBusinessPost(Vacancy vacancy);

}
