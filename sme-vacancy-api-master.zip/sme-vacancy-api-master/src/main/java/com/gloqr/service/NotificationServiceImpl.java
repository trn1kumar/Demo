package com.gloqr.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.gloqr.configuration.NotificationPropertyValues;

import com.gloqr.constants.VacancyState;
import com.gloqr.dto.SMEDto;
import com.gloqr.entities.ShortListedInfo;
import com.gloqr.entities.Vacancy;
import com.gloqr.entities.VacancyApplicant;
import com.gloqr.entities.jobseekers.ExperienceDetail;
import com.gloqr.entities.jobseekers.JobSeekerProfile;
import com.gloqr.exception.CustomException;
import com.gloqr.model.notification.EmailEvent;
import com.gloqr.model.notification.SmsEvent;
import com.gloqr.rest.endpoint.NotificationEndPoint;
import com.gloqr.rest.endpoint.SmeEndPoint;

@Service
public class NotificationServiceImpl implements NotificationService {

	private Logger log = LogManager.getLogger();

	@Autowired
	private SmeService smeService;

	@Autowired
	private NotificationEndPoint notificationEndpoint;

	@Autowired
	private SmeEndPoint smeEndPoint;

	@Autowired
	private TemplateEngine templateEngine;

	@Autowired
	private NotificationPropertyValues propertyValues;

	@Override
	@Async("taskExecutor")
	public void sendVacancyVerificationSummaryNotification(String smeId, List<Vacancy> vacancies) {

		try {
			SMEDto sme = smeService.getSME(smeId);
			String emailId = sme.getContactEmail();

			if (emailId != null) {

				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd 'at' hh:mm:ss a");
				Date date = new Date();

				List<Vacancy> approvedVacancies = new ArrayList<>();
				List<Vacancy> rejectedVacancies = new ArrayList<>();

				vacancies.parallelStream().forEach(vacancy -> {
					if (vacancy.getVacancyState().equals(VacancyState.APPROVED))
						approvedVacancies.add(vacancy);
					else if (vacancy.getVacancyState().equals(VacancyState.REJECTED))
						rejectedVacancies.add(vacancy);
				});

				Context context = new Context();
				context.setVariable("smeName", sme.getSmeName());
				context.setVariable("approvedVacancies", approvedVacancies);
				context.setVariable("rejectedVacancies", rejectedVacancies);
				context.setVariable("totalApproved", approvedVacancies.size());
				context.setVariable("totalRejected", rejectedVacancies.size());
				context.setVariable("approvedDateTime", formatter.format(date));
				context.setVariable("homeUrl", propertyValues.getBaseUrl());
				context.setVariable("contentServerUrl", propertyValues.getContentServerUrl());
				

				String mailPage = templateEngine.process("vacancyVerifyNotification.html", context);
				String mailSub = propertyValues.getVacanciesVerificationEmailSub();
				EmailEvent emailEvent = new EmailEvent(emailId, mailSub, mailPage, null);
				sendNotification(null, emailEvent);
			} else {
				throw new CustomException("email id can't be empty for send notification.", HttpStatus.BAD_REQUEST);
			}

		} catch (Exception e) {
			log.info("can't send notification job. Exception:- {}", e.getMessage());
		}

	}

	@Override
	@Async("taskExecutor")
	public void sendSeekerShortlistedNotification(VacancyApplicant vacancyApplicant,
			String vacancyTitleAndUrlAndSmeId) {

		String strs[] = vacancyTitleAndUrlAndSmeId.split(",");
		String vacancyTitle = strs[0];
		String vacancyUrl = strs[1];
		String smeId = strs[2];

		SMEDto smeDto = smeEndPoint.getSME(smeId);

		SmsEvent smsEvent = null;
		EmailEvent emailEvent = null;

		String mobileNumber = vacancyApplicant.getApplicant().getMobileNumber();
		String emailId = vacancyApplicant.getApplicant().getEmailId();

		checkMobileOrEmailAvailable(mobileNumber, emailId);

		if (emailId != null) {
			Context context = new Context();
			JobSeekerProfile jobSeekerDetails = vacancyApplicant.getApplicant();
			ShortListedInfo shortListedInfo = vacancyApplicant.getShortListedInfo();

			if (jobSeekerDetails != null) {
				context.setVariable("vacancyDetailPageUrl", propertyValues.getVacancyDetailPageUrl());
				context.setVariable("fullName", jobSeekerDetails.getFullName());
				context.setVariable("vacancyTitle", vacancyTitle);
				context.setVariable("interviewDate", shortListedInfo.getInterviewDate());
				context.setVariable("message", shortListedInfo.getDescription());
				context.setVariable("smeName", smeDto.getSmeName());

			}

			String mailPage = templateEngine.process("ShortListJobSeeker.html", context);

			String emailSubject = propertyValues.getSeekerShortlistedEmailSubject();

			emailEvent = new EmailEvent(emailId, emailSubject, mailPage, null);
		}

		if (mobileNumber != null) {
			String smsMsg = propertyValues.getSeekerShortlistedSmsMsg().replace("{vacancyTitle}", vacancyTitle)
					.replace("{emailId}", emailId);
			smsEvent = new SmsEvent(mobileNumber, smsMsg);
			smsEvent.setMobileNo(mobileNumber);
		}
		sendNotification(smsEvent, emailEvent);

	}

	@Override
	@Async("taskExecutor")
	public void sendVacancyAppliedNotification(Vacancy vacancy, VacancyApplicant vacancyApplicant) {

		SmsEvent smsEvent = null;
		EmailEvent emailEvent = null;
		String emailAttachment = null;
		String mobileNumber = vacancy.getVacancyDetail().getContactMobileNumber();
		String emailId = vacancy.getVacancyDetail().getContactEmail();
		String vacancyTitle = vacancy.getVacancyTitle();
		String sUuid = vacancy.getSmeUuid();
		String jobSeekerName = null;
		String phoneNumber = null;
		String email = null;

		SMEDto smeDto = smeEndPoint.getSME(vacancy.getSmeUuid());

		checkMobileOrEmailAvailable(mobileNumber, emailId);

		if (emailId != null) {
			Context context = new Context();
			JobSeekerProfile jobSeekerDetails = vacancyApplicant.getApplicant();

			if (jobSeekerDetails != null) {

				jobSeekerName = vacancyApplicant.getApplicant().getFullName();
				phoneNumber = vacancyApplicant.getApplicant().getMobileNumber();
				email = vacancyApplicant.getApplicant().getEmailId();
				if (vacancyApplicant.getApplicant().getResume() != null) {
					emailAttachment = vacancyApplicant.getApplicant().getResume().getResumeUrl();
				}

				if (jobSeekerDetails.getTotalExperience() != null) {
					context.setVariable("year", jobSeekerDetails.getTotalExperience().getYear());
					context.setVariable("month", jobSeekerDetails.getTotalExperience().getMonth());
				}
				if (jobSeekerDetails.getCurrentSalary() != null) {
					context.setVariable("salary", jobSeekerDetails.getCurrentSalary().getSalary());
					context.setVariable("salaryType", jobSeekerDetails.getCurrentSalary().getSalaryType());
				}

				if (jobSeekerDetails.getJobSeekerAddress() != null) {
					context.setVariable("userCity", jobSeekerDetails.getJobSeekerAddress().getCurrentCity());
					context.setVariable("userState", jobSeekerDetails.getJobSeekerAddress().getCurrentState());
				}

				List<ExperienceDetail> expDetails = jobSeekerDetails.getExperienceDetails();

				if (expDetails != null && !expDetails.isEmpty()) {
					Optional<ExperienceDetail> currentlyWorkingDetailOpt = expDetails.parallelStream()
							.filter(exp -> exp.isCurrentlyWorking()).findFirst();
					if (currentlyWorkingDetailOpt.isPresent()) {
						context.setVariable("currentExp", currentlyWorkingDetailOpt.get());
						context.setVariable("currentJobRole", currentlyWorkingDetailOpt.get().getJobRole());
					}

				}

				if (jobSeekerDetails.getEducationalDetail() != null) {
					context.setVariable("education",
							jobSeekerDetails.getEducationalDetail().getQualificationCourse().getCourseName());
				}

			} else {
				jobSeekerName = vacancyApplicant.getCustomApplicant().getFullName();
				phoneNumber = vacancyApplicant.getCustomApplicant().getContactNumber();
				email = vacancyApplicant.getCustomApplicant().getEmailId();

				if (vacancyApplicant.getCustomApplicant().getResumeUrl() != null) {
					emailAttachment = vacancyApplicant.getCustomApplicant().getResumeUrl();
				}
			}

			context.setVariable("vacancyDetailPageUrl", propertyValues.getVacancyDetailPageUrl());

			context.setVariable("fullName", jobSeekerName);
			context.setVariable("emailId", email);
			context.setVariable("phoneNumber", phoneNumber);
			context.setVariable("sUuid", sUuid);
			context.setVariable("smeName", smeDto.getSmeName());
			context.setVariable("vacancyTitle", vacancyTitle);

			String mailPage = templateEngine.process("VacancyApplied.html", context);

			String emailSubject = propertyValues.getVacancyAppiledEmailSubject().replace("{vacancyTitle}", vacancyTitle)
					.replace("{jobSeekerName}", jobSeekerName);

			emailEvent = new EmailEvent(emailId, emailSubject, mailPage, emailAttachment);

		}
		if (mobileNumber != null) {
			String smsMsg = propertyValues.getVacancyAppiledSmsMsg().replace("{vacancyTitle}", vacancyTitle)
					.replace("{jobSeekerName}", jobSeekerName).replace("{sUuid}", sUuid);
			smsEvent = new SmsEvent(mobileNumber, smsMsg);
			smsEvent.setMobileNo(mobileNumber);
		}
		sendNotification(smsEvent, emailEvent);
	}

	private void sendNotification(SmsEvent smsEvent, EmailEvent emailEvent) {
		List<Object> events = new ArrayList<>();

		if (smsEvent != null)
			events.add(smsEvent);
		if (emailEvent != null)
			events.add(emailEvent);

		try {
			events.parallelStream().forEach(e -> notificationEndpoint.sendNotification(e));
		} catch (Exception e) {
			log.error("failed to send notifications.Exception:- " + e.getMessage());
		}
	}

	private void checkMobileOrEmailAvailable(String mobileNum, String emailId) {
		if (mobileNum == null && emailId == null) {
			throw new CustomException("'mobile no'. and 'email' both are null.required either 'mobile no' or 'email'.",
					HttpStatus.BAD_REQUEST);
		}
	}

}
