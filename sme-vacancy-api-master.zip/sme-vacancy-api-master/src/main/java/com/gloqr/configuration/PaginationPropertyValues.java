package com.gloqr.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.gloqr.constants.PropertyNames;

@Configuration
public class PaginationPropertyValues {

	@Value(PropertyNames.TOP_VACANCIES_PAGE_SIZE)
	private int topVacanciesPageSize;

	@Value(PropertyNames.NORMAL_PAGE_SIZE)
	private int normalPageSize;

	@Value(PropertyNames.MOBILE_PAGE_SIZE)
	private int mobilePageSize;

	@Value(PropertyNames.TABLET_PAGE_SIZE)
	private int tabletPageSize;

	public int getTopVacanciesPageSize() {
		return topVacanciesPageSize;
	}

	public void setTopVacanciesPageSize(int topVacanciesPageSize) {
		this.topVacanciesPageSize = topVacanciesPageSize;
	}

	public int getNormalPageSize() {
		return normalPageSize;
	}

	public void setNormalPageSize(int normalPageSize) {
		this.normalPageSize = normalPageSize;
	}

	public int getMobilePageSize() {
		return mobilePageSize;
	}

	public void setMobilePageSize(int mobilePageSize) {
		this.mobilePageSize = mobilePageSize;
	}

	public int getTabletPageSize() {
		return tabletPageSize;
	}

	public void setTabletPageSize(int tabletPageSize) {
		this.tabletPageSize = tabletPageSize;
	}

}
