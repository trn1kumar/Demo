package com.gloqr.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.gloqr.constants.PropertyNames;

@Configuration
public class NotificationPropertyValues {

	@Value(PropertyNames.BASE_URL)
	private String baseUrl;

	@Value(PropertyNames.CONTENT_SERVER_URL)
	private String contentServerUrl;

	@Value(PropertyNames.VACANCY_APPILED_NOTIFI_SMS_MSG)
	private String vacancyAppiledSmsMsg;

	@Value(PropertyNames.VACANCY_APPILED_NOTIFI_EMAIL_MSG)
	private String vacancyAppiledEmailSubject;

	@Value(PropertyNames.VACANCY_DETAIL_PAGE_URL)
	private String vacancyDetailPageUrl;

	@Value(PropertyNames.NOTIFY_VACANCIES_VERIFICATIONS_EMAIL_SUB)
	private String vacanciesVerificationEmailSub;

	@Value(PropertyNames.SEEKER_SHORTLISTED_NOTIFI_SMS_MSG)
	private String seekerShortlistedSmsMsg;

	@Value(PropertyNames.SEEKER_SHORTLISTED_NOTIFI_EMAIL_MSG)
	private String seekerShortlistedEmailSubject;

	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	public String getContentServerUrl() {
		return contentServerUrl;
	}

	public void setContentServerUrl(String contentServerUrl) {
		this.contentServerUrl = contentServerUrl;
	}

	public String getSeekerShortlistedEmailSubject() {
		return seekerShortlistedEmailSubject;
	}

	public void setSeekerShortlistedEmailSubject(String seekerShortlistedEmailSubject) {
		this.seekerShortlistedEmailSubject = seekerShortlistedEmailSubject;
	}

	public String getSeekerShortlistedSmsMsg() {
		return seekerShortlistedSmsMsg;
	}

	public void setSeekerShortlistedSmsMsg(String seekerShortlistedSmsMsg) {
		this.seekerShortlistedSmsMsg = seekerShortlistedSmsMsg;
	}

	public String getVacanciesVerificationEmailSub() {
		return vacanciesVerificationEmailSub;
	}

	public void setVacanciesVerificationEmailSub(String vacanciesVerificationEmailSub) {
		this.vacanciesVerificationEmailSub = vacanciesVerificationEmailSub;
	}

	public String getVacancyAppiledSmsMsg() {
		return vacancyAppiledSmsMsg;
	}

	public void setVacancyAppiledSmsMsg(String vacancyAppiledSmsMsg) {
		this.vacancyAppiledSmsMsg = vacancyAppiledSmsMsg;
	}

	public String getVacancyAppiledEmailSubject() {
		return vacancyAppiledEmailSubject;
	}

	public void setVacancyAppiledEmailSubject(String vacancyAppiledEmailSubject) {
		this.vacancyAppiledEmailSubject = vacancyAppiledEmailSubject;
	}

	public String getVacancyDetailPageUrl() {
		return vacancyDetailPageUrl;
	}

	public void setVacancyDetailPageUrl(String vacancyDetailPageUrl) {
		this.vacancyDetailPageUrl = vacancyDetailPageUrl;
	}

}
