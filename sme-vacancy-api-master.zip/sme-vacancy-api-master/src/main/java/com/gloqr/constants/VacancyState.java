package com.gloqr.constants;

public enum VacancyState {
	PENDING, APPROVED, REJECTED
}
