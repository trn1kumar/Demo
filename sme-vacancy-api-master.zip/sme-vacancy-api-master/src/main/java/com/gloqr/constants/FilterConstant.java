package com.gloqr.constants;

public class FilterConstant {

	private FilterConstant() {
		throw new IllegalStateException("FilterConstant class.can't initiate");
	}

	public static final String SALARY_CURRENCY_UNIT = " Lakhs";
	public static final long SALARY_CURRENCY = 100000;
	public static final String EXP_YEAR = " yrs";

	public class FacetConstant {
		private FacetConstant() {
			throw new IllegalStateException("FacetConstant class.can't initiate");
		}

		public static final String SME_ID_FACET = "smeIdFacet";
		public static final String LOCATIONS_FACET = "locationFacet";
		public static final String JOB_ROLE_FACET = "jobRoleFacet";

		public static final String SME_ID_FACET_REQ = "smeIdFacetingReq";
		public static final String LOCATIONS_FACET_REQ = "locationFacetingReq";
		public static final String JOB_ROLE_FACET_REQ = "jobRoleFacetingReq";
	}

	public class SearchFileds {
		private SearchFileds() {
			throw new IllegalStateException("SearchFileds class.can't initiate");
		}

		public static final String VACANCY_STATE = "vacancyState";
		public static final String VACANCY_ACTIVE = "vacancyActive";
		public static final String SME_ID = "smeUuid";

		public static final String MIN_SALARY = "minSalary";
		public static final String MAX_SALARY = "maxSalary";

		public static final String MIN_EXP = "minExp";
		public static final String MAX_EXP = "maxExp";

		public static final String LOCATIONS = "locations";
		public static final String JOB_ROLE = "jobRole.jobRole";

		public static final String CREATION_DATE = "creationDate";

	}

}
