package com.gloqr.constants;

public class VacancyConstants {

	private VacancyConstants() {
		throw new IllegalStateException("SMEVacancyConstants class");
	}

	public class FileDirectory {
		public static final String RESUME_DIR = "users/{userId}/resume";
		public static final String CUSTOM_APPLICANT_RESUME_DIR = "resume/{vacancyId}";
	}

	public class RoleAccess {
		public static final String SME_ADMIN = "hasAnyRole('SME-ADMIN')";
		public static final String GLOQR_ADMIN = "GLOQR-SUPER-ADMIN";
		public static final String USER = "hasAnyRole('USER')";
		public static final String SME_ADMIN_AND_USER = "hasAnyRole('USER','SME-ADMIN')";
		public static final String ALL_ROLES = "hasAnyRole('USER','GLOQR-SUPER-ADMIN','SME-ADMIN')";
	}


	public class BooleanClause {
		public static final boolean TRUE = true;
		public static final boolean FALSE = false;
	}

}
