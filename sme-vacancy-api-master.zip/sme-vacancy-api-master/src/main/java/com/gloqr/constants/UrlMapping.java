package com.gloqr.constants;

public class UrlMapping {

	private UrlMapping() {
		throw new IllegalStateException("UrlMapping class.can't initiate");
	}

	public static final String VACANCY_ROOT_API = "/api/vacancies";// root api
	public static final String JOB_SEEKER_ROOT_API = "/api/jobseekers";// root api
	public static final String GLOQR_ADMIN_API = VACANCY_ROOT_API + "/gloqr-admin";//gloqr admin root api

	// SMEVacancyControllerUrls
	public static final String SAVE = "/";// create vacancy
	public static final String VACANCIES = "/jobs";// get active vacancies
	public static final String VACANCIES_BY_SME_EDIT_MODE = "/sme-vacancies";// get sme vacancies for edit mode
	public static final String VACANCIES_BY_SME_VIEW_MODE = "/view/{smeId}/sme";// get sme vacancies for view mode
	public static final String VACANCY_EDIT_MODE = "/{vacancyUuid}/vacancy";// get single vacancy for edit mode
	public static final String VACANCY_VIEW_MODE = "/view/sme/{vacancyUuid}/vacancy";// get single vacancy for
																								// view mode
	public static final String APPLY = "/{vacancyUuid}/apply";// apply for vacancy
	public static final String CUSTOM_APPLY = "/{vacancyUuid}/custom-apply";// custom apply for vacancy

	public static final String APPLICANTS = "/{vacancyUuid}/applicants";// get vacancy applicants
	public static final String GET_SINGLE_APPLICANT = "/{applicantUuid}/applicant";
	
	
	public static final String DELETE_VACANCY = "/{vacancyUuid}";
	public static final String GET_TOP_JOBS = "/top";
	public static final String SHORTLISTED = "/shortlist";
	
	//SMEVacancyFilterURls
	public static final String MENU_BAR_FILTER = "/menu/filter";

	// MasterDataControllerUrls
	public static final String JOB_ROLES = "/job-roles";
	public static final String INDUSTRIAL_AREA = "/industrial-areas";

	public static final String GET_CATEGORIES = "/course-categories";
	public static final String GET_CATEGORIES_WITH_COURSES = "/course-categories/courses";

	public static final String GET_COURSES = "/courses";
	public static final String GET_SPECIALIZATIONS = "/specializations";

	// SMEVacancyAdminControllerUrls
	public static final String SME_VACANCIES = "/{smeId}";
	public static final String MODIFY_VACANCY = "/modify-state-of-vacancy";

	// JobSeekerProfileControllerUrls
	public static final String JOB_SEEKER_PROFILE = "/profile";
	public static final String JOB_SEEKER_BASIC_PROFILE = "/basic-profile-info";

	public static final String JOB_SEEKER_UPLOAD_RESUME = "/upload-resume";
	public static final String JOB_SEEKER_DELETE_RESUME = "/resume";

	public static final String EDUCATIONAL_DETAIL = "/educational-detail";
	public static final String EXPERIENCE_DETAIL = "/experience-detail";
	public static final String CAREER_DETAIL = "/career-detail";

	public static final String SKILL_SETS = "/skill-sets";
	
	public static final String JOB_SEEKER_VIEW_MODE = "/{jobSeekerProfileUuid}/profile";// get single seeker for


}
