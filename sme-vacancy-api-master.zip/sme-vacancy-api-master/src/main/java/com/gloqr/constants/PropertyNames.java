package com.gloqr.constants;

public class PropertyNames {

	private PropertyNames() {
		throw new IllegalStateException("PropertyNames class.can't initiate");
	}

	// PAGINATION PROPERTY-NAMES
	public static final String TOP_VACANCIES_PAGE_SIZE = "${top-vacancies-page-size}";
	public static final String NORMAL_PAGE_SIZE = "${normal-page-size}";
	public static final String MOBILE_PAGE_SIZE = "${mobile-page-size}";
	public static final String TABLET_PAGE_SIZE = "${tablet-page-size}";

	// NOTIFICATION PROPERTY-NAMES
	public static final String BASE_URL = "${base-url}";
	public static final String CONTENT_SERVER_URL = "${content-server.localized-url}";
	public static final String VACANCY_APPILED_NOTIFI_SMS_MSG = "${notify.vacancy_appiled_notifi_sms_msg}";
	public static final String VACANCY_APPILED_NOTIFI_EMAIL_MSG = "${notify.vacancy_appiled_notifi_email_msg}";
	public static final String NOTIFY_VACANCIES_VERIFICATIONS_EMAIL_SUB = "${notify.vacancies.verifications.email-sub}";
	public static final String VACANCY_DETAIL_PAGE_URL = "${vacancy.detail-url}";
	public static final String SEEKER_SHORTLISTED_NOTIFI_SMS_MSG = "${notify.seeker_shortlisted_notifi_sms_msg}";
	public static final String SEEKER_SHORTLISTED_NOTIFI_EMAIL_MSG = "${notify.seeker_shortlisted_notifi_email_msg}";
}
