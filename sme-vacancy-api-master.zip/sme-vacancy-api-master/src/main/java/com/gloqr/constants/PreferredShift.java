package com.gloqr.constants;

public enum PreferredShift {
	DAY, NIGHT, FLEXIBLE, MID_DAY;
}
