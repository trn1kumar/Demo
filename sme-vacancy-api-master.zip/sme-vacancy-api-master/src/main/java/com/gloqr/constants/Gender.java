package com.gloqr.constants;

public enum Gender {
	MALE, FEMALE, OTHER
}
