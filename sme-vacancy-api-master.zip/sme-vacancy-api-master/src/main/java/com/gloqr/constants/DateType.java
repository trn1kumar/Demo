package com.gloqr.constants;

public enum DateType {

	DAY, MONTH, YEAR
}
