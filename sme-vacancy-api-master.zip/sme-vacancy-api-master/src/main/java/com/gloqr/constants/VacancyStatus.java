package com.gloqr.constants;

public enum VacancyStatus {
	ACTIVE, DEACTIVE
}
