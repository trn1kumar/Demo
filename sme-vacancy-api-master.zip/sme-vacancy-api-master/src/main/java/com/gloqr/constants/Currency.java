package com.gloqr.constants;

public enum Currency {

	INR, DOLLAR
}
