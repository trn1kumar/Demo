package com.gloqr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
@EnableCaching
@PropertySource(value = { "file:${location}/sme_vacancy.properties" })
public class SmeJobPostingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmeJobPostingApplication.class, args);
	}

}
