package com.gloqr.dao;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.constants.VacancyState;
import com.gloqr.entities.Vacancy;
import com.gloqr.exception.CustomException;
import com.gloqr.model.ItemCountUpdate;
import com.gloqr.repository.SMEVacancyRepository;
import com.gloqr.util.PaginationUtil;

@Service
public class VacancyDaoImpl implements VacancyDao {

	@Autowired
	private SMEVacancyRepository vacancyRepo;

	public static final String SORT_FILED_NAME = "creationDate";

	@Autowired
	private PaginationUtil paginationUtils;

	@Override
	public Vacancy saveVacancy(Vacancy vacancy) {
		try {
			vacancy = vacancyRepo.save(vacancy);
		} catch (Exception e) {
			throw new CustomException("error occured while vacancy saving. Message:- " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
		return vacancy;
	}

	@Override
	@Caching(evict = { @CacheEvict(value = { "topVacancies" }, allEntries = true) })
	public void saveVacancies(List<Vacancy> vacancies) {
		try {
			vacancyRepo.saveAll(vacancies);
		} catch (Exception e) {
			throw new CustomException("Exception in :: saveVacancies(),  message:  " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@Override
	public Vacancy getVacancyByUuidAndSmeId(String vacancyUuid, String smeUuid) {
		Vacancy vacancy = vacancyRepo.findByVacancyUuidAndSmeUuid(vacancyUuid, smeUuid);
		if (vacancy == null)
			throw new CustomException("Vacancy not found with vacancyId " + vacancyUuid + " and smeId " + smeUuid,
					HttpStatus.NOT_FOUND);
		return vacancy;
	}

	@Override
	public Vacancy getSingleVacancy(String vacancyUuid) {
		Vacancy vacancy = vacancyRepo.findByVacancyUuid(vacancyUuid);
		if (vacancy == null)
			throw new CustomException("Vacancy Not Found with " + vacancyUuid, HttpStatus.NOT_FOUND);
		return vacancy;
	}

	@Override
	public Vacancy getVacancyByUuidAndActiveAndState(String vacancyUuid) {
		Vacancy vacancy = vacancyRepo.findByVacancyUuidAndVacancyActiveAndVacancyState(vacancyUuid, true,
				VacancyState.APPROVED);
		if (vacancy == null)
			throw new CustomException("Vacancy Not Found with " + vacancyUuid, HttpStatus.NOT_FOUND);
		return vacancy;
	}

	@Override
	public Set<String> getSmeUuidOfVacancyActiveTrueAndVacancyState(VacancyState state) {
		Set<String> smeIds = vacancyRepo.getSmeUuidOfVacancyActiveTrueAndVacancyState(state);
		if (smeIds.isEmpty())
			throw new CustomException("No Vacancies Available", HttpStatus.NOT_FOUND);
		return smeIds;
	}

	@Override
	public List<Vacancy> getVacanciesBySmeUuidAndVacancyStateAndVacancyActiveTrue(String smeId, VacancyState state) {
		List<Vacancy> vacancies = vacancyRepo.findBySmeUuidAndVacancyStateAndVacancyActiveTrue(smeId, state,Sort.by(Direction.DESC, SORT_FILED_NAME));

		if (vacancies.isEmpty()) {
			throw new CustomException("No Vacancies Available for " + smeId, HttpStatus.NOT_FOUND);
		}

		return vacancies;
	}

	@Override
	public List<Vacancy> getVacanciesBySmeId(String smeUuid, boolean pendingVacancies) {
		List<Vacancy> vacancy = null;

		if (pendingVacancies) {
			vacancy = vacancyRepo.findBySmeUuidAndVacancyStateNotIn(smeUuid, VacancyState.APPROVED);
		} else {
			vacancy = vacancyRepo.findBySmeUuid(smeUuid, Sort.by(Direction.DESC, SORT_FILED_NAME));
		}

		if (vacancy != null && !vacancy.isEmpty())
			return vacancy;

		else
			throw new CustomException("No Vacancies found for sme id " + smeUuid, HttpStatus.NOT_FOUND);
	}

	@Override
	public List<Vacancy> getTopVacancies() {

		int size = paginationUtils.getTopVacanciesPageSize();

		List<Vacancy> vacancieslist = vacancyRepo.findByVacancyStateAndVacancyActiveTrue(VacancyState.APPROVED,
				PageRequest.of(0, size, Direction.DESC, SORT_FILED_NAME));

		if (vacancieslist != null && !vacancieslist.isEmpty()) {
			return vacancieslist;
		}

		else
			throw new CustomException("No Vacancies Available", HttpStatus.NOT_FOUND);
	}

	@Override
	public ItemCountUpdate getCounts(String smeUuid) {
		return vacancyRepo.getCounts(smeUuid);
	}

	@Override
	public String getVacancyTitleAndUrlAndSmeId(Long applicantId) {

		return vacancyRepo.getVacancyTitleAndUrlAndSmeId(applicantId);
	}

}
