package com.gloqr.dao;

import java.util.List;
import java.util.Set;

import com.gloqr.constants.VacancyState;
import com.gloqr.entities.Vacancy;
import com.gloqr.model.ItemCountUpdate;

public interface VacancyDao {

	Vacancy saveVacancy(Vacancy vacancy);

	void saveVacancies(List<Vacancy> vacancies);

	Vacancy getSingleVacancy(String vacancyUuid);

	Vacancy getVacancyByUuidAndActiveAndState(String vacancyUuid);

	Vacancy getVacancyByUuidAndSmeId(String vacancyUuid, String smeUuid);

	Set<String> getSmeUuidOfVacancyActiveTrueAndVacancyState(VacancyState state);

	List<Vacancy> getVacanciesBySmeUuidAndVacancyStateAndVacancyActiveTrue(String smeId, VacancyState state);

	List<Vacancy> getVacanciesBySmeId(String smeUuid, boolean pendingVacancies);

	List<Vacancy> getTopVacancies();

	ItemCountUpdate getCounts(String smeUuid);
	
	String getVacancyTitleAndUrlAndSmeId(Long applicantId);

}
