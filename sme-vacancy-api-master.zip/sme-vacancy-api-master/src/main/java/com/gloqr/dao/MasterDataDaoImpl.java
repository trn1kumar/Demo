package com.gloqr.dao;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gloqr.entities.master.Course;
import com.gloqr.entities.master.CourseCategory;
import com.gloqr.entities.master.IndustrialArea;
import com.gloqr.entities.master.IndustrialJobRole;
import com.gloqr.entities.master.Specialization;
import com.gloqr.exception.CustomException;
import com.gloqr.repository.master.CourseCategoryRepo;
import com.gloqr.repository.master.CourseRepo;
import com.gloqr.repository.master.IndustrialAreaRepository;
import com.gloqr.repository.master.JobRoleRepository;
import com.gloqr.repository.master.SpecializationRepo;
import com.gloqr.util.UuidUtil;

@Repository
public class MasterDataDaoImpl implements MasterDataDao {

	@Autowired
	JobRoleRepository jobRoleRepository;

	@Autowired
	IndustrialAreaRepository industrialAreaRepository;

	@Autowired
	SpecializationRepo specRepo;

	@Autowired
	CourseRepo courseRepo;

	@Autowired
	CourseCategoryRepo courseCategoryRepo;

	@Override
	public void saveIndustrialArea(IndustrialArea industrialArea) {
		try {
			industrialArea.setAreaUuid(UuidUtil.getUuid().substring(5, 12));
			if (industrialArea.getJobRoles() != null) {
				industrialArea.getJobRoles().forEach(jobRole -> {
					jobRole.setJobRoleUuid(UuidUtil.getUuid().substring(5, 12));
					jobRole.setIndustrialArea(industrialArea);
				});

			}
			industrialAreaRepository.save(industrialArea);
		} catch (Exception e) {
			throw new CustomException("Exception in saveIndustrialArea() { }. message:  " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR,e);
		}

	}

	@Override
	public List<IndustrialJobRole> getJobRoles() {
		List<IndustrialJobRole> roles = jobRoleRepository.findAll();
		if (roles != null && !roles.isEmpty())
			return roles;
		else
			throw new CustomException("No Roles Found", HttpStatus.NOT_FOUND);
	}

	@Override
	public List<CourseCategory> getAllCourseCategories() {
		List<CourseCategory> categories = courseCategoryRepo.findAll();
		if (categories != null && !categories.isEmpty())
			return categories;
		else
			throw new CustomException("No Course Categories Available", HttpStatus.NOT_FOUND);
	}

	@Override
	public List<Course> getCoursesByCategory(String courseCategoryId) {

		List<Course> courses = courseCategoryRepo.findCoursesByCategoryId(courseCategoryId);
		if (courses != null && !courses.isEmpty())
			return courses;
		else
			throw new CustomException("No Courses Available in Course Category  " + courseCategoryId,
					HttpStatus.NOT_FOUND);
	}

	@Override
	public List<Course> getCoursesByIds(Set<String> coursesId) {
		List<Course> courses = courseRepo.findByCourseIdIn(coursesId);
		if (courses != null && !courses.isEmpty()) {
			return courses;
		} else {
			throw new CustomException("No Courses found in " + courses, HttpStatus.NOT_FOUND);
		}
	}

	@Override
	@Transactional(readOnly = true)
	public Course getCourseById(String courseId) {
		Course course = courseRepo.findByCourseId(courseId);
		if (course != null) {
			return course;
		} else {
			throw new CustomException("No Course found for id " + courseId, HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public List<Specialization> getSpecializationsByCourse(String courseId) {
		List<Specialization> specializations = courseRepo.findSpecializationsByCourseId(courseId);
		if (specializations != null && !specializations.isEmpty())
			return specializations;
		else
			throw new CustomException("No specializations Available in course:  " + courseId, HttpStatus.NOT_FOUND);
	}

	@Override
	public IndustrialJobRole getJobRole(String jobRoleUuid) {
		IndustrialJobRole jobRole = jobRoleRepository.findByJobRoleUuid(jobRoleUuid);

		if (jobRole == null)
			throw new CustomException("Job Role Not found with id " + jobRoleUuid, HttpStatus.NOT_FOUND);
		return jobRole;
	}

	@Override
	public Specialization getSpecializationById(String specId) {
		Optional<Specialization> specOpt = specRepo.findById(specId);
		if (specOpt.isPresent()) {
			return specOpt.get();
		} else {
			throw new CustomException("Specialization Not found with id " + specId, HttpStatus.NOT_FOUND);
		}

	}

	@Override
	@Transactional(readOnly = true)
	public List<Specialization> getSpecializationsByIds(Set<String> specsId) {

		List<Specialization> specs = specRepo.findBySpecializationIdIn(specsId);
		if (specs != null && !specs.isEmpty()) {
			return specs;
		} else {
			throw new CustomException("No Specializations found in " + specsId, HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public List<IndustrialArea> getAllIndustrialArea() {
		List<IndustrialArea> industrialAreas = null;
		industrialAreas = industrialAreaRepository.findAll();

		if (industrialAreas != null && !industrialAreas.isEmpty()) {
			return industrialAreas;
		} else {
			throw new CustomException("No IndustrialAreas Found", HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public List<IndustrialJobRole> getJobRolesByIndustrialAreaId(String industrialAreaId) {
		List<IndustrialJobRole> roles = null;

		roles = industrialAreaRepository.findJobRolesByIndustrialAreaId(industrialAreaId);

		if (roles != null && !roles.isEmpty()) {
			return roles;
		} else {
			throw new CustomException("Industrial Job Roles Not Found", HttpStatus.NOT_FOUND);
		}
	}

}
