package com.gloqr.dao;

import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.entities.jobseekers.CareerProfile;
import com.gloqr.entities.jobseekers.EducationalDetail;
import com.gloqr.entities.jobseekers.ExperienceDetail;
import com.gloqr.entities.jobseekers.JobSeekerProfile;
import com.gloqr.exception.CustomException;
import com.gloqr.repository.jobseekers.CareerProfileRepo;
import com.gloqr.repository.jobseekers.EducationalDetailRepo;
import com.gloqr.repository.jobseekers.ExperienceDetailRepo;
import com.gloqr.repository.jobseekers.JobSeekerRepository;

@Repository
public class JobSeekerDaoImpl implements JobSeekerDao {

	@Autowired
	private JobSeekerRepository jobSeekerRepo;

	@Autowired
	EducationalDetailRepo educationalDetailRepo;

	@Autowired
	ExperienceDetailRepo experienceDetailRepo;

	@Autowired
	CareerProfileRepo careerProfileRepo;

	Logger logger = LogManager.getLogger();

	@Override
	public void saveJobSeekerProfile(JobSeekerProfile jobSeekerProfile) {
		try {
			jobSeekerRepo.save(jobSeekerProfile);
		} catch (Exception e) {
			logger.error(e);
			throw new CustomException("Exception in saveJobSeekerProfile( ){ }. message: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
	}

	@Override
	public void saveEducationalDetail(EducationalDetail educationalDetail) {
		try {
			educationalDetailRepo.save(educationalDetail);
		} catch (Exception e) {
			throw new CustomException("Exception in saveEducationalDetail( ){ }. message: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

	}

	@Override
	public void saveExperienceDetail(ExperienceDetail experienceDetail) {
		try {
			experienceDetailRepo.save(experienceDetail);
		} catch (Exception e) {
			throw new CustomException("Exception in saveExperienceDetail ( ) { }. message:  " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
	}

	@Override
	public void saveCareerProfileInfo(CareerProfile careerProfile) {
		try {
			careerProfileRepo.save(careerProfile);
		} catch (Exception e) {
			throw new CustomException("Exception in saveCareerProfileInfo ( ) { }. message:  " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR,e);
		}
	}

	@Override
	public JobSeekerProfile getJobSeekerProfile(String seekerProfileId) {
		Optional<JobSeekerProfile> jobSeekerProfileOpt = jobSeekerRepo.findById(seekerProfileId);
		if (jobSeekerProfileOpt.isPresent()) {
			return jobSeekerProfileOpt.get();
		} else {
			throw new CustomException("Job Seeker Profile not found with id " + seekerProfileId, HttpStatus.NOT_FOUND);
		}
	}
	
	@Override
	public JobSeekerProfile getJobSeekerProfileByUuid(String jobSeekerProfileUuid) {
		Optional<JobSeekerProfile> jobSeekerProfileOpt = jobSeekerRepo.findByJobSeekerProfileUuid(jobSeekerProfileUuid);
		if (jobSeekerProfileOpt.isPresent()) {
			return jobSeekerProfileOpt.get();
		} else {
			throw new CustomException("Job Seeker Profile not found with id " + jobSeekerProfileUuid, HttpStatus.NOT_FOUND);
		}
	}
	
	@Override
	public JobSeekerProfile getJobSeekerProfileByIdAndUuid(String seekerProfileId, String seekerProfileUuid) {
		Optional<JobSeekerProfile> jobSeekerProfileOpt = jobSeekerRepo
				.findByJobSeekerProfileIdAndJobSeekerProfileUuid(seekerProfileId, seekerProfileUuid);
		if (jobSeekerProfileOpt.isPresent()) {
			return jobSeekerProfileOpt.get();
		} else {
			throw new CustomException("Job Seeker Profile not found with profile id and uuid " + seekerProfileId + "  "
					+ seekerProfileUuid, HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public EducationalDetail getEducationalDetail(String educationalDetailId) {
		EducationalDetail detail = educationalDetailRepo.findByEducationalDetailUuid(educationalDetailId);

		if (detail != null) {
			return detail;
		} else {
			throw new CustomException("No educational detail found for " + educationalDetailId, HttpStatus.NOT_FOUND);
		}

	}

	@Override
	public ExperienceDetail getExperienceDetail(String experienceDetailId) {
		ExperienceDetail detail = experienceDetailRepo.findByExperienceDetailUuid(experienceDetailId);

		if (detail != null) {
			return detail;
		} else {
			throw new CustomException("No experience detail found for " + experienceDetailId, HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public List<ExperienceDetail> getExperienceDetailsBySeekerId(String jobSeekerId) {

		List<ExperienceDetail> details = jobSeekerRepo.getExperienceDetailsBySeekerId(jobSeekerId);
		if (details != null && !details.isEmpty()) {
			return details;
		} else {
			throw new CustomException("No Experiences found for " + jobSeekerId, HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public CareerProfile getCareerProfileByUuid(String careerProfileId) {
		CareerProfile careerProfile = careerProfileRepo.findByCareerProfileDetailUuid(careerProfileId);
		if (careerProfile != null) {
			return careerProfile;
		} else {
			throw new CustomException("No Career Profile found for " + careerProfileId, HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public boolean isJobSeekerHasGivenEducationalDetail(String jobSeekerId, String educationalDetailUuid) {
		return jobSeekerRepo.isJobSeekerHasGivenEducationalDetail(jobSeekerId, educationalDetailUuid);
	}

	@Override
	public boolean isJobSeekerHasGivenExperienceDetail(String jobSeekerId, String experienceDetailId) {
		return jobSeekerRepo.isJobSeekerHasGivenExperienceDetail(jobSeekerId, experienceDetailId);
	}

	@Override
	public boolean isJobSeekerHasGivenCareerProfile(String jobSeekerId, String careerProfileId) {
		return jobSeekerRepo.isJobSeekerHasGivenCareerProfile(jobSeekerId, careerProfileId);
	}



}
