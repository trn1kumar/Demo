package com.gloqr.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.entities.VacancyApplicant;
import com.gloqr.exception.CustomException;
import com.gloqr.repository.VacancyApplicantRepo;

@Repository
public class VacancyApplicantDaoImpl implements VacancyApplicantDao {

	@Autowired
	private VacancyApplicantRepo applicantRepo;

	@Override
	public VacancyApplicant getApplicant(String applicantUuid) {
		VacancyApplicant vacancyApplicant = applicantRepo.findByApplicantUuid(applicantUuid);
		if(vacancyApplicant==null) {
			throw new CustomException("No Applicant found with id:: "+applicantUuid, HttpStatus.NOT_FOUND);
		}
		return vacancyApplicant;
	}

	@Override
	public void saveApplicant(VacancyApplicant applicant) {
		
		try
		{
			applicantRepo.save(applicant);
		}
		catch(Exception e)
		{
			throw new  CustomException("Exception in saveApplicant() {}. message:- "+e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}

}
