package com.gloqr.dao;

import java.util.List;

import com.gloqr.entities.jobseekers.CareerProfile;
import com.gloqr.entities.jobseekers.EducationalDetail;
import com.gloqr.entities.jobseekers.ExperienceDetail;
import com.gloqr.entities.jobseekers.JobSeekerProfile;

public interface JobSeekerDao {

	public void saveJobSeekerProfile(JobSeekerProfile jobSeekerProfile);

	public void saveEducationalDetail(EducationalDetail educationalDetail);

	public void saveExperienceDetail(ExperienceDetail experienceDetail);

	public void saveCareerProfileInfo(CareerProfile careerProfile);

	public JobSeekerProfile getJobSeekerProfile(String userAccountId);

	public JobSeekerProfile getJobSeekerProfileByUuid(String jobSeekerProfileUuid);
	
	public JobSeekerProfile getJobSeekerProfileByIdAndUuid(String seekerProfileId, String seekerProfileUuid);

	public EducationalDetail getEducationalDetail(String educationalDetailId);

	public ExperienceDetail getExperienceDetail(String experienceDetailId);

	public List<ExperienceDetail> getExperienceDetailsBySeekerId(String jobSeekerId);

	public CareerProfile getCareerProfileByUuid(String careerProfileId);

	public boolean isJobSeekerHasGivenEducationalDetail(String jobSeekerId, String educationalDetailUuid);

	public boolean isJobSeekerHasGivenExperienceDetail(String jobSeekerId, String experienceDetailId);

	public boolean isJobSeekerHasGivenCareerProfile(String jobSeekerId, String careerProfileId);
	
}