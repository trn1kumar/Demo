package com.gloqr.dao;

import com.gloqr.entities.VacancyApplicant;

public interface VacancyApplicantDao {

	VacancyApplicant getApplicant(String applicantUuid);

	void saveApplicant(VacancyApplicant applicant);

}
