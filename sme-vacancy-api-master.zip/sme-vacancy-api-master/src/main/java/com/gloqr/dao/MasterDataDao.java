package com.gloqr.dao;

import java.util.List;
import java.util.Set;

import com.gloqr.entities.master.Course;
import com.gloqr.entities.master.CourseCategory;
import com.gloqr.entities.master.IndustrialArea;
import com.gloqr.entities.master.IndustrialJobRole;
import com.gloqr.entities.master.Specialization;

public interface MasterDataDao {

	public void saveIndustrialArea(IndustrialArea industrialArea);

	public List<IndustrialArea> getAllIndustrialArea();

	public List<IndustrialJobRole> getJobRolesByIndustrialAreaId(String industrialAreaId);

	public List<IndustrialJobRole> getJobRoles();

	public IndustrialJobRole getJobRole(String jobRoleUuid);

	public Specialization getSpecializationById(String specId);

	public List<CourseCategory> getAllCourseCategories();

	public List<Course> getCoursesByCategory(String courseCategoryId);

	public List<Specialization> getSpecializationsByCourse(String courseId);

	public List<Specialization> getSpecializationsByIds(Set<String> specsId);

	public List<Course> getCoursesByIds(Set<String> coursesId);

	public Course getCourseById(String courseId);

}
