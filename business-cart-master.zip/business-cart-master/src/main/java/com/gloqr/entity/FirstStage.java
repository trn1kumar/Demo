package com.gloqr.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.gloqr.constant.CartState;
import com.gloqr.constant.Stage;
import com.gloqr.state.State;

@Entity
@Table(name = "Cart_First_Stage")
@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler" })
public class FirstStage extends Audit implements Serializable, State {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "First_Stage_ID")
	private Long firstStageId;

	@Column(name = "Status", nullable = false)
	@Enumerated(EnumType.STRING)
	private Stage status = Stage.ORDERED;

	@Column(name = "Reject_Message", length = 500)
	private String rejectMessage;

	@Transient
	private String statusName;

	@Override
	public void acceptStage(CartItem cartItem) {
		cartItem.setCartState(CartState.ACTIVE);
		cartItem.setFirstStage(this);
	}

	@Override
	public void rejectStage(CartItem cartItem, String rejectMessage) {
		cartItem.setCartState(CartState.REJECTED);
		this.status = Stage.REJECTED;
		this.rejectMessage = rejectMessage;
	}

	public String getStatusName() {
		return status.getValue();
	}

	public Long getFirstStageId() {
		return firstStageId;
	}

	public Stage getStatus() {
		return status;
	}

	public String getRejectMessage() {
		return rejectMessage;
	}

	public void setFirstStageId(Long firstStageId) {
		this.firstStageId = firstStageId;
	}

	public void setStatus(Stage status) {
		this.status = status;
	}

	public void setRejectMessage(String rejectMessage) {
		this.rejectMessage = rejectMessage;
	}

}
