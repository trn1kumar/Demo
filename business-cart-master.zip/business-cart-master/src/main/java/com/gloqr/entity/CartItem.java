package com.gloqr.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.gloqr.constant.CartState;

@Entity
@Table(name = "Cart_Item")
public class CartItem extends Audit {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Cart_ID")
	private Long cartId;

	@Column(name = "Order_Id", unique = true, nullable = false, updatable = false)
	private String orderId;

	@Column(name = "Cart_Uuid", unique = true, nullable = false, updatable = false)
	private String cartUuid;

	@Column(name = "User_Uuid")
	private String userUuid;

	@Column(name = "userName")
	private String userName;

	@Column(name = "SME_Uuid", nullable = false, updatable = false)
	private String sUuid;

	@Column(name = "View_Status")
	private boolean viewStatus;

	@Column(name = "Expiration_Date", nullable = false)
	@Temporal(TemporalType.DATE)
	private Date expirationDate;

	@Column(name = "Cart_State", nullable = false)
	@Enumerated(EnumType.STRING)
	private CartState cartState;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "Item_Data_ID", nullable = false)
	private ItemData itemData;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "First_Stage_ID", nullable = false)
	private FirstStage firstStage;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "Second_Stage_ID")
	private SecondStage secondStage;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "Third_Stage_ID")
	private ThirdStage thirdStage;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "Fourth_Stage_ID")
	private FourthStage fourthStage;

	public CartItem() {
		super();
	}

	public CartItem(String userUuid, ItemData itemData, String cartUuid, String orderId) {
		super();
		this.userUuid = userUuid;
		this.sUuid = itemData.getsUuid();
		this.itemData = itemData;
		this.cartUuid = cartUuid;
		this.orderId = orderId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Long getCartId() {
		return cartId;
	}

	public String getOrderId() {
		return orderId;
	}

	public String getCartUuid() {
		return cartUuid;
	}

	public String getUserUuid() {
		return userUuid;
	}

	public String getsUuid() {
		return sUuid;
	}

	public boolean isViewStatus() {
		return viewStatus;
	}

	public CartState getCartState() {
		return cartState;
	}

	public ItemData getItemData() {
		return itemData;
	}

	public FirstStage getFirstStage() {
		return firstStage;
	}

	public SecondStage getSecondStage() {
		return secondStage;
	}

	public ThirdStage getThirdStage() {
		return thirdStage;
	}

	public FourthStage getFourthStage() {
		return fourthStage;
	}

	public void setCartId(Long cartId) {
		this.cartId = cartId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public void setCartUuid(String cartUuid) {
		this.cartUuid = cartUuid;
	}

	public void setUserUuid(String userUuid) {
		this.userUuid = userUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public void setViewStatus(boolean viewStatus) {
		this.viewStatus = viewStatus;
	}

	public void setCartState(CartState cartState) {
		this.cartState = cartState;
	}

	public void setItemData(ItemData itemData) {
		this.itemData = itemData;
	}

	public void setFirstStage(FirstStage firstStage) {
		this.firstStage = firstStage;
	}

	public void setSecondStage(SecondStage secondStage) {
		this.secondStage = secondStage;
	}

	public void setThirdStage(ThirdStage thirdStage) {
		this.thirdStage = thirdStage;
	}

	public void setFourthStage(FourthStage fourthStage) {
		this.fourthStage = fourthStage;
	}

	public Date getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

}
