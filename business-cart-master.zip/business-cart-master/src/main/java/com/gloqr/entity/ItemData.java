package com.gloqr.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.gloqr.constant.ItemType;

@Entity
@Table(name = "Cart_Item_Data")
@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler" })
public class ItemData implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Item_ID")
	private Long itemId;

	@Column(name = "Item_Uuid", nullable = false, updatable = false)
	private String itemUuid;

	@Column(name = "Item_Name", nullable = false)
	private String itemName;

	@Column(name = "Item_Url_Name")
	private String itemUrlName;

	@Column(name = "Item_Image", nullable = false)
	private String mainImage;

	@Column(name = "SME_Uuid", nullable = false, updatable = false)
	private String sUuid;

	@Column(name = "SME_Name")
	private String smeName;

	@Column(name = "Price_Unit")
	private String priceUnit;

	@Column(name = "Actual_Price", nullable = false, columnDefinition = "DOUBLE(9,2) UNSIGNED")
	private double price;

	@Column(name = "Discounted_Price", nullable = false, columnDefinition = "DOUBLE(9,2) UNSIGNED")
	private double discountedPrice;

	@Column(name = "Discount", length = 3, columnDefinition = "INT UNSIGNED")
	private int discount;

	@Column(name = "Quantity", columnDefinition = "INT UNSIGNED")
	private int quantity;

	@Column(name = "Item_Type", nullable = false)
	@Enumerated(EnumType.STRING)
	private ItemType itemType;

	@Transient
	private double orderTotal;

	@Transient
	private boolean autoQuotation;

	public String getItemUuid() {
		return itemUuid;
	}

	public String getItemName() {
		return itemName;
	}

	public String getItemUrlName() {
		return itemUrlName;
	}

	public String getMainImage() {
		return mainImage;
	}

	public String getsUuid() {
		return sUuid;
	}

	public String getSmeName() {
		return smeName;
	}

	public String getPriceUnit() {
		return priceUnit;
	}

	public double getPrice() {
		return price;
	}

	public double getDiscountedPrice() {
		return discountedPrice;
	}

	public int getDiscount() {
		return discount;
	}

	public int getQuantity() {
		return quantity;
	}

	public ItemType getItemType() {
		return itemType;
	}

	public double getOrderTotal() {
		return discountedPrice * quantity;
	}

	public boolean isAutoQuotation() {
		return autoQuotation;
	}

	public void setItemUuid(String itemUuid) {
		this.itemUuid = itemUuid;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public void setItemUrlName(String itemUrlName) {
		this.itemUrlName = itemUrlName;
	}

	public void setMainImage(String mainImage) {
		this.mainImage = mainImage;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public void setPriceUnit(String priceUnit) {
		this.priceUnit = priceUnit;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public void setDiscountedPrice(double discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public void setItemType(ItemType itemType) {
		this.itemType = itemType;
	}

	public void setOrderTotal(double orderTotal) {
		this.orderTotal = orderTotal;
	}

	public void setAutoQuotation(boolean autoQuotation) {
		this.autoQuotation = autoQuotation;
	}
}
