package com.gloqr.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.gloqr.constant.CartState;
import com.gloqr.constant.Stage;
import com.gloqr.state.State;

@Entity
@Table(name = "Cart_Second_Stage")
@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler" })
public class SecondStage extends Audit implements Serializable, State {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Second_Stage_ID")
	private Long secondStageId;

	@Column(name = "Status", nullable = false)
	@Enumerated(EnumType.STRING)
	private Stage status = Stage.QUOTATION;

	@Column(name = "Comment_Message", length = 500)
	private String commentMessage;

	@Column(name = "Reject_Message", length = 500)
	private String rejectMessage;

	@Column(name = "FileLocation")
	private String fileLocation;

	@Transient
	private String statusName;

	public SecondStage() {
		super();
	}

	public SecondStage(String commentMessage, String fileLocation) {
		super();
		this.commentMessage = commentMessage;
		this.fileLocation = fileLocation;
	}

	@Override
	public void acceptStage(CartItem cartItem) {
		cartItem.setCartState(CartState.ACTIVE);
		cartItem.setSecondStage(this);
	}

	@Override
	public void rejectStage(CartItem cartItem, String rejectMessage) {
		cartItem.setCartState(CartState.REJECTED);
		this.status = Stage.REJECTED;
		this.rejectMessage = rejectMessage;
	}

	public String getStatusName() {
		return status.getValue();
	}

	public Long getSecondStageId() {
		return secondStageId;
	}

	public Stage getStatus() {
		return status;
	}

	public String getCommentMessage() {
		return commentMessage;
	}

	public String getRejectMessage() {
		return rejectMessage;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public void setSecondStageId(Long secondStageId) {
		this.secondStageId = secondStageId;
	}

	public void setStatus(Stage status) {
		this.status = status;
	}

	public void setCommentMessage(String commentMessage) {
		this.commentMessage = commentMessage;
	}

	public void setRejectMessage(String rejectMessage) {
		this.rejectMessage = rejectMessage;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

}