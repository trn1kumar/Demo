package com.gloqr.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.gloqr.constant.Stage;

@JsonInclude(Include.NON_DEFAULT)
public class StageDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private Stage status;
	private String rejectMessage;
	private String commentMessage;
	private String fileLocation;
	private String statusName;

	public Stage getStatus() {
		return status;
	}

	public String getRejectMessage() {
		return rejectMessage;
	}

	public String getCommentMessage() {
		return commentMessage;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public void setStatus(Stage status) {
		this.status = status;
	}

	public void setRejectMessage(String rejectMessage) {
		this.rejectMessage = rejectMessage;
	}

	public void setCommentMessage(String commentMessage) {
		this.commentMessage = commentMessage;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

}
