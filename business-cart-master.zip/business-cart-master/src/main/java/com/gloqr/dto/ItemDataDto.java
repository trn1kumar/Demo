package com.gloqr.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.gloqr.constant.ItemType;

@JsonInclude(Include.NON_NULL)
public class ItemDataDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String itemUuid;
	private String itemName;
	private String itemUrlName;
	private String mainImage;
	private String sUuid;
	private String smeName;
	private String priceUnit;
	private double price;
	private double discountedPrice;
	private int discount;
	private int quantity;
	private ItemType itemType;
	private double orderTotal;

	public String getItemUuid() {
		return itemUuid;
	}

	public String getItemName() {
		return itemName;
	}

	public String getItemUrlName() {
		return itemUrlName;
	}

	public String getMainImage() {
		return mainImage;
	}

	public String getsUuid() {
		return sUuid;
	}

	public String getSmeName() {
		return smeName;
	}

	public String getPriceUnit() {
		return priceUnit;
	}

	public double getPrice() {
		return price;
	}

	public double getDiscountedPrice() {
		return discountedPrice;
	}

	public int getDiscount() {
		return discount;
	}

	public int getQuantity() {
		return quantity;
	}

	public ItemType getItemType() {
		return itemType;
	}

	public double getOrderTotal() {
		return orderTotal;
	}

	public void setItemUuid(String itemUuid) {
		this.itemUuid = itemUuid;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public void setItemUrlName(String itemUrlName) {
		this.itemUrlName = itemUrlName;
	}

	public void setMainImage(String mainImage) {
		this.mainImage = mainImage;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public void setPriceUnit(String priceUnit) {
		this.priceUnit = priceUnit;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public void setDiscountedPrice(double discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public void setItemType(ItemType itemType) {
		this.itemType = itemType;
	}

	public void setOrderTotal(double orderTotal) {
		this.orderTotal = orderTotal;
	}

}
