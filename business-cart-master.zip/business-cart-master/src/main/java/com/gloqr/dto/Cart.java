package com.gloqr.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.gloqr.http.response.CartCount;

@JsonInclude(Include.NON_NULL)
public class Cart implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<CartItemDto> sentItems;
	private List<CartItemDto> receivedItems;
	private long sentCount;
	private long receivedCount;
	private CartCount cartFilterCount;

	public List<CartItemDto> getSentItems() {
		return sentItems;
	}

	public List<CartItemDto> getReceivedItems() {
		return receivedItems;
	}

	public long getSentCount() {
		return sentCount;
	}

	public long getReceivedCount() {
		return receivedCount;
	}

	public void setSentItems(List<CartItemDto> sentItems) {
		this.sentItems = sentItems;
	}

	public void setReceivedItems(List<CartItemDto> receivedItems) {
		this.receivedItems = receivedItems;
	}

	public void setSentCount(long sentCount) {
		this.sentCount = sentCount;
	}

	public void setReceivedCount(long receivedCount) {
		this.receivedCount = receivedCount;
	}

	public CartCount getCartFilterCount() {
		return cartFilterCount;
	}

	public void setCartFilterCount(CartCount cartFilterCount) {
		this.cartFilterCount = cartFilterCount;
	}

}
