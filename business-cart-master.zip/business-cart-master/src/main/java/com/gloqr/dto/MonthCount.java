package com.gloqr.dto;

public class MonthCount {

	private String monthName;
	private long count;

	public MonthCount(String monthName, long count) {
		super();
		this.monthName = monthName;
		this.count = count;
	}

	public String getMonthName() {
		return monthName;
	}

	public long getCount() {
		return count;
	}

	@Override
	public String toString() {
		return "MonthCount [monthName=" + monthName + ", count=" + count + "]";
	}

}
