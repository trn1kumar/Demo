package com.gloqr.dto;

import com.gloqr.constant.CartState;

public class GroupCount {

	private CartState cartState;
	private long count;
	private double gmv;

	public GroupCount(CartState cartState, long count, double gmv) {
		super();
		this.cartState = cartState;
		this.count = count;
		this.gmv = gmv;
	}

	public GroupCount(CartState cartState, long count) {
		super();
		this.cartState = cartState;
		this.count = count;
	}

	public CartState getCartState() {
		return cartState;
	}

	public long getCount() {
		return count;
	}

	public double getGmv() {
		return gmv;
	}

}
