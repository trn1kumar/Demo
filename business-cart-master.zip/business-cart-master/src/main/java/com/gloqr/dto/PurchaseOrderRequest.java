package com.gloqr.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class PurchaseOrderRequest {

	@NotBlank(message = "{comment}")
	@Size(max = 500, message = "{comment.max}")
	private String commentMessage;

	@NotBlank(message = "{cart.uuid}")
	private String cartUuid;

	private String fileLocation;

	public String getCommentMessage() {
		return commentMessage;
	}

	public String getCartUuid() {
		return cartUuid;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}
}
