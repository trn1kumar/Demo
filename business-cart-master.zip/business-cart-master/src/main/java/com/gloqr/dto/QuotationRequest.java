package com.gloqr.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.gloqr.constant.QuotationType;

public class QuotationRequest {

	@NotNull(message = "{quotation.type}")
	private QuotationType quotationType;

	@NotBlank(message = "{comment}")
	@Size(max = 500, message = "{comment.max}")
	private String commentMessage;

	@NotBlank(message = "{cart.uuid}")
	private String cartUuid;

	private String fileLocation;

	public QuotationType getQuotationType() {
		return quotationType;
	}

	public String getCommentMessage() {
		return commentMessage;
	}

	public String getCartUuid() {
		return cartUuid;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

}
