package com.gloqr.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class RejectOrder {

	@NotBlank(message = "{comment}")
	@Size(max = 500, message = "{comment.max}")
	private String rejectMessage;

	@NotBlank(message = "{cart.uuid}")
	private String cartUuid;

	public String getRejectMessage() {
		return rejectMessage;
	}

	public String getCartUuid() {
		return cartUuid;
	}

}
