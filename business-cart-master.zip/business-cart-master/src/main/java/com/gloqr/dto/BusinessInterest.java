package com.gloqr.dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.gloqr.constant.ItemType;

public class BusinessInterest {

	@NotBlank(message = "{user.uuid}")
	private String userUuid;

	@NotBlank(message = "{sme.uuid}")
	private String sUuid;

	@NotBlank(message = "{item.uuid}")
	private String itemUuid;

	@Min(value = 1, message = "{min.qty}")
	private int quantity;

	@NotNull(message = "{item.type}")
	private ItemType itemType;

	public String getUserUuid() {
		return userUuid;
	}

	public String getsUuid() {
		return sUuid;
	}

	public String getItemUuid() {
		return itemUuid;
	}

	public int getQuantity() {
		return quantity;
	}

	public ItemType getItemType() {
		return itemType;
	}

}
