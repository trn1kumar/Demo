package com.gloqr.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.gloqr.constant.CartState;
import com.gloqr.endpoint.dto.UserDto;

@JsonInclude(Include.NON_DEFAULT)
public class CartItemDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String orderId;
	private String cartUuid;
	private String userUuid;
	private String userName;
	private String sUuid;
	private boolean viewStatus;
	private ItemDataDto itemData;
	private StageDto firstStage;
	private StageDto secondStage;
	private StageDto thirdStage;
	private StageDto fourthStage;
	private UserDto userDetails;
	private Date createdAt;
	private Date expirationDate;
	private CartState cartState;

	public CartState getCartState() {
		return cartState;
	}

	public void setCartState(CartState cartState) {
		this.cartState = cartState;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public String getOrderId() {
		return orderId;
	}

	public String getCartUuid() {
		return cartUuid;
	}

	public String getUserUuid() {
		return userUuid;
	}

	public String getsUuid() {
		return sUuid;
	}

	public boolean isViewStatus() {
		return viewStatus;
	}

	public ItemDataDto getItemData() {
		return itemData;
	}

	public StageDto getFirstStage() {
		return firstStage;
	}

	public StageDto getSecondStage() {
		return secondStage;
	}

	public StageDto getThirdStage() {
		return thirdStage;
	}

	public StageDto getFourthStage() {
		return fourthStage;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public void setCartUuid(String cartUuid) {
		this.cartUuid = cartUuid;
	}

	public void setUserUuid(String userUuid) {
		this.userUuid = userUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public void setViewStatus(boolean viewStatus) {
		this.viewStatus = viewStatus;
	}

	public void setItemData(ItemDataDto itemData) {
		this.itemData = itemData;
	}

	public void setFirstStage(StageDto firstStage) {
		this.firstStage = firstStage;
	}

	public void setSecondStage(StageDto secondStage) {
		this.secondStage = secondStage;
	}

	public void setThirdStage(StageDto thirdStage) {
		this.thirdStage = thirdStage;
	}

	public void setFourthStage(StageDto fourthStage) {
		this.fourthStage = fourthStage;
	}

	public UserDto getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(UserDto userDetails) {
		this.userDetails = userDetails;
	}

	public Date getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

}
