package com.gloqr.dto;

public class BICountUpdate {

	private String itemType = "BI";
	private String smeUuid;
	private Long totalCount;

	public BICountUpdate(String smeUuid, Long totalCount) {
		super();
		this.smeUuid = smeUuid;
		this.totalCount = totalCount;
	}

	public String getSmeUuid() {
		return smeUuid;
	}

	public void setSmeUuid(String smeUuid) {
		this.smeUuid = smeUuid;
	}

	public Long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

}
