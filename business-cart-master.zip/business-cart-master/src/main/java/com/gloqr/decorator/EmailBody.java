package com.gloqr.decorator;

public class EmailBody extends CommonValue {

	private String itemUrl;
	private String cartUrl;

	public String getItemUrl() {
		return itemUrl;
	}

	public void setItemUrl(String itemUrl) {
		this.itemUrl = itemUrl;
	}

	public String getCartUrl() {
		return cartUrl;
	}

	public void setCartUrl(String cartUrl) {
		this.cartUrl = cartUrl;
	}

}
