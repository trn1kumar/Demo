package com.gloqr.decorator;

import com.gloqr.constant.ItemType;

public class CommonValue {

	// SME Data
	private String sUuid;
	private String smeLogo;
	private String smeName;
	private String address;
	private String smeEmail;
	private String smePhone;

	// User Data
	private String userFullName;
	private String userEmail;
	private Long userMobile;

	// Item Data
	private String orderId;
	private String itemUuid;
	private String itemName;
	private String itemUrlName;
	private ItemType itemType;
	private String mainImage;
	private String priceUnit;
	private double price;
	private double discountedPrice;
	private int discount;
	private int quantity;
	private double orderTotal;
	private String attachment;

	public ItemType getItemType() {
		return itemType;
	}

	public void setItemType(ItemType itemType) {
		this.itemType = itemType;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getOrderId() {
		return orderId;
	}

	public String getsUuid() {
		return sUuid;
	}

	public String getSmeLogo() {
		return smeLogo;
	}

	public String getSmeName() {
		return smeName;
	}

	public String getAddress() {
		return address;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public String getItemName() {
		return itemName;
	}

	public String getItemUuid() {
		return itemUuid;
	}

	public String getMainImage() {
		return mainImage;
	}

	public String getPriceUnit() {
		return priceUnit;
	}

	public double getPrice() {
		return price;
	}

	public double getDiscountedPrice() {
		return discountedPrice;
	}

	public int getDiscount() {
		return discount;
	}

	public int getQuantity() {
		return quantity;
	}

	public double getOrderTotal() {
		return orderTotal;
	}

	public String getSmeEmail() {
		return smeEmail;
	}

	public String getSmePhone() {
		return smePhone;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public Long getUserMobile() {
		return userMobile;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public void setSmeLogo(String smeLogo) {
		this.smeLogo = smeLogo;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setSmeEmail(String smeEmail) {
		this.smeEmail = smeEmail;
	}

	public void setSmePhone(String smePhone) {
		this.smePhone = smePhone;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public void setUserMobile(Long userMobile) {
		this.userMobile = userMobile;
	}

	public void setItemUuid(String itemUuid) {
		this.itemUuid = itemUuid;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public void setMainImage(String mainImage) {
		this.mainImage = mainImage;
	}

	public void setPriceUnit(String priceUnit) {
		this.priceUnit = priceUnit;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public void setDiscountedPrice(double discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public void setOrderTotal(double orderTotal) {
		this.orderTotal = orderTotal;
	}

	public String getItemUrlName() {
		return itemUrlName;
	}

	public void setItemUrlName(String itemUrlName) {
		this.itemUrlName = itemUrlName;
	}

	public String getAttachment() {
		return attachment;
	}

	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}

}
