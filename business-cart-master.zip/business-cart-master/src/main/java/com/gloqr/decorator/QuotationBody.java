package com.gloqr.decorator;

import com.gloqr.constant.QuotationFormat;

public class QuotationBody extends CommonValue {

	// SME data
	private String gstin;

	// Item Data
	private double gstPercentage;
	private double addedGST;
	private double totalAmount;
	private String amountInWords;
	private String termsAndCondition;
	private QuotationFormat quotationFormat;
	private String fileLocation;

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public double getGstPercentage() {
		return gstPercentage;
	}

	public void setGstPercentage(double gstPercentage) {
		this.gstPercentage = gstPercentage;
	}

	public double getAddedGST() {
		return addedGST;
	}

	public void setAddedGST(double addedGST) {
		this.addedGST = addedGST;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getAmountInWords() {
		return amountInWords;
	}

	public void setAmountInWords(String amountInWords) {
		this.amountInWords = amountInWords;
	}

	public String getTermsAndCondition() {
		return termsAndCondition;
	}

	public void setTermsAndCondition(String termsAndCondition) {
		this.termsAndCondition = termsAndCondition;
	}

	public QuotationFormat getQuotationFormat() {
		return quotationFormat;
	}

	public void setQuotationFormat(QuotationFormat quotationFormat) {
		this.quotationFormat = quotationFormat;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

}
