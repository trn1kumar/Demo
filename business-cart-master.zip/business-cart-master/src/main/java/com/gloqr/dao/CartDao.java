package com.gloqr.dao;

import java.util.Set;

import com.gloqr.constant.CartState;
import com.gloqr.constant.ItemType;
import com.gloqr.dto.BusinessInterest;
import com.gloqr.dto.Cart;
import com.gloqr.entity.CartItem;
import com.gloqr.http.response.CartCount;
import com.gloqr.http.response.CartSummary;
import com.gloqr.http.response.ChartReport;

public interface CartDao {

	void checkItemAddedToCart(BusinessInterest bi);

	CartItem saveCartItem(CartItem cartItem);

	Cart sentCartItems(String userUuid, String sUuid, int page, CartState cartState);

	Cart receivedCartItems(String userUuid, String sUuid, int page, CartState cartState);

	CartCount sentCount(String userUuid);

	CartCount receivedCount(String sUuid);

	CartItem userCartItem(String userUuid, String cartUuid);

	CartItem smeCartItem(String sUuid, String cartUuid);

	Set<String> addedCartItems(String userUuid, ItemType itemType);

	ChartReport getChartReport(String sUuid);

	CartSummary cartSummary(String sUuid);

}
