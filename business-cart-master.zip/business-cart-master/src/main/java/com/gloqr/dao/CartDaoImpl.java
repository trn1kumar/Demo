package com.gloqr.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.constant.CartState;
import com.gloqr.constant.ItemType;
import com.gloqr.dto.BusinessInterest;
import com.gloqr.dto.Cart;
import com.gloqr.dto.CartItemDto;
import com.gloqr.dto.GroupCount;
import com.gloqr.dto.MonthCount;
import com.gloqr.entity.CartItem;
import com.gloqr.exception.CustomException;
import com.gloqr.http.response.CartCount;
import com.gloqr.http.response.CartSummary;
import com.gloqr.http.response.ChartReport;
import com.gloqr.mapper.Mapper;
import com.gloqr.repository.CartRepo;
import com.gloqr.util.CustomGenerator;

@Repository
public class CartDaoImpl implements CartDao {

	@Value("${cart.perpage}")
	private int pageLimit;

	@Autowired
	private CartRepo cartRepo;

	@Autowired
	private Mapper mapper;

	@Autowired
	private CustomGenerator generator;

	@Override
	public void checkItemAddedToCart(BusinessInterest bi) {
		if (cartRepo.existsByUserUuidAndCartStateAndItemDataItemUuidAndItemDataItemType(bi.getUserUuid(),
				CartState.ACTIVE, bi.getItemUuid(), bi.getItemType())) {
			throw new CustomException(bi.getItemType().getName() + " already added to cart",
					HttpStatus.ALREADY_REPORTED);
		}
	}

	@Override
	@Caching(evict = { @CacheEvict(value = "sentCount", key = "#cartItem.getUserUuid()"),
			@CacheEvict(value = { "receivedCount", "quotationCountAndAmount" }, key = "#cartItem.getsUuid()"),
			@CacheEvict(value = { "receivedCartItems", "sentCartItems" }, allEntries = true),
			@CacheEvict(value = "addedCartItems", key = "#cartItem.getUserUuid() + #cartItem.getItemData().getItemType()") })
	public CartItem saveCartItem(CartItem cartItem) {

		try {
			return cartRepo.save(cartItem);
		} catch (Exception e) {
			throw new CustomException("Error while saving cart item", HttpStatus.NOT_FOUND, e);
		}

	}

	@Override
	@Cacheable(value = "sentCartItems", key = "{#userUuid, #cartState, #page}")
	public Cart sentCartItems(String userUuid, String sUuid, int page, CartState cartState) {
		if (page <= 0) {
			page = 1;
		}

		Optional<List<CartItem>> optional = cartRepo.findByUserUuidAndCartState(userUuid, cartState,
				PageRequest.of(--page, pageLimit, Sort.Direction.DESC, "createdAt"));

		Cart cart = new Cart();
		if (optional.isPresent()) {
			List<CartItemDto> items = new ArrayList<>();
			optional.get().stream().forEach(i -> items.add(mapper.convert(i, CartItemDto.class)));
			cart.setSentItems(items);
		}

		return cart;
	}

	@Override
	@Cacheable(value = "receivedCartItems", key = "{#sUuid, #cartState, #page}")
	public Cart receivedCartItems(String userUuid, String sUuid, int page, CartState cartState) {
		if (page <= 0) {
			page = 1;
		}

		PageRequest pageable = PageRequest.of(--page, pageLimit, Sort.Direction.DESC, "createdAt");
		List<CartItem> cartItems = null;

		if (cartState.equals(CartState.REJECTED)) {
			cartItems = cartRepo.getRejectedWithAutoClosed(sUuid, cartState, CartState.AUTO_CLOSED, pageable);
		} else {
			cartItems = cartRepo.findBySUuidAndCartState(sUuid, cartState, pageable);
		}

		Cart cart = new Cart();
		if (cartItems != null) {
			List<CartItemDto> items = new ArrayList<>();
			cartItems.stream().forEach(i -> items.add(mapper.convert(i, CartItemDto.class)));
			cart.setReceivedItems(items);
		}

		return cart;
	}

	@Override
	@Cacheable(value = "sentCount", key = "#userUuid")
	public CartCount sentCount(String userUuid) {
		List<GroupCount> group = cartRepo.sentCartCount(userUuid);
		CartCount count = new CartCount();

		if (!group.isEmpty()) {
			group.forEach(g -> {
				if (g.getCartState().equals(CartState.ACTIVE)) {
					count.setActiveCount(g.getCount());
				} else if (g.getCartState().equals(CartState.COMPLETED)) {
					count.setDeliveredCount(g.getCount());
				} else if (g.getCartState().equals(CartState.REJECTED)
						|| g.getCartState().equals(CartState.AUTO_CLOSED)) {
					count.setRejectedCount(count.getRejectedCount() + g.getCount());
				}
			});
		}
		return count;
	}

	@Override
	@Cacheable(value = "receivedCount", key = "#sUuid")
	public CartCount receivedCount(String sUuid) {
		List<GroupCount> group = cartRepo.receivedCartCount(sUuid);
		CartCount count = new CartCount();

		if (!group.isEmpty()) {
			group.forEach(g -> {
				if (g.getCartState().equals(CartState.ACTIVE)) {
					count.setActiveCount(g.getCount());
					count.setActiveGMV(g.getGmv());
				} else if (g.getCartState().equals(CartState.COMPLETED)) {
					count.setDeliveredCount(g.getCount());
					count.setDeliveredGMV(g.getGmv());
				} else if (g.getCartState().equals(CartState.REJECTED)
						|| g.getCartState().equals(CartState.AUTO_CLOSED)) {
					count.setRejectedCount(count.getRejectedCount() + g.getCount());
					count.setRejectedGMV(count.getRejectedGMV() + g.getGmv());
				}
			});
		}
		return count;
	}

	@Override
	public CartItem userCartItem(String userUuid, String cartUuid) {
		Optional<CartItem> optional = cartRepo.findByUserUuidAndCartUuidAndCartState(userUuid, cartUuid,
				CartState.ACTIVE);

		if (optional.isPresent()) {
			return optional.get();
		} else {
			throw new CustomException("User CartItem not found with cart uuid :: " + cartUuid, HttpStatus.BAD_REQUEST);
		}

	}

	@Override
	public CartItem smeCartItem(String sUuid, String cartUuid) {
		Optional<CartItem> optional = cartRepo.findBySUuidAndCartUuidAndCartState(sUuid, cartUuid, CartState.ACTIVE);

		if (optional.isPresent()) {
			return optional.get();
		} else {
			throw new CustomException("SME CartItem not found with cart uuid :: " + cartUuid, HttpStatus.BAD_REQUEST);
		}
	}

	@Override
	@Cacheable(value = "addedCartItems", key = "#userUuid + #itemType")
	public Set<String> addedCartItems(String userUuid, ItemType itemType) {

		return cartRepo.addedCartItems(userUuid, itemType, CartState.ACTIVE);
	}

	@Override
	public ChartReport getChartReport(String sUuid) {

		String[] months = generator.getLastSixMonths();
		Date fromDate = generator.getLastSixMonthDate();

		List<MonthCount> monthCounts1 = cartRepo.getTotalCountForChart(sUuid, fromDate);
		List<MonthCount> monthCounts2 = cartRepo.getQuotationCountForChart(sUuid, fromDate);
		List<MonthCount> monthCounts3 = cartRepo.getDeliveredCountForChart(sUuid, fromDate);

		long[] total = new long[6];
		long[] quotation = new long[6];
		long[] delivered = new long[6];

		for (int i = 0; i < months.length; i++) {
			if (!monthCounts1.isEmpty()) {
				for (MonthCount monthCount : monthCounts1) {
					if (months[i].equals(monthCount.getMonthName())) {
						total[i] = monthCount.getCount();
						break;
					}
				}
			}
			if (!monthCounts2.isEmpty()) {
				for (MonthCount monthCount : monthCounts2) {
					if (months[i].equals(monthCount.getMonthName())) {
						quotation[i] = monthCount.getCount();
						break;
					}
				}
			}
			if (!monthCounts3.isEmpty()) {
				for (MonthCount monthCount : monthCounts3) {
					if (months[i].equals(monthCount.getMonthName())) {
						delivered[i] = monthCount.getCount();
						break;
					}
				}
			}

		}

		return new ChartReport(total, quotation, delivered, months);
	}

	@Override
	@Cacheable(value = "quotationCountAndAmount", key = "#sUuid")
	public CartSummary cartSummary(String sUuid) {

		return cartRepo.quotationCountAndAmount(sUuid);
	}

}
