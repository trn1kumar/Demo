package com.gloqr.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.config.PropertyValue;
import com.gloqr.constant.CartConstant;
import com.gloqr.constant.CreditType;
import com.gloqr.constant.ItemType;
import com.gloqr.constant.NotificationType;
import com.gloqr.dao.CartDao;
import com.gloqr.decorator.EmailBody;
import com.gloqr.decorator.QuotationBody;
import com.gloqr.endpoint.dto.CommonField;
import com.gloqr.endpoint.dto.PricingRequest;
import com.gloqr.endpoint.dto.SMEInfoDto;
import com.gloqr.endpoint.dto.UserDto;
import com.gloqr.endpoint.service.EndpointService;
import com.gloqr.endpoint.service.FileService;
import com.gloqr.entity.CartItem;
import com.gloqr.entity.SecondStage;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.Mapper;
import com.gloqr.state.State;
import com.gloqr.util.Converter;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Service
public class QuotationServiceImpl implements QuotationService {
	Logger logger = LogManager.getLogger();

	@Autowired
	private EndpointService endpointService;

	@Autowired
	private FileService fileService;

	@Autowired
	private CartDao cartDao;

	@Autowired
	private Mapper mapper;

	@Autowired
	private Converter converter;

	@Autowired
	private PropertyValue property;

	@Autowired
	private NotificationService notificationService;

	@Override
	public String manualQuotation(CartItem cartItem, MultipartFile file, String sUuid) {
		fileService.checkFileFormat(file);
		try {
			return fileService.sendSingleFile(file, CartConstant.QUOTATION_FILE_LOCATION.replace("{sUuid}", sUuid))
					.getFileLocation();
		} catch (IOException e) {
			throw new CustomException("Internal Server Error", HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
	}

	@Override
	@Async
	@Transactional
	public void asyncAutoQuotation(CartItem cartItem) {

		// PreChecking of available credits
		endpointService.asyncCheckCredits(CreditType.BUSINESS_INTEREST_VIEW, cartItem.getsUuid());

		// Generate Quotation
		QuotationBody body = autoQuotation(cartItem);

		State state = new SecondStage(null, body.getFileLocation());
		state.acceptStage(cartItem);
		cartItem.setViewStatus(true);
		cartDao.saveCartItem(cartItem);

		// Updating Credits
		PricingRequest request = new PricingRequest(CreditType.BUSINESS_INTEREST_VIEW, "DEBIT", 1);
		request.setsUuid(cartItem.getsUuid());
		request.setUserUUID("Auto_Quotation");
		request.setUsedFor("User view details..User Uuid :: " + cartItem.getUserUuid());
		endpointService.asyncUpdateCredits(request);

		// Sending Quotation to user
		notificationService.autoQuotationNotification(mapper.convert(body, EmailBody.class), NotificationType.QUOTATION,
				body.getFileLocation());

		logger.info("Auto Quotation Sent Successfully");
	}

	@Override
	public QuotationBody autoQuotation(CartItem cartItem) {

		logger.info("Generating Quotation");

		QuotationBody body = mapper.convert(cartItem.getItemData(), QuotationBody.class);
		body.setOrderId(cartItem.getOrderId());

		CommonField commonField = null;

		if (cartItem.getItemData().getItemType().equals(ItemType.PRODUCT)) {
			commonField = endpointService.getProduct(cartItem.getItemData().getItemUuid());
		} else {
			commonField = endpointService.getService(cartItem.getItemData().getItemUuid());
		}
		
		UserDto userDto = endpointService.singleUserDetails(cartItem.getUserUuid());
		SMEInfoDto smeInfo = endpointService.getSMEInfo(cartItem.getsUuid());
		body.setSmeLogo(property.getSmeLogoPath() + smeInfo.getLogoImage());

		mapper.mapToQuotationObj(body, commonField, smeInfo, userDto);

		body.setAddedGST(body.getOrderTotal() * (body.getGstPercentage() / 100));
		body.setTotalAmount(body.getOrderTotal() + body.getAddedGST());
		body.setAmountInWords(converter.amountToWords((int) Math.round(body.getTotalAmount())) + " Only");

		return createPDF(body);
	}

	public QuotationBody createPDF(QuotationBody quotationBody) {

		List<QuotationBody> list = new ArrayList<>();
		list.add(quotationBody);

		try {
			// Getting JRXML of Format
			JasperReport jasperReport = JasperCompileManager.compileReport(
					property.getFormatPath().replace("{FORMAT}", quotationBody.getQuotationFormat().getName()));

			// Adding quotation body object to datasource
			JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(list);

			// Creating Report with datasource
			JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, new HashMap<>(), dataSource);

			String fileName = "/Quotation" + quotationBody.getOrderId() + ".pdf";

			String storePath = property.getStorePath().replace("{sUuid}", quotationBody.getsUuid());

			String path = property.getDistPath() + storePath;

			File directory = new File(path);

			// Check QuotationFile Directory exists else create directory
			if (!directory.exists()) {
				directory.mkdirs();
			}

			// Storing generated PDF file on SME quotation file folder
			JasperExportManager.exportReportToPdfFile(jasperPrint, path + fileName);

			quotationBody.setFileLocation(storePath + fileName);

			logger.info("Quotation Generated Successfully...Path :: " + quotationBody.getFileLocation());
			return quotationBody;
		} catch (Exception e) {
			throw new CustomException("Error while generating PDF", e);
		}

	}

}
