package com.gloqr.service;

import org.springframework.web.multipart.MultipartFile;

import com.gloqr.dto.QuotationRequest;
import com.gloqr.dto.RejectOrder;
import com.gloqr.dto.StageDto;
import com.gloqr.endpoint.dto.FileResponse;
import com.gloqr.endpoint.dto.UserDto;

public interface SMEStageService {

	UserDto viewUserDetails(String cartUuid, String sUuid, String userUuid);

	StageDto sendQuotation(String sUuid, QuotationRequest quotation, MultipartFile file);

	void rejectOrder(String sUuid, RejectOrder rejectOrder);

	void confirmOrder(String sUuid, String cartUuid);

	FileResponse generateQuotation(String cartUuid, String sUuid);

	void rejectPurchaseOrder(String sUuid, RejectOrder rejectOrder);

}
