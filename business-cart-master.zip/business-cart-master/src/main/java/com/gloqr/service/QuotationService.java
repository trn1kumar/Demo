package com.gloqr.service;

import org.springframework.web.multipart.MultipartFile;

import com.gloqr.decorator.QuotationBody;
import com.gloqr.entity.CartItem;

public interface QuotationService {

	String manualQuotation(CartItem cartItem, MultipartFile file, String sUuid);

	QuotationBody autoQuotation(CartItem cartItem);

	void asyncAutoQuotation(CartItem cartItem);
}
