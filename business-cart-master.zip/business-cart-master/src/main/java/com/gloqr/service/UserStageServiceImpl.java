package com.gloqr.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.constant.CartConstant;
import com.gloqr.constant.NotificationType;
import com.gloqr.dao.CartDao;
import com.gloqr.dto.PurchaseOrderRequest;
import com.gloqr.dto.RejectOrder;
import com.gloqr.dto.StageDto;
import com.gloqr.endpoint.service.FileService;
import com.gloqr.entity.CartItem;
import com.gloqr.entity.ThirdStage;
import com.gloqr.exception.CustomException;
import com.gloqr.mapper.Mapper;
import com.gloqr.state.State;
import com.gloqr.util.CustomGenerator;

@Service
public class UserStageServiceImpl implements UserStageService {

	@Autowired
	private CartDao cartDao;

	@Autowired
	private FileService fileService;

	@Autowired
	private Mapper mapper;

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private CustomGenerator generator;

	@Override
	public StageDto sendPurchaseOrder(String userUuid, PurchaseOrderRequest purchaseOrder, MultipartFile file) {

		CartItem cartItem = cartDao.userCartItem(userUuid, purchaseOrder.getCartUuid());

		if (file != null) {
			purchaseOrder.setFileLocation(uploadFile(userUuid, file));
		}

		State state = new ThirdStage(purchaseOrder.getCommentMessage(), purchaseOrder.getFileLocation());
		state.acceptStage(cartItem);

		// Set expiration date after 90 Days from current date
		cartItem.setExpirationDate(generator.getExpirationDate());
		cartDao.saveCartItem(cartItem);

		// ASYNC Call
		notificationService.sendNotification(cartItem, NotificationType.PURCHASE_ORDER,
				purchaseOrder.getFileLocation());

		return mapper.convert(cartItem.getThirdStage(), StageDto.class);
	}

	@Override
	public void rejectQuotation(String userUuid, RejectOrder rejectOrder) {
		CartItem cartItem = cartDao.userCartItem(userUuid, rejectOrder.getCartUuid());
		State state = cartItem.getSecondStage();
		state.rejectStage(cartItem, rejectOrder.getRejectMessage());

		cartDao.saveCartItem(cartItem);

		// ASYNC Call
		notificationService.sendNotification(cartItem, NotificationType.REJECT_QUOTATION, null);
	}

	private String uploadFile(String userUuid, MultipartFile file) {

		fileService.checkFileFormat(file);
		try {
			return fileService
					.sendSingleFile(file, CartConstant.PURCHASE_ORDER_FILE_LOCATION.replace("{userUuid}", userUuid))
					.getFileLocation();
		} catch (IOException e) {
			throw new CustomException("Internal Server Error", HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
	}
}
