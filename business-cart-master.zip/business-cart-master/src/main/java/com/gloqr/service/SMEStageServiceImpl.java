package com.gloqr.service;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.constant.CreditType;
import com.gloqr.constant.NotificationType;
import com.gloqr.constant.QuotationType;
import com.gloqr.dao.CartDao;
import com.gloqr.dto.QuotationRequest;
import com.gloqr.dto.RejectOrder;
import com.gloqr.dto.StageDto;
import com.gloqr.endpoint.dto.FileResponse;
import com.gloqr.endpoint.dto.PricingRequest;
import com.gloqr.endpoint.dto.UserDto;
import com.gloqr.endpoint.service.EndpointService;
import com.gloqr.entity.CartItem;
import com.gloqr.entity.FourthStage;
import com.gloqr.entity.SecondStage;
import com.gloqr.mapper.Mapper;
import com.gloqr.state.State;
import com.gloqr.util.CustomGenerator;

@Service
public class SMEStageServiceImpl implements SMEStageService {

	@Autowired
	private CartDao cartDao;

	@Autowired
	private Mapper mapper;

	@Autowired
	private QuotationService quotationService;

	@Autowired
	private EndpointService endpointService;

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private CustomGenerator generator;

	@Override
	@Transactional
	public UserDto viewUserDetails(String cartUuid, String sUuid, String userUuid) {
		// PreChecking of available credits
		endpointService.checkCredits(CreditType.BUSINESS_INTEREST_VIEW);

		CartItem cartItem = cartDao.smeCartItem(sUuid, cartUuid);
		cartItem.setViewStatus(true);
		cartDao.saveCartItem(cartItem);

		// Getting User Details by Id
		UserDto userDto = endpointService.singleUserDetails(cartItem.getUserUuid());

		// Updating credits
		PricingRequest request = new PricingRequest(CreditType.BUSINESS_INTEREST_VIEW, "DEBIT", 1);
		request.setsUuid(sUuid);
		request.setUserUUID(userUuid);
		request.setUsedFor("User view details..User Uuid :: " + cartItem.getUserUuid());
		endpointService.updateCredits(request);

		return userDto;
	}

	@Override
	public StageDto sendQuotation(String sUuid, QuotationRequest quotation, MultipartFile file) {
		CartItem cartItem = cartDao.smeCartItem(sUuid, quotation.getCartUuid());

		if (quotation.getQuotationType().equals(QuotationType.MANUAL) && file != null) {
			quotation.setFileLocation(quotationService.manualQuotation(cartItem, file, sUuid));
		}

		if (quotation.getQuotationType().equals(QuotationType.AUTO)
				&& StringUtils.isBlank(quotation.getFileLocation())) {
			quotation.setFileLocation(quotationService.autoQuotation(cartItem).getFileLocation());
		}

		State state = new SecondStage(quotation.getCommentMessage(), quotation.getFileLocation());
		state.acceptStage(cartItem);

		// Set expiration date after 90 Days from current date
		cartItem.setExpirationDate(generator.getExpirationDate());
		cartDao.saveCartItem(cartItem);

		// ASYNC Call
		notificationService.sendNotification(cartItem, NotificationType.QUOTATION, quotation.getFileLocation());

		return mapper.convert(cartItem.getSecondStage(), StageDto.class);
	}

	@Override
	public void rejectOrder(String sUuid, RejectOrder rejectOrder) {

		CartItem cartItem = cartDao.smeCartItem(sUuid, rejectOrder.getCartUuid());
		State state = cartItem.getFirstStage();
		state.rejectStage(cartItem, rejectOrder.getRejectMessage());

		cartDao.saveCartItem(cartItem);

		// ASYNC Call
		notificationService.sendNotification(cartItem, NotificationType.REJECT_BI, null);
	}

	@Override
	public void rejectPurchaseOrder(String sUuid, RejectOrder rejectOrder) {
		CartItem cartItem = cartDao.smeCartItem(sUuid, rejectOrder.getCartUuid());
		State state = cartItem.getThirdStage();
		state.rejectStage(cartItem, rejectOrder.getRejectMessage());

		cartDao.saveCartItem(cartItem);

		// ASYNC Call
		notificationService.sendNotification(cartItem, NotificationType.REJECT_PO, null);
	}

	@Override
	public void confirmOrder(String sUuid, String cartUuid) {
		CartItem cartItem = cartDao.smeCartItem(sUuid, cartUuid);
		State state = new FourthStage();
		state.acceptStage(cartItem);

		cartDao.saveCartItem(cartItem);

		// ASYNC Call
		notificationService.sendNotification(cartItem, NotificationType.CONFIRM_ORDER, null);
	}

	@Override
	public FileResponse generateQuotation(String cartUuid, String sUuid) {
		CartItem cartItem = cartDao.smeCartItem(sUuid, cartUuid);

		FileResponse response = new FileResponse();
		response.setFileLocation(quotationService.autoQuotation(cartItem).getFileLocation());

		return response;
	}

}
