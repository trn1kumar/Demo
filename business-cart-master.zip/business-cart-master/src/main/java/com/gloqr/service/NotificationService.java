package com.gloqr.service;

import com.gloqr.constant.NotificationType;
import com.gloqr.decorator.EmailBody;
import com.gloqr.endpoint.dto.EmailEvent;
import com.gloqr.endpoint.dto.SmsEvent;
import com.gloqr.entity.CartItem;

public interface NotificationService {

	void sendNotification(CartItem cartItem, NotificationType type, String attachment);

	void autoQuotationNotification(EmailBody body, NotificationType type, String attachment);

	void sendAutoClosedNotification(CartItem cartItem);

	void sendSMS(SmsEvent smsEvent);

	void sendEmail(EmailEvent emailEvent);
}
