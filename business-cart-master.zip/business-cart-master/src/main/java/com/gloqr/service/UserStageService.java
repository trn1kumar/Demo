package com.gloqr.service;

import org.springframework.web.multipart.MultipartFile;

import com.gloqr.dto.PurchaseOrderRequest;
import com.gloqr.dto.RejectOrder;
import com.gloqr.dto.StageDto;

public interface UserStageService {

	StageDto sendPurchaseOrder(String userUuid, PurchaseOrderRequest purchaseOrder, MultipartFile file);

	void rejectQuotation(String userUuid, RejectOrder rejectOrder);

}
