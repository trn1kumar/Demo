package com.gloqr.service;

import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.constant.CartState;
import com.gloqr.constant.ItemType;
import com.gloqr.constant.NotificationType;
import com.gloqr.dao.CartDao;
import com.gloqr.dto.BusinessInterest;
import com.gloqr.dto.Cart;
import com.gloqr.dto.CartItemDto;
import com.gloqr.endpoint.dto.ProductDto;
import com.gloqr.endpoint.dto.ServiceDto;
import com.gloqr.endpoint.dto.UserDto;
import com.gloqr.endpoint.service.EndpointService;
import com.gloqr.entity.CartItem;
import com.gloqr.entity.FirstStage;
import com.gloqr.entity.ItemData;
import com.gloqr.http.response.CartCount;
import com.gloqr.http.response.CartSummary;
import com.gloqr.http.response.ChartReport;
import com.gloqr.mapper.Mapper;
import com.gloqr.state.State;
import com.gloqr.util.CustomGenerator;
import com.gloqr.util.RequestParser;

@Service
public class CartServiceImpl implements CartService {

	@Autowired
	private EndpointService endpointService;

	@Autowired
	private CustomGenerator generator;

	@Autowired
	private RequestParser requestParser;

	@Autowired
	private Mapper mapper;

	@Autowired
	private CartDao cartDao;

	@Autowired
	private QuotationService quotationService;

	@Autowired
	private NotificationService notificationService;

	@Override
	@Transactional
	public void generateInterest(BusinessInterest bi) {

		// Check Product/Service added to cart
		cartDao.checkItemAddedToCart(bi);

		ItemData itemData = null;
		if (bi.getItemType().equals(ItemType.PRODUCT)) {
			ProductDto productDto = endpointService.getProduct(bi.getItemUuid());
			itemData = mapper.productToItemData(productDto);
		} else {
			ServiceDto serviceDto = endpointService.getService(bi.getItemUuid());
			itemData = mapper.serviceToItemData(serviceDto);
		}

		itemData.setQuantity(bi.getQuantity());
		CartItem cartItem = new CartItem(bi.getUserUuid(), itemData, generator.generateUUID(),
				generator.generateOrderId());

		// Set expiration date after 90 Days from current date
		cartItem.setExpirationDate(generator.getExpirationDate());

		State state = new FirstStage();
		state.acceptStage(cartItem);

		cartItem.setUserName(endpointService.singleUserDetails(cartItem.getUserUuid()).getUserFullName());
		cartDao.saveCartItem(cartItem);

		// ASYNC Calls

		endpointService.incrementBiCount(bi.getItemType(), bi.getItemUuid(), requestParser.getHeader());
		if (itemData.isAutoQuotation()) {
			quotationService.asyncAutoQuotation(cartItem);
			notificationService.sendNotification(cartItem, NotificationType.AUTO_QUOTATION, null);
		} else {
			notificationService.sendNotification(cartItem, NotificationType.BI_GENERATION, null);
		}
	}

	@Override
	public long cartCount(String userUuid, String sUuid) {
		long count = 0;

		if (StringUtils.isNotBlank(sUuid)) {
			count = cartDao.receivedCount(sUuid).getActiveCount();
		}

		return count + cartDao.sentCount(userUuid).getActiveCount();
	}

	@Override
	public Cart sentCart(String userUuid, String sUuid, int page, CartState cartState) {
		Cart cart = cartDao.sentCartItems(userUuid, sUuid, page, cartState);

		cart.setSentCount(cartDao.sentCount(userUuid).getActiveCount());
		if (StringUtils.isNotBlank(sUuid)) {
			cart.setReceivedCount(cartDao.receivedCount(sUuid).getActiveCount());
		}
		cart.setCartFilterCount(cartDao.sentCount(userUuid));
		return cart;
	}

	@Override
	public Cart receivedCart(String userUuid, String sUuid, int page, CartState cartState) {
		Cart cart = cartDao.receivedCartItems(userUuid, sUuid, page, cartState);

		cart.setSentCount(cartDao.sentCount(userUuid).getActiveCount());
		cart.setReceivedCount(cartDao.receivedCount(sUuid).getActiveCount());
		cart.setCartFilterCount(cartDao.receivedCount(sUuid));

		if (cart.getReceivedItems() != null) {
			Object[] userUuids = cart.getReceivedItems().stream().filter(c -> c.isViewStatus())
					.map(CartItemDto::getUserUuid).collect(Collectors.toList()).toArray();

			if (userUuids.length > 0) {
				Map<String, UserDto> map = endpointService.multipleUserDetails(userUuids);

				if (!map.isEmpty()) {
					cart.getReceivedItems().stream().forEach(c -> {
						UserDto u = map.get(c.getUserUuid());
						if (u != null && c.isViewStatus()) {
							c.setUserDetails(u);
						}
					});
				}
			}
		}
		return cart;
	}

	@Override
	public Set<String> productAddedCartItems(String userUuid) {

		return cartDao.addedCartItems(userUuid, ItemType.PRODUCT);
	}

	@Override
	public Set<String> serviceAddedCartItems(String userUuid) {

		return cartDao.addedCartItems(userUuid, ItemType.SERVICE);
	}

	@Override
	public ChartReport chartReport(String sUuid) {

		return cartDao.getChartReport(sUuid);
	}

	@Override
	public CartSummary cartSummary(String sUuid) {

		CartSummary cartSummary = cartDao.cartSummary(sUuid);

		CartCount count = cartDao.receivedCount(sUuid);
		long totalCount = count.getActiveCount() + count.getDeliveredCount() + count.getRejectedCount();
		double totalAmount = count.getActiveGMV() + count.getDeliveredGMV() + count.getRejectedGMV();

		cartSummary.setTotalAmount(totalAmount);
		cartSummary.setTotalCount(totalCount);
		cartSummary.setDeliveredAmount(count.getDeliveredGMV());
		cartSummary.setDeliveredCount(count.getDeliveredCount());

		return cartSummary;
	}

}
