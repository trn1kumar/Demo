package com.gloqr.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.gloqr.config.PropertyValue;
import com.gloqr.config.TemplateCommonUrl;
import com.gloqr.config.TemplateProperties;
import com.gloqr.constant.ItemType;
import com.gloqr.constant.NotificationType;
import com.gloqr.constant.SchedulerSubGroup;
import com.gloqr.decorator.EmailBody;
import com.gloqr.endpoint.NotificationEndpoint;
import com.gloqr.endpoint.dto.EmailEvent;
import com.gloqr.endpoint.dto.SMEInfoDto;
import com.gloqr.endpoint.dto.SchedulerJob;
import com.gloqr.endpoint.dto.SmsEvent;
import com.gloqr.endpoint.dto.UserDto;
import com.gloqr.endpoint.service.EndpointService;
import com.gloqr.entity.CartItem;
import com.gloqr.mapper.Mapper;
import com.google.gson.Gson;

@Service
public class NotificationServiceImpl implements NotificationService {
	private Logger log = LogManager.getLogger();

	@Autowired
	private TemplateEngine templateEngine;

	@Autowired
	private NotificationEndpoint notificationEndpoint;

	@Autowired
	private Mapper mapper;

	@Autowired
	private EndpointService endpointService;

	@Autowired
	private PropertyValue property;

	@Autowired
	private TemplateCommonUrl commonUrl;

	private static final String PRODUCT_NAME = "{productName}";
	private static final String SME_NAME = "{smeName}";
	private static final String USER_NAME = "{userName}";
	private static final String CART_URL = "{cartUrl}";
	private static final String ORDER_ID = "{orderId}";

	@Override
	@Async
	public void sendNotification(CartItem cartItem, NotificationType type, String attachment) {

		EmailBody body = mapper.convert(cartItem.getItemData(), EmailBody.class);
		body.setOrderId(cartItem.getOrderId());
		body.setAttachment(attachment);

		UserDto userDto = endpointService.singleUserDetails(cartItem.getUserUuid());
		SMEInfoDto smeInfo = endpointService.getSMEInfo(cartItem.getsUuid());

		mapper.mapToEmailObj(body, smeInfo, userDto);
		String itemUrl = property.getProductWebsiteUrl();
		if (body.getItemType().equals(ItemType.SERVICE)) {
			itemUrl = property.getServiceWebsiteUrl();
		}
		body.setItemUrl(itemUrl.replace("{itemName}", body.getItemUrlName()).replace("{itemUuid}", body.getItemUuid()));

		notificationFilter(body, type);
	}

	private void notificationFilter(EmailBody body, NotificationType type) {

		log.info("In ASYNC Notification Method");

		EmailEvent emailEvent = null;
		SmsEvent smsEvent = null;
		Map<String, Object> map = new HashMap<>();

		switch (type) {

		case BI_GENERATION:

			if (StringUtils.isNotBlank(body.getSmeEmail())) {
				map.put("userDetailsImgPath", TemplateProperties.USER_DETAILS_IMG);
				Context context = getContext(body, map);
				String subject = createsubjectOrContent(property.getBiGenerationSubject(), body, false);
				String mailPage = templateEngine.process(TemplateProperties.ORDER_RECEIVED_HTML, context);

				emailEvent = new EmailEvent(body.getSmeEmail(), subject, mailPage);
			}

			if (body.getSmePhone() != null) {
				String content = createsubjectOrContent(property.getBiGenerationContent(), body, false);

				smsEvent = new SmsEvent(body.getSmePhone(), content);
			}

			scheduleNotification(TemplateProperties.BI_GENERATION_JOB + body.getOrderId(), smsEvent, emailEvent, map,
					SchedulerSubGroup.BI_FIRST_STAGE, null);
			break;

		case AUTO_QUOTATION:

			if (StringUtils.isNotBlank(body.getSmeEmail())) {
				Context context = getContext(body, map);
				String subject = createsubjectOrContent(property.getBiGenerationSubject(), body, false);
				String mailPage = templateEngine.process(TemplateProperties.AUTO_QUOTATION_SENT_HTML, context);

				emailEvent = new EmailEvent(body.getSmeEmail(), subject, mailPage);
				sendEmail(emailEvent);
			}
			if (body.getSmePhone() != null) {
				String content = createsubjectOrContent(property.getBiAutoGenerationContent(), body, false);

				smsEvent = new SmsEvent(body.getSmePhone(), content);
				sendSMS(smsEvent);
			}
			break;

		case REJECT_BI:

			unScheduleNotification(TemplateProperties.BI_GENERATION_JOB + body.getOrderId());

			if (StringUtils.isNotBlank(body.getUserEmail())) {
				Context context = getContext(body, map);
				String subject = createsubjectOrContent(property.getRejectOrderSubject(), body, true);
				String mailPage = templateEngine.process(TemplateProperties.REJECT_BI_HTML, context);

				emailEvent = new EmailEvent(body.getUserEmail(), subject, mailPage);
				sendEmail(emailEvent);
			}
			if (body.getUserMobile() != null) {
				String content = createsubjectOrContent(property.getRejectOrderContent(), body, true);

				smsEvent = new SmsEvent(String.valueOf(body.getUserMobile()), content);
				sendSMS(smsEvent);
			}
			break;

		case QUOTATION:

			if (StringUtils.isNotBlank(body.getUserEmail())) {
				map.put("secondCartStageImgPath", TemplateProperties.SECOND_STEP_IMG);
				Context context = getContext(body, map);
				String subject = createsubjectOrContent(property.getQuotationSubject(), body, true);
				String mailPage = templateEngine.process(TemplateProperties.QUOTATION_RECEIVED_HTML, context);

				emailEvent = new EmailEvent(body.getUserEmail(), subject, mailPage);
				emailEvent.setAttachmentFileLocation(body.getAttachment());
			}

			if (body.getUserMobile() != null) {
				String content = createsubjectOrContent(property.getQuotationContent(), body, true);

				smsEvent = new SmsEvent(String.valueOf(body.getUserMobile()), content);
			}

			scheduleNotification(TemplateProperties.QUOTATION_RECEIVED_JOB + body.getOrderId(), smsEvent, emailEvent,
					map, SchedulerSubGroup.BI_SECOND_STAGE, TemplateProperties.BI_GENERATION_JOB + body.getOrderId());
			break;

		case REJECT_QUOTATION:

			unScheduleNotification(TemplateProperties.QUOTATION_RECEIVED_JOB + body.getOrderId());

			if (StringUtils.isNotBlank(body.getSmeEmail())) {
				Context context = getContext(body, map);
				String subject = createsubjectOrContent(property.getRejectQuotationSubject(), body, false);
				String mailPage = templateEngine.process(TemplateProperties.REJECT_QUOTATION_HTML, context);

				emailEvent = new EmailEvent(body.getSmeEmail(), subject, mailPage);
				sendEmail(emailEvent);
			}

			if (body.getSmePhone() != null) {
				String content = createsubjectOrContent(property.getRejectQuotationContent(), body, false);

				smsEvent = new SmsEvent(String.valueOf(body.getSmePhone()), content);
				sendSMS(smsEvent);
			}
			break;

		case PURCHASE_ORDER:

			if (StringUtils.isNotBlank(body.getSmeEmail())) {
				map.put("thirdCartStageImgPath", TemplateProperties.THIRD_STEP_IMG);
				Context context = getContext(body, map);
				String subject = createsubjectOrContent(property.getPurchaseOrderSubject(), body, false);
				String mailPage = templateEngine.process(TemplateProperties.PO_RECEIVED_HTML, context);

				emailEvent = new EmailEvent(body.getSmeEmail(), subject, mailPage);
				emailEvent.setAttachmentFileLocation(body.getAttachment());
			}

			if (body.getSmePhone() != null) {
				String content = createsubjectOrContent(property.getPurchaseOrderContent(), body, false);

				smsEvent = new SmsEvent(body.getSmePhone(), content);
			}

			scheduleNotification(TemplateProperties.PO_RECEIVED_JOB + body.getOrderId(), smsEvent, emailEvent, map,
					SchedulerSubGroup.BI_THIRD_STAGE, TemplateProperties.QUOTATION_RECEIVED_JOB + body.getOrderId());
			break;

		case REJECT_PO:

			unScheduleNotification(TemplateProperties.PO_RECEIVED_JOB + body.getOrderId());

			if (StringUtils.isNotBlank(body.getUserEmail())) {
				Context context = getContext(body, map);
				String subject = createsubjectOrContent(property.getRejectPoSubject(), body, true);
				String mailPage = templateEngine.process(TemplateProperties.REJECT_PO_HTML, context);

				emailEvent = new EmailEvent(body.getUserEmail(), subject, mailPage);
				sendEmail(emailEvent);
			}

			if (body.getUserMobile() != null) {
				String content = createsubjectOrContent(property.getRejectPoContent(), body, true);

				smsEvent = new SmsEvent(String.valueOf(body.getUserMobile()), content);
				sendSMS(smsEvent);
			}
			break;

		case CONFIRM_ORDER:

			unScheduleNotification(TemplateProperties.PO_RECEIVED_JOB + body.getOrderId());

			if (StringUtils.isNotBlank(body.getUserEmail())) {
				map.put("fourthCartStageImgPath", TemplateProperties.FOURTH_STEP_IMG);
				Context context = getContext(body, map);
				String subject = createsubjectOrContent(property.getConfirmOrderSubject(), body, true);
				String mailPage = templateEngine.process(TemplateProperties.ORDER_CONFIRMED_HTML, context);

				emailEvent = new EmailEvent(body.getUserEmail(), subject, mailPage);
				sendEmail(emailEvent);
			}

			if (body.getUserMobile() != null) {
				String content = createsubjectOrContent(property.getConfirmOrderContent(), body, true);

				smsEvent = new SmsEvent(String.valueOf(body.getUserMobile()), content);
				sendSMS(smsEvent);
			}
			break;

		default:
			log.warn("Notification Type Not Found");
			break;
		}

	}

	@Override
	@Async
	public void autoQuotationNotification(EmailBody body, NotificationType type, String attachment) {
		body.setAttachment(attachment);
		notificationFilter(body, type);
	}

	private Context getContext(EmailBody body, Map<String, Object> map) {
		Context context = new Context();
		map.put("urls", commonUrl);
		map.put("cartItem", body);

		context.setVariables(map);

		return context;
	}

	private String createsubjectOrContent(String subjectOrContent, EmailBody body, boolean sentCart) {

		String orderID = '#' + body.getOrderId();
		String cartUrl = property.getReceivedCartUrl() + orderID;

		if (sentCart) {
			cartUrl = property.getSentCartUrl() + orderID;
		}
		body.setCartUrl(cartUrl);

		return subjectOrContent.replace(PRODUCT_NAME, body.getItemName()).replace(SME_NAME, body.getSmeName())
				.replace(USER_NAME, body.getUserFullName()).replace(CART_URL, cartUrl)
				.replace(ORDER_ID, body.getOrderId());
	}

	private void scheduleNotification(String jobName, SmsEvent smsEvent, EmailEvent emailEvent, Map<String, Object> map,
			SchedulerSubGroup subGroup, String jobNameForUnSchedule) {

		SchedulerJob job = new SchedulerJob(jobName, property.getSchedulerGroup(), emailEvent, smsEvent);
		job.setRemindNotifiJobDataJsonString(new Gson().toJson(map));
		job.setJobSubGroup(subGroup);

		notificationEndpoint.scheduleJob(job, jobNameForUnSchedule);
	}

	private void unScheduleNotification(String jobName) {
		notificationEndpoint.unScheduleJob(jobName);
	}

	@Override
	public void sendSMS(SmsEvent smsEvent) {
		notificationEndpoint.sendSMS(smsEvent);
	}

	@Override
	public void sendEmail(EmailEvent emailEvent) {
		notificationEndpoint.sendEmail(emailEvent);
	}

	@Override
	@Async
	public void sendAutoClosedNotification(CartItem cartItem) {

		UserDto userDto = endpointService.singleUserDetails(cartItem.getUserUuid());
		SMEInfoDto smeInfo = endpointService.getSMEInfo(cartItem.getsUuid());

		String orderID = '#' + cartItem.getOrderId();
		String receivedCartUrl = property.getReceivedCartUrl() + orderID;
		String sentCartUrl = property.getSentCartUrl() + orderID;

		String smsContent = property.getAutoClosedMessage().replace(PRODUCT_NAME, cartItem.getItemData().getItemName())
				.replace(ORDER_ID, cartItem.getOrderId());

		Context context = new Context();
		context.setVariable("urls", commonUrl);
		context.setVariable("productName", "(" + cartItem.getItemData().getItemType().getName().toLowerCase() + ") "
				+ cartItem.getItemData().getItemName());
		context.setVariable("orderId", cartItem.getOrderId());

		// SME Email
		if (StringUtils.isNotBlank(smeInfo.getContactEmail())) {
			context.setVariable("receiverName", smeInfo.getSmeName());
			context.setVariable("cartUrl", receivedCartUrl);
			String mailPage = templateEngine.process(TemplateProperties.AUTO_CLOSED_HTML, context);
			EmailEvent emailEvent = new EmailEvent(smeInfo.getContactEmail(), property.getAutoClosedSubject(),
					mailPage);
			sendEmail(emailEvent);
		}

		// SME Mobile
		if (StringUtils.isNotBlank(smeInfo.getContactPhone())) {
			SmsEvent smsEvent = new SmsEvent(smeInfo.getContactPhone(), smsContent.replace(CART_URL, receivedCartUrl));
			sendSMS(smsEvent);
		}

		// User Email
		if (StringUtils.isNotBlank(userDto.getUserEmail())) {
			context.setVariable("receiverName", userDto.getUserFullName());
			context.setVariable("cartUrl", sentCartUrl);
			String mailPage = templateEngine.process(TemplateProperties.AUTO_CLOSED_HTML, context);
			EmailEvent emailEvent = new EmailEvent(userDto.getUserEmail(), property.getAutoClosedSubject(), mailPage);
			sendEmail(emailEvent);
		}

		// User Mobile
		if (userDto.getUserMobile() != null) {
			SmsEvent smsEvent = new SmsEvent(String.valueOf(userDto.getUserMobile()),
					smsContent.replace(CART_URL, sentCartUrl));
			sendSMS(smsEvent);
		}
	}
}
