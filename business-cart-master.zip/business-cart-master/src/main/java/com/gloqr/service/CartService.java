package com.gloqr.service;

import java.util.Set;

import com.gloqr.constant.CartState;
import com.gloqr.dto.BusinessInterest;
import com.gloqr.dto.Cart;
import com.gloqr.http.response.CartSummary;
import com.gloqr.http.response.ChartReport;

public interface CartService {

	void generateInterest(BusinessInterest bi);

	long cartCount(String userUuid, String sUuid);

	Cart sentCart(String userUuid, String sUuid, int page, CartState cartState);

	Cart receivedCart(String userUuid, String sUuid, int page, CartState cartState);

	Set<String> productAddedCartItems(String userUuid);

	Set<String> serviceAddedCartItems(String userUuid);

	ChartReport chartReport(String sUuid);

	CartSummary cartSummary(String sUuid);
}
