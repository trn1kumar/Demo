package com.gloqr.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constant.CartConstant;
import com.gloqr.constant.CartState;
import com.gloqr.constant.UrlMapping;
import com.gloqr.dto.BusinessInterest;
import com.gloqr.dto.Cart;
import com.gloqr.exception.CustomException;
import com.gloqr.http.response.CartSummary;
import com.gloqr.http.response.ChartReport;
import com.gloqr.http.response.CustomHttpResponse;
import com.gloqr.service.CartService;
import com.gloqr.util.RequestParser;
import com.gloqr.util.ResponseMaker;

@RestController
@RequestMapping(UrlMapping.BASE_URL)
public class CartController {

	@Autowired
	private CartService cartService;

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private RequestParser requestParser;

	@PostMapping(UrlMapping.ADD_TO_CART)
	@PreAuthorize(value = CartConstant.ROLE_SME_AND_USER)
	public ResponseEntity<CustomHttpResponse<String>> generateInterest(@RequestBody @Valid BusinessInterest bi) {

		if (requestParser.isSME() && requestParser.getSuuid().equals(bi.getsUuid())) {
			throw new CustomException("SME can't generate interest on its own " + bi.getItemType().getName(),
					HttpStatus.NOT_ACCEPTABLE);
		}

		cartService.generateInterest(bi);

		return responseMaker.successResponse("Business Interest Generated", HttpStatus.CREATED);
	}

	@GetMapping(UrlMapping.CART_COUNT)
	@PreAuthorize(value = CartConstant.ROLE_SME_AND_USER)
	public ResponseEntity<CustomHttpResponse<Map<String, Long>>> cartCount() {

		long count = 0;

		if (requestParser.isSME()) {
			count = cartService.cartCount(requestParser.getUserUUID(), requestParser.getSuuid());
		} else {
			count = cartService.cartCount(requestParser.getUserUUID(), null);
		}

		Map<String, Long> map = new HashMap<>();
		map.put("count", count);

		return responseMaker.successResponse(map, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.SENT_CART_ITEMS)
	@PreAuthorize(value = CartConstant.ROLE_SME_AND_USER)
	public ResponseEntity<CustomHttpResponse<Cart>> sentCartItems(
			@RequestParam(defaultValue = "1", value = "page") int page,
			@RequestParam(defaultValue = "ACTIVE", value = "state") CartState cartState) {

		String sUuid = null;
		if (requestParser.isSME()) {
			sUuid = requestParser.getSuuid();
		}

		return responseMaker.successResponse(cartService.sentCart(requestParser.getUserUUID(), sUuid, page, cartState),
				HttpStatus.OK);
	}

	@GetMapping(UrlMapping.RECEIVED_CART_ITEMS)
	@PreAuthorize(value = CartConstant.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<Cart>> receivedCartItems(
			@RequestParam(defaultValue = "1", value = "page") int page,
			@RequestParam(defaultValue = "ACTIVE", value = "state") CartState cartState) {

		return responseMaker.successResponse(
				cartService.receivedCart(requestParser.getUserUUID(), requestParser.getSuuid(), page, cartState),
				HttpStatus.OK);
	}

	@GetMapping(UrlMapping.PRODUCT_ADDED_CART_ITEMS)
	@PreAuthorize(value = CartConstant.ROLE_SME_AND_USER)
	public ResponseEntity<CustomHttpResponse<Set<String>>> productAddedCartItems() {

		return responseMaker.successResponse(cartService.productAddedCartItems(requestParser.getUserUUID()),
				HttpStatus.OK);
	}

	@GetMapping(UrlMapping.SERVICE_ADDED_CART_ITEMS)
	@PreAuthorize(value = CartConstant.ROLE_SME_AND_USER)
	public ResponseEntity<CustomHttpResponse<Set<String>>> serviceAddedCartItems() {

		return responseMaker.successResponse(cartService.serviceAddedCartItems(requestParser.getUserUUID()),
				HttpStatus.OK);
	}

	@GetMapping(UrlMapping.BAR_CHART_DATA)
	@PreAuthorize(value = CartConstant.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<ChartReport>> barChartData() {

		return responseMaker.successResponse(cartService.chartReport(requestParser.getSuuid()), HttpStatus.OK);
	}

	@GetMapping(UrlMapping.CART_SUMMARY)
	@PreAuthorize(value = CartConstant.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<CartSummary>> cartSummary() {

		return responseMaker.successResponse(cartService.cartSummary(requestParser.getSuuid()), HttpStatus.OK);
	}
}
