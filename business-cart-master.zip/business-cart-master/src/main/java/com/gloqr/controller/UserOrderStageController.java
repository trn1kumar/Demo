package com.gloqr.controller;

import javax.validation.Valid;

import org.glassfish.jersey.media.multipart.FormDataParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.gloqr.constant.CartConstant;
import com.gloqr.constant.UrlMapping;
import com.gloqr.dto.PurchaseOrderRequest;
import com.gloqr.dto.RejectOrder;
import com.gloqr.dto.StageDto;
import com.gloqr.http.response.CustomHttpResponse;
import com.gloqr.service.UserStageService;
import com.gloqr.util.CustomValidation;
import com.gloqr.util.RequestParser;
import com.gloqr.util.ResponseMaker;

@RestController
@RequestMapping(UrlMapping.BASE_URL)
public class UserOrderStageController {

	@Autowired
	private RequestParser requestParser;

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private UserStageService stageService;

	@Autowired
	private CustomValidation validation;

	@PostMapping(UrlMapping.ACCEPT_QUOTATION)
	@PreAuthorize(CartConstant.ROLE_USER)
	public ResponseEntity<CustomHttpResponse<StageDto>> acceptQuotation(MultipartHttpServletRequest request,
			@FormDataParam("file") MultipartFile file) {

		PurchaseOrderRequest purchaseOrder = requestParser.parseJsonData(request, "obj", PurchaseOrderRequest.class);
		validation.checkPurchaseOrderObj(purchaseOrder);

		StageDto stageDto = stageService.sendPurchaseOrder(requestParser.getUserUUID(), purchaseOrder, file);

		return responseMaker.successResponse(stageDto, HttpStatus.OK);
	}

	@PutMapping(UrlMapping.REJECT_QUOTATION)
	@PreAuthorize(CartConstant.ROLE_USER)
	public ResponseEntity<CustomHttpResponse<String>> rejectOrder(@RequestBody @Valid RejectOrder rejectOrder) {

		stageService.rejectQuotation(requestParser.getUserUUID(), rejectOrder);
		return responseMaker.successResponse("Cart Item Added to Rejection list", HttpStatus.OK);
	}

}
