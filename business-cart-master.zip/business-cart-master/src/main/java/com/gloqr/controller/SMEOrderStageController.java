package com.gloqr.controller;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.gloqr.constant.CartConstant;
import com.gloqr.constant.UrlMapping;
import com.gloqr.dto.QuotationRequest;
import com.gloqr.dto.RejectOrder;
import com.gloqr.dto.StageDto;
import com.gloqr.endpoint.dto.FileResponse;
import com.gloqr.endpoint.dto.UserDto;
import com.gloqr.exception.CustomException;
import com.gloqr.http.response.CustomHttpResponse;
import com.gloqr.service.SMEStageService;
import com.gloqr.util.CustomValidation;
import com.gloqr.util.RequestParser;
import com.gloqr.util.ResponseMaker;

@RestController
@RequestMapping(UrlMapping.BASE_URL)
public class SMEOrderStageController {

	@Autowired
	private RequestParser requestParser;

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private SMEStageService stageService;

	@Autowired
	private CustomValidation validation;

	@GetMapping(UrlMapping.VIEW_USER_DETAILS)
	@PreAuthorize(value = CartConstant.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<UserDto>> viewUserDetails(@PathVariable String cartUuid) {

		return responseMaker.successResponse(
				stageService.viewUserDetails(cartUuid, requestParser.getSuuid(), requestParser.getUserUUID()),
				HttpStatus.OK);
	}

	@PostMapping(UrlMapping.ACCEPT_ORDER)
	@PreAuthorize(CartConstant.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<StageDto>> acceptOrder(MultipartHttpServletRequest request,
			@FormDataParam("file") MultipartFile file) {

		QuotationRequest quotation = requestParser.parseJsonData(request, "obj", QuotationRequest.class);
		validation.checkQuotationObj(quotation);

		StageDto stageDto = stageService.sendQuotation(requestParser.getSuuid(), quotation, file);

		return responseMaker.successResponse(stageDto, HttpStatus.OK);
	}

	@PutMapping(UrlMapping.REJECT_ORDER)
	@PreAuthorize(CartConstant.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> rejectOrder(@RequestBody @Valid RejectOrder rejectOrder) {

		stageService.rejectOrder(requestParser.getSuuid(), rejectOrder);
		return responseMaker.successResponse("Cart Item Added to Rejection list", HttpStatus.OK);
	}

	@PutMapping(UrlMapping.REJECT_PURCHASE_ORDER)
	@PreAuthorize(CartConstant.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> rejectPurchaseOrder(@RequestBody @Valid RejectOrder rejectOrder) {

		stageService.rejectPurchaseOrder(requestParser.getSuuid(), rejectOrder);
		return responseMaker.successResponse("Cart Item Added to Rejection list", HttpStatus.OK);
	}

	@PutMapping(UrlMapping.CONFIRM_ORDER)
	@PreAuthorize(CartConstant.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> confirmOrder(@PathVariable String cartUuid) {

		if (StringUtils.isNotBlank(cartUuid)) {
			stageService.confirmOrder(requestParser.getSuuid(), cartUuid);
		} else {
			throw new CustomException("Cart Uuid cannot be null or empty", HttpStatus.BAD_REQUEST);
		}

		return responseMaker.successResponse("Cart Item Delivered", HttpStatus.OK);
	}

	@GetMapping(UrlMapping.GENERATE_QUOTATION)
	@PreAuthorize(CartConstant.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<FileResponse>> generateQuotation(@PathVariable String cartUuid) {

		return responseMaker.successResponse(stageService.generateQuotation(cartUuid, requestParser.getSuuid()),
				HttpStatus.OK);
	}

}
