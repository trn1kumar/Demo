package com.gloqr.state;

import com.gloqr.entity.CartItem;

public interface State {
	void acceptStage(CartItem cartItem);

	void rejectStage(CartItem cartItem, String rejetMessage);
}
