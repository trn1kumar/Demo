package com.gloqr.config;

import javax.annotation.Resource;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.gloqr.endpoint.ContentServer;
import com.gloqr.endpoint.NotificationEndpoint;
import com.gloqr.endpoint.PricingEndpoint;
import com.gloqr.endpoint.ProductEndpoint;
import com.gloqr.endpoint.ServiceEndpoint;
import com.gloqr.endpoint.SmeEndpoint;
import com.gloqr.endpoint.UserEndpoint;

@Configuration
@PropertySource(value = { "file:${location}/business_cart_${env}.properties" })
public class CartConfig {

	@Resource
	private Environment environment;

	@Bean
	public ClientConfig clientConfig() {
		ClientConfig configuration = new ClientConfig();
		configuration.property(ClientProperties.CONNECT_TIMEOUT, 10000);
		configuration.property(ClientProperties.READ_TIMEOUT, 30000);

		return configuration;
	}

	@Bean
	public ContentServer contentServerConfig() {
		Client client = ClientBuilder.newBuilder().register(MultiPartFeature.class).build();
		String enpoint = environment.getRequiredProperty("contentserver.endpoint");
		String uploadFile = environment.getRequiredProperty("upload.files");
		String deleteFile = environment.getRequiredProperty("delete.files");

		return new ContentServer(client, enpoint, uploadFile, deleteFile);
	}

	@Bean
	public ProductEndpoint productConfig() {
		Client client = ClientBuilder.newClient(clientConfig());
		String enpoint = environment.getRequiredProperty("product.endpoint");
		String detailsPath = environment.getRequiredProperty("product.details.path");
		String biCountPath = environment.getRequiredProperty("product.bicount.path");

		return new ProductEndpoint(client, enpoint, detailsPath, biCountPath);
	}

	@Bean
	public ServiceEndpoint serviceConfig() {
		Client client = ClientBuilder.newClient();
		String enpoint = environment.getRequiredProperty("service.endpoint");
		String detailsPath = environment.getRequiredProperty("service.details.path");
		String biCountPath = environment.getRequiredProperty("service.bicount.path");

		return new ServiceEndpoint(client, enpoint, detailsPath, biCountPath);
	}

	@Bean
	public UserEndpoint userConfig() {
		Client client = ClientBuilder.newClient(clientConfig());
		String enpoint = environment.getRequiredProperty("user.endpoint");
		String userDetailsPath = environment.getRequiredProperty("user.detail");
		String multipleUserPath = environment.getRequiredProperty("multiple.user.detail");

		return new UserEndpoint(client, enpoint, userDetailsPath, multipleUserPath);
	}

	@Bean
	public SmeEndpoint smeConfig() {
		Client client = ClientBuilder.newClient(clientConfig());
		String enpoint = environment.getRequiredProperty("sme.endpoint");
		String userDetailsPath = environment.getRequiredProperty("sme.detail");
		String countUpdate = environment.getRequiredProperty("count.update");

		return new SmeEndpoint(client, enpoint, userDetailsPath, countUpdate);
	}

	@Bean
	public PricingEndpoint pricingConfig() {
		Client client = ClientBuilder.newClient(clientConfig());
		String enpoint = environment.getRequiredProperty("pricing.endpoint");
		String creditsPath = environment.getRequiredProperty("pricing.credits");
		String adminCreditsPath = environment.getRequiredProperty("pricing.admin.credits");

		return new PricingEndpoint(client, enpoint, creditsPath, adminCreditsPath);
	}

	@Bean
	public NotificationEndpoint notificationConfig() {
		Client client = ClientBuilder.newClient(clientConfig());
		String enpoint = environment.getRequiredProperty("notification.endpoint");
		String emailPath = environment.getRequiredProperty("email.path");
		String smsPath = environment.getRequiredProperty("sms.path");
		String schedulePath = environment.getRequiredProperty("schedule.job.path");
		String unSchedulePath = environment.getRequiredProperty("unschedule.job.path");

		return new NotificationEndpoint(client, enpoint, emailPath, smsPath, schedulePath, unSchedulePath);
	}

	@Bean
	public TemplateCommonUrl templatePropertiesConfig() {

		String websiteUrl = environment.getRequiredProperty("website.url");
		String contentServerUrl = environment.getRequiredProperty("content.server.cdn.path");

		return new TemplateCommonUrl(websiteUrl, contentServerUrl);
	}

	@Bean(name = "taskExecutor")
	public TaskExecutor workExecutor() {
		ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
		threadPoolTaskExecutor.setThreadNamePrefix("Async-Thread");

		threadPoolTaskExecutor.setCorePoolSize(5);
		threadPoolTaskExecutor.setMaxPoolSize(10);
		threadPoolTaskExecutor.setQueueCapacity(600);
		threadPoolTaskExecutor.afterPropertiesSet();

		return threadPoolTaskExecutor;
	}
}
