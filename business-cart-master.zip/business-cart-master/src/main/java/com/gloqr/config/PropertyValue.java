package com.gloqr.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PropertyValue {

	// Quotation Format JRXML path
	@Value(value = "${quotation.format.path}")
	private String formatPath;

	// SME Quotation Store Folder path
	@Value(value = "${quotation.store.path}")
	private String storePath;

	// SME LOGO path
	@Value(value = "${sme.logo.path}")
	private String smeLogoPath;

	// DIST Path
	@Value(value = "${quotation.dist.path}")
	private String distPath;

	// Notification Scheduler Job Name
	@Value(value = "${scheduler.group.name}")
	private String schedulerGroup;

	// After Show Interest
	@Value(value = "${email.subject.bi.generation}")
	private String biGenerationSubject;
	@Value(value = "${sms.content.bi.generation}")
	private String biGenerationContent;
	@Value(value = "${sms.content.bi.generation.auto}")
	private String biAutoGenerationContent;

	// First Stage Accept and Reject
	@Value(value = "${email.subject.quotation}")
	private String quotationSubject;
	@Value(value = "${sms.content.quotation}")
	private String quotationContent;
	@Value(value = "${email.subject.reject.order}")
	private String rejectOrderSubject;
	@Value(value = "${sms.content.reject.order}")
	private String rejectOrderContent;

	// Second Stage Accept and Reject
	@Value(value = "${email.subject.purchase.order}")
	private String purchaseOrderSubject;
	@Value(value = "${sms.content.purchase.order}")
	private String purchaseOrderContent;
	@Value(value = "${email.subject.reject.quotation}")
	private String rejectQuotationSubject;
	@Value(value = "${sms.content.reject.quotation}")
	private String rejectQuotationContent;

	// Third Stage Accept and Reject
	@Value(value = "${email.subject.reject.po}")
	private String rejectPoSubject;
	@Value(value = "${sms.content.reject.po}")
	private String rejectPoContent;
	@Value(value = "${email.subject.confirm.order}")
	private String confirmOrderSubject;
	@Value(value = "${sms.content.confirm.order}")
	private String confirmOrderContent;

	// Web site Cart URL
	@Value(value = "${sent.cart.web.url}")
	private String sentCartUrl;
	@Value(value = "${received.cart.web.url}")
	private String receivedCartUrl;

	// Web site Product & Service Details Page URL
	@Value(value = "${product.website.url}")
	private String productWebsiteUrl;
	@Value(value = "${service.website.url}")
	private String serviceWebsiteUrl;

	// Auto Closed
	@Value(value = "${auto.closed.subject}")
	private String autoClosedSubject;
	@Value(value = "${auto.closed.message}")
	private String autoClosedMessage;

	public String getFormatPath() {
		return formatPath;
	}

	public String getStorePath() {
		return storePath;
	}

	public String getSmeLogoPath() {
		return smeLogoPath;
	}

	public String getDistPath() {
		return distPath;
	}

	public String getSchedulerGroup() {
		return schedulerGroup;
	}

	public String getBiGenerationSubject() {
		return biGenerationSubject;
	}

	public String getBiGenerationContent() {
		return biGenerationContent;
	}

	public String getBiAutoGenerationContent() {
		return biAutoGenerationContent;
	}

	public String getRejectOrderSubject() {
		return rejectOrderSubject;
	}

	public String getRejectOrderContent() {
		return rejectOrderContent;
	}

	public String getQuotationSubject() {
		return quotationSubject;
	}

	public String getQuotationContent() {
		return quotationContent;
	}

	public String getRejectQuotationSubject() {
		return rejectQuotationSubject;
	}

	public String getRejectQuotationContent() {
		return rejectQuotationContent;
	}

	public String getPurchaseOrderSubject() {
		return purchaseOrderSubject;
	}

	public String getPurchaseOrderContent() {
		return purchaseOrderContent;
	}

	public String getRejectPoSubject() {
		return rejectPoSubject;
	}

	public String getRejectPoContent() {
		return rejectPoContent;
	}

	public String getConfirmOrderSubject() {
		return confirmOrderSubject;
	}

	public String getConfirmOrderContent() {
		return confirmOrderContent;
	}

	public String getSentCartUrl() {
		return sentCartUrl;
	}

	public String getReceivedCartUrl() {
		return receivedCartUrl;
	}

	public String getProductWebsiteUrl() {
		return productWebsiteUrl;
	}

	public String getServiceWebsiteUrl() {
		return serviceWebsiteUrl;
	}

	public String getAutoClosedSubject() {
		return autoClosedSubject;
	}

	public String getAutoClosedMessage() {
		return autoClosedMessage;
	}

}
