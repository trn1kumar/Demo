package com.gloqr.config;

public class TemplateProperties {

	private TemplateProperties() {
		super();
	}

	public static final String BI_GENERATION_JOB = "BIGeneration_";
	public static final String QUOTATION_RECEIVED_JOB = "QuotationReceived_";
	public static final String PO_RECEIVED_JOB = "PurchaseOrderReceived_";

	public static final String ORDER_RECEIVED_HTML = "order-received";
	public static final String QUOTATION_RECEIVED_HTML = "quotation-received";
	public static final String PO_RECEIVED_HTML = "po-received";
	public static final String ORDER_CONFIRMED_HTML = "order-confirmed";
	public static final String AUTO_QUOTATION_SENT_HTML = "auto-quotation-sent";

	public static final String REJECT_BI_HTML = "order-rejected";
	public static final String REJECT_PO_HTML = "po-rejected";
	public static final String REJECT_QUOTATION_HTML = "quotation-rejected";

	public static final String AUTO_CLOSED_HTML = "auto-closed";

	public static final String USER_DETAILS_IMG = TemplateCommonUrl.BASE_PATH + "view_user-detail.png";
	public static final String SECOND_STEP_IMG = TemplateCommonUrl.BASE_PATH + "QuotationReceivedCompleteStep.png";
	public static final String THIRD_STEP_IMG = TemplateCommonUrl.BASE_PATH + "3rdstage.PNG";
	public static final String FOURTH_STEP_IMG = TemplateCommonUrl.BASE_PATH + "OrderConfirmedStep.png";
}
