package com.gloqr.endpoint.dto;

import com.gloqr.constant.SchedulerSubGroup;

public class SchedulerJob {

	private String jobName;
	private String jobGroup;
	private EmailEvent emailEvent;
	private SmsEvent smsEvent;
	private SchedulerSubGroup jobSubGroup;
	private String remindNotifiJobDataJsonString;

	public SchedulerJob(String jobName, String jobGroup, EmailEvent emailEvent, SmsEvent smsEvent) {
		super();
		this.jobName = jobName;
		this.jobGroup = jobGroup;
		this.emailEvent = emailEvent;
		this.smsEvent = smsEvent;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public EmailEvent getEmailEvent() {
		return emailEvent;
	}

	public void setEmailEvent(EmailEvent emailEvent) {
		this.emailEvent = emailEvent;
	}

	public SmsEvent getSmsEvent() {
		return smsEvent;
	}

	public void setSmsEvent(SmsEvent smsEvent) {
		this.smsEvent = smsEvent;
	}

	public SchedulerSubGroup getJobSubGroup() {
		return jobSubGroup;
	}

	public void setJobSubGroup(SchedulerSubGroup jobSubGroup) {
		this.jobSubGroup = jobSubGroup;
	}

	public String getRemindNotifiJobDataJsonString() {
		return remindNotifiJobDataJsonString;
	}

	public void setRemindNotifiJobDataJsonString(String remindNotifiJobDataJsonString) {
		this.remindNotifiJobDataJsonString = remindNotifiJobDataJsonString;
	}

	public String getJobGroup() {
		return jobGroup;
	}

	public void setJobGroup(String jobGroup) {
		this.jobGroup = jobGroup;
	}

}
