package com.gloqr.endpoint.service;

import java.util.Map;

import com.gloqr.constant.CreditType;
import com.gloqr.constant.ItemType;
import com.gloqr.endpoint.dto.PricingRequest;
import com.gloqr.endpoint.dto.ProductDto;
import com.gloqr.endpoint.dto.SMEInfoDto;
import com.gloqr.endpoint.dto.ServiceDto;
import com.gloqr.endpoint.dto.UserDto;

public interface EndpointService {

	ProductDto getProduct(String itemUuid);

	ServiceDto getService(String itemUuid);

	void incrementBiCount(ItemType itemType, String itemUuid, String token);

	UserDto singleUserDetails(String userUuid);

	Map<String, UserDto> multipleUserDetails(Object[] userUuids);

	SMEInfoDto getSMEInfo(String sUuid);

	long asyncCheckCredits(CreditType creditType, String sUuid);

	void asyncUpdateCredits(PricingRequest pricingRequest);

	void checkCredits(CreditType creditType);

	void updateCredits(PricingRequest request);

}
