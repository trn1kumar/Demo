package com.gloqr.endpoint.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.gloqr.constant.CreditType;
import com.gloqr.constant.ItemType;
import com.gloqr.endpoint.PricingEndpoint;
import com.gloqr.endpoint.ProductEndpoint;
import com.gloqr.endpoint.ServiceEndpoint;
import com.gloqr.endpoint.SmeEndpoint;
import com.gloqr.endpoint.UserEndpoint;
import com.gloqr.endpoint.dto.PricingRequest;
import com.gloqr.endpoint.dto.ProductDto;
import com.gloqr.endpoint.dto.SMEInfoDto;
import com.gloqr.endpoint.dto.ServiceDto;
import com.gloqr.endpoint.dto.UserDto;

@Service
public class EndpointServiceImpl implements EndpointService {

	@Autowired
	private ProductEndpoint productEndpoint;

	@Autowired
	private ServiceEndpoint serviceEndpoint;

	@Autowired
	private UserEndpoint userEndpoint;

	@Autowired
	private PricingEndpoint pricingEndpoint;

	@Autowired
	private SmeEndpoint smeEndpoint;

	@Override
	public ProductDto getProduct(String itemUuid) {
		return productEndpoint.getProduct(itemUuid);
	}

	@Override
	public ServiceDto getService(String itemUuid) {
		return serviceEndpoint.getService(itemUuid);
	}

	@Override
	@Async
	public void incrementBiCount(ItemType itemType, String itemUuid, String token) {
		if (itemType.equals(ItemType.PRODUCT)) {
			productEndpoint.incrementProductBiCount(itemUuid, token);
		} else {
			serviceEndpoint.incrementServiceBiCount(itemUuid, token);
		}
	}

	@Override
	public UserDto singleUserDetails(String userUuid) {
		return userEndpoint.singleUserDetails(userUuid);
	}

	@Override
	public Map<String, UserDto> multipleUserDetails(Object[] userUuids) {
		return userEndpoint.multipleUserDetails(userUuids);
	}

	@Override
	public long asyncCheckCredits(CreditType creditType, String sUuid) {
		return pricingEndpoint.asyncCheckCredits(creditType, sUuid);
	}

	@Override
	public void asyncUpdateCredits(PricingRequest pricingRequest) {
		pricingEndpoint.asyncUpdateCredits(pricingRequest);
	}

	@Override
	public void checkCredits(CreditType creditType) {
		pricingEndpoint.checkCredits(creditType);
	}

	@Override
	public void updateCredits(PricingRequest request) {
		pricingEndpoint.updateCredits(request);
	}

	@Override
	public SMEInfoDto getSMEInfo(String sUuid) {
		return smeEndpoint.getSmeInfo(sUuid);
	}

}
