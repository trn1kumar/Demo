package com.gloqr.endpoint;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

import com.gloqr.dto.BICountUpdate;
import com.gloqr.endpoint.dto.SMEInfoDto;
import com.gloqr.exception.CustomException;
import com.gloqr.http.response.CustomHttpResponse;

public class SmeEndpoint {
	private Client client;
	private String enpoint;
	private String smeDetailPath;
	private String countUpdate;

	@Value(value = "${internal.secret.key}")
	private String secretKey;

	Logger logger = LogManager.getLogger();

	public SmeEndpoint(Client client, String enpoint, String smeDetailPath, String countUpdate) {
		this.client = client;
		this.enpoint = enpoint;
		this.smeDetailPath = smeDetailPath;
		this.countUpdate = countUpdate;
	}

	public SMEInfoDto getSmeInfo(String sUuid) {

		logger.info("Getting SME Details by ID :: " + sUuid);

		Response response = null;
		CustomHttpResponse<SMEInfoDto> httpResponse = null;

		try {
			response = client.target(enpoint).path(smeDetailPath.replace("{sUuid}", sUuid))
					.request(MediaType.APPLICATION_JSON).get();

			logger.info("Response from SME endpoint :: " + response.toString());

		} catch (Exception e) {
			throw new CustomException("Internal Server Error", e);
		}

		httpResponse = response.readEntity(new GenericType<CustomHttpResponse<SMEInfoDto>>() {
		});

		if (httpResponse.isError()) {
			throw new CustomException(httpResponse.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
			return httpResponse.getData();
		}

	}

	public void updateBiCountInSME(List<BICountUpdate> biCountUpdate) {

		try {
			Response response = client.target(enpoint).path(countUpdate).queryParam("key", secretKey)
					.request(MediaType.APPLICATION_JSON).put(Entity.entity(biCountUpdate, MediaType.APPLICATION_JSON));

			logger.info("Response from SME endpoint :: " + response.toString());

			CustomHttpResponse<String> httpResponse = response
					.readEntity(new GenericType<CustomHttpResponse<String>>() {
					});

			if (httpResponse.isError()) {
				logger.error("Error while updating bi count in sme module :: " + httpResponse.getMessage());
			}
		} catch (Exception e) {
			logger.error("Internal Server Error " + e);
		}

	}

}
