package com.gloqr.endpoint;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;

import com.gloqr.endpoint.dto.ProductDto;
import com.gloqr.exception.CustomException;
import com.gloqr.http.response.CustomHttpResponse;
import com.gloqr.security.JWTConstants;

public class ProductEndpoint {

	Logger logger = LogManager.getLogger();

	Client client;
	String endpoint;
	String detailsPath;
	String biCountPath;

	public ProductEndpoint(Client client, String endpoint, String detailsPath, String biCountPath) {
		super();
		this.client = client;
		this.endpoint = endpoint;
		this.detailsPath = detailsPath;
		this.biCountPath = biCountPath;
	}

	public ProductDto getProduct(String productUuid) {

		logger.info("Getting Product Details by id :: " + productUuid);
		Response response = null;
		CustomHttpResponse<ProductDto> httpResponse = null;

		try {
			response = client.target(endpoint).path(detailsPath.replace("{uuid}", productUuid))
					.request(MediaType.APPLICATION_JSON).get();

			logger.info("Response from Product endpoint :: " + response.toString());
		} catch (Exception e) {
			throw new CustomException("Internal Server Error", e);
		}

		httpResponse = response.readEntity(new GenericType<CustomHttpResponse<ProductDto>>() {
		});

		if (httpResponse.isError()) {
			throw new CustomException(httpResponse.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
			return httpResponse.getData();
		}

	}

	public void incrementProductBiCount(String productUuid, String token) {

		logger.info("Incrementing BI Count of Product ID :: " + productUuid);
		Response response = null;
		CustomHttpResponse<String> httpResponse = null;

		try {
			response = client.target(endpoint).path(biCountPath.replace("{uuid}", productUuid))
					.request(MediaType.APPLICATION_JSON).header(JWTConstants.HEADER_STRING, token)
					.put(Entity.entity(productUuid, MediaType.APPLICATION_JSON));

			logger.info("Response from Product endpoint :: " + response.toString());
		} catch (Exception e) {
			throw new CustomException("Internal Server Error", HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

		httpResponse = response.readEntity(new GenericType<CustomHttpResponse<String>>() {
		});

		if (httpResponse.isError()) {
			logger.info("Error Incrementing BI Count :: " + httpResponse.getMessage());
		} else {
			logger.info("BI Count Incremented Successfully");
		}

	}

}
