package com.gloqr.endpoint;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;

import com.gloqr.endpoint.dto.ServiceDto;
import com.gloqr.exception.CustomException;
import com.gloqr.http.response.CustomHttpResponse;
import com.gloqr.security.JWTConstants;

public class ServiceEndpoint {

	Logger logger = LogManager.getLogger();

	Client client;
	String endpoint;
	String detailsPath;
	String biCountPath;

	public ServiceEndpoint(Client client, String endpoint, String detailsPath, String biCountPath) {
		super();
		this.client = client;
		this.endpoint = endpoint;
		this.detailsPath = detailsPath;
		this.biCountPath = biCountPath;
	}

	public ServiceDto getService(String serviceUuid) {

		logger.info("Getting Service Details by id :: " + serviceUuid);
		Response response = null;
		CustomHttpResponse<ServiceDto> httpResponse = null;

		try {
			response = client.target(endpoint).path(detailsPath.replace("{uuid}", serviceUuid))
					.request(MediaType.APPLICATION_JSON).get();

			logger.info("Response from Service endpoint :: " + response.toString());
		} catch (Exception e) {
			throw new CustomException("Internal Server Error", e);
		}

		httpResponse = response.readEntity(new GenericType<CustomHttpResponse<ServiceDto>>() {
		});

		if (httpResponse.isError()) {
			throw new CustomException(httpResponse.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
			return httpResponse.getData();
		}

	}

	public void incrementServiceBiCount(String serviceUuid, String token) {

		logger.info("Incrementing BI Count of Service ID :: " + serviceUuid);
		Response response = null;
		CustomHttpResponse<String> httpResponse = null;

		try {
			response = client.target(endpoint).path(biCountPath.replace("{uuid}", serviceUuid))
					.request(MediaType.APPLICATION_JSON).header(JWTConstants.HEADER_STRING, token)
					.put(Entity.entity(serviceUuid, MediaType.APPLICATION_JSON));

			logger.info("Response from Service endpoint :: " + response.toString());
		} catch (Exception e) {
			throw new CustomException("Internal Server Error", HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

		httpResponse = response.readEntity(new GenericType<CustomHttpResponse<String>>() {
		});

		if (httpResponse.isError()) {
			logger.info("Error Incrementing BI Count :: " + httpResponse.getMessage());
		} else {
			logger.info("BI Count Incremented Successfully");
		}

	}

}
