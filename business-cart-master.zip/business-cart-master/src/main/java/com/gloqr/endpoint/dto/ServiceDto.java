package com.gloqr.endpoint.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ServiceDto extends CommonField {

	private String serviceUuid;
	private String serviceName;
	private String serviceUrlName;

	public String getServiceUuid() {
		return serviceUuid;
	}

	public String getServiceName() {
		return serviceName;
	}

	public String getServiceUrlName() {
		return serviceUrlName;
	}

}
