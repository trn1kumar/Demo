package com.gloqr.endpoint;

import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;

import com.gloqr.endpoint.dto.UserDto;
import com.gloqr.exception.CustomException;
import com.gloqr.http.response.CustomHttpResponse;

public class UserEndpoint {
	Logger logger = LogManager.getLogger();

	private Client client;
	private String enpoint;
	private String userDetailsPath;
	private String multipleUserPath;

	public UserEndpoint(Client client, String enpoint, String userDetailsPath, String multipleUserPath) {
		super();
		this.client = client;
		this.enpoint = enpoint;
		this.userDetailsPath = userDetailsPath;
		this.multipleUserPath = multipleUserPath;
	}

	public UserDto singleUserDetails(String userUuid) {

		logger.info("Getting User Details by id :: " + userUuid);
		Response response = null;
		CustomHttpResponse<UserDto> httpResponse = null;

		try {
			response = client.target(enpoint).path(userDetailsPath.replace("{userUuid}", userUuid))
					.request(MediaType.APPLICATION_JSON).get();

			logger.info("Response from User endpoint :: " + response.toString());
		} catch (Exception e) {
			throw new CustomException("Internal Server Error", e);
		}

		httpResponse = response.readEntity(new GenericType<CustomHttpResponse<UserDto>>() {
		});

		if (httpResponse.isError()) {
			throw new CustomException(httpResponse.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
			return httpResponse.getData();
		}
	}

	public Map<String, UserDto> multipleUserDetails(Object[] userUuids) {

		logger.info("Getting Multiple User Details");
		Response response = null;

		try {
			response = client.target(enpoint).path(multipleUserPath).queryParam("userUuids", userUuids)
					.request(MediaType.APPLICATION_JSON).get();

			logger.info("Response from User endpoint :: " + response.toString());
		} catch (Exception e) {
			throw new CustomException("Internal Server Error", e);
		}

		CustomHttpResponse<Map<String, UserDto>> httpResponse = response
				.readEntity(new GenericType<CustomHttpResponse<Map<String, UserDto>>>() {
				});

		return httpResponse.getData();
	}
}
