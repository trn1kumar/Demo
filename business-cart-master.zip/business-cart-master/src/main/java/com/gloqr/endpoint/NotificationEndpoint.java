package com.gloqr.endpoint;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.gloqr.endpoint.dto.EmailEvent;
import com.gloqr.endpoint.dto.SchedulerJob;
import com.gloqr.endpoint.dto.SmsEvent;

public class NotificationEndpoint {

	Logger log = LogManager.getLogger();

	private Client client;
	private String endPoint;
	private String emailPath;
	private String smsPath;
	private String schedulePath;
	private String unSchedulePath;

	public NotificationEndpoint(Client client, String endPoint, String emailPath, String smsPath, String schedulePath,
			String unSchedulePath) {
		super();
		this.client = client;
		this.endPoint = endPoint;
		this.emailPath = emailPath;
		this.smsPath = smsPath;
		this.schedulePath = schedulePath;
		this.unSchedulePath = unSchedulePath;
	}

	public void sendSMS(SmsEvent smsEvent) {
		log.info("Sending SMS to Mobile Number :: " + smsEvent.getMobileNo());
		try {
			Response response = client.target(endPoint).path(smsPath).request(MediaType.APPLICATION_JSON)
					.post(Entity.entity(smsEvent, MediaType.APPLICATION_JSON));

			log.info("SMS Sent Response :: " + response.toString());
		} catch (Exception e) {
			log.error("Error while sending SMS :: " + e.toString());
		}
	}

	public void sendEmail(EmailEvent emailEvent) {
		log.info("Sending Email to Id :: " + emailEvent.getEmailId());
		try {
			Response response = client.target(endPoint).path(emailPath).request(MediaType.APPLICATION_JSON)
					.post(Entity.entity(emailEvent, MediaType.APPLICATION_JSON));

			log.info("Email Sent Response :: " + response.toString());
		} catch (Exception e) {
			log.error("Error while sending Email :: " + e.toString());
		}
	}

	public void scheduleJob(SchedulerJob job, String jobNameForUnSchedule) {
		log.info("Scheduling job for :: " + job.getJobName());
		try {
			Response response = client.target(endPoint).path(schedulePath)
					.queryParam("jobNameForUnSchedule", jobNameForUnSchedule).request(MediaType.APPLICATION_JSON)
					.post(Entity.entity(job, MediaType.APPLICATION_JSON));

			log.info("Scheduling Job Response :: " + response.toString());
		} catch (Exception e) {
			log.error("Error while Scheduling Job :: " + e.toString());
		}
	}

	public void unScheduleJob(String jobName) {
		log.info("UnScheduling job for :: " + jobName);
		try {
			Response response = client.target(endPoint).path(unSchedulePath).queryParam("jobName", jobName)
					.request(MediaType.APPLICATION_JSON).put(Entity.entity(jobName, MediaType.APPLICATION_JSON));

			log.info("UnScheduling Job Response :: " + response.toString());
		} catch (Exception e) {
			log.error("Error while UnScheduling Job :: " + e.toString());
		}
	}

}
