package com.gloqr.endpoint.dto;

import com.gloqr.constant.CreditType;

public class PricingRequest {

	private String sUuid;
	private String userUUID;
	private CreditType creditType;
	private String action;
	private long credits;
	private String usedFor;

	public PricingRequest(CreditType creditType, String action, long credits) {
		super();
		this.creditType = creditType;
		this.action = action;
		this.credits = credits;
	}

	public String getsUuid() {
		return sUuid;
	}

	public String getUserUUID() {
		return userUUID;
	}

	public CreditType getCreditType() {
		return creditType;
	}

	public String getAction() {
		return action;
	}

	public long getCredits() {
		return credits;
	}

	public String getUsedFor() {
		return usedFor;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public void setUserUUID(String userUUID) {
		this.userUUID = userUUID;
	}

	public void setUsedFor(String usedFor) {
		this.usedFor = usedFor;
	}

	@Override
	public String toString() {
		return "PricingRequest [sUuid=" + sUuid + ", userUUID=" + userUUID + ", creditType=" + creditType + ", action="
				+ action + ", credits=" + credits + ", usedFor=" + usedFor + "]";
	}

}
