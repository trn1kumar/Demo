package com.gloqr.endpoint.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.endpoint.ContentServer;
import com.gloqr.endpoint.dto.FileResponse;
import com.gloqr.exception.CustomException;
import com.gloqr.util.FileUtil;

@Service
public class FileServiceImpl implements FileService {

	@Autowired
	private ContentServer contentServer;

	@Autowired
	private FileUtil fileUtil;

	@Override
	public FileResponse sendSingleFile(MultipartFile file, String fileLocation) throws IOException {
		FileResponse response = null;
		try {
			response = contentServer.sendSingleFile(file, file.getOriginalFilename(), fileLocation);
		} catch (CustomException e) {
			throw e;
		}
		return response;
	}

	@Override
	public void deleteFile(String fileLocation) throws IOException {
		try {
			contentServer.deleteFileFromContentServer(fileLocation);
		} catch (CustomException e) {
			throw e;
		}
	}

	@Override
	public void checkFileFormat(MultipartFile file) {
		fileUtil.checkFileFormat(file);
	}

}
