package com.gloqr.endpoint.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AddressDto {

	private String street;
	private String locality;
	private String city;
	private String state;
	private String country;
	private int pincode;

	public String getStreet() {
		return street;
	}

	public String getLocality() {
		return locality;
	}

	public String getCity() {
		return city;
	}

	public String getState() {
		return state;
	}

	public String getCountry() {
		return country;
	}

	public int getPincode() {
		return pincode;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return street + ", " + locality + ", " + city + ", " + state + ", " + country + ", " + pincode;
	}

}
