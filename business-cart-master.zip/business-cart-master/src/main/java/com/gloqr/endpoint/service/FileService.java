package com.gloqr.endpoint.service;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

import com.gloqr.endpoint.dto.FileResponse;

public interface FileService {

	// Single file upload
	FileResponse sendSingleFile(MultipartFile file, String fileLocation) throws IOException;

	// Delete single file from Content Server
	void deleteFile(String fileLocation) throws IOException;

	// Check File Format & Size
	void checkFileFormat(MultipartFile file);
}
