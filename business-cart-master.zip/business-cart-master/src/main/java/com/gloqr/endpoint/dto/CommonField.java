package com.gloqr.endpoint.dto;

import java.util.List;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.gloqr.constant.QuotationFormat;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CommonField {

	private String sUuid;
	private String smeName;
	private String mainImage;
	private String priceUnit;
	private double price;
	private double discountedPrice;
	private int discount;
	private boolean active;
	private QuotationFormat quotationFormat;
	private String termsAndCondition;
	private float gst;
	private String description;
	private String location;
	private Map<String, String> specifications;
	private List<FileResponse> images;
	private boolean autoQuotation;

	public String getsUuid() {
		return sUuid;
	}

	public String getSmeName() {
		return smeName;
	}

	public String getMainImage() {
		return mainImage;
	}

	public String getPriceUnit() {
		return priceUnit;
	}

	public double getPrice() {
		return price;
	}

	public double getDiscountedPrice() {
		return discountedPrice;
	}

	public int getDiscount() {
		return discount;
	}

	public boolean isActive() {
		return active;
	}

	public QuotationFormat getQuotationFormat() {
		return quotationFormat;
	}

	public String getTermsAndCondition() {
		return termsAndCondition;
	}

	public float getGst() {
		return gst;
	}

	public String getDescription() {
		return description;
	}

	public String getLocation() {
		return location;
	}

	public Map<String, String> getSpecifications() {
		return specifications;
	}

	public List<FileResponse> getImages() {
		return images;
	}

	public boolean isAutoQuotation() {
		return autoQuotation;
	}

}
