package com.gloqr.endpoint.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class UserDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String uuid;
	private String userEmail;
	private Long userMobile;
	private String userFullName;

	public String getUuid() {
		return uuid;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public Long getUserMobile() {
		return userMobile;
	}

	public String getUserFullName() {
		return userFullName;
	}

}
