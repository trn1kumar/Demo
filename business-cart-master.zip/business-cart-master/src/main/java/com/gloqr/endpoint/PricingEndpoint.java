package com.gloqr.endpoint;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

import com.gloqr.constant.CreditType;
import com.gloqr.endpoint.dto.CreditsResponse;
import com.gloqr.endpoint.dto.PricingRequest;
import com.gloqr.exception.CustomException;
import com.gloqr.exception.NoCreditException;
import com.gloqr.http.response.CustomHttpResponse;
import com.gloqr.security.JWTConstants;
import com.gloqr.util.RequestParser;

public class PricingEndpoint {

	Logger logger = LogManager.getLogger();

	private Client client;
	private String endpoint;
	private String creditsPath;
	private String adminCreditsPath;

	@Value(value = "${internal.secret.key}")
	private String secretKey;

	@Autowired
	private RequestParser requestParser;

	public PricingEndpoint(Client client, String endpoint, String creditsPath, String adminCreditsPath) {
		super();
		this.client = client;
		this.endpoint = endpoint;
		this.creditsPath = creditsPath;
		this.adminCreditsPath = adminCreditsPath;
	}

	public long checkCredits(CreditType creditType) {

		logger.info("Checking Credits from Pricing API for " + creditType);

		Response response = null;
		CustomHttpResponse<CreditsResponse> httpResponse = null;
		try {
			response = client.target(endpoint).path(creditsPath).queryParam("type", creditType)
					.request(MediaType.APPLICATION_JSON).header(JWTConstants.HEADER_STRING, requestParser.getHeader())
					.get();

			logger.info("Response from Pricing enpoint :: " + response.toString());

		} catch (Exception e) {
			throw new CustomException("Internal Server Error", e);
		}

		httpResponse = response.readEntity(new GenericType<CustomHttpResponse<CreditsResponse>>() {
		});

		if (httpResponse.isError() && httpResponse.getCode() == HttpStatus.PAYMENT_REQUIRED.value()) {
			throw new NoCreditException(creditType);
		} else {
			return httpResponse.getData().getCredits();
		}

	}

	public void updateCredits(PricingRequest pricingRequest) {

		logger.info("Updating Credits :: request obj ::" + pricingRequest.toString());

		Response response = null;

		try {
			response = client.target(endpoint).path(creditsPath).request(MediaType.APPLICATION_JSON)
					.header(JWTConstants.HEADER_STRING, requestParser.getHeader())
					.put(Entity.entity(pricingRequest, MediaType.APPLICATION_JSON));

			logger.info("Response from Pricing enpoint :: " + response.toString());

		} catch (Exception e) {
			throw new CustomException("Internal Server Error", e);
		}

		CustomHttpResponse<?> httpResponse = response.readEntity(new GenericType<CustomHttpResponse<?>>() {
		});

		if (httpResponse.isError() && httpResponse.getCode() == HttpStatus.PAYMENT_REQUIRED.value()) {
			throw new NoCreditException(pricingRequest.getCreditType());
		}

	}

	public long asyncCheckCredits(CreditType creditType, String sUuid) {
		logger.info("Checking Credits from Pricing API for " + creditType);

		Response response = null;
		CustomHttpResponse<CreditsResponse> httpResponse = null;
		try {
			response = client.target(endpoint).path(adminCreditsPath).queryParam("type", creditType)
					.queryParam("s", sUuid).queryParam("key", secretKey).request(MediaType.APPLICATION_JSON).get();

			logger.info("Response :: " + response.toString());

		} catch (Exception e) {
			throw new CustomException("Error", e);
		}

		httpResponse = response.readEntity(new GenericType<CustomHttpResponse<CreditsResponse>>() {
		});

		if (httpResponse.isError() && httpResponse.getCode() == HttpStatus.PAYMENT_REQUIRED.value()) {
			throw new NoCreditException(creditType);
		} else {
			return httpResponse.getData().getCredits();
		}
	}

	public void asyncUpdateCredits(PricingRequest pricingRequest) {

		logger.info("Updating Credits :: request obj ::" + pricingRequest.toString());

		Response response = null;

		try {
			response = client.target(endpoint).path(adminCreditsPath).queryParam("key", secretKey)
					.request(MediaType.APPLICATION_JSON).put(Entity.entity(pricingRequest, MediaType.APPLICATION_JSON));

			logger.info("Response :: " + response.toString());

		} catch (Exception e) {
			throw new CustomException("Error", e);
		}

		CustomHttpResponse<?> httpResponse = response.readEntity(new GenericType<CustomHttpResponse<?>>() {
		});

		if (httpResponse.isError() && httpResponse.getCode() == HttpStatus.PAYMENT_REQUIRED.value()) {
			throw new NoCreditException(pricingRequest.getCreditType());
		}

	}
}
