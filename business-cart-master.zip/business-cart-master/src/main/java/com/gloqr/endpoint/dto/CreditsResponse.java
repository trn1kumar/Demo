package com.gloqr.endpoint.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.gloqr.constant.CreditType;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CreditsResponse {

	private long credits;
	String displayName;
	private CreditType creditType;

	public long getCredits() {
		return credits;
	}

	public String getDisplayName() {
		return displayName;
	}

	public CreditType getCreditType() {
		return creditType;
	}

}