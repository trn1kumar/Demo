package com.gloqr.endpoint.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductDto extends CommonField {

	private String productUuid;
	private String productName;
	private String productUrlName;

	public String getProductUuid() {
		return productUuid;
	}

	public String getProductName() {
		return productName;
	}

	public String getProductUrlName() {
		return productUrlName;
	}

}
