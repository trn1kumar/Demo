package com.gloqr.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.gloqr.constant.CartState;
import com.gloqr.constant.ItemType;
import com.gloqr.dto.BICountUpdate;
import com.gloqr.dto.GroupCount;
import com.gloqr.dto.MonthCount;
import com.gloqr.entity.CartItem;
import com.gloqr.http.response.CartSummary;

public interface CartRepo extends JpaRepository<CartItem, Long> {

	boolean existsByUserUuidAndCartStateAndItemDataItemUuidAndItemDataItemType(String userUuid, CartState cartState,
			String itemUuid, ItemType itemType);

	@Query(value = "SELECT i.itemUuid FROM CartItem c JOIN c.itemData i WHERE c.userUuid=:userUuid AND c.cartState=:cartState"
			+ " AND i.itemType=:itemType")
	Set<String> addedCartItems(String userUuid, ItemType itemType, CartState cartState);

	Optional<List<CartItem>> findByUserUuidAndCartState(String userUuid, CartState cartState, Pageable pageable);

	List<CartItem> findBySUuidAndCartState(String sUuid, CartState cartState, Pageable pageable);

	@Query(value = "SELECT c FROM CartItem c WHERE c.sUuid=:sUuid AND (c.cartState=:cartState OR c.cartState=:cartState1)")
	List<CartItem> getRejectedWithAutoClosed(String sUuid, CartState cartState, CartState cartState1,
			Pageable pageable);

	@Query(value = "SELECT new com.gloqr.dto.GroupCount(c.cartState,COUNT(*)) FROM CartItem c WHERE c.userUuid=:userUuid GROUP BY c.cartState")
	List<GroupCount> sentCartCount(String userUuid);

	@Query(value = "SELECT new com.gloqr.dto.GroupCount(c.cartState,COUNT(*),COALESCE(SUM(c.itemData.discountedPrice * c.itemData.quantity),0)) FROM CartItem c WHERE c.sUuid=:sUuid GROUP BY c.cartState")
	List<GroupCount> receivedCartCount(String sUuid);

	@Query(value = "SELECT COALESCE(SUM(c.itemData.discountedPrice * c.itemData.quantity),0) FROM CartItem c WHERE c.sUuid=:sUuid AND c.cartState=:cartState")
	double sumByState(String sUuid, CartState cartState);

	Optional<CartItem> findByUserUuidAndCartUuidAndCartState(String userUuid, String cartUuid, CartState cartState);

	Optional<CartItem> findBySUuidAndCartUuidAndCartState(String sUuid, String cartUuid, CartState cartState);

	@Query("SELECT new com.gloqr.dto.BICountUpdate(c.sUuid AS smeUuid,COUNT(c.sUuid) AS totalCount) FROM CartItem c GROUP BY c.sUuid")
	List<BICountUpdate> countOfSmeIds();

	Optional<List<CartItem>> findByCartStateAndExpirationDate(CartState cartState, Date date);

	@Query("SELECT new com.gloqr.dto.MonthCount(MONTHNAME(c.createdAt),COUNT(*)) "
			+ "FROM CartItem c WHERE c.sUuid=:sUuid AND c.createdAt > :from " + "GROUP BY MONTHNAME(c.createdAt)")
	List<MonthCount> getTotalCountForChart(String sUuid, Date from);

	@Query("SELECT new com.gloqr.dto.MonthCount(MONTHNAME(c.createdAt),COUNT(*)) "
			+ "FROM CartItem c WHERE (c.sUuid=:sUuid AND c.secondStage != null) AND c.createdAt > :from "
			+ "GROUP BY MONTHNAME(c.createdAt)")
	List<MonthCount> getQuotationCountForChart(String sUuid, Date from);

	@Query("SELECT new com.gloqr.dto.MonthCount(MONTHNAME(c.createdAt),COUNT(*)) "
			+ "FROM CartItem c WHERE (c.sUuid=:sUuid AND c.fourthStage != null) AND c.createdAt > :from "
			+ "GROUP BY MONTHNAME(c.createdAt)")
	List<MonthCount> getDeliveredCountForChart(String sUuid, Date from);

	@Query("SELECT new com.gloqr.http.response.CartSummary(COALESCE(SUM(c.itemData.discountedPrice * c.itemData.quantity),0),"
			+ "COUNT(*)) FROM CartItem c WHERE c.sUuid=:sUuid AND c.secondStage != null")
	CartSummary quotationCountAndAmount(String sUuid);
}
