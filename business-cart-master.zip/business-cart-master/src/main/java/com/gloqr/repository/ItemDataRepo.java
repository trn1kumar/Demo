package com.gloqr.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.constant.ItemType;
import com.gloqr.entity.ItemData;

public interface ItemDataRepo extends JpaRepository<ItemData, Long> {

	ItemData findByItemUuidAndSUuidAndItemType(String itemUuid, String sUuid, ItemType itemType);
}
