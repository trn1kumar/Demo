package com.gloqr.schedular;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.gloqr.constant.CartState;
import com.gloqr.dao.CartDao;
import com.gloqr.dto.BICountUpdate;
import com.gloqr.endpoint.SmeEndpoint;
import com.gloqr.entity.CartItem;
import com.gloqr.repository.CartRepo;
import com.gloqr.service.NotificationService;

@Component
public class EventSchedular {
	Logger logger = LogManager.getLogger();

	@Autowired
	private CartRepo cartRepo;

	@Autowired
	private SmeEndpoint smeEndpoint;

	@Autowired
	private CartDao cartDao;

	@Autowired
	private NotificationService notification;

	@Scheduled(cron = "0 0 0 * * ?")
	public void scheduledTaskEveryDay() {
		List<BICountUpdate> biCounts = cartRepo.countOfSmeIds();

		if (!biCounts.isEmpty()) {
			logger.info(biCounts.size() + " Records Found...Started Updating Business Interest Count in SME Module");
			smeEndpoint.updateBiCountInSME(biCounts);
		}

		Optional<List<CartItem>> cartItems = cartRepo.findByCartStateAndExpirationDate(CartState.ACTIVE, new Date());

		if (cartItems.isPresent()) {

			cartItems.get().stream().forEach(c -> {
				c.setCartState(CartState.AUTO_CLOSED);
				cartDao.saveCartItem(c);

				// ASYNC Notification to SME and User
				notification.sendAutoClosedNotification(c);
			});

		} else {
			logger.info("No Cart Items found for Auto Closing BI");
		}

	}
}
