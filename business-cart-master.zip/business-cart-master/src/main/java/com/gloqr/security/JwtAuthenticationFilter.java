package com.gloqr.security;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.stream.Collectors;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import io.jsonwebtoken.Claims;

public class JwtAuthenticationFilter extends OncePerRequestFilter {

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		String header = request.getHeader(JWTConstants.HEADER_STRING);

		if (StringUtils.isNotBlank(header)) {

			String authToken = header.replace(JWTConstants.TOKEN_PREFIX, "");
			Claims claims = jwtTokenUtil.getAllClaimsFromToken(authToken);

			String username = claims.getSubject();
			Collection<? extends GrantedAuthority> authorities = Arrays
					.stream(claims.get(JWTConstants.AUTHORITIES_KEY).toString().split(","))
					.map(SimpleGrantedAuthority::new).collect(Collectors.toList());

			UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(username, "",
					authorities);

			logger.info("authenticated user :: " + username);
			SecurityContextHolder.getContext().setAuthentication(authentication);

		}

		filterChain.doFilter(request, response);

	}

}
