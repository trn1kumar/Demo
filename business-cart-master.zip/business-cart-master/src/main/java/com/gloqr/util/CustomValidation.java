package com.gloqr.util;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.gloqr.dto.PurchaseOrderRequest;
import com.gloqr.dto.QuotationRequest;
import com.gloqr.exception.CustomException;

@Component
public class CustomValidation {

	public void checkQuotationObj(QuotationRequest q) {
		if (StringUtils.isBlank(q.getCartUuid())) {
			throwException("Cart Uuid cannot be null or empty");
		}

		if (StringUtils.isNotBlank(q.getCommentMessage()) && q.getCommentMessage().length() > 500) {
			throwException("Maxmimum 500 characters allowed for message");
		}

		if (q.getQuotationType() == null) {
			throwException("Please select correct quotation type");
		}
	}

	public void checkPurchaseOrderObj(PurchaseOrderRequest p) {
		if (StringUtils.isBlank(p.getCartUuid())) {
			throwException("Cart Uuid cannot be null or empty");
		}

		if (StringUtils.isNotBlank(p.getCommentMessage()) && p.getCommentMessage().length() > 500) {
			throwException("Maxmimum 500 characters allowed for message");
		}
	}

	private void throwException(String message) {
		throw new CustomException(message, HttpStatus.BAD_REQUEST);
	}

}
