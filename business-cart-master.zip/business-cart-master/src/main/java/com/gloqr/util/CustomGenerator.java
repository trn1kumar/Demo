package com.gloqr.util;

import java.text.DateFormatSymbols;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.UUID;

import org.springframework.stereotype.Component;

import com.fasterxml.uuid.Generators;

@Component
public class CustomGenerator {

	public String generateUUID() {
		UUID uuid = Generators.timeBasedGenerator().generate();
		String[] arr = uuid.toString().split("-");
		if (arr[4].isEmpty()) {
			return uuid.toString();
		}
		return arr[4];
	}

	public String generateOrderId() {
		int n = 1000000000 + new Random().nextInt(900000000);
		return "BI" + n;
	}

	public Date getExpirationDate() {
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.DATE, 90);

		return cal.getTime();
	}

	public String[] getLastSixMonths() {
		String[] months = new DateFormatSymbols().getMonths();

		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());

		String[] arr = new String[6];

		for (int i = 5; i >= 0; i--) {
			arr[i] = months[cal.get(Calendar.MONTH)];
			cal.add(Calendar.MONTH, -1);
		}

		return arr;
	}

	public Date getLastSixMonthDate() {
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.MONTH, -6);

		return cal.getTime();
	}

}
