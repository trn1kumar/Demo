package com.gloqr.util;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.exception.CustomException;

@Component
public class FileUtil {

	private final List<String> fileTypes = Arrays.asList("image/png", "image/jpeg", "image/jpg", "application/pdf",
			"application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/txt",
			"application/msword","text/plain");

	public void checkFileFormat(MultipartFile file) {
		if (file != null) {
			if (fileTypes.indexOf(file.getContentType()) == -1) {
				throw new CustomException(
						"Please select correct format for File type. Supported file formats are .png .jpeg .jpg .docx .txt .pdf",
						HttpStatus.BAD_REQUEST);
			}
		} else {
			throw new CustomException("Please select file", HttpStatus.BAD_REQUEST);
		}
	}
}
