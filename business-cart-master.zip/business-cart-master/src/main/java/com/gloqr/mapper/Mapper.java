package com.gloqr.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.gloqr.constant.ItemType;
import com.gloqr.decorator.EmailBody;
import com.gloqr.decorator.QuotationBody;
import com.gloqr.endpoint.dto.CommonField;
import com.gloqr.endpoint.dto.ProductDto;
import com.gloqr.endpoint.dto.SMEInfoDto;
import com.gloqr.endpoint.dto.ServiceDto;
import com.gloqr.endpoint.dto.UserDto;
import com.gloqr.entity.ItemData;
import com.gloqr.exception.CustomException;

@Component
public class Mapper {

	public <T> T convert(Object srcObj, Class<T> targetClass) {
		T entity = null;

		try {
			entity = new ModelMapper().map(srcObj, targetClass);
		} catch (Exception e) {
			throw new CustomException("Error while converting object", HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
		return entity;
	}

	public ItemData productToItemData(ProductDto productDto) {
		ItemData itemData = convert(productDto, ItemData.class);
		itemData.setItemName(productDto.getProductName());
		itemData.setItemType(ItemType.PRODUCT);
		itemData.setItemUrlName(productDto.getProductUrlName());
		itemData.setItemUuid(productDto.getProductUuid());

		return itemData;
	}

	public ItemData serviceToItemData(ServiceDto serviceDto) {
		ItemData itemData = convert(serviceDto, ItemData.class);
		itemData.setItemName(serviceDto.getServiceName());
		itemData.setItemType(ItemType.SERVICE);
		itemData.setItemUrlName(serviceDto.getServiceUrlName());
		itemData.setItemUuid(serviceDto.getServiceUuid());

		return itemData;
	}

	public void mapToQuotationObj(QuotationBody body, CommonField commonField, SMEInfoDto infoDto, UserDto userDto) {
		// setting product/service remaining properties
		body.setTermsAndCondition(commonField.getTermsAndCondition());
		body.setQuotationFormat(commonField.getQuotationFormat());
		body.setGstPercentage(commonField.getGst());

		// setting User properties
		body.setUserFullName(userDto.getUserFullName());
		body.setUserEmail(userDto.getUserEmail());
		body.setUserMobile(userDto.getUserMobile());

		// setting SME properties
		body.setAddress(infoDto.getSmeAddress().toString());
		body.setSmeEmail(infoDto.getContactEmail());
		body.setSmePhone(infoDto.getContactPhone());
		body.setGstin(infoDto.getGstin());

	}

	public void mapToEmailObj(EmailBody body, SMEInfoDto infoDto, UserDto userDto) {
		// setting User properties
		body.setUserFullName(userDto.getUserFullName());
		body.setUserEmail(userDto.getUserEmail());
		body.setUserMobile(userDto.getUserMobile());

		// setting SME properties
		body.setAddress(infoDto.getSmeAddress().toString());
		body.setSmeEmail(infoDto.getContactEmail());
		body.setSmePhone(infoDto.getContactPhone());
	}

}
