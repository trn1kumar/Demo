package com.gloqr.constant;

public enum CartState {
	
	ACTIVE,
	REJECTED,
	COMPLETED,
	AUTO_CLOSED;
}
