package com.gloqr.constant;

public enum ItemType {
	PRODUCT("Product"), SERVICE("Service");

	private final String name;

	private ItemType(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
}
