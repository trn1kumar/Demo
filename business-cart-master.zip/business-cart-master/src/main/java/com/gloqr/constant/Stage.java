package com.gloqr.constant;

public enum Stage {
	
	ORDERED("Ordered"),
	QUOTATION("Quotation"),
	PURCHASE_ORDER("Purchase Order"),
	DELIVERED("Delivered"),
	REJECTED("Rejected");
	
	private final String value;
	
	private Stage(String value){
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}
