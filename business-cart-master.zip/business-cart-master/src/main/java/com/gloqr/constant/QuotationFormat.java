package com.gloqr.constant;

public enum QuotationFormat {

	FORMAT_ONE("Format1"), 
	FORMAT_TWO("Format2"), 
	FORMAT_THREE("Format3");

	private String name;
	
	private QuotationFormat(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
}
