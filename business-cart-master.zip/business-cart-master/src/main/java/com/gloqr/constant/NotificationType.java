package com.gloqr.constant;

public enum NotificationType {

	BI_GENERATION,
	QUOTATION,
	PURCHASE_ORDER,
	CONFIRM_ORDER,
	REJECT_BI,
	REJECT_QUOTATION,
	REJECT_PO,
	AUTO_QUOTATION
	
}
