package com.gloqr.constant;

public enum SchedulerSubGroup {

	BI_FIRST_STAGE, BI_SECOND_STAGE, BI_THIRD_STAGE, BI_FOURTH_STAGE;

}
