package com.gloqr.constant;

public class CartConstant {

	private CartConstant() {
		super();
	}

	// Role Constants
	public static final String ROLE_SME = "hasRole('SME-ADMIN')";
	public static final String ROLE_USER = "hasRole('USER')";
	public static final String ROLE_SME_AND_USER = "hasAnyRole('SME-ADMIN','USER')";
	public static final String ROLE_GLOQR_ADMIN = "hasAnyRole('GLOQR-SUPER-ADMIN')";
	public static final String ROLE_GLOQR_AND_SME = "hasAnyRole('GLOQR-SUPER-ADMIN','SME-ADMIN')";

	public static final String USER = "USER";
	public static final String SME = "SME-ADMIN";

	// Content Server File Path
	public static final String QUOTATION_FILE_LOCATION = "sme/{sUuid}/QuotationFile";
	public static final String PURCHASE_ORDER_FILE_LOCATION = "users/{userUuid}/PurchaseOrder";
}
