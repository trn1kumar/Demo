package com.gloqr.constant;

public class UrlMapping {
	private UrlMapping() {
		super();
	}

	public static final String BASE_URL = "api/cart";

	// Cart Controller
	public static final String ADD_TO_CART = "business-interest";
	public static final String SENT_CART_ITEMS = "sent-items";
	public static final String RECEIVED_CART_ITEMS = "received-items";
	public static final String CART_COUNT = "count";
	public static final String PRODUCT_ADDED_CART_ITEMS = "items/products";
	public static final String SERVICE_ADDED_CART_ITEMS = "items/services";
	public static final String CART_SUMMARY = "summary";
	public static final String BAR_CHART_DATA = "bar-chart";

	// SME Order Stages
	public static final String VIEW_USER_DETAILS = "{cartUuid}/items/user-details";
	public static final String ACCEPT_ORDER = "accept-order";
	public static final String REJECT_ORDER = "reject-order";
	public static final String REJECT_PURCHASE_ORDER = "reject-purchase-order";
	public static final String CONFIRM_ORDER = "{cartUuid}/items/confirm-order";
	public static final String GENERATE_QUOTATION = "{cartUuid}/items/generate-quotation";

	// SME Order Stages
	public static final String ACCEPT_QUOTATION = "accept-quotation";
	public static final String REJECT_QUOTATION = "reject-quotation";
	public static final String REMOVE_CART_ITEM = "{cartUuid}/items";

}
