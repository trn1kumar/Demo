package com.gloqr.constant;

public enum QuotationType {
	AUTO, MANUAL;
}
