package com.gloqr.http.response;

import java.io.Serializable;

public class CartSummary implements Serializable {

	private static final long serialVersionUID = 1L;
	private double totalAmount;
	private double quotationAmount;
	private double deliveredAmount;
	private long totalCount;
	private long quotationCount;
	private long deliveredCount;

	public CartSummary(double quotationAmount, long quotationCount) {
		super();
		this.quotationAmount = quotationAmount;
		this.quotationCount = quotationCount;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public double getQuotationAmount() {
		return quotationAmount;
	}

	public double getDeliveredAmount() {
		return deliveredAmount;
	}

	public long getTotalCount() {
		return totalCount;
	}

	public long getQuotationCount() {
		return quotationCount;
	}

	public long getDeliveredCount() {
		return deliveredCount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public void setQuotationAmount(double quotationAmount) {
		this.quotationAmount = quotationAmount;
	}

	public void setDeliveredAmount(double deliveredAmount) {
		this.deliveredAmount = deliveredAmount;
	}

	public void setTotalCount(long totalCount) {
		this.totalCount = totalCount;
	}

	public void setQuotationCount(long quotationCount) {
		this.quotationCount = quotationCount;
	}

	public void setDeliveredCount(long deliveredCount) {
		this.deliveredCount = deliveredCount;
	}

}
