package com.gloqr.http.response;

import java.io.Serializable;

public class ChartReport implements Serializable {

	private static final long serialVersionUID = 1L;
	private long[] total;
	private long[] quotation;
	private long[] delivered;
	private String[] months;

	public ChartReport(long[] total, long[] quotation, long[] delivered, String[] months) {
		super();
		this.total = total;
		this.quotation = quotation;
		this.delivered = delivered;
		this.months = months;
	}

	public long[] getTotal() {
		return total;
	}

	public long[] getQuotation() {
		return quotation;
	}

	public long[] getDelivered() {
		return delivered;
	}

	public String[] getMonths() {
		return months;
	}

}
