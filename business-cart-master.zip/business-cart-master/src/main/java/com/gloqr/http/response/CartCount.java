package com.gloqr.http.response;

import java.io.Serializable;

public class CartCount implements Serializable {

	private static final long serialVersionUID = 1L;

	private long activeCount;
	private long rejectedCount;
	private long deliveredCount;
	long totalCount;
	private double activeGMV;
	private double rejectedGMV;
	private double deliveredGMV;

	public CartCount(long activeCount, long rejectedCount, long deliveredCount) {
		super();
		this.activeCount = activeCount;
		this.rejectedCount = rejectedCount;
		this.deliveredCount = deliveredCount;
	}

	public CartCount() {
		super();
	}

	public long getActiveCount() {
		return activeCount;
	}

	public void setActiveCount(long activeCount) {
		this.activeCount = activeCount;
	}

	public long getRejectedCount() {
		return rejectedCount;
	}

	public void setRejectedCount(long rejectedCount) {
		this.rejectedCount = rejectedCount;
	}

	public long getDeliveredCount() {
		return deliveredCount;
	}

	public void setDeliveredCount(long deliveredCount) {
		this.deliveredCount = deliveredCount;
	}

	public long getTotalCount() {
		return activeCount + deliveredCount + rejectedCount;
	}

	public void setTotalCount(long totalCount) {
		this.totalCount = totalCount;
	}

	public double getActiveGMV() {
		return activeGMV;
	}

	public void setActiveGMV(double activeGMV) {
		this.activeGMV = activeGMV;
	}

	public double getRejectedGMV() {
		return rejectedGMV;
	}

	public void setRejectedGMV(double rejectedGMV) {
		this.rejectedGMV = rejectedGMV;
	}

	public double getDeliveredGMV() {
		return deliveredGMV;
	}

	public void setDeliveredGMV(double deliveredGMV) {
		this.deliveredGMV = deliveredGMV;
	}

}
