package com.gloqr.constants;

public class UrlMapping {

	private UrlMapping() {
		throw new IllegalStateException("UrlMapping class.can't initiate");
	}

	public static final String ROOT_API = "/api/cdn/";

	public static final String UPLOAD_FILE = "/uploadFile/**";
	public static final String UPLOAD_FILES = "/uploadMultipleFiles/**";
	public static final String FILE_LOCATION = "/file/**";
	public static final String FILE_LOCATIONS = "/files";

}
