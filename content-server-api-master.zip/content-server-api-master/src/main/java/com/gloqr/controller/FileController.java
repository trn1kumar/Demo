package com.gloqr.controller;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.gloqr.constants.UrlMapping;
import com.gloqr.payload.UploadFileResponse;
import com.gloqr.service.FileStorageService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.ROOT_API)
public class FileController {

	private static final Logger logger = LoggerFactory.getLogger(FileController.class);

	@Autowired
	private FileStorageService fileStorageService;

	@PostMapping(UrlMapping.UPLOAD_FILE)
	public UploadFileResponse uploadFile(HttpServletRequest request,
			@RequestParam(value = "files", required = true) MultipartFile file) {

		Path path = null;
		final String reqURI = request.getRequestURI();
		if (reqURI.contains("uploadFile"))
			path = Paths.get(UrlMapping.ROOT_API + "uploadFile/").toAbsolutePath().normalize();
		else
			path = Paths.get(UrlMapping.ROOT_API + "uploadMultipleFiles/").toAbsolutePath().normalize();

		String location = reqURI.replace(path.toString(), "");
		try {
			UploadFileResponse fileDetail = fileStorageService.storeFile(file, location);
			String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath().path("/downloadFile/")
					.path(fileDetail.getFileName()).toUriString();
			fileDetail.setFileType(file.getContentType());
			fileDetail.setSize(file.getSize());
			fileDetail.setFileDownloadUri(fileDownloadUri);
			return fileDetail;
		} catch (Exception e) {
			throw e;
		}

	}

	@PostMapping(UrlMapping.UPLOAD_FILES)
	public List<UploadFileResponse> uploadMultipleFiles(HttpServletRequest request,
			@RequestParam(value = "files", required = true) MultipartFile[] files) {

		return Arrays.asList(files).stream().map(file -> uploadFile(request, file)).collect(Collectors.toList());
	}

	@GetMapping(UrlMapping.FILE_LOCATION)
	public ResponseEntity<Resource> downloadFile(HttpServletRequest request) {
		// Load file as Resource
		Path path = Paths.get(UrlMapping.ROOT_API + "file/").toAbsolutePath().normalize();
		String fileLocation = request.getRequestURI().replace(path.toString(), "");
		Resource resource = fileStorageService.loadFileAsResource(fileLocation);

		// Try to determine file's content type
		String contentType = null;
		try {
			contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
		} catch (IOException ex) {
			logger.info("Could not determine file type.");
		}

		// Fallback to the default content type if type could not be determined
		if (contentType == null) {
			contentType = "application/octet-stream";
		}

		return ResponseEntity.ok().contentType(MediaType.parseMediaType(contentType))
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
				.body(resource);
	}

	@DeleteMapping(UrlMapping.FILE_LOCATION)
	public ResponseEntity<?> deleteFile(HttpServletRequest request) {

		Path path = Paths.get(UrlMapping.ROOT_API + "file/").toAbsolutePath().normalize();
		String fileLocation = request.getRequestURI().replace(path.toString(), "");
		try {
			fileStorageService.deleteFile(fileLocation);

		} catch (Exception e) {
			throw e;
		}
		return new ResponseEntity<>(HttpStatus.OK);

	}

	@DeleteMapping(UrlMapping.FILE_LOCATIONS)
	public ResponseEntity<?> deleteMultipleFile(@RequestParam List<String> fileLocations) {

		for (String fileLocation : fileLocations) {
			try {
				fileStorageService.deleteFile(fileLocation);
			} catch (Exception e) {
				logger.error("Exception In deleteMultipleFile.", e);
			}
		}
		return new ResponseEntity<>(HttpStatus.OK);

	}

}
