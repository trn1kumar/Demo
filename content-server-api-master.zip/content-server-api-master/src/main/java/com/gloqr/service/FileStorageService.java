package com.gloqr.service;

import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.aspectlogger.CentralLoggingHandler;
import com.gloqr.exception.CustomException;
import com.gloqr.exception.FileStorageException;
import com.gloqr.payload.UploadFileResponse;
import com.gloqr.property.FileStorageProperties;

@Service
public class FileStorageService {

	private Logger logger = LogManager.getLogger(CentralLoggingHandler.class);

	private String basePath;

	@Value("${root.folder}")
	private String rootFolder;

	@Autowired
	public FileStorageService(FileStorageProperties fileStorageProperties) {
		basePath = fileStorageProperties.getBasePath();
		logger.info("BasePath " + basePath);

		try {
			Path p = Paths.get(fileStorageProperties.getBasePath()).toAbsolutePath().normalize();
			Files.createDirectories(p);
		} catch (Exception ex) {
			throw new FileStorageException("Could not create the directory where the uploaded files will be stored.",
					ex);
		}
	}

	public UploadFileResponse storeFile(MultipartFile file, String location) {

		UploadFileResponse fileDetail = null;

		// Normalize file name
		String originalFilename = StringUtils.cleanPath(file.getOriginalFilename());

		try {

			// Check if the file's name contains invalid characters if
			if (originalFilename.contains("..")) {
				throw new CustomException("Sorry! Filename contains invalid path sequence " + originalFilename,
						HttpStatus.BAD_REQUEST);
			}

			String fileName = originalFilename.replace(" ", "");

			location = basePath + rootFolder + location;

			Path fileStorageLocation = Paths.get(location).toAbsolutePath().normalize();
			try {

				if (!fileStorageLocation.toFile().exists())
					Files.createDirectories(fileStorageLocation);
			} catch (Exception ex) {
				throw new FileStorageException(
						"Could not create the directory where the uploaded files will be stored.", ex);
			}
			Path targetLocation = fileStorageLocation.resolve(fileName);
			int indexLocation = targetLocation.toAbsolutePath().toString().indexOf("cdn") + 3;

			fileDetail = new UploadFileResponse(
					targetLocation.toAbsolutePath().toString().substring(indexLocation).replace("\\", "/"), fileName);

			try {
				Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

			} catch (Exception e) {
				throw new CustomException("Could not store file " + originalFilename + ". Please try again!",
						HttpStatus.BAD_REQUEST, e);
			}
			return fileDetail;

		} catch (Exception ex) {
			throw ex;
		}
	}

	public Resource loadFileAsResource(String fileLocation) {
		Path filePath = null;
		Resource resource = null;
		String location = basePath + rootFolder + fileLocation;
		filePath = Paths.get(location).toAbsolutePath().normalize();

		try {
			resource = new UrlResource(filePath.toUri());
			if (resource.exists() || resource.isReadable()) {
				return resource;
			} else {
				throw new CustomException("File not found for location " + fileLocation
						+ ". Please try again! Check location path is Valid.", HttpStatus.NOT_FOUND);
			}

		} catch (MalformedURLException ex) {
			throw new CustomException("MalformedURLException while loading file, Message: " + ex.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, ex);
		} catch (Exception ex) {
			throw ex;
		}
	}

	public void deleteFile(String fileLocation) {
		String location = basePath + rootFolder + fileLocation;
		Path path = Paths.get(location).toAbsolutePath().normalize();
		try {
			Files.delete(path);
			logger.info("File Deleted from Location {}", fileLocation);
		} catch (Exception e) {
			throw new CustomException("Exception while deleting file: Cause= " + e.getClass() + " and Message= "
					+ e.getLocalizedMessage() + ". Deletion failed!!!", HttpStatus.BAD_REQUEST, e);
		}

	}

	

}
