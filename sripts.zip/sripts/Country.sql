﻿INSERT INTO SMEfacmasterDataBase.country (country_id,country_code,country_name) VALUES 
(70,'IND','INDIA')
;