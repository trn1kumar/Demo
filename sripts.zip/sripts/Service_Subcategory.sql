﻿INSERT INTO SMEfacmasterDataBase.service_master_sub_catgory (created_at,updated_at,category_image_location,category_active,master_sub_category_display_name,master_sub_category_name,master_sub_category_uuid,services_count,category_id) VALUES 
('2018-11-24 17:49:53.000','2018-11-24 17:49:53.000','smefacePlatform/categoryImages/services/587business-accounting-assignment-help-f.png',1,'Business Accounting','business-accounting','d7cfff99fce0',0,1)
,('2018-11-24 17:51:10.000','2018-11-24 17:51:10.000','smefacePlatform/categoryImages/services/1040e93511ba4aeb44f24c4f58bcd396f69e.jpg',1,'Chartered Accounting','chartered-accounting','27f754cd2ea3',0,1)
,('2018-11-24 17:55:44.000','2018-11-24 17:55:44.000','smefacePlatform/categoryImages/services/2978architectural-design.jpg',1,'Architectural Design','architectural-design','b1c649feba95',0,2)
,('2018-11-24 17:56:02.000','2018-11-24 17:56:02.000','smefacePlatform/categoryImages/services/6046emma-jean-gold-dvd.jpg',1,'Building Design','building-design','b9f4e77e2389',0,2)
,('2018-11-24 18:07:41.000','2018-11-24 18:07:41.000','smefacePlatform/categoryImages/services/7217structural-design-courses-in-chandigarh1.jpg',1,'Structural Design','structural-design','ffa254665be8',0,2)
,('2018-11-24 18:08:55.000','2018-11-25 11:25:28.000','smefacePlatform/categoryImages/services/4970landside_operations_1536_original.jpg',1,'Local Logistics','local-logistics','b54b88cda8ec',1,3)
,('2018-11-24 18:09:25.000','2018-11-24 18:09:25.000','smefacePlatform/categoryImages/services/4448third-party-logistics-featured-image.jpg',1,'Third Party Logistics','third-party-logistics','db3376b42780',0,3)
,('2018-11-24 18:11:06.000','2018-11-24 18:11:06.000','smefacePlatform/categoryImages/services/6015cnc-machine-500x500.jpg',1,'CNC Machines','cnc-machines','954227aa281c',0,4)
,('2018-11-24 18:11:23.000','2018-11-24 18:11:23.000','smefacePlatform/categoryImages/services/9752grinding.jpg',1,'Grinding Machines','grinding-machines','61637160858a',0,4)
,('2018-11-24 18:11:38.000','2018-11-24 18:11:38.000','smefacePlatform/categoryImages/services/7269sheet-rolling-machine-500x500.jpg',1,'Rolling Machines','rolling-machines','a91529b12e12',0,4)
;
INSERT INTO SMEfacmasterDataBase.service_master_sub_catgory (created_at,updated_at,category_image_location,category_active,master_sub_category_display_name,master_sub_category_name,master_sub_category_uuid,services_count,category_id) VALUES 
('2018-11-24 18:11:53.000','2018-11-25 11:25:28.000','smefacePlatform/categoryImages/services/41930_350b69a3.jpg',1,'SPM Machines','spm-machines','afc1b4a5b342',1,4)
,('2018-11-24 18:13:04.000','2018-11-24 18:13:04.000','smefacePlatform/categoryImages/services/4208cnc-metal-cutting-services-250x250.jpg',1,'CNC Metal Cutting','cnc-metal-cutting','27390288737b',0,5)
,('2018-11-24 18:13:27.000','2018-11-24 18:13:27.000','smefacePlatform/categoryImages/services/1374core-cutting-services.jpg',1,'Core Cutting','core-cutting','cdac5a6d2a4c',0,5)
,('2018-11-24 18:13:40.000','2018-11-24 18:13:40.000','smefacePlatform/categoryImages/services/8535close-laser-cutting.jpg',1,'Laser Cutting','laser-cutting','e3dbfcb24924',0,5)
;