﻿INSERT INTO SMEfacmasterDataBase.product_category (category_id,carousel_active,categoryname,creation_date,isactive,last_updated_date,uuid) VALUES 
(11,1,'Machining','2018-11-24 17:54:03.000',1,'2018-11-24 17:54:03.000','046ab67c2f3d4c6ba191f2474276c4d9')
,(64,1,'Safety','2018-11-24 18:24:28.000',1,'2018-11-24 18:24:28.000','2fbf19b956234687ae86ac0b4841f584')
,(351,1,'Power tools','2018-11-25 11:27:46.000',1,'2018-11-25 11:27:46.000','d58f4b4ddfcd4e39b3218690c07b1ef1')
,(446,1,'Electricals','2018-11-25 16:33:26.000',1,'2018-11-25 16:33:26.000','987ae8ad7feb48a3bdb0b2787c3c8ba1')
;