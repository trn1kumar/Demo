﻿INSERT INTO SMEfacmasterDataBase.sub_category (id,carousel_active,is_active,product_count,sub_category,url,uuid,category_id) VALUES 
(50,1,1,1,'Machines & Machine Tool Accessories','machines-machine-tool-accessories','a6e6dbf095864096855f00bb1d56ef16',11)
,(52,1,1,1,'Precision Measuring Tools','precision-measuring-tools','519e6b82d9b74ca7a659c4fa76bf4411',11)
,(68,1,1,1,'Safety Shoes','safety-shoes','98dbfbd6db9d4ce787a4c73b4d736825',64)
,(96,1,1,0,'Safety Goggles','safety-goggles','16b4cb92c3de4f8eaf4a30fff233f748',64)
,(98,1,1,1,'Safety Gloves','safety-gloves','8cb4ae155e144f6e91d33f95d303a89e',64)
,(100,1,1,1,'Safety Helmet','safety-helmet','1d51bd9d2ee248638544514233fbf4d3',64)
,(142,1,1,1,'Fire Protection','fire-protection','ac820f5c02164fd1b473f1ffad153346',64)
,(353,1,1,1,'Saws','saws','bc2155508b5140da9eaffa2ccfd96693',351)
,(452,1,1,0,'Drills','drills','c9874e2081b04a82827b4da49ea06786',351)
,(454,1,1,0,'Blowers','blowers','ecf49d4ed9324e56bf3d96f5640cb3c0',351)
;
INSERT INTO SMEfacmasterDataBase.sub_category (id,carousel_active,is_active,product_count,sub_category,url,uuid,category_id) VALUES 
(456,1,1,0,'Demolition Hammers','demolition-hammers','ccedac65d6274be4abed7398589c9e7e',351)
,(458,1,1,0,'Insulator','insulator','1a248aff77ac4a4a97705f69293da66c',446)
,(462,1,1,0,'Electrical Appliances','electrical-appliances','302c328863024744ac737feccd2df842',446)
,(464,1,1,0,'AMF Pannels','amf-pannels','e98370c356e64dd69348dfd1cb81ca87',446)
;