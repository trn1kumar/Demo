﻿INSERT INTO SMEfacmasterDataBase.sme_category (category_id,category_name,category_url,category_uuid) VALUES 
(13,'Auto Components','auto-components4725','32d517dd13624382afe4ab7ff526eb4d')
,(14,'Automation & Robotics','automation-robotics2085','37122084411e4183b3571a6e6b93b601')
,(15,'Bearings','bearings320','fdeb73bb04414d2d851141de005aa5ce')
,(16,'Castings & Forgings','castings-forgings8008','d43f5921df2846908302bf5ba0d86558')
,(17,'Cutting Tools','cutting-tools4381','48a12f0d2f484f49b984a51b5cd1a2d8')
,(18,'Die & Mould','die-mould267','4e1d43902c904e098cc8b310b5839e45')
,(19,'Electricals & Electronics','electricals-electronics4805','de1000be6b0a4b398c7ba92403527cbd')
,(20,'Factory Interiors','factory-interiors6813','8e6e2cedcfb44318a5777ce2753499e4')
,(21,'Gears & Gear Boxes','gears-gear9621','b01f5ac042ab4ff4bb90cedd52f7b177')
,(22,'Hand Tools','hand-tools4595','55c3c0727078486bb473e29fb544a635')
;
INSERT INTO SMEfacmasterDataBase.sme_category (category_id,category_name,category_url,category_uuid) VALUES 
(23,'Hydraulics & Pneumatics','hydraulics-pneumatics9481','12dd4b8f58cc402da7ae090009f59ddc')
,(24,'Industrial Maintenance Products','industrial-maintenance8777','893d8b33f7314ff394a5e20b74b7aef1')
,(25,'Industrial Safety Equipments','industrial-safety4226','253ac1a9c5d54212b75ef905f009b2a2')
,(26,'Instrumentation & Control','instrumentation-control9161','599153198e464ea888c090f97324b79a')
,(27,'IT Products & Services','it-products6654','979ac9034c154b3cbc232aa0fe0443b5')
,(28,'Infrastructure','infrastructure614','9ecc5e9c48ed42d2b47319a02da071ff')
,(29,'Logistics','logistics2936','21d0405bf7b44e65afeb9f3f3144216e')
,(30,'Machine Tools & Accessories','machine-tools4511','81ab14b84368453088e2adfc15408135')
,(31,'Manufacturing Aids','manufacturing-aids6415','37cb8994cd144f749e19d96dd03d02ad')
,(32,'Material Handling Equipments ','material-handling1016','62c3557df9244f2cadae2e6cbb37f850')
;
INSERT INTO SMEfacmasterDataBase.sme_category (category_id,category_name,category_url,category_uuid) VALUES 
(33,'Metal & Steel','metal-steel1403','90abd3c940994045936140db2657cea8')
,(34,'Packaging Machinery & Equipments','packaging-machinery4947','262bd3019f1542aa9870e30daf9628c1')
,(35,'Pipes Tubes Fittings','pipes-tubes3917','740073963edd4804b8be4f7c11ed196f')
,(36,'Plastics Machinery & Equipments','plastics-machinery9972','95f1b14470754d9a885f8a044a673ee6')
,(37,'Power or Energy Process Automation','power-or9538','f3e05e8161ca4a128316814012b970ff')
,(38,'Process Industries Equipments','process-industries393','df0a1705fc5d40588d1191d1593b2a61')
,(39,'Pumps Valves','pumps-valves8771','987f2bc711b04395819a3091179a4861')
,(40,'Safety & Security','safety-security5977','414d3c578fdc4dc8904457cd75024319')
,(41,'Special Purpose Machine','special-purpose2643','32b86faab66f4eb4ae25ad0e0b358eb1')
,(42,'Testing & Measuring Instruments','testing-measuring746','519bc65af6724ef38a7e4fe609d7b38a')
;
INSERT INTO SMEfacmasterDataBase.sme_category (category_id,category_name,category_url,category_uuid) VALUES 
(43,'Water treatment products','water-treatment6011','6d6c05da9a2d48708de044fd02247b2e')
,(44,'Welding & Safety Equipments','welding-safety7088','f14c1619110a496386c980a291b1b5d6')
,(45,'Wheels & Castors','wheels-castors7826','467e3f4b28d74c65bd6b724e69c8614f')
,(46,'Wires & Cables','wires-cables7104','5175dfc35922481abaa415b7d273ec37')
;