﻿INSERT INTO SMEfacmasterDataBase.state (state_id,formatted_state_name,state_code,state_name,country_id) VALUES 
(71,'Maharashtra,India','IND-MH','Maharashtra',70)
,(72,'Delhi,India','IND-DL','Delhi',70)
,(73,'Gujarat,India','IND-GJ','Gujarat',70)
,(74,'Telangana,India','IND-TG','Telangana',70)
,(75,'Karnataka,India','IND-KA','Karnataka',70)
,(76,'Tamil Nadu,India','IND-TN','Tamil Nadu',70)
;