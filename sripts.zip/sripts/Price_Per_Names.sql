﻿INSERT INTO SMEfacmasterDataBase.master_price_per_details (price_per_name) VALUES 
('Piece')
,('Square Feet')
,('Square Meter')
,('Unit')
,('Pack')
,('Meter')
,('Kilogram')
,('Number')
,('Set')
,('Hour')
;
INSERT INTO SMEfacmasterDataBase.master_price_per_details (price_per_name) VALUES 
('Day')
,('Week')
,('Month')
;