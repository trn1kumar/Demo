﻿INSERT INTO SMEfacmasterDataBase.city (city_id,city_code,city_name,formatted_city_name,state_id) VALUES 
(77,'MH-PU','Pune','Pune, Maharashtra',71)
,(78,'MH-MUM','Mumbai','Mumbai, Maharashtra',71)
,(79,'DL-DEL','Delhi NCR','Delhi NCR, Delhi',72)
,(80,'GJ-AHMD','Ahmedabad','Ahmedabad, Gujarat',73)
,(81,'TG-HYBD','Hyderabad','Hyderabad, Telangana',74)
,(82,'KA-BENG','Bengaluru','Bengaluru, Karnataka',75)
,(83,'TN-CH','Chennai','Chennai, Tamil Nadu',76)
;