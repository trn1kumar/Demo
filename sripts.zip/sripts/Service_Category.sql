﻿INSERT INTO SMEfacmasterDataBase.service_category (created_at,updated_at,category_image_location,category_active,category_display_name,category_url_name,category_uuid) VALUES 
('2018-11-24 17:47:55.000','2018-11-24 17:51:10.000','smefacePlatform/categoryImages/services/5290small-business-accounting-services-1080x675.jpeg',1,'Accounting','accounting','8da6a5c308b4')
,('2018-11-24 17:54:15.000','2018-11-24 18:07:41.000','smefacePlatform/categoryImages/services/4423800px_colourbox1988331.jpg',1,'Architectural','architectural','f5601d50c346')
,('2018-11-24 18:08:01.000','2018-11-24 18:09:25.000','smefacePlatform/categoryImages/services/6137quick-and-reliable-domestic-logistics-services-366.jpg',1,'Logistics','logistics','7f5aaeeb1019')
,('2018-11-24 18:10:22.000','2018-11-24 18:11:53.000','smefacePlatform/categoryImages/services/6115shop.jpg',1,'Machines & Equipment','machines-equipment','79e5ba91544f')
,('2018-11-24 18:12:18.000','2018-11-24 18:13:40.000','smefacePlatform/categoryImages/services/2744abrasive-material-waterjet-cutting-services-big.jpg',1,'Material Cutting','material-cutting','a9c0e0bc0b98')
;