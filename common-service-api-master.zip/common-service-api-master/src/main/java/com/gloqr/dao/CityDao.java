package com.gloqr.dao;

import java.util.List;

import com.gloqr.entity.address.City;

public interface CityDao {

	void saveCities(List<City> cities);

	City getCityByPincode(int pincode);

	City getCity(String cityCode);
		
}
