package com.gloqr.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.entity.address.City;
import com.gloqr.exception.CustomException;
import com.gloqr.repository.CityRepo;

@Repository
public class CityDaoImpl implements CityDao {

	@Autowired
	private CityRepo cityRepo;

	@Override
	public void saveCities(List<City> cities) {
		try {
			cityRepo.saveAll(cities);
		} catch (Exception e) {
			throw new CustomException("Exception while saving Cities. message:- " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

	}

	@Override
	public City getCityByPincode(int pincode) {
		City city = cityRepo.findByPincode(pincode);
		if (city == null)
			throw new CustomException("City Not Found for with pincode " + pincode, HttpStatus.NOT_FOUND);

		return city;
	}

	@Override
	public City getCity(String cityCode) {
		City city = cityRepo.findByCityCode(cityCode);
		if (city == null)
			throw new CustomException("City Not Found for Code " + cityCode, HttpStatus.NOT_FOUND);
		return city;
	}

}
