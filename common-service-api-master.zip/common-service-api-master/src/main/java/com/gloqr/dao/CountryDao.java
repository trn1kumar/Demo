package com.gloqr.dao;

import java.util.List;

import com.gloqr.entity.address.Country;

public interface CountryDao {

	void saveCountries(List<Country> countries);

	List<Country> getCountries();

	Country getCountry(String countryCode);

}
