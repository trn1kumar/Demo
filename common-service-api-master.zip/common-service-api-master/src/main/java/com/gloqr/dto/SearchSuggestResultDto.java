package com.gloqr.dto;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class SearchSuggestResultDto {

	private Map<String, List<String>> suggestedResult;
	private Map<String, Object> searchedResult;

	public Map<String, List<String>> getSuggestedResult() {
		return suggestedResult;
	}

	public void setSuggestedResult(Map<String, List<String>> suggestedResult) {
		this.suggestedResult = suggestedResult;
	}

	public Map<String, Object> getSearchedResult() {
		return searchedResult;
	}

	public void setSearchedResult(Map<String, Object> searchedResult) {
		this.searchedResult = searchedResult;
	}

}
