package com.gloqr.dto.search;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SMEDto {

	private String smeName;
	private String sUuid;
	private String logoImage;
	private AddressDto smeAddress;

	private String status;
	private int mutualConnectionCount;

	public String getSmeName() {
		return smeName;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public String getsUuid() {
		return sUuid;
	}

	public void setsUuid(String sUuid) {
		this.sUuid = sUuid;
	}

	public String getLogoImage() {
		return logoImage;
	}

	public void setLogoImage(String logoImage) {
		this.logoImage = logoImage;
	}

	public AddressDto getSmeAddress() {
		return smeAddress;
	}

	public void setSmeAddress(AddressDto smeAddress) {
		this.smeAddress = smeAddress;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getMutualConnectionCount() {
		return mutualConnectionCount;
	}

	public void setMutualConnectionCount(int mutualConnectionCount) {
		this.mutualConnectionCount = mutualConnectionCount;
	}

}
