package com.gloqr.dto.search;

import java.util.List;
import java.util.Map;

public class SMEFilterAndResultResponse {

	private Map<String, Object> filters = null;
	private List<SMEDto> result = null;
	private int totalSmesCount;

	public Map<String, Object> getFilters() {
		return filters;
	}

	public void setFilters(Map<String, Object> filters) {
		this.filters = filters;
	}

	public List<SMEDto> getResult() {
		return result;
	}

	public void setResult(List<SMEDto> result) {
		this.result = result;
	}

	public int getTotalSmesCount() {
		return totalSmesCount;
	}

	public void setTotalSmesCount(int totalSmesCount) {
		this.totalSmesCount = totalSmesCount;
	}

}
