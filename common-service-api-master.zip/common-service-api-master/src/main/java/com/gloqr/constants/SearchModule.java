package com.gloqr.constants;

public class SearchModule {

	public static final String SME = "smes";
	public static final String SERVICES = "services";
	public static final String PRODUCTS = "products";
	public static final String ALL = "all";
}
