package com.gloqr.constants;

public class SMEFileDirectory {

	public static final String SMEFACE_HOMEPAGE = "smeface-platform/sliders";
	public static final String SMEFACE_LOGO = "smeface-platform/logo";
	
	
}
