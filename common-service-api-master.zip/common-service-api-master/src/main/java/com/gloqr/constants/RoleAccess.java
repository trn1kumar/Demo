package com.gloqr.constants;

public interface RoleAccess {
	String ADMIN = "hasAnyRole('SME-ADMIN','ADMIN')";
	String USER = "hasAnyRole('USER')";
	String ADMIN_AND_USER = "hasAnyRole('USER','SME-ADMIN', 'ADMIN')";

	String USER_ROLE = "USER";
	String SMEFACE_DBA = "SMEFACE-DBA";
	String SMEFACE_SUPER_ADMIN = "SMEFACE-SUPER-ADMIN";
	String SMEFACE_ADMIN = "SMEFACE-ADMIN";
	String SME_SUPER_ADMIN = "SME-SUPER-ADMIN";
	String SME_ADMIN = "SME-ADMIN";
}
