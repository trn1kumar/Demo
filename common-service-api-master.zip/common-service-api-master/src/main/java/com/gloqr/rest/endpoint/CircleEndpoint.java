package com.gloqr.rest.endpoint;

import javax.ws.rs.client.Client;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;

import com.gloqr.dto.search.SMEFilterAndResultResponse;
import com.gloqr.exception.CustomException;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.security.configuration.JwtConstants;

public class CircleEndpoint {

	private Client client;
	private String endPointUri;
	private String searchSmes;

	private static final Logger log = LogManager.getLogger();

	public CircleEndpoint(Client client, String endPointUri, String searchSmes) {
		super();
		this.client = client;
		this.endPointUri = endPointUri;
		this.searchSmes = searchSmes;
	}

	public SMEFilterAndResultResponse getSearchedSmes(String searchText, String jwtTokenString) {
		Response response = null;
		CustomHttpResponse<SMEFilterAndResultResponse> customResponse = null;
		log.info("Getting Searched Smes Results.");
		log.info("Connecting to CIRCLE Module...  {method=GET, uri: {}{} ,params=searchText:{} }", endPointUri,
				searchSmes, searchText);

		try {
			response = client.target(endPointUri).path(searchSmes).queryParam("searchText", searchText)
					.queryParam("page", -1).request(MediaType.APPLICATION_JSON)
					.header(JwtConstants.HEADER_STRING, jwtTokenString).get();

		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);
		Integer statusCode = response.getStatus();

		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}
		try {
			customResponse = response.readEntity(new GenericType<CustomHttpResponse<SMEFilterAndResultResponse>>() {
			});
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}
		if (customResponse.isError()) {
			throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
		}
		return customResponse.getData();

	}

	private void throwEntityResponseReadException(Exception e) {
		throw new CustomException("Exception at read response from Circle Module. Message: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private void throwInvalidResponseException(int statusCode) {
		throw new CustomException("Invalid Response from Circle Module: ", HttpStatus.resolve(statusCode));
	}

	private void throwConnectionRefusedException(Exception e) {
		throw new CustomException("Couldn't Connect to Circle Module, Exception: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private void logResponse(Response response) {
		log.info("Response From SME Module : " + response);
	}

}
