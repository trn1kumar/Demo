package com.gloqr.rest.endpoint;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;

import com.gloqr.dto.search.SMEFilterAndResultResponse;
import com.gloqr.exception.CustomException;
import com.gloqr.model.http.response.CustomHttpResponse;

public class SmeEndPoint {

	private Client client;
	private String endPointUri;
	private String suggestSmes;
	private String searchSmes;

	private static final Logger log = LogManager.getLogger();

	public SmeEndPoint(Client client, String endPointUri, String suggestSmes, String searchSmes) {
		super();
		this.client = client;
		this.endPointUri = endPointUri;
		this.suggestSmes = suggestSmes;
		this.searchSmes = searchSmes;
	}

	public SMEFilterAndResultResponse getSearchedSmes(String searchText) {
		Response response = null;
		CustomHttpResponse<SMEFilterAndResultResponse> customResponse = null;
		log.info("Getting Searched Smes Results.");
		log.info("Connecting to SME Module...  {method=GET, uri: {}{} ,params=searchText:{} }", endPointUri, searchSmes,
				searchText);

		try {
			response = client.target(endPointUri).path(searchSmes).queryParam("searchText", searchText)
					.queryParam("page", -1).request(MediaType.APPLICATION_JSON).get();

		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);
		Integer statusCode = response.getStatus();

		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}
		try {
			customResponse = response.readEntity(new GenericType<CustomHttpResponse<SMEFilterAndResultResponse>>() {
			});
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}
		if (customResponse.isError()) {
			throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
		}
		return customResponse.getData();

	}

	public List<String> getSuggestedSmes(String searchText) {

		Response response = null;
		CustomHttpResponse<List<String>> customResponse = null;
		log.info("Getting TOP SME details.");
		log.info("Connecting to SME Module...  {method=GET, uri: {}{} ,params=searchText:{} }", endPointUri,
				suggestSmes, searchText);

		try {

			response = client.target(endPointUri).path(suggestSmes).queryParam("searchText", searchText)
					.queryParam("maxResult", 5).request(MediaType.APPLICATION_JSON).get();
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);
		Integer statusCode = response.getStatus();

		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}
		try {
			customResponse = response.readEntity(new GenericType<CustomHttpResponse<List<String>>>() {
			});
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}
		if (customResponse.isError()) {
			throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
		}
		return customResponse.getData();

	}

	private void throwEntityResponseReadException(Exception e) {
		throw new CustomException("Exception at read response from SME Module. Message: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private void throwInvalidResponseException(int statusCode) {
		throw new CustomException("Invalid Response from SME Module: ", HttpStatus.resolve(statusCode));
	}

	private void throwConnectionRefusedException(Exception e) {
		throw new CustomException("Couldn't Connect to SME Module, Exception: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private void logResponse(Response response) {
		log.info("Response From SME Module : " + response);
	}

}
