package com.gloqr.rest.endpoint;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;

import com.gloqr.exception.CustomException;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.security.configuration.JwtConstants;

public class ServiceEndPoint {

	private Client client;
	private String endPointUri;
	private String searchServices;
	private String suggestServices;

	public static final String COUNT_PARAM = "smeIds";

	Logger log = LogManager.getLogger(ServiceEndPoint.class.getName());

	public ServiceEndPoint(Client client, String endPointUri, String searchServices, String suggestServices) {
		super();
		this.client = client;
		this.endPointUri = endPointUri;
		this.searchServices = searchServices;
		this.suggestServices = suggestServices;

	}

	public Object getSearchedServices(String searchText, String jwtToken) {
		CustomHttpResponse<Object> customResponse = null;
		Response response = null;

		log.info("Getting Services ");
		log.info("Connecting to Services Module...  {method=GET ,uri= {}{} ,params= searchSuggest:{} }", endPointUri,
				searchServices, searchText);
		try {
			response = client.target(endPointUri).path(searchServices).queryParam("searchText", searchText)
					.queryParam("page", -1).request(MediaType.APPLICATION_JSON)
					.header(JwtConstants.HEADER_STRING, jwtToken).get();
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);

		Integer statusCode = response.getStatus();

		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}

		try {
			customResponse = response.readEntity(new GenericType<CustomHttpResponse<Object>>() {
			});
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}

		if (customResponse.isError()) {
			throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
		}
		return customResponse.getData();

	}

	public List<String> getSuggestedSerivces(String searchText) {

		CustomHttpResponse<List<String>> customResponse = null;
		Response response = null;

		log.info("Getting Services ");
		log.info("Connecting to Services Module...  {method=GET ,uri= {}{} ,params= searchSuggest:{} }", endPointUri,
				suggestServices, searchText);
		try {
			response = client.target(endPointUri).path(suggestServices).queryParam("searchText", searchText)
					.queryParam("maxResult", 5).request(MediaType.APPLICATION_JSON).get();
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);

		Integer statusCode = response.getStatus();

		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}

		try {
			customResponse = response.readEntity(new GenericType<CustomHttpResponse<List<String>>>() {
			});
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}

		if (customResponse.isError()) {
			throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
		}
		return customResponse.getData();

	}

	private void throwEntityResponseReadException(Exception e) {
		throw new CustomException("Exception at read response from Service Module. Message: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	private void throwInvalidResponseException(int statusCode) {
		throw new CustomException("Invalid Response from Service Module: ", HttpStatus.resolve(statusCode));
	}

	private void throwConnectionRefusedException(Exception e) {
		throw new CustomException("Couldn't Connect to Service module, Exception: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	private void logResponse(Response response) {
		log.info("Response From Service Module API: " + response);
	}

}
