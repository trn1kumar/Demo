package com.gloqr.rest.endpoint;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.gloqr.notification.EmailEvent;
import com.gloqr.notification.SmsEvent;

public class NotificationEndPoint {

	Logger log = LogManager.getLogger();

	private Client client;
	private String endpoint;
	private String emailPath;
	private String smsPath;

	public NotificationEndPoint(Client client, String notificationEndPoint, String emailEndPointPath, String smsPath) {
		this.client = client;
		this.endpoint = notificationEndPoint;
		this.emailPath = emailEndPointPath;
		this.smsPath = smsPath;
	}

	public void sendSMS(SmsEvent smsEvent) {
		log.info("Sending SMS to Mobile Number :: " + smsEvent.getMobileNo());
		try {
			Response response = client.target(endpoint).path(smsPath).request(MediaType.APPLICATION_JSON)
					.post(Entity.entity(smsEvent, MediaType.APPLICATION_JSON));

			log.info("SMS Sent Response :: " + response.toString());
		} catch (Exception e) {
			log.error("Error while sending SMS :: " + e.toString());
		}
	}

	public void sendEmail(EmailEvent emailEvent) {
		log.info("Sending Email to Id :: " + emailEvent.getEmailId());
		try {
			Response response = client.target(endpoint).path(emailPath).request(MediaType.APPLICATION_JSON)
					.post(Entity.entity(emailEvent, MediaType.APPLICATION_JSON));

			log.info("Email Sent Response :: " + response.toString());
		} catch (Exception e) {
			log.error("Error while sending Email :: " + e.toString());
		}
	}

}
