package com.gloqr.rest.endpoint;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;

import com.gloqr.exception.CustomException;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.security.configuration.JwtConstants;

public class ProductEndPoint {

	private Client client;
	private String endPointUri;
	private String searchProducts;
	private String suggestProducts;

	public static final String COUNT_PARAM = "smeIds";

	private static final Logger log = LogManager.getLogger();

	public ProductEndPoint(Client client, String endPointUri, String searchProducts, String suggestProducts) {
		super();
		this.client = client;
		this.endPointUri = endPointUri;
		this.searchProducts = searchProducts;
		this.suggestProducts = suggestProducts;
	}

	public Object getSearchedProducts(String searchText, String jwtToken) {

		CustomHttpResponse<Object> customResponse = null;
		Response response = null;

		log.info("Getting Products...");
		log.info("Connecting to Product Module...  {method=GET ,uri= {}{} ,params= searchText:{} }", endPointUri,
				searchProducts, searchText);

		try {
			response = client.target(endPointUri).path(searchProducts).queryParam("searchText", searchText)
					.queryParam("page", -1).request(MediaType.APPLICATION_JSON)
					.header(JwtConstants.HEADER_STRING, jwtToken).get();
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);

		Integer statusCode = response.getStatus();

		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}
		try {
			customResponse = response.readEntity(new GenericType<CustomHttpResponse<Object>>() {
			});
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}

		if (customResponse.isError()) {
			throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
		}
		return customResponse.getData();
	}

	public List<String> getSuggestedProducts(String searchText) {

		CustomHttpResponse<List<String>> customResponse = null;
		Response response = null;

		log.info("Getting Products...");
		log.info("Connecting to Product Module...  {method=GET ,uri= {}{} ,params= searchText:{} }", endPointUri,
				suggestProducts, searchText);

		try {
			response = client.target(endPointUri).path(suggestProducts).queryParam("searchText", searchText)
					.queryParam("maxResult", 5).request(MediaType.APPLICATION_JSON).get();
		} catch (Exception e) {
			throwConnectionRefusedException(e);
		}

		logResponse(response);

		Integer statusCode = response.getStatus();

		if (statusCode != HttpStatus.OK.value()) {
			throwInvalidResponseException(statusCode);
		}
		try {
			customResponse = response.readEntity(new GenericType<CustomHttpResponse<List<String>>>() {
			});
		} catch (Exception e) {
			throwEntityResponseReadException(e);
		}

		if (customResponse.isError()) {
			throw new CustomException(customResponse.getMessage(), customResponse.getStatus());
		}
		return customResponse.getData();

	}

	private void throwEntityResponseReadException(Exception e) {
		throw new CustomException("Exception at read response from Product Module. Message: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	private void throwInvalidResponseException(int statusCode) {
		throw new CustomException("Invalid Response from Product Module: ", HttpStatus.resolve(statusCode));
	}

	private void throwConnectionRefusedException(Exception e) {
		throw new CustomException("Couldn't Connect to Product module, Exception: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	private void logResponse(Response response) {
		log.info("Response From Product Module API: " + response);
	}

}
