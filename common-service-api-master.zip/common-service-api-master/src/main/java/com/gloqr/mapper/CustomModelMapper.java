package com.gloqr.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.gloqr.exception.CustomException;

import io.jsonwebtoken.lang.Assert;

@Component
public class CustomModelMapper {

	public <T> T convert(Object srcObj, Class<T> targetClass) {
		T targetObj = null;

		try {
			Assert.notNull(srcObj, "source object can not be null for convertion");
			targetObj = new ModelMapper().map(srcObj, targetClass);
		} catch (Exception e) {
			throw new CustomException("Exception in CustomModelMapper.  Message:- " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
		return targetObj;
	}

}
