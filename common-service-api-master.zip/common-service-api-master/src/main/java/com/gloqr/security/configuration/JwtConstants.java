package com.gloqr.security.configuration;

public class JwtConstants {

	private JwtConstants() {
		throw new IllegalStateException("JWT Constants class.can't initiate");
	}

	public static final String TOKEN_PREFIX = "Bearer";
	public static final String HEADER_STRING = "Authorization";

	public static final String USER_ID = "uuid";
	public static final String SME_ID = "smeid";
	public static final String FIRST_NAME = "name";
	public static final String USER_TYPE = "usertype";
	public static final String SIGNING_KEY = "GL_18_OQ_1219_R";
	public static final String AUTHORITIES_KEY = "role";
	public static final String PROFILE_IMAGE = "profileImage";

}
