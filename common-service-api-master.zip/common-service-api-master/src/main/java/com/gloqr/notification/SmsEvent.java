package com.gloqr.notification;

public class SmsEvent {
	private String mobileNo;
	private String eventMessage;
	private String sender;

	public SmsEvent() {
	}

	public SmsEvent(String mobileNum, String eventMessage) {
		this.mobileNo = mobileNum;
		this.eventMessage = eventMessage;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEventMessage() {
		return eventMessage;
	}

	public void setEventMessage(String eventMessage) {
		this.eventMessage = eventMessage;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

}
