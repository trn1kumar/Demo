package com.gloqr.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gloqr.entity.address.City;

public interface CityRepo extends JpaRepository<City, Long> {

	City findByCityCode(String cityCode);

	@Query("select city from City city JOIN city.pincodes p where p.pincode=:pincode")
	City findByPincode(@Param("pincode") int pincode);

}
