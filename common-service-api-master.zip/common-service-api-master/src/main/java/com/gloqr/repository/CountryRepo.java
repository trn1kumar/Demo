package com.gloqr.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.entity.address.Country;


public interface CountryRepo extends JpaRepository<Country, Long>{

	Country findByCountryCode(String countryCode);


}
