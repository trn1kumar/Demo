package com.gloqr.service;

import com.gloqr.entity.ContactUs;

public interface ContactUsService {

	void newContact(ContactUs contactUs);

}
