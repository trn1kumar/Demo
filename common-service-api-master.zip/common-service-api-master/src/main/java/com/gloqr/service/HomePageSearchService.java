package com.gloqr.service;

import com.gloqr.dto.SearchSuggestResultDto;

public interface HomePageSearchService {
	public SearchSuggestResultDto getSuggestions(String searchText);

	public SearchSuggestResultDto getSearchResults(String searchText);

}
