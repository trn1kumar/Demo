package com.gloqr.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.dao.CityDao;
import com.gloqr.dao.CountryDao;
import com.gloqr.dao.StateDao;
import com.gloqr.entity.address.City;
import com.gloqr.entity.address.Country;
import com.gloqr.entity.address.State;
import com.gloqr.exception.CustomException;

@Service
public class AddressServiceImpl implements AddressService {

	@Autowired
	private CityDao cityDao;

	@Autowired
	private StateDao stateDao;

	@Autowired
	private CountryDao countryDao;

	@Override
	public void saveCities(List<City> cities) {
		cities.forEach(city -> {
			State state = this.getState(city.getState().getStateCode());
			city.setState(state);
		});
		cityDao.saveCities(cities);

	}

	@Override
	public void saveStates(List<State> states) {
		states.forEach(state -> {
			Country country = this.getCountry(state.getCountry().getCountryCode());
			state.setCountry(country);
		});
		stateDao.saveStates(states);

	}

	@Override
	public void saveCountries(List<Country> countries) {
		countryDao.saveCountries(countries);

	}

	@Override
	public List<City> getCitiesByState(String stateCode) {
		State state = getState(stateCode);
		List<City> cities = state.getCities();
		if (cities != null && !cities.isEmpty()) {
			cities.forEach(city -> {
				city.setState(null);
				city.setPincodes(null);
			});
			return cities;
		} else {
			throw new CustomException("Cities Not Available", HttpStatus.NOT_FOUND);
		}

	}

	public List<State> getStatesByCountry(String countryCode) {
		Country country = getCountry(countryCode);
		List<State> states = country.getStates();
		if (states != null && !states.isEmpty()) {
			states.forEach(state -> {
				state.setCountry(null);
				state.setCities(null);
			});
			return states;
		} else {
			throw new CustomException("States Not Available", HttpStatus.NOT_FOUND);
		}

	}

	@Override
	public List<State> getStatesWithCities() {
		List<State> states = stateDao.getStatesWithCities();
		states = filterEmptyCitiesStates(states);
		states.forEach(state -> {
			state.setCountry(null);
			state.getCities().forEach(city -> {
				city.setState(null);
				city.setPincodes(null);
			});
		});

		return states;

	}

	private List<State> filterEmptyCitiesStates(List<State> states) {
		states = states.stream().filter(state -> state.getCities() != null && !state.getCities().isEmpty())
				.collect(Collectors.toList());
		return states;
	}

	public List<Country> getCountries() {
		List<Country> countries = countryDao.getCountries();
		countries.forEach(country -> country.setStates(null));
		return countries;

	}

	@Override
	public City getCityByPincode(int pincode) {
		return cityDao.getCityByPincode(pincode);
	}

	public City getCity(String cityCode) {
		return cityDao.getCity(cityCode);
	}

	public Country getCountry(String countryCode) {
		return countryDao.getCountry(countryCode);
	}

	public State getState(String stateCode) {
		return stateDao.getState(stateCode);
	}

}
