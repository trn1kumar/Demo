package com.gloqr.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.constants.SearchModule;
import com.gloqr.dto.SearchSuggestResultDto;
import com.gloqr.rest.endpoint.CircleEndpoint;
import com.gloqr.rest.endpoint.ProductEndPoint;
import com.gloqr.rest.endpoint.ServiceEndPoint;
import com.gloqr.rest.endpoint.SmeEndPoint;
import com.gloqr.security.context.holder.AuthenticationFacade;

@Service
public class HomePageSearchServiceImpl implements HomePageSearchService {

	@Autowired
	private SmeEndPoint smeEndPoint;

	@Autowired
	private CircleEndpoint circleEndPoint;

	@Autowired
	private ProductEndPoint productEndPoint;

	@Autowired
	private AuthenticationFacade authenticationFacade;

	@Autowired
	private ServiceEndPoint serviceEndPoint;

	@Override
	public SearchSuggestResultDto getSuggestions(String searchText) {

		SearchSuggestResultDto searchResult = new SearchSuggestResultDto();
		Map<String, List<String>> result = new HashMap<>();
		ExecutorService executor = Executors.newFixedThreadPool(3);

		Runnable servicesSuggetionSearchThread = new Thread(
				() -> result.put(SearchModule.SERVICES, serviceEndPoint.getSuggestedSerivces(searchText)),
				"servicesSuggetionSearchThread");

		Runnable productsSuggetionSearchThread = new Thread(
				() -> result.put(SearchModule.PRODUCTS, productEndPoint.getSuggestedProducts(searchText)),
				"productsSuggetionSearchThread");

		Runnable smesSuggetionSearchThread = new Thread(
				() -> result.put(SearchModule.SME, smeEndPoint.getSuggestedSmes(searchText)),
				"smesSuggetionSearchThread");

		executor.execute(servicesSuggetionSearchThread);
		executor.execute(productsSuggetionSearchThread);
		executor.execute(smesSuggetionSearchThread);

		executor.shutdown();

		while (!executor.isTerminated()) {

		}

		searchResult.setSuggestedResult(result);
		return searchResult;

	}

	@Override
	public SearchSuggestResultDto getSearchResults(String searchText) {
		SearchSuggestResultDto searchResult = new SearchSuggestResultDto();
		Map<String, Object> searchedResult = new HashMap<>();

		String jwtToken = authenticationFacade.getJwtToken();

		ExecutorService executor = Executors.newFixedThreadPool(3);

		Runnable servicesSearchResultThread = new Thread(() -> searchedResult.put(SearchModule.SERVICES,
				serviceEndPoint.getSearchedServices(searchText, jwtToken)), "servicesSearchResultThread");

		Runnable productsSearchResultThread = new Thread(() -> searchedResult.put(SearchModule.PRODUCTS,
				productEndPoint.getSearchedProducts(searchText, jwtToken)), "productsSearchResultThread");

		Runnable smesFromSmeModule = new Thread(
				() -> searchedResult.put(SearchModule.SME, smeEndPoint.getSearchedSmes(searchText).getResult()),
				"smesSearchResultThread");

		Runnable smesFromCircleModule = new Thread(
				() -> searchedResult.put(SearchModule.SME, circleEndPoint.getSearchedSmes(searchText, jwtToken).getResult()),
				"smesSearchResultThread1");

		executor.execute(servicesSearchResultThread);
		executor.execute(productsSearchResultThread);
		if (jwtToken != null)
			executor.execute(smesFromCircleModule);
		else
			executor.execute(smesFromSmeModule);

		executor.shutdown();

		while (!executor.isTerminated()) {

		}

		searchResult.setSearchedResult(searchedResult);

		return searchResult;
	}
}
