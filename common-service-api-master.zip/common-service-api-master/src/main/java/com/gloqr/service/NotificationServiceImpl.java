package com.gloqr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.gloqr.entity.ContactUs;
import com.gloqr.notification.EmailEvent;
import com.gloqr.notification.SmsEvent;
import com.gloqr.rest.endpoint.NotificationEndPoint;

@Service
public class NotificationServiceImpl implements NotificationService {

	@Autowired
	private NotificationEndPoint notification;

	@Value("${email.subject}")
	private String emailSubject;

	@Value("${email.message}")
	private String emailMessage;

	@Value("${pune.gloqr.email}")
	private String gloqrEmail;

	@Value("${gloqr.email.subject}")
	private String gloqrEmailSubject;

	@Value("${gloqr.email.message}")
	private String gloqrEmailMessage;

	private String userName = "{userName}";

	@Override
	@Async
	public void sendEmailAndSMS(ContactUs contactUs) {

		String messageBody = emailMessage.replace(userName, contactUs.getName());

		if (contactUs.getEmail() != null) {
			notification.sendEmail(new EmailEvent(contactUs.getEmail(), emailSubject, messageBody));
		}
		notification.sendSMS(new SmsEvent(String.valueOf(contactUs.getMobile()), messageBody.replace("<br>", "")));
	}

	@Override
	@Async
	public void sendEmailToGloqr(ContactUs contactUs) {
		String msg = gloqrEmailMessage.replace(userName, contactUs.getName())
				.replace("{mobileNumber}", String.valueOf(contactUs.getMobile()))
				.replace("{msg}", contactUs.getMessage());

		if (contactUs.getEmail() != null) {
			msg = msg.replace("{emailId}", contactUs.getEmail());
		} else {
			msg = msg.replace("{emailId}", "N/A");
		}

		notification
				.sendEmail(new EmailEvent(gloqrEmail, gloqrEmailSubject.replace(userName, contactUs.getName()), msg));
	}
}
