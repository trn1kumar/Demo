package com.gloqr.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.entity.Image;
import com.gloqr.entity.UploadFileResponse;
import com.gloqr.exception.CustomException;
import com.gloqr.repository.ImageRepository;
import com.gloqr.rest.endpoint.ContentServerEndpoint;
import com.gloqr.util.RandomNumber;

@Service
public class ContentServerServiceImpl implements ContentServerService {

	@Autowired
	private ContentServerEndpoint contentServerEndpoint;

	@Autowired
	private ImageRepository imageRepository;

	@Override
	public List<Image> sendFilesToContentServer(List<MultipartFile> files, String fileContentDirName)
			throws IllegalArgumentException, IOException {

		List<String> names = new ArrayList<>();
		List<Image> images = new ArrayList<>();
		Image image = null;

		files.forEach(file -> {
			try {
				RandomNumber number = new RandomNumber();
				String imageName = number.numberGenerator() + file.getOriginalFilename();
				names.add(imageName);
				images.add(new Image(imageName, true));

			} catch (CustomException e) {
				e.printStackTrace();
			}
		});

		List<UploadFileResponse> fileDetails = contentServerEndpoint.sendFilesToContentServer(files, names,
				fileContentDirName);
		int i = 0;
		for (UploadFileResponse fileDetail : fileDetails) {
			image = images.get(i++);
			image.setImageLocation(fileDetail.getFileLocation());
		}

		return images;

	}

	@Override
	public Image sendFileToContentServer(MultipartFile file, String fileContentDirName)
			throws IllegalArgumentException, IOException {
		String names = null;

		Image image = null;

		try {
			RandomNumber number = new RandomNumber();
			String imageName = /* fileContentDirName */ number.numberGenerator() + file.getOriginalFilename();
			names = imageName;
			image = new Image(imageName, true);

		} catch (CustomException e) {
			e.printStackTrace();
		}

		UploadFileResponse fileDetails = contentServerEndpoint.sendFileToContentServer(file, names, fileContentDirName);

		image.setImageLocation(fileDetails.getFileLocation());

		return image;
	}

	@Override
	public void saveImage(Image image) {
		try {
			if (image != null) {
				imageRepository.save(image);
			} else {
				throw new CustomException("Image file not present", HttpStatus.NO_CONTENT);
			}

		} catch (CustomException e) {
			throw e;
		}
	}

	@Override
	public HashMap<String, List<Image>> getImageFileLocation() {
		try {
			List<Image> images = imageRepository.findByProvider("SMEFACE-SLIDER");
			HashMap<String, List<Image>> imageLocation = new HashMap<>();
			imageLocation.put("fileLocation", images);

			return imageLocation;

		} catch (CustomException e) {
			throw e;
		}

	}

	@Override
	public Image getSmefaceLogo() {
		try {
			List<Image> images = imageRepository.findByProvider("SMEFACE-LOGO");
			Image image = images.stream().findAny().get();
			return image;
		} catch (CustomException e) {
			throw e;
		}
	}
}
