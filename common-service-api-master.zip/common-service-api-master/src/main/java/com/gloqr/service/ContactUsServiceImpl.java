package com.gloqr.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.entity.ContactUs;
import com.gloqr.exception.CustomException;
import com.gloqr.repository.ContactUsRepo;

@Service
public class ContactUsServiceImpl implements ContactUsService {

	@Autowired
	private ContactUsRepo contactRepo;

	@Override
	public void newContact(ContactUs contactUs) {
		try {
			contactUs.setCreatedAt(new Date());
			contactRepo.save(contactUs);
		} catch (Exception e) {
			throw new CustomException("Error while saving contact-us details", HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
	}

}
