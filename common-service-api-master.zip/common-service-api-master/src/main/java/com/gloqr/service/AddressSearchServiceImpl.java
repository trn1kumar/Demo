package com.gloqr.service;

import java.util.List;
import javax.persistence.EntityManager;

import org.apache.lucene.search.Query;
import org.hibernate.search.exception.EmptyQueryException;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.entity.address.City;

@Service
public class AddressSearchServiceImpl implements AddressSearchService {

	@Autowired
	private EntityManager entityManager;

	@Override
	public List<City> getSearchResult(String city, Integer pincode) {
		List<City> cities = null;
		if (city != null)
			cities = this.searchByCity(city);
		if (pincode != null && pincode>0) {
			cities = this.searchByPincode(pincode);
		}
		return cities;

	}

	@SuppressWarnings("unchecked")
	private List<City> searchByPincode(Integer pincode) {
		List<City> cities = null;
		try {
			FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

			QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
					.forEntity(City.class).get();

			Query luceneQuery = queryBuilder.bool()
					.must(queryBuilder.keyword().onField("pincodes.pincode").matching(pincode).createQuery())
					.must(queryBuilder.keyword().onField("active").matching(true).createQuery()).createQuery();

			FullTextQuery query = fullTextEntityManager.createFullTextQuery(luceneQuery, City.class);

			cities = query.getResultList();

		} catch (EmptyQueryException e) {
			e.printStackTrace();
		}

		return cities;

	}

	@SuppressWarnings("unchecked")
	private List<City> searchByCity(String city) {

		List<City> cities = null;
		try {
			FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

			QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
					.forEntity(City.class).get();

			Query luceneQuery = queryBuilder.bool()
					.must(queryBuilder.keyword().onField("cityName").matching(city).createQuery())
					.must(queryBuilder.keyword().onField("active").matching(true).createQuery()).createQuery();
			FullTextQuery query = fullTextEntityManager.createFullTextQuery(luceneQuery, City.class);

			cities = query.getResultList();

		} catch (EmptyQueryException e) {
			e.printStackTrace();
		}

		return cities;
	}
}
