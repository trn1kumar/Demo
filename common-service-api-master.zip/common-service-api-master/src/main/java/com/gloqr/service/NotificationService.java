package com.gloqr.service;

import com.gloqr.entity.ContactUs;

public interface NotificationService {

	void sendEmailAndSMS(ContactUs contactUs);

	void sendEmailToGloqr(ContactUs contactUs);

}
