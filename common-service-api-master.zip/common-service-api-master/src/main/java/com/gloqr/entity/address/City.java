package com.gloqr.entity.address;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.lucene.analysis.core.LowerCaseFilterFactory;
import org.apache.lucene.analysis.ngram.EdgeNGramFilterFactory;
import org.apache.lucene.analysis.snowball.SnowballPorterFilterFactory;
import org.apache.lucene.analysis.standard.StandardTokenizerFactory;
import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Analyzer;
import org.hibernate.search.annotations.AnalyzerDef;
import org.hibernate.search.annotations.AnalyzerDefs;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;
import org.hibernate.search.annotations.Parameter;
import org.hibernate.search.annotations.Store;
import org.hibernate.search.annotations.TokenFilterDef;
import org.hibernate.search.annotations.TokenizerDef;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Entity
@Table(name = "city")
@JsonInclude(Include.NON_DEFAULT)

@AnalyzerDefs({

		@AnalyzerDef(name = "edgecustomanalyzer1", tokenizer = @TokenizerDef(factory = StandardTokenizerFactory.class), filters = {

				@TokenFilterDef(factory = LowerCaseFilterFactory.class),
				@TokenFilterDef(factory = SnowballPorterFilterFactory.class, params = {
						@Parameter(name = "language", value = "English") }),
				@TokenFilterDef(factory = EdgeNGramFilterFactory.class, params = {
						@Parameter(name = "maxGramSize", value = "8"),
						@Parameter(name = "minGramSize", value = "2") }) }) })
@Indexed
public class City {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "city_id")
	@JsonIgnore
	private Long cityId;
	private String cityCode;

	@Field(index = Index.YES, store = Store.NO, analyze = Analyze.YES)
	@Analyzer(definition = "edgecustomanalyzer1")
	private String cityName;

	private String formattedCityName;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "state_id", nullable = false)
	@IndexedEmbedded(includeEmbeddedObjectId = true)
	private State state;

	@Column(name = "is_active")
	@Field
	private boolean active;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "city_id")
	@IndexedEmbedded(includePaths = "pincode")
	private List<Pincode> pincodes;

	public City() {
		super();
	}

	public City(String cityCode, String cityName, String formattedCityName, State state, List<Pincode> pincodes,
			boolean active) {
		super();
		this.cityCode = cityCode;
		this.cityName = cityName;
		this.formattedCityName = formattedCityName;
		this.state = state;
		this.active = active;
		this.pincodes = pincodes;
	}

	public Long getCityId() {
		return cityId;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityId(Long cityId) {
		this.cityId = cityId;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getFormattedCityName() {
		return formattedCityName;
	}

	public void setFormattedCityName(String formattedCityName) {
		this.formattedCityName = formattedCityName;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public List<Pincode> getPincodes() {
		return pincodes;
	}

	public void setPincodes(List<Pincode> pincodes) {
		this.pincodes = pincodes;
	}

}
