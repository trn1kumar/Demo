package com.gloqr.configuration;

import javax.annotation.Resource;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.gloqr.rest.endpoint.CircleEndpoint;
import com.gloqr.rest.endpoint.ContentServerEndpoint;
import com.gloqr.rest.endpoint.NotificationEndPoint;
import com.gloqr.rest.endpoint.ProductEndPoint;
import com.gloqr.rest.endpoint.ServiceEndPoint;
import com.gloqr.rest.endpoint.SmeEndPoint;

@Configuration
@PropertySource(value = { "file:${location}/common-service-dev.properties" })
public class BeanConfiguration {

	@Resource
	private Environment environment;

	@Bean
	public CircleEndpoint circleEndPointConfig() {
		Client client = ClientBuilder.newClient();
		String endPoint = environment.getRequiredProperty("circle.endpoint");
		String searchSmes = environment.getRequiredProperty("search.smes");
		return new CircleEndpoint(client, endPoint, searchSmes);
	}

	@Bean
	public SmeEndPoint smeEndPointConfig() {
		Client client = ClientBuilder.newClient();
		String endPoint = environment.getRequiredProperty("sme.endpoint");
		String suggestSmes = environment.getRequiredProperty("suggest.smes");
		String searchSmes = environment.getRequiredProperty("search.smes");
		return new SmeEndPoint(client, endPoint, suggestSmes, searchSmes);
	}

	@Bean
	public ProductEndPoint productEndPointConfig() {
		Client client = ClientBuilder.newClient();
		String endPoint = environment.getRequiredProperty("product.endpoint");
		String productsResult = environment.getRequiredProperty("search.product.result");
		String searchSuggest = environment.getRequiredProperty("search.product.suggest");

		return new ProductEndPoint(client, endPoint, productsResult, searchSuggest);

	}

	@Bean
	public ServiceEndPoint serviceEndPointConfig() {
		Client client = ClientBuilder.newClient();
		String endPoint = environment.getRequiredProperty("service.endpoint");
		String searchResult = environment.getRequiredProperty("search.service.result");
		String searchSuggest = environment.getRequiredProperty("search.service.suggest");

		return new ServiceEndPoint(client, endPoint, searchResult, searchSuggest);
	}

	@Bean
	public ContentServerEndpoint contentConfiguration() {
		Client client = ClientBuilder.newBuilder().register(MultiPartFeature.class).build();

		String endPoint = environment.getRequiredProperty("contentserver.endpoint");
		String uploadFiles = environment.getRequiredProperty("files.endpoint.path");
		String uploadFile = environment.getRequiredProperty("file.endpoint.path");
		String deleteFile = environment.getRequiredProperty("deletefiles.endpoint.path");
		return new ContentServerEndpoint(client, endPoint, uploadFiles, uploadFile, deleteFile);
	}

	@Bean
	public NotificationEndPoint notificationConfiguration() {
		Client client = ClientBuilder.newClient();
		String notificationEndPoint = environment.getRequiredProperty("notification.endpoint");
		String emailEndPointPath = environment.getRequiredProperty("email.endpoint.path");
		String smsEndPointPath = environment.getRequiredProperty("sms.endpoint.path");

		return new NotificationEndPoint(client, notificationEndPoint, emailEndPointPath, smsEndPointPath);
	}

	@Bean(name = "taskExecutor")
	public TaskExecutor workExecutor() {
		ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
		threadPoolTaskExecutor.setThreadNamePrefix("Async-Thread");

		threadPoolTaskExecutor.setCorePoolSize(5);
		threadPoolTaskExecutor.setMaxPoolSize(10);
		threadPoolTaskExecutor.setQueueCapacity(600);
		threadPoolTaskExecutor.afterPropertiesSet();

		return threadPoolTaskExecutor;
	}

}
