package com.gloqr.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.SearchSuggestResultDto;
import com.gloqr.exception.CustomException;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.model.http.response.ResponseMessages;
import com.gloqr.service.HomePageSearchService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = UrlMapping.ROOT_API)
public class HomePageSearchController {

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private HomePageSearchService masterSearchService;

	@GetMapping(UrlMapping.HOMEPAGE_SUGGESTION)
	public ResponseEntity<CustomHttpResponse<SearchSuggestResultDto>> getSuggestions(
			@RequestParam(value = "searchText") String searchText) {

		SearchSuggestResultDto suggestResult = masterSearchService.getSuggestions(searchText);
		return responseMaker.successResponse(suggestResult, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.HOMEPAGE_SEARCH_RESULT)
	public ResponseEntity<CustomHttpResponse<SearchSuggestResultDto>> getSearchResult(
			@RequestParam(value = "searchText") String searchText) {

		SearchSuggestResultDto searchResult = masterSearchService.getSearchResults(searchText);

		if (searchResult.getSearchedResult().isEmpty())
			throw new CustomException("No results found.", HttpStatus.NOT_FOUND);

		return responseMaker.successResponse(searchResult, ResponseMessages.SUCCESS, HttpStatus.OK);
	}
}
