package com.gloqr.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.CityDto;
import com.gloqr.entity.address.City;
import com.gloqr.mapper.CustomModelMapper;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.model.http.response.ResponseMessages;
import com.gloqr.service.AddressSearchService;

@RestController
@CrossOrigin("*")
@RequestMapping(value = UrlMapping.ROOT_API)
public class AddressSearchController {

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private AddressSearchService searchService;

	@Autowired
	private CustomModelMapper customModelMapper;

	@GetMapping(UrlMapping.SUGGEST_CITIES)
	public ResponseEntity<CustomHttpResponse<List<CityDto>>> addressSearch(
			@RequestParam(required = false) String searchText, @RequestParam(required = false) Integer pincode) {

		List<City> cities = null;
		List<CityDto> citiesDto = new ArrayList<>();
		try {
			cities = searchService.getSearchResult(searchText, pincode);

			cities.forEach(city -> citiesDto.add(customModelMapper.convert(city, CityDto.class)));
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(citiesDto, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

}
