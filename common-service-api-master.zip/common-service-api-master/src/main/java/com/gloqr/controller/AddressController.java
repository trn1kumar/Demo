package com.gloqr.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.UrlMapping;
import com.gloqr.dto.CityDto;
import com.gloqr.entity.address.City;
import com.gloqr.entity.address.Country;
import com.gloqr.entity.address.State;
import com.gloqr.mapper.CustomModelMapper;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.model.http.response.ResponseMessages;
import com.gloqr.service.AddressService;

@RestController
@RequestMapping(value = UrlMapping.ROOT_API)
@CrossOrigin("*")
public class AddressController {

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private AddressService addressService;

	@Autowired
	private CustomModelMapper customModelMapper;

	@PostMapping(UrlMapping.ADD_CITIES)
	public ResponseEntity<CustomHttpResponse<String>> addCities(@RequestBody List<City> cities) {
		try {
			addressService.saveCities(cities);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(ResponseMessages.CITITES_ADDED, HttpStatus.CREATED);
	}

	@PostMapping(UrlMapping.ADD_STATES)
	public ResponseEntity<CustomHttpResponse<String>> addStates(@RequestBody List<State> states) {
		try {
			addressService.saveStates(states);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(ResponseMessages.STATES_ADDED, HttpStatus.CREATED);
	}

	@PostMapping(UrlMapping.ADD_COUNTRIES)
	public ResponseEntity<CustomHttpResponse<String>> addCountries(@RequestBody List<Country> countries) {
		try {
			addressService.saveCountries(countries);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(ResponseMessages.CONTRIES_ADDED, HttpStatus.CREATED);
	}

	@GetMapping(UrlMapping.GET_CITY)
	public ResponseEntity<CustomHttpResponse<City>> getCity(@RequestParam String cityCode) {
		City city = null;
		try {
			city = addressService.getCity(cityCode);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(city, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.GET_STATE)
	public ResponseEntity<CustomHttpResponse<State>> getState(@RequestParam String stateCode) {
		State state = null;
		try {
			state = addressService.getState(stateCode);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(state, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.GET_COUNTRY)
	public ResponseEntity<CustomHttpResponse<Country>> getCountry(@RequestParam String countryCode) {
		Country country = null;
		try {
			country = addressService.getCountry(countryCode);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(country, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.GET_CITIES)
	public ResponseEntity<CustomHttpResponse<List<City>>> getCitiesByState(@RequestParam String code) {

		List<City> cities = null;
		try {
			cities = addressService.getCitiesByState(code);
		} catch (Exception e) {
			throw e;
		}
		return responseMaker.successResponse(cities, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.GET_STATES)
	public ResponseEntity<CustomHttpResponse<List<State>>> getStatesByCountry(@RequestParam String code) {
		List<State> states = null;
		try {
			states = addressService.getStatesByCountry(code);
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(states, ResponseMessages.SUCCESS, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.GET_INDIAN_STATES)
	public ResponseEntity<CustomHttpResponse<List<State>>> getIndianStatesWithCities() {

		List<State> states = null;
		try {
			states = addressService.getStatesWithCities();
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(states, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.GET_COUNTRIES)
	public ResponseEntity<CustomHttpResponse<List<Country>>> getCountries() {
		List<Country> contries = null;
		try {
			contries = addressService.getCountries();
		} catch (Exception e) {
			throw e;
		}

		return responseMaker.successResponse(contries, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

	@GetMapping(UrlMapping.GET_CITY_BY_PINCODE)
	public ResponseEntity<CustomHttpResponse<CityDto>> getCityByPincode(@RequestParam int pincode) {
		CityDto cityDto = customModelMapper.convert(addressService.getCityByPincode(pincode), CityDto.class);
		return responseMaker.successResponse(cityDto, ResponseMessages.SUCCESS, HttpStatus.OK);

	}

}
