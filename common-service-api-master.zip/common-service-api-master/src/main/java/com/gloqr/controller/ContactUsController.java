package com.gloqr.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.constants.UrlMapping;
import com.gloqr.entity.ContactUs;
import com.gloqr.model.http.response.CustomHttpResponse;
import com.gloqr.model.http.response.ResponseMaker;
import com.gloqr.service.ContactUsService;
import com.gloqr.service.NotificationService;

@RestController
@RequestMapping(value = UrlMapping.ROOT_API)
@CrossOrigin("*")
public class ContactUsController {

	@Autowired
	private ContactUsService contactUsService;

	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private NotificationService notification;

	@PostMapping(UrlMapping.NEW_CONTACT)
	public ResponseEntity<CustomHttpResponse<String>> newContactUs(@RequestBody @Valid ContactUs contactUs) {

		contactUsService.newContact(contactUs);
		notification.sendEmailAndSMS(contactUs);
		notification.sendEmailToGloqr(contactUs);
		return responseMaker.successResponse("Contact Us entry added successfully", HttpStatus.OK);
	}

}
