package com.smeface.cart.status.entity;

import java.io.Serializable;

public class FirstStage implements Serializable {

	private static final long serialVersionUID = -7479261488635495335L;
	private Integer id;
	private String stepStatus = "Pending";
	private String statusName = "Ordered";

	public FirstStage() {
		super();
	}

	public static class FirstStageBuilder {
		private String stepStatus = "Pending";
		private String statusName = "Ordered";

		public FirstStageBuilder stepStatus(String stepStatus) {
			this.stepStatus = stepStatus;
			return this;
		}

		public FirstStageBuilder statusName(String statusName) {
			this.statusName = statusName;
			return this;
		}

		public FirstStage build() {
			return new FirstStage(this);

		}

	}

	private FirstStage(FirstStageBuilder builder) {
		this.stepStatus = builder.stepStatus;
		this.statusName = builder.statusName;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

	public String getStepStatus() {
		return stepStatus;
	}

	public void setStepStatus(String stepStatus) {
		this.stepStatus = stepStatus;
	}

}
