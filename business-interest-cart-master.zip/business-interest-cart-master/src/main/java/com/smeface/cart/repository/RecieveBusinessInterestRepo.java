package com.smeface.cart.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.smeface.cart.entity.RecievdBusinessInterest;

@Repository
public interface RecieveBusinessInterestRepo extends JpaRepository<RecievdBusinessInterest, Long> {

	RecievdBusinessInterest findByUuidAndRejectStatus(String uuid, boolean status);

	RecievdBusinessInterest findByUuidAndIsActive(String uuid, boolean status);

	List<RecievdBusinessInterest> findBySmeUserIDAndIsActive(String smeUserUid, boolean bool, Pageable pageable);

	RecievdBusinessInterest findByBusinessInterestUUIDAndUserUUIDAndIsActive(String productUUID, String userUUID,
			Boolean bool);

	@Query(value = "SELECT COUNT(r) FROM RecievdBusinessInterest r JOIN " + "r.orderStatus os "
			+ "where r.smeUserID=:smeId AND r.isActive=true "
			+ "AND (os.currentStatus!=:biClosed AND os.currentStatus!=:poConfirmed)")
	Integer receivedCartCount(@Param("smeId") String smeId, @Param("biClosed") String biClosed,
			@Param("poConfirmed") String poConfirmed);

	@Query(value = "SELECT r FROM RecievdBusinessInterest r JOIN " + "r.orderStatus os "
			+ "where r.smeUserID=:uuid AND r.isActive=true "
			+ "AND os.currentStatus!=:biClosed AND os.currentStatus!=:poConfirmed")
	List<RecievdBusinessInterest> receivedCart(@Param("uuid") String uuid, Pageable pageable,
			@Param("biClosed") String biClosed, @Param("poConfirmed") String poConfirmed);

	RecievdBusinessInterest findByUuid(String uid);

}
