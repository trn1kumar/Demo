package com.smeface.cart.factory;

import com.smeface.cart.status.entity.ThirdStage;

public class ThirdStageImpl implements FactoryInterface<Object>{

	@Override
	public Object returnObject() {
		return new ThirdStage.ThirdStageBuilder().build();
	}

}
