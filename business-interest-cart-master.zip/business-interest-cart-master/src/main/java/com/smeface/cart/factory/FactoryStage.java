package com.smeface.cart.factory;

public class FactoryStage {

	private FactoryStage() {
		super();
	}

	public static FactoryInterface<?> createStageObject(String classname) {

		switch (classname) {

		case "OrderStatus":
			return new OrderStatusImpl();
		case "FirstStage":
			return new FirstStageImpl();
		case "SecondStage":
			return new SecondStageImpl();
		case "ThirdStage":
			return new ThirdStageImpl();
		case "FinalStage":
			return new FinalStageImpl();
		default:
			return null;
		}

	}

}
