package com.smeface.cart.dto;

import com.smeface.cart.entity.QuotationFormat;

public class QuotationPDF {

	private String fileLocation;
	private QuotationFormat quotationFormat;
	private boolean isSelected;

	public String getFileLocation() {
		return fileLocation;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

	public QuotationFormat getQuotationFormat() {
		return quotationFormat;
	}

	public void setQuotationFormat(QuotationFormat quotationFormat) {
		this.quotationFormat = quotationFormat;
	}

	public boolean isSelected() {
		return isSelected;
	}

	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}

}
