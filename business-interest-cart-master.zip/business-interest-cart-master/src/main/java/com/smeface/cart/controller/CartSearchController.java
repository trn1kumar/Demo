package com.smeface.cart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smeface.cart.constant.APIList;
import com.smeface.cart.entity.RecievdBusinessInterest;
import com.smeface.cart.exception.CustomException;
import com.smeface.cart.filter.CartFilter;
import com.smeface.cart.util.HttpRequestParser;

@RestController
@RequestMapping(APIList.BASE_URL)
public class CartSearchController {

	@Autowired
	private CartFilter cartFilter;

	@Autowired
	private HttpRequestParser requestParser;

	@GetMapping(value = "/search/cart/{productName}")
	public ResponseEntity<?> getProductsCartItems(@PathVariable String productName) {
		try {

			List<RecievdBusinessInterest> recievdBusinessInterests = cartFilter.getCartByProductName(productName,
					requestParser.getUserUUID());
			return ResponseEntity.ok(recievdBusinessInterests);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}
	}

	@GetMapping(value = "/search/cart/{userName}/user")
	public ResponseEntity<?> getProductsCartItemsByUser(@PathVariable String userName) {
		try {
			List<RecievdBusinessInterest> recievdBusinessInterests = cartFilter.getCartByUserName(userName,
					requestParser.getUserUUID());
			return ResponseEntity.ok(recievdBusinessInterests);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}
	}

	@GetMapping(value = "/search/cart/{stages}/stages")
	public ResponseEntity<?> getProductsCartItemsByStage(@PathVariable String stages) {
		try {
			List<RecievdBusinessInterest> recievdBusinessInterests = cartFilter.getCartByStage(stages,
					requestParser.getUserUUID());
			return ResponseEntity.ok(recievdBusinessInterests);
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}
	}

}
