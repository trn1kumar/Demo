package com.smeface.cart.status.entity;

import java.io.Serializable;

public class FinalStage implements Serializable {

	private static final long serialVersionUID = 8482501177824404311L;

	private Integer id;

	private String stepStatus = "Pending";

	private String statusName = "Delivered";

	public FinalStage() {
		super();
	}

	public FinalStage(String statusName) {
		super();
		this.statusName = statusName;
	}

	public FinalStage(String stepStatus, String statusName) {
		this.stepStatus = stepStatus;
		this.statusName = statusName;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getStepStatus() {
		return stepStatus;
	}

	public void setStepStatus(String stepStatus) {
		this.stepStatus = stepStatus;
	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

}