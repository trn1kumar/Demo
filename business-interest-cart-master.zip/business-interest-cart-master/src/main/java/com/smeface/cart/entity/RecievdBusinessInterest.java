package com.smeface.cart.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.lucene.analysis.core.LowerCaseFilterFactory;
import org.apache.lucene.analysis.ngram.EdgeNGramFilterFactory;
import org.apache.lucene.analysis.snowball.SnowballPorterFilterFactory;
import org.apache.lucene.analysis.standard.StandardTokenizerFactory;
import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Analyzer;
import org.hibernate.search.annotations.AnalyzerDef;
import org.hibernate.search.annotations.AnalyzerDefs;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;
import org.hibernate.search.annotations.Parameter;
import org.hibernate.search.annotations.Store;
import org.hibernate.search.annotations.TokenFilterDef;
import org.hibernate.search.annotations.TokenizerDef;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.smeface.audit.Auditable;
import com.smeface.cart.dto.BiAttributeMapper;
import com.smeface.cart.dto.QuotationPDF;
import com.smeface.cart.dto.UserDto;
import com.smeface.cart.status.entity.OrderStatus;

@Entity
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@Table(name = "RecievedCartItem")
@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler", "recievedCartId" })
@AnalyzerDefs({
		@AnalyzerDef(name = "customanalyzer", tokenizer = @TokenizerDef(factory = StandardTokenizerFactory.class), filters = {

				@TokenFilterDef(factory = LowerCaseFilterFactory.class),
				@TokenFilterDef(factory = SnowballPorterFilterFactory.class, params = {
						@Parameter(name = "language", value = "English") }), }),
		@AnalyzerDef(name = "edgecustomanalyzer1", tokenizer = @TokenizerDef(factory = StandardTokenizerFactory.class), filters = {

				@TokenFilterDef(factory = LowerCaseFilterFactory.class),
				@TokenFilterDef(factory = SnowballPorterFilterFactory.class, params = {
						@Parameter(name = "language", value = "English") }),
				@TokenFilterDef(factory = EdgeNGramFilterFactory.class, params = {
						@Parameter(name = "maxGramSize", value = "8"),
						@Parameter(name = "minGramSize", value = "2") }) })

})

@Indexed
public class RecievdBusinessInterest extends Auditable<String> {

	private static final long serialVersionUID = 7684951516540598469L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long recievedCartId;

	@Column(name = "SMEID")
	@Field(index = Index.YES, store = Store.YES, analyze = Analyze.NO)
	@Analyzer(definition = "customanalyzer")
	private String smeId;

	@Column(name = "SME_USER_ID")
	private String smeUserID;

	@Column(name = "Recievd_Business_Interest_UUID", unique = true)
	@Field(index = Index.YES, store = Store.YES, analyze = Analyze.YES)
	@Analyzer(definition = "customanalyzer")
	private String uuid;

	@Column(name = "username")
	private String userName;

	@OneToOne(cascade = CascadeType.ALL)
	@IndexedEmbedded(includeEmbeddedObjectId = true)
	private OrderStatus orderStatus;

	@Column(name = "userUUID")
	@Field(index = Index.YES, store = Store.YES, analyze = Analyze.YES)
	@Analyzer(definition = "customanalyzer")
	private String userUUID;

	@Column(name = "viewStatus")
	private Boolean viewStatus;

	@OneToOne(cascade = CascadeType.ALL)
	@IndexedEmbedded(includeEmbeddedObjectId = true)
	private BiAttributeMapper cartAttribute;

	@Column(name = "ACTIVE_STATUS")
	@Field(index = Index.YES, store = Store.YES, analyze = Analyze.YES)
	@Analyzer(definition = "customanalyzer")
	private Boolean isActive;

	@Transient
	private String quotationType;

	@Transient
	private boolean isQuotationGenerated;

	@Transient
	private List<QuotationPDF> quotationPDF;

	@Column(name = "Reject_Status")
	private boolean rejectStatus;

	@Column(name = "BUSINES_INTEREST_QUANTITY")
	private Integer businessInterestQuantity;

	@Column(name = "BUSINESS_CART_TOTAL_AMOUNT")
	private Double totalAmount;

	@Column(name = "BusinessInterestUUID")
	private String businessInterestUUID;

	@Transient
	private UserDto userDetails;

	@Column(name = "Provider", updatable = false, nullable = false)
	private String provider;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public OrderStatus getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(OrderStatus orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getQuotationType() {
		return quotationType;
	}

	public void setQuotationType(String quotationType) {
		this.quotationType = quotationType;
	}

	public List<QuotationPDF> getQuotationPDF() {
		return quotationPDF;
	}

	public void setQuotationPDF(List<QuotationPDF> quotationPDF) {
		this.quotationPDF = quotationPDF;
	}

	public boolean isQuotationGenerated() {
		return isQuotationGenerated;
	}

	public void setQuotationGenerated(boolean isGenerated) {
		this.isQuotationGenerated = isGenerated;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getSmeUserID() {
		return smeUserID;
	}

	public void setSmeUserID(String smeUserID) {
		this.smeUserID = smeUserID;
	}

	public UserDto getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(UserDto userDetails) {
		this.userDetails = userDetails;
	}

	public Boolean getViewStatus() {
		return viewStatus;
	}

	public void setViewStatus(Boolean viewStatus) {
		this.viewStatus = viewStatus;
	}

	public boolean isRejectStatus() {
		return rejectStatus;
	}

	public void setRejectStatus(boolean rejectStatus) {
		this.rejectStatus = rejectStatus;
	}

	public String getProvider() {
		return provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public String getBusinessInterestUUID() {
		return businessInterestUUID;
	}

	public void setBusinessInterestUUID(String businessInterestUUID) {
		this.businessInterestUUID = businessInterestUUID;
	}

	public String getUserUUID() {
		return userUUID;
	}

	public void setUserUUID(String userUUID) {
		this.userUUID = userUUID;
	}

	public Integer getBusinessInterestQuantity() {
		return businessInterestQuantity;
	}

	public void setBusinessInterestQuantity(Integer businessInterestQuantity) {
		this.businessInterestQuantity = businessInterestQuantity;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Long getRecievedCartId() {
		return recievedCartId;
	}

	public void setRecievedCartId(Long recievedCartId) {
		this.recievedCartId = recievedCartId;
	}

	public String getSmeId() {
		return smeId;
	}

	public void setSmeId(String smeId) {
		this.smeId = smeId;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	/*
	 * public MessageCenter getMessageCenter() { return messageCenter; }
	 * 
	 * public void setMessageCenter(MessageCenter messageCenter) {
	 * this.messageCenter = messageCenter; }
	 */

	public BiAttributeMapper getCartAttribute() {
		return cartAttribute;
	}

	public void setCartAttribute(BiAttributeMapper cartAttribute) {
		this.cartAttribute = cartAttribute;
	}

	@Override
	public String toString() {
		return "RecievdBusinessInterest [recievedCartId=" + recievedCartId + ", smeId=" + smeId + ", uuid=" + uuid
				+ ", userName=" + userName + ", userUUID=" + userUUID + ", mobileNumber=" + ", eMailid=" + ", isActive="
				+ isActive + ", businessInterestQuantity=" + businessInterestQuantity + ", totalAmount=" + totalAmount
				+ ", status=" + ", products=" + businessInterestUUID + ", userBusinessInterestCreationDate=" + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((businessInterestQuantity == null) ? 0 : businessInterestQuantity.hashCode());
		result = prime * result + ((isActive == null) ? 0 : isActive.hashCode());
		result = prime * result + ((businessInterestUUID == null) ? 0 : businessInterestUUID.hashCode());
		result = prime * result + ((recievedCartId == null) ? 0 : recievedCartId.hashCode());
		result = prime * result + ((smeId == null) ? 0 : smeId.hashCode());
		result = prime * result + ((userName == null) ? 0 : userName.hashCode());
		result = prime * result + ((userUUID == null) ? 0 : userUUID.hashCode());
		result = prime * result + ((uuid == null) ? 0 : uuid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RecievdBusinessInterest other = (RecievdBusinessInterest) obj;
		if (businessInterestQuantity == null) {
			if (other.businessInterestQuantity != null)
				return false;
		} else if (!businessInterestQuantity.equals(other.businessInterestQuantity))
			return false;

		if (isActive == null) {
			if (other.isActive != null)
				return false;
		} else if (!isActive.equals(other.isActive))
			return false;

		if (businessInterestUUID == null) {
			if (other.businessInterestUUID != null)
				return false;
		} else if (!businessInterestUUID.equals(other.businessInterestUUID))
			return false;
		if (recievedCartId == null) {
			if (other.recievedCartId != null)
				return false;
		} else if (!recievedCartId.equals(other.recievedCartId))
			return false;
		if (smeId == null) {
			if (other.smeId != null)
				return false;
		} else if (!smeId.equals(other.smeId))
			return false;

		if (totalAmount == null) {
			if (other.totalAmount != null)
				return false;
		} else if (!totalAmount.equals(other.totalAmount))
			return false;

		if (userName == null) {
			if (other.userName != null)
				return false;
		} else if (!userName.equals(other.userName))
			return false;
		if (userUUID == null) {
			if (other.userUUID != null)
				return false;
		} else if (!userUUID.equals(other.userUUID))
			return false;
		if (uuid == null) {
			if (other.uuid != null)
				return false;
		} else if (!uuid.equals(other.uuid))
			return false;
		return true;
	}

}
