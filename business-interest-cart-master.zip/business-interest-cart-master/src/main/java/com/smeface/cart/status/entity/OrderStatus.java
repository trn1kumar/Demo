package com.smeface.cart.status.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.smeface.audit.Auditable;

@Entity
@Table(name = "OrderStatus")
@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler", "id", "quotationFileLocation",
		"purchaseOrderLocation" })
public class OrderStatus extends Auditable<String> implements Serializable {

	private static final long serialVersionUID = -4062844263212761707L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(name = "action")
	private String action;

	@Column(name = "quotationFileLocation")
	private String quotationFileLocation;

	@Column(name = "purchaseOrderLocation")
	private String purchaseOrderLocation;

	@Column(name = "currentStatus")
	private String currentStatus;

	@Column(name = "remark", length = 500)
	private String remark;

	@Column(name = "rejectRemark")
	private String rejectRemark;

	@Column(name = "purchaseOrderRemark", length = 500)
	private String purchaseOrderRemark;

	@Transient
	private FirstStage firstStage;
	@Transient
	private SecondStage secondStage;
	@Transient
	private ThirdStage thirdStage;
	@Transient
	private FinalStage finalStage;

	public OrderStatus() {
		super();
	}

	public static class CartOrderStageBuilder {
		private Long id;
		private String action;
		private String quotationFileLocation;
		private String purchaseOrderLocation;
		private String currentStatus;
		private String remark;
		private String purchaseOrderRemark;

		public CartOrderStageBuilder id(Long id) {
			this.id = id;
			return this;
		}

		public CartOrderStageBuilder action(String action) {
			this.action = action;
			return this;
		}

		public CartOrderStageBuilder quotationFileLocation(String quotationFileLocation) {
			this.quotationFileLocation = quotationFileLocation;
			return this;
		}

		public CartOrderStageBuilder purchaseOrderLocation(String purchaseOrderLocation) {
			this.purchaseOrderLocation = purchaseOrderLocation;
			return this;
		}

		public CartOrderStageBuilder currentStatus(String currentStatus) {
			this.currentStatus = currentStatus;
			return this;
		}

		public CartOrderStageBuilder remark(String remark) {
			this.remark = remark;
			return this;
		}

		public CartOrderStageBuilder purchaseOrderRemark(String purchaseOrderRemark) {
			this.purchaseOrderRemark = purchaseOrderRemark;
			return this;
		}

		public OrderStatus build() {
			return new OrderStatus(this);
		}

	}

	private OrderStatus(CartOrderStageBuilder cartOrderStageBuilder) {
		this.id = cartOrderStageBuilder.id;
		this.action = cartOrderStageBuilder.action;
		this.purchaseOrderLocation = cartOrderStageBuilder.purchaseOrderLocation;
		this.quotationFileLocation = cartOrderStageBuilder.quotationFileLocation;
		this.remark = cartOrderStageBuilder.remark;
		this.currentStatus = cartOrderStageBuilder.currentStatus;
		this.purchaseOrderRemark = cartOrderStageBuilder.purchaseOrderRemark;
	}

	public Long getId() {
		return id;
	}

	public String getAction() {
		return action;
	}

	public String getQuotationFileLocation() {
		return quotationFileLocation;
	}

	public String getPurchaseOrderLocation() {
		return purchaseOrderLocation;
	}

	public String getCurrentStatus() {
		return currentStatus;
	}

	public String getRemark() {
		return remark;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public void setQuotationFileLocation(String quotationFileLocation) {
		this.quotationFileLocation = quotationFileLocation;
	}

	public void setPurchaseOrderLocation(String purchaseOrderLocation) {
		this.purchaseOrderLocation = purchaseOrderLocation;
	}

	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public FirstStage getFirstStage() {
		return firstStage;
	}

	public void setFirstStage(FirstStage firstStage) {
		this.firstStage = firstStage;
	}

	public SecondStage getSecondStage() {
		return secondStage;
	}

	public void setSecondStage(SecondStage secondStage) {
		this.secondStage = secondStage;
	}

	public ThirdStage getThirdStage() {
		return thirdStage;
	}

	public void setThirdStage(ThirdStage thirdStage) {
		this.thirdStage = thirdStage;
	}

	public FinalStage getFinalStage() {
		return finalStage;
	}

	public void setFinalStage(FinalStage finalStage) {
		this.finalStage = finalStage;
	}

	public void setPurchaseOrderRemark(String purchaseOrderRemark) {
		this.purchaseOrderRemark = purchaseOrderRemark;
	}

	public String getPurchaseOrderRemark() {
		return purchaseOrderRemark;
	}

	public String getRejectRemark() {
		return rejectRemark;
	}

	public void setRejectRemark(String rejectRemark) {
		this.rejectRemark = rejectRemark;
	}

}
