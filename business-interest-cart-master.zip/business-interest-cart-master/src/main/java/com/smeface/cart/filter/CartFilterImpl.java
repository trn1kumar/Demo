package com.smeface.cart.filter;

import java.util.List;

import javax.persistence.EntityManager;

import org.apache.lucene.search.Query;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smeface.cart.entity.RecievdBusinessInterest;

@Service
public class CartFilterImpl implements CartFilter {
	
	@Autowired
	private EntityManager entityManager;
	
	private String smeUID = "smeId";
	private String isActive = "isActive";

	@SuppressWarnings("unchecked")	
	@Override
	public List<RecievdBusinessInterest> getCartByProductName(String productName, String smeId) {
		List<RecievdBusinessInterest> recieveCarts = null;
		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);
		
		QueryBuilder cartQueryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(RecievdBusinessInterest.class).get();
		Query luceneQuery = cartQueryBuilder.keyword().onField("cartAttribute.itemDisplayName")
				.matching(productName).createQuery();
		Query luceneQuery1 = cartQueryBuilder.keyword().onField(isActive).matching(true)
				.createQuery();
		Query smeID = cartQueryBuilder.keyword().onField(smeUID).matching(smeId)
				.createQuery();

		Query masterquery = cartQueryBuilder.bool().must(luceneQuery).must(luceneQuery1).must(smeID).createQuery();
		FullTextQuery query = fullTextEntityManager.createFullTextQuery(masterquery, RecievdBusinessInterest.class);
		recieveCarts = query.getResultList();
		
		return recieveCarts;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RecievdBusinessInterest> getCartByUserName(String userName, String smeId) {
		List<RecievdBusinessInterest> recieveCarts = null;
		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);
		
		QueryBuilder cartQueryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(RecievdBusinessInterest.class).get();
		Query luceneQuery = cartQueryBuilder.keyword().onField("userUUID")
				.matching(userName).createQuery();
		Query luceneQuery1 = cartQueryBuilder.keyword().onField(isActive).matching(true)
				.createQuery();
		Query smeID = cartQueryBuilder.keyword().onField(smeUID).matching(smeId)
				.createQuery();

		Query masterquery = cartQueryBuilder.bool().must(luceneQuery).must(luceneQuery1).must(smeID).createQuery();
		FullTextQuery query = fullTextEntityManager.createFullTextQuery(masterquery, RecievdBusinessInterest.class);
		recieveCarts = query.getResultList();
		
		return recieveCarts;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RecievdBusinessInterest> getCartByStage(String stage, String smeId) {
		List<RecievdBusinessInterest> recieveCarts = null;
		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);
		
		QueryBuilder cartQueryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(RecievdBusinessInterest.class).get();
		Query luceneQuery = cartQueryBuilder.keyword().onField("orderStatus.currentStatus")
				.matching(stage).createQuery();
		Query luceneQuery1 = cartQueryBuilder.keyword().onField(isActive).matching(true)
				.createQuery();
		Query smeID = cartQueryBuilder.keyword().onField(smeUID).matching(smeId)
				.createQuery();

		Query masterquery = cartQueryBuilder.bool().must(luceneQuery).must(luceneQuery1).must(smeID).createQuery();
		FullTextQuery query = fullTextEntityManager.createFullTextQuery(masterquery, RecievdBusinessInterest.class);
		recieveCarts = query.getResultList();
		
		return recieveCarts;
	}

}
