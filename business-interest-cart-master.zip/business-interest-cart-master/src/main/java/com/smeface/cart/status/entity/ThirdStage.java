package com.smeface.cart.status.entity;

import java.io.Serializable;

public class ThirdStage implements Serializable {

	private static final long serialVersionUID = 8242530674794153548L;
	private Integer id;
	private String stepStatus = "Pending";
	private String quotationFile;
	private String remark;
	private String statusName = "Purchase Order";

	public ThirdStage() {
		super();
	}

	public static class ThirdStageBuilder {
		private String stepStatus = "Pending";
		private String quotationFile;
		private String remark;
		private String statusName = "Purchase Order";

		public ThirdStageBuilder stepStatus(String stepStatus) {
			this.stepStatus = stepStatus;
			return this;
		}

		public ThirdStageBuilder quotationFile(String quotationFile) {
			this.quotationFile = quotationFile;
			return this;
		}

		public ThirdStageBuilder remark(String remark) {
			this.remark = remark;
			return this;
		}

		public ThirdStageBuilder statusName(String statusName) {
			this.statusName = statusName;
			return this;
		}

		public ThirdStage build() {
			return new ThirdStage(this);
		}

	}

	private ThirdStage(ThirdStageBuilder builder) {
		this.statusName = builder.statusName;
		this.stepStatus = builder.stepStatus;
		this.quotationFile = builder.quotationFile;
		this.remark = builder.remark;

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

	public String getStepStatus() {
		return stepStatus;
	}

	public void setStepStatus(String stepStatus) {
		this.stepStatus = stepStatus;
	}

	public String getQuotationFile() {
		return quotationFile;
	}

	public void setQuotationFile(String quotationFile) {
		this.quotationFile = quotationFile;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

}