package com.smeface.cart.model.notification;

public class EmailEvent {

	private String emailId;
	private String subject;
	private String eventMessage;
	private boolean sentStatus;
	private String attachmentFileLocation;

	public EmailEvent() {
		super();
	}

	public EmailEvent(String emailId, String subject, String eventMessage, String attachmentFileLocation) {
		this(emailId, subject, eventMessage);
		this.attachmentFileLocation = attachmentFileLocation;
	}

	public EmailEvent(String emailId, String subject, String eventMessage) {
		super();
		this.emailId = emailId;
		this.subject = subject;
		this.eventMessage = eventMessage;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getEventMessage() {
		return eventMessage;
	}

	public void setEventMessage(String eventMessage) {
		this.eventMessage = eventMessage;
	}

	public boolean isSentStatus() {
		return sentStatus;
	}

	public void setSentStatus(boolean sentStatus) {
		this.sentStatus = sentStatus;
	}

	public String getAttachmentFileLocation() {
		return attachmentFileLocation;
	}

	public void setAttachmentFileLocation(String attachmentFileLocation) {
		this.attachmentFileLocation = attachmentFileLocation;
	}

}
