package com.smeface.cart.constant;

public class CartConstants {

	public enum BusinessInterest {
		PROVIDER;
	    public static final String PRODUCT = "PRODUCT";
	    public static final String SERVICE = "SERVICE";
	}

	public enum UserStages {
		USER_STAGES;
		public static final String SENT = "SENT";
		public static final String QUOTATION = "Quotation Received";
		public static final String BI_CLOSED = "BI closed"; 
		public static final String PURCHASE_ORDER = "PO Sent";
	}
	
	public enum SMEStages {
		SME_STAGES;
		public static final String RECEIVE = "Receive";
		public static final String QUOTATION = "Quotation Sent";
		public static final String PURCHASE_ORDER = "PO Received";
		public static final String PO_CONFIRMED = "PO Confirmed";
			
	}
	public enum Flag{
		FLAG;
		public static final boolean TRUE = true;
		public static final boolean FALSE = false;
		public static final String STEP_STATUS_PENDING = "Pending";
		public static final String STEP_STATUS_COMPLETED = "Completed";
	}

}
