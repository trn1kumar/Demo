package com.smeface.cart.dao;

import java.util.List;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.smeface.cart.constant.CartConstants;
import com.smeface.cart.entity.Cart;
import com.smeface.cart.entity.CartItem;
import com.smeface.cart.entity.RecievdBusinessInterest;
import com.smeface.cart.exception.CustomException;
import com.smeface.cart.repository.CartItemRepo;
import com.smeface.cart.repository.CartRepo;
import com.smeface.cart.repository.RecieveBusinessInterestRepo;

@Component
public class CartDaoImpl implements CartDao {

	@Autowired
	private CartRepo cartRepo;

	@Autowired
	private CartItemRepo cartItemRepo;

	@Autowired
	private RecieveBusinessInterestRepo recieveBusinessInterestRepo;

	private Logger logger = LogManager.getLogger();

	@Value("${cart.perpage}")
	private Integer limit;

	@Override
	@Caching(put = { @CachePut(value = { "cartItems", "recievedItems", "sentCount",
			"recieveCount" }, unless = "#result==null") }, evict = {
					@CacheEvict(value = { "cartItems", "recievedItems", "sentCount",
							"recieveCount" }, allEntries = true) })
	public void save(Cart cart) {
		try {
			cartRepo.save(cart);
		} catch (CustomException err) {
			logger.log(Level.ALL, err);
			throw new CustomException(err.getMessage(), err.getErrorCode());
		}
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	@Caching(put = { @CachePut(value = { "recievedItems" }, unless = "#result==null") }, evict = {
			@CacheEvict(value = { "recievedItems", "sentCount", "recieveCount" }, allEntries = true) })
	public void saveRecievedItem(RecievdBusinessInterest recievdBusinessInterest) {
		try {
			recieveBusinessInterestRepo.save(recievdBusinessInterest);
		} catch (CustomException err) {
			logger.log(Level.ALL, err);
			throw new CustomException(err.getMessage(), err.getErrorCode());
		}
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	@Caching(put = { @CachePut(value = { "cartItems" }, unless = "#result==null") }, evict = {
			@CacheEvict(value = { "cartItems", "sentCount", "recieveCount" }, allEntries = true) })
	public void saveCartItem(CartItem cartItem) {
		try {
			cartItemRepo.save(cartItem);
		} catch (CustomException err) {
			logger.log(Level.ALL, err);
			throw new CustomException(err.getMessage(), err.getErrorCode());
		}
	}

	@Override
	@Cacheable(value = "cartItems", key = "#userId + #page")
	public List<CartItem> getCartItem(String userId, int page) {
		try {
			return cartItemRepo.sentCartItems(userId,
					PageRequest.of(--page, limit, Sort.Direction.DESC, "creationDate"),
					CartConstants.UserStages.BI_CLOSED, CartConstants.SMEStages.PO_CONFIRMED);
		} catch (CustomException e) {
			logger.log(Level.ALL, e);
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}
	}

	@Override
	@Cacheable(value = "recievedItems", key = "#userId + #page")
	public List<RecievdBusinessInterest> getRecieveItem(String userId, int page) {
		try {
			return recieveBusinessInterestRepo.receivedCart(userId,
					PageRequest.of(--page, limit, Sort.Direction.DESC, "creationDate"),
					CartConstants.UserStages.BI_CLOSED, CartConstants.SMEStages.PO_CONFIRMED);
		} catch (CustomException e) {
			logger.log(Level.ALL, e);
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}
	}

	@Override
	@Cacheable(value = "sentCount", key = "#userId")
	public int getSentCount(String userId) {
		try {
			return cartItemRepo.sentCartCount(userId, CartConstants.UserStages.BI_CLOSED,
					CartConstants.SMEStages.PO_CONFIRMED);
		} catch (CustomException err) {
			logger.log(Level.ALL, err);
			throw new CustomException(err.getMessage(), err.getErrorCode());
		}
	}

	@Override
	@Cacheable(value = "recieveCount", key = "#userId")
	public int getRecievedCount(String userId) {
		try {
			return recieveBusinessInterestRepo.receivedCartCount(userId, CartConstants.UserStages.BI_CLOSED,
					CartConstants.SMEStages.PO_CONFIRMED);
		} catch (CustomException err) {
			logger.log(Level.ALL, err);
			throw new CustomException(err.getMessage(), err.getErrorCode());
		}
	}

	@Override
	@Cacheable(value = "recievedItems", key = "#uid")
	public RecievdBusinessInterest getRecieveInterest(String uid) {
		return recieveBusinessInterestRepo.findByUuidAndIsActive(uid, CartConstants.Flag.TRUE);
	}
}
