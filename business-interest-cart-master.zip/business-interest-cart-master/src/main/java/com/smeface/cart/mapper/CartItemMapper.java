package com.smeface.cart.mapper;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import com.smeface.cart.dto.CartItemDTO;
import com.smeface.cart.entity.CartItem;

@Component
public class CartItemMapper {

	private Logger logger = LogManager.getLogger(CartItemMapper.class);
	public CartItemDTO convertToDto(CartItem cartItem) {
		ModelMapper mapper = new ModelMapper();
		try {
			CartItemDTO cartItemDTO = mapper.map(cartItem, CartItemDTO.class);
			
			
			cartItemDTO.setIsActive(true);
			

			return cartItemDTO;
		} catch (Exception e) {
			logger.info(Level.ALL, e);
		}
		return null;
	}

	public CartItem convertToEntity(CartItemDTO cartItemDTO) {
		ModelMapper mapper = new ModelMapper();
		try {
			CartItem cartItem = mapper.map(cartItemDTO, CartItem.class);
			cartItemDTO.setBusinessInterestStages(true);
			return cartItem;
		} catch (Exception e) {
			logger.info(Level.ALL, e);
		}
		return null;
	}
}
