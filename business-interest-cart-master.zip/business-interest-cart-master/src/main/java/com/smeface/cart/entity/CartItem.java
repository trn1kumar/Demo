package com.smeface.cart.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.smeface.audit.Auditable;
import com.smeface.cart.dto.BiAttributeMapper;
import com.smeface.cart.status.entity.OrderStatus;

@Entity
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@Table(name = "cartitem")
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler","smeCartId"})
public class CartItem extends Auditable<String>  {

	private static final long serialVersionUID = 3956650320808291914L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long smeCartId;

	@Column(name = "CART_ITEM_UUID", unique = true)
	private String uuid;

	@Column(name = "BusinessInterestUUID")
	@NotBlank(message = "Product or Service UUID cannot be left blank")
	private String businessInterestUUID;

	@OneToOne(cascade = CascadeType.ALL)
	private BiAttributeMapper cartAttribute;

	@OneToOne(cascade = CascadeType.ALL)
	private OrderStatus orderStatus;

	@Column(name = "UserId")
	private String userUUId;

	@Column(name = "Provider", updatable = false, nullable = false)
	@Pattern(regexp = "^(PRODUCT|SERVICE)$", message = "Enter valid Provider")
	private String provider;

	@Column(name = "ACTIVE_STATUS")
	private Boolean isActive;

	@Column(name = "Reject_Status")
	private boolean rejectStatus;

	@Column(name = "BUSINES_INTEREST_QUANTITY")
	@Min(value = 1, message = "Minimum Business Interest quantity should be atleast 1 or more than 1")
	private Integer businessInterestQuantity;

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public boolean isRejectStatus() {
		return rejectStatus;
	}

	public void setRejectStatus(boolean rejectStatus) {
		this.rejectStatus = rejectStatus;
	}

	public OrderStatus getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(OrderStatus orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getProvider() {
		return provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public BiAttributeMapper getCartAttribute() {
		return cartAttribute;
	}

	public void setCartAttribute(BiAttributeMapper cartAttribute) {
		this.cartAttribute = cartAttribute;
	}

	public String getUserUUId() {
		return userUUId;
	}

	public void setUserUUId(String userUUId) {
		this.userUUId = userUUId;
	}

	public String getBusinessInterestUUID() {
		return businessInterestUUID;
	}

	public void setBusinessInterestUUID(String businessInterestUUID) {
		this.businessInterestUUID = businessInterestUUID;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Integer getBusinessInterestQuantity() {
		return businessInterestQuantity;
	}

	public void setBusinessInterestQuantity(Integer businessInterestQuantity) {
		this.businessInterestQuantity = businessInterestQuantity;
	}

	public Long getSmeCartId() {
		return smeCartId;
	}

	public void setSmeCartId(Long smeCartId) {
		this.smeCartId = smeCartId;
	}

	@Override
	public String toString() {
		return "CartItem [smeCartId=" + smeCartId + ", products=" + businessInterestUUID + ", userName=" + ", smeID="
				+ ", isActive=" + isActive + ", businessInterestStages=" + ", businessInterestQuantity="
				+ businessInterestQuantity + ", userBusinessInterestCreationDate="
				+ ", userBusinessInterestClosingDate=" + ", totalAmount=" + ", supplierBusinessInterestAcceptedDate="
				+ ", supplierBusinessInterestClosingDate=" + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((businessInterestQuantity == null) ? 0 : businessInterestQuantity.hashCode());
		result = prime * result + ((isActive == null) ? 0 : isActive.hashCode());
		result = prime * result + ((businessInterestUUID == null) ? 0 : businessInterestUUID.hashCode());
		result = prime * result + ((smeCartId == null) ? 0 : smeCartId.hashCode());

		result = prime * result + ((userUUId == null) ? 0 : userUUId.hashCode());
		result = prime * result + ((uuid == null) ? 0 : uuid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CartItem other = (CartItem) obj;
		if (businessInterestQuantity == null) {
			if (other.businessInterestQuantity != null)
				return false;
		} else if (!businessInterestQuantity.equals(other.businessInterestQuantity)) {
			return false;
		}
		if (isActive == null) {
			if (other.isActive != null)
				return false;
		} else if (!isActive.equals(other.isActive)) {
			return false;
		}
		if (businessInterestUUID == null) {
			if (other.businessInterestUUID != null)
				return false;
		} else if (!businessInterestUUID.equals(other.businessInterestUUID)) {
			return false;
		}
		if (smeCartId == null) {
			if (other.smeCartId != null)
				return false;
		} else if (!smeCartId.equals(other.smeCartId)) {
			return false;
		}

		if (userUUId == null) {
			if (other.userUUId != null)
				return false;
		} else if (!userUUId.equals(other.userUUId)) {
			return false;
		}
		if (uuid == null) {
			if (other.uuid != null)
				return false;
		} else if (!uuid.equals(other.uuid)) {
			return false;
		}
		return true;
	}

}