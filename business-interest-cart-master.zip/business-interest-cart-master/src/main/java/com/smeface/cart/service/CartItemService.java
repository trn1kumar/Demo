package com.smeface.cart.service;

import java.util.Set;

import com.smeface.cart.dto.PricingRequestDTO;
import com.smeface.cart.dto.QuotationPDF;
import com.smeface.cart.dto.UserDto;
import com.smeface.cart.entity.Cart;
import com.smeface.cart.entity.CartItem;

import net.sf.jasperreports.engine.JRException;

public interface CartItemService {

	void cart(Cart cartRequest,String smeId);

	void removeCartItem(String uuid);

	Cart getRecievedInterest(String userId, int page);

	Cart getSentInterest(String userId, int page);
	
	CartItem updateBusinessInterest(CartItem cartItem);

	int totalCountOfUserCart(String userId);

	Set<String> getServiceCartItems(String userUUID);

	public void biCountUpdate(Cart cart, String token);
	
	Set<String> getProductCartItems(String userUUID);

	UserDto userDetails(PricingRequestDTO pricingRequestDTO);

	boolean checkUUIDisExist(String userUUID, String uuid);
	
	public QuotationPDF generateQuotation(String cartId) throws JRException;

}