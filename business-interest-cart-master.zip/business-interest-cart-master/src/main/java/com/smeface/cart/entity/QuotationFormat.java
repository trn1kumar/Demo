package com.smeface.cart.entity;

public class QuotationFormat {

	private String formatPath;
	private String orderId;
	private String smeLogo;
	private String smeName;
	private String address;
	private String gstin;
	private String smeEmail;
	private String smePhone;
	private String userName;
	private String userEmail;
	private String userMobile;
	private String itemName;
	private String itemImage;
	private Integer quantity;
	private String unit;
	private Double itemActualPrice;
	private String discountedPrice;
	private Integer discount;
	private double gstPercentage;
	private String addedGST;
	private String totalAmount;
	private String amountInWords;
	private String termsAndCondition;

	public String getFormatPath() {
		return formatPath;
	}

	public void setFormatPath(String formatPath) {
		this.formatPath = formatPath;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getSmeLogo() {
		return smeLogo;
	}

	public void setSmeLogo(String smeLogo) {
		this.smeLogo = smeLogo;
	}

	public String getItemImage() {
		return itemImage;
	}

	public void setItemImage(String itemImage) {
		this.itemImage = itemImage;
	}

	public String getSmeName() {
		return smeName;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getSmeEmail() {
		return smeEmail;
	}

	public void setSmeEmail(String smeEmail) {
		this.smeEmail = smeEmail;
	}

	public String getSmePhone() {
		return smePhone;
	}

	public void setSmePhone(String smePhone) {
		this.smePhone = smePhone;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserMobile() {
		return userMobile;
	}

	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getAmountInWords() {
		return amountInWords;
	}

	public void setAmountInWords(String amountInWords) {
		this.amountInWords = amountInWords;
	}

	public String getTermsAndCondition() {
		return termsAndCondition;
	}

	public void setTermsAndCondition(String termsAndCondition) {
		this.termsAndCondition = termsAndCondition;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Double getItemActualPrice() {
		return itemActualPrice;
	}

	public void setItemActualPrice(Double itemActualPrice) {
		this.itemActualPrice = itemActualPrice;
	}

	public int getDiscount() {
		return discount;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}

	public double getGstPercentage() {
		return gstPercentage;
	}

	public void setGstPercentage(double gstPercentage) {
		this.gstPercentage = gstPercentage;
	}

	public void setDiscount(Integer discount) {
		this.discount = discount;
	}

	public String getDiscountedPrice() {
		return discountedPrice;
	}

	public void setDiscountedPrice(String discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

	public String getAddedGST() {
		return addedGST;
	}

	public void setAddedGST(String addedGST) {
		this.addedGST = addedGST;
	}

	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	@Override
	public String toString() {
		return "QuotationFormat [formatPath=" + formatPath + ", orderId=" + orderId + ", smeLogo=" + smeLogo
				+ ", smeName=" + smeName + ", address=" + address + ", gstin=" + gstin + ", smeEmail=" + smeEmail
				+ ", smePhone=" + smePhone + ", userName=" + userName + ", userEmail=" + userEmail + ", userMobile="
				+ userMobile + ", itemName=" + itemName + ", itemImage=" + itemImage + ", quantity=" + quantity
				+ ", unit=" + unit + ", itemActualPrice=" + itemActualPrice + ", discountedPrice=" + discountedPrice
				+ ", discount=" + discount + ", gstPercentage=" + gstPercentage + ", addedGST=" + addedGST
				+ ", totalAmount=" + totalAmount + ", amountInWords=" + amountInWords + ", termsAndCondition="
				+ termsAndCondition + "]";
	}

}
