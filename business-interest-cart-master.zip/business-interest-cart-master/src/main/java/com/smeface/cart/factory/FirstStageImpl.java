package com.smeface.cart.factory;

import com.smeface.cart.status.entity.FirstStage;

public class FirstStageImpl implements FactoryInterface<Object>{

	@Override
	public  Object returnObject() {
		return new FirstStage.FirstStageBuilder().build();
	}

}
