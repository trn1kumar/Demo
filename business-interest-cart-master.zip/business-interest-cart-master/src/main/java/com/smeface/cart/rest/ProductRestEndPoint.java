package com.smeface.cart.rest;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

import com.smeface.cart.dto.ProductDTO;
import com.smeface.cart.exception.CustomException;
import com.smeface.cart.securityconfiguration.Constants;
import com.smeface.cart.util.CustomHttpResponse;

public class ProductRestEndPoint {

	private Client client;
	private String productEndPointUrl;
	private String getProductPath;
	private String getBiPath;

	@Value("${product.details.path}")
	private String detailsPath;

	public ProductRestEndPoint(Client client, String productEndPointUrl, String getProductPath, String getBiPath) {
		this.getProductPath = getProductPath;
		this.client = client;
		this.productEndPointUrl = productEndPointUrl;
		this.getBiPath = getBiPath;
	}

	private Logger logger = LogManager.getLogger();

	public ProductDTO getProduct(String pUuid, boolean details, String token) {
		try {
			String path = null;
			if (details) {
				path = detailsPath.replace("{uuid}", pUuid);
			} else {
				path = getProductPath.replace("{uuid}", pUuid);
			}

			client = ClientBuilder.newClient();
			Response response = client.target(productEndPointUrl).path(path).request(MediaType.APPLICATION_JSON)
					.header(Constants.HEADER_STRING, token).get();

			CustomHttpResponse<ProductDTO> productDTO = null;
			Integer responseCode = response.getStatus();

			if (responseCode == HttpStatus.OK.value()) {
				productDTO = response.readEntity(new GenericType<CustomHttpResponse<ProductDTO>>() {
				});
				return productDTO.getData();

			} else if (responseCode == HttpStatus.BAD_REQUEST.value()) {
				return null;

			} else {
				throw new CustomException(" Internal Exception occrurred while fetching product,Invalid Response: "
						+ response.getStatusInfo().getReasonPhrase(), HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (CustomException e) {
			throw new CustomException(e.getErrorMessage(), e.getErrorCode());
		}
	}

	public void updateBiCountOfProduct(String productId, String token) {
		try {

			String pathUrl = getBiPath.replace("{pUid}", productId);
			Response response = client.target(productEndPointUrl).path(pathUrl).request(MediaType.APPLICATION_JSON)
					.header(Constants.HEADER_STRING, token).put(Entity.entity(productId, MediaType.APPLICATION_JSON));
			CustomHttpResponse<?> body = response.readEntity(new GenericType<CustomHttpResponse<?>>() {
			});
			if (!body.isError()) {
				logger.log(Level.ALL, "Updated product business count successfully");
			}
		} catch (CustomException e) {
			logger.log(Level.ALL, e);

		}
	}

}
