package com.smeface.cart.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.smeface.cart.entity.Cart;

@Repository
public interface CartRepo extends JpaRepository<Cart, Long>{

	Cart findByUuid(String uuid);
	Cart findByUserUuid(String userUUID);
	Page<Cart> findAll(Pageable pageable);
	
}
