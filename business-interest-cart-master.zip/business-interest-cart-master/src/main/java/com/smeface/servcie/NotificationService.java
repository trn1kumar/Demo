package com.smeface.servcie;

import java.util.List;

import com.smeface.cart.entity.CartItem;

public interface NotificationService {
	
	public void scheduleNotification(List<CartItem> cartItems, String stage, String token);

}
